const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const serverTimestamp = () => new Date(Date.now() - 1000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_EMAIL = "ogundiyatemidayo1@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read products, orders, or user private info", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("products").where("status", "==", "active").get());
  await assertFails(unauthDb.collection("orders").where("buyerId", "==", ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("private").doc("info").get());
});

test("User profile & private PII isolation: Alice can access hers, Bob cannot", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      selectedState: "Lagos",
      role: "buyer",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("info").set({
      userId: ALICE_UID,
      email: "alice@example.com",
      phone: "+2348000000000",
      shippingAddress: "12 Victoria Island, Lagos",
      shippingState: "Lagos",
      savedPaymentReady: true,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("private").doc("info").get());
});

test("Seller Storefront: seller cannot self-verify or inject ghost fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();

  // Attempt self-verification -> MUST FAIL
  await assertFails(
    aliceDb.collection("sellers").doc("seller_alice").set({
      ownerId: ALICE_UID,
      businessName: "Alice Lagos Lux",
      stateLocation: "Lagos",
      themeId: "emerald",
      verified: true,
      rating: 4.9,
      followersCount: 0,
      giftEarningsCoins: 0,
      status: "active",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Valid creation with verified: false -> MUST SUCCEED
  await assertSucceeds(
    aliceDb.collection("sellers").doc("seller_alice").set({
      ownerId: ALICE_UID,
      businessName: "Alice Lagos Lux",
      stateLocation: "Lagos",
      themeId: "emerald",
      verified: false,
      rating: 4.9,
      followersCount: 0,
      giftEarningsCoins: 0,
      status: "active",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Seller cannot flip verified to true on update -> MUST FAIL
  await assertFails(
    aliceDb.collection("sellers").doc("seller_alice").update({
      verified: true,
      updatedAt: serverTimestamp(),
    })
  );
});

test("Email spoofing test: unverified admin email cannot verify seller or read audit logs", async () => {
  const spoofAdminDb = testEnv
    .authenticatedContext("spoof_uid", { email: ADMIN_EMAIL, email_verified: false })
    .firestore();
  const realAdminDb = testEnv
    .authenticatedContext("admin_uid", { email: ADMIN_EMAIL, email_verified: true })
    .firestore();

  await assertFails(spoofAdminDb.collection("audit_logs").get());
  await assertSucceeds(
    realAdminDb.collection("audit_logs").doc("log_1").set({
      adminId: "admin_uid",
      adminEmail: ADMIN_EMAIL,
      action: "VERIFY_SELLER",
      targetPath: "sellers/seller_alice",
      summary: "Verified seller storefront",
      createdAt: serverTimestamp(),
    })
  );
});

test("Marketplace products: matching status query succeeds, unfiltered list fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("products").doc("prod_1").set({
      sellerId: ALICE_UID,
      sellerName: "Alice Lagos Lux",
      title: "Ankara Heritage Tote",
      category: "Fashion",
      brand: "LagosCraft",
      priceNaira: 45000,
      stockCount: 12,
      rating: 4.8,
      reviewCount: 15,
      isFlashDeal: false,
      status: "active",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  await assertSucceeds(bobDb.collection("products").where("status", "==", "active").get());
  await assertFails(bobDb.collection("products").get());
});

test("Live Auction: enforces minimum bid increment and blocks bidding after ended", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("auctions").doc("auc_1").set({
      sellerId: ALICE_UID,
      sellerName: "Alice Lagos Lux",
      productId: "prod_1",
      productTitle: "Ankara Heritage Tote",
      startingBidNaira: 20000,
      currentBidNaira: 20000,
      minIncrementNaira: 2000,
      bidCount: 0,
      endsAtEpochMs: Date.now() + 600000,
      status: "live",
      visibility: "public",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Underbid (+500 instead of +2000) -> MUST FAIL
  await assertFails(
    bobDb.collection("auctions").doc("auc_1").update({
      currentBidNaira: 20500,
      highestBidderId: BOB_UID,
      highestBidderName: "Bob",
      bidCount: 1,
      updatedAt: serverTimestamp(),
    })
  );

  // Valid bid (+2000) -> MUST SUCCEED
  await assertSucceeds(
    bobDb.collection("auctions").doc("auc_1").update({
      currentBidNaira: 22000,
      highestBidderId: BOB_UID,
      highestBidderName: "Bob",
      bidCount: 1,
      updatedAt: serverTimestamp(),
    })
  );

  // End auction -> then new bid MUST FAIL
  await assertSucceeds(
    aliceDb.collection("auctions").doc("auc_1").update({
      status: "ended",
      updatedAt: serverTimestamp(),
    })
  );

  await assertFails(
    bobDb.collection("auctions").doc("auc_1").update({
      currentBidNaira: 25000,
      highestBidderId: BOB_UID,
      highestBidderName: "Bob",
      bidCount: 2,
      updatedAt: serverTimestamp(),
    })
  );
});

test("Wallet & Ledger: wallet ledger is immutable (no update/delete) and cross-user read blocked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("wallet").doc("balance").set({
      userId: ALICE_UID,
      purchasedCoins: 500,
      promoTestCoins: 100,
      totalSpentNaira: 2500,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("wallet_ledger").doc("tx_1").set({
      userId: ALICE_UID,
      idempotencyKey: "idem_coin_1",
      entryType: "coin_purchase",
      coinBucket: "purchased",
      coinDelta: 500,
      amountNaira: 2500,
      description: "Purchased 500 Cash Coins via Flutterwave",
      createdAt: serverTimestamp(),
    })
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("wallet_ledger").doc("tx_1").update({
      coinDelta: 999999,
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("wallet_ledger").doc("tx_1").delete()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("wallet").doc("balance").get()
  );
});

test("Orders: terminal state locking prevents modification after delivered", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    bobDb.collection("orders").doc("ord_1").set({
      idempotencyKey: "idem_ord_1",
      buyerId: BOB_UID,
      sellerId: ALICE_UID,
      sellerName: "Alice Lagos Lux",
      itemsSummary: "1x Ankara Heritage Tote",
      totalNaira: 45000,
      deliveryState: "Lagos",
      deliveryAddress: "24 Admiralty Way, Lekki",
      paymentMethod: "flutterwave_card",
      paymentReference: "FLW_REF_12345",
      paymentStatus: "paid",
      orderStatus: "confirmed",
      sourceType: "marketplace",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Seller ships & delivers
  await assertSucceeds(
    aliceDb.collection("orders").doc("ord_1").update({
      orderStatus: "delivered",
      updatedAt: serverTimestamp(),
    })
  );

  // Delivered order is locked for buyer/seller
  await assertFails(
    bobDb.collection("orders").doc("ord_1").update({
      orderStatus: "cancelled",
      updatedAt: serverTimestamp(),
    })
  );
});

test("User Profile bio/avatarKey & uploaded short_videos: owner updates succeed, cross-user updates fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Creator",
      avatarKey: "seller_banner",
      bio: "Lagos luxury curator",
      selectedState: "Lagos",
      role: "buyer",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  // Owner updates bio & avatarKey -> MUST SUCCEED
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      bio: "Sharing verified leather & tech unboxings live from VI.",
      avatarKey: "live_fashion",
      updatedAt: serverTimestamp(),
    })
  );

  // Cross-user update -> MUST FAIL
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      bio: "Hacked bio",
      updatedAt: serverTimestamp(),
    })
  );

  // Oversized bio (> 240 chars) -> MUST FAIL
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      bio: "x".repeat(241),
      updatedAt: serverTimestamp(),
    })
  );

  // Upload shoppable short video and query by sellerId -> MUST SUCCEED
  await assertSucceeds(
    aliceDb.collection("short_videos").doc("vid_alice_1").set({
      sellerId: ALICE_UID,
      sellerName: "Alice Creator",
      title: "Unboxing Eko Leather Tote",
      caption: "24h nationwide shipping",
      productId: "prod_1",
      productTitle: "Eko Leather Tote",
      productPriceNaira: 62000,
      coverKey: "live_fashion",
      category: "Fashion",
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      status: "published",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("short_videos").where("sellerId", "==", ALICE_UID).get()
  );
});

test("Existence checks (resource == null) on non-existent docs succeed without leaking existing private orders", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Non-existent seller & order existence checks must succeed (returns exists = false)
  await assertSucceeds(aliceDb.collection("sellers").doc(`seller_${ALICE_UID}`).get());
  await assertSucceeds(aliceDb.collection("orders").doc("nonexistent_order_id").get());
  await assertSucceeds(aliceDb.collection("auctions").doc("nonexistent_auction_id").get());
  await assertSucceeds(aliceDb.collection("gift_transactions").doc("nonexistent_gift_tx").get());

  // Existing private order belonging to Alice must still block unrelated Bob
  await assertSucceeds(
    aliceDb.collection("orders").doc("ord_alice_private").set({
      idempotencyKey: "idem_alice_priv",
      buyerId: ALICE_UID,
      sellerId: "other_seller_uid",
      sellerName: "Other Seller",
      itemsSummary: "1x Watch",
      totalNaira: 35000,
      deliveryState: "Lagos",
      deliveryAddress: "10 Ikoyi Crescent",
      paymentMethod: "flutterwave_card",
      paymentReference: "FLW_PRIV_1",
      paymentStatus: "paid",
      orderStatus: "confirmed",
      sourceType: "marketplace",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );

  await assertFails(bobDb.collection("orders").doc("ord_alice_private").get());
});

test("Seller fulfillment 'processing', admin product 'flagged', and post-end auction winner claim", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv
    .authenticatedContext("admin_uid", { email: ADMIN_EMAIL, email_verified: true })
    .firestore();

  // Admin can flag active product
  await assertSucceeds(
    aliceDb.collection("products").doc("prod_mod_1").set({
      sellerId: ALICE_UID,
      sellerName: "Alice Lagos Lux",
      title: "Sample Watch",
      category: "Fashion",
      brand: "Eko",
      priceNaira: 15000,
      stockCount: 5,
      rating: 4.7,
      reviewCount: 3,
      isFlashDeal: false,
      status: "active",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    adminDb.collection("products").doc("prod_mod_1").update({
      status: "flagged",
      updatedAt: serverTimestamp(),
    })
  );

  // Seller can transition order to 'processing'
  await assertSucceeds(
    bobDb.collection("orders").doc("ord_proc_1").set({
      idempotencyKey: "idem_proc_1",
      buyerId: BOB_UID,
      sellerId: ALICE_UID,
      sellerName: "Alice Lagos Lux",
      itemsSummary: "1x Sample Watch",
      totalNaira: 15000,
      deliveryState: "Lagos",
      deliveryAddress: "14 Bourdillon Rd, Ikoyi",
      paymentMethod: "flutterwave_card",
      paymentReference: "FLW_PROC_1",
      paymentStatus: "paid",
      orderStatus: "confirmed",
      sourceType: "marketplace",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("orders").doc("ord_proc_1").update({
      orderStatus: "processing",
      updatedAt: serverTimestamp(),
    })
  );

  // Highest bidder can claim winningOrderId even after seller sets status='ended'
  await assertSucceeds(
    aliceDb.collection("auctions").doc("auc_claim_1").set({
      sellerId: ALICE_UID,
      sellerName: "Alice Lagos Lux",
      productId: "prod_mod_1",
      productTitle: "Sample Watch",
      startingBidNaira: 10000,
      currentBidNaira: 10000,
      minIncrementNaira: 1000,
      bidCount: 0,
      endsAtEpochMs: Date.now() + 60000,
      status: "live",
      visibility: "public",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("auctions").doc("auc_claim_1").update({
      currentBidNaira: 12000,
      highestBidderId: BOB_UID,
      highestBidderName: "Bob",
      bidCount: 1,
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("auctions").doc("auc_claim_1").update({
      status: "ended",
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(
    bobDb.collection("auctions").doc("auc_claim_1").update({
      status: "ended",
      winningOrderId: "ord_auc_claim_1",
      updatedAt: serverTimestamp(),
    })
  );
  // Second overwrite by winner once winningOrderId is already set -> MUST FAIL
  await assertFails(
    bobDb.collection("auctions").doc("auc_claim_1").update({
      status: "ended",
      winningOrderId: "ord_auc_claim_2",
      updatedAt: serverTimestamp(),
    })
  );
});


