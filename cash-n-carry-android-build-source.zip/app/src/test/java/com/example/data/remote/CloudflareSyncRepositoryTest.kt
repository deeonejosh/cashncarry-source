package com.example.data.remote

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.net.InetSocketAddress
import java.nio.charset.StandardCharsets

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CloudflareSyncRepositoryTest {
    private lateinit var server: HttpServer
    private lateinit var baseUrl: String
    private lateinit var storage: SessionStorage
    private lateinit var repository: CloudflareSyncRepository

    private val recordedRequests = mutableListOf<RecordedCall>()

    data class RecordedCall(
        val method: String,
        val path: String,
        val clientType: String?,
        val authorization: String?,
        val body: String
    )

    @Before
    fun setUp() {
        recordedRequests.clear()
        val context = ApplicationProvider.getApplicationContext<Context>()
        storage = SharedPreferencesSessionStorage(context).apply { clearSession() }
        server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        baseUrl = "http://127.0.0.1:${server.address.port}"

        server.createContext("/api/health") { exchange ->
            record(exchange)
            respond(
                exchange,
                200,
                """{"ok":true,"service":"cashncarry-d1-staging-worker","environment":"staging","dbConnected":true,"authDbConnected":true,"staging":{"paymentsEnabled":false,"coinsPurchasesEnabled":false,"kycUploadsEnabled":false,"orderReservationsEnabled":true}}"""
            )
        }

        server.createContext("/api/auth/login") { exchange ->
            val body = record(exchange)
            val json = JSONObject(body)
            val email = json.optString("email")
            if (email == "admin@cashncarryng.com") {
                respond(exchange, 200, """{"signedIn":true,"token":"${"a".repeat(64)}","user":{"id":"admin-1","email":"admin@cashncarryng.com","role":"admin"}}""")
            } else {
                respond(exchange, 200, """{"signedIn":true,"token":"${"b".repeat(64)}","user":{"id":"buyer-1","email":"$email","role":"buyer"}}""")
            }
        }

        server.createContext("/api/v1/profile") { exchange ->
            record(exchange)
            if (exchange.requestMethod == "GET") {
                respond(exchange, 200, """{"profile":{"user_id":"buyer-1","display_name":"Chidi Lagos","selected_state":"Abuja (FCT)"}}""")
            } else {
                respond(exchange, 200, """{"updated":true}""")
            }
        }

        server.createContext("/api/checkout") { exchange ->
            record(exchange)
            respond(exchange, 201, """{"order":{"id":"CNC-2026-8841","status":"awaiting_payment"}}""")
        }

        server.createContext("/api/payments/initialize") { exchange ->
            record(exchange)
            respond(exchange, 503, """{"error":"Payments temporarily unavailable","code":"PAYMENTS_DISABLED"}""")
        }

        server.createContext("/api/auth/logout") { exchange ->
            record(exchange)
            respond(exchange, 200, """{"signedOut":true}""")
        }

        server.start()
        repository = CloudflareSyncRepository(storage = storage, baseUrl = baseUrl)
    }

    @After
    fun tearDown() {
        server.stop(0)
    }

    @Test
    fun fetchHealth_persistsFailClosedStagingFlags() = runBlocking {
        val health = repository.fetchHealth()
        assertTrue(health.ok)
        assertEquals("cashncarry-d1-staging-worker", health.service)
        assertFalse(health.staging.paymentsEnabled)
        assertFalse(health.staging.coinsPurchasesEnabled)
        assertFalse(health.staging.kycUploadsEnabled)
        assertFalse(storage.getStagingFlags().paymentsEnabled)
    }

    @Test
    fun signInWithPassword_storesMobileBearerTokenAndRejectsAdminRole() = runBlocking {
        val buyerResult = repository.signInWithPassword("chidi@example.ng", "StagingPass#2026!")
        assertTrue(buyerResult is CloudflareResult.Success)
        val snapshot = (buyerResult as CloudflareResult.Success).data
        assertTrue(snapshot.signedIn)
        assertEquals("b".repeat(64), storage.getToken())
        assertEquals("Abuja (FCT)", snapshot.selectedState)

        val loginCall = recordedRequests.first { it.path == "/api/auth/login" }
        assertEquals("mobile", loginCall.clientType)

        storage.clearSession()
        val adminResult = repository.signInWithPassword("admin@cashncarryng.com", "AdminPass#2026!")
        assertTrue(adminResult is CloudflareResult.Failure)
        assertNull(storage.getToken())
    }

    @Test
    fun updateProfile_andCheckout_sendBearerTokenAndIdempotentRequestId() = runBlocking {
        storage.saveSession("c".repeat(64), "buyer-2", "amina@example.ng", "buyer")

        val profResult = repository.updateProfile(
            displayName = "Amina Bello",
            bio = "Lagos luxury fashion buyer",
            avatarUrl = "https://cdn.example/a.png",
            selectedState = "Rivers"
        )
        assertTrue(profResult is CloudflareResult.Success)
        val profCall = recordedRequests.last { it.path == "/api/v1/profile" }
        assertEquals("Bearer ${"c".repeat(64)}", profCall.authorization)
        assertEquals("mobile", profCall.clientType)
        assertEquals("Rivers", JSONObject(profCall.body).getString("selectedState"))

        val checkoutRes = repository.checkoutCart(requestId = "req-idem-001", addressId = "addr-1")
        assertTrue(checkoutRes is CloudflareResult.Success)
        assertEquals("CNC-2026-8841", (checkoutRes as CloudflareResult.Success).data)
        val checkoutCall = recordedRequests.last { it.path == "/api/checkout" }
        assertEquals("req-idem-001", JSONObject(checkoutCall.body).getString("request_id"))
    }

    @Test
    fun initializePayment_failsClosedWhenPaymentsDisabledInStaging() = runBlocking {
        repository.fetchHealth()
        val result = repository.initializePayment("CNC-2026-8841")
        assertTrue(result is CloudflareResult.Failure)
        val failure = result as CloudflareResult.Failure
        assertEquals(503, failure.statusCode)
        assertEquals("PAYMENTS_DISABLED", failure.code)
    }

    private fun record(exchange: HttpExchange): String {
        val body = exchange.requestBody.readBytes().toString(StandardCharsets.UTF_8)
        recordedRequests += RecordedCall(
            method = exchange.requestMethod,
            path = exchange.requestURI.path,
            clientType = exchange.requestHeaders.getFirst(CloudflareEndpoints.CLIENT_TYPE_HEADER),
            authorization = exchange.requestHeaders.getFirst("Authorization"),
            body = body
        )
        return body
    }

    private fun respond(exchange: HttpExchange, status: Int, jsonBody: String) {
        val bytes = jsonBody.toByteArray(StandardCharsets.UTF_8)
        exchange.responseHeaders.add("Content-Type", "application/json")
        exchange.sendResponseHeaders(status, bytes.size.toLong())
        exchange.responseBody.use { it.write(bytes) }
    }
}
