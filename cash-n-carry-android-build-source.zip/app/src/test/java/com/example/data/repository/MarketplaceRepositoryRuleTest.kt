package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class MarketplaceRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun authenticatedSeller_createsProductAndBuyerObservesActiveCatalog() = runBlocking {
        val sellerUid = signInTestUser(ALICE_EMAIL)
        val catalogRepo = CatalogRepository(firestore)

        val productResult = withTimeout(TIMEOUT_MS) {
            catalogRepo.createProductListing(
                sellerId = sellerUid,
                sellerName = "Alice Lux",
                title = "Lagos Gold Watch ${UUID.randomUUID().toString().take(6)}",
                description = "Minimalist sapphire crystal dress watch",
                category = "Watches & Jewelry",
                brand = "EkoTime",
                priceNaira = 35000L,
                originalPriceNaira = 45000L,
                stockCount = 8L,
                variants = listOf("Gold 40mm", "Silver 40mm"),
                isFlashDeal = true
            )
        }
        assertTrue("Expected product creation success: ${productResult.exceptionOrNull()}", productResult.isSuccess)
        val productId = productResult.getOrThrow()

        signInTestUser(BOB_EMAIL)
        val activeProducts = withTimeout(FLOW_TIMEOUT_MS) {
            catalogRepo.observeActiveProducts().first { list -> list.any { it.id == productId } }
        }
        assertTrue(activeProducts.any { it.id == productId && it.priceNaira == 35000L })
    }

    @Test
    fun unauthenticatedCaller_observeActiveProducts_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val catalogRepo = CatalogRepository(firestore)

        var caught: Exception? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                catalogRepo.observeActiveProducts().first()
            }
        } catch (e: Exception) {
            caught = e
        }
        val firestoreEx = checkNotNull(caught?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $caught"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx.code)
    }

    @Test
    fun walletAndVirtualGifting_promoCoinsRemainSeparateFromPurchasedCoins() = runBlocking {
        val buyerUid = signInTestUser(BOB_EMAIL)
        val liveRepo = LiveCommerceRepository(firestore)

        withTimeout(TIMEOUT_MS) {
            liveRepo.ensureWalletInitialized(buyerUid).getOrThrow()
            liveRepo.claimPromoTestCoins(buyerUid, 250L).getOrThrow()
            liveRepo.purchaseCoinsWithFlutterwave(buyerUid, 500L, 2500L).getOrThrow()
        }

        val wallet = withTimeout(FLOW_TIMEOUT_MS) {
            liveRepo.observeWallet(buyerUid).first { it.purchasedCoins >= 500L && it.promoTestCoins >= 250L }
        }
        assertTrue(wallet.purchasedCoins >= 500L)
        assertTrue(wallet.promoTestCoins >= 250L)
    }

    @Test
    fun auctionEngine_enforcesMinIncrementAndAllowsValidBid() = runBlocking {
        val sellerUid = signInTestUser(ALICE_EMAIL)
        val catalogRepo = CatalogRepository(firestore)
        val liveRepo = LiveCommerceRepository(firestore)

        val productId = withTimeout(TIMEOUT_MS) {
            catalogRepo.createProductListing(
                sellerId = sellerUid,
                sellerName = "Alice Lux",
                title = "Auction Sneaker ${UUID.randomUUID().toString().take(4)}",
                description = "Limited run",
                category = "Sneakers",
                brand = "VeloRun",
                priceNaira = 40000L,
                originalPriceNaira = 55000L,
                stockCount = 2L,
                variants = listOf("EU 43"),
                isFlashDeal = false
            ).getOrThrow()
        }
        val products = withTimeout(FLOW_TIMEOUT_MS) {
            catalogRepo.observeActiveProducts().first { list -> list.any { it.id == productId } }
        }
        val product = products.first { it.id == productId }

        val auctionId = withTimeout(TIMEOUT_MS) {
            liveRepo.createLiveAuction(
                sellerId = sellerUid,
                sellerName = "Alice Lux",
                product = product,
                startingBidNaira = 20000L,
                minIncrementNaira = 2000L,
                durationMinutes = 15L
            ).getOrThrow()
        }

        val bidderUid = signInTestUser(BOB_EMAIL)
        val underbid = withTimeout(TIMEOUT_MS) {
            liveRepo.placeAuctionBid(auctionId, bidderUid, "Bob", 20500L)
        }
        assertTrue("Underbid should fail", underbid.isFailure)

        val validBid = withTimeout(TIMEOUT_MS) {
            liveRepo.placeAuctionBid(auctionId, bidderUid, "Bob", 22000L)
        }
        assertTrue("Valid bid should succeed: ${validBid.exceptionOrNull()}", validBid.isSuccess)

        val syncedAuction = withTimeout(FLOW_TIMEOUT_MS) {
            liveRepo.observeAuction(auctionId).first {
                it != null && it.currentBidNaira == 22000L && it.highestBidderId == bidderUid && it.bidCount == 1L
            }
        }
        assertEquals(22000L, syncedAuction?.currentBidNaira)
        assertEquals("Bob", syncedAuction?.highestBidderName)
    }

    @Test
    fun userProfile_ownerUpdatesBioAndAvatarAndObservesUploadedShoppableVideos() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val catalogRepo = CatalogRepository(firestore)
        val liveRepo = LiveCommerceRepository(firestore)

        withTimeout(TIMEOUT_MS) {
            catalogRepo.ensureUserInitialized(aliceUid, "Alice Creator", ALICE_EMAIL).getOrThrow()
            catalogRepo.updateUserProfileDetails(
                userId = aliceUid,
                displayName = "Alice Lagos Studio",
                bio = "Curating fashion & tech drops from Lagos.",
                avatarKey = "live_fashion"
            ).getOrThrow()
        }

        val updatedProfile = withTimeout(FLOW_TIMEOUT_MS) {
            catalogRepo.observeUserProfile(aliceUid).first {
                it != null && it.displayName == "Alice Lagos Studio" && it.avatarKey == "live_fashion"
            }
        }
        assertEquals("Curating fashion & tech drops from Lagos.", updatedProfile?.bio)

        val productId = withTimeout(TIMEOUT_MS) {
            catalogRepo.createProductListing(
                sellerId = aliceUid,
                sellerName = "Alice Lagos Studio",
                title = "Studio Leather Clutch ${UUID.randomUUID().toString().take(4)}",
                description = "Handcrafted clutch",
                category = "Fashion",
                brand = "EkoLuxe",
                priceNaira = 32000L,
                originalPriceNaira = 40000L,
                stockCount = 5L,
                variants = listOf("Emerald"),
                isFlashDeal = false
            ).getOrThrow()
        }
        val product = withTimeout(FLOW_TIMEOUT_MS) {
            catalogRepo.observeActiveProducts().first { list -> list.any { it.id == productId } }
                .first { it.id == productId }
        }

        val videoId = withTimeout(TIMEOUT_MS) {
            liveRepo.publishShortVideo(
                sellerId = aliceUid,
                sellerName = "Alice Lagos Studio",
                title = "Inside My Studio Clutch Drop",
                caption = "Tap to shop in Naira",
                product = product
            ).getOrThrow()
        }

        val userVideos = withTimeout(FLOW_TIMEOUT_MS) {
            liveRepo.observeUserShortVideos(aliceUid).first { list -> list.any { it.id == videoId } }
        }
        assertTrue(userVideos.any { it.id == videoId && it.productId == productId })

        // Cross-user profile modification must fail with PERMISSION_DENIED
        signInTestUser(BOB_EMAIL)
        val crossUserUpdate = withTimeout(TIMEOUT_MS) {
            catalogRepo.updateUserProfileDetails(
                userId = aliceUid,
                displayName = "Hijacked",
                bio = "Should fail",
                avatarKey = "live_tech"
            )
        }
        assertTrue("Cross-user profile update must fail", crossUserUpdate.isFailure)
        val firestoreEx = crossUserUpdate.exceptionOrNull()?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }

    @Test
    fun bootstrapInitialMarketplaceCatalog_nonAdminFreshUser_succeedsAndRemainsIdempotent() = runBlocking {
        val freshUid = signInTestUser("fresh_buyer_${UUID.randomUUID().toString().take(6)}@gmail.com")
        val catalogRepo = CatalogRepository(firestore)

        val initResult = withTimeout(TIMEOUT_MS) {
            catalogRepo.ensureUserInitialized(freshUid, "Fresh User", "fresh@gmail.com")
        }
        assertTrue("User init failed: ${initResult.exceptionOrNull()}", initResult.isSuccess)

        val bootstrapResult = withTimeout(TIMEOUT_MS) {
            catalogRepo.bootstrapInitialMarketplaceCatalog(freshUid, "Fresh User")
        }
        assertTrue("Bootstrap failed: ${bootstrapResult.exceptionOrNull()}", bootstrapResult.isSuccess)

        val secondUid = signInTestUser("second_buyer_${UUID.randomUUID().toString().take(6)}@gmail.com")
        val secondBootstrap = withTimeout(TIMEOUT_MS) {
            catalogRepo.bootstrapInitialMarketplaceCatalog(secondUid, "Second User")
        }
        assertTrue("Second user bootstrap failed: ${secondBootstrap.exceptionOrNull()}", secondBootstrap.isSuccess)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_rule_test@cashncarry.test"
        const val BOB_EMAIL = "bob_rule_test@cashncarry.test"
        const val TIMEOUT_MS = 8000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
