package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.formatCompactCount
import com.example.core.formatNaira
import com.example.data.model.Product
import com.example.data.model.ShortVideo
import com.example.data.model.UserProfile
import com.example.data.model.WalletBalance
import com.example.data.remote.CloudflareHealthSnapshot
import com.example.data.remote.CloudflareSessionSnapshot
import com.example.ui.components.resolveDrawableRes
import com.example.ui.theme.BrandBorder
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandEmeraldDark
import com.example.ui.theme.BrandEmeraldSoft
import com.example.ui.theme.BrandMuted
import com.example.ui.theme.BrandNavy
import com.example.ui.theme.BrandSlate
import com.example.ui.theme.GoldCoin
import com.example.ui.theme.LiveCrimson
import com.example.ui.theme.SurfaceSoft

private val AVATAR_PRESETS = listOf(
    "seller_banner" to "Emerald Studio",
    "live_fashion" to "Runway Chic",
    "live_tech" to "Tech Creator",
    "hero_marketplace" to "Lagos Flagship"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    userProfile: UserProfile?,
    fallbackName: String,
    userEmail: String,
    googlePhotoUrl: String?,
    wallet: WalletBalance,
    uploadedVideos: List<ShortVideo>,
    catalogProducts: List<Product>,
    onBack: () -> Unit,
    onSaveProfile: (String, String, String) -> Unit,
    onUploadShoppableVideo: (String, String, String, Product) -> Unit,
    onWatchVideoFeed: () -> Unit,
    onOpenProduct: (Product) -> Unit,
    onOpenWallet: () -> Unit,
    onSignOut: () -> Unit,
    cloudflareHealth: CloudflareHealthSnapshot = CloudflareHealthSnapshot(),
    cloudflareSession: CloudflareSessionSnapshot = CloudflareSessionSnapshot(),
    onLinkCloudflareAccount: (String, String) -> Unit = { _, _ -> },
    onSignOutCloudflare: () -> Unit = {}
) {
    BackHandler { onBack() }

    val displayName = userProfile?.displayName?.ifBlank { fallbackName } ?: fallbackName
    val bio = userProfile?.bio.orEmpty()
    val avatarKey = userProfile?.avatarKey?.ifBlank { "seller_banner" } ?: "seller_banner"
    val selectedState = userProfile?.selectedState ?: "Lagos"
    val followingCount = userProfile?.followingSellerIds?.size ?: 0
    val totalVideoLikes = remember(uploadedVideos) { uploadedVideos.sumOf { it.likesCount } }

    var showEditSheet by remember { mutableStateOf(false) }
    var showUploadDialog by remember { mutableStateOf(false) }
    var showCloudflareLinkDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color.White,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "My Profile",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrandSlate
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("profile_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = BrandSlate)
                    }
                },
                actions = {
                    IconButton(onClick = onSignOut, modifier = Modifier.testTag("profile_sign_out_button")) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Sign Out", tint = LiveCrimson)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val gridColumns = if (maxWidth >= 680.dp) 4 else 3
            val videoRows = remember(uploadedVideos, gridColumns) {
                uploadedVideos.chunked(gridColumns)
            }

            LazyColumn(
                contentPadding = PaddingValues(bottom = 28.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White)
            ) {
                // 1. Gradient Profile Header + Avatar + Bio
                item {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(104.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(BrandNavy, BrandEmeraldDark)
                                    )
                                )
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 56.dp, start = 16.dp, end = 16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(92.dp)
                                        .clickable { showEditSheet = true }
                                        .testTag("profile_avatar_box")
                                ) {
                                    ProfileAvatarImage(
                                        avatarKey = avatarKey,
                                        contentDescription = "$displayName avatar",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .border(3.dp, Color.White, CircleShape)
                                            .background(SurfaceSoft)
                                    )
                                    Surface(
                                        color = BrandEmerald,
                                        shape = CircleShape,
                                        border = BorderStroke(2.dp, Color.White),
                                        modifier = Modifier
                                            .size(28.dp)
                                            .align(Alignment.BottomEnd)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = "Edit avatar",
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { showEditSheet = true },
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, BrandBorder),
                                        modifier = Modifier
                                            .height(48.dp)
                                            .testTag("edit_profile_button")
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(5.dp))
                                        Text("Edit Profile")
                                    }
                                    Button(
                                        onClick = { showUploadDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .height(48.dp)
                                            .testTag("upload_shoppable_video_button")
                                    ) {
                                        Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(5.dp))
                                        Text("Post Video")
                                    }
                                }
                            }

                            Spacer(Modifier.height(12.dp))

                            Text(
                                text = displayName,
                                style = MaterialTheme.typography.headlineSmall,
                                color = BrandSlate,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = BrandEmerald,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = "$selectedState • $userEmail",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BrandMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Spacer(Modifier.height(10.dp))

                            Surface(
                                color = SurfaceSoft,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, BrandBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showEditSheet = true }
                                    .testTag("profile_bio_card")
                            ) {
                                Text(
                                    text = bio.ifBlank { "Tap Edit Profile to add your bio, favorite Nigerian brands, and creator showcase notes." },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (bio.isNotBlank()) BrandSlate else BrandMuted,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }

                            Spacer(Modifier.height(14.dp))

                            // Stats Row
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                ProfileStatPill(
                                    label = "Videos",
                                    value = "${uploadedVideos.size}",
                                    accent = BrandNavy,
                                    modifier = Modifier.weight(1f)
                                )
                                ProfileStatPill(
                                    label = "Likes",
                                    value = formatCompactCount(totalVideoLikes),
                                    accent = LiveCrimson,
                                    modifier = Modifier.weight(1f)
                                )
                                ProfileStatPill(
                                    label = "Following",
                                    value = "$followingCount",
                                    accent = BrandEmerald,
                                    modifier = Modifier.weight(1f)
                                )
                                ProfileStatPill(
                                    label = "Coins",
                                    value = "${wallet.purchasedCoins + wallet.promoTestCoins}",
                                    accent = GoldCoin,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable(onClick = onOpenWallet)
                                )
                            }

                            Spacer(Modifier.height(14.dp))

                            Surface(
                                color = BrandEmeraldSoft.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, BrandEmerald.copy(alpha = 0.25f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("cloudflare_sync_card")
                            ) {
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(14.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "Cloudflare Web & D1 Sync",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = BrandNavy
                                        )
                                        Surface(
                                            color = if (cloudflareHealth.ok) BrandEmerald else BrandMuted,
                                            shape = RoundedCornerShape(50)
                                        ) {
                                            Text(
                                                text = if (cloudflareHealth.ok) "Staging Connected" else "Offline Cache",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = if (cloudflareSession.signedIn) {
                                            "Synced as ${cloudflareSession.email} (${cloudflareSession.role.uppercase()})"
                                        } else {
                                            "Link your Cash N Carry web account to sync cart, wishlist, follows, and orders across website & Android."
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = BrandSlate
                                    )
                                    Text(
                                        text = "Staging flags: Payments ${if (cloudflareHealth.staging.paymentsEnabled) "Enabled" else "Disabled"} • KYC Uploads ${if (cloudflareHealth.staging.kycUploadsEnabled) "Enabled" else "Disabled"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = BrandMuted
                                    )
                                    if (cloudflareSession.signedIn) {
                                        OutlinedButton(
                                            onClick = onSignOutCloudflare,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .height(48.dp)
                                                .testTag("cloudflare_unlink_button")
                                        ) {
                                            Text("Disconnect Web Sync")
                                        }
                                    } else {
                                        Button(
                                            onClick = { showCloudflareLinkDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .height(48.dp)
                                                .testTag("cloudflare_link_button")
                                        ) {
                                            Text("Sign In to Web Sync")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. Shoppable Videos Grid Header
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 12.dp, top = 20.dp, bottom = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = BrandEmerald, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Uploaded Shoppable Videos (${uploadedVideos.size})",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandSlate,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (uploadedVideos.isNotEmpty()) {
                            TextButton(onClick = onWatchVideoFeed) {
                                Text("Open Reels", color = BrandEmerald)
                            }
                        }
                    }
                }

                // 3. Responsive 3/4-Column Grid of Uploaded Shoppable Videos
                if (uploadedVideos.isEmpty()) {
                    item {
                        Surface(
                            color = SurfaceSoft,
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, BrandBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(28.dp)
                            ) {
                                Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = BrandEmerald, modifier = Modifier.size(36.dp))
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = "No shoppable videos uploaded yet",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = BrandSlate
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "Tag a marketplace product and publish a short video to showcase it on your profile grid.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BrandMuted
                                )
                                Spacer(Modifier.height(14.dp))
                                Button(
                                    onClick = { showUploadDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavy),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Text("Upload Shoppable Video")
                                }
                            }
                        }
                    }
                } else {
                    items(videoRows) { rowVideos ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                        ) {
                            rowVideos.forEach { video ->
                                ShoppableVideoGridTile(
                                    video = video,
                                    onClick = {
                                        val linked = catalogProducts.find { it.id == video.productId }
                                        if (linked != null) {
                                            onOpenProduct(linked)
                                        } else {
                                            onWatchVideoFeed()
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            repeat(gridColumns - rowVideos.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditSheet) {
        var editedName by remember(displayName) { mutableStateOf(displayName) }
        var editedBio by remember(bio) { mutableStateOf(bio) }
        var selectedAvatar by remember(avatarKey) { mutableStateOf(avatarKey) }

        ModalBottomSheet(
            onDismissRequest = { showEditSheet = false },
            containerColor = Color.White
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text("Edit Firestore Profile", style = MaterialTheme.typography.titleLarge, color = BrandSlate)

                OutlinedTextField(
                    value = editedName,
                    onValueChange = { editedName = it.take(80) },
                    label = { Text("Display Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_profile_name_input")
                )

                OutlinedTextField(
                    value = editedBio,
                    onValueChange = { editedBio = it.take(240) },
                    label = { Text("Bio (${editedBio.length}/240)") },
                    minLines = 3,
                    maxLines = 4,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_profile_bio_input")
                )

                Text("Choose Avatar", style = MaterialTheme.typography.titleSmall, color = BrandSlate)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!googlePhotoUrl.isNullOrBlank()) {
                        item {
                            AvatarChoiceChip(
                                key = googlePhotoUrl,
                                label = "Google Photo",
                                selected = selectedAvatar == googlePhotoUrl,
                                onClick = { selectedAvatar = googlePhotoUrl }
                            )
                        }
                    }
                    items(AVATAR_PRESETS) { (key, label) ->
                        AvatarChoiceChip(
                            key = key,
                            label = label,
                            selected = selectedAvatar == key,
                            onClick = { selectedAvatar = key }
                        )
                    }
                }

                Button(
                    onClick = {
                        onSaveProfile(editedName, editedBio, selectedAvatar)
                        showEditSheet = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_profile_button")
                ) {
                    Text("Save Profile to Firestore", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showUploadDialog) {
        val defaultProd = catalogProducts.firstOrNull()
        var chosenProduct by remember(catalogProducts) { mutableStateOf(defaultProd) }
        var videoTitle by remember { mutableStateOf("") }
        var videoCaption by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showUploadDialog = false },
            title = { Text("Upload Shoppable Video") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = videoTitle,
                        onValueChange = { videoTitle = it },
                        label = { Text("Video Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = videoCaption,
                        onValueChange = { videoCaption = it },
                        label = { Text("Caption") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (catalogProducts.isNotEmpty()) {
                        Text("Tag Marketplace Product", style = MaterialTheme.typography.labelLarge, color = BrandSlate)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(catalogProducts.take(6), key = { it.id }) { prod ->
                                FilterChip(
                                    selected = chosenProduct?.id == prod.id,
                                    onClick = { chosenProduct = prod },
                                    label = { Text(prod.title.take(18)) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = videoTitle.isNotBlank() && chosenProduct != null,
                    onClick = {
                        chosenProduct?.let { prod ->
                            onUploadShoppableVideo(
                                displayName,
                                videoTitle,
                                videoCaption.ifBlank { "Shop ${prod.title} on Cash N Carry!" },
                                prod
                            )
                            showUploadDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald)
                ) {
                    Text("Publish")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUploadDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showCloudflareLinkDialog) {
        var linkEmail by remember(userEmail) { mutableStateOf(userEmail) }
        var linkPassword by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCloudflareLinkDialog = false },
            title = { Text("Link Cash N Carry Web Sync") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Sign in with your verified Cash N Carry web credentials (12+ char password) to sync via Bearer token.",
                        style = MaterialTheme.typography.bodySmall,
                        color = BrandMuted
                    )
                    OutlinedTextField(
                        value = linkEmail,
                        onValueChange = { linkEmail = it },
                        label = { Text("Email") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cloudflare_link_email_input")
                    )
                    OutlinedTextField(
                        value = linkPassword,
                        onValueChange = { linkPassword = it },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cloudflare_link_password_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = linkEmail.isNotBlank() && linkPassword.length >= 12,
                    onClick = {
                        onLinkCloudflareAccount(linkEmail.trim(), linkPassword)
                        showCloudflareLinkDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald)
                ) {
                    Text("Link Account")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCloudflareLinkDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ProfileAvatarImage(
    avatarKey: String,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    if (avatarKey.startsWith("http://") || avatarKey.startsWith("https://")) {
        AsyncImage(
            model = avatarKey,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Image(
            painter = painterResource(id = resolveDrawableRes(avatarKey)),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    }
}

@Composable
private fun AvatarChoiceChip(
    key: String,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        ProfileAvatarImage(
            avatarKey = key,
            contentDescription = label,
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) BrandEmerald else BrandBorder,
                    shape = CircleShape
                )
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) BrandEmerald else BrandMuted,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun ProfileStatPill(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = BrandEmeraldSoft.copy(alpha = 0.45f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BrandBorder),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = accent,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = BrandMuted
            )
        }
    }
}

@Composable
private fun ShoppableVideoGridTile(
    video: ShortVideo,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BrandNavy),
        modifier = modifier
            .aspectRatio(0.72f)
            .clickable(onClick = onClick)
            .testTag("profile_video_tile_${video.id}")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = resolveDrawableRes(video.coverKey)),
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.25f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            )
            Surface(
                color = Color.Black.copy(alpha = 0.55f),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = LiveCrimson,
                        modifier = Modifier.size(11.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                    Text(
                        text = formatCompactCount(video.likesCount),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Play shoppable video",
                tint = Color.White.copy(alpha = 0.9f),
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(30.dp)
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            ) {
                Surface(
                    color = BrandEmerald,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = formatNaira(video.productPriceNaira),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
                Spacer(Modifier.height(3.dp))
                Text(
                    text = video.title,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
