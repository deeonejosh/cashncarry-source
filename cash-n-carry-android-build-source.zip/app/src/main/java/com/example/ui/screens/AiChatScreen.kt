package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.remote.SharedPreferencesSessionStorage
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private data class ChatLine(val fromUser: Boolean, val text: String)
private val chatHttp = OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build()

@Composable
fun AiChatScreen(onBack: () -> Unit) {
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val messages = remember { mutableStateListOf<ChatLine>() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val endpoint = BuildConfig.CHAT_API_BASE_URL.trimEnd('/')
    val sessionStore = remember { SharedPreferencesSessionStorage(context) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("Back") }
        Text("AI Shopping Assistant", style = MaterialTheme.typography.headlineSmall)
        Text("Avoid sharing passwords, card details or sensitive information.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { line ->
                Card { Text((if (line.fromUser) "You: " else "Assistant: ") + line.text, Modifier.padding(12.dp)) }
            }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = draft,
                onValueChange = { if (it.length <= 4000) draft = it },
                label = { Text("Message") },
                modifier = Modifier.weight(1f),
                enabled = !busy && endpoint.isNotBlank(),
                maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            Button(enabled = !busy && draft.isNotBlank() && endpoint.isNotBlank(), onClick = {
                val message = draft.trim()
                draft = ""
                messages.add(ChatLine(true, message))
                busy = true
                error = null
                scope.launch {
                    try {
                        val reply = withContext(Dispatchers.IO) {
                            val payload = JSONObject().put("message", message).toString()
                            val token = sessionStore.getToken() ?: throw IllegalStateException("Please sign in first")
                            val request = Request.Builder().url("$endpoint/api/chat")
                                .header("Authorization", "Bearer $token")
                                .post(payload.toRequestBody("application/json".toMediaType()))
                                .build()
                            chatHttp.newCall(request).execute().use { response ->
                                if (!response.isSuccessful) throw IllegalStateException("Chat unavailable (HTTP ${response.code})")
                                JSONObject(response.body?.string().orEmpty()).getString("reply")
                            }
                        }
                        messages.add(ChatLine(false, reply))
                    } catch (_: Exception) {
                        error = "Unable to reach the chat service. Please try again."
                    } finally { busy = false }
                }
            }) { Text("Send") }
        }
        if (endpoint.isBlank()) Text("Chat is not configured for this build.", style = MaterialTheme.typography.bodySmall)
    }
}
