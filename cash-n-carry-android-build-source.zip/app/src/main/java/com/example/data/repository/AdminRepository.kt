package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.AuditLog
import com.example.data.model.Dispute
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class AdminRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    fun observeDisputesForAdmin(): Flow<List<Dispute>> =
        db.collection("disputes")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    Dispute::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "disputes")
                throw error
            }

    fun observeAuditLogs(): Flow<List<AuditLog>> =
        db.collection("audit_logs")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    AuditLog::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "audit_logs")
                throw error
            }

    suspend fun fileReportOrDispute(
        reporterId: String,
        targetType: String,
        targetId: String,
        reason: String
    ): Result<String> = runCatching {
        val ref = db.collection("disputes").document()
        ref.set(
            mapOf(
                "reporterId" to reporterId,
                "targetType" to targetType,
                "targetId" to targetId,
                "reason" to reason.trim().take(500),
                "status" to "open",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        ref.id
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "disputes")
    }

    suspend fun verifySeller(
        adminId: String,
        adminEmail: String,
        sellerId: String,
        verified: Boolean
    ): Result<Unit> = runCatching {
        db.collection("sellers").document(sellerId)
            .update(
                mapOf(
                    "verified" to verified,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        writeAuditLog(
            adminId = adminId,
            adminEmail = adminEmail,
            action = if (verified) "VERIFY_SELLER" else "UNVERIFY_SELLER",
            targetPath = "sellers/$sellerId",
            summary = "Updated verified=$verified for seller $sellerId"
        )
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "sellers/$sellerId")
    }

    suspend fun moderateProduct(
        adminId: String,
        adminEmail: String,
        productId: String,
        newStatus: String
    ): Result<Unit> = runCatching {
        db.collection("products").document(productId)
            .update(
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        writeAuditLog(
            adminId = adminId,
            adminEmail = adminEmail,
            action = "MODERATE_PRODUCT",
            targetPath = "products/$productId",
            summary = "Set product status=$newStatus"
        )
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "products/$productId")
    }

    suspend fun createOrUpdateVirtualGift(
        adminId: String,
        adminEmail: String,
        giftId: String?,
        name: String,
        category: String,
        coinCost: Long,
        animationType: String
    ): Result<Unit> = runCatching {
        val ref = if (giftId.isNullOrBlank()) db.collection("gifts").document() else db.collection("gifts").document(giftId)
        val snap = ref.get().await()
        if (snap.exists()) {
            ref.update(
                mapOf(
                    "name" to name.trim().take(60),
                    "category" to category,
                    "coinCost" to coinCost.coerceIn(1L, 100000L),
                    "animationType" to animationType,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            ref.set(
                mapOf(
                    "name" to name.trim().take(60),
                    "category" to category,
                    "coinCost" to coinCost.coerceIn(1L, 100000L),
                    "animationType" to animationType,
                    "colorHex" to "#F59E0B",
                    "enabled" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        writeAuditLog(
            adminId = adminId,
            adminEmail = adminEmail,
            action = "UPSERT_GIFT",
            targetPath = "gifts/${ref.id}",
            summary = "Configured gift $name ($coinCost coins)"
        )
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "gifts")
    }

    suspend fun resolveDispute(
        adminId: String,
        adminEmail: String,
        disputeId: String,
        status: String,
        note: String
    ): Result<Unit> = runCatching {
        db.collection("disputes").document(disputeId)
            .update(
                mapOf(
                    "status" to status,
                    "resolutionNote" to note.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        writeAuditLog(
            adminId = adminId,
            adminEmail = adminEmail,
            action = "RESOLVE_DISPUTE",
            targetPath = "disputes/$disputeId",
            summary = "Dispute $disputeId marked $status: $note"
        )
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "disputes/$disputeId")
    }

    private suspend fun writeAuditLog(
        adminId: String,
        adminEmail: String,
        action: String,
        targetPath: String,
        summary: String
    ) {
        db.collection("audit_logs").document().set(
            mapOf(
                "adminId" to adminId,
                "adminEmail" to adminEmail.ifBlank { "admin@cashncarryng.com" },
                "action" to action,
                "targetPath" to targetPath,
                "summary" to summary.take(400),
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    private fun logFlowError(error: Throwable, op: OperationType, path: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        handleFirestoreError(firestoreError ?: error, op, path)
    }
}
