package com.example.data.repository

import android.util.Log
import com.example.data.model.Product
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class AiSearchAdvice(
    val summary: String,
    val recommendedProductIds: List<String>,
    val suggestedQueries: List<String>
)

class AiRecommendationRepository {

    private val adviceSchema = Schema.obj(
        properties = mapOf(
            "summary" to Schema.string(description = "Brief 1-2 sentence Nigerian marketplace shopping insight"),
            "recommendedProductIds" to Schema.array(
                items = Schema.string(),
                description = "Up to 4 matching product IDs from the provided catalog"
            ),
            "suggestedQueries" to Schema.array(
                items = Schema.string(),
                description = "Up to 3 refined predictive search suggestions"
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = adviceSchema
            }
        )
    }

    suspend fun getSearchRecommendations(
        query: String,
        selectedState: String,
        catalog: List<Product>,
        recentIds: List<String>
    ): Result<AiSearchAdvice> {
        return try {
            val catalogContext = catalog.take(20).joinToString("\n") { p ->
                "- id=${p.id} | title=${p.title} | category=${p.category} | brand=${p.brand} | priceNaira=${p.priceNaira}"
            }
            val prompt = """
                You are the smart shopping search engine for Cash N Carry Nigeria (cashncarryng.com).
                User query: "$query"
                Delivery state: "$selectedState"
                Recently viewed IDs: ${recentIds.joinToString(",")}
                Available catalog:
                $catalogContext

                Pick the best matching product IDs from the catalog above, write a crisp 1-2 sentence buying insight in Naira context, and suggest 3 short predictive search queries.
            """.trimIndent()

            val response = withTimeout(45_000L) {
                model.generateContent(prompt)
            }
            val rawJson = response.text ?: throw IllegalStateException("Empty AI response")
            val json = JSONObject(rawJson)
            val summary = json.optString("summary", "Curated picks for $selectedState shoppers.")
            val idsArr = json.optJSONArray("recommendedProductIds")
            val ids = if (idsArr != null) {
                (0 until idsArr.length()).map { idsArr.getString(it) }
            } else emptyList()
            val queriesArr = json.optJSONArray("suggestedQueries")
            val queries = if (queriesArr != null) {
                (0 until queriesArr.length()).map { queriesArr.getString(it) }
            } else emptyList()

            Result.success(AiSearchAdvice(summary, ids, queries))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI recommendation timed out", e)
            Result.failure(IllegalStateException("AI recommendation timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI recommendation failed", e)
            Result.failure(e)
        }
    }

    private companion object {
        const val TAG = "AiRecRepo"
    }
}
