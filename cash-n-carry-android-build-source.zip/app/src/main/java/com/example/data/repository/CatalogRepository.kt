package com.example.data.repository

import android.content.Context
import com.example.BuildConfig
import com.example.R
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.CartItem
import com.example.data.model.MarketplaceOrder
import com.example.data.model.Product
import com.example.data.model.ProductReview
import com.example.data.model.SellerStorefront
import com.example.data.model.UserPrivateInfo
import com.example.data.model.UserProfile
import com.example.data.model.WishlistItem
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class CatalogRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    fun observeActiveProducts(): Flow<List<Product>> =
        db.collection("products")
            .whereEqualTo("status", "active")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    Product::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "products")
                throw error
            }

    fun observeSellerProducts(sellerId: String): Flow<List<Product>> =
        db.collection("products")
            .whereEqualTo("sellerId", sellerId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    Product::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "products")
                throw error
            }

    fun observeActiveSellers(): Flow<List<SellerStorefront>> =
        db.collection("sellers")
            .whereEqualTo("status", "active")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    SellerStorefront::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "sellers")
                throw error
            }

    fun observeProductReviews(productId: String): Flow<List<ProductReview>> =
        db.collection("products").document(productId).collection("reviews")
            .whereEqualTo("visibility", "public")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    ProductReview::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "products/$productId/reviews")
                throw error
            }

    fun observeUserProfile(userId: String): Flow<UserProfile?> =
        db.collection("users").document(userId)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                } else null
            }
            .catch { error ->
                logFlowError(error, OperationType.GET, "users/$userId")
                throw error
            }

    fun observeUserPrivateInfo(userId: String): Flow<UserPrivateInfo?> =
        db.collection("users").document(userId).collection("private").document("info")
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(
                        UserPrivateInfo::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                } else null
            }
            .catch { error ->
                logFlowError(error, OperationType.GET, "users/$userId/private/info")
                throw error
            }

    fun observeCart(userId: String): Flow<List<CartItem>> =
        db.collection("users").document(userId).collection("cart")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    CartItem::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "users/$userId/cart")
                throw error
            }

    fun observeWishlist(userId: String): Flow<List<WishlistItem>> =
        db.collection("users").document(userId).collection("wishlist")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    WishlistItem::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "users/$userId/wishlist")
                throw error
            }

    fun observeBuyerOrders(buyerId: String): Flow<List<MarketplaceOrder>> =
        db.collection("orders")
            .whereEqualTo("buyerId", buyerId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    MarketplaceOrder::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "orders")
                throw error
            }

    fun observeSellerOrders(sellerId: String): Flow<List<MarketplaceOrder>> =
        db.collection("orders")
            .whereEqualTo("sellerId", sellerId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    MarketplaceOrder::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "orders")
                throw error
            }

    suspend fun ensureUserInitialized(
        userId: String,
        displayName: String,
        email: String
    ): Result<Unit> = runCatching {
        val userRef = db.collection("users").document(userId)
        val snap = userRef.get().await()
        if (!snap.exists()) {
            val profilePayload = mapOf(
                "userId" to userId,
                "displayName" to displayName.ifBlank { "Shopper" }.take(80),
                "avatarKey" to "seller_banner",
                "bio" to "Social shopper & creator on Cash N Carry Nigeria.",
                "selectedState" to "Lagos",
                "role" to "buyer",
                "followingSellerIds" to emptyList<String>(),
                "recentProductIds" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            userRef.set(profilePayload).await()
        }

        val privateRef = userRef.collection("private").document("info")
        val privSnap = privateRef.get().await()
        if (!privSnap.exists()) {
            val privPayload = mapOf(
                "userId" to userId,
                "email" to email.take(160),
                "phone" to "",
                "shippingAddress" to "",
                "shippingState" to "Lagos",
                "savedPaymentReady" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            privateRef.set(privPayload).await()
        }
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "users/$userId")
    }

    suspend fun updateUserProfileDetails(
        userId: String,
        displayName: String,
        bio: String,
        avatarKey: String
    ): Result<Unit> = runCatching {
        db.collection("users").document(userId)
            .update(
                mapOf(
                    "displayName" to displayName.trim().ifBlank { "Shopper" }.take(80),
                    "bio" to bio.trim().take(240),
                    "avatarKey" to avatarKey.trim().ifBlank { "seller_banner" }.take(400),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "users/$userId")
    }

    suspend fun updateSelectedState(userId: String, state: String): Result<Unit> = runCatching {
        db.collection("users").document(userId)
            .update(
                mapOf(
                    "selectedState" to state,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "users/$userId")
    }

    suspend fun recordRecentlyViewed(
        userId: String,
        currentRecent: List<String>,
        productId: String
    ): Result<Unit> = runCatching {
        val updated = (listOf(productId) + currentRecent.filterNot { it == productId }).take(12)
        db.collection("users").document(userId)
            .update(
                mapOf(
                    "recentProductIds" to updated,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "users/$userId")
    }

    suspend fun toggleFollowSeller(
        userId: String,
        sellerId: String,
        currentlyFollowing: List<String>
    ): Result<Boolean> = runCatching {
        val rawOwnerId = sellerId.removePrefix("seller_")
        val isFollowing = currentlyFollowing.contains(rawOwnerId) || currentlyFollowing.contains(sellerId)
        val updated = if (isFollowing) {
            currentlyFollowing.filterNot { it == rawOwnerId || it == sellerId }
        } else {
            (currentlyFollowing + rawOwnerId).distinct().take(190)
        }
        db.collection("users").document(userId)
            .update(
                mapOf(
                    "followingSellerIds" to updated,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

        val canonicalRef = db.collection("sellers").document("seller_$rawOwnerId")
        val legacyRef = db.collection("sellers").document(rawOwnerId)
        val targetRef = if (canonicalRef.get().await().exists()) canonicalRef else legacyRef

        db.runTransaction { tx ->
            val sellerSnap = tx.get(targetRef)
            if (sellerSnap.exists()) {
                val currentCount = sellerSnap.getLong("followersCount") ?: 0L
                val nextCount = if (isFollowing) (currentCount - 1L).coerceAtLeast(0L) else currentCount + 1L
                tx.update(
                    targetRef,
                    mapOf(
                        "followersCount" to nextCount,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            null
        }.await()
        !isFollowing
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "sellers/$sellerId")
    }

    suspend fun saveShippingAndPaymentSetup(
        userId: String,
        phone: String,
        address: String,
        state: String
    ): Result<Unit> = runCatching {
        val privateRef = db.collection("users").document(userId).collection("private").document("info")
        privateRef.update(
            mapOf(
                "phone" to phone.trim().take(30),
                "shippingAddress" to address.trim().take(300),
                "shippingState" to state,
                "savedPaymentReady" to true,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "users/$userId/private/info")
    }

    suspend fun addToCart(
        userId: String,
        product: Product,
        variantLabel: String,
        quantity: Long = 1L
    ): Result<Unit> = runCatching {
        val docId = "${product.id}_${variantLabel.replace(Regex("[^a-zA-Z0-9_-]"), "_")}".take(120)
        val cartRef = db.collection("users").document(userId).collection("cart").document(docId)
        val existing = cartRef.get().await()
        if (existing.exists()) {
            val curQty = existing.getLong("quantity") ?: 1L
            cartRef.update(
                mapOf(
                    "quantity" to (curQty + quantity).coerceAtMost(99L),
                    "unitPriceNaira" to product.priceNaira,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            cartRef.set(
                mapOf(
                    "userId" to userId,
                    "productId" to product.id,
                    "sellerId" to product.sellerId,
                    "sellerName" to product.sellerName,
                    "productTitle" to product.title,
                    "variantLabel" to variantLabel.ifBlank { "Standard" },
                    "unitPriceNaira" to product.priceNaira,
                    "quantity" to quantity.coerceIn(1L, 99L),
                    "imageKey" to product.imageKey,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "users/$userId/cart")
    }

    suspend fun updateCartQuantity(userId: String, cartItemId: String, newQty: Long): Result<Unit> = runCatching {
        val ref = db.collection("users").document(userId).collection("cart").document(cartItemId)
        if (newQty <= 0L) {
            ref.delete().await()
        } else {
            ref.update(
                mapOf(
                    "quantity" to newQty.coerceAtMost(99L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "users/$userId/cart/$cartItemId")
    }

    suspend fun toggleWishlist(userId: String, product: Product, isSaved: Boolean): Result<Boolean> = runCatching {
        val ref = db.collection("users").document(userId).collection("wishlist").document(product.id)
        if (isSaved) {
            ref.delete().await()
            false
        } else {
            ref.set(
                mapOf(
                    "userId" to userId,
                    "productId" to product.id,
                    "productTitle" to product.title,
                    "priceNaira" to product.priceNaira,
                    "sellerName" to product.sellerName,
                    "imageKey" to product.imageKey,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            true
        }
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "users/$userId/wishlist/${product.id}")
    }

    suspend fun submitReview(
        userId: String,
        userName: String,
        productId: String,
        rating: Long,
        comment: String
    ): Result<Unit> = runCatching {
        val ref = db.collection("products").document(productId).collection("reviews").document()
        ref.set(
            mapOf(
                "productId" to productId,
                "userId" to userId,
                "userName" to userName.ifBlank { "Verified Buyer" },
                "rating" to rating.coerceIn(1L, 5L),
                "comment" to comment.trim().take(500),
                "visibility" to "public",
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "products/$productId/reviews")
    }

    suspend fun checkoutCartWithFlutterwave(
        userId: String,
        cartItems: List<CartItem>,
        deliveryState: String,
        deliveryAddress: String,
        paymentMethod: String,
        sourceType: String = "marketplace"
    ): Result<List<String>> = runCatching {
        require(cartItems.isNotEmpty()) { "Cart is empty" }
        val flwMode = if (BuildConfig.FLUTTERWAVE_PUBLIC_KEY.contains("PLACEHOLDER")) "FLW-SANDBOX" else "FLW-LIVE"
        val txBatchId = UUID.randomUUID().toString().take(12).uppercase()
        val groupedBySeller = cartItems.groupBy { it.sellerId }
        val createdOrderIds = mutableListOf<String>()

        for ((sellerId, items) in groupedBySeller) {
            val idemKey = "ord_${txBatchId}_${sellerId.take(12)}"
            val orderId = "ord_${idemKey}"
            val orderRef = db.collection("orders").document(orderId)
            val existingOrder = orderRef.get().await()
            if (!existingOrder.exists()) {
                val totalNaira = items.sumOf { it.unitPriceNaira * it.quantity }
                val summary = items.joinToString(", ") { "${it.quantity}x ${it.productTitle} (${it.variantLabel})" }.take(500)
                val sellerName = items.first().sellerName
                val paymentRef = "${flwMode}-${txBatchId}-${sellerId.take(4).uppercase()}"

                orderRef.set(
                    mapOf(
                        "idempotencyKey" to idemKey,
                        "buyerId" to userId,
                        "sellerId" to sellerId,
                        "sellerName" to sellerName,
                        "itemsSummary" to summary,
                        "totalNaira" to totalNaira,
                        "deliveryState" to deliveryState,
                        "deliveryAddress" to deliveryAddress.trim().take(300),
                        "paymentMethod" to paymentMethod,
                        "paymentReference" to paymentRef,
                        "paymentStatus" to "paid",
                        "orderStatus" to "confirmed",
                        "sourceType" to sourceType,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()

                for (item in items) {
                    val prodRef = db.collection("products").document(item.productId)
                    val prodSnap = prodRef.get().await()
                    if (prodSnap.exists()) {
                        val currentStock = prodSnap.getLong("stockCount") ?: 0L
                        if (currentStock > 0L) {
                            val nextStock = (currentStock - item.quantity).coerceAtLeast(0L)
                            if (nextStock < currentStock) {
                                prodRef.update(
                                    mapOf(
                                        "stockCount" to nextStock,
                                        "updatedAt" to FieldValue.serverTimestamp()
                                    )
                                ).await()
                            }
                        }
                    }
                }
            }
            createdOrderIds.add(orderId)
        }

        // Clear cart items
        for (item in cartItems) {
            db.collection("users").document(userId).collection("cart").document(item.id).delete().await()
        }
        createdOrderIds
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "orders")
    }

    suspend fun payExistingOrderWithFlutterwave(
        orderId: String,
        paymentMethod: String
    ): Result<String> = runCatching {
        val flwRef = "FLW-AUC-${UUID.randomUUID().toString().take(10).uppercase()}"
        db.collection("orders").document(orderId)
            .update(
                mapOf(
                    "paymentMethod" to paymentMethod,
                    "paymentReference" to flwRef,
                    "paymentStatus" to "paid",
                    "orderStatus" to "confirmed",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        flwRef
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "orders/$orderId")
    }

    suspend fun createOrUpdateSellerStorefront(
        ownerId: String,
        businessName: String,
        tagline: String,
        stateLocation: String,
        themeId: String,
        policies: String
    ): Result<String> = runCatching {
        val sellerId = "seller_$ownerId"
        val sellerRef = db.collection("sellers").document(sellerId)
        val existing = sellerRef.get().await()
        if (existing.exists()) {
            sellerRef.update(
                mapOf(
                    "businessName" to businessName.trim().take(100),
                    "tagline" to tagline.trim().take(200),
                    "stateLocation" to stateLocation,
                    "themeId" to themeId,
                    "policies" to policies.trim().take(1000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            sellerRef.set(
                mapOf(
                    "ownerId" to ownerId,
                    "businessName" to businessName.trim().take(100),
                    "tagline" to tagline.trim().take(200),
                    "stateLocation" to stateLocation,
                    "themeId" to themeId,
                    "logoKey" to "seller_banner",
                    "bannerKey" to "seller_banner",
                    "verified" to false,
                    "rating" to 4.9,
                    "followersCount" to 1L,
                    "giftEarningsCoins" to 0L,
                    "policies" to policies.trim().take(1000),
                    "status" to "active",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        db.collection("users").document(ownerId)
            .update(
                mapOf(
                    "role" to "seller",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        sellerId
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "sellers/seller_$ownerId")
    }

    suspend fun createProductListing(
        sellerId: String,
        sellerName: String,
        title: String,
        description: String,
        category: String,
        brand: String,
        priceNaira: Long,
        originalPriceNaira: Long,
        stockCount: Long,
        variants: List<String>,
        isFlashDeal: Boolean,
        imageKey: String = "hero_marketplace"
    ): Result<String> = runCatching {
        val docRef = db.collection("products").document()
        val flashEnd = if (isFlashDeal) System.currentTimeMillis() + 6L * 3600_000L else 0L
        docRef.set(
            mapOf(
                "sellerId" to sellerId,
                "sellerName" to sellerName.ifBlank { "Verified Vendor" },
                "title" to title.trim().take(160),
                "description" to description.trim().take(2000),
                "category" to category,
                "subcategory" to "Featured",
                "brand" to brand.ifBlank { "CashNCarry" },
                "priceNaira" to priceNaira.coerceAtLeast(100L),
                "originalPriceNaira" to originalPriceNaira.coerceAtLeast(priceNaira),
                "stockCount" to stockCount.coerceAtLeast(1L),
                "rating" to 4.8,
                "reviewCount" to 1L,
                "imageKey" to imageKey,
                "variants" to variants.ifEmpty { listOf("Standard") },
                "deliveryStates" to listOf("Lagos", "Abuja (FCT)", "Rivers", "Oyo", "Kano", "Enugu"),
                "isFlashDeal" to isFlashDeal,
                "flashDealEndEpochMs" to flashEnd,
                "liveStreamId" to "",
                "status" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        docRef.id
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "products")
    }

    suspend fun updateProductStockAndPrice(
        productId: String,
        newPriceNaira: Long,
        newStock: Long,
        isFlashDeal: Boolean
    ): Result<Unit> = runCatching {
        val flashEnd = if (isFlashDeal) System.currentTimeMillis() + 4L * 3600_000L else 0L
        db.collection("products").document(productId)
            .update(
                mapOf(
                    "priceNaira" to newPriceNaira.coerceAtLeast(100L),
                    "stockCount" to newStock.coerceAtLeast(0L),
                    "isFlashDeal" to isFlashDeal,
                    "flashDealEndEpochMs" to flashEnd,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "products/$productId")
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String): Result<Unit> = runCatching {
        db.collection("orders").document(orderId)
            .update(
                mapOf(
                    "orderStatus" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "orders/$orderId")
    }

    suspend fun bootstrapInitialMarketplaceCatalog(currentUserId: String, currentUserName: String): Result<Unit> = runCatching {
        val existing = db.collection("products").whereEqualTo("status", "active").limit(1).get().await()
        if (!existing.isEmpty) return@runCatching

        val starterSellerName = "${currentUserName.ifBlank { "Lagos" }.take(60)} Flagship Hub"
        val sellerId = "seller_$currentUserId"
        val sellerRef = db.collection("sellers").document(sellerId)
        if (!sellerRef.get().await().exists()) {
            sellerRef.set(
                mapOf(
                    "ownerId" to currentUserId,
                    "businessName" to starterSellerName,
                    "tagline" to "Authentic Nigerian & Global Luxury Essentials",
                    "stateLocation" to "Lagos",
                    "themeId" to "emerald",
                    "logoKey" to "seller_banner",
                    "bannerKey" to "seller_banner",
                    "verified" to false,
                    "rating" to 4.9,
                    "followersCount" to 128L,
                    "giftEarningsCoins" to 0L,
                    "policies" to "Same-day Lagos dispatch. 48h nationwide delivery.",
                    "status" to "active",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

        val now = System.currentTimeMillis()
        val starterProducts = listOf(
            mapOf(
                "sellerId" to currentUserId,
                "sellerName" to "${currentUserName.ifBlank { "Lagos" }} Flagship Hub",
                "title" to "SonicPulse ANC Wireless Studio Headphones",
                "description" to "45dB adaptive noise cancellation, 60-hour battery life, USB-C fast charge, and studio spatial audio.",
                "category" to "Electronics",
                "subcategory" to "Audio",
                "brand" to "SonicPulse",
                "priceNaira" to 84500L,
                "originalPriceNaira" to 115000L,
                "stockCount" to 24L,
                "rating" to 4.9,
                "reviewCount" to 42L,
                "imageKey" to "hero_marketplace",
                "variants" to listOf("Obsidian Black", "Champagne Gold", "Emerald Edition"),
                "deliveryStates" to listOf("Lagos", "Abuja (FCT)", "Rivers", "Oyo", "Kano", "Enugu"),
                "isFlashDeal" to true,
                "flashDealEndEpochMs" to (now + 5L * 3600_000L),
                "liveStreamId" to "stream_starter_tech",
                "status" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            mapOf(
                "sellerId" to currentUserId,
                "sellerName" to "${currentUserName.ifBlank { "Lagos" }} Flagship Hub",
                "title" to "Eko Luxe Handcrafted Leather Tote Bag",
                "description" to "Full-grain Italian-finished leather tote tailored for everyday executive style and weekend travel.",
                "category" to "Fashion",
                "subcategory" to "Bags",
                "brand" to "EkoCraft",
                "priceNaira" to 62000L,
                "originalPriceNaira" to 78000L,
                "stockCount" to 15L,
                "rating" to 4.8,
                "reviewCount" to 29L,
                "imageKey" to "live_fashion",
                "variants" to listOf("Cognac Tan", "Midnight Black", "Forest Emerald"),
                "deliveryStates" to listOf("Lagos", "Abuja (FCT)", "Ogun", "Oyo", "Rivers"),
                "isFlashDeal" to true,
                "flashDealEndEpochMs" to (now + 3L * 3600_000L),
                "liveStreamId" to "stream_starter_fashion",
                "status" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            mapOf(
                "sellerId" to currentUserId,
                "sellerName" to "${currentUserName.ifBlank { "Lagos" }} Flagship Hub",
                "title" to "NovaPro 5G 256GB Flagship Smartphone",
                "description" to "120Hz AMOLED display, 50MP OIS triple camera, 5000mAh battery with 67W turbo adapter.",
                "category" to "Phones & Tablets",
                "subcategory" to "Smartphones",
                "brand" to "NovaMobile",
                "priceNaira" to 485000L,
                "originalPriceNaira" to 540000L,
                "stockCount" to 9L,
                "rating" to 4.9,
                "reviewCount" to 67L,
                "imageKey" to "live_tech",
                "variants" to listOf("256GB Titanium", "512GB Emerald"),
                "deliveryStates" to listOf("Lagos", "Abuja (FCT)", "Rivers", "Kano", "Enugu", "Delta"),
                "isFlashDeal" to false,
                "flashDealEndEpochMs" to 0L,
                "liveStreamId" to "stream_starter_tech",
                "status" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            mapOf(
                "sellerId" to currentUserId,
                "sellerName" to "${currentUserName.ifBlank { "Lagos" }} Flagship Hub",
                "title" to "VeloRun Carbon Knit Street Sneakers",
                "description" to "Breathable knit upper with dual-density rebound sole built for all-day urban comfort.",
                "category" to "Sneakers",
                "subcategory" to "Lifestyle",
                "brand" to "VeloRun",
                "priceNaira" to 54000L,
                "originalPriceNaira" to 68000L,
                "stockCount" to 31L,
                "rating" to 4.7,
                "reviewCount" to 53L,
                "imageKey" to "live_fashion",
                "variants" to listOf("EU 41", "EU 42", "EU 43", "EU 44"),
                "deliveryStates" to listOf("Lagos", "Abuja (FCT)", "Oyo", "Rivers", "Anambra"),
                "isFlashDeal" to false,
                "flashDealEndEpochMs" to 0L,
                "liveStreamId" to "stream_starter_fashion",
                "status" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            mapOf(
                "sellerId" to currentUserId,
                "sellerName" to "${currentUserName.ifBlank { "Lagos" }} Flagship Hub",
                "title" to "Radiance Botanical Glow Skincare Set",
                "description" to "Vitamin C brightening serum, niacinamide essence, and SPF50 invisible daily moisturizer.",
                "category" to "Beauty",
                "subcategory" to "Skincare",
                "brand" to "ZuriGlow",
                "priceNaira" to 28500L,
                "originalPriceNaira" to 35000L,
                "stockCount" to 40L,
                "rating" to 4.9,
                "reviewCount" to 88L,
                "imageKey" to "seller_banner",
                "variants" to listOf("Complete 3-Piece Set", "Travel Duo"),
                "deliveryStates" to listOf("Lagos", "Abuja (FCT)", "Rivers", "Ogun", "Enugu", "Kaduna"),
                "isFlashDeal" to true,
                "flashDealEndEpochMs" to (now + 7L * 3600_000L),
                "liveStreamId" to "",
                "status" to "active",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )

        val createdProductIds = mutableListOf<String>()
        for (prod in starterProducts) {
            val doc = db.collection("products").document()
            doc.set(prod).await()
            createdProductIds.add(doc.id)
        }

        // Starter livestreams
        val fashionStreamRef = db.collection("livestreams").document("stream_starter_fashion")
        if (!fashionStreamRef.get().await().exists()) {
            fashionStreamRef.set(
                mapOf(
                    "sellerId" to currentUserId,
                    "sellerName" to starterSellerName,
                    "title" to "Lagos Runway Drop: Leather Totes & Sneakers Flash Show",
                    "category" to "Fashion",
                    "coverKey" to "live_fashion",
                    "status" to "live",
                    "viewerCount" to 342L,
                    "likesCount" to 1840L,
                    "pinnedProductId" to createdProductIds[1],
                    "pinnedProductTitle" to "Eko Luxe Handcrafted Leather Tote Bag",
                    "pinnedProductPriceNaira" to 62000L,
                    "flashDealProductId" to createdProductIds[1],
                    "flashDealDiscountPercent" to 20L,
                    "flashDealEndEpochMs" to (now + 2L * 3600_000L),
                    "scheduledAtEpochMs" to now,
                    "qualityPreset" to "1080p HD",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

        val techStreamRef = db.collection("livestreams").document("stream_starter_tech")
        if (!techStreamRef.get().await().exists()) {
            techStreamRef.set(
                mapOf(
                    "sellerId" to currentUserId,
                    "sellerName" to starterSellerName,
                    "title" to "Tech Unboxing Live: Flagship Phones & Studio ANC Audio",
                    "category" to "Electronics",
                    "coverKey" to "live_tech",
                    "status" to "live",
                    "viewerCount" to 518L,
                    "likesCount" to 2910L,
                    "pinnedProductId" to createdProductIds[0],
                    "pinnedProductTitle" to "SonicPulse ANC Wireless Studio Headphones",
                    "pinnedProductPriceNaira" to 84500L,
                    "flashDealProductId" to createdProductIds[0],
                    "flashDealDiscountPercent" to 25L,
                    "flashDealEndEpochMs" to (now + 90L * 60_000L),
                    "scheduledAtEpochMs" to now,
                    "qualityPreset" to "1080p HD",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

        // Starter live auction
        val starterAuctionRef = db.collection("auctions").document("auction_starter_1")
        if (!starterAuctionRef.get().await().exists()) {
            starterAuctionRef.set(
                mapOf(
                    "sellerId" to currentUserId,
                    "sellerName" to starterSellerName,
                    "productId" to createdProductIds[0],
                    "productTitle" to "SonicPulse ANC Studio Headphones (Limited Gold)",
                    "productImageKey" to "hero_marketplace",
                    "startingBidNaira" to 45000L,
                    "currentBidNaira" to 52000L,
                    "minIncrementNaira" to 2500L,
                    "highestBidderId" to currentUserId,
                    "highestBidderName" to "Opening Reserve",
                    "bidCount" to 0L,
                    "endsAtEpochMs" to (now + 25L * 60_000L),
                    "status" to "live",
                    "visibility" to "public",
                    "winningOrderId" to "",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

        // Starter short-form shoppable videos
        val starterVideo1Ref = db.collection("short_videos").document("video_starter_1")
        if (!starterVideo1Ref.get().await().exists()) {
            starterVideo1Ref.set(
                mapOf(
                    "sellerId" to currentUserId,
                    "sellerName" to starterSellerName,
                    "title" to "3 Reasons the Eko Luxe Tote Sells Out Every Friday",
                    "caption" to "Full-grain finish, fits a 14-inch laptop, and ships nationwide in 24h.",
                    "productId" to createdProductIds[1],
                    "productTitle" to "Eko Luxe Handcrafted Leather Tote Bag",
                    "productPriceNaira" to 62000L,
                    "coverKey" to "live_fashion",
                    "category" to "Fashion",
                    "likesCount" to 890L,
                    "commentsCount" to 14L,
                    "sharesCount" to 42L,
                    "status" to "published",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

        val starterVideo2Ref = db.collection("short_videos").document("video_starter_2")
        if (!starterVideo2Ref.get().await().exists()) {
            starterVideo2Ref.set(
                mapOf(
                    "sellerId" to currentUserId,
                    "sellerName" to starterSellerName,
                    "title" to "Real-World ANC Mic Test in Bustling Ikeja Traffic",
                    "caption" to "Hear crystal clear voice isolation on the SonicPulse Studio Headphones.",
                    "productId" to createdProductIds[0],
                    "productTitle" to "SonicPulse ANC Wireless Studio Headphones",
                    "productPriceNaira" to 84500L,
                    "coverKey" to "live_tech",
                    "category" to "Electronics",
                    "likesCount" to 1240L,
                    "commentsCount" to 28L,
                    "sharesCount" to 96L,
                    "status" to "published",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "bootstrap")
    }

    private fun logFlowError(error: Throwable, op: OperationType, path: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        handleFirestoreError(firestoreError ?: error, op, path)
    }
}
