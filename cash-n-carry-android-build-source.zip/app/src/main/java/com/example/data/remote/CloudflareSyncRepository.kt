package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class CloudflareSyncRepository(
    private val storage: SessionStorage,
    private val baseUrl: String = CloudflareEndpoints.STAGING_BASE_URL,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val normalizedBase = baseUrl.trimEnd('/')

    fun currentSessionSnapshot(): CloudflareSessionSnapshot {
        val token = storage.getToken()
        return CloudflareSessionSnapshot(
            signedIn = !token.isNullOrBlank(),
            userId = storage.getUserId(),
            email = storage.getEmail(),
            role = storage.getRole(),
            displayName = storage.getDisplayName(),
            selectedState = storage.getSelectedState()
        )
    }

    fun currentStagingFlags(): StagingFeatureFlags = storage.getStagingFlags()

    suspend fun fetchHealth(): CloudflareHealthSnapshot = withContext(Dispatchers.IO) {
        try {
            val req = newRequestBuilder("/api/health").get().build()
            client.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful || raw.isBlank()) {
                    return@withContext CloudflareHealthSnapshot(
                        ok = false,
                        error = "Health check HTTP ${res.code}"
                    )
                }
                val obj = JSONObject(raw)
                val stagingObj = obj.optJSONObject("staging") ?: JSONObject()
                val flags = StagingFeatureFlags(
                    paymentsEnabled = stagingObj.optBoolean("paymentsEnabled", false),
                    coinsPurchasesEnabled = stagingObj.optBoolean("coinsPurchasesEnabled", false),
                    kycUploadsEnabled = stagingObj.optBoolean("kycUploadsEnabled", false),
                    orderReservationsEnabled = stagingObj.optBoolean("orderReservationsEnabled", true),
                    streamConfigured = stagingObj.optBoolean("streamConfigured", false),
                    r2Configured = stagingObj.optBoolean("r2Configured", false)
                )
                storage.saveStagingFlags(flags)
                CloudflareHealthSnapshot(
                    ok = obj.optBoolean("ok", false),
                    service = obj.optString("service", "cashncarry-d1-staging-worker"),
                    environment = obj.optString("environment", "staging"),
                    dbConnected = obj.optBoolean("dbConnected", false),
                    authDbConnected = obj.optBoolean("authDbConnected", false),
                    authenticated = obj.optBoolean("authenticated", false),
                    staging = flags
                )
            }
        } catch (t: Throwable) {
            CloudflareHealthSnapshot(
                ok = false,
                staging = storage.getStagingFlags(),
                error = t.message ?: "Unable to reach staging worker"
            )
        }
    }

    suspend fun signInWithPassword(
        email: String,
        password: String
    ): CloudflareResult<CloudflareSessionSnapshot> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("email", email.trim())
            .put("password", password)
            .toString()

        when (val res = executeJson("POST", "/api/auth/login", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val obj = res.data
                val signedIn = obj.optBoolean("signedIn", false)
                val token = obj.optString("token", "")
                val userObj = obj.optJSONObject("user") ?: JSONObject()
                val userId = userObj.optString("id", "")
                val userEmail = userObj.optString("email", email.trim())
                val role = userObj.optString("role", "buyer")

                if (!signedIn || token.length != 64 || role == "admin") {
                    return@withContext CloudflareResult.Failure(
                        statusCode = 403,
                        code = "MOBILE_AUTH_REJECTED",
                        message = "Mobile sign-in requires a valid buyer or seller account"
                    )
                }

                storage.saveSession(token, userId, userEmail, role)
                fetchProfile()
                CloudflareResult.Success(currentSessionSnapshot())
            }
        }
    }

    suspend fun signOut(): Unit = withContext(Dispatchers.IO) {
        runCatching {
            executeJson("POST", "/api/auth/logout", "{}")
        }
        storage.clearSession()
    }

    suspend fun fetchProfile(): CloudflareResult<CloudflareSessionSnapshot> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/v1/profile", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val profile = res.data.optJSONObject("profile") ?: res.data
                val displayName = profile.optString("display_name", "")
                val state = profile.optString("selected_state", "Lagos").ifBlank { "Lagos" }
                storage.saveProfileMetadata(displayName, state)
                CloudflareResult.Success(currentSessionSnapshot())
            }
        }
    }

    suspend fun updateProfile(
        displayName: String,
        bio: String,
        avatarUrl: String,
        selectedState: String
    ): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("displayName", displayName.trim())
            .put("bio", bio.trim())
            .put("avatarUrl", avatarUrl.trim())
            .put("selectedState", selectedState.trim())
            .toString()

        when (val res = executeJson("PUT", "/api/v1/profile", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                storage.saveProfileMetadata(displayName.trim(), selectedState.trim())
                CloudflareResult.Success(res.data.optBoolean("updated", true))
            }
        }
    }

    suspend fun updateCart(
        productId: String,
        quantity: Int,
        source: String = "replacement"
    ): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("id", productId)
            .put("quantity", quantity)
            .put("source", source)
            .toString()

        when (val res = executeJson("POST", "/api/cart", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(true)
        }
    }

    suspend fun checkoutCart(
        requestId: String,
        addressId: String
    ): CloudflareResult<String> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("request_id", requestId)
            .put("address_id", addressId)
            .toString()

        when (val res = executeJson("POST", "/api/checkout", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val orderId = res.data.optJSONObject("order")?.optString("id")
                    ?: res.data.optString("orderId", "")
                CloudflareResult.Success(orderId)
            }
        }
    }

    suspend fun initializePayment(orderId: String): CloudflareResult<String> = withContext(Dispatchers.IO) {
        if (!storage.getStagingFlags().paymentsEnabled) {
            return@withContext CloudflareResult.Failure(
                statusCode = 503,
                code = "PAYMENTS_DISABLED",
                message = "Payments temporarily unavailable in staging (PAYMENTS_ENABLED=false)"
            )
        }
        val payload = JSONObject().put("order_id", orderId).toString()
        when (val res = executeJson("POST", "/api/payments/initialize", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val checkoutUrl = res.data.optString("checkout_url", "")
                if (checkoutUrl.isBlank()) {
                    CloudflareResult.Failure(503, "PAYMENTS_DISABLED", "Payments temporarily unavailable")
                } else {
                    CloudflareResult.Success(checkoutUrl)
                }
            }
        }
    }

    suspend fun toggleWishlist(productId: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("productId", productId).toString()
        when (val res = executeJson("POST", "/api/v1/wishlist", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(res.data.optBoolean("wishlisted", true))
        }
    }

    suspend fun toggleFollowSeller(sellerId: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("sellerId", sellerId).toString()
        when (val res = executeJson("POST", "/api/v1/follows", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(res.data.optBoolean("following", true))
        }
    }

    private fun newRequestBuilder(path: String): Request.Builder {
        val builder = Request.Builder()
            .url("$normalizedBase$path")
            .header(CloudflareEndpoints.CLIENT_TYPE_HEADER, CloudflareEndpoints.CLIENT_TYPE_MOBILE)
        storage.getToken()?.let { token ->
            builder.header("Authorization", "Bearer $token")
        }
        return builder
    }

    private fun executeJson(
        method: String,
        path: String,
        jsonBody: String?
    ): CloudflareResult<JSONObject> {
        return try {
            val builder = newRequestBuilder(path)
            when (method) {
                "GET" -> builder.get()
                "POST" -> builder.post((jsonBody ?: "{}").toRequestBody(jsonMediaType))
                "PUT" -> builder.put((jsonBody ?: "{}").toRequestBody(jsonMediaType))
                "PATCH" -> builder.patch((jsonBody ?: "{}").toRequestBody(jsonMediaType))
                "DELETE" -> builder.delete((jsonBody ?: "{}").toRequestBody(jsonMediaType))
                else -> builder.method(method, jsonBody?.toRequestBody(jsonMediaType))
            }
            client.newCall(builder.build()).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = runCatching {
                    if (raw.isNotBlank()) JSONObject(raw) else JSONObject()
                }.getOrDefault(JSONObject())

                if (!res.isSuccessful) {
                    return CloudflareResult.Failure(
                        statusCode = res.code,
                        code = obj.optString("code", "HTTP_${res.code}"),
                        message = obj.optString("error", "Request failed (${res.code})")
                    )
                }
                CloudflareResult.Success(obj)
            }
        } catch (t: Throwable) {
            CloudflareResult.Failure(
                statusCode = 0,
                code = "NETWORK_ERROR",
                message = t.message ?: "Network error communicating with Cloudflare Worker"
            )
        }
    }
}
