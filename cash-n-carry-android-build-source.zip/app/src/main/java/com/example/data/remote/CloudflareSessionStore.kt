package com.example.data.remote

import android.content.Context
import android.content.SharedPreferences

interface SessionStorage {
    fun getToken(): String?
    fun getUserId(): String
    fun getEmail(): String
    fun getRole(): String
    fun getDisplayName(): String
    fun getSelectedState(): String
    fun getStagingFlags(): StagingFeatureFlags
    fun saveSession(token: String, userId: String, email: String, role: String)
    fun saveProfileMetadata(displayName: String, selectedState: String)
    fun saveStagingFlags(flags: StagingFeatureFlags)
    fun clearSession()
}

class SharedPreferencesSessionStorage(context: Context) : SessionStorage {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    override fun getToken(): String? = prefs.getString(KEY_TOKEN, null)?.takeIf { it.isNotBlank() }

    override fun getUserId(): String = prefs.getString(KEY_USER_ID, "").orEmpty()

    override fun getEmail(): String = prefs.getString(KEY_EMAIL, "").orEmpty()

    override fun getRole(): String = prefs.getString(KEY_ROLE, "buyer").orEmpty()

    override fun getDisplayName(): String = prefs.getString(KEY_DISPLAY_NAME, "").orEmpty()

    override fun getSelectedState(): String = prefs.getString(KEY_STATE, "Lagos").orEmpty()

    override fun getStagingFlags(): StagingFeatureFlags {
        return StagingFeatureFlags(
            paymentsEnabled = prefs.getBoolean(KEY_PAYMENTS, false),
            coinsPurchasesEnabled = prefs.getBoolean(KEY_COINS, false),
            kycUploadsEnabled = prefs.getBoolean(KEY_KYC, false),
            orderReservationsEnabled = prefs.getBoolean(KEY_RESERVATIONS, true),
            streamConfigured = prefs.getBoolean(KEY_STREAM, false),
            r2Configured = prefs.getBoolean(KEY_R2, false)
        )
    }

    override fun saveSession(token: String, userId: String, email: String, role: String) {
        // Admin accounts are strictly prohibited from persisting mobile Bearer tokens
        if (role == "admin") return
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USER_ID, userId)
            .putString(KEY_EMAIL, email)
            .putString(KEY_ROLE, role)
            .apply()
    }

    override fun saveProfileMetadata(displayName: String, selectedState: String) {
        prefs.edit()
            .putString(KEY_DISPLAY_NAME, displayName)
            .putString(KEY_STATE, selectedState)
            .apply()
    }

    override fun saveStagingFlags(flags: StagingFeatureFlags) {
        prefs.edit()
            .putBoolean(KEY_PAYMENTS, flags.paymentsEnabled)
            .putBoolean(KEY_COINS, flags.coinsPurchasesEnabled)
            .putBoolean(KEY_KYC, flags.kycUploadsEnabled)
            .putBoolean(KEY_RESERVATIONS, flags.orderReservationsEnabled)
            .putBoolean(KEY_STREAM, flags.streamConfigured)
            .putBoolean(KEY_R2, flags.r2Configured)
            .apply()
    }

    override fun clearSession() {
        prefs.edit()
            .remove(KEY_TOKEN)
            .remove(KEY_USER_ID)
            .remove(KEY_EMAIL)
            .remove(KEY_ROLE)
            .remove(KEY_DISPLAY_NAME)
            .apply()
    }

    private companion object {
        const val PREFS_NAME = "cnc_cloudflare_sync_prefs"
        const val KEY_TOKEN = "bearer_token"
        const val KEY_USER_ID = "user_id"
        const val KEY_EMAIL = "email"
        const val KEY_ROLE = "role"
        const val KEY_DISPLAY_NAME = "display_name"
        const val KEY_STATE = "selected_state"
        const val KEY_PAYMENTS = "flag_payments_enabled"
        const val KEY_COINS = "flag_coins_enabled"
        const val KEY_KYC = "flag_kyc_enabled"
        const val KEY_RESERVATIONS = "flag_order_reservations"
        const val KEY_STREAM = "flag_stream_configured"
        const val KEY_R2 = "flag_r2_configured"
    }
}

class InMemorySessionStorage : SessionStorage {
    private var token: String? = null
    private var userId: String = ""
    private var email: String = ""
    private var role: String = "buyer"
    private var displayName: String = ""
    private var selectedState: String = "Lagos"
    private var flags: StagingFeatureFlags = StagingFeatureFlags()

    override fun getToken(): String? = token
    override fun getUserId(): String = userId
    override fun getEmail(): String = email
    override fun getRole(): String = role
    override fun getDisplayName(): String = displayName
    override fun getSelectedState(): String = selectedState
    override fun getStagingFlags(): StagingFeatureFlags = flags

    override fun saveSession(token: String, userId: String, email: String, role: String) {
        if (role == "admin") return
        this.token = token
        this.userId = userId
        this.email = email
        this.role = role
    }

    override fun saveProfileMetadata(displayName: String, selectedState: String) {
        this.displayName = displayName
        this.selectedState = selectedState
    }

    override fun saveStagingFlags(flags: StagingFeatureFlags) {
        this.flags = flags
    }

    override fun clearSession() {
        token = null
        userId = ""
        email = ""
        role = "buyer"
        displayName = ""
    }
}
