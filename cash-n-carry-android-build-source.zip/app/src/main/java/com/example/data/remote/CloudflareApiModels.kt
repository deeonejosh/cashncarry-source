package com.example.data.remote

object CloudflareEndpoints {
    const val STAGING_BASE_URL = "https://cashncarry-d1-staging-worker.cashncarry-workforce-2026.workers.dev"
    const val CLIENT_TYPE_HEADER = "X-Client-Type"
    const val CLIENT_TYPE_MOBILE = "mobile"
}

data class StagingFeatureFlags(
    val paymentsEnabled: Boolean = false,
    val coinsPurchasesEnabled: Boolean = false,
    val kycUploadsEnabled: Boolean = false,
    val orderReservationsEnabled: Boolean = true,
    val streamConfigured: Boolean = false,
    val r2Configured: Boolean = false
)

data class CloudflareHealthSnapshot(
    val ok: Boolean = false,
    val service: String = "cashncarry-d1-staging-worker",
    val environment: String = "staging",
    val dbConnected: Boolean = false,
    val authDbConnected: Boolean = false,
    val authenticated: Boolean = false,
    val staging: StagingFeatureFlags = StagingFeatureFlags(),
    val error: String? = null
)

data class CloudflareSessionSnapshot(
    val signedIn: Boolean = false,
    val userId: String = "",
    val email: String = "",
    val role: String = "buyer",
    val displayName: String = "",
    val selectedState: String = "Lagos"
)

sealed interface CloudflareResult<out T> {
    data class Success<T>(val data: T) : CloudflareResult<T>
    data class Failure(
        val statusCode: Int,
        val code: String,
        val message: String
    ) : CloudflareResult<Nothing>
}
