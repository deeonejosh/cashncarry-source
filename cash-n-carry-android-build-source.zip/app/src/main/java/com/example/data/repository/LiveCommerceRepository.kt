package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.Auction
import com.example.data.model.AuctionBid
import com.example.data.model.GiftTransaction
import com.example.data.model.Livestream
import com.example.data.model.Product
import com.example.data.model.ShortVideo
import com.example.data.model.StreamMessage
import com.example.data.model.TopGifterEntry
import com.example.data.model.VideoComment
import com.example.data.model.VirtualGift
import com.example.data.model.WalletBalance
import com.example.data.model.WalletLedgerEntry
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class LiveCommerceRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    fun observeLivestreams(): Flow<List<Livestream>> =
        db.collection("livestreams")
            .whereIn("status", listOf("live", "scheduled"))
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    Livestream::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "livestreams")
                throw error
            }

    fun observeStreamMessages(streamId: String): Flow<List<StreamMessage>> =
        db.collection("livestreams").document(streamId).collection("messages")
            .whereEqualTo("visibility", "public")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    StreamMessage::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "livestreams/$streamId/messages")
                throw error
            }

    fun observeTopGifters(streamId: String): Flow<List<TopGifterEntry>> =
        db.collection("livestreams").document(streamId).collection("top_gifters")
            .whereEqualTo("visibility", "public")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    TopGifterEntry::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.totalCoins }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "livestreams/$streamId/top_gifters")
                throw error
            }

    fun observeAuctions(): Flow<List<Auction>> =
        db.collection("auctions")
            .whereEqualTo("visibility", "public")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    Auction::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedBy { it.endsAtEpochMs }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "auctions")
                throw error
            }

    fun observeAuction(auctionId: String): Flow<Auction?> =
        db.collection("auctions").document(auctionId)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(
                        Auction::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                } else {
                    null
                }
            }
            .catch { error ->
                logFlowError(error, OperationType.GET, "auctions/$auctionId")
                throw error
            }

    fun observeAuctionBids(auctionId: String): Flow<List<AuctionBid>> =
        db.collection("auctions").document(auctionId).collection("bids")
            .whereEqualTo("visibility", "public")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    AuctionBid::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.amountNaira }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "auctions/$auctionId/bids")
                throw error
            }

    fun observeWallet(userId: String): Flow<WalletBalance> =
        db.collection("users").document(userId).collection("wallet").document("balance")
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(
                        WalletBalance::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: WalletBalance(userId = userId)
                } else {
                    WalletBalance(userId = userId)
                }
            }
            .catch { error ->
                logFlowError(error, OperationType.GET, "users/$userId/wallet/balance")
                throw error
            }

    fun observeWalletLedger(userId: String): Flow<List<WalletLedgerEntry>> =
        db.collection("users").document(userId).collection("wallet_ledger")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    WalletLedgerEntry::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "users/$userId/wallet_ledger")
                throw error
            }

    fun observeVirtualGifts(): Flow<List<VirtualGift>> =
        db.collection("gifts")
            .whereEqualTo("enabled", true)
            .snapshots()
            .map { snapshot ->
                val list = snapshot.toObjects(
                    VirtualGift::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedBy { it.coinCost }
                list.ifEmpty { DEFAULT_GIFTS }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "gifts")
                throw error
            }

    fun observeShortVideos(): Flow<List<ShortVideo>> =
        db.collection("short_videos")
            .whereEqualTo("status", "published")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    ShortVideo::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.likesCount }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "short_videos")
                throw error
            }

    fun observeUserShortVideos(userId: String): Flow<List<ShortVideo>> =
        db.collection("short_videos")
            .whereEqualTo("sellerId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    ShortVideo::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "short_videos")
                throw error
            }

    fun observeVideoComments(videoId: String): Flow<List<VideoComment>> =
        db.collection("short_videos").document(videoId).collection("comments")
            .whereEqualTo("visibility", "public")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    VideoComment::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "short_videos/$videoId/comments")
                throw error
            }

    fun observeGiftTransactionsForSeller(sellerId: String): Flow<List<GiftTransaction>> =
        db.collection("gift_transactions")
            .whereEqualTo("sellerId", sellerId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    GiftTransaction::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                logFlowError(error, OperationType.LIST, "gift_transactions")
                throw error
            }

    suspend fun ensureWalletInitialized(userId: String): Result<Unit> = runCatching {
        val walletRef = db.collection("users").document(userId).collection("wallet").document("balance")
        if (!walletRef.get().await().exists()) {
            walletRef.set(
                mapOf(
                    "userId" to userId,
                    "purchasedCoins" to 0L,
                    "promoTestCoins" to 0L,
                    "totalSpentNaira" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "users/$userId/wallet/balance")
    }

    suspend fun claimPromoTestCoins(userId: String, amount: Long = 250L): Result<Unit> = runCatching {
        val idemKey = "promo_claim_${userId.take(16)}_${System.currentTimeMillis() / 60000L}"
        val ledgerRef = db.collection("users").document(userId).collection("wallet_ledger").document(idemKey)
        val walletRef = db.collection("users").document(userId).collection("wallet").document("balance")

        db.runTransaction { tx ->
            if (tx.get(ledgerRef).exists()) return@runTransaction null
            val walletSnap = tx.get(walletRef)
            val currentPromo = walletSnap.getLong("promoTestCoins") ?: 0L
            if (!walletSnap.exists()) {
                tx.set(
                    walletRef,
                    mapOf(
                        "userId" to userId,
                        "purchasedCoins" to 0L,
                        "promoTestCoins" to amount,
                        "totalSpentNaira" to 0L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                tx.update(
                    walletRef,
                    mapOf(
                        "promoTestCoins" to (currentPromo + amount),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            tx.set(
                ledgerRef,
                mapOf(
                    "userId" to userId,
                    "idempotencyKey" to idemKey,
                    "entryType" to "promo_grant",
                    "coinBucket" to "promo",
                    "coinDelta" to amount,
                    "amountNaira" to 0L,
                    "description" to "Promotional Test Coins (Non-redeemable for cash)",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            null
        }.await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "users/$userId/wallet")
    }

    suspend fun purchaseCoinsWithFlutterwave(
        userId: String,
        coins: Long,
        amountNaira: Long
    ): Result<String> = runCatching {
        val idemKey = "coin_${UUID.randomUUID().toString().take(12)}"
        val walletRef = db.collection("users").document(userId).collection("wallet").document("balance")
        val ledgerRef = db.collection("users").document(userId).collection("wallet_ledger").document(idemKey)

        db.runTransaction { tx ->
            if (tx.get(ledgerRef).exists()) return@runTransaction null
            val walletSnap = tx.get(walletRef)
            val currentPurchased = walletSnap.getLong("purchasedCoins") ?: 0L
            val currentSpent = walletSnap.getLong("totalSpentNaira") ?: 0L
            if (!walletSnap.exists()) {
                tx.set(
                    walletRef,
                    mapOf(
                        "userId" to userId,
                        "purchasedCoins" to coins,
                        "promoTestCoins" to 0L,
                        "totalSpentNaira" to amountNaira,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                tx.update(
                    walletRef,
                    mapOf(
                        "purchasedCoins" to (currentPurchased + coins),
                        "totalSpentNaira" to (currentSpent + amountNaira),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            tx.set(
                ledgerRef,
                mapOf(
                    "userId" to userId,
                    "idempotencyKey" to idemKey,
                    "entryType" to "coin_purchase",
                    "coinBucket" to "purchased",
                    "coinDelta" to coins,
                    "amountNaira" to amountNaira,
                    "description" to "Purchased $coins Cash Coins via Flutterwave",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            null
        }.await()
        idemKey
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "users/$userId/wallet")
    }

    suspend fun sendVirtualGift(
        streamId: String,
        sellerId: String,
        senderId: String,
        senderName: String,
        gift: VirtualGift,
        usePromoCoins: Boolean,
        comboCount: Long
    ): Result<Unit> = runCatching {
        val idemKey = "gift_${UUID.randomUUID().toString().take(14)}"
        val walletRef = db.collection("users").document(senderId).collection("wallet").document("balance")
        val ledgerRef = db.collection("users").document(senderId).collection("wallet_ledger").document(idemKey)
        val giftTxRef = db.collection("gift_transactions").document(idemKey)
        val topGifterRef = db.collection("livestreams").document(streamId).collection("top_gifters").document(senderId)

        db.runTransaction { tx ->
            if (tx.get(giftTxRef).exists()) return@runTransaction null
            val walletSnap = tx.get(walletRef)
            val purchased = walletSnap.getLong("purchasedCoins") ?: 0L
            val promo = walletSnap.getLong("promoTestCoins") ?: 0L
            val gifterSnap = tx.get(topGifterRef)

            if (usePromoCoins) {
                if (promo < gift.coinCost) throw IllegalStateException("Insufficient Promotional Test Coins")
                tx.update(
                    walletRef,
                    mapOf(
                        "promoTestCoins" to (promo - gift.coinCost),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                if (purchased < gift.coinCost) throw IllegalStateException("Insufficient Purchased Coins. Top up your wallet first.")
                tx.update(
                    walletRef,
                    mapOf(
                        "purchasedCoins" to (purchased - gift.coinCost),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            tx.set(
                ledgerRef,
                mapOf(
                    "userId" to senderId,
                    "idempotencyKey" to idemKey,
                    "entryType" to "gift_debit",
                    "coinBucket" to if (usePromoCoins) "promo" else "purchased",
                    "coinDelta" to -gift.coinCost,
                    "amountNaira" to 0L,
                    "description" to "Sent ${gift.name} (x$comboCount) in live stream",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )

            tx.set(
                giftTxRef,
                mapOf(
                    "idempotencyKey" to idemKey,
                    "streamId" to streamId,
                    "senderId" to senderId,
                    "senderName" to senderName.ifBlank { "Fan" },
                    "sellerId" to sellerId,
                    "giftId" to gift.id,
                    "giftName" to gift.name,
                    "coinCost" to gift.coinCost,
                    "coinSource" to if (usePromoCoins) "promo" else "purchased",
                    "comboCount" to comboCount.coerceIn(1L, 999L),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )

            if (gifterSnap.exists()) {
                val curCoins = gifterSnap.getLong("totalCoins") ?: 0L
                val curCount = gifterSnap.getLong("giftCount") ?: 0L
                tx.update(
                    topGifterRef,
                    mapOf(
                        "totalCoins" to (curCoins + gift.coinCost),
                        "giftCount" to (curCount + 1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                tx.set(
                    topGifterRef,
                    mapOf(
                        "streamId" to streamId,
                        "userId" to senderId,
                        "userName" to senderName.ifBlank { "Fan" },
                        "totalCoins" to gift.coinCost,
                        "giftCount" to 1L,
                        "visibility" to "public",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            null
        }.await()

        // Credit seller giftEarningsCoins only when real purchased coins were gifted
        if (!usePromoCoins) {
            val sellerDocId = "seller_$sellerId"
            val sellerRef = db.collection("sellers").document(sellerDocId)
            val sellerSnap = sellerRef.get().await()
            if (sellerSnap.exists()) {
                val currentEarnings = sellerSnap.getLong("giftEarningsCoins") ?: 0L
                sellerRef.update(
                    mapOf(
                        "giftEarningsCoins" to (currentEarnings + gift.coinCost),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        }

        // Post celebratory chat announcement
        sendStreamMessage(
            streamId = streamId,
            userId = senderId,
            userName = senderName,
            text = "Sent ${gift.name} (${gift.coinCost} coins) x$comboCount!",
            isSystem = true
        )
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "gift_transactions")
    }

    suspend fun sendStreamMessage(
        streamId: String,
        userId: String,
        userName: String,
        text: String,
        isSystem: Boolean = false
    ): Result<Unit> = runCatching {
        db.collection("livestreams").document(streamId).collection("messages").document()
            .set(
                mapOf(
                    "streamId" to streamId,
                    "userId" to userId,
                    "userName" to userName.ifBlank { "Viewer" }.take(80),
                    "text" to text.trim().take(300),
                    "isSystem" to isSystem,
                    "visibility" to "public",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "livestreams/$streamId/messages")
    }

    suspend fun deleteStreamMessage(streamId: String, messageId: String): Result<Unit> = runCatching {
        db.collection("livestreams").document(streamId).collection("messages").document(messageId)
            .delete().await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.DELETE, "livestreams/$streamId/messages/$messageId")
    }

    suspend fun likeLivestream(streamId: String): Result<Unit> = runCatching {
        val ref = db.collection("livestreams").document(streamId)
        val snap = ref.get().await()
        val current = snap.getLong("likesCount") ?: 0L
        ref.update(
            mapOf(
                "likesCount" to (current + 1L),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "livestreams/$streamId")
    }

    suspend fun startSellerLivestream(
        sellerId: String,
        sellerName: String,
        title: String,
        category: String,
        qualityPreset: String,
        pinnedProduct: Product?
    ): Result<String> = runCatching {
        val docRef = db.collection("livestreams").document()
        val payload = mutableMapOf<String, Any>(
            "sellerId" to sellerId,
            "sellerName" to sellerName.ifBlank { "Verified Seller" },
            "title" to title.trim().take(160),
            "category" to category,
            "coverKey" to if (category == "Electronics" || category == "Phones & Tablets") "live_tech" else "live_fashion",
            "status" to "live",
            "viewerCount" to 1L,
            "likesCount" to 0L,
            "qualityPreset" to qualityPreset,
            "scheduledAtEpochMs" to System.currentTimeMillis(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (pinnedProduct != null) {
            payload["pinnedProductId"] = pinnedProduct.id
            payload["pinnedProductTitle"] = pinnedProduct.title
            payload["pinnedProductPriceNaira"] = pinnedProduct.priceNaira
        }
        docRef.set(payload).await()
        docRef.id
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "livestreams")
    }

    suspend fun pinProductToLivestream(streamId: String, product: Product): Result<Unit> = runCatching {
        db.collection("livestreams").document(streamId)
            .update(
                mapOf(
                    "pinnedProductId" to product.id,
                    "pinnedProductTitle" to product.title,
                    "pinnedProductPriceNaira" to product.priceNaira,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "livestreams/$streamId")
    }

    suspend fun launchLiveFlashDeal(
        streamId: String,
        productId: String,
        discountPercent: Long
    ): Result<Unit> = runCatching {
        db.collection("livestreams").document(streamId)
            .update(
                mapOf(
                    "flashDealProductId" to productId,
                    "flashDealDiscountPercent" to discountPercent.coerceIn(5L, 80L),
                    "flashDealEndEpochMs" to (System.currentTimeMillis() + 15L * 60_000L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "livestreams/$streamId")
    }

    suspend fun endLivestream(streamId: String): Result<Unit> = runCatching {
        db.collection("livestreams").document(streamId)
            .update(
                mapOf(
                    "status" to "ended",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "livestreams/$streamId")
    }

    suspend fun createLiveAuction(
        sellerId: String,
        sellerName: String,
        product: Product,
        startingBidNaira: Long,
        minIncrementNaira: Long,
        durationMinutes: Long
    ): Result<String> = runCatching {
        val ref = db.collection("auctions").document()
        ref.set(
            mapOf(
                "sellerId" to sellerId,
                "sellerName" to sellerName.ifBlank { "Verified Seller" },
                "productId" to product.id,
                "productTitle" to product.title,
                "productImageKey" to product.imageKey,
                "startingBidNaira" to startingBidNaira.coerceAtLeast(100L),
                "currentBidNaira" to startingBidNaira.coerceAtLeast(100L),
                "minIncrementNaira" to minIncrementNaira.coerceAtLeast(100L),
                "bidCount" to 0L,
                "endsAtEpochMs" to (System.currentTimeMillis() + durationMinutes.coerceIn(1L, 120L) * 60_000L),
                "status" to "live",
                "visibility" to "public",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        ref.id
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "auctions")
    }

    suspend fun placeAuctionBid(
        auctionId: String,
        bidderId: String,
        bidderName: String,
        bidAmountNaira: Long
    ): Result<Unit> = runCatching {
        val auctionRef = db.collection("auctions").document(auctionId)
        val bidRef = auctionRef.collection("bids").document()

        db.runTransaction { tx ->
            val snap = tx.get(auctionRef)
            if (!snap.exists()) throw IllegalStateException("Auction not found")
            val status = snap.getString("status") ?: "ended"
            if (status != "live") throw IllegalStateException("Auction has ended")
            val currentBid = snap.getLong("currentBidNaira") ?: 0L
            val minInc = snap.getLong("minIncrementNaira") ?: 500L
            val bidCount = snap.getLong("bidCount") ?: 0L
            val endsAt = snap.getLong("endsAtEpochMs") ?: 0L
            val now = System.currentTimeMillis()

            if (bidAmountNaira < currentBid + minInc) {
                throw IllegalStateException("Minimum next bid is ₦${currentBid + minInc}")
            }

            // Anti-sniping auction extension: extend by 30s if < 30s left
            val nextEndsAt = if (endsAt - now in 1L..30_000L) now + 30_000L else endsAt

            tx.update(
                auctionRef,
                mapOf(
                    "currentBidNaira" to bidAmountNaira,
                    "highestBidderId" to bidderId,
                    "highestBidderName" to bidderName.ifBlank { "Bidder" }.take(80),
                    "bidCount" to (bidCount + 1L),
                    "endsAtEpochMs" to nextEndsAt,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            tx.set(
                bidRef,
                mapOf(
                    "auctionId" to auctionId,
                    "bidderId" to bidderId,
                    "bidderName" to bidderName.ifBlank { "Bidder" }.take(80),
                    "amountNaira" to bidAmountNaira,
                    "visibility" to "public",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            null
        }.await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "auctions/$auctionId")
    }

    suspend fun finalizeWonAuctionOrder(
        auction: Auction,
        buyerId: String,
        deliveryState: String,
        deliveryAddress: String
    ): Result<String> = runCatching {
        if (auction.winningOrderId.isNotBlank()) return@runCatching auction.winningOrderId
        val orderId = "ord_auc_${auction.id.take(24)}"
        val orderRef = db.collection("orders").document(orderId)
        val auctionRef = db.collection("auctions").document(auction.id)

        if (!orderRef.get().await().exists()) {
            orderRef.set(
                mapOf(
                    "idempotencyKey" to "auc_${auction.id}",
                    "buyerId" to buyerId,
                    "sellerId" to auction.sellerId,
                    "sellerName" to auction.sellerName,
                    "itemsSummary" to "1x ${auction.productTitle} (Auction Win)",
                    "totalNaira" to auction.currentBidNaira,
                    "deliveryState" to deliveryState,
                    "deliveryAddress" to deliveryAddress.ifBlank { "Saved Default Address, $deliveryState" },
                    "paymentMethod" to "flutterwave_card",
                    "paymentReference" to "PENDING-AUCTION-${auction.id.take(8).uppercase()}",
                    "paymentStatus" to "pending",
                    "orderStatus" to "pending_payment",
                    "sourceType" to "auction",
                    "auctionId" to auction.id,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

        auctionRef.update(
            mapOf(
                "status" to "ended",
                "winningOrderId" to orderId,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        orderId
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "auctions/${auction.id}")
    }

    suspend fun likeShortVideo(videoId: String): Result<Unit> = runCatching {
        val ref = db.collection("short_videos").document(videoId)
        val snap = ref.get().await()
        val cur = snap.getLong("likesCount") ?: 0L
        ref.update(
            mapOf(
                "likesCount" to (cur + 1L),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "short_videos/$videoId")
    }

    suspend fun commentOnShortVideo(
        videoId: String,
        userId: String,
        userName: String,
        text: String
    ): Result<Unit> = runCatching {
        val videoRef = db.collection("short_videos").document(videoId)
        videoRef.collection("comments").document().set(
            mapOf(
                "videoId" to videoId,
                "userId" to userId,
                "userName" to userName.ifBlank { "Shopper" },
                "text" to text.trim().take(300),
                "visibility" to "public",
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        val snap = videoRef.get().await()
        val cur = snap.getLong("commentsCount") ?: 0L
        videoRef.update(
            mapOf(
                "commentsCount" to (cur + 1L),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "short_videos/$videoId/comments")
    }

    suspend fun publishShortVideo(
        sellerId: String,
        sellerName: String,
        title: String,
        caption: String,
        product: Product
    ): Result<String> = runCatching {
        val ref = db.collection("short_videos").document()
        ref.set(
            mapOf(
                "sellerId" to sellerId,
                "sellerName" to sellerName,
                "title" to title.trim().take(160),
                "caption" to caption.trim().take(400),
                "productId" to product.id,
                "productTitle" to product.title,
                "productPriceNaira" to product.priceNaira,
                "coverKey" to product.imageKey,
                "category" to product.category,
                "likesCount" to 0L,
                "commentsCount" to 0L,
                "sharesCount" to 0L,
                "status" to "published",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        ref.id
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "short_videos")
    }

    private fun logFlowError(error: Throwable, op: OperationType, path: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        handleFirestoreError(firestoreError ?: error, op, path)
    }

    companion object {
        val DEFAULT_GIFTS = listOf(
            VirtualGift(id = "gift_rose", name = "Lagos Rose", category = "Starter", coinCost = 10L, animationType = "float", colorHex = "#E11D48"),
            VirtualGift(id = "gift_spark", name = "Naira Spark", category = "Popular", coinCost = 50L, animationType = "burst", colorHex = "#059669"),
            VirtualGift(id = "gift_crown", name = "Eko Crown", category = "Premium", coinCost = 200L, animationType = "crown", colorHex = "#F59E0B"),
            VirtualGift(id = "gift_rocket", name = "Carry Rocket", category = "VIP Fullscreen", coinCost = 500L, animationType = "fullscreen", colorHex = "#7C3AED")
        )
    }
}
