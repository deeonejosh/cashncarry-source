# Android AI chat staging integration

The uploaded archive is a Kotlin/Jetpack Compose Android app. Added an AI Shopping Assistant screen, reachable through the Create & Explore sheet on mobile and the AI Help rail item on wide screens.

Build with CHAT_API_BASE_URL set to your verified **staging** Cloudflare API origin (HTTPS, no trailing slash). No OpenAI key belongs in the Android app. The server must provide POST /api/chat returning {"reply":"..."}.

The separate GitHub Cloudflare Pages Function has not been deployed. It lacks authentication and rate limiting; do not expose it publicly until those controls are implemented. No build or device tests have been run in this environment.

The Android archive also contains nested ZIP files under public/assets/aistudio. They have been preserved unchanged.
