# Cash N Carry Android / Cloudflare Staging Repair — 15 November 2026

**Status: candidate source, not approved for production.** This source is based on the uploaded `Cash-N-Carry-Staging-Upload-Under-25MB.zip`, with explicit source changes for the Android UI and Cloudflare Worker. The existing GitHub Actions workflow applies previously validated Android session/origin patches during CI.

## Source repairs made

- Removed automatic demo/verified seller catalog population on app launch.
- Removed fake livestream, auction and video seed lists; a successful empty API response now means no livestream/video is available.
- Repaired product field mapping to `id, store, name, price, stock, image`, with prices in NGN and no invented ₦100 fallback. Renders HTTPS product images using existing Coil dependency.
- Repaired wishlist/follow list contract mapping and enriched wishlist items from loaded product data.
- Repaired cart source to `legacy` for public catalog product IDs; remote writes now precede local success display. Errors propagate instead of pretending to save.
- Added Cloudflare-backed seller store and product draft creation (UUID, kobo minor currency, server ACK). New listings are *drafts*, not falsely published. Stock/price changes without revision synchronisation fail closed.
- Enabled a seller to act as a buyer on cart/orders *in the staging Worker source*, preserving server-side authentication. This requires separate staging Worker deployment; the currently deployed Worker may still reject seller carts until deployed.
- Added public paginated, verified-only `/api/storefronts` list endpoint in Worker source, with strict field allowlist; staging Worker deployment pending.
- Replaced large authentication hero with compact accessible header and keyboard-aware scrolling (`imePadding`).
- Added branded responsive Resend HTML + plain-text email code template with escaped code, clear 15-minute expiration and security copy. Source-only until Worker deploy.
- Disabled fake promo wallet/grant, gifting and local auction bidding, and disabled the misleading "Start Live Broadcast" button, until live media and wallet providers are actually wired.
- Disabled Android cloud backup for session-key reliability.
- Added native product/storefront regression tests, Worker storefront list probe, and email template escaping/expiry assertions.

## Important blockers still open

1. **Real livestreaming:** need a streaming ingest/playback provider, published media URLs, media lifecycle, device-to-device stream test.
2. **Wallet/coins/auctions:** real idempotent transaction ledger, gift animation delivery, settlement and wallet reconciliation. Payments and purchases remain disabled.
3. **Stock/product updates:** server revision IDs and status transition UI; the native app now fails closed instead of showing fake success.
4. **Seller order fulfilment, addresses, media uploads:** deeper persistence and QA still needed.
5. **Cross-device QA:** install the new APK and verify buyer/seller/navigation, session persistence, images and cart against staging Worker & D1.
6. **Provider setup and release signing:** no Play Store ready AAB or production signing changes.

## Deployment safety

Never deploy this bundle to live cashncarryng.com. First run GitHub Actions for the **staging** branch, review Android/Worker tests, back up staging D1 and deploy only the isolated staging Worker after confirming compatibility. Never deploy Flutterwave production keys. If testing with an older staging APK, uninstall only the staging app before installing a differently signed debug APK.

## Continuation: truthful persistence and safety repairs

- Corrected double network submission on seller follow and product reviews, preventing a second toggle from undoing the first follow request and preventing duplicate reviews.
- Profile details and state edits now require a successful Cloudflare write before showing the change in the app.
- The local-only shipping/payment-ready action now fails with an explicit unsupported message rather than claiming an address/payment method was saved.
- Added a D1-backed `GET /api/cart` restore client, mapped server product names and prices, and a native cart restoration regression test. Cart updates continue to wait for server acknowledgement.
- Livestream comments, short-video likes/comments, and end-live now require successful remote API writes before local confirmation; pseudo-stream publication, fake viewer/like count increments, fake auction orders and metadata-only video publication fail closed.
- Added seven source-contract regression checks (16 total offline Python checks).

These are candidate **source edits only**. The updated archive does not include a built APK. GitHub Actions for the new Phase 1 package will perform Gradle and Worker integration tests *after* this package is uploaded to staging. Do not deploy to production or mutate production D1.
