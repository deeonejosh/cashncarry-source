# Upload and verify Cash N Carry Phase 1 staging repair

1. Open GitHub repository `deeonejosh/cashncarry-source`, branch `feature/openai-chat-staging`.
2. Upload the **ZIP itself** with the exact filename `Cash-N-Carry-Staging-Phase1-Repair.zip`, under 25 MB, and commit it to this staging branch. Do **not** upload it to main.
3. GitHub Actions workflow `.github/workflows/verify-phase1-staging-repair.yml` automatically picks up this exact ZIP path. It extracts the source, runs offline Python checks, TypeScript lint/build/Worker tests, native Android + Robolectric tests, and creates a staging-only signed APK artifact if all pass.
4. Until the new workflow is green, **the existing APK and staging Worker remain the test baseline**. The ZIP is not deployed automatically and does not change production.
5. For Worker rollout, first take a verified staging D1 backup, review migration history, and deploy only to the explicitly isolated staging Worker. An API-only Android Worker may require a separate, asset-free bundle. Do not update DNS or production Workers/D1.
6. Real livestream video, coin/gift transactions, auction ledger, and native saved shipping addresses require additional implementation; the app now fails closed instead of simulating those functions.
