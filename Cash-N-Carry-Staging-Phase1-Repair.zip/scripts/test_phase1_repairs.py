"""Conservative source-level checks; real Gradle/Worker suites run in GitHub CI."""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def source(path): return (ROOT/path).read_text(encoding='utf-8')

class PhaseOneContracts(unittest.TestCase):
    def test_no_demo_catalog_bootstrap(self):
        s=source('app/src/main/java/com/example/ui/viewmodel/MarketplaceViewModel.kt')
        self.assertNotIn('.bootstrapInitialMarketplaceCatalog(',s)
    def test_no_fake_initial_lives(self):
        s=source('app/src/main/java/com/example/data/repository/LiveCommerceRepository.kt')
        self.assertIn('MutableStateFlow<List<Livestream>>(emptyList())',s)
        self.assertIn('is CloudflareResult.Success -> _livestreams.value = streams.data',s)
        self.assertIn('Livestream likes need a server-backed',s)
        self.assertIn('Connect and verify a media-streaming provider',s)
    def test_correct_live_product_fields(self):
        s=source('app/src/main/java/com/example/data/remote/CloudflareSyncRepository.kt')
        self.assertIn('obj.optString("name", obj.optString("title", ""))',s)
        self.assertIn('obj.optLong("price", -1L)',s)
        self.assertNotIn('coerceAtLeast(100L)',s)
        self.assertIn('priceNaira = priceNaira',s)
        self.assertIn('imageKey = obj.optString("image",',s)
    def test_cart_roundtrip_is_server_first(self):
        s=source('app/src/main/java/com/example/data/repository/CatalogRepository.kt')
        c=s.index('when (val cartRes = remote.fetchCart())')
        w=s.index('when (val wishRes = remote.fetchWishlist())')
        self.assertLess(c,w)
        self.assertIn('remote.updateCart(product.id, savedQty, source = "legacy")',s)
        self.assertIn('is CloudflareResult.Failure -> throw IllegalStateException(result.message)',s)
        api=source('app/src/main/java/com/example/data/remote/CloudflareSyncRepository.kt')
        self.assertIn('suspend fun fetchCart()',api)
        self.assertIn('res.data.optJSONArray("items")',api)
        self.assertIn('CART_ITEM_UNAVAILABLE', api)
    def test_no_duplicate_writes_or_local_only_success(self):
        s=source('app/src/main/java/com/example/data/repository/CatalogRepository.kt')
        self.assertEqual(s.count('remote.toggleFollowSeller(rawOwnerId)'),1)
        self.assertEqual(s.count('remote.submitReview(productId, rating, comment)'),1)
        self.assertNotIn('syncRepo?.toggleFollowSeller(rawOwnerId)',s)
        self.assertNotIn('syncRepo?.submitReview(productId, rating, comment)',s)
        self.assertIn('Saving a delivery address is not available',s)
        live=source('app/src/main/java/com/example/data/repository/LiveCommerceRepository.kt')
        self.assertEqual(live.count('remote.sendLiveComment(streamId, text)'),1)
        self.assertNotIn('syncRepo?.sendLiveComment(streamId, text)',live)
    def test_email_template_and_compact_login(self):
        s=source('web/deploy/chatgpt-sites/auth-email.ts')
        self.assertIn('renderAuthEmail',s)
        self.assertIn('htmlEscape(token)',s)
        self.assertIn('15 minutes',s)
        self.assertIn('word-break:break-all', s)
        self.assertIn('text: rendered.text',s)
        a=source('app/src/main/java/com/example/ui/auth/AuthComponents.kt')
        self.assertIn('.imePadding()',a)
        self.assertIn('Welcome to Cash N Carry',a)
    def test_flags_and_worker_security(self):
        config=source('web/wrangler.jsonc')
        for variable in ('PAYMENTS_ENABLED','COINS_PURCHASES_ENABLED','KYC_UPLOADS_ENABLED'):
            self.assertIn(variable, config)
        m=source('web/deploy/chatgpt-sites/marketplace.ts')
        self.assertIn('hasValidMutationOrigin(request, env)', m)
        s=source('web/deploy/chatgpt-sites/catalog.ts')
        self.assertIn('verified = 1 AND suspended = 0', s)

if __name__ == '__main__': unittest.main()
