package com.example.data.repository

import com.example.data.model.Auction
import com.example.data.model.AuctionBid
import com.example.data.model.GiftTransaction
import com.example.data.model.Livestream
import com.example.data.model.Product
import com.example.data.model.ShortVideo
import com.example.data.model.StreamMessage
import com.example.data.model.TopGifterEntry
import com.example.data.model.VideoComment
import com.example.data.model.VirtualGift
import com.example.data.model.WalletBalance
import com.example.data.model.WalletLedgerEntry
import com.example.data.remote.CloudflareResult
import com.example.data.remote.CloudflareSyncRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import java.util.UUID

class LiveCommerceRepository(
    private val syncRepo: CloudflareSyncRepository? = null
) {
    private val now = System.currentTimeMillis()
    private val _livestreams = MutableStateFlow<List<Livestream>>(emptyList())
    private val _streamMessages = MutableStateFlow<Map<String, List<StreamMessage>>>(emptyMap())
    private val _topGifters = MutableStateFlow<Map<String, List<TopGifterEntry>>>(emptyMap())
    private val _auctions = MutableStateFlow<List<Auction>>(emptyList())
    private val _auctionBids = MutableStateFlow<Map<String, List<AuctionBid>>>(emptyMap())
    private val _wallets = MutableStateFlow<Map<String, WalletBalance>>(emptyMap())
    private val _walletLedgers = MutableStateFlow<Map<String, List<WalletLedgerEntry>>>(emptyMap())
    private val _virtualGifts = MutableStateFlow(DEFAULT_GIFTS)
    private val _shortVideos = MutableStateFlow<List<ShortVideo>>(emptyList())
    private val _videoComments = MutableStateFlow<Map<String, List<VideoComment>>>(emptyMap())
    private val _giftTransactions = MutableStateFlow<List<GiftTransaction>>(emptyList())

    fun observeLivestreams(): Flow<List<Livestream>> =
        _livestreams.map { list -> list.filter { it.status == "live" || it.status == "scheduled" } }

    fun observeStreamMessages(streamId: String): Flow<List<StreamMessage>> =
        _streamMessages.map { it[streamId].orEmpty() }

    fun observeTopGifters(streamId: String): Flow<List<TopGifterEntry>> =
        _topGifters.map { map -> map[streamId].orEmpty().sortedByDescending { it.totalCoins } }

    fun observeAuctions(): Flow<List<Auction>> =
        _auctions.map { list -> list.sortedBy { it.endsAtEpochMs } }

    fun observeAuction(auctionId: String): Flow<Auction?> =
        _auctions.map { list -> list.find { it.id == auctionId } }

    fun observeAuctionBids(auctionId: String): Flow<List<AuctionBid>> =
        _auctionBids.map { map -> map[auctionId].orEmpty().sortedByDescending { it.amountNaira } }

    fun observeWallet(userId: String): Flow<WalletBalance> =
        _wallets.map { it[userId] ?: WalletBalance(userId = userId) }

    fun observeWalletLedger(userId: String): Flow<List<WalletLedgerEntry>> =
        _walletLedgers.map { map -> map[userId].orEmpty().sortedByDescending { it.createdAtEpochMs } }

    fun observeVirtualGifts(): Flow<List<VirtualGift>> = _virtualGifts

    fun observeShortVideos(): Flow<List<ShortVideo>> =
        _shortVideos.map { list -> list.sortedByDescending { it.likesCount } }

    fun observeUserShortVideos(userId: String): Flow<List<ShortVideo>> =
        _shortVideos.map { list -> list.filter { it.sellerId == userId }.sortedByDescending { it.createdAtEpochMs } }

    fun observeVideoComments(videoId: String): Flow<List<VideoComment>> =
        _videoComments.map { map -> map[videoId].orEmpty().sortedByDescending { it.createdAtEpochMs } }

    fun observeGiftTransactionsForSeller(sellerId: String): Flow<List<GiftTransaction>> =
        _giftTransactions.map { list -> list.filter { it.sellerId == sellerId } }

    suspend fun ensureWalletInitialized(userId: String): Result<Unit> = runCatching {
        if (!_wallets.value.containsKey(userId)) {
            _wallets.value = _wallets.value + (userId to WalletBalance(id = userId, userId = userId))
        }
        val remote = syncRepo
        if (remote != null) {
            when (val streams = remote.fetchLivestreams()) {
                is CloudflareResult.Success -> _livestreams.value = streams.data
                is CloudflareResult.Failure -> Unit
            }
            when (val videos = remote.fetchVideos()) {
                is CloudflareResult.Success -> _shortVideos.value = videos.data
                is CloudflareResult.Failure -> Unit
            }
        }
        Unit
    }

    suspend fun claimPromoTestCoins(userId: String, amount: Long = 250L): Result<Unit> = runCatching {
        throw IllegalStateException("Test coin grants need a server-authorised promotional ledger; local wallet simulation is disabled.")
    }

    suspend fun purchaseCoinsWithFlutterwave(
        userId: String,
        coins: Long,
        amountNaira: Long
    ): Result<String> = runCatching {
        val coinsEnabled = syncRepo?.currentStagingFlags()?.coinsPurchasesEnabled ?: false
        if (!coinsEnabled) {
            throw IllegalStateException("Cash Coins purchases are disabled in staging (COINS_PURCHASES_ENABLED=false).")
        }
        throw IllegalStateException("Use verified Cloudflare web checkout for Cash Coins.")
    }

    suspend fun sendVirtualGift(
        streamId: String,
        sellerId: String,
        senderId: String,
        senderName: String,
        gift: VirtualGift,
        usePromoCoins: Boolean,
        comboCount: Long
    ): Result<Unit> = runCatching {
        throw IllegalStateException("Gifting is disabled until the server wallet ledger and live room are connected.")
    }

    suspend fun sendStreamMessage(
        streamId: String,
        userId: String,
        userName: String,
        text: String,
        isSystem: Boolean = false
    ): Result<Unit> = runCatching {
        val remote = syncRepo ?: throw IllegalStateException("Live comments require Cloudflare connectivity")
        if (isSystem) throw IllegalStateException("System messages are server-managed")
        when (val sent = remote.sendLiveComment(streamId, text)) {
            is CloudflareResult.Failure -> throw IllegalStateException(sent.message)
            is CloudflareResult.Success -> if (!sent.data) throw IllegalStateException("Comment not saved")
        }
        val msg = StreamMessage(
            id = "msg_${UUID.randomUUID().toString().take(8)}",
            streamId = streamId,
            userId = userId,
            userName = userName.ifBlank { "Viewer" }.take(80),
            text = text.trim().take(300),
            isSystem = isSystem,
            createdAtEpochMs = System.currentTimeMillis()
        )
        val cur = _streamMessages.value[streamId].orEmpty()
        _streamMessages.value = _streamMessages.value + (streamId to (cur + msg))
        Unit
    }

    suspend fun deleteStreamMessage(streamId: String, messageId: String): Result<Unit> = runCatching {
        val cur = _streamMessages.value[streamId].orEmpty()
        _streamMessages.value = _streamMessages.value + (streamId to cur.filterNot { it.id == messageId })
        Unit
    }

    suspend fun likeLivestream(streamId: String): Result<Unit> = runCatching {
        throw IllegalStateException("Livestream likes need a server-backed reaction endpoint before being counted.")
    }

    suspend fun startSellerLivestream(
        sellerId: String,
        sellerName: String,
        title: String,
        category: String,
        qualityPreset: String,
        pinnedProduct: Product?
    ): Result<String> = runCatching {
        // A D1 room record alone does not publish camera video. No real media
        // provider is connected, so do not advertise a false LIVE broadcast.
        throw IllegalStateException("Connect and verify a media-streaming provider before starting a live broadcast.")
        @Suppress("UNREACHABLE_CODE")
        val remoteRoomId = when (val res = syncRepo?.createLivestream(title, category, pinnedProduct?.id)) {
            is CloudflareResult.Success -> res.data.takeIf { it.isNotBlank() }
            else -> null
        }
        val id = remoteRoomId ?: "stream_${UUID.randomUUID().toString().take(10)}"
        val nowMs = System.currentTimeMillis()
        val stream = Livestream(
            id = id,
            sellerId = sellerId,
            sellerName = sellerName.ifBlank { "Verified Seller" },
            title = title.trim().take(160),
            category = category,
            coverKey = if (category == "Electronics" || category == "Phones & Tablets") "live_tech" else "live_fashion",
            status = "live",
            viewerCount = 1L,
            pinnedProductId = pinnedProduct?.id.orEmpty(),
            pinnedProductTitle = pinnedProduct?.title.orEmpty(),
            pinnedProductPriceNaira = pinnedProduct?.priceNaira ?: 0L,
            qualityPreset = qualityPreset,
            scheduledAtEpochMs = nowMs,
            createdAtEpochMs = nowMs,
            updatedAtEpochMs = nowMs
        )
        _livestreams.value = listOf(stream) + _livestreams.value
        id
    }

    suspend fun pinProductToLivestream(streamId: String, product: Product): Result<Unit> = runCatching {
        throw IllegalStateException("Product pins are not live until the server supports stream pin updates.")
        @Suppress("UNREACHABLE_CODE")
        _livestreams.value = _livestreams.value.map {
            if (it.id == streamId) {
                it.copy(
                    pinnedProductId = product.id,
                    pinnedProductTitle = product.title,
                    pinnedProductPriceNaira = product.priceNaira
                )
            } else it
        }
        Unit
    }

    suspend fun launchLiveFlashDeal(
        streamId: String,
        productId: String,
        discountPercent: Long
    ): Result<Unit> = runCatching {
        throw IllegalStateException("Live flash deals need a server-backed offer lifecycle.")
        @Suppress("UNREACHABLE_CODE")
        _livestreams.value = _livestreams.value.map {
            if (it.id == streamId) {
                it.copy(
                    flashDealProductId = productId,
                    flashDealDiscountPercent = discountPercent.coerceIn(5L, 80L),
                    flashDealEndEpochMs = System.currentTimeMillis() + 15L * 60_000L
                )
            } else it
        }
        Unit
    }

    suspend fun endLivestream(streamId: String): Result<Unit> = runCatching {
        val remote = syncRepo ?: throw IllegalStateException("Live actions require Cloudflare connectivity")
        when (val ended = remote.endLivestream(streamId)) {
            is CloudflareResult.Failure -> throw IllegalStateException(ended.message)
            is CloudflareResult.Success -> if (!ended.data) throw IllegalStateException("Stream end not confirmed")
        }
        _livestreams.value = _livestreams.value.map {
            if (it.id == streamId) it.copy(status = "ended") else it
        }
        Unit
    }

    suspend fun createLiveAuction(
        sellerId: String,
        sellerName: String,
        product: Product,
        startingBidNaira: Long,
        minIncrementNaira: Long,
        durationMinutes: Long
    ): Result<String> = runCatching {
        throw IllegalStateException("Auctions require a server-backed livestream and bid ledger; offline simulation is disabled.")
    }

    suspend fun placeAuctionBid(
        auctionId: String,
        bidderId: String,
        bidderName: String,
        bidAmountNaira: Long
    ): Result<Unit> = runCatching {
        throw IllegalStateException("Bids must be committed by the auction API; local bids are disabled.")
    }

    suspend fun finalizeWonAuctionOrder(
        auction: Auction,
        buyerId: String,
        deliveryState: String,
        deliveryAddress: String
    ): Result<String> = runCatching {
        val paymentsEnabled = syncRepo?.currentStagingFlags()?.paymentsEnabled ?: false
        if (!paymentsEnabled) {
            throw IllegalStateException("Auction checkout is disabled in staging (PAYMENTS_ENABLED=false).")
        }
        throw IllegalStateException("Auction settlements must be authorised by Cloudflare; simulated order IDs are disabled.")
    }

    suspend fun likeShortVideo(videoId: String): Result<Unit> = runCatching {
        val remote = syncRepo ?: throw IllegalStateException("Video likes require Cloudflare connectivity")
        when (val liked = remote.likeVideo(videoId)) {
            is CloudflareResult.Failure -> throw IllegalStateException(liked.message)
            is CloudflareResult.Success -> if (!liked.data) throw IllegalStateException("Like not confirmed")
        }
        _shortVideos.value = _shortVideos.value.map {
            if (it.id == videoId) it.copy(likesCount = it.likesCount + 1L) else it
        }
        Unit
    }

    suspend fun commentOnShortVideo(
        videoId: String,
        userId: String,
        userName: String,
        text: String
    ): Result<Unit> = runCatching {
        val remote = syncRepo ?: throw IllegalStateException("Video comments require Cloudflare connectivity")
        when (val saved = remote.commentVideo(videoId, text)) {
            is CloudflareResult.Failure -> throw IllegalStateException(saved.message)
            is CloudflareResult.Success -> if (!saved.data) throw IllegalStateException("Comment not confirmed")
        }
        val comment = VideoComment(
            id = "vcom_${UUID.randomUUID().toString().take(8)}",
            videoId = videoId,
            userId = userId,
            userName = userName.ifBlank { "Shopper" },
            text = text.trim().take(300),
            createdAtEpochMs = System.currentTimeMillis()
        )
        _videoComments.value = _videoComments.value + (
            videoId to (listOf(comment) + _videoComments.value[videoId].orEmpty())
        )
        _shortVideos.value = _shortVideos.value.map {
            if (it.id == videoId) it.copy(commentsCount = it.commentsCount + 1L) else it
        }
        Unit
    }

    suspend fun publishShortVideo(
        sellerId: String,
        sellerName: String,
        title: String,
        caption: String,
        product: Product
    ): Result<String> = runCatching {
        // Metadata alone is not a video upload. Do not display video published.
        throw IllegalStateException("Connect video upload and playback before publishing.")
        @Suppress("UNREACHABLE_CODE")
        val remoteId = when (val res = syncRepo?.publishShortVideo(product.id, title, caption)) {
            is CloudflareResult.Success -> res.data.takeIf { it.isNotBlank() }
            else -> null
        }
        val id = remoteId ?: "vid_${UUID.randomUUID().toString().take(10)}"
        val nowMs = System.currentTimeMillis()
        val video = ShortVideo(
            id = id,
            sellerId = sellerId,
            sellerName = sellerName,
            title = title.trim().take(160),
            caption = caption.trim().take(400),
            productId = product.id,
            productTitle = product.title,
            productPriceNaira = product.priceNaira,
            coverKey = product.imageKey,
            category = product.category,
            createdAtEpochMs = nowMs,
            updatedAtEpochMs = nowMs
        )
        _shortVideos.value = listOf(video) + _shortVideos.value
        id
    }

    companion object {
        val DEFAULT_GIFTS = listOf(
            VirtualGift(id = "gift_rose", name = "Lagos Rose", category = "Starter", coinCost = 10L, animationType = "float", colorHex = "#E11D48"),
            VirtualGift(id = "gift_spark", name = "Naira Spark", category = "Popular", coinCost = 50L, animationType = "burst", colorHex = "#059669"),
            VirtualGift(id = "gift_crown", name = "Eko Crown", category = "Premium", coinCost = 200L, animationType = "crown", colorHex = "#F59E0B"),
            VirtualGift(id = "gift_rocket", name = "Carry Rocket", category = "VIP Fullscreen", coinCost = 500L, animationType = "fullscreen", colorHex = "#7C3AED")
        )

        private fun defaultStreams(now: Long) = listOf(
            Livestream(
                id = "stream_starter_fashion",
                sellerId = "seller_lagos",
                sellerName = "Eko Runway Hub",
                title = "Lagos Runway Drop: Leather Totes & Sneakers Flash Show",
                category = "Fashion",
                coverKey = "live_fashion",
                status = "live",
                viewerCount = 342L,
                likesCount = 1840L,
                pinnedProductId = "prod_starter_tote",
                pinnedProductTitle = "Eko Luxe Handcrafted Leather Tote Bag",
                pinnedProductPriceNaira = 62000L,
                flashDealProductId = "prod_starter_tote",
                flashDealDiscountPercent = 20L,
                flashDealEndEpochMs = now + 2L * 3600_000L,
                scheduledAtEpochMs = now
            ),
            Livestream(
                id = "stream_starter_tech",
                sellerId = "seller_ikeja",
                sellerName = "Ikeja Tech Hub",
                title = "Tech Unboxing Live: Flagship Phones & Studio ANC Audio",
                category = "Electronics",
                coverKey = "live_tech",
                status = "live",
                viewerCount = 518L,
                likesCount = 2910L,
                pinnedProductId = "prod_starter_anc",
                pinnedProductTitle = "SonicPulse ANC Wireless Studio Headphones",
                pinnedProductPriceNaira = 84500L,
                flashDealProductId = "prod_starter_anc",
                flashDealDiscountPercent = 25L,
                flashDealEndEpochMs = now + 90L * 60_000L,
                scheduledAtEpochMs = now
            )
        )

        private fun defaultAuctions(now: Long) = listOf(
            Auction(
                id = "auction_starter_1",
                sellerId = "seller_ikeja",
                sellerName = "Ikeja Tech Hub",
                productId = "prod_starter_anc",
                productTitle = "SonicPulse ANC Studio Headphones (Limited Gold)",
                productImageKey = "hero_marketplace",
                startingBidNaira = 45000L,
                currentBidNaira = 52000L,
                minIncrementNaira = 2500L,
                highestBidderName = "Opening Reserve",
                endsAtEpochMs = now + 25L * 60_000L,
                status = "live"
            )
        )

        private fun defaultShortVideos(now: Long) = listOf(
            ShortVideo(
                id = "video_starter_1",
                sellerId = "seller_lagos",
                sellerName = "Eko Runway Hub",
                title = "3 Reasons the Eko Luxe Tote Sells Out Every Friday",
                caption = "Full-grain finish, fits a 14-inch laptop, and ships nationwide in 24h.",
                productId = "prod_starter_tote",
                productTitle = "Eko Luxe Handcrafted Leather Tote Bag",
                productPriceNaira = 62000L,
                coverKey = "live_fashion",
                category = "Fashion",
                likesCount = 890L,
                commentsCount = 14L,
                sharesCount = 42L,
                createdAtEpochMs = now
            ),
            ShortVideo(
                id = "video_starter_2",
                sellerId = "seller_ikeja",
                sellerName = "Ikeja Tech Hub",
                title = "Real-World ANC Mic Test in Bustling Ikeja Traffic",
                caption = "Hear crystal clear voice isolation on the SonicPulse Studio Headphones.",
                productId = "prod_starter_anc",
                productTitle = "SonicPulse ANC Wireless Studio Headphones",
                productPriceNaira = 84500L,
                coverKey = "live_tech",
                category = "Electronics",
                likesCount = 1240L,
                commentsCount = 28L,
                sharesCount = 96L,
                createdAtEpochMs = now
            )
        )
    }
}
