import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { Miniflare } from 'miniflare';
import { chromium } from 'playwright-core';

const CHROME_PATH =
  process.env.CNC_TEST_CHROMIUM ||
  '/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-linux64/chrome-headless-shell';

const DIST_DIR = path.resolve('dist');
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.xml': 'application/xml; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.json': 'application/json',
};

function serveDistAsset(request) {
  const url = new URL(request.url);
  let rel = url.pathname === '/' ? 'index.html' : url.pathname.replace(/^\/+/, '');
  let target = path.join(DIST_DIR, rel);
  if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
    // Match Wrangler assets.not_found_handling = "single-page-application"
    target = path.join(DIST_DIR, 'index.html');
    rel = 'index.html';
  }
  const ext = path.extname(rel).toLowerCase();
  return new Response(fs.readFileSync(target), {
    status: 200,
    headers: { 'content-type': MIME_TYPES[ext] || 'application/octet-stream' },
  });
}

async function execMigrationSql(db, sql) {
  const parts = sql.split(/(?=CREATE TRIGGER)/);
  const ddl = parts[0]
    .split('\n')
    .filter((line) => !line.trim().startsWith('--'))
    .join('\n')
    .trim();
  if (ddl) {
    await db.exec(ddl.replace(/\s+/g, ' ').replace(/;\s*/g, ';\n').trim());
  }
  for (const trigger of parts.slice(1)) {
    const cleanTrigger = trigger
      .split('\n')
      .filter((line) => !line.trim().startsWith('--'))
      .join('\n')
      .trim();
    if (cleanTrigger) {
      await db.prepare(cleanTrigger).run();
    }
  }
}

const browserPort = 18799;
const workerOrigin = `https://127.0.0.1:${browserPort}`;

const mf = new Miniflare({
  https: true,
  host: '127.0.0.1',
  port: browserPort,
  modules: true,
  scriptPath: 'dist/_worker.js',
  compatibilityDate: '2026-08-06',
  compatibilityFlags: ['nodejs_compat'],
  d1Databases: ['AUTH_DB', 'DB'],
  bindings: {
    AUTH_ORIGIN: workerOrigin,
    PAYMENTS_ENABLED: 'false',
    COINS_PURCHASES_ENABLED: 'false',
    KYC_UPLOADS_ENABLED: 'false',
    FLW_MODE: 'disabled',
    FLW_WEBHOOK_SIGNATURE: 'hmac-sha256',
    ORDER_RESERVATIONS: 'enabled',
  },
  serviceBindings: {
    ASSETS: serveDistAsset,
  },
});

const browser = await chromium.launch({
  executablePath: CHROME_PATH,
  headless: true,
  args: ['--no-sandbox'],
});

try {
  // Seed both D1 bindings identically to cashncarry-d1-staging
  const migrationsDir = path.resolve('deploy/chatgpt-sites/migrations');
  const files = fs.readdirSync(migrationsDir).filter((f) => f.endsWith('.sql')).sort();
  for (const binding of ['AUTH_DB', 'DB']) {
    const db = await mf.getD1Database(binding);
    for (const file of files) {
      await execMigrationSql(db, fs.readFileSync(path.join(migrationsDir, file), 'utf8'));
    }
  }

  const origin = (await mf.ready).origin.replace(/\/$/, '');

  // Check API health first
  const healthRes = await mf.dispatchFetch(origin + '/api/health');
  const healthData = await healthRes.json();
  assert.equal(healthData.ok, true);
  assert.equal(healthData.dbConnected, true);
  assert.equal(healthData.staging.paymentsEnabled, false);
  assert.equal(healthData.staging.coinsPurchasesEnabled, false);
  assert.equal(healthData.staging.kycUploadsEnabled, false);

  const tabsToVerify = [
    { tab: 'home', text: 'Cash N Carry' },
    { tab: 'shop', text: 'Shop Marketplace' },
    { tab: 'orders', text: 'Payments temporarily unavailable' },
    { tab: 'coins', text: 'Coin purchases & simulated credits temporarily unavailable' },
    { tab: 'auctions', text: 'Payments temporarily unavailable' },
    { tab: 'live', text: 'Staging UI Fixture Mode' },
    { tab: 'seller-kyc', text: 'KYC document uploads temporarily unavailable' },
    { tab: 'seller-settlements', text: 'Payments temporarily unavailable' },
    { tab: 'admin-dashboard', text: 'Platform Administration & Compliance' },
  ];

  const viewports = [
    { name: 'desktop', width: 1440, height: 900 },
    { name: 'mobile', width: 390, height: 844 },
  ];

  for (const vp of viewports) {
    const context = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, ignoreHTTPSErrors: true });
    const page = await context.newPage();
    const consoleErrors = [];
    const pageErrors = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') consoleErrors.push(msg.text());
    });
    page.on('pageerror', (err) => pageErrors.push(err.message));

    for (const entry of tabsToVerify) {
      const targetUrl = entry.tab === 'home' ? origin + '/' : `${origin}/?tab=${entry.tab}`;
      await page.goto(targetUrl, { waitUntil: 'networkidle' });
      await page.waitForTimeout(150);

      const bodyText = await page.locator('body').innerText();
      assert.ok(
        bodyText.includes(entry.text),
        `[${vp.name}] Expected "${entry.text}" on tab=${entry.tab}`
      );

      const overflowCheck = await page.evaluate(() => ({
        scrollWidth: document.documentElement.scrollWidth,
        innerWidth: window.innerWidth,
      }));
      assert.ok(
        overflowCheck.scrollWidth <= overflowCheck.innerWidth + 1,
        `[${vp.name}] Horizontal overflow on tab=${entry.tab}: ${overflowCheck.scrollWidth} > ${overflowCheck.innerWidth}`
      );

      if (entry.tab === 'coins') {
        const coinBtn = page.getByRole('button', { name: 'Coin Purchases Disabled' });
        assert.equal(await coinBtn.isDisabled(), true, `[${vp.name}] Coin Purchases button must be disabled`);
      }
      if (entry.tab === 'seller-kyc') {
        const disabledBtn = page.getByRole('button', { name: 'KYC Uploads Disabled in Staging' });
        assert.equal(await disabledBtn.isDisabled(), true, `[${vp.name}] KYC submit button must be disabled`);
      }
      if (entry.tab === 'seller-settlements') {
        const disabledPayout = page.getByRole('button', { name: /Payouts Disabled/i });
        assert.equal(await disabledPayout.isDisabled(), true, `[${vp.name}] Payout button must be disabled`);
      }
      if (entry.tab === 'admin-dashboard') {
        await page.getByRole('button', { name: /Orders & Refunds/i }).click();
        assert.ok((await page.locator('body').innerText()).includes('Payments temporarily unavailable'));
        await page.getByRole('button', { name: /Coin Gifting Treasury/i }).click();
        const coinBtn = page.getByRole('button', { name: 'Coin Minting Disabled in Staging' });
        assert.equal(await coinBtn.isDisabled(), true, `[${vp.name}] Admin coin minting button must be disabled`);
      }
    }

    // Add item from Shop and test full Checkout disabled payments flow
    await page.goto(`${origin}/?tab=shop`, { waitUntil: 'networkidle' });
    await page.getByRole('button', { name: /Add/i }).first().click();
    await page.waitForTimeout(150);
    await page.getByRole('button', { name: /Proceed to Checkout/i }).click();
    await page.waitForTimeout(200);
    const checkoutText = await page.locator('body').innerText();
    assert.ok(checkoutText.includes('Payments temporarily unavailable'), `[${vp.name}] Checkout missing unavailable banner`);
    assert.ok(checkoutText.includes('PAYMENTS DISABLED'), `[${vp.name}] Checkout missing PAYMENTS DISABLED badge`);
    const prepareBtn = page.getByRole('button', { name: /Prepare Unpaid Test Order/i });
    assert.equal(await prepareBtn.isEnabled(), true, `[${vp.name}] Prepare Unpaid Test Order should be enabled`);

    assert.equal(pageErrors.length, 0, `[${vp.name}] Uncaught page errors: ${pageErrors.join('; ')}`);
    assert.equal(consoleErrors.length, 0, `[${vp.name}] Console errors: ${consoleErrors.join('; ')}`);
    console.log(`  ✅ [BROWSER PASS] ${vp.name} (${vp.width}x${vp.height}): 10 views + Cart/Checkout + Admin tabs verified, 0 console/page errors, 0 overflow`);
    await context.close();
  }
} finally {
  await browser.close();
  await mf.dispose();
}
