import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { products, categories, sellers } from '../src/lib/data';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

// Helper to escape XML special characters
function escapeXml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

const GOOGLE_CATEGORY_MAP: Record<string, string> = {
  tech: 'Electronics > Audio > Audio Components > Headphones &amp; Headsets',
  fashion: 'Apparel &amp; Accessories > Clothing > Traditional &amp; Cultural Clothing',
  beauty: 'Health &amp; Beauty > Personal Care > Cosmetics > Skin Care',
  food: 'Food, Beverages &amp; Tobacco > Food Items',
  home: 'Home &amp; Garden > Kitchen &amp; Dining > Kitchen Appliances',
  services: 'Business &amp; Industrial > Commercial Printing &amp; Logistics',
};

export function generateGoogleShoppingFeedXml(baseUrl: string = 'https://www.cashncarryng.com'): string {
  const cleanBase = baseUrl.replace(/\/+$/, '');

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">\n';
  xml += '  <channel>\n';
  xml += '    <title>Cash N Carry Nigeria - Google Shopping Product Feed</title>\n';
  xml += `    <link>${escapeXml(cleanBase)}</link>\n`;
  xml += '    <description>Authentic wholesale and retail products from verified Nigerian CAC merchants with escrow protection and nationwide dispatch.</description>\n';
  xml += '    <language>en-NG</language>\n';

  for (const prod of products) {
    const slug = prod.slug || prod.id;
    const link = `${cleanBase}/product/${encodeURIComponent(slug)}`;
    const priceFormatted = `${prod.price.toFixed(2)} NGN`;
    const googleCategory = GOOGLE_CATEGORY_MAP[prod.category] || 'General Merchandise';
    const seller = sellers.find((s) => s.id === (prod as any).sellerId) || sellers[0];

    xml += '    <item>\n';
    xml += `      <g:id>${escapeXml(prod.id)}</g:id>\n`;
    xml += `      <g:title>${escapeXml(prod.title)}</g:title>\n`;
    xml += `      <g:description>${escapeXml(prod.description)}</g:description>\n`;
    xml += `      <g:link>${escapeXml(link)}</g:link>\n`;
    xml += `      <g:image_link>${escapeXml(prod.image)}</g:image_link>\n`;
    xml += '      <g:condition>new</g:condition>\n';
    xml += '      <g:availability>in_stock</g:availability>\n';
    xml += `      <g:price>${escapeXml(priceFormatted)}</g:price>\n`;
    xml += `      <g:brand>${escapeXml(prod.brand || 'Cash N Carry')}</g:brand>\n`;
    xml += '      <g:identifier_exists>no</g:identifier_exists>\n';
    xml += `      <g:google_product_category>${googleCategory}</g:google_product_category>\n`;
    xml += `      <g:product_type>${escapeXml(prod.category)}</g:product_type>\n`;
    xml += `      <g:custom_label_0>${escapeXml(prod.category)}</g:custom_label_0>\n`;
    xml += `      <g:custom_label_1>${escapeXml(seller ? seller.name : 'Cash N Carry')}</g:custom_label_1>\n`;
    xml += '      <g:shipping>\n';
    xml += '        <g:country>NG</g:country>\n';
    xml += '        <g:service>Standard Nationwide Delivery</g:service>\n';
    xml += '        <g:price>1500.00 NGN</g:price>\n';
    xml += '      </g:shipping>\n';
    xml += '    </item>\n';
  }

  xml += '  </channel>\n';
  xml += '</rss>\n';
  return xml;
}

export function writeGoogleShoppingFeed(baseUrl?: string) {
  const resolvedBase =
    baseUrl ||
    process.env.APP_URL ||
    process.env.SITE_URL ||
    'https://www.cashncarryng.com';

  const xmlContent = generateGoogleShoppingFeedXml(resolvedBase);

  // Write to public/feed/
  const publicFeedDir = path.resolve(rootDir, 'public', 'feed');
  if (!fs.existsSync(publicFeedDir)) {
    fs.mkdirSync(publicFeedDir, { recursive: true });
  }

  const publicFeedPath = path.resolve(publicFeedDir, 'google-shopping.xml');
  fs.writeFileSync(publicFeedPath, xmlContent, 'utf-8');
  console.log(`[Google Shopping Feed] Written to public/feed/google-shopping.xml (${xmlContent.length} bytes)`);

  // Write to dist/feed/ if dist exists
  const distFeedDir = path.resolve(rootDir, 'dist', 'feed');
  if (fs.existsSync(path.resolve(rootDir, 'dist'))) {
    if (!fs.existsSync(distFeedDir)) {
      fs.mkdirSync(distFeedDir, { recursive: true });
    }
    const distFeedPath = path.resolve(distFeedDir, 'google-shopping.xml');
    fs.writeFileSync(distFeedPath, xmlContent, 'utf-8');
    console.log(`[Google Shopping Feed] Synced to dist/feed/google-shopping.xml`);
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const cliBaseArg = process.argv.find((arg) => arg.startsWith('--base-url='));
  const customBase = cliBaseArg ? cliBaseArg.split('=')[1] : undefined;
  writeGoogleShoppingFeed(customBase);
}
