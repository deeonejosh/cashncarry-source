import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { categories, products, sellers } from '../src/lib/data';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

// Helper to escape XML special characters
function escapeXml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

interface SitemapUrl {
  loc: string;
  lastmod?: string;
  changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
  priority?: number;
  images?: Array<{ loc: string; title: string; caption?: string }>;
}

export function generateSitemapXml(baseUrl: string = 'https://www.cashncarryng.com'): string {
  const cleanBase = baseUrl.replace(/\/+$/, '');
  const today = new Date().toISOString().split('T')[0];

  const urls: SitemapUrl[] = [];

  // 1. High-Priority Marketplace Static Pages
  urls.push(
    {
      loc: `${cleanBase}/`,
      lastmod: today,
      changefreq: 'daily',
      priority: 1.0,
      images: [
        {
          loc: `${cleanBase}/brand/logo.png`,
          title: 'Cash N Carry Nigeria Marketplace',
          caption: "Nigeria's premier live commerce marketplace",
        },
      ],
    },
    {
      loc: `${cleanBase}/shop`,
      lastmod: today,
      changefreq: 'daily',
      priority: 0.9,
    },
    {
      loc: `${cleanBase}/live`,
      lastmod: today,
      changefreq: 'daily',
      priority: 0.8,
    },
    {
      loc: `${cleanBase}/auctions`,
      lastmod: today,
      changefreq: 'hourly',
      priority: 0.8,
    },
    {
      loc: `${cleanBase}/flash-deals`,
      lastmod: today,
      changefreq: 'hourly',
      priority: 0.8,
    },
    {
      loc: `${cleanBase}/returns`,
      lastmod: today,
      changefreq: 'monthly',
      priority: 0.5,
    }
  );

  // 2. Category Pages
  for (const cat of categories) {
    urls.push({
      loc: `${cleanBase}/shop?category=${encodeURIComponent(cat.id)}`,
      lastmod: today,
      changefreq: 'daily',
      priority: 0.8,
    });
  }

  // 3. Product Detail Pages with Image Sitemap Metadata
  for (const prod of products) {
    const productSlug = prod.slug || prod.id;
    const productImages: SitemapUrl['images'] = [];

    if (prod.image) {
      productImages.push({
        loc: prod.image,
        title: prod.title,
        caption: `${prod.title} by ${prod.brand} - ₦${prod.price.toLocaleString()} on Cash N Carry Nigeria`,
      });
    }

    urls.push({
      loc: `${cleanBase}/product/${encodeURIComponent(productSlug)}`,
      lastmod: today,
      changefreq: 'weekly',
      priority: 0.9,
      images: productImages,
    });
  }

  // 4. Verified Seller Storefront Pages
  for (const seller of sellers) {
    const sellerSlug = seller.slug || seller.id;
    urls.push({
      loc: `${cleanBase}/seller/${encodeURIComponent(sellerSlug)}`,
      lastmod: today,
      changefreq: 'weekly',
      priority: 0.7,
      images: seller.avatar
        ? [
            {
              loc: seller.avatar,
              title: `${seller.name} Storefront`,
              caption: `Verified CAC Merchant in ${seller.location}`,
            },
          ]
        : undefined,
    });
  }

  // Build XML String
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"\n';
  xml += '        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n';

  for (const entry of urls) {
    xml += '  <url>\n';
    xml += `    <loc>${escapeXml(entry.loc)}</loc>\n`;
    if (entry.lastmod) {
      xml += `    <lastmod>${entry.lastmod}</lastmod>\n`;
    }
    if (entry.changefreq) {
      xml += `    <changefreq>${entry.changefreq}</changefreq>\n`;
    }
    if (entry.priority !== undefined) {
      xml += `    <priority>${entry.priority.toFixed(1)}</priority>\n`;
    }

    if (entry.images && entry.images.length > 0) {
      for (const img of entry.images) {
        xml += '    <image:image>\n';
        xml += `      <image:loc>${escapeXml(img.loc)}</image:loc>\n`;
        if (img.title) {
          xml += `      <image:title>${escapeXml(img.title)}</image:title>\n`;
        }
        if (img.caption) {
          xml += `      <image:caption>${escapeXml(img.caption)}</image:caption>\n`;
        }
        xml += '    </image:image>\n';
      }
    }

    xml += '  </url>\n';
  }

  xml += '</urlset>\n';
  return xml;
}

export function generateRobotsTxt(baseUrl: string = 'https://www.cashncarryng.com'): string {
  const cleanBase = baseUrl.replace(/\/+$/, '');
  return `# Cash N Carry Nigeria - Robots Crawler Directives
# https://www.cashncarryng.com

User-agent: *

# Publicly discoverable marketplace catalog & media
Allow: /
Allow: /shop
Allow: /product/
Allow: /auctions
Allow: /live
Allow: /flash-deals
Allow: /returns
Allow: /coins
Allow: /seller/storefront/
Allow: /brand/
Allow: /assets/
Allow: /sitemap.xml
Allow: /feed/
Allow: /feed/google-shopping.xml

# Protected backend APIs & webhook gateways
Disallow: /api/
Disallow: /api/*

# Sensitive administration portals
Disallow: /admin
Disallow: /admin/
Disallow: /admin/*
Disallow: /*?tab=admin*

# Sensitive merchant & seller centre consoles
Disallow: /seller/dashboard
Disallow: /seller/kyc
Disallow: /seller/orders
Disallow: /seller/products
Disallow: /seller/settlements
Disallow: /seller-dashboard
Disallow: /seller-kyc
Disallow: /seller-orders
Disallow: /seller-products
Disallow: /seller-settlements
Disallow: /*?tab=seller*

# Private user accounts, checkout & order receipts
Disallow: /checkout
Disallow: /checkout/
Disallow: /checkout-complete
Disallow: /profile
Disallow: /profile/
Disallow: /orders
Disallow: /orders/
Disallow: /messages
Disallow: /notifications
Disallow: /*?tab=checkout*
Disallow: /*?tab=profile*
Disallow: /*?tab=orders*
Disallow: /*?tab=messages*
Disallow: /*?tab=notifications*

# Crawl rate limit
Crawl-delay: 1

# Canonical XML Sitemaps
Sitemap: ${cleanBase}/sitemap.xml
`;
}

export function writeSitemapFiles(baseUrl?: string) {
  const resolvedBase =
    baseUrl ||
    process.env.APP_URL ||
    process.env.SITE_URL ||
    'https://www.cashncarryng.com';

  const xmlContent = generateSitemapXml(resolvedBase);
  const robotsContent = generateRobotsTxt(resolvedBase);

  // Write to public/
  const publicDir = path.resolve(rootDir, 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  const publicSitemapPath = path.resolve(publicDir, 'sitemap.xml');
  fs.writeFileSync(publicSitemapPath, xmlContent, 'utf-8');

  const publicRobotsPath = path.resolve(publicDir, 'robots.txt');
  fs.writeFileSync(publicRobotsPath, robotsContent, 'utf-8');

  console.log(`[Sitemap] Generated public/sitemap.xml (${xmlContent.length} bytes)`);
  console.log(`[Sitemap] Generated public/robots.txt (${robotsContent.length} bytes)`);

  // Write to dist/ if it exists
  const distDir = path.resolve(rootDir, 'dist');
  if (fs.existsSync(distDir)) {
    const distSitemapPath = path.resolve(distDir, 'sitemap.xml');
    fs.writeFileSync(distSitemapPath, xmlContent, 'utf-8');

    const distRobotsPath = path.resolve(distDir, 'robots.txt');
    fs.writeFileSync(distRobotsPath, robotsContent, 'utf-8');

    console.log(`[Sitemap] Synced to dist/sitemap.xml and dist/robots.txt`);
  }

  console.log(`[Sitemap] Total products indexed: ${products.length}`);
  console.log(`[Sitemap] Total categories indexed: ${categories.length}`);
  console.log(`[Sitemap] Total sellers indexed: ${sellers.length}`);
  console.log(`[Sitemap] Base Canonical Domain: ${resolvedBase}`);
}

// Run immediately when executed directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const cliBaseArg = process.argv.find((arg) => arg.startsWith('--base-url='));
  const customBase = cliBaseArg ? cliBaseArg.split('=')[1] : undefined;
  writeSitemapFiles(customBase);
}
