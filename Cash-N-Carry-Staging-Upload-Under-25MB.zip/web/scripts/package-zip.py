#!/usr/bin/env python3
import os
import zipfile
import shutil

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
PUBLIC_DIR = os.path.join(ROOT_DIR, 'public')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')

OUTPUT_NAMES = ['Cash-N-Carry-Staging-V17-Repaired.zip', 'cash-n-carry-source.zip']

EXCLUDE_DIRS = {
    'node_modules',
    '.git',
    '.aistudio',
    'dist',
    '__pycache__',
    'merged-cash-n-carry',
    '.wrangler',
    '.wrangler-dry-run',
    '.playwright-cli',
    'playwright-report',
    'test-results',
}

EXCLUDE_EXTS = {
    '.zip'
}

EXCLUDE_FILES = {
    '.env',
    '.env.local',
    '.env.production',
    '.DS_Store',
    'server.js',
    '_temp_package.zip',
}

def should_include(rel_path):
    parts = rel_path.split(os.sep)
    for p in parts:
        if p in EXCLUDE_DIRS:
            return False
    base = os.path.basename(rel_path)
    if base in EXCLUDE_FILES:
        return False
    _, ext = os.path.splitext(rel_path)
    if ext in EXCLUDE_EXTS:
        return False
    return True

def package():
    temp_zip = os.path.join(ROOT_DIR, '_temp_package.zip')
    if os.path.exists(temp_zip):
        os.remove(temp_zip)

    count = 0
    with zipfile.ZipFile(temp_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(ROOT_DIR):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, ROOT_DIR)
                if should_include(rel_path):
                    zf.write(full_path, rel_path)
                    count += 1

    size_mb = os.path.getsize(temp_zip) / (1024 * 1024)
    print(f"Packaged {count} files ({size_mb:.2f} MB)")

    os.makedirs(PUBLIC_DIR, exist_ok=True)
    os.makedirs(DIST_DIR, exist_ok=True)

    for name in OUTPUT_NAMES:
        dest_public = os.path.join(PUBLIC_DIR, name)
        dest_dist = os.path.join(DIST_DIR, name)
        shutil.copyfile(temp_zip, dest_public)
        shutil.copyfile(temp_zip, dest_dist)
        print(f" -> Wrote {dest_public} and {dest_dist}")

    os.remove(temp_zip)
    print("Packaging complete!")

if __name__ == '__main__':
    package()
