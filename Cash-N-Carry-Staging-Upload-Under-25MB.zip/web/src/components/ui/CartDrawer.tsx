import React from 'react';
import { useStore } from '../../context/StoreContext';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onProceedToCheckout: () => void;
}

export default function CartDrawer({ isOpen, onClose, onProceedToCheckout }: CartDrawerProps) {
  const { cart, removeFromCart, updateCartQuantity, cartCount, cartSubtotal } = useStore();

  if (!isOpen) return null;

  const shipping = cartSubtotal > 50000 ? 0 : cart.length > 0 ? 2500 : 0;
  const total = cartSubtotal + shipping;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-sm transition-opacity">
      <div
        className="relative flex h-full w-full max-w-md flex-col bg-white shadow-2xl animate-in slide-in-from-right duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div className="flex items-center gap-2">
            <ShoppingBag className="text-[#0c5c36]" size={22} />
            <h2 className="text-lg font-black text-slate-900">Your Shopping Bag ({cartCount})</h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Free Shipping Progress Indicator */}
        <div className="bg-emerald-50 px-6 py-2.5 text-xs text-emerald-900 border-b border-emerald-100">
          {cartSubtotal >= 50000 ? (
            <span className="font-bold text-emerald-800 flex items-center gap-1.5">
              🎉 Congratulations! You have unlocked FREE Nationwide Delivery!
            </span>
          ) : (
            <span>
              Add <b className="text-emerald-800">₦{(50000 - cartSubtotal).toLocaleString()}</b> more for{' '}
              <b className="underline">FREE Nationwide Delivery</b>!
            </span>
          )}
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto px-6 py-4 divide-y divide-slate-100">
          {cart.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-slate-100 text-slate-400">
                <ShoppingBag size={36} />
              </div>
              <h3 className="mt-4 text-base font-black text-slate-800">Your cart is empty</h3>
              <p className="mt-1 max-w-xs text-xs text-slate-500">
                Explore our catalog of verified Nigerian vendors and add items you love.
              </p>
              <button
                onClick={onClose}
                className="mt-6 rounded-full bg-[#0c5c36] px-6 py-2.5 text-xs font-bold text-white hover:bg-emerald-900 transition"
              >
                Start Shopping
              </button>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.productId} className="flex gap-4 py-4">
                <img
                  src={item.image}
                  alt={item.title}
                  className="h-20 w-20 rounded-xl object-cover border border-slate-100 bg-slate-50 shrink-0"
                />
                <div className="flex flex-1 flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{item.title}</h4>
                      <button
                        onClick={() => removeFromCart(item.productId)}
                        className="text-slate-400 hover:text-rose-600 transition"
                        title="Remove item"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                    <span className="text-[10px] text-slate-400 font-semibold">{item.sellerName}</span>
                    <div className="mt-1 text-xs font-extrabold text-[#0c5c36]">
                      ₦{item.price.toLocaleString('en-NG')}
                    </div>
                  </div>

                  <div className="mt-2 flex items-center justify-between">
                    {/* Quantity controls */}
                    <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 p-0.5">
                      <button
                        onClick={() => updateCartQuantity(item.productId, item.quantity - 1)}
                        className="rounded p-1 text-slate-600 hover:bg-white transition"
                        aria-label="Decrease quantity"
                      >
                        <Minus size={12} />
                      </button>
                      <span className="w-6 text-center text-xs font-black text-slate-800">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateCartQuantity(item.productId, item.quantity + 1)}
                        className="rounded p-1 text-slate-600 hover:bg-white transition"
                        aria-label="Increase quantity"
                        disabled={item.quantity >= item.stock}
                      >
                        <Plus size={12} />
                      </button>
                    </div>

                    <div className="text-right text-xs font-bold text-slate-700">
                      ₦{(item.price * item.quantity).toLocaleString('en-NG')}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Drawer Footer & Checkout CTA */}
        {cart.length > 0 && (
          <div className="border-t border-slate-200 bg-slate-50/80 p-6 space-y-3">
            <div className="space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Items Subtotal:</span>
                <span className="font-bold text-slate-900">₦{cartSubtotal.toLocaleString('en-NG')}</span>
              </div>
              <div className="flex justify-between">
                <span>Nationwide Shipping:</span>
                <span>
                  {shipping === 0 ? (
                    <span className="font-bold text-emerald-700 uppercase text-[10px]">FREE</span>
                  ) : (
                    `₦${shipping.toLocaleString('en-NG')}`
                  )}
                </span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2 text-sm font-black text-slate-900">
                <span>Estimated Total:</span>
                <span className="text-[#0c5c36]">₦{total.toLocaleString('en-NG')}</span>
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                onProceedToCheckout();
              }}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white shadow-lg transition hover:bg-emerald-900 hover:shadow-xl"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight size={16} />
            </button>

            <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400">
              <ShieldCheck size={14} className="text-emerald-700" />
              <span>Protected by Flutterwave Sandbox Escrow</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
