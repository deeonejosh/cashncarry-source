import React, { useState } from 'react';
import BrandLogo from './BrandLogo';
import { useStore } from '../../context/StoreContext';
import { Terminal, Download, ArrowRight, CheckCircle2 } from 'lucide-react';

interface FooterProps {
  setCurrentTab: (tab: string) => void;
  onOpenQA: () => void;
  onOpenExport: () => void;
}

export default function Footer({ setCurrentTab, onOpenQA, onOpenExport }: FooterProps) {
  const { currentUser, showToast, subscribeToNewsletter } = useStore();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) {
      showToast('Please enter a valid email address');
      return;
    }
    const res = subscribeToNewsletter(newsletterEmail, { source: 'footer' });
    if (res.success) {
      setSubscribed(true);
      setNewsletterEmail('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  return (
    <footer className="border-t border-slate-200 bg-white pt-14 pb-28 md:pb-12 text-slate-600">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        
        {/* Main Footer Grid: 6 Columns + Branding matching Image 2 */}
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-7 pb-12 border-b border-slate-100">
          
          {/* Brand & Socials (Col 1-2 on wide screens) */}
          <div className="col-span-2 space-y-4">
            <button
              onClick={() => {
                setCurrentTab('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-left"
            >
              <BrandLogo />
            </button>
            <p className="max-w-xs text-xs text-slate-500 leading-relaxed">
              Nigeria's trusted marketplace for shopping, livestreams and business growth.
            </p>

            {/* Social Icons matching Image 2: Facebook, Instagram, TikTok, YouTube, X */}
            <div className="flex items-center gap-2.5 pt-1">
              {/* Facebook */}
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white hover:bg-[#0c5c36] transition"
                aria-label="Facebook"
              >
                <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </a>

              {/* Instagram */}
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white hover:bg-[#0c5c36] transition"
                aria-label="Instagram"
              >
                <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.13-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>

              {/* TikTok */}
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white hover:bg-[#0c5c36] transition"
                aria-label="TikTok"
              >
                <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298-.002.595.042.88.13V9.4a6.33 6.33 0 0 0-1-.08A6.34 6.34 0 0 0 3 15.66a6.34 6.34 0 0 0 10.82 4.49 6.26 6.26 0 0 0 1.87-4.49V8.7a8.28 8.28 0 0 0 3.9 1.44V6.69z" />
                </svg>
              </a>

              {/* YouTube */}
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white hover:bg-[#0c5c36] transition"
                aria-label="YouTube"
              >
                <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.5 12 3.5 12 3.5s-7.505 0-9.377.55a3.016 3.016 0 0 0-2.122 2.136C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.55 9.376.55 9.376.55s7.505 0 9.377-.55a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                </svg>
              </a>

              {/* X / Twitter */}
              <a
                href="https://x.com"
                target="_blank"
                rel="noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white hover:bg-[#0c5c36] transition"
                aria-label="X (Twitter)"
              >
                <svg className="h-3.5 w-3.5 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Col 1: Shop */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900">Shop</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentTab('shop')} className="hover:text-[#0c5c36] transition text-left">
                  All Products
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('flash-deals')} className="hover:text-[#0c5c36] transition text-left">
                  Flash Deals
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('shop')} className="hover:text-[#0c5c36] transition text-left">
                  Featured Sellers
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('shop')} className="hover:text-[#0c5c36] transition text-left">
                  Categories
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('for-you')} className="hover:text-[#0c5c36] transition text-left">
                  For You
                </button>
              </li>
            </ul>
          </div>

          {/* Col 2: Sell With Us */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900">Sell With Us</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => {
                    setCurrentTab('seller-kyc');
                  }}
                  className="hover:text-[#0c5c36] transition text-left"
                >
                  Become a Seller
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    if (currentUser.role === 'seller') {
                      setCurrentTab('seller-dashboard');
                    } else {
                      setCurrentTab('seller-kyc');
                    }
                  }}
                  className="hover:text-[#0c5c36] transition text-left"
                >
                  Seller Centre
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentTab('policies');
                  }}
                  className="hover:text-[#0c5c36] transition text-left"
                >
                  Seller Guidelines & Code
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    if (currentUser.role === 'seller') {
                      setCurrentTab('seller-settlements');
                    } else {
                      setCurrentTab('policies');
                    }
                  }}
                  className="hover:text-[#0c5c36] transition text-left"
                >
                  Fees & Settlement
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentTab('messages');
                  }}
                  className="hover:text-[#0c5c36] transition text-left"
                >
                  Seller Support
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Support */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900">Support</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentTab('profile')} className="hover:text-[#0c5c36] transition text-left">
                  Help Centre
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('profile')} className="hover:text-[#0c5c36] transition text-left">
                  FAQs
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('messages')} className="hover:text-[#0c5c36] transition text-left">
                  Contact Us
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('messages')} className="hover:text-[#0c5c36] transition text-left">
                  Report a Problem
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('messages')} className="hover:text-[#0c5c36] transition text-left">
                  Complaints
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: About Cash N Carry */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900">About Cash N Carry</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentTab('home')} className="hover:text-[#0c5c36] transition text-left">
                  About Us
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('home')} className="hover:text-[#0c5c36] transition text-left">
                  How It Works
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('home')} className="hover:text-[#0c5c36] transition text-left">
                  Why Shop With Us
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('home')} className="hover:text-[#0c5c36] transition text-left">
                  Careers
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('home')} className="hover:text-[#0c5c36] transition text-left">
                  Partnerships
                </button>
              </li>
            </ul>
          </div>

          {/* Col 5: Legal */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900">Legal</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentTab('policies')} className="hover:text-[#0c5c36] transition text-left">
                  Terms & Conditions
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('policies')} className="hover:text-[#0c5c36] transition text-left">
                  Privacy Policy (NDPA 2023)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('policies')} className="hover:text-[#0c5c36] transition text-left">
                  CBN Escrow & Settlement
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('policies')} className="hover:text-[#0c5c36] transition text-left">
                  7-Day Returns & Refunds
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('policies')} className="hover:text-[#0c5c36] transition text-left">
                  All Policies & Code
                </button>
              </li>
            </ul>
          </div>

          {/* Col 6: Stay in the loop (Newsletter matching Image 2) */}
          <div className="space-y-3 col-span-2 sm:col-span-1 lg:col-span-1">
            <h4 className="text-xs font-black text-slate-900">Stay in the loop</h4>
            <p className="text-xs text-slate-500">
              Get the latest deals, offers and updates.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <input
                type="email"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="Enter your email"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 outline-none focus:border-[#0c5c36] focus:bg-white"
              />
              <button
                type="submit"
                className="w-full rounded-xl bg-[#0c5c36] py-2 text-xs font-bold text-white transition hover:bg-emerald-900 shadow-sm"
              >
                {subscribed ? 'Subscribed ✓' : 'Subscribe'}
              </button>
            </form>
          </div>

        </div>

        {/* Bottom Bar matching Image 2 */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <div>
            © 2026 Cash N Carry Nigeria. All rights reserved.
          </div>
          
          <div className="flex flex-wrap items-center gap-4 text-xs">
            <span className="flex items-center gap-1 font-semibold text-slate-700">
              <span>🇳🇬</span>
              <span>Nigeria (₦ NGN)</span>
            </span>
            <span className="text-slate-300">|</span>
            <button
              onClick={() => showToast('WCAG 2.1 AA Accessibility Compliant')}
              className="hover:text-slate-900 transition"
            >
              Accessibility
            </button>
            <span className="text-slate-300">|</span>
            <a
              href="/sitemap.xml"
              target="_blank"
              rel="noreferrer"
              className="hover:text-[#0c5c36] font-medium transition"
              title="View Dynamic XML Sitemap"
            >
              Sitemap
            </a>
            
            {/* Quick Testing Diagnostics */}
            <span className="text-slate-300">|</span>
            <button
              onClick={onOpenQA}
              className="flex items-center gap-1 text-emerald-800 font-bold hover:underline"
              title="Open QA Diagnostic Suite"
            >
              <Terminal size={12} /> QA
            </button>
            <a
              href="/Cash-N-Carry-Staging-V17-Repaired.zip"
              download="Cash-N-Carry-Staging-V17-Repaired.zip"
              className="flex items-center gap-1 text-orange-600 font-bold hover:underline"
              title="Download Repaired V17 Staging Source ZIP"
            >
              <Download size={12} /> V17 Staging ZIP
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
}

