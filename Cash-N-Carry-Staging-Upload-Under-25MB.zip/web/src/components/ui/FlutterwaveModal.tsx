import React, { useState } from 'react';
import { Order } from '../../types';
import { useStore } from '../../context/StoreContext';
import { ShieldCheck, CreditCard, Building2, Smartphone, CheckCircle2, Lock, AlertCircle, Loader2, KeyRound, ExternalLink } from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../../lib/api';

interface FlutterwaveModalProps {
  order: Order;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (orderId: string, txRef: string) => void;
}

export default function FlutterwaveModal({ order, isOpen, onClose, onSuccess }: FlutterwaveModalProps) {
  const { stagingConfig, payOrderWithFlutterwave } = useStore();
  const paymentsEnabled = stagingConfig.paymentsEnabled;

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'bank' | 'ussd'>('card');
  const [step, setStep] = useState<'card' | 'otp' | 'complete'>('card');
  const [cardNumber, setCardNumber] = useState('5531 8200 4819 9021');
  const [expiry, setExpiry] = useState('09/28');
  const [cvv, setCvv] = useState('842');
  const [pin, setPin] = useState('1234');
  const [otp, setOtp] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCardSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentsEnabled) {
      setErrorMessage('Payments temporarily unavailable in staging (PAYMENTS_ENABLED=false).');
      return;
    }
    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const init = await api.initializePayment(order.id);
      if (init.error || !init.checkout_url) {
        setErrorMessage(init.error || 'Payments temporarily unavailable');
      } else {
        setStep('otp');
      }
    } catch {
      setErrorMessage('Payments temporarily unavailable');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentsEnabled) {
      setErrorMessage('Payments temporarily unavailable in staging (PAYMENTS_ENABLED=false).');
      return;
    }
    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const result = await payOrderWithFlutterwave(order.id, cardNumber);
      if (result.success && result.txRef) {
        setStep('complete');
        try {
          confetti({
            particleCount: 90,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch {}
        onSuccess(order.id, result.txRef);
      } else {
        setErrorMessage(result.message || 'Payments temporarily unavailable');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Payment gateway connection error');
    } finally {
      setIsProcessing(false);
    }
  };

  const useTestCard = (type: 'mastercard' | 'verve' | 'visa') => {
    if (type === 'mastercard') {
      setCardNumber('5531 8200 4819 9021');
      setExpiry('09/28');
      setCvv('842');
    } else if (type === 'verve') {
      setCardNumber('5061 0000 1234 5678');
      setExpiry('11/27');
      setCvv('381');
    } else {
      setCardNumber('4084 0840 0840 0840');
      setExpiry('12/29');
      setCvv('111');
    }
    setStep('card');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl border border-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Flutterwave Branded Header */}
        <div className="bg-[#0c5c36] p-5 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-white/10 font-black text-xs text-orange-400">
                FW
              </span>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-emerald-200 font-bold">
                  {paymentsEnabled ? 'Verified Flutterwave Sandbox' : 'Flutterwave Disabled in Staging'}
                </div>
                <h3 className="text-sm font-black">Cash N Carry Nigeria</h3>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-emerald-200">Order: {order.id}</div>
              <div className="text-base font-black">₦{order.total.toLocaleString('en-NG')}</div>
            </div>
          </div>
        </div>

        {/* Payment Channels Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-bold text-slate-600">
          <button
            onClick={() => { setPaymentMethod('card'); setStep('card'); }}
            className={`flex flex-1 items-center justify-center gap-1.5 py-3 border-b-2 transition ${
              paymentMethod === 'card' ? 'border-[#0c5c36] text-[#0c5c36] bg-white' : 'hover:bg-slate-100'
            }`}
          >
            <CreditCard size={15} /> Card
          </button>
          <button
            onClick={() => setPaymentMethod('bank')}
            className={`flex flex-1 items-center justify-center gap-1.5 py-3 border-b-2 transition ${
              paymentMethod === 'bank' ? 'border-[#0c5c36] text-[#0c5c36] bg-white' : 'hover:bg-slate-100'
            }`}
          >
            <Building2 size={15} /> Bank Transfer
          </button>
          <button
            onClick={() => setPaymentMethod('ussd')}
            className={`flex flex-1 items-center justify-center gap-1.5 py-3 border-b-2 transition ${
              paymentMethod === 'ussd' ? 'border-[#0c5c36] text-[#0c5c36] bg-white' : 'hover:bg-slate-100'
            }`}
          >
            <Smartphone size={15} /> USSD
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6">
          {!paymentsEnabled && (
            <div className="mb-4 flex items-start gap-2 rounded-xl bg-amber-50 p-3 text-xs text-amber-900 border border-amber-200">
              <AlertCircle size={16} className="shrink-0 mt-0.5 text-amber-700" />
              <div>
                <div className="font-black">Payments temporarily unavailable</div>
                <p className="text-[11px] text-amber-800 mt-0.5">
                  Payment initiation and checkout confirmation are disabled in staging (PAYMENTS_ENABLED=false).
                </p>
              </div>
            </div>
          )}

          {errorMessage && (
            <div className="mb-4 flex items-center gap-2 rounded-xl bg-rose-50 p-3 text-xs text-rose-700 border border-rose-200">
              <AlertCircle size={16} />
              <span>{errorMessage}</span>
            </div>
          )}

          {step === 'card' && paymentMethod === 'card' && (
            <form onSubmit={handleCardSubmit} className="space-y-4">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-semibold text-slate-500">Official Test Cards:</span>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => useTestCard('mastercard')}
                    className="rounded bg-emerald-50 px-2 py-0.5 font-bold text-emerald-800 hover:bg-emerald-100"
                  >
                    Mastercard
                  </button>
                  <button
                    type="button"
                    onClick={() => useTestCard('verve')}
                    className="rounded bg-amber-50 px-2 py-0.5 font-bold text-amber-800 hover:bg-amber-100"
                  >
                    Verve
                  </button>
                  <button
                    type="button"
                    onClick={() => useTestCard('visa')}
                    className="rounded bg-blue-50 px-2 py-0.5 font-bold text-blue-800 hover:bg-blue-100"
                  >
                    Visa
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700">Card Number</label>
                <div className="relative mt-1">
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    required
                    className="h-11 w-full rounded-xl border border-slate-200 px-3 font-mono text-sm outline-none focus:border-emerald-600"
                    placeholder="5531 8200 4819 9021"
                  />
                  <CreditCard className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700">Valid Till</label>
                  <input
                    type="text"
                    value={expiry}
                    onChange={(e) => setExpiry(e.target.value)}
                    required
                    className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 font-mono text-sm outline-none focus:border-emerald-600"
                    placeholder="MM/YY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700">CVV</label>
                  <input
                    type="password"
                    maxLength={3}
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value)}
                    required
                    className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 font-mono text-sm outline-none focus:border-emerald-600"
                    placeholder="123"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700">Card PIN (4 digits)</label>
                <input
                  type="password"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 font-mono text-sm outline-none focus:border-emerald-600"
                  placeholder="••••"
                />
              </div>

              <button
                type="submit"
                disabled={isProcessing || !paymentsEnabled}
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white shadow-lg transition hover:bg-emerald-900 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isProcessing ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Connecting to Flutterwave Sandbox...</span>
                  </>
                ) : !paymentsEnabled ? (
                  <>
                    <Lock size={15} />
                    <span>Payments temporarily unavailable</span>
                  </>
                ) : (
                  <>
                    <Lock size={15} />
                    <span>Proceed to 3D-Secure (₦{order.total.toLocaleString('en-NG')})</span>
                  </>
                )}
              </button>
            </form>
          )}

          {step === 'otp' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-amber-900">
                  <ShieldCheck size={16} className="text-amber-700" />
                  <span>Flutterwave 3D-Secure 2.0 Challenge</span>
                </div>
                <p className="text-slate-600">
                  Enter the 3D-Secure OTP issued by your Flutterwave sandbox session when enabled.
                </p>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700">One-Time Password (OTP)</label>
                <div className="relative mt-1">
                  <input
                    type="text"
                    maxLength={6}
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    required
                    disabled={!paymentsEnabled}
                    autoFocus
                    className="h-12 w-full rounded-xl border border-slate-200 px-3 text-center font-mono text-lg font-black tracking-widest outline-none focus:border-emerald-600 disabled:bg-slate-100"
                    placeholder="••••••"
                  />
                  <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('card')}
                  className="rounded-xl border border-slate-200 px-4 py-3 text-xs font-bold text-slate-600 hover:bg-slate-50"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isProcessing || !paymentsEnabled}
                  className="flex-1 flex items-center justify-center gap-2 rounded-2xl bg-[#0c5c36] py-3 text-xs font-black text-white shadow-lg transition hover:bg-emerald-900 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      <span>Reconciling Transaction...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 size={15} />
                      <span>Authorize ₦{order.total.toLocaleString('en-NG')}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {step === 'complete' && (
            <div className="py-6 text-center space-y-3">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-[#0c5c36]">
                <CheckCircle2 size={32} />
              </div>
              <h4 className="text-base font-black text-slate-900">Payment Authorized</h4>
              <p className="text-xs text-slate-500">
                Flutterwave reference generated. Updating order status and initializing GIG Logistics fulfillment...
              </p>
            </div>
          )}

          {paymentMethod === 'bank' && (
            <div className="space-y-4 text-xs">
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 space-y-2">
                <div className="font-bold text-emerald-900">Dedicated Virtual NUBAN Account (Preview)</div>
                <div className="space-y-1 text-slate-700">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Bank Name:</span>
                    <span className="font-bold">Wema Bank / Flutterwave</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Account Number:</span>
                    <span className="font-mono font-bold text-sm text-emerald-800">0192849102</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Account Name:</span>
                    <span className="font-bold">Cash N Carry / {order.id}</span>
                  </div>
                </div>
              </div>
              <button
                type="button"
                disabled={isProcessing || !paymentsEnabled}
                onClick={() => handleVerifyOtp({ preventDefault: () => {} } as any)}
                className="w-full rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {paymentsEnabled ? `I have transferred ₦${order.total.toLocaleString('en-NG')}` : 'Payments temporarily unavailable'}
              </button>
            </div>
          )}

          {paymentMethod === 'ussd' && (
            <div className="space-y-4 text-xs">
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-2 text-center">
                <span className="text-slate-500 font-medium">USSD Payment Preview Code:</span>
                <div className="font-mono text-base font-black text-emerald-800 bg-white py-2 rounded-xl border border-slate-200">
                  *737*50*{order.total}*1092#
                </div>
                <p className="text-[11px] text-slate-500">Supports GTBank, Zenith, Access, UBA, FirstBank</p>
              </div>
              <button
                type="button"
                disabled={isProcessing || !paymentsEnabled}
                onClick={() => handleVerifyOtp({ preventDefault: () => {} } as any)}
                className="w-full rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {paymentsEnabled ? 'Confirm USSD Payment' : 'Payments temporarily unavailable'}
              </button>
            </div>
          )}

          <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-4 text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <ShieldCheck size={14} className="text-emerald-700" />
              <span>PCI-DSS Level 1 & CBN Compliant</span>
            </span>
            <button onClick={onClose} className="font-bold hover:text-slate-700">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
