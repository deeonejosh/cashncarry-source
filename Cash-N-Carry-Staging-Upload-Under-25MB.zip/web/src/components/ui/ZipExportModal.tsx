import React, { useState } from 'react';
import { Download, X, CheckCircle2, FileCode, Layers, ShieldCheck, Terminal, Copy } from 'lucide-react';

export default function ZipExportModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const deployInstructions = `# Cash N Carry Nigeria - V17 Repaired Cloudflare Staging Guide

1. Unzip the repaired V17 source bundle:
   unzip Cash-N-Carry-Staging-V17-Repaired.zip -d cashncarry-v17
   cd cashncarry-v17 && npm install

2. Run TypeScript checks, D1 migration checks, and automated Worker tests:
   npm run lint
   npm test

3. Configure Staging Environment (PAYMENTS_ENABLED=false by default):
   - D1 Binding: cashncarry-d1-staging (9a2cdbee-e030-4b10-908b-b10b8142d2aa)
   - Apply migrations: npx wrangler d1 migrations apply AUTH_DB --remote
   - Secrets (only if enabling features): FLW_SECRET_KEY, FLW_WEBHOOK_HASH, KYC_DOCUMENT_KEY

4. Build Vite frontend + Cloudflare Worker bundle:
   npm run build:sites-candidate

5. Deploy to private Cloudflare staging:
   npx wrangler deploy --env staging`;

  const copyInstructions = () => {
    navigator.clipboard.writeText(deployInstructions);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="flex h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl border border-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-slate-200 bg-[#073c22] p-5 text-white">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 text-emerald-300">
              <Download size={22} />
            </div>
            <div>
              <h3 className="text-base font-black">Export V17 Repaired Staging Source Bundle</h3>
              <p className="text-xs text-emerald-200/80">
                Cloudflare Workers + D1 Migrations (0001–0010) + Fail-Closed Staging Safeguards
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-emerald-200 hover:bg-white/10 hover:text-white transition"
          >
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 space-y-2">
            <div className="flex items-center gap-2 text-xs font-black text-emerald-900">
              <CheckCircle2 size={16} className="text-emerald-700" />
              <span>Repaired V17 Staging Source Package Ready</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Includes repaired <code>wrangler.jsonc</code> bound to staging D1 <code>cashncarry-d1-staging</code>
              (<code>9a2cdbee-e030-4b10-908b-b10b8142d2aa</code>), server-controlled staging flags
              (<code>PAYMENTS_ENABLED=false</code>, <code>COINS_PURCHASES_ENABLED=false</code>, <code>KYC_UPLOADS_ENABLED=false</code>),
              repaired D1 triggers and schema, and verified frontend/Worker API alignment.
            </p>
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <a
                href="/Cash-N-Carry-Staging-V17-Repaired.zip"
                download="Cash-N-Carry-Staging-V17-Repaired.zip"
                className="flex items-center gap-2 rounded-xl bg-[#0c5c36] px-5 py-2.5 text-xs font-black text-white shadow-md hover:bg-emerald-900 transition"
              >
                <Download size={15} />
                <span>Download Cash-N-Carry-Staging-V17-Repaired.zip</span>
              </a>

              <a
                href="/cash-n-carry-source.zip"
                download="cash-n-carry-source.zip"
                className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition shadow-sm"
              >
                <Download size={15} />
                <span>Mirror (cash-n-carry-source.zip)</span>
              </a>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-black text-slate-800">
                <Terminal size={15} className="text-slate-500" />
                <span>Staging Build &amp; Verification Instructions</span>
              </div>
              <button
                onClick={copyInstructions}
                className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-[11px] font-bold text-slate-700 hover:bg-slate-100"
              >
                <Copy size={12} />
                <span>{copied ? 'Copied!' : 'Copy Commands'}</span>
              </button>
            </div>
            <pre className="max-h-60 overflow-y-auto rounded-2xl bg-slate-900 p-4 font-mono text-xs text-emerald-300 leading-relaxed whitespace-pre-wrap">
              {deployInstructions}
            </pre>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-1.5 text-xs text-slate-600">
            <div className="font-bold text-slate-900">Safety &amp; Staging Isolation Notes:</div>
            <ul className="list-disc pl-4 space-y-1 text-[11px]">
              <li>All Cloudflare D1 migrations (<code>0001</code>–<code>0010</code>) &amp; <code>staging-init-complete.sql</code> remain verified.</li>
              <li>Payments, paid coins, payouts, and KYC R2 uploads fail closed while staging flags remain disabled.</li>
              <li>Production domains (<code>cashncarryng.com</code>) and production databases are untouched.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
