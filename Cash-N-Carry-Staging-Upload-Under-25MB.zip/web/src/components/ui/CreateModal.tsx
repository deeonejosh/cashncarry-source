import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  X,
  Upload,
  Radio,
  Video,
  Sparkles,
  Store,
  Tag,
  Music,
  CheckCircle2,
  Camera,
  Mic,
  MicOff,
  RotateCcw,
  Eye,
  MessageSquare,
  ShoppingBag,
  AlertCircle,
  Zap,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface CreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: string) => void;
}

export default function CreateModal({ isOpen, onClose, onNavigate }: CreateModalProps) {
  const {
    currentUser,
    products,
    uploadShortVideo,
    showToast,
  } = useStore();

  const [activeView, setActiveView] = useState<'menu' | 'upload-video' | 'go-live' | 'broadcasting'>('menu');

  // Video Upload State
  const [videoCaption, setVideoCaption] = useState('');
  const [selectedProductId, setSelectedProductId] = useState<string>('p5');
  const [soundTitle, setSoundTitle] = useState('Trending Naija Sound – Asake Live Remix');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [videoUrl, setVideoUrl] = useState('https://assets.mixkit.co/videos/preview/mixkit-young-man-dancing-while-listening-to-music-with-headphones-42171-large.mp4');
  const [posterUrl, setPosterUrl] = useState('https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80');

  // Go Live State
  const [streamTitle, setStreamTitle] = useState('Flash Sale Live: Huge Discounts on Verified Tech & Fashion');
  const [streamProductId, setStreamProductId] = useState<string>('p1');
  const [cameraActive, setCameraActive] = useState(false);
  const [micMuted, setMicMuted] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('user');
  const [liveViewers, setLiveViewers] = useState(148);
  const [liveComments, setLiveComments] = useState<Array<{ id: string; user: string; text: string }>>([
    { id: '1', user: 'Emeka L.', text: 'Is this available in Lagos today?' },
    { id: '2', user: 'Bisi W.', text: 'Checking out the pinned product right now!' },
  ]);
  const [liveCommentInput, setLiveCommentInput] = useState('');

  const videoPreviewRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Filter products for seller catalog tag picker
  const sellerProducts = products.filter((p) => p.publication === 'published');

  // Reset state on modal open
  useEffect(() => {
    if (isOpen) {
      setActiveView('menu');
      setUploadProgress(0);
      setIsUploading(false);
    } else {
      stopCamera();
    }
  }, [isOpen]);

  // Clean up media tracks when leaving live preview
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: cameraFacing },
          audio: true,
        });
        mediaStreamRef.current = stream;
        if (videoPreviewRef.current) {
          videoPreviewRef.current.srcObject = stream;
          videoPreviewRef.current.play().catch(() => {});
        }
        setCameraActive(true);
      } else {
        setCameraActive(false);
      }
    } catch {
      // Permission rejected or not supported in sandbox
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (videoPreviewRef.current) {
      videoPreviewRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const toggleMic = () => {
    if (mediaStreamRef.current) {
      const audioTracks = mediaStreamRef.current.getAudioTracks();
      audioTracks.forEach((t) => (t.enabled = !t.enabled));
      setMicMuted(!micMuted);
    } else {
      setMicMuted(!micMuted);
    }
  };

  const toggleCameraFacing = async () => {
    const nextFacing = cameraFacing === 'user' ? 'environment' : 'user';
    setCameraFacing(nextFacing);
    stopCamera();
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: nextFacing },
          audio: true,
        });
        mediaStreamRef.current = stream;
        if (videoPreviewRef.current) {
          videoPreviewRef.current.srcObject = stream;
          videoPreviewRef.current.play().catch(() => {});
        }
        setCameraActive(true);
      }
    } catch {
      setCameraActive(false);
    }
  };

  // Video Upload Simulation
  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoCaption.trim()) {
      showToast('Please enter a caption or description for your video');
      return;
    }

    setIsUploading(true);
    setUploadProgress(10);

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          setTimeout(() => {
            const tagged = products.find((p) => p.id === selectedProductId) || products[0];
            uploadShortVideo({
              sellerId: currentUser.id,
              sellerName: currentUser.storeName || currentUser.name,
              sellerAvatar: currentUser.avatar || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
              sellerVerified: true,
              isLiveNow: false,
              videoUrl: videoUrl,
              posterUrl: posterUrl,
              caption: videoCaption,
              taggedProduct: tagged,
              soundTitle: soundTitle || 'Original Audio',
            });
            setIsUploading(false);
            setUploadProgress(100);
            showToast('Video published successfully to For You feed!');
            onClose();
            onNavigate('for-you');
          }, 400);
          return 95;
        }
        return prev + 25;
      });
    }, 250);
  };

  // Start Live Broadcast
  const handleStartBroadcast = () => {
    setActiveView('broadcasting');
    showToast('Connecting to Cloudflare Stream WHIP session... You are now LIVE!');

    // Simulate real live engagement
    const commentTimer = setInterval(() => {
      const sampleNames = ['Tayo A.', 'Folake K.', 'Uche N.', 'Chinedu B.', 'Zainab M.'];
      const sampleTexts = [
        'How fast is shipping to Abuja?',
        'Does this come with official warranty?',
        'Just added to my cart!',
        'Can I pay with Flutterwave transfer?',
        'Very high quality!',
      ];
      const randomUser = sampleNames[Math.floor(Math.random() * sampleNames.length)];
      const randomText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
      setLiveComments((prev) => [...prev.slice(-6), { id: String(Date.now()), user: randomUser, text: randomText }]);
      setLiveViewers((v) => v + Math.floor(Math.random() * 5) - 1);
    }, 4000);

    return () => clearInterval(commentTimer);
  };

  const handleEndBroadcast = () => {
    stopCamera();
    setActiveView('menu');
    showToast('Broadcast concluded. Cloudflare Stream recording archived to your Seller Centre.');
    onClose();
  };

  const handlePostLiveComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!liveCommentInput.trim()) return;
    setLiveComments((prev) => [
      ...prev,
      { id: String(Date.now()), user: currentUser.name, text: liveCommentInput.trim() },
    ]);
    setLiveCommentInput('');
  };

  if (!isOpen) return null;

  const isSeller = currentUser.role === 'seller';
  const taggedProduct = products.find((p) => p.id === (activeView === 'go-live' || activeView === 'broadcasting' ? streamProductId : selectedProductId)) || products[0];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-t-3xl sm:rounded-3xl bg-white shadow-2xl max-h-[92vh] flex flex-col overflow-hidden text-slate-900 border border-slate-100">
        
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-orange-500/10 text-orange-600 font-black">
              <Sparkles size={18} />
            </div>
            <div>
              <h2 className="text-sm font-black text-slate-900">
                {activeView === 'menu' && (isSeller ? 'Create Content' : 'Become a Seller')}
                {activeView === 'upload-video' && 'Upload Product Video'}
                {activeView === 'go-live' && 'Cloudflare Live Setup'}
                {activeView === 'broadcasting' && 'Broadcasting Live Now'}
              </h2>
              <p className="text-[10px] text-slate-500">
                {isSeller ? 'Sell to thousands of shoppers across Nigeria' : 'Start selling on Cash N Carry Nigeria'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition"
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* VIEW 1: BUYER ONBOARDING (if user is buyer) */}
          {!isSeller && (
            <div className="space-y-6 py-2">
              <div className="rounded-2xl bg-gradient-to-br from-[#0c5c36] to-[#06331e] p-6 text-white text-center space-y-3 shadow-md">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-orange-400">
                  <Store size={28} />
                </div>
                <h3 className="text-lg font-black tracking-tight">Sell on Cash N Carry Nigeria</h3>
                <p className="text-xs text-emerald-100/90 leading-relaxed max-w-sm mx-auto">
                  Short video creation, product tagging, and live interactive broadcasting are reserved for verified Nigerian sellers.
                </p>
              </div>

              {/* Verified Seller Benefits */}
              <div className="space-y-3">
                <div className="text-xs font-black text-slate-800 uppercase tracking-wider">
                  Verified Merchant Benefits
                </div>
                <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-600">
                  <div className="flex items-start gap-2.5 rounded-xl border border-slate-100 bg-slate-50/70 p-3">
                    <CheckCircle2 size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-800">Zero Upfront Listing Fees:</span> Only pay 5% commission on successfully completed orders.
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5 rounded-xl border border-slate-100 bg-slate-50/70 p-3">
                    <CheckCircle2 size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-800">Instant Live Video & Short Clips:</span> Broadcast with Cloudflare Stream ultra-low latency WHIP/WHEP.
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5 rounded-xl border border-slate-100 bg-slate-50/70 p-3">
                    <CheckCircle2 size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-800">Flutterwave Escrow Protection:</span> Direct settlement to your Nigerian bank account with automated payouts.
                    </div>
                  </div>
                </div>
              </div>

              {/* CTA Buttons strictly matching specification */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={() => {
                    onClose();
                    onNavigate('seller-kyc');
                  }}
                  className="w-full flex items-center justify-center gap-2 rounded-2xl bg-orange-500 py-3.5 text-xs font-black text-white shadow-lg hover:bg-orange-600 transition"
                >
                  <Store size={16} />
                  <span>Become a Seller</span>
                  <ArrowRight size={15} />
                </button>

                <button
                  onClick={() => {
                    onClose();
                    onNavigate('policies');
                  }}
                  className="w-full rounded-2xl border border-slate-200 py-3 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
                >
                  Learn About Selling
                </button>

                <button
                  onClick={onClose}
                  className="w-full py-2.5 text-xs font-bold text-slate-400 hover:text-slate-600 transition"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* VIEW 2: SELLER CREATION MENU */}
          {isSeller && activeView === 'menu' && (
            <div className="space-y-4 py-2">
              <div className="text-xs font-black text-slate-500 uppercase tracking-wider">
                Select Creation Mode
              </div>

              {/* Option 1: Upload Short Video */}
              <button
                onClick={() => setActiveView('upload-video')}
                className="group flex w-full items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:border-[#0c5c36] hover:bg-emerald-50/40 hover:shadow-md"
              >
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-800 transition group-hover:scale-105 group-hover:bg-[#0c5c36] group-hover:text-white">
                  <Video size={26} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-slate-900">Upload Product Video</span>
                    <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[9px] font-black text-emerald-800">For You Feed</span>
                  </div>
                  <p className="mt-1 text-xs text-slate-500">
                    Publish a 15–60s vertical product showcase with buy-now tag and soundtrack.
                  </p>
                </div>
              </button>

              {/* Option 2: Go Live Stream */}
              <button
                onClick={() => {
                  setActiveView('go-live');
                  startCamera();
                }}
                className="group flex w-full items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:border-orange-500 hover:bg-orange-50/40 hover:shadow-md"
              >
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-orange-100 text-orange-600 transition group-hover:scale-105 group-hover:bg-orange-500 group-hover:text-white">
                  <Radio size={26} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-slate-900">Go Live Stream</span>
                    <span className="rounded-full bg-rose-500 px-2 py-0.5 text-[9px] font-black text-white animate-pulse">WHIP / WHEP</span>
                  </div>
                  <p className="mt-1 text-xs text-slate-500">
                    Host an interactive live commerce show with live orders and pinned products.
                  </p>
                </div>
              </button>

              {/* Option 3: Create Promotional Flash Deal */}
              <button
                onClick={() => {
                  onClose();
                  onNavigate('seller-products');
                }}
                className="group flex w-full items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:border-amber-500 hover:bg-amber-50/40 hover:shadow-md"
              >
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-amber-100 text-amber-700 transition group-hover:scale-105 group-hover:bg-amber-500 group-hover:text-white">
                  <Zap size={26} />
                </div>
                <div className="flex-1">
                  <span className="text-sm font-black text-slate-900">List New Product / Deal</span>
                  <p className="mt-1 text-xs text-slate-500">
                    Add new stock to your store catalog with multi-variant pricing.
                  </p>
                </div>
              </button>

              <div className="rounded-2xl bg-slate-50 p-4 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-800">Store:</span> {currentUser.storeName || currentUser.name}
                </div>
                <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700">
                  <ShieldCheck size={14} /> CAC Verified
                </span>
              </div>
            </div>
          )}

          {/* VIEW 3: UPLOAD SHORT VIDEO */}
          {isSeller && activeView === 'upload-video' && (
            <form onSubmit={handleUploadSubmit} className="space-y-4">
              {/* Video Sample Picker */}
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-700">Select Video Clip</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setVideoUrl('https://assets.mixkit.co/videos/preview/mixkit-young-man-dancing-while-listening-to-music-with-headphones-42171-large.mp4');
                      setPosterUrl('https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80');
                      setSelectedProductId('p1');
                    }}
                    className={`rounded-xl border p-2.5 text-left text-xs transition ${
                      videoUrl.includes('headphones') ? 'border-orange-500 bg-orange-50/50 font-bold' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    🎧 Wireless Headset
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setVideoUrl('https://assets.mixkit.co/videos/preview/mixkit-african-woman-in-traditional-dress-dancing-41551-large.mp4');
                      setPosterUrl('https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80');
                      setSelectedProductId('p5');
                    }}
                    className={`rounded-xl border p-2.5 text-left text-xs transition ${
                      videoUrl.includes('traditional') ? 'border-orange-500 bg-orange-50/50 font-bold' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    👗 Ankara Dress Drop
                  </button>
                </div>
              </div>

              {/* Caption */}
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-700">Video Caption & Hashtags</label>
                <textarea
                  value={videoCaption}
                  onChange={(e) => setVideoCaption(e.target.value)}
                  placeholder="e.g. Handmade Lagos Ankara Dress! Limited 14 pieces remaining in stock #LagosFashion #CashNCarry"
                  rows={3}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-xs outline-none focus:border-[#0c5c36] focus:bg-white"
                />
              </div>

              {/* Tag Product Dropdown */}
              <div className="space-y-1.5">
                <label className="flex items-center gap-1.5 text-xs font-black text-slate-700">
                  <Tag size={14} className="text-orange-500" />
                  <span>Tag Product from Your Catalog</span>
                </label>
                <select
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-xs font-semibold outline-none focus:border-[#0c5c36]"
                >
                  {sellerProducts.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} (₦{p.price.toLocaleString()}) – {p.stock} in stock
                    </option>
                  ))}
                </select>
              </div>

              {/* Soundtrack */}
              <div className="space-y-1.5">
                <label className="flex items-center gap-1.5 text-xs font-black text-slate-700">
                  <Music size={14} className="text-emerald-700" />
                  <span>Soundtrack / Audio Title</span>
                </label>
                <input
                  type="text"
                  value={soundTitle}
                  onChange={(e) => setSoundTitle(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-xs font-semibold outline-none focus:border-[#0c5c36]"
                />
              </div>

              {/* Upload Progress Bar if uploading */}
              {isUploading && (
                <div className="space-y-1.5 rounded-2xl bg-emerald-50 p-4 border border-emerald-200">
                  <div className="flex justify-between text-xs font-bold text-emerald-900">
                    <span>Publishing to Cloudflare R2 & Video Stream...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-emerald-200 overflow-hidden">
                    <div
                      className="h-full bg-[#0c5c36] transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveView('menu')}
                  className="flex-1 rounded-2xl border border-slate-200 py-3 text-xs font-bold text-slate-600 hover:bg-slate-50"
                  disabled={isUploading}
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isUploading}
                  className="flex-1 flex items-center justify-center gap-2 rounded-2xl bg-[#0c5c36] py-3 text-xs font-black text-white hover:bg-emerald-900 shadow-md transition"
                >
                  <Upload size={16} />
                  <span>{isUploading ? 'Publishing...' : 'Publish to Feed'}</span>
                </button>
              </div>
            </form>
          )}

          {/* VIEW 4: GO LIVE CAMERA PREPARATION */}
          {isSeller && activeView === 'go-live' && (
            <div className="space-y-4">
              {/* WebRTC Camera / Stream Preview Box */}
              <div className="relative aspect-[9/12] w-full rounded-3xl bg-slate-900 overflow-hidden shadow-inner flex items-center justify-center">
                {cameraActive ? (
                  <video
                    ref={videoPreviewRef}
                    autoPlay
                    playsInline
                    muted
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="text-center p-6 space-y-3 text-white">
                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10 text-orange-400">
                      <Camera size={28} />
                    </div>
                    <div className="text-xs font-bold">WebRTC Camera Preview Ready</div>
                    <p className="text-[11px] text-slate-400 max-w-xs">
                      Connecting your device camera and microphone for live Cloudflare Stream broadcasting.
                    </p>
                    <button
                      type="button"
                      onClick={startCamera}
                      className="rounded-full bg-orange-500 px-4 py-2 text-xs font-black text-white shadow"
                    >
                      Enable Camera
                    </button>
                  </div>
                )}

                {/* Overlay Controls */}
                <div className="absolute top-3 inset-x-3 flex items-center justify-between text-xs text-white">
                  <span className="flex items-center gap-1.5 rounded-full bg-black/60 px-3 py-1 font-bold backdrop-blur-md">
                    <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse" />
                    Cloudflare WHIP Ready
                  </span>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={toggleCameraFacing}
                      className="rounded-full bg-black/60 p-2 backdrop-blur-md hover:bg-black/80"
                      title="Flip camera"
                    >
                      <RotateCcw size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={toggleMic}
                      className="rounded-full bg-black/60 p-2 backdrop-blur-md hover:bg-black/80"
                      title="Toggle mic"
                    >
                      {micMuted ? <MicOff size={16} className="text-rose-400" /> : <Mic size={16} />}
                    </button>
                  </div>
                </div>

                {/* Pinned Product Preview */}
                <div className="absolute bottom-3 inset-x-3 rounded-2xl bg-black/75 p-3 backdrop-blur-md text-white flex items-center gap-3">
                  <img
                    src={taggedProduct.image}
                    alt={taggedProduct.title}
                    className="h-10 w-10 rounded-xl object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="text-[10px] font-bold text-orange-400 uppercase">Pinned Live Item</div>
                    <div className="text-xs font-bold truncate">{taggedProduct.title}</div>
                    <div className="text-xs font-black text-white">₦{taggedProduct.price.toLocaleString()}</div>
                  </div>
                </div>
              </div>

              {/* Title Input */}
              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700">Livestream Show Title</label>
                <input
                  type="text"
                  value={streamTitle}
                  onChange={(e) => setStreamTitle(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-xs font-semibold outline-none focus:border-[#0c5c36]"
                />
              </div>

              {/* Tagged Product Selector */}
              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700">Featured Showcase Product</label>
                <select
                  value={streamProductId}
                  onChange={(e) => setStreamProductId(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-3 text-xs font-semibold outline-none focus:border-[#0c5c36]"
                >
                  {sellerProducts.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} (₦{p.price.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              {/* Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setActiveView('menu');
                  }}
                  className="flex-1 rounded-2xl border border-slate-200 py-3 text-xs font-bold text-slate-600 hover:bg-slate-50"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleStartBroadcast}
                  className="flex-1 flex items-center justify-center gap-2 rounded-2xl bg-rose-600 py-3 text-xs font-black text-white hover:bg-rose-700 shadow-lg shadow-rose-600/20 transition"
                >
                  <Radio size={16} />
                  <span>Start Live Broadcast</span>
                </button>
              </div>
            </div>
          )}

          {/* VIEW 5: BROADCASTING ACTIVE */}
          {isSeller && activeView === 'broadcasting' && (
            <div className="space-y-4">
              <div className="relative aspect-[9/13] w-full rounded-3xl bg-slate-950 overflow-hidden shadow-2xl flex flex-col justify-between p-4 text-white">
                {/* Background Camera */}
                {cameraActive && (
                  <video
                    ref={videoPreviewRef}
                    autoPlay
                    playsInline
                    muted
                    className="absolute inset-0 h-full w-full object-cover opacity-90"
                  />
                )}

                {/* Top Info Bar */}
                <div className="relative z-10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1.5 rounded-full bg-rose-600 px-3 py-1 text-xs font-black text-white shadow animate-pulse">
                      <span className="h-2 w-2 rounded-full bg-white" />
                      LIVE
                    </span>
                    <span className="flex items-center gap-1 rounded-full bg-black/60 px-2.5 py-1 text-xs font-bold backdrop-blur-md">
                      <Eye size={13} className="text-emerald-400" />
                      <span>{liveViewers}</span>
                    </span>
                  </div>

                  <button
                    onClick={handleEndBroadcast}
                    className="rounded-full bg-rose-600/90 px-3 py-1 text-xs font-black text-white hover:bg-rose-700 transition"
                  >
                    End Stream
                  </button>
                </div>

                {/* Middle: Live Comments Stream */}
                <div className="relative z-10 space-y-1.5 max-h-48 overflow-y-auto pr-2 mt-auto mb-3">
                  {liveComments.map((c) => (
                    <div key={c.id} className="flex items-start gap-2 rounded-xl bg-black/50 px-3 py-1.5 text-xs backdrop-blur-md w-fit max-w-[85%]">
                      <span className="font-black text-amber-300 shrink-0">{c.user}:</span>
                      <span className="text-white font-medium">{c.text}</span>
                    </div>
                  ))}
                </div>

                {/* Pinned Product Card */}
                <div className="relative z-10 rounded-2xl bg-white/95 p-3 text-slate-900 shadow-lg flex items-center gap-3">
                  <img
                    src={taggedProduct.image}
                    alt={taggedProduct.title}
                    className="h-11 w-11 rounded-xl object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="text-[10px] font-black text-emerald-700 uppercase">Live Deal #1</div>
                    <div className="text-xs font-bold truncate">{taggedProduct.title}</div>
                    <div className="text-xs font-black text-slate-900">₦{taggedProduct.price.toLocaleString()}</div>
                  </div>
                  <div className="rounded-xl bg-orange-500 px-3 py-1.5 text-[10px] font-black text-white">
                    Tag Active
                  </div>
                </div>

                {/* Chat Input */}
                <form onSubmit={handlePostLiveComment} className="relative z-10 mt-2 flex gap-2">
                  <input
                    type="text"
                    value={liveCommentInput}
                    onChange={(e) => setLiveCommentInput(e.target.value)}
                    placeholder="Type an announcement to viewers..."
                    className="flex-1 rounded-xl bg-black/60 px-3 py-2 text-xs text-white placeholder-slate-400 outline-none backdrop-blur-md focus:ring-1 focus:ring-orange-400"
                  />
                  <button
                    type="submit"
                    className="rounded-xl bg-orange-500 px-3 py-2 text-xs font-black text-white"
                  >
                    Send
                  </button>
                </form>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
