import React, { useState } from 'react';
import { X, Lock, Mail, CheckCircle2, ShieldCheck, KeyRound, ArrowRight } from 'lucide-react';
import BrandLogo from './BrandLogo';
import { api } from '../../lib/api';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  onAuthenticated: () => void;
}

type AuthTab = 'login' | 'register' | 'verify' | 'reset';

export default function AuthModal({ open, onClose, onAuthenticated }: AuthModalProps) {
  const [tab, setTab] = useState<AuthTab>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState('');
  const [role, setRole] = useState<'buyer' | 'seller'>('buyer');
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setFeedback(null);
    setErrorMsg(null);
    try {
      if (tab === 'login') {
        const res = await api.login(email, password);
        if (res.signedIn) {
          onAuthenticated();
          onClose();
        } else {
          setErrorMsg(res.error || 'Sign-in failed. Check your email and password.');
        }
      } else if (tab === 'register') {
        const res = await api.register(email);
        if (res.accepted) {
          setFeedback('Verification link/token sent if the account is eligible. Complete verification in the Verify tab.');
          setTab('verify');
        } else {
          setErrorMsg(res.error || 'Unable to register account.');
        }
      } else if (tab === 'verify') {
        const res = await api.verifyAccount(token, password, role);
        if (res.completed) {
          setFeedback('Account verified! You can now sign in with your password.');
          setTab('login');
        } else {
          setErrorMsg(res.error || 'Invalid or expired verification token.');
        }
      } else if (tab === 'reset') {
        const res = await api.requestPasswordReset(email);
        if (res.accepted) {
          setFeedback('If an eligible verified account exists, a password reset email has been queued.');
        } else {
          setErrorMsg(res.error || 'Unable to process reset request.');
        }
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close sign in dialog"
          className="absolute right-4 top-4 rounded-full p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
        >
          <X size={18} />
        </button>

        {/* Emerald Header synced with Android AuthComponents */}
        <div className="bg-gradient-to-br from-[#084B26] via-[#0E6B38] to-[#093B22] px-6 py-6 text-white">
          <div className="flex items-center gap-3">
            <div className="rounded-2xl bg-white p-1.5 shadow">
              <BrandLogo className="h-9 w-9" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight">Cash N Carry Nigeria</h2>
              <p className="text-xs text-emerald-100/90">
                Unified account synced across Mobile App &amp; Web
              </p>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-1 rounded-2xl bg-black/25 p-1 text-xs font-bold">
            <button
              type="button"
              onClick={() => setTab('login')}
              className={`rounded-xl py-2 transition ${tab === 'login' ? 'bg-white text-[#0E6B38] shadow' : 'text-emerald-100'}`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => setTab('register')}
              className={`rounded-xl py-2 transition ${tab === 'register' || tab === 'verify' ? 'bg-white text-[#0E6B38] shadow' : 'text-emerald-100'}`}
            >
              Create Account
            </button>
            <button
              type="button"
              onClick={() => setTab('reset')}
              className={`rounded-xl py-2 transition ${tab === 'reset' ? 'bg-white text-[#0E6B38] shadow' : 'text-emerald-100'}`}
            >
              Recovery
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 p-6">
          {feedback && (
            <div className="flex items-start gap-2 rounded-2xl border border-emerald-200 bg-[#EAF7EF] p-3 text-xs font-semibold text-[#084B26]">
              <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-[#0E6B38]" />
              <span>{feedback}</span>
            </div>
          )}
          {errorMsg && (
            <div className="rounded-2xl border border-rose-200 bg-rose-50 p-3 text-xs font-semibold text-rose-700">
              {errorMsg}
            </div>
          )}

          {tab !== 'verify' && (
            <div>
              <label className="text-xs font-bold text-slate-700">Email address</label>
              <div className="relative mt-1">
                <Mail size={15} className="absolute left-3.5 top-3.5 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="h-11 w-full rounded-xl border border-slate-200 pl-10 pr-3 text-sm outline-none focus:border-[#0E6B38]"
                />
              </div>
            </div>
          )}

          {tab === 'verify' && (
            <>
              <div>
                <label className="text-xs font-bold text-slate-700">64-character Verification Token</label>
                <div className="relative mt-1">
                  <KeyRound size={15} className="absolute left-3.5 top-3.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    placeholder="Paste verification token from email"
                    className="h-11 w-full rounded-xl border border-slate-200 pl-10 pr-3 text-xs font-mono outline-none focus:border-[#0E6B38]"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700">Account Type</label>
                <div className="mt-1 grid grid-cols-2 gap-2">
                  {(['buyer', 'seller'] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      className={`h-10 rounded-xl border text-xs font-black capitalize transition ${
                        role === r ? 'border-[#0E6B38] bg-[#EAF7EF] text-[#0E6B38]' : 'border-slate-200 text-slate-600'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {(tab === 'login' || tab === 'verify') && (
            <div>
              <label className="text-xs font-bold text-slate-700">Password (min 12 characters)</label>
              <div className="relative mt-1">
                <Lock size={15} className="absolute left-3.5 top-3.5 text-slate-400" />
                <input
                  type="password"
                  required
                  minLength={12}
                  maxLength={128}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 12 characters"
                  className="h-11 w-full rounded-xl border border-slate-200 pl-10 pr-3 text-sm outline-none focus:border-[#0E6B38]"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-[#0E6B38] text-sm font-black text-white shadow-md transition hover:bg-[#084B26] disabled:opacity-50"
          >
            <span>
              {loading
                ? 'Connecting...'
                : tab === 'login'
                ? 'Sign In to Cash N Carry'
                : tab === 'register'
                ? 'Request Verification Token'
                : tab === 'verify'
                ? 'Complete Verification & Set Password'
                : 'Send Reset Link'}
            </span>
            <ArrowRight size={15} />
          </button>

          <div className="flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2 text-[11px] text-slate-500">
            <ShieldCheck size={14} className="shrink-0 text-[#0E6B38]" />
            <span>
              Protected by scrypt hashing &amp; HttpOnly session cookies on web, and Bearer tokens on mobile.
            </span>
          </div>
        </form>
      </div>
    </div>
  );
}
