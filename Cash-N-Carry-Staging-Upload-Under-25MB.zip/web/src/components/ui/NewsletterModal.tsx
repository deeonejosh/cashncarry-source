import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { X, Mail, CheckCircle2, Gift, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';

interface NewsletterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenEmailPreview?: () => void;
}

export default function NewsletterModal({ isOpen, onClose, onOpenEmailPreview }: NewsletterModalProps) {
  const { subscribeToNewsletter, currentUser } = useStore();
  const [email, setEmail] = useState(currentUser.email || '');
  const [name, setName] = useState(currentUser.name || '');
  const [preferences, setPreferences] = useState<string[]>([
    'flash-deals',
    'livestreams',
    'tech',
    'fashion',
  ]);
  const [submittedVoucher, setSubmittedVoucher] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const togglePref = (id: string) => {
    setPreferences((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = subscribeToNewsletter(email, {
      name: name.trim() || undefined,
      preferences,
      source: 'modal',
    });

    if (res.success) {
      setSubmittedVoucher(res.voucherCode || 'WELCOME2500');
    }
  };

  const copyVoucher = () => {
    if (submittedVoucher) {
      navigator.clipboard.writeText(submittedVoucher);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Banner */}
        <div className="relative bg-gradient-to-br from-[#0c5c36] via-[#09472a] to-[#042415] p-6 text-white sm:p-8">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 rounded-full p-2 text-white/70 hover:bg-white/10 hover:text-white transition"
            aria-label="Close"
          >
            <X size={20} />
          </button>

          <div className="inline-flex items-center gap-1.5 rounded-full bg-orange-500/20 px-3 py-1 text-[11px] font-black text-orange-300 border border-orange-400/30">
            <Gift size={13} />
            <span>EXCLUSIVELY FOR NIGERIAN SHOPPERS</span>
          </div>

          <h2 className="mt-3 text-2xl font-black tracking-tight sm:text-3xl leading-snug">
            Claim ₦2,500 Off Your First Order
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
            Subscribe to Cash N Carry newsletters for daily flash sales, live creator streams, and exclusive voucher codes.
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8">
          {submittedVoucher ? (
            /* Success State */
            <div className="space-y-5 text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-100 text-[#0c5c36]">
                <CheckCircle2 size={32} />
              </div>

              <div>
                <h3 className="text-lg font-black text-slate-900">
                  You’re Subscribed to Cash N Carry!
                </h3>
                <p className="mt-1 text-xs text-slate-500">
                  We sent a welcome confirmation to <b className="text-slate-800">{email}</b>.
                </p>
              </div>

              {/* Voucher Box */}
              <div className="rounded-2xl border-2 border-dashed border-orange-500 bg-orange-50 p-4 text-center">
                <span className="text-[10px] font-black uppercase tracking-wider text-orange-800">
                  Your First-Order Promo Code
                </span>
                <div className="my-1.5 font-mono text-2xl font-black tracking-wider text-orange-600">
                  {submittedVoucher}
                </div>
                <div className="text-[11px] text-orange-950">
                  Valid for ₦2,500 OFF on orders above ₦10,000 across all verified Nigerian stores.
                </div>
                <button
                  onClick={copyVoucher}
                  className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-orange-600 px-4 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-orange-700 transition"
                >
                  {copied ? 'Copied to Clipboard! ✓' : 'Copy Voucher Code'}
                </button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                {onOpenEmailPreview && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenEmailPreview();
                    }}
                    className="w-full sm:w-auto rounded-xl border border-[#0c5c36] bg-emerald-50 px-4 py-2.5 text-xs font-black text-[#0c5c36] hover:bg-emerald-100 transition"
                  >
                    View Welcome Email Template
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="w-full sm:w-auto rounded-xl bg-[#0c5c36] px-6 py-2.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow"
                >
                  Start Shopping Now
                </button>
              </div>
            </div>
          ) : (
            /* Subscription Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700">
                  Email Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative mt-1">
                  <Mail
                    size={16}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. yourname@gmail.com"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 outline-none focus:border-[#0c5c36] focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700">
                  Full Name <span className="text-slate-400 font-normal">(Optional for personalization)</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Temidayo Ogundiya"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 outline-none focus:border-[#0c5c36] focus:bg-white"
                />
              </div>

              {/* Preferences Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  What deals would you like to receive?
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'flash-deals', label: '⚡ Daily Flash Deals' },
                    { id: 'livestreams', label: '🎬 Live Shopping Drops' },
                    { id: 'tech', label: '📱 Tech & Electronics' },
                    { id: 'fashion', label: '👗 Fashion & Ankara' },
                  ].map((item) => {
                    const active = preferences.includes(item.id);
                    return (
                      <button
                        type="button"
                        key={item.id}
                        onClick={() => togglePref(item.id)}
                        className={`flex items-center justify-between rounded-xl border p-2.5 text-xs font-bold transition text-left ${
                          active
                            ? 'border-[#0c5c36] bg-emerald-50/60 text-[#0c5c36]'
                            : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span>{item.label}</span>
                        <span
                          className={`h-4 w-4 rounded-md border flex items-center justify-center text-[10px] ${
                            active
                              ? 'border-[#0c5c36] bg-[#0c5c36] text-white'
                              : 'border-slate-300 bg-white'
                          }`}
                        >
                          {active && '✓'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#0c5c36] py-3 text-xs font-black text-white shadow-md hover:bg-emerald-900 transition"
                >
                  <span>Subscribe & Unlock ₦2,500 Voucher</span>
                  <ArrowRight size={15} />
                </button>
              </div>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
                <ShieldCheck size={13} className="text-emerald-700" />
                <span>Zero spam. NDPR compliant. Unsubscribe anytime with 1 click.</span>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
