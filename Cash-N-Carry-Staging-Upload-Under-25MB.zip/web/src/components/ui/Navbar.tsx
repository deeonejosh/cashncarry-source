import React, { useState } from 'react';
import BrandLogo from './BrandLogo';
import { useStore } from '../../context/StoreContext';
import { NIGERIAN_STATES } from '../../lib/design-tokens';
import {
  Search,
  ShoppingBag,
  Heart,
  Bell,
  User,
  ChevronDown,
  Sparkles,
  Radio,
  Gavel,
  Zap,
  Store,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  Menu,
  X,
  Package,
  Layers,
  Coins,
  Download,
  PlaySquare,
  Mail,
  MapPin,
  LogIn,
  LogOut,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  selectedCategory?: string;
  onSelectCategory?: (category: string) => void;
  onOpenQA: () => void;
  onOpenExport: () => void;
}

export default function Navbar({
  currentTab,
  setCurrentTab,
  selectedCategory,
  onSelectCategory,
  onOpenQA,
  onOpenExport,
}: NavbarProps) {
  const {
    currentUser,
    cartCount,
    cartSubtotal,
    wishlist,
    notifications,
    setCartDrawerOpen,
    coinBalance,
    selectedState,
    setSelectedState,
    isAuthenticatedSession,
    setAuthModalOpen,
    signOutAccount,
  } = useStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const unreadNotifs = notifications.filter((n) => !n.read).length;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setCurrentTab('shop');
    }
  };

  const navCategories = [
    { id: 'fashion', label: 'Fashion & Ankara' },
    { id: 'tech', label: 'Tech & Electronics' },
    { id: 'beauty', label: 'Beauty & Skincare' },
    { id: 'food', label: 'Food & Groceries' },
    { id: 'home', label: 'Home & Kitchen' },
  ];

  return (
    <header className={`sticky top-0 z-40 w-full border-b border-slate-200 bg-white/95 backdrop-blur-md ${currentTab === 'for-you' ? 'hidden' : ''}`}>
      {/* Top Utility Staging Bar */}
      <div className="bg-[#073c22] px-3 sm:px-4 py-1.5 text-xs text-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-1.5">
          <div className="flex items-center gap-2 min-w-0">
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-300 truncate">
              <span className="h-2 w-2 shrink-0 animate-pulse rounded-full bg-emerald-400" />
              <span className="sm:hidden">Staging V17 (Cloudflare D1)</span>
              <span className="hidden sm:inline">Staging V17 (Cloudflare Workers &amp; D1)</span>
            </span>
            <span className="hidden text-[11px] text-emerald-200/80 md:inline">
              Private staging · Currency: <b>NGN (₦)</b> · Payments Disabled
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Nigerian State Delivery Selector Pill (synchronized with Android State selector) */}
            <label className="hidden lg:inline-flex items-center gap-1 rounded-full bg-white/10 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-100">
              <MapPin size={11} className="text-orange-300" />
              <span>Deliver to:</span>
              <select
                aria-label="Select delivery state"
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="bg-transparent font-black text-white outline-none cursor-pointer"
              >
                {NIGERIAN_STATES.map((st) => (
                  <option key={st} value={st} className="bg-[#073c22] text-white">
                    {st}
                  </option>
                ))}
              </select>
            </label>
            {!isAuthenticatedSession && (
              <button
                type="button"
                onClick={() => setAuthModalOpen(true)}
                className="flex items-center gap-1 rounded-full bg-[#FF6B00] px-2.5 py-0.5 text-[11px] font-black text-white hover:bg-orange-500 transition"
              >
                <LogIn size={11} />
                <span>Sign In</span>
              </button>
            )}
            {/* Authenticated Identity Badge (Zero Demo Role Switching) */}
            <div className="flex items-center gap-1.5 bg-black/30 px-2 py-0.5 rounded-full text-[11px]">
              <span className="hidden sm:inline text-emerald-300 font-medium">Active:</span>
              <span className="font-bold text-white truncate max-w-[100px] sm:max-w-none">{currentUser.name}</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] uppercase font-black ${
                currentUser.role === 'admin' ? 'bg-purple-600 text-white' :
                currentUser.role === 'seller' ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-200'
              }`}>
                {currentUser.role}
              </span>
            </div>

            <button
              onClick={onOpenQA}
              className="flex items-center gap-1 rounded bg-emerald-600/60 px-2 py-0.5 text-[11px] font-bold text-white hover:bg-emerald-600 transition"
              title="Run Automated Staging Diagnostic"
            >
              <CheckCircle2 size={13} className="text-emerald-300" />
              QA Suite
            </button>

            <button
              onClick={onOpenExport}
              className="flex items-center gap-1 rounded bg-orange-600 px-2 py-0.5 text-[11px] font-bold text-white hover:bg-orange-500 transition"
              title="Download Repaired V17 Staging Source ZIP"
            >
              <Download size={13} />
              Export ZIP
            </button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 md:px-8">
        {/* Brand Logo */}
        <button
          onClick={() => {
            setCurrentTab('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-2 shrink-0 text-left"
        >
          <BrandLogo />
        </button>

        {/* Category Menu Button */}
        <div className="relative hidden lg:block">
          <button
            onClick={() => setCategoryDropdownOpen(!categoryDropdownOpen)}
            className="flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 transition"
          >
            Categories <ChevronDown size={14} className={`transition-transform ${categoryDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {categoryDropdownOpen && (
            <div className="absolute left-0 top-full mt-2 w-56 rounded-2xl border border-slate-100 bg-white p-2 shadow-xl z-50">
              {navCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    onSelectCategory?.(cat.id);
                    setCurrentTab('shop');
                    setCategoryDropdownOpen(false);
                  }}
                  className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 transition"
                >
                  {cat.label}
                  <ChevronDown size={12} className="-rotate-90 text-slate-400" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} className="relative hidden flex-1 max-w-xl md:block">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search verified Nigerian sellers, tech, ankara, beauty..."
            className="h-11 w-full rounded-full border border-slate-200 bg-slate-50 pl-11 pr-24 text-sm text-slate-900 outline-none transition focus:border-emerald-600 focus:bg-white focus:ring-4 focus:ring-emerald-600/10"
          />
          <button
            type="submit"
            className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-full bg-[#0c5c36] px-4 py-1.5 text-xs font-bold text-white hover:bg-emerald-900 transition"
          >
            Search
          </button>
        </form>

        {/* Desktop Quick Actions */}
        <div className="hidden items-center gap-2 sm:flex">
          {/* Coins balance badge */}
          <button
            onClick={() => setCurrentTab('coins')}
            className="flex items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-3 py-1.5 text-xs font-extrabold text-amber-900 hover:bg-amber-100 transition"
            title="Gifting & Promotional Test Coins"
          >
            <Coins size={14} className="text-amber-600" />
            <span>{coinBalance.toLocaleString()}</span>
          </button>

          {/* Wishlist */}
          <button
            onClick={() => setCurrentTab('wishlist')}
            className="relative rounded-full p-2.5 text-slate-700 hover:bg-slate-100 transition"
            aria-label="Wishlist"
            title="Saved items"
          >
            <Heart size={20} className={wishlist.length > 0 ? 'fill-rose-500 text-rose-500' : ''} />
            {wishlist.length > 0 && (
              <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-black text-white">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Notifications */}
          <button
            onClick={() => setCurrentTab('notifications')}
            className="relative rounded-full p-2.5 text-slate-700 hover:bg-slate-100 transition"
            aria-label="Notifications"
            title="Notifications"
          >
            <Bell size={20} />
            {unreadNotifs > 0 && (
              <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-orange-500 text-[10px] font-black text-white">
                {unreadNotifs}
              </span>
            )}
          </button>

          {/* Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
              className="flex items-center gap-2 rounded-full p-1.5 hover:bg-slate-100 transition border border-transparent hover:border-slate-200"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="h-8 w-8 rounded-full object-cover border border-emerald-700"
              />
              <span className="hidden xl:block text-xs font-bold text-slate-800">{currentUser.name.split(' ')[0]}</span>
              <ChevronDown size={14} className="text-slate-500" />
            </button>

            {profileDropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-56 rounded-2xl border border-slate-100 bg-white p-2 shadow-2xl z-50">
                <div className="px-3 py-2 border-b border-slate-100">
                  <div className="text-xs font-black text-slate-900">{currentUser.name}</div>
                  <div className="text-[11px] text-slate-500 truncate">{currentUser.email}</div>
                  <div className="mt-1 inline-block rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                    {currentUser.role}
                  </div>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => {
                      setCurrentTab('profile');
                      setProfileDropdownOpen(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    <User size={15} /> My Profile & Addresses
                  </button>
                  <button
                    onClick={() => {
                      setCurrentTab('orders');
                      setProfileDropdownOpen(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    <Package size={15} /> Order History & Tracking
                  </button>
                  <button
                    onClick={() => {
                      setCurrentTab('messages');
                      setProfileDropdownOpen(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    <Layers size={15} /> Messages & Support
                  </button>
                  <button
                    onClick={() => {
                      setCurrentTab('email-marketing');
                      setProfileDropdownOpen(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    <Mail size={15} /> Email Marketing & Newsletters
                  </button>

                  {/* Seller Links */}
                  <div className="border-t border-slate-100 my-1 pt-1">
                    {currentUser.role === 'seller' ? (
                      <button
                        onClick={() => {
                          setCurrentTab('seller-dashboard');
                          setProfileDropdownOpen(false);
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-emerald-800 hover:bg-emerald-50"
                      >
                        <Store size={15} /> Seller Centre Portal
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          setCurrentTab('seller-kyc');
                          setProfileDropdownOpen(false);
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-emerald-800 hover:bg-emerald-50"
                      >
                        <Store size={15} /> Become a Seller (CAC Registration)
                      </button>
                    )}
                  </div>

                  <div className="border-t border-slate-100 my-1 pt-1">
                    {isAuthenticatedSession ? (
                      <button
                        onClick={() => {
                          signOutAccount();
                          setProfileDropdownOpen(false);
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-rose-700 hover:bg-rose-50"
                      >
                        <LogOut size={15} /> Sign Out
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          setAuthModalOpen(true);
                          setProfileDropdownOpen(false);
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-[#0E6B38] hover:bg-emerald-50"
                      >
                        <LogIn size={15} /> Sign In / Create Account
                      </button>
                    )}
                  </div>
                  {/* Admin Links - Accessible strictly to authenticated admins */}
                  {currentUser.role === 'admin' && (
                    <div className="border-t border-slate-100 my-1 pt-1">
                      <button
                        onClick={() => {
                          setCurrentTab('admin-dashboard');
                          setProfileDropdownOpen(false);
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-purple-800 hover:bg-purple-50"
                      >
                        <ShieldCheck size={15} /> Admin Console
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Cart Pill */}
          <button
            onClick={() => setCartDrawerOpen(true)}
            className="flex items-center gap-2 rounded-full bg-[#0c5c36] px-4 py-2.5 text-xs font-black text-white shadow-sm transition hover:bg-emerald-900 hover:shadow"
          >
            <ShoppingBag size={16} />
            <span>Cart</span>
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-orange-500 text-[10px] text-white">
              {cartCount}
            </span>
          </button>
        </div>

        {/* Mobile Hamburger */}
        <div className="flex items-center gap-2 sm:hidden">
          <button
            onClick={() => setCartDrawerOpen(true)}
            className="relative rounded-full p-2 text-slate-700 hover:bg-slate-100"
          >
            <ShoppingBag size={22} />
            {cartCount > 0 && (
              <span className="absolute right-0 top-0 flex h-4 w-4 items-center justify-center rounded-full bg-orange-500 text-[10px] font-black text-white">
                {cartCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="rounded-xl p-2 text-slate-700 hover:bg-slate-100"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Secondary Category & Feature Navigation Bar */}
      <nav className="mx-auto hidden max-w-7xl items-center gap-5 px-8 pb-3 text-xs font-bold text-slate-700 md:flex overflow-x-auto">
        <button
          onClick={() => setCurrentTab('shop')}
          className={`whitespace-nowrap transition ${
            currentTab === 'shop' || currentTab === 'home'
              ? 'text-[#0c5c36] font-extrabold border-b-2 border-[#0c5c36] pb-1'
              : 'hover:text-[#0c5c36]'
          }`}
        >
          Shop
        </button>

        <button
          onClick={() => setCurrentTab('for-you')}
          className={`flex items-center gap-1.5 whitespace-nowrap transition ${
            currentTab === 'for-you'
              ? 'text-[#0c5c36] font-extrabold border-b-2 border-[#0c5c36] pb-1'
              : 'hover:text-[#0c5c36]'
          }`}
        >
          <PlaySquare size={14} className="text-orange-500" />
          For You
        </button>

        <button
          onClick={() => setCurrentTab('live')}
          className={`flex items-center gap-1.5 whitespace-nowrap transition ${
            currentTab === 'live'
              ? 'text-rose-600 font-extrabold border-b-2 border-rose-600 pb-1'
              : 'hover:text-rose-600'
          }`}
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
          </span>
          Livestreams <span className="rounded-full bg-rose-600 px-1.5 py-0.2 text-[9px] font-black text-white">Live</span>
        </button>

        <button
          onClick={() => setCurrentTab('flash-deals')}
          className={`flex items-center gap-1.5 whitespace-nowrap transition ${
            currentTab === 'flash-deals'
              ? 'text-orange-600 font-extrabold border-b-2 border-orange-600 pb-1'
              : 'hover:text-orange-600'
          }`}
        >
          <Zap size={14} className="text-orange-500" />
          Flash Deals
        </button>

        <button
          onClick={() => setCurrentTab('auctions')}
          className={`flex items-center gap-1.5 whitespace-nowrap transition ${
            currentTab === 'auctions'
              ? 'text-amber-700 font-extrabold border-b-2 border-amber-700 pb-1'
              : 'hover:text-amber-700'
          }`}
        >
          <Gavel size={14} className="text-amber-600" />
          Auctions
        </button>

        <button
          onClick={() => {
            setCurrentTab('seller-kyc');
          }}
          className="whitespace-nowrap transition hover:text-orange-600"
        >
          Become a Seller
        </button>

        <div className="ml-auto flex items-center gap-2">
          {/* Seller Centre Pill */}
          <button
            onClick={() => {
              if (currentUser.role === 'seller') {
                setCurrentTab('seller-dashboard');
              } else {
                setCurrentTab('seller-kyc');
              }
            }}
            className="flex items-center gap-1.5 rounded-full bg-orange-500 px-3.5 py-1.5 text-xs font-black text-white hover:bg-orange-600 shadow-sm transition"
          >
            <Store size={13} />
            <span>{currentUser.role === 'seller' ? 'Seller Centre' : 'Start Selling'}</span>
          </button>

          {/* Admin Console Pill - Strictly gated */}
          {currentUser.role === 'admin' ? (
            <button
              onClick={() => {
                setCurrentTab('admin-dashboard');
              }}
              className="flex items-center gap-1.5 rounded-full bg-[#073c22] border border-emerald-500/30 px-3.5 py-1.5 text-xs font-black text-white hover:bg-emerald-950 transition"
            >
              <ShieldCheck size={13} className="text-emerald-400" />
              <span>Admin Console</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setCurrentTab('policies');
              }}
              className="flex items-center gap-1.5 rounded-full bg-slate-100 border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-200 transition"
            >
              <ShieldCheck size={13} className="text-slate-500" />
              <span>Policies & Trust</span>
            </button>
          )}
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="border-t border-slate-200 bg-white p-4 sm:hidden">
          <form onSubmit={handleSearchSubmit} className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products & stores..."
              className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-16 text-xs outline-none focus:border-emerald-600"
            />
            <button
              type="submit"
              className="absolute right-1 top-1/2 -translate-y-1/2 rounded-lg bg-[#0c5c36] px-3 py-1 text-[11px] font-bold text-white"
            >
              Search
            </button>
          </form>

          <div className="grid grid-cols-2 gap-2 text-xs font-bold text-slate-800">
            <button
              onClick={() => { setCurrentTab('home'); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 rounded-xl bg-slate-50 p-2.5 text-left hover:bg-emerald-50"
            >
              <Sparkles size={16} className="text-amber-500" /> For You
            </button>
            <button
              onClick={() => { setCurrentTab('shop'); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 rounded-xl bg-slate-50 p-2.5 text-left hover:bg-emerald-50"
            >
              <ShoppingBag size={16} className="text-emerald-700" /> Shop Catalog
            </button>
            <button
              onClick={() => { setCurrentTab('live'); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 rounded-xl bg-rose-50 p-2.5 text-left text-rose-700"
            >
              <Radio size={16} /> Live Shopping
            </button>
            <button
              onClick={() => { setCurrentTab('auctions'); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 rounded-xl bg-amber-50 p-2.5 text-left text-amber-800"
            >
              <Gavel size={16} /> Auctions
            </button>
            <button
              onClick={() => { setCurrentTab('orders'); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 rounded-xl bg-slate-50 p-2.5 text-left hover:bg-emerald-50"
            >
              <Package size={16} /> My Orders
            </button>
            <button
              onClick={() => { setCurrentTab('profile'); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 rounded-xl bg-slate-50 p-2.5 text-left hover:bg-emerald-50"
            >
              <User size={16} /> Profile & Addr
            </button>
            <button
              onClick={() => {
                if (currentUser.role === 'seller') {
                  setCurrentTab('seller-dashboard');
                } else {
                  setCurrentTab('seller-kyc');
                }
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 rounded-xl bg-emerald-50 p-2.5 text-left text-emerald-800 font-black"
            >
              <Store size={16} /> {currentUser.role === 'seller' ? 'Seller Centre' : 'Become a Seller'}
            </button>
            {currentUser.role === 'admin' && (
              <button
                onClick={() => { setCurrentTab('admin-dashboard'); setMobileMenuOpen(false); }}
                className="flex items-center gap-2 rounded-xl bg-purple-50 p-2.5 text-left text-purple-800 font-black"
              >
                <ShieldCheck size={16} /> Admin Console
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
