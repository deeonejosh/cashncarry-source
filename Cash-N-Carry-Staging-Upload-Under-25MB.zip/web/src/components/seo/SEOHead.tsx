import React, { useEffect, useMemo } from 'react';
import { ProductItem } from '../../types';

export interface SEOHeadProps {
  currentTab: string;
  selectedProduct?: ProductItem | null;
  selectedCategory?: string;
  products?: ProductItem[];
  baseUrl?: string;
  googleSiteVerification?: string;
  bingSiteVerification?: string;
}

export interface SEOMetadata {
  title: string;
  description: string;
  canonicalUrl: string;
  ogType: 'website' | 'product';
  image: string;
  jsonLd: Record<string, any>;
  breadcrumbs: Record<string, any>;
}

export const CATEGORY_SEO_MAP: Record<string, { label: string; desc: string }> = {
  tech: {
    label: 'Tech & Electronics Deals',
    desc: 'Shop authentic gadgets, smartphones, audio gear, and accessories at wholesale prices in Nigeria. Fast dispatch with verified escrow warranty protection.',
  },
  fashion: {
    label: 'Fashion & Ankara Collections',
    desc: 'Discover trending Nigerian fashion, Ankara prints, and ready-to-wear apparel from verified Lagos designers with fast nationwide delivery and escrow.',
  },
  beauty: {
    label: 'Beauty & Skincare Essentials',
    desc: 'Shop genuine skincare, cosmetics, and beauty sets from verified Nigerian sellers. Guaranteed authentic formulas with secure escrow checkout and delivery.',
  },
  food: {
    label: 'Food & Groceries Fresh Market',
    desc: 'Order pantry staples, fresh food, and wholesale groceries in Nigeria. Direct from market vendors with refrigerated handling and express doorstep delivery.',
  },
  home: {
    label: 'Home & Kitchen Appliances',
    desc: 'Shop quality home essentials, cookware, and reliable kitchen appliances with manufacturer warranty, secure payment escrow, and fast delivery in Nigeria.',
  },
  services: {
    label: 'Verified Services & Logistics',
    desc: 'Book verified commercial services, logistics dispatch, and artisan assistance across Lagos and Nigeria with escrow protection and money-back guarantee.',
  },
};

/**
 * Dynamically generates the absolute canonical URL based on currentTab,
 * selectedCategory, and selectedProduct to prevent duplicate content indexing issues.
 */
export function buildCanonicalUrl({
  currentTab,
  selectedCategory = 'all',
  selectedProduct,
  products = [],
  baseUrl,
}: {
  currentTab: string;
  selectedCategory?: string;
  selectedProduct?: ProductItem | null;
  products?: ProductItem[];
  baseUrl?: string;
}): string {
  const origin = (
    baseUrl ||
    (typeof window !== 'undefined' && window.location.origin
      ? window.location.origin
      : 'https://www.cashncarryng.com')
  ).replace(/\/+$/, '');

  // 1. Product Detail Page: canonical is strictly /product/{slug}
  if (currentTab === 'product-detail') {
    const prod = selectedProduct || (products && products.length > 0 ? products[0] : null);
    if (prod) {
      const slug = prod.slug || prod.id;
      return `${origin}/product/${encodeURIComponent(slug)}`;
    }
    return `${origin}/shop`;
  }

  // 2. Shop Page: canonical is either /shop or /shop?category={cat}
  if (currentTab === 'shop') {
    if (selectedCategory && selectedCategory !== 'all') {
      return `${origin}/shop?category=${encodeURIComponent(selectedCategory.toLowerCase())}`;
    }
    return `${origin}/shop`;
  }

  // 3. Tab-based canonical URLs
  const tabPathMap: Record<string, string> = {
    home: '/',
    auctions: '/auctions',
    live: '/live',
    'flash-deals': '/flash-deals',
    coins: '/coins',
    returns: '/returns',
    wishlist: '/wishlist',
    orders: '/orders',
    shipments: '/shipments',
    profile: '/profile',
    checkout: '/checkout',
    'checkout-complete': '/checkout-complete',
    'seller-dashboard': '/seller/dashboard',
    'seller-products': '/seller/products',
    'seller-orders': '/seller/orders',
    'seller-kyc': '/seller/kyc',
    'seller-settlements': '/seller/settlements',
    'admin-dashboard': '/admin',
    messages: '/messages',
    notifications: '/notifications',
    'email-marketing': '/email-marketing',
  };

  const path = tabPathMap[currentTab] || `/${currentTab}`;
  return `${origin}${path.startsWith('/') ? path : `/${path}`}`;
}

/**
 * Generates Schema.org BreadcrumbList structured data for rich search result snippets.
 */
export function buildBreadcrumbsList({
  origin,
  currentTab,
  selectedCategory,
  effectiveProduct,
}: {
  origin: string;
  currentTab: string;
  selectedCategory?: string;
  effectiveProduct?: ProductItem | null;
}) {
  const items: Array<{ name: string; url: string }> = [
    { name: 'Home', url: `${origin}/` },
  ];

  if (currentTab === 'product-detail' && effectiveProduct) {
    items.push({ name: 'Shop', url: `${origin}/shop` });
    if (effectiveProduct.category) {
      const catLabel =
        CATEGORY_SEO_MAP[effectiveProduct.category]?.label || effectiveProduct.category;
      items.push({
        name: catLabel,
        url: `${origin}/shop?category=${encodeURIComponent(effectiveProduct.category)}`,
      });
    }
    items.push({
      name: effectiveProduct.title,
      url: `${origin}/product/${encodeURIComponent(effectiveProduct.slug || effectiveProduct.id)}`,
    });
  } else if (currentTab === 'shop') {
    items.push({ name: 'Shop', url: `${origin}/shop` });
    if (selectedCategory && selectedCategory !== 'all') {
      const catLabel = CATEGORY_SEO_MAP[selectedCategory]?.label || selectedCategory;
      items.push({
        name: catLabel,
        url: `${origin}/shop?category=${encodeURIComponent(selectedCategory)}`,
      });
    }
  } else if (currentTab !== 'home') {
    const titles: Record<string, string> = {
      auctions: 'Live Auctions',
      live: 'Live Shopping',
      'flash-deals': 'Flash Deals',
      coins: 'CNC Coins & Wallet',
      returns: 'Returns & Buyer Protection',
      wishlist: 'Wishlist',
      orders: 'Order History',
      shipments: 'Shipment Tracking',
      profile: 'My Profile',
      checkout: 'Checkout',
      'checkout-complete': 'Order Receipt',
      'seller-dashboard': 'Seller Centre',
      'seller-products': 'Manage Products',
      'seller-orders': 'Manage Orders',
      'seller-kyc': 'Seller Verification',
      'seller-settlements': 'Merchant Settlements',
      'admin-dashboard': 'Admin Console',
    };
    items.push({
      name: titles[currentTab] || currentTab,
      url: `${origin}/${currentTab}`,
    });
  }

  return {
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, idx) => ({
      '@type': 'ListItem',
      position: idx + 1,
      name: item.name,
      item: item.url,
    })),
  };
}

export function getSEOMetadata({
  currentTab,
  selectedProduct,
  selectedCategory = 'all',
  products = [],
  baseUrl,
}: SEOHeadProps): SEOMetadata {
  const origin = (
    baseUrl ||
    (typeof window !== 'undefined' && window.location.origin
      ? window.location.origin
      : 'https://www.cashncarryng.com')
  ).replace(/\/+$/, '');

  const defaultImage = `${origin}/brand/logo.png`;

  // Compute canonical URL dynamically using buildCanonicalUrl
  const canonicalUrl = buildCanonicalUrl({
    currentTab,
    selectedCategory,
    selectedProduct,
    products,
    baseUrl: origin,
  });

  const effectiveProduct =
    selectedProduct || (products && products.length > 0 ? products[0] : null);

  const breadcrumbs = buildBreadcrumbsList({
    origin,
    currentTab,
    selectedCategory,
    effectiveProduct,
  });

  // Product Details Page
  if (currentTab === 'product-detail' && effectiveProduct) {
    const formattedPrice = `₦${effectiveProduct.price.toLocaleString()}`;
    const title = `${effectiveProduct.title} - ${formattedPrice} | Cash N Carry`.slice(0, 60);
    const rawDesc = `${effectiveProduct.title} by ${effectiveProduct.brand}. Buy for ${formattedPrice} on Cash N Carry Nigeria with fast delivery, warranty, and secure escrow.`;
    const description = rawDesc.length > 160 ? `${rawDesc.slice(0, 157)}...` : rawDesc;

    const productSchema = {
      '@type': 'Product',
      name: effectiveProduct.title,
      image: [effectiveProduct.image || defaultImage],
      description: effectiveProduct.description,
      sku: effectiveProduct.id,
      brand: {
        '@type': 'Brand',
        name: effectiveProduct.brand || 'Cash N Carry Nigeria',
      },
      offers: {
        '@type': 'Offer',
        url: canonicalUrl,
        priceCurrency: 'NGN',
        price: effectiveProduct.price,
        priceValidUntil: '2027-12-31',
        itemCondition: 'https://schema.org/NewCondition',
        availability:
          effectiveProduct.stock > 0
            ? 'https://schema.org/InStock'
            : 'https://schema.org/OutOfStock',
        seller: {
          '@type': 'Organization',
          name: effectiveProduct.sellerName || 'Cash N Carry Nigeria',
        },
      },
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: effectiveProduct.rating || 4.8,
        reviewCount: effectiveProduct.reviews || 12,
      },
    };

    return {
      title,
      description,
      canonicalUrl,
      ogType: 'product',
      image: effectiveProduct.image || defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [productSchema, breadcrumbs],
      },
    };
  }

  // Shop Page (with category or all)
  if (currentTab === 'shop') {
    const isCategorySelected = selectedCategory && selectedCategory !== 'all';
    const catData = isCategorySelected ? CATEGORY_SEO_MAP[selectedCategory] : null;

    const title = catData
      ? `${catData.label} | Cash N Carry Nigeria`
      : 'Shop Marketplace Wholesale & Retail | Cash N Carry';

    const description = catData
      ? catData.desc
      : 'Browse verified Nigerian wholesale and retail products with genuine CAC-verified seller protection, instant delivery, and Flutterwave escrow payments.';

    const visibleProducts = products
      .filter((p) => p.publication === 'published' && !p.archived)
      .filter((p) => (isCategorySelected ? p.category === selectedCategory : true))
      .slice(0, 10);

    const collectionSchema = {
      '@type': 'CollectionPage',
      name: catData ? catData.label : 'Cash N Carry Marketplace Catalog',
      description,
      url: canonicalUrl,
      mainEntity: {
        '@type': 'ItemList',
        numberOfItems: visibleProducts.length,
        itemListElement: visibleProducts.map((p, idx) => ({
          '@type': 'ListItem',
          position: idx + 1,
          url: `${origin}/product/${p.slug || p.id}`,
          name: p.title,
          image: p.image,
        })),
      },
    };

    return {
      title,
      description,
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [collectionSchema, breadcrumbs],
      },
    };
  }

  // Auctions Page
  if (currentTab === 'auctions') {
    const auctionSchema = {
      '@type': 'WebPage',
      name: 'Live Penny Auctions & Bidding | Cash N Carry Nigeria',
      description:
        'Bid in real-time verified auctions starting at ₦100. Win premium electronics, phones, and appliances with fast delivery and transparent escrow tracking.',
      url: canonicalUrl,
    };
    return {
      title: 'Live Penny Auctions & Bidding | Cash N Carry Nigeria',
      description:
        'Bid in real-time verified auctions starting at ₦100. Win premium electronics, phones, and appliances with fast delivery and transparent escrow tracking.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [auctionSchema, breadcrumbs],
      },
    };
  }

  // Live Commerce Page
  if (currentTab === 'live') {
    const liveSchema = {
      '@type': 'BroadcastEvent',
      name: 'Cash N Carry Nigeria Live Shopping Streams',
      description:
        'Real-time interactive commerce stream with WHIP/WHEP low-latency broadcasting, live vendor chat, and instant checkout in Nigeria.',
      isLiveBroadcast: true,
      url: canonicalUrl,
    };
    return {
      title: 'Interactive Live Shopping Stream | Cash N Carry',
      description:
        'Watch interactive live shopping streams from verified Nigerian vendors, claim exclusive flash vouchers, and buy featured products with 1-click checkout.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [liveSchema, breadcrumbs],
      },
    };
  }

  // Flash Deals Page
  if (currentTab === 'flash-deals') {
    const flashSchema = {
      '@type': 'OfferCatalog',
      name: 'Cash N Carry Flash Deals',
      description:
        'Exclusive promotional flash deals with real-time inventory allocation and Flutterwave escrow protection.',
      url: canonicalUrl,
    };
    return {
      title: 'Flash Deals & Limited Discounts | Cash N Carry',
      description:
        'Grab limited-time flash sales with up to 60% off top electronics, fashion, and daily essentials across Nigeria. Secure escrow protection on every order.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [flashSchema, breadcrumbs],
      },
    };
  }

  // CNC Coins & Wallet
  if (currentTab === 'coins') {
    const coinsSchema = {
      '@type': 'WebPage',
      name: 'CNC Reward Coins & Gifting',
      url: canonicalUrl,
    };
    return {
      title: 'CNC Coins, Gifting & Rewards | Cash N Carry Nigeria',
      description:
        'Claim daily CNC reward coins, send stream gifts to verified sellers, and unlock loyalty discounts on your Cash N Carry purchases across Nigeria.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [coinsSchema, breadcrumbs],
      },
    };
  }

  // Orders
  if (currentTab === 'orders') {
    const ordersSchema = {
      '@type': 'WebPage',
      name: 'Customer Orders & Escrow Ledger',
      url: canonicalUrl,
    };
    return {
      title: 'My Orders & Order History | Cash N Carry Nigeria',
      description:
        'Track your active Cash N Carry orders, view delivery status with GIG Logistics and DHL, request returns, and inspect verified escrow receipts.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [ordersSchema, breadcrumbs],
      },
    };
  }

  // Shipments
  if (currentTab === 'shipments') {
    const shipmentsSchema = {
      '@type': 'WebPage',
      name: 'Carrier Shipment Tracking',
      url: canonicalUrl,
    };
    return {
      title: 'Live Package & Carrier Tracking | Cash N Carry',
      description:
        'Real-time shipment tracking for GIG Logistics and DHL waybills. Monitor transit status, dispatch timestamps, and estimated arrival across Nigeria.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [shipmentsSchema, breadcrumbs],
      },
    };
  }

  // Returns
  if (currentTab === 'returns') {
    const returnsSchema = {
      '@type': 'WebPage',
      name: 'Buyer Protection & Returns Policy',
      url: canonicalUrl,
    };
    return {
      title: 'Returns & Escrow Protection | Cash N Carry Nigeria',
      description:
        'Cash N Carry 7-day buyer protection: easy returns, dispute resolution, and instant escrow refund protection for all verified marketplace purchases.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [returnsSchema, breadcrumbs],
      },
    };
  }

  // Profile
  if (currentTab === 'profile') {
    const profileSchema = {
      '@type': 'ProfilePage',
      name: 'User Account Profile',
      url: canonicalUrl,
    };
    return {
      title: 'My Account & Addresses | Cash N Carry Nigeria',
      description:
        'Manage your Cash N Carry profile, saved Nigerian delivery addresses, notification settings, and switch between buyer, seller, and admin staging roles.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [profileSchema, breadcrumbs],
      },
    };
  }

  // Checkout
  if (currentTab === 'checkout') {
    const checkoutSchema = {
      '@type': 'CheckoutPage',
      name: 'Secure Flutterwave Escrow Checkout',
      url: canonicalUrl,
    };
    return {
      title: 'Secure Checkout & Escrow | Cash N Carry Nigeria',
      description:
        'Complete your purchase with Flutterwave escrow payment. 15-minute stock reservation, verified bank transfer, card, and USSD payment options.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [checkoutSchema, breadcrumbs],
      },
    };
  }

  // Checkout Complete
  if (currentTab === 'checkout-complete') {
    const completeSchema = {
      '@type': 'Order',
      name: 'Order Confirmation',
      url: canonicalUrl,
    };
    return {
      title: 'Order Confirmed - Receipt | Cash N Carry Nigeria',
      description:
        'Your Cash N Carry order has been placed successfully with Flutterwave escrow protection. View tracking details and download your official receipt.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [completeSchema, breadcrumbs],
      },
    };
  }

  // Seller Dashboard
  if (currentTab === 'seller-dashboard') {
    const sellerDashSchema = {
      '@type': 'WebPage',
      name: 'Merchant Operations Centre',
      url: canonicalUrl,
    };
    return {
      title: 'Seller Centre Operations | Cash N Carry Nigeria',
      description:
        'Access the Cash N Carry merchant portal. Track daily revenue, fulfill customer orders, manage product inventory, and verify CAC compliance in Nigeria.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [sellerDashSchema, breadcrumbs],
      },
    };
  }

  // Seller Products
  if (currentTab === 'seller-products') {
    const sellerProdSchema = {
      '@type': 'WebPage',
      name: 'Merchant Product Management',
      url: canonicalUrl,
    };
    return {
      title: 'Merchant Product Catalog | Cash N Carry Nigeria',
      description:
        'Create, edit, and publish merchant product listings. Manage wholesale and retail stock quantities, product images, and promotional discount badges.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [sellerProdSchema, breadcrumbs],
      },
    };
  }

  // Seller Orders
  if (currentTab === 'seller-orders') {
    const sellerOrdSchema = {
      '@type': 'WebPage',
      name: 'Merchant Fulfillment Centre',
      url: canonicalUrl,
    };
    return {
      title: 'Merchant Fulfillment & Waybills | Cash N Carry',
      description:
        'Manage buyer orders, print carrier waybills for GIG Logistics and DHL, mark orders as packaged, and confirm dispatch to release escrow funds.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [sellerOrdSchema, breadcrumbs],
      },
    };
  }

  // Seller KYC
  if (currentTab === 'seller-kyc') {
    const sellerKycSchema = {
      '@type': 'WebPage',
      name: 'Merchant KYC Verification',
      url: canonicalUrl,
    };
    return {
      title: 'CAC & Merchant KYC Verification | Cash N Carry',
      description:
        'Submit Corporate Affairs Commission (CAC) business certificates, identity documents, and bank details for AES-256 encrypted verification in Nigeria.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [sellerKycSchema, breadcrumbs],
      },
    };
  }

  // Seller Settlements
  if (currentTab === 'seller-settlements') {
    const sellerSetSchema = {
      '@type': 'WebPage',
      name: 'Merchant Settlement Ledger',
      url: canonicalUrl,
    };
    return {
      title: 'Merchant Settlements Ledger | Cash N Carry Nigeria',
      description:
        'View payout schedules, commission breakdowns, completed escrow releases, and bank transfer settlement history for verified Nigerian merchants.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [sellerSetSchema, breadcrumbs],
      },
    };
  }

  // Admin Dashboard
  if (currentTab === 'admin-dashboard') {
    const adminSchema = {
      '@type': 'WebPage',
      name: 'Administration & Moderation Console',
      url: canonicalUrl,
    };
    return {
      title: 'Administration & Moderation | Cash N Carry Nigeria',
      description:
        'Cash N Carry admin control panel: moderate vendor listings, approve CAC credentials, review refund claims, and monitor marketplace transactions.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [adminSchema, breadcrumbs],
      },
    };
  }

  // Email Marketing Studio
  if (currentTab === 'email-marketing') {
    const emailSchema = {
      '@type': 'WebPage',
      name: 'Email Marketing & Newsletter Studio',
      url: canonicalUrl,
    };
    return {
      title: 'Email Marketing & Newsletters | Cash N Carry Nigeria',
      description:
        'Design branded email templates, broadcast promotional campaigns to Nigerian shoppers, claim welcome vouchers, and manage newsletter subscribers.',
      canonicalUrl,
      ogType: 'website',
      image: defaultImage,
      breadcrumbs,
      jsonLd: {
        '@context': 'https://schema.org',
        '@graph': [emailSchema, breadcrumbs],
      },
    };
  }

  // Default: Home Page
  const homeSchema = {
    '@type': 'WebSite',
    name: 'Cash N Carry Nigeria',
    url: canonicalUrl,
    description:
      "Nigeria's premier live commerce marketplace for authentic fashion, tech, groceries, and appliances with fast nationwide delivery and escrow protection.",
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: `${origin}/shop?q={search_term_string}`,
      },
      'query-input': 'required name=search_term_string',
    },
  };

  return {
    title: 'Cash N Carry Nigeria | Online Shopping & Live Deals',
    description:
      "Shop Nigeria's premier live commerce marketplace for authentic fashion, tech, groceries, and appliances with fast nationwide delivery and escrow protection.",
    canonicalUrl,
    ogType: 'website',
    image: defaultImage,
    breadcrumbs,
    jsonLd: {
      '@context': 'https://schema.org',
      '@graph': [homeSchema, breadcrumbs],
    },
  };
}

function setOrCreateMetaTag(attributeName: 'name' | 'property', attributeValue: string, content: string) {
  if (typeof document === 'undefined') return;
  let element = document.head.querySelector(`meta[${attributeName}="${attributeValue}"]`);
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attributeName, attributeValue);
    document.head.appendChild(element);
  }
  element.setAttribute('content', content);
}

function setOrCreateCanonicalLink(href: string) {
  if (typeof document === 'undefined') return;
  let link = document.head.querySelector('link[rel="canonical"]');
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', href);
}

function setOrCreateJsonLdScript(data: Record<string, any>) {
  if (typeof document === 'undefined') return;
  const scriptId = 'cnc-seo-structured-data';
  let script = document.getElementById(scriptId) as HTMLScriptElement | null;
  if (!script) {
    script = document.createElement('script');
    script.id = scriptId;
    script.type = 'application/ld+json';
    document.head.appendChild(script);
  }
  script.textContent = JSON.stringify(data, null, 2);
}

export default function SEOHead(props: SEOHeadProps) {
  const seo = useMemo(() => getSEOMetadata(props), [
    props.currentTab,
    props.selectedProduct?.id,
    props.selectedProduct?.slug,
    props.selectedProduct?.price,
    props.selectedProduct?.title,
    props.selectedCategory,
    props.products?.length,
    props.baseUrl,
  ]);

  useEffect(() => {
    if (typeof document === 'undefined') return;

    // 1. Page Title
    document.title = seo.title;

    // 2. Meta Description
    setOrCreateMetaTag('name', 'description', seo.description);

    // 3. Dynamic Absolute Canonical URL Link Tag
    setOrCreateCanonicalLink(seo.canonicalUrl);

    // 4. OpenGraph Tags with Absolute Canonical og:url
    setOrCreateMetaTag('property', 'og:title', seo.title);
    setOrCreateMetaTag('property', 'og:description', seo.description);
    setOrCreateMetaTag('property', 'og:url', seo.canonicalUrl);
    setOrCreateMetaTag('property', 'og:type', seo.ogType);
    setOrCreateMetaTag('property', 'og:site_name', 'Cash N Carry Nigeria');
    setOrCreateMetaTag('property', 'og:image', seo.image);

    // 5. Twitter Card Tags with Absolute Canonical twitter:url
    setOrCreateMetaTag('name', 'twitter:card', 'summary_large_image');
    setOrCreateMetaTag('name', 'twitter:title', seo.title);
    setOrCreateMetaTag('name', 'twitter:description', seo.description);
    setOrCreateMetaTag('name', 'twitter:image', seo.image);
    setOrCreateMetaTag('name', 'twitter:url', seo.canonicalUrl);

    // 6. Search Engine Verification Meta Tags
    const googleToken =
      props.googleSiteVerification || 'google-site-verification-token-cashncarryng';
    const bingToken =
      props.bingSiteVerification || 'bing-site-verification-token-cashncarryng';
    setOrCreateMetaTag('name', 'google-site-verification', googleToken);
    setOrCreateMetaTag('name', 'msvalidate.01', bingToken);

    // 7. Schema.org JSON-LD Structured Data with @graph (Main entity + BreadcrumbList)
    setOrCreateJsonLdScript(seo.jsonLd);
  }, [seo, props.googleSiteVerification, props.bingSiteVerification]);

  return null;
}
