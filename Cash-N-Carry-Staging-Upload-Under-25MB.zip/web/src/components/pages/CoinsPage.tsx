import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Coins, Plus, Gift, History, ShieldCheck, ArrowUpRight, ArrowDownLeft } from 'lucide-react';

export default function CoinsPage() {
  const { stagingConfig, coinBalance, coinLedger, claimTestCoins, sendLiveGift, showToast } = useStore();
  const coinsEnabled = stagingConfig.paymentsEnabled && stagingConfig.coinsPurchasesEnabled;

  const [recipient, setRecipient] = useState('olaoluwa');
  const [selectedGift, setSelectedGift] = useState<'rose' | 'star' | 'lion'>('star');

  const handleSendCustomGift = (e: React.FormEvent) => {
    e.preventDefault();
    const res = sendLiveGift(recipient, selectedGift);
    if (!res.success) {
      showToast(res.message || 'Gift failed');
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {!coinsEnabled && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900">
          <div className="font-black">Coin purchases & simulated credits temporarily unavailable</div>
          <p className="mt-0.5 text-amber-800">
            Wallet top-ups and paid coin purchases are disabled in staging (<code className="font-mono">PAYMENTS_ENABLED=false</code>).
            Balances cannot be increased via simulated payments; the fixture balance below is for non-financial UI layout preview only.
          </p>
        </div>
      )}

      {/* Wallet Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-amber-600 via-yellow-600 to-amber-700 p-8 text-white shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <span className="rounded-full bg-white/20 px-3 py-1 text-[10px] font-black uppercase text-amber-100">
              ISOLATED STAGING FIXTURE WALLET
            </span>
            <div className="text-xs text-amber-100">Staging Fixture Balance (Non-Financial):</div>
            <div className="flex items-center gap-3">
              <Coins size={36} className="text-amber-200" />
              <span className="text-4xl font-black">{coinBalance.toLocaleString()}</span>
              <span className="text-xs text-amber-200 font-bold">Coins</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => claimTestCoins(500)}
              disabled={!coinsEnabled}
              className="flex items-center gap-2 rounded-2xl bg-white px-5 py-3 text-xs font-black text-amber-900 shadow-md hover:bg-amber-50 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus size={16} />
              <span>{coinsEnabled ? 'Purchase Coins' : 'Coin Purchases Disabled'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* Send Gift Box */}
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-sm font-black text-slate-900">
            <Gift size={18} className="text-amber-600" />
            <span>Send Streamer Gift</span>
          </div>

          <p className="text-xs text-slate-500">
            Send gifts to your favorite Nigerian creators during live broadcasts.
          </p>

          <form onSubmit={handleSendCustomGift} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-700">Select Streamer</label>
              <select
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none bg-white"
              >
                <option value="olaoluwa">Olaoluwa Trends (Fashion)</option>
                <option value="ziva">Ziva Glow Essentials (Beauty)</option>
                <option value="mile12">Mile 12 Fresh Market (Food)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700">Choose Gift</label>
              <div className="mt-2 grid grid-cols-3 gap-2 text-center">
                <button
                  type="button"
                  onClick={() => setSelectedGift('rose')}
                  className={`rounded-2xl border p-2.5 transition ${
                    selectedGift === 'rose' ? 'border-rose-500 bg-rose-50' : 'border-slate-200'
                  }`}
                >
                  <span className="text-2xl">🌹</span>
                  <div className="text-[11px] font-bold">Rose</div>
                  <div className="text-[10px] text-rose-600 font-black">10 coins</div>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedGift('star')}
                  className={`rounded-2xl border p-2.5 transition ${
                    selectedGift === 'star' ? 'border-amber-500 bg-amber-50' : 'border-slate-200'
                  }`}
                >
                  <span className="text-2xl">⭐</span>
                  <div className="text-[11px] font-bold">Star</div>
                  <div className="text-[10px] text-amber-600 font-black">100 coins</div>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedGift('lion')}
                  className={`rounded-2xl border p-2.5 transition ${
                    selectedGift === 'lion' ? 'border-orange-500 bg-orange-50' : 'border-slate-200'
                  }`}
                >
                  <span className="text-2xl">🦁</span>
                  <div className="text-[11px] font-bold">Lion</div>
                  <div className="text-[10px] text-orange-600 font-black">1,000 coins</div>
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full rounded-2xl bg-amber-600 py-3 text-xs font-black text-white hover:bg-amber-700 transition"
            >
              Send Gift Now
            </button>
          </form>
        </div>

        {/* Ledger Activity History (2 Cols) */}
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4 lg:col-span-2">
          <div className="flex items-center gap-2 text-sm font-black text-slate-900 border-b border-slate-100 pb-3">
            <History size={18} className="text-amber-600" />
            <span>Coin Ledger & Audit Trail</span>
          </div>

          <div className="divide-y divide-slate-100">
            {coinLedger.map((item) => (
              <div key={item.id} className="flex items-center justify-between py-3 text-xs">
                <div className="flex items-center gap-3">
                  <span
                    className={`flex h-8 w-8 items-center justify-center rounded-xl ${
                      item.delta > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {item.delta > 0 ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}
                  </span>
                  <div>
                    <div className="font-bold text-slate-800">{item.reason}</div>
                    <div className="text-[10px] text-slate-400">
                      {new Date(item.createdAt).toLocaleDateString()} · {new Date(item.createdAt).toLocaleTimeString()}
                    </div>
                  </div>
                </div>

                <div
                  className={`text-sm font-black ${
                    item.delta > 0 ? 'text-emerald-700' : 'text-rose-600'
                  }`}
                >
                  {item.delta > 0 ? `+${item.delta}` : item.delta} coins
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
