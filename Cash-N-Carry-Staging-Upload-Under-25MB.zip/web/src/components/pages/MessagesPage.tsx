import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductItem } from '../../types';
import {
  MessageSquare,
  Send,
  CheckCheck,
  Check,
  User,
  Store,
  ShieldCheck,
  Package,
  Search,
  ArrowLeft,
  ShoppingBag,
  ExternalLink,
  MoreVertical,
  Flag,
  Slash,
  Paperclip,
  CheckCircle2,
} from 'lucide-react';

interface MessagesPageProps {
  onSelectProduct?: (product: ProductItem) => void;
  onNavigateOrder?: (orderId: string) => void;
}

interface ConversationSummary {
  vendorId: string;
  name: string;
  avatar: string;
  verified: boolean;
  role: string;
  lastMessage: string;
  timestamp: string;
  unreadCount: number;
  orderId?: string;
  orderStatus?: string;
}

export default function MessagesPage({ onSelectProduct, onNavigateOrder }: MessagesPageProps) {
  const { messages, sendMessage, currentUser, products, showToast } = useStore();

  const [activeVendorId, setActiveVendorId] = useState<string>('olaoluwa');
  const [mobileThreadOpen, setMobileThreadOpen] = useState<boolean>(false);
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showProductPicker, setShowProductPicker] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  const conversations: ConversationSummary[] = [
    {
      vendorId: 'olaoluwa',
      name: 'Olaoluwa Trends',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
      verified: true,
      role: 'Fashion & Ankara Specialist (Lagos)',
      lastMessage: 'The driver will call you on arrival in Ikeja.',
      timestamp: '17h ago',
      unreadCount: 0,
      orderId: 'CNC-2026-9042',
      orderStatus: 'In Transit via GIG Logistics',
    },
    {
      vendorId: 'ziva',
      name: 'Ziva Glow Essentials',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      verified: true,
      role: 'Beauty & Skincare (Abuja)',
      lastMessage: 'Hi Chidi, thanks for checking out our Glow Gold Skincare Set! We have 25 units in stock.',
      timestamp: '5h ago',
      unreadCount: 1,
    },
    {
      vendorId: 'support',
      name: 'Cash N Carry Help Desk',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
      verified: true,
      role: 'Escrow & Dispute Resolution',
      lastMessage: 'All payments are held in Flutterwave escrow until you confirm delivery.',
      timestamp: '2d ago',
      unreadCount: 0,
    },
  ];

  const currentConv = conversations.find((c) => c.vendorId === activeVendorId) || conversations[0];

  // Filter messages belonging to this thread
  const threadMessages = messages.filter(
    (m) =>
      (m.senderId === activeVendorId && m.receiverId === currentUser.id) ||
      (m.senderId === currentUser.id && m.receiverId === activeVendorId) ||
      (activeVendorId === 'support' && (m.senderId === 'support' || m.receiverId === 'support'))
  );

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    sendMessage(activeVendorId, inputText.trim(), {
      orderId: currentConv.orderId,
    });
    setInputText('');
  };

  const handleSendProduct = (product: ProductItem) => {
    sendMessage(activeVendorId, `Attached product: ${product.title} (₦${product.price.toLocaleString()})`, {
      attachedProduct: product,
      orderId: currentConv.orderId,
    });
    setShowProductPicker(false);
    showToast(`Shared ${product.title} with seller`);
  };

  const quickReplies = [
    'Is this item available in stock?',
    'When will my order dispatch?',
    'Can I change my delivery address?',
    'Does this come with warranty?',
    'Can I get custom sizing?',
  ];

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900">Messages & Inquiries</h1>
          <p className="text-xs text-slate-500">
            Secure buyer-seller communications backed by Cash N Carry dispute protection.
          </p>
        </div>
      </div>

      {/* Main Messaging Container */}
      <div className="grid grid-cols-1 md:grid-cols-3 rounded-3xl border border-slate-200 bg-white shadow-sm overflow-hidden h-[680px]">
        
        {/* LEFT PANE: THREAD LIST (hidden on mobile if thread is open) */}
        <div
          className={`${
            mobileThreadOpen ? 'hidden md:flex' : 'flex'
          } flex-col border-r border-slate-100 bg-slate-50/40 h-full`}
        >
          {/* Search Box */}
          <div className="p-3 border-b border-slate-100 bg-white">
            <div className="relative">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search conversations..."
                className="h-9 w-full rounded-xl border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs outline-none focus:border-[#0c5c36]"
              />
            </div>
          </div>

          {/* Conversation List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {conversations
              .filter((c) => c.name.toLowerCase().includes(searchQuery.toLowerCase()))
              .map((conv) => {
                const isActive = activeVendorId === conv.vendorId;
                return (
                  <button
                    key={conv.vendorId}
                    onClick={() => {
                      setActiveVendorId(conv.vendorId);
                      setMobileThreadOpen(true);
                    }}
                    className={`flex w-full items-start gap-3 p-3.5 text-left transition ${
                      isActive ? 'bg-emerald-50/70 border-l-4 border-[#0c5c36]' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img
                        src={conv.avatar}
                        alt={conv.name}
                        className="h-11 w-11 rounded-2xl object-cover border border-slate-200"
                      />
                      {conv.verified && (
                        <span className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-600 text-white">
                          <CheckCircle2 size={10} />
                        </span>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900 truncate">
                          {conv.name}
                        </span>
                        <span className="text-[10px] text-slate-400">{conv.timestamp}</span>
                      </div>

                      <p className="mt-0.5 text-[11px] text-slate-500 line-clamp-1">
                        {conv.lastMessage}
                      </p>

                      {conv.orderStatus && (
                        <div className="mt-1 flex items-center gap-1 text-[9px] font-bold text-emerald-800">
                          <Package size={10} />
                          <span className="truncate">{conv.orderStatus}</span>
                        </div>
                      )}
                    </div>

                    {conv.unreadCount > 0 && (
                      <span className="flex h-4 min-w-[16px] items-center justify-center rounded-full bg-orange-500 px-1 text-[9px] font-black text-white">
                        {conv.unreadCount}
                      </span>
                    )}
                  </button>
                );
              })}
          </div>
        </div>

        {/* RIGHT PANE: ACTIVE CHAT THREAD */}
        <div
          className={`${
            !mobileThreadOpen ? 'hidden md:flex' : 'flex'
          } flex-col md:col-span-2 h-full bg-slate-50/20`}
        >
          {/* Top Thread Bar */}
          <div className="flex items-center justify-between border-b border-slate-100 bg-white px-4 py-3">
            <div className="flex items-center gap-3">
              {/* Back Button on Mobile */}
              <button
                onClick={() => setMobileThreadOpen(false)}
                className="md:hidden rounded-full p-1.5 text-slate-600 hover:bg-slate-100"
                aria-label="Back to conversations"
              >
                <ArrowLeft size={18} />
              </button>

              <img
                src={currentConv.avatar}
                alt={currentConv.name}
                className="h-10 w-10 rounded-2xl object-cover border border-slate-200"
              />

              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-slate-900">{currentConv.name}</span>
                  {currentConv.verified && (
                    <span className="flex items-center gap-0.5 rounded-full bg-emerald-100 px-1.5 py-0.2 text-[9px] font-black text-emerald-800">
                      <ShieldCheck size={10} /> CAC Verified
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-slate-500">{currentConv.role}</div>
              </div>
            </div>

            {/* Thread Actions Menu */}
            <div className="relative">
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="rounded-full p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
              >
                <MoreVertical size={16} />
              </button>

              {showDropdown && (
                <div className="absolute right-0 top-full mt-1 w-44 rounded-2xl border border-slate-100 bg-white p-1.5 shadow-xl z-20 text-xs">
                  <button
                    onClick={() => {
                      showToast('User reported to Cash N Carry Compliance Desk.');
                      setShowDropdown(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-rose-600 hover:bg-rose-50 font-bold"
                  >
                    <Flag size={14} /> Report User
                  </button>
                  <button
                    onClick={() => {
                      showToast('Vendor blocked from direct messaging.');
                      setShowDropdown(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-slate-700 hover:bg-slate-50 font-semibold"
                  >
                    <Slash size={14} /> Block Messages
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Context Banner: Linked Order (if any) */}
          {currentConv.orderId && (
            <div className="flex items-center justify-between border-b border-emerald-100 bg-emerald-50/80 px-4 py-2 text-xs">
              <div className="flex items-center gap-2 text-emerald-900 font-bold">
                <Package size={14} className="text-emerald-700" />
                <span>Linked Order: {currentConv.orderId}</span>
                <span className="rounded-full bg-emerald-200/80 px-2 py-0.5 text-[9px] font-black text-emerald-900">
                  {currentConv.orderStatus}
                </span>
              </div>
              <button
                onClick={() => onNavigateOrder?.(currentConv.orderId!)}
                className="text-[11px] font-black text-[#0c5c36] hover:underline"
              >
                Track Shipment →
              </button>
            </div>
          )}

          {/* Chat Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {threadMessages.map((msg) => {
              const isMine = msg.senderId === currentUser.id;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl p-3 text-xs leading-relaxed shadow-sm ${
                      isMine
                        ? 'bg-[#0c5c36] text-white rounded-tr-none'
                        : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
                    }`}
                  >
                    {/* Attached Product Card if present */}
                    {msg.attachedProduct && (
                      <div className="mb-2 rounded-xl bg-black/10 p-2.5 text-slate-900 flex items-center gap-3 bg-white/90">
                        <img
                          src={msg.attachedProduct.image}
                          alt={msg.attachedProduct.title}
                          className="h-10 w-10 rounded-lg object-cover"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="text-[11px] font-bold truncate">{msg.attachedProduct.title}</div>
                          <div className="text-xs font-black text-orange-600">
                            ₦{msg.attachedProduct.price.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    )}

                    <p>{msg.content}</p>

                    <div
                      className={`mt-1 flex items-center justify-end gap-1 text-[9px] ${
                        isMine ? 'text-emerald-200' : 'text-slate-400'
                      }`}
                    >
                      <span>
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                      {isMine && (
                        <span>
                          {msg.status === 'read' ? (
                            <CheckCheck size={12} className="text-emerald-300" />
                          ) : msg.status === 'delivered' ? (
                            <CheckCheck size={12} className="text-slate-300" />
                          ) : (
                            <Check size={12} className="text-slate-300" />
                          )}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Replies Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto border-t border-slate-100 bg-white px-3 py-2 text-[11px]">
            {quickReplies.map((qr) => (
              <button
                key={qr}
                onClick={() => setInputText(qr)}
                className="whitespace-nowrap rounded-full bg-slate-100 px-3 py-1 font-semibold text-slate-600 hover:bg-emerald-50 hover:text-[#0c5c36] transition"
              >
                {qr}
              </button>
            ))}
          </div>

          {/* Product Attachment Drawer */}
          {showProductPicker && (
            <div className="border-t border-slate-200 bg-slate-50 p-3 space-y-2 max-h-48 overflow-y-auto">
              <div className="text-[11px] font-black text-slate-600 uppercase">Attach Product Card</div>
              <div className="grid grid-cols-2 gap-2">
                {products.slice(0, 4).map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleSendProduct(p)}
                    className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white p-2 text-left hover:border-emerald-600"
                  >
                    <img src={p.image} alt={p.title} className="h-8 w-8 rounded-lg object-cover" />
                    <div className="min-w-0 flex-1 text-[11px]">
                      <div className="font-bold truncate">{p.title}</div>
                      <div className="font-black text-orange-600">₦{p.price.toLocaleString()}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Message Input Form */}
          <form onSubmit={handleSend} className="flex items-center gap-2 border-t border-slate-200 bg-white p-3">
            <button
              type="button"
              onClick={() => setShowProductPicker(!showProductPicker)}
              className="rounded-full p-2 text-slate-500 hover:bg-slate-100 hover:text-[#0c5c36]"
              title="Attach Product"
            >
              <Paperclip size={18} />
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Message ${currentConv.name}...`}
              className="flex-1 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs outline-none focus:border-[#0c5c36] focus:bg-white"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#0c5c36] text-white transition hover:bg-emerald-900 disabled:opacity-40"
              aria-label="Send Message"
            >
              <Send size={16} />
            </button>
          </form>

        </div>
      </div>
    </div>
  );
}
