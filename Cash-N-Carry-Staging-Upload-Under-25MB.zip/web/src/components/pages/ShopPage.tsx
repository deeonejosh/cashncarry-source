import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import ProductCard from '../ui/ProductCard';
import { ProductItem } from '../../types';
import { Search, Filter, SlidersHorizontal, ArrowUpDown, Check } from 'lucide-react';
import { categories } from '../../lib/data';

interface ShopPageProps {
  onSelectProduct: (product: ProductItem) => void;
  onQuickBuy?: (product: ProductItem) => void;
  selectedCategory?: string;
  onSelectCategory?: (category: string) => void;
}

export default function ShopPage({
  onSelectProduct,
  onQuickBuy,
  selectedCategory: controlledCategory,
  onSelectCategory,
}: ShopPageProps) {
  const { products } = useStore();

  const [internalCategory, setInternalCategory] = useState<string>('all');
  const selectedCategory = controlledCategory !== undefined ? controlledCategory : internalCategory;

  const handleCategoryChange = (category: string) => {
    setInternalCategory(category);
    onSelectCategory?.(category);
  };

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating' | 'newest'>('featured');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [maxPrice, setMaxPrice] = useState<number>(100000);

  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => p.publication === 'published' && !p.archived)
      .filter((p) => {
        if (selectedCategory !== 'all' && p.category !== selectedCategory) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = p.title.toLowerCase().includes(q);
          const matchBrand = p.brand.toLowerCase().includes(q);
          const matchDesc = p.description.toLowerCase().includes(q);
          if (!matchTitle && !matchBrand && !matchDesc) return false;
        }
        if (inStockOnly && p.stock <= 0) return false;
        if (p.price > maxPrice) return false;
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-low') return a.price - b.price;
        if (sortBy === 'price-high') return b.price - a.price;
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        return 0;
      });
  }, [products, selectedCategory, searchQuery, sortBy, inStockOnly, maxPrice]);

  return (
    <div className="space-y-8 pb-16">
      {/* Header Banner */}
      <div className="rounded-3xl bg-[#0c5c36] p-8 text-white shadow-md">
        <h1 className="text-2xl font-black sm:text-3xl">Shop Marketplace</h1>
        <p className="mt-1 text-xs text-emerald-100 sm:text-sm">
          Browse authentic inventory from verified Nigerian sellers with real-time stock and escrow checkout.
        </p>

        {/* Search input in banner */}
        <div className="mt-5 max-w-xl">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products, brands, or categories..."
              className="h-12 w-full rounded-2xl bg-white pl-11 pr-4 text-xs font-semibold text-slate-800 outline-none shadow-md focus:ring-4 focus:ring-emerald-400/30"
            />
          </div>
        </div>
      </div>

      {/* Main Content: Sidebar Filters + Products Grid */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
        {/* Filters Sidebar */}
        <aside className="space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm h-fit">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2 text-xs font-black text-slate-900 uppercase tracking-wider">
              <SlidersHorizontal size={15} className="text-[#0c5c36]" />
              <span>Filters</span>
            </div>
            {(selectedCategory !== 'all' || searchQuery || inStockOnly || maxPrice < 100000) && (
              <button
                onClick={() => {
                  handleCategoryChange('all');
                  setSearchQuery('');
                  setInStockOnly(false);
                  setMaxPrice(100000);
                  setSortBy('featured');
                }}
                className="text-[11px] font-bold text-orange-600 hover:underline"
              >
                Reset All
              </button>
            )}
          </div>

          {/* Categories */}
          <div>
            <label className="block text-xs font-black text-slate-800">Category</label>
            <div className="mt-2.5 space-y-1">
              <button
                onClick={() => handleCategoryChange('all')}
                className={`flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs font-bold transition ${
                  selectedCategory === 'all'
                    ? 'bg-[#0c5c36] text-white'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <span>All Categories</span>
                <span>{products.length}</span>
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryChange(cat.id)}
                  className={`flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs font-bold transition ${
                    selectedCategory === cat.id
                      ? 'bg-[#0c5c36] text-white'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <span>{cat.icon}</span>
                    <span>{cat.name}</span>
                  </span>
                  <span className="text-[11px] opacity-70">{cat.count}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="border-t border-slate-100 pt-4">
            <div className="flex items-center justify-between text-xs font-bold text-slate-800">
              <span>Max Price:</span>
              <span className="font-black text-[#0c5c36]">₦{maxPrice.toLocaleString()}</span>
            </div>
            <input
              type="range"
              min={5000}
              max={100000}
              step={2500}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="mt-3 w-full accent-[#0c5c36]"
            />
            <div className="mt-1 flex justify-between text-[10px] text-slate-400">
              <span>₦5,000</span>
              <span>₦100,000</span>
            </div>
          </div>

          {/* In Stock Only Checkbox */}
          <div className="border-t border-slate-100 pt-4">
            <label className="flex items-center gap-2.5 cursor-pointer text-xs font-bold text-slate-700">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-[#0c5c36]"
              />
              <span>In Stock Only</span>
            </label>
          </div>
        </aside>

        {/* Product Grid Area */}
        <div className="space-y-6 lg:col-span-3">
          {/* Controls Bar: Count + Sorting */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="text-xs font-bold text-slate-600">
              Showing <b className="text-slate-900">{filteredProducts.length}</b> verified items
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-500">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-800 outline-none focus:border-emerald-600"
              >
                <option value="featured">Featured / Best Match</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Top Customer Rated</option>
                <option value="newest">Newly Listed</option>
              </select>
            </div>
          </div>

          {/* Products Grid */}
          {filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-slate-200 bg-white p-16 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-slate-400">
                <Search size={32} />
              </div>
              <h3 className="mt-4 text-base font-black text-slate-800">No matching products found</h3>
              <p className="mt-1 text-xs text-slate-500">
                Try loosening your filters or searching for something else like "Ankara", "Earbuds", or "Cream".
              </p>
              <button
                onClick={() => {
                  handleCategoryChange('all');
                  setSearchQuery('');
                  setMaxPrice(100000);
                  setInStockOnly(false);
                }}
                className="mt-5 rounded-full bg-[#0c5c36] px-5 py-2.5 text-xs font-bold text-white hover:bg-emerald-900 transition"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelectProduct={onSelectProduct}
                  onQuickBuy={onQuickBuy}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
