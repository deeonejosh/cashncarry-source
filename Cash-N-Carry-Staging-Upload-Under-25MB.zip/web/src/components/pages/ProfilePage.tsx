import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { NIGERIAN_STATES } from '../../lib/design-tokens';
import {
  User,
  MapPin,
  ShieldCheck,
  Mail,
  Plus,
  Trash2,
  CheckCircle2,
  Package,
  Heart,
  Users,
  Coins,
  Store,
  LogOut,
  LogIn,
  Edit3,
  Video,
  Play,
  Sparkles,
} from 'lucide-react';

interface ProfilePageProps {
  onNavigate?: (tab: string) => void;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=240&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=240&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=240&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=240&auto=format&fit=crop&q=80',
];

export default function ProfilePage({ onNavigate }: ProfilePageProps) {
  const {
    currentUser,
    isAuthenticatedSession,
    setAuthModalOpen,
    updateUserProfile,
    signOutAccount,
    selectedState,
    setSelectedState,
    addresses,
    addAddress,
    deleteAddress,
    orders,
    wishlist,
    followingSellers,
    coinBalance,
    shortVideos,
    uploadShortVideo,
    products,
    showToast,
  } = useStore();

  const [showAddressForm, setShowAddressForm] = useState(false);
  const [recipient, setRecipient] = useState(currentUser.name);
  const [phone, setPhone] = useState('+234 803 123 4567');
  const [line, setLine] = useState('');
  const [city, setCity] = useState('Lagos');
  const [state, setState] = useState(selectedState || 'Lagos');

  const [editingProfile, setEditingProfile] = useState(false);
  const [displayNameDraft, setDisplayNameDraft] = useState(currentUser.name);
  const [bioDraft, setBioDraft] = useState(
    currentUser.bio || 'Verified Cash N Carry shopper discovering Nigerian live deals.'
  );
  const [avatarDraft, setAvatarDraft] = useState(currentUser.avatar || AVATAR_PRESETS[0]);
  const [stateDraft, setStateDraft] = useState(selectedState || 'Lagos');

  const [showVideoComposer, setShowVideoComposer] = useState(false);
  const [videoCaption, setVideoCaption] = useState('');
  const [videoCover, setVideoCover] = useState(
    'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80'
  );
  const [taggedProductId, setTaggedProductId] = useState(products[0]?.id || 'p1');

  const userUploadedVideos = shortVideos.filter(
    (v) => v.sellerId === currentUser.id || v.sellerName === currentUser.name
  );
  const galleryVideos = userUploadedVideos.length > 0 ? userUploadedVideos : shortVideos.slice(0, 4);
  const totalLikes = galleryVideos.reduce((acc, v) => acc + v.likesCount, 0);

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!line || !city) {
      showToast('Please enter street line and city');
      return;
    }
    addAddress({ recipient, phone, line, city, state });
    setShowAddressForm(false);
    setLine('');
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateUserProfile({
      displayName: displayNameDraft,
      bio: bioDraft,
      avatarUrl: avatarDraft,
      selectedState: stateDraft,
    });
    setEditingProfile(false);
  };

  const handlePublishShortVideo = (e: React.FormEvent) => {
    e.preventDefault();
    const product = products.find((p) => p.id === taggedProductId) || products[0];
    if (!product || !videoCaption.trim()) {
      showToast('Add a caption and tagged product');
      return;
    }
    uploadShortVideo({
      sellerId: currentUser.id,
      sellerName: currentUser.name,
      sellerAvatar: currentUser.avatar || AVATAR_PRESETS[0],
      sellerVerified: currentUser.verified,
      videoUrl:
        'https://assets.mixkit.co/videos/preview/mixkit-fashion-model-showing-off-her-clothing-41553-large.mp4',
      posterUrl: videoCover,
      caption: videoCaption.trim(),
      taggedProduct: product,
    });
    setVideoCaption('');
    setShowVideoComposer(false);
  };

  const navigateTo = (tab: string) => {
    if (onNavigate) {
      onNavigate(tab);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Profile Header Matching Android UserProfileScreen */}
      <div className="rounded-3xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm space-y-5">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="relative shrink-0">
              <img
                src={currentUser.avatar || AVATAR_PRESETS[0]}
                alt={currentUser.name}
                className="h-20 w-20 rounded-3xl object-cover border-2 border-[#0E6B38] shadow-sm"
              />
              <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-[#0E6B38] text-white shadow">
                <CheckCircle2 size={14} />
              </span>
            </div>
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl font-black text-slate-900 sm:text-2xl">{currentUser.name}</h1>
                <span className="inline-flex items-center gap-1 rounded-full bg-[#EAF7EF] px-2.5 py-0.5 text-xs font-bold text-[#0E6B38]">
                  <CheckCircle2 size={12} /> {isAuthenticatedSession ? 'Cloudflare Synced' : 'Staging Preview'}
                </span>
                <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-[10px] font-black uppercase text-slate-700">
                  {currentUser.role}
                </span>
              </div>
              <p className="text-xs text-slate-600 max-w-xl">
                {currentUser.bio || 'Verified Cash N Carry shopper discovering Nigerian live deals.'}
              </p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                <span className="inline-flex items-center gap-1">
                  <Mail size={13} /> {currentUser.email}
                </span>
                <span className="inline-flex items-center gap-1 font-bold text-[#0E6B38]">
                  <MapPin size={13} /> Delivery State: {selectedState}
                </span>
              </div>
              {currentUser.storeName && (
                <div className="text-xs font-bold text-[#FF6B00] flex items-center gap-1">
                  <Store size={13} />
                  <span>Store: {currentUser.storeName}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            <button
              type="button"
              onClick={() => {
                setDisplayNameDraft(currentUser.name);
                setBioDraft(currentUser.bio || '');
                setAvatarDraft(currentUser.avatar || AVATAR_PRESETS[0]);
                setStateDraft(selectedState);
                setEditingProfile(!editingProfile);
              }}
              className="inline-flex min-h-[44px] items-center gap-1.5 rounded-2xl border border-slate-200 bg-slate-50 px-4 text-xs font-black text-slate-800 hover:bg-slate-100 transition"
            >
              <Edit3 size={14} />
              <span>Edit Profile</span>
            </button>
            {isAuthenticatedSession ? (
              <button
                type="button"
                onClick={signOutAccount}
                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-2xl border border-rose-200 bg-rose-50 px-4 text-xs font-black text-rose-700 hover:bg-rose-100 transition"
              >
                <LogOut size={14} />
                <span>Sign Out</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setAuthModalOpen(true)}
                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-2xl bg-[#0E6B38] px-5 text-xs font-black text-white hover:bg-[#084B26] transition shadow-sm"
              >
                <LogIn size={14} />
                <span>Sign In / Create Account</span>
              </button>
            )}
          </div>
        </div>

        {/* Inline Edit Profile Form (Avatar, Display Name, Bio, Nigerian State) */}
        {editingProfile && (
          <form onSubmit={handleSaveProfile} className="rounded-2xl border border-emerald-200 bg-[#EAF7EF]/60 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black uppercase tracking-wider text-[#084B26]">
                Edit Unified Profile (Web & Android Sync)
              </h3>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {AVATAR_PRESETS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setAvatarDraft(preset)}
                  className={`rounded-2xl p-0.5 border-2 transition ${
                    avatarDraft === preset ? 'border-[#FF6B00] scale-105' : 'border-transparent'
                  }`}
                >
                  <img src={preset} alt="Avatar choice" className="h-12 w-12 rounded-xl object-cover" />
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700">Display Name</label>
                <input
                  type="text"
                  value={displayNameDraft}
                  onChange={(e) => setDisplayNameDraft(e.target.value)}
                  required
                  className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-xs outline-none focus:border-[#0E6B38]"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700">Primary Delivery State</label>
                <select
                  value={stateDraft}
                  onChange={(e) => setStateDraft(e.target.value)}
                  className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-xs outline-none focus:border-[#0E6B38]"
                >
                  {NIGERIAN_STATES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-700">Bio / Creator Tagline</label>
              <textarea
                rows={2}
                value={bioDraft}
                onChange={(e) => setBioDraft(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-white p-3 text-xs outline-none focus:border-[#0E6B38]"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="min-h-[40px] rounded-xl bg-[#0E6B38] px-5 text-xs font-black text-white hover:bg-[#084B26]"
              >
                Save Profile
              </button>
              <button
                type="button"
                onClick={() => setEditingProfile(false)}
                className="min-h-[40px] rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-600"
              >
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Stats Counter Bar matching Android UserProfileScreen */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <button
          onClick={() => navigateTo('orders')}
          className="rounded-2xl border border-slate-200 bg-white p-4 text-center hover:border-[#0E6B38] transition shadow-sm"
        >
          <div className="text-xl font-black text-slate-900">{orders.length}</div>
          <div className="mt-0.5 flex items-center justify-center gap-1 text-[11px] font-bold text-slate-500">
            <Package size={13} className="text-[#0E6B38]" />
            <span>Orders</span>
          </div>
        </button>
        <button
          onClick={() => navigateTo('wishlist')}
          className="rounded-2xl border border-slate-200 bg-white p-4 text-center hover:border-[#0E6B38] transition shadow-sm"
        >
          <div className="text-xl font-black text-slate-900">{wishlist.length}</div>
          <div className="mt-0.5 flex items-center justify-center gap-1 text-[11px] font-bold text-slate-500">
            <Heart size={13} className="text-rose-500" />
            <span>Wishlist</span>
          </div>
        </button>
        <button
          onClick={() => navigateTo('for-you')}
          className="rounded-2xl border border-slate-200 bg-white p-4 text-center hover:border-[#0E6B38] transition shadow-sm"
        >
          <div className="text-xl font-black text-slate-900">{galleryVideos.length}</div>
          <div className="mt-0.5 flex items-center justify-center gap-1 text-[11px] font-bold text-slate-500">
            <Video size={13} className="text-[#FF6B00]" />
            <span>Videos ({totalLikes.toLocaleString()} Likes)</span>
          </div>
        </button>
        <button
          onClick={() => navigateTo('shop')}
          className="rounded-2xl border border-slate-200 bg-white p-4 text-center hover:border-[#0E6B38] transition shadow-sm"
        >
          <div className="text-xl font-black text-slate-900">{followingSellers.length}</div>
          <div className="mt-0.5 flex items-center justify-center gap-1 text-[11px] font-bold text-slate-500">
            <Users size={13} className="text-blue-500" />
            <span>Following</span>
          </div>
        </button>
        <button
          onClick={() => navigateTo('coins')}
          className="col-span-2 sm:col-span-1 rounded-2xl border border-amber-200 bg-amber-50/60 p-4 text-center hover:border-amber-400 transition shadow-sm"
        >
          <div className="text-xl font-black text-amber-900">{coinBalance.toLocaleString()}</div>
          <div className="mt-0.5 flex items-center justify-center gap-1 text-[11px] font-bold text-amber-700">
            <Coins size={13} className="text-amber-600" />
            <span>Coins (₦)</span>
          </div>
        </button>
      </div>

      {/* Uploaded Shoppable Videos Section (from Android UserProfileScreen) */}
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles size={18} className="text-[#FF6B00]" />
            <h2 className="text-sm font-black text-slate-900">Uploaded Shoppable Videos</h2>
          </div>
          <button
            type="button"
            onClick={() => setShowVideoComposer(!showVideoComposer)}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-[#FF6B00] px-4 text-xs font-black text-white hover:bg-orange-600 transition"
          >
            <Plus size={14} />
            <span>Post Shoppable Video</span>
          </button>
        </div>

        {showVideoComposer && (
          <form onSubmit={handlePublishShortVideo} className="rounded-2xl border border-orange-200 bg-[#FFF4EB] p-4 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700">Tag Product</label>
                <select
                  value={taggedProductId}
                  onChange={(e) => setTaggedProductId(e.target.value)}
                  className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-xs outline-none"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} (₦{p.price.toLocaleString('en-NG')})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700">Cover Thumbnail URL</label>
                <input
                  type="url"
                  value={videoCover}
                  onChange={(e) => setVideoCover(e.target.value)}
                  required
                  className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-xs outline-none"
                />
              </div>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-700">Video Caption</label>
              <input
                type="text"
                value={videoCaption}
                onChange={(e) => setVideoCaption(e.target.value)}
                required
                placeholder="Show off product unboxing, sizing, or live drop promo..."
                className="mt-1 h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-xs outline-none"
              />
            </div>
            <div className="flex gap-2">
              <button type="submit" className="rounded-xl bg-[#0E6B38] px-4 py-2 text-xs font-black text-white">
                Publish to For You Feed
              </button>
              <button
                type="button"
                onClick={() => setShowVideoComposer(false)}
                className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {galleryVideos.map((vid) => (
            <button
              key={vid.id}
              type="button"
              onClick={() => navigateTo('for-you')}
              className="group relative aspect-[9/14] overflow-hidden rounded-2xl border border-slate-200 bg-slate-900 text-left"
            >
              <img
                src={vid.posterUrl}
                alt={vid.caption}
                className="h-full w-full object-cover group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
              <div className="absolute right-2.5 top-2.5 rounded-full bg-black/50 p-1.5 text-white">
                <Play size={12} className="fill-white" />
              </div>
              <div className="absolute bottom-2.5 left-2.5 right-2.5 text-white">
                <p className="line-clamp-2 text-[11px] font-bold">{vid.caption}</p>
                <span className="text-[10px] font-semibold text-emerald-300">
                  ♥ {vid.likesCount.toLocaleString()}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* SELLER SPECIFIC SECTION */}
      {currentUser.role === 'seller' && (
        <div className="rounded-3xl border border-orange-200 bg-gradient-to-br from-orange-50 via-white to-orange-50/40 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FF6B00] text-white shadow">
                <Store size={20} />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900">Seller Centre Management</h3>
                <p className="text-[11px] text-slate-500">
                  Manage inventory, livestream drops, orders, and settlements
                </p>
              </div>
            </div>
            <button
              onClick={() => navigateTo('seller-dashboard')}
              className="rounded-xl bg-[#0E6B38] px-4 py-2 text-xs font-black text-white hover:bg-[#084B26]"
            >
              Open Seller Centre
            </button>
          </div>
        </div>
      )}

      {/* Saved Delivery Addresses with all 37 Nigerian States */}
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm font-black text-slate-900">
            <MapPin size={18} className="text-[#0E6B38]" />
            <span>Saved Nigerian Delivery Addresses ({addresses.length})</span>
          </div>
          <button
            onClick={() => setShowAddressForm(!showAddressForm)}
            className="flex items-center gap-1.5 rounded-xl bg-[#0E6B38] px-4 py-2 text-xs font-bold text-white hover:bg-[#084B26] transition"
          >
            <Plus size={14} /> Add Address
          </button>
        </div>

        {showAddressForm && (
          <form onSubmit={handleSaveAddress} className="rounded-2xl border border-dashed border-emerald-300 bg-emerald-50/40 p-5 space-y-3">
            <h4 className="text-xs font-black text-[#0E6B38]">New Delivery Location</h4>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="text-[11px] font-bold text-slate-700">Recipient Name</label>
                <input
                  type="text"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  required
                  className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none bg-white"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700">Phone</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none bg-white"
                />
              </div>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-700">Street Address</label>
              <input
                type="text"
                value={line}
                onChange={(e) => setLine(e.target.value)}
                required
                placeholder="Plot / Street / Building number"
                className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none bg-white"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700">City / LGA</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  required
                  className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none bg-white"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700">State (All 37 Nigerian States)</label>
                <select
                  value={state}
                  onChange={(e) => {
                    setState(e.target.value);
                    setSelectedState(e.target.value);
                  }}
                  className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none bg-white"
                >
                  {NIGERIAN_STATES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="submit"
                className="rounded-xl bg-[#0E6B38] px-5 py-2 text-xs font-black text-white hover:bg-[#084B26]"
              >
                Save
              </button>
              <button
                type="button"
                onClick={() => setShowAddressForm(false)}
                className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 bg-white"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        <div className="grid gap-4 sm:grid-cols-2">
          {addresses.map((addr) => (
            <div
              key={addr.id}
              className="rounded-2xl border border-slate-200 bg-white p-4 space-y-2 relative"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-900">{addr.recipient}</span>
                <div className="flex items-center gap-2">
                  {addr.isDefault && (
                    <span className="rounded bg-emerald-100 px-2 py-0.5 text-[9px] font-bold text-emerald-800">
                      DEFAULT
                    </span>
                  )}
                  {addresses.length > 1 && (
                    <button
                      onClick={() => deleteAddress(addr.id)}
                      className="text-slate-400 hover:text-rose-600 transition"
                      title="Delete"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">{addr.line}</p>
              <div className="text-xs font-bold text-slate-800">{addr.city}, {addr.state}</div>
              <div className="text-[11px] text-slate-400">{addr.phone}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Account Security Banner */}
      <div className="rounded-3xl border border-emerald-200 bg-[#EAF7EF]/60 p-5 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 text-xs">
          <ShieldCheck size={22} className="text-[#0E6B38] shrink-0" />
          <div>
            <div className="font-black text-slate-900">Account & Session Synchronization</div>
            <p className="text-slate-600">
              Web and Android share unified Cloudflare Workers D1 identity, wishlist, follows, orders, and livestream state.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => navigateTo('email-marketing')}
          className="shrink-0 rounded-xl bg-white border border-slate-200 px-4 py-2 text-xs font-bold text-slate-800 hover:bg-slate-50"
        >
          Email Studio
        </button>
      </div>
    </div>
  );
}
