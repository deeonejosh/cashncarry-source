import React, { useState } from 'react';
import { useStore } from '../../../context/StoreContext';
import { ShieldCheck, Upload, FileText, CheckCircle2, Clock, AlertTriangle, Lock, Cpu } from 'lucide-react';

export default function SellerKYCPage() {
  const { currentUser, kycSubmissions, submitKYC, stagingConfig, showToast } = useStore();
  const kycUploadsEnabled = stagingConfig.kycUploadsEnabled;

  const mySubmission = kycSubmissions.find((s) => s.sellerId === currentUser.id);

  const [cacNumber, setCacNumber] = useState('RC-1849203');
  const [businessName, setBusinessName] = useState('Olaoluwa Fashion Enterprises Ltd');
  const [fileName, setFileName] = useState('CAC_Certificate_2026.pdf');
  const [isUploading, setIsUploading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!kycUploadsEnabled) {
      showToast('KYC document uploads temporarily unavailable until private R2 storage is configured');
      return;
    }
    if (!cacNumber || !businessName || !fileName) {
      showToast('Please fill all business verification fields');
      return;
    }

    setIsUploading(true);
    try {
      await submitKYC(cacNumber, businessName, fileName);
    } catch (err: any) {
      showToast(err?.message || 'KYC upload unavailable in staging');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {!kycUploadsEnabled && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-900">
          <AlertTriangle size={18} className="shrink-0 text-amber-700 mt-0.5" />
          <div>
            <div className="font-black">KYC document uploads temporarily unavailable</div>
            <p className="text-amber-800 mt-0.5">
              Private R2 storage and malware scanning are disabled in staging (KYC_UPLOADS_ENABLED=false). No simulated scan or upload will mark your account verified.
            </p>
          </div>
        </div>
      )}

      {/* Banner */}
      <div className="rounded-3xl bg-[#0c5c36] p-8 text-white shadow-lg space-y-2">
        <div className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-xs font-black uppercase text-emerald-200">
          <ShieldCheck size={14} />
          <span>CORPORATE AFFAIRS COMMISSION (CAC) VERIFICATION</span>
        </div>
        <h1 className="text-2xl font-black sm:text-3xl">Seller Identity & Business Verification</h1>
        <p className="max-w-xl text-xs text-emerald-100 sm:text-sm">
          All sellers on Cash N Carry Nigeria are verified against official Nigerian business registries.
          When enabled, documents are scanned for malware using ClamAV and stored in private AES-256-GCM encrypted R2 storage.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* Verification Status Card */}
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-3">
            Current Verification Status
          </h3>

          {mySubmission?.status === 'verified' ? (
            <div className="rounded-2xl bg-emerald-50 p-5 text-center space-y-2 border border-emerald-200">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-[#0c5c36]">
                <CheckCircle2 size={28} />
              </div>
              <h4 className="text-sm font-black text-emerald-900">CAC Verified Vendor (Fixture)</h4>
              <p className="text-xs text-emerald-800">
                Staging fixture status for UI preview only.
              </p>
              <div className="mt-2 text-[11px] font-mono text-emerald-700 font-bold">
                CAC Ref: {mySubmission.cacNumber}
              </div>
            </div>
          ) : mySubmission?.status === 'pending' ? (
            <div className="rounded-2xl bg-amber-50 p-5 text-center space-y-2 border border-amber-200">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 text-amber-800">
                <Clock size={28} />
              </div>
              <h4 className="text-sm font-black text-amber-900">Under Admin Review</h4>
              <p className="text-xs text-amber-800">
                Awaiting compliance officer approval once KYC uploads are enabled.
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-slate-50 p-5 text-center space-y-2">
              <h4 className="text-sm font-black text-slate-700">Verification Pending</h4>
              <p className="text-xs text-slate-500">
                Submit your official CAC certificate when private R2 storage is active.
              </p>
            </div>
          )}

          {/* Encryption & Security Protocol Checklist */}
          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
            <div className="font-bold text-slate-800">Security Safeguards:</div>
            <div className="flex items-center gap-2 text-emerald-800 text-[11px]">
              <CheckCircle2 size={13} className="text-emerald-600" />
              <span>ClamAV INSTREAM Antivirus Scanning</span>
            </div>
            <div className="flex items-center gap-2 text-emerald-800 text-[11px]">
              <CheckCircle2 size={13} className="text-emerald-600" />
              <span>Authenticated AES-256-GCM Envelope Encryption</span>
            </div>
            <div className="flex items-center gap-2 text-emerald-800 text-[11px]">
              <CheckCircle2 size={13} className="text-emerald-600" />
              <span>Strict 5 MiB File Size Limit</span>
            </div>
            <div className="flex items-center gap-2 text-emerald-800 text-[11px]">
              <CheckCircle2 size={13} className="text-emerald-600" />
              <span>Restricted Administrator-Only Access</span>
            </div>
          </div>
        </div>

        {/* KYC Submission Form (2 Cols) */}
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4 lg:col-span-2">
          <h3 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-3">
            Submit Corporate Registration Documents
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="font-bold text-slate-700">Registered Business Name</label>
                <input
                  type="text"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  required
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700">CAC Registration (RC or BN Number)</label>
                <input
                  type="text"
                  value={cacNumber}
                  onChange={(e) => setCacNumber(e.target.value)}
                  required
                  placeholder="RC-123456 or BN-789012"
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none focus:border-emerald-600"
                />
              </div>
            </div>

            {/* Document File Selector */}
            <div>
              <label className="font-bold text-slate-700">CAC Certificate Document (PDF Only, Max 5MB)</label>
              <div className="mt-2 flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-emerald-300 bg-emerald-50/40 p-6 text-center space-y-2">
                <FileText size={32} className="text-[#0c5c36]" />
                <div className="text-xs font-bold text-slate-900">{fileName}</div>
                <div className="text-[11px] text-slate-400">PDF Document · Validated MIME type: application/pdf</div>
                <button
                  type="button"
                  disabled={!kycUploadsEnabled}
                  onClick={() => setFileName('CAC_Form_CAC7_Updated.pdf')}
                  className="rounded-xl border border-[#0c5c36] bg-white px-3 py-1.5 text-xs font-bold text-[#0c5c36] hover:bg-emerald-50 disabled:opacity-50"
                >
                  Change Sample File
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isUploading || !kycUploadsEnabled}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Upload size={15} />
              <span>
                {!kycUploadsEnabled
                  ? 'KYC Uploads Disabled in Staging'
                  : isUploading
                    ? 'Uploading to Private R2...'
                    : 'Submit CAC Document for Verification'}
              </span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
