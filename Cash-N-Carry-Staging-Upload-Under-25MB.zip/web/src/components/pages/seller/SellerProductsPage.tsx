import React, { useState } from 'react';
import { useStore } from '../../../context/StoreContext';
import { ProductItem } from '../../../types';
import { Plus, Edit, Archive, Eye, CheckCircle2, Clock, FileText, X } from 'lucide-react';

export default function SellerProductsPage() {
  const { currentUser, products, sellerAddProduct, sellerUpdateProduct, showToast } = useStore();

  const sellerProducts = products.filter((p) => p.sellerId === currentUser.id);

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [brand, setBrand] = useState(currentUser.storeName || 'Olaoluwa Trends');
  const [price, setPrice] = useState(15000);
  const [compareAt, setCompareAt] = useState(18000);
  const [stock, setStock] = useState(10);
  const [category, setCategory] = useState('fashion');
  const [badge, setBadge] = useState('New');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState(
    'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80'
  );
  const [publication, setPublication] = useState<'draft' | 'pending' | 'published'>('pending');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || price <= 0 || stock <= 0) {
      showToast('Please fill all required fields');
      return;
    }

    sellerAddProduct({
      title,
      brand,
      price,
      compareAt,
      stock,
      category,
      badge,
      description: description || 'Authentic product sourced in Nigeria.',
      image,
      publication,
    });

    setShowAddModal(false);
    setTitle('');
  };

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    sellerUpdateProduct(editingProduct.id, {
      title: editingProduct.title,
      price: editingProduct.price,
      stock: editingProduct.stock,
      publication: editingProduct.publication,
    });
    setEditingProduct(null);
  };

  return (
    <div className="space-y-6 pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 sm:text-3xl">Manage Products & Inventory</h1>
          <p className="mt-1 text-xs text-slate-500">
            Create, edit and submit listings to the Cash N Carry admin moderation queue.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 rounded-2xl bg-[#0c5c36] px-5 py-2.5 text-xs font-black text-white hover:bg-emerald-900 shadow transition"
        >
          <Plus size={16} />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Product List */}
      <div className="overflow-x-auto rounded-3xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-slate-100 bg-slate-50 text-[11px] font-black uppercase text-slate-400">
            <tr>
              <th className="py-3 px-4">Product</th>
              <th className="py-3 px-4">Price (NGN)</th>
              <th className="py-3 px-4">Stock</th>
              <th className="py-3 px-4">Category</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sellerProducts.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-slate-400">
                  No products added yet. Click "Add New Product" to list your first item.
                </td>
              </tr>
            ) : (
              sellerProducts.map((prod) => (
                <tr key={prod.id} className="hover:bg-slate-50/60 transition">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <img src={prod.image} alt={prod.title} className="h-12 w-12 rounded-xl object-cover border border-slate-100 shrink-0" />
                      <div>
                        <div className="font-bold text-slate-900 line-clamp-1">{prod.title}</div>
                        <div className="text-[10px] text-slate-400">{prod.brand}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                    ₦{prod.price.toLocaleString('en-NG')}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`font-bold ${prod.stock <= 3 ? 'text-rose-600' : 'text-slate-700'}`}>
                      {prod.stock} units
                    </span>
                  </td>
                  <td className="py-3.5 px-4 capitalize text-slate-600 font-semibold">{prod.category}</td>
                  <td className="py-3.5 px-4">
                    {prod.publication === 'published' && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-bold text-emerald-800">
                        <CheckCircle2 size={11} /> Published
                      </span>
                    )}
                    {prod.publication === 'pending' && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-0.5 text-[10px] font-bold text-amber-800">
                        <Clock size={11} /> In Moderation
                      </span>
                    )}
                    {prod.publication === 'draft' && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-0.5 text-[10px] font-bold text-slate-600">
                        Draft
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setEditingProduct(prod)}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                        title="Edit product"
                      >
                        <Edit size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div
            className="flex h-[90vh] w-full max-w-xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 p-5">
              <h3 className="text-base font-black text-slate-900">Add New Marketplace Listing</h3>
              <button onClick={() => setShowAddModal(false)}>
                <X size={18} className="text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700">Product Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  placeholder="e.g. Ankara Print Silk Dress"
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none focus:border-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700">Price in Naira (₦)</label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    required
                    className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">Compare-At Price (₦)</label>
                  <input
                    type="number"
                    value={compareAt}
                    onChange={(e) => setCompareAt(Number(e.target.value))}
                    className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700">Available Stock (Units)</label>
                  <input
                    type="number"
                    value={stock}
                    onChange={(e) => setStock(Number(e.target.value))}
                    required
                    min={1}
                    className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none bg-white"
                  >
                    <option value="fashion">Fashion & Apparel</option>
                    <option value="tech">Tech & Electronics</option>
                    <option value="beauty">Beauty & Cosmetics</option>
                    <option value="food">Food & Grocery</option>
                    <option value="home">Home & Kitchen</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700">Product Image URL</label>
                <input
                  type="url"
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                  required
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700">Description</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detailed product specifications, materials, and care instructions..."
                  className="mt-1 w-full rounded-xl border border-slate-200 p-3 outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700">Submission Workflow</label>
                <select
                  value={publication}
                  onChange={(e: any) => setPublication(e.target.value)}
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none bg-white font-bold"
                >
                  <option value="pending">Submit to Admin Moderation Queue (Recommended)</option>
                  <option value="draft">Save as Seller Draft</option>
                  <option value="published">Direct Publish (Staging Bypass)</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow-lg"
                >
                  Submit Listing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div
            className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900">Edit Product</h3>
              <button onClick={() => setEditingProduct(null)}>✕</button>
            </div>

            <form onSubmit={handleUpdate} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700">Product Title</label>
                <input
                  type="text"
                  value={editingProduct.title}
                  onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700">Price (₦)</label>
                  <input
                    type="number"
                    value={editingProduct.price}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">Stock (Units)</label>
                  <input
                    type="number"
                    value={editingProduct.stock}
                    onChange={(e) => setEditingProduct({ ...editingProduct, stock: Number(e.target.value) })}
                    className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700">Status</label>
                <select
                  value={editingProduct.publication}
                  onChange={(e: any) => setEditingProduct({ ...editingProduct, publication: e.target.value })}
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 outline-none bg-white font-bold"
                >
                  <option value="published">Published</option>
                  <option value="pending">In Moderation (Pending)</option>
                  <option value="draft">Draft</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full rounded-2xl bg-[#0c5c36] py-3 text-xs font-black text-white hover:bg-emerald-900 transition"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
