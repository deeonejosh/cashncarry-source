import React from 'react';
import { useStore } from '../../../context/StoreContext';
import {
  Store,
  Package,
  Plus,
  Radio,
  Gavel,
  ShieldCheck,
  TrendingUp,
  DollarSign,
  AlertCircle,
  Truck,
  CheckCircle2,
} from 'lucide-react';

interface SellerDashboardProps {
  onNavigate: (tab: string) => void;
}

export default function SellerDashboardPage({ onNavigate }: SellerDashboardProps) {
  const { currentUser, products, orders } = useStore();

  const sellerProducts = products.filter((p) => p.sellerId === currentUser.id);
  const sellerOrders = orders.filter((o) =>
    o.items.some((i) => i.sellerId === currentUser.id)
  );

  const totalRevenue = sellerOrders
    .filter((o) => o.status === 'paid' || o.status === 'shipped' || o.status === 'delivered')
    .reduce((acc, o) => acc + o.total, 0);

  const pendingFulfillments = sellerOrders.filter((o) => o.status === 'paid').length;
  const publishedCount = sellerProducts.filter((p) => p.publication === 'published').length;
  const pendingReviewCount = sellerProducts.filter((p) => p.publication === 'pending').length;

  return (
    <div className="space-y-8 pb-16">
      {/* Seller Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-3xl bg-gradient-to-r from-[#0c5c36] to-[#073c22] p-8 text-white shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-white/20 px-3 py-1 text-[10px] font-black uppercase text-emerald-200">
              SELLER CENTRE DASHBOARD
            </span>
            <span className="flex items-center gap-1 text-xs font-bold text-emerald-300">
              <CheckCircle2 size={13} /> CAC Verified Merchant
            </span>
          </div>
          <h1 className="text-2xl font-black sm:text-3xl">
            {currentUser.storeName || currentUser.name}
          </h1>
          <p className="text-xs text-emerald-100 sm:text-sm">
            Manage your catalog inventory, fulfill buyer orders, broadcast live commerce, and monitor settlements.
          </p>
        </div>

        {/* Quick Launch Buttons */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => onNavigate('seller-products')}
            className="flex items-center gap-1.5 rounded-2xl bg-orange-500 px-4 py-2.5 text-xs font-black text-white hover:bg-orange-600 transition shadow"
          >
            <Plus size={15} /> Add Product
          </button>
          <button
            onClick={() => onNavigate('live')}
            className="flex items-center gap-1.5 rounded-2xl bg-rose-600 px-4 py-2.5 text-xs font-black text-white hover:bg-rose-700 transition shadow"
          >
            <Radio size={15} /> Go Live (WHIP)
          </button>
        </div>
      </div>

      {/* Real Analytics Metrics (No invented data) */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Total Settled Revenue</div>
          <div className="text-2xl font-black text-[#0c5c36]">
            ₦{totalRevenue.toLocaleString('en-NG')}
          </div>
          <div className="text-[11px] text-slate-500">From verified paid orders</div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Pending Fulfillment</div>
          <div className="text-2xl font-black text-orange-600">{pendingFulfillments}</div>
          <div className="text-[11px] text-slate-500">Orders ready to dispatch</div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Published Products</div>
          <div className="text-2xl font-black text-slate-900">{publishedCount}</div>
          <div className="text-[11px] text-slate-500">Active in marketplace</div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Moderation Queue</div>
          <div className="text-2xl font-black text-amber-600">{pendingReviewCount}</div>
          <div className="text-[11px] text-slate-500">Awaiting admin review</div>
        </div>
      </div>

      {/* Navigation Modules Tabs */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <button
          onClick={() => onNavigate('seller-products')}
          className="flex flex-col items-start rounded-2xl border border-slate-200 bg-white p-4 text-left hover:border-emerald-500 transition shadow-sm"
        >
          <Package className="text-[#0c5c36]" size={22} />
          <span className="mt-2 text-xs font-black text-slate-900">Products & Inventory</span>
          <span className="text-[11px] text-slate-400">Manage listings & prices</span>
        </button>

        <button
          onClick={() => onNavigate('seller-orders')}
          className="flex flex-col items-start rounded-2xl border border-slate-200 bg-white p-4 text-left hover:border-emerald-500 transition shadow-sm"
        >
          <Truck className="text-blue-600" size={22} />
          <span className="mt-2 text-xs font-black text-slate-900">Order Dispatch</span>
          <span className="text-[11px] text-slate-400">Pack & add tracking</span>
        </button>

        <button
          onClick={() => onNavigate('seller-kyc')}
          className="flex flex-col items-start rounded-2xl border border-slate-200 bg-white p-4 text-left hover:border-emerald-500 transition shadow-sm"
        >
          <ShieldCheck className="text-purple-600" size={22} />
          <span className="mt-2 text-xs font-black text-slate-900">KYC & CAC Verification</span>
          <span className="text-[11px] text-slate-400">ClamAV scan & encryption</span>
        </button>

        <button
          onClick={() => onNavigate('seller-settlements')}
          className="flex flex-col items-start rounded-2xl border border-slate-200 bg-white p-4 text-left hover:border-emerald-500 transition shadow-sm"
        >
          <DollarSign className="text-amber-600" size={22} />
          <span className="mt-2 text-xs font-black text-slate-900">Payout Settlements</span>
          <span className="text-[11px] text-slate-400">Draft payouts & bank details</span>
        </button>
      </div>

      {/* Recent Orders Table */}
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-sm font-black text-slate-900">Recent Customer Orders</h3>
          <button
            onClick={() => onNavigate('seller-orders')}
            className="text-xs font-bold text-[#0c5c36] hover:underline"
          >
            View all seller orders →
          </button>
        </div>

        {sellerOrders.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            No orders placed yet for your storefront.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {sellerOrders.slice(0, 5).map((order) => (
              <div key={order.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-3 text-xs">
                <div>
                  <span className="font-mono font-bold text-slate-900">{order.id}</span>
                  <div className="text-slate-500 text-[11px]">Buyer: {order.buyerName}</div>
                </div>
                <div className="text-slate-600 font-bold">
                  ₦{order.total.toLocaleString('en-NG')}
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-bold text-emerald-800">
                    {order.status.toUpperCase()}
                  </span>
                  <button
                    onClick={() => onNavigate('seller-orders')}
                    className="text-xs font-bold text-[#0c5c36] hover:underline"
                  >
                    Fulfill
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
