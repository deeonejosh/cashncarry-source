import React, { useState } from 'react';
import { useStore } from '../../../context/StoreContext';
import { DollarSign, Building2, CheckCircle2, ArrowUpRight, ShieldCheck, Plus, AlertTriangle } from 'lucide-react';

export default function SellerSettlementsPage() {
  const { currentUser, orders, stagingConfig, showToast } = useStore();
  const paymentsEnabled = stagingConfig.paymentsEnabled;

  const sellerOrders = orders.filter((o) =>
    o.items.some((i) => i.sellerId === currentUser.id) && (o.status === 'paid' || o.status === 'shipped' || o.status === 'delivered')
  );

  const totalEarned = sellerOrders.reduce((acc, o) => acc + o.total, 0);
  const platformFee = Math.round(totalEarned * 0.05); // 5% marketplace commission
  const netPayable = totalEarned - platformFee;

  const [payoutRequested, setPayoutRequested] = useState(false);

  const handleRequestPayout = () => {
    if (!paymentsEnabled) {
      showToast('Payments and financial settlements are temporarily unavailable in staging (PAYMENTS_ENABLED=false)');
      return;
    }
    if (netPayable <= 0) {
      showToast('No eligible earnings to draft for payout');
      return;
    }
    setPayoutRequested(true);
    showToast('Draft payout request logged! Transferred to Admin Payout Batch.');
  };

  return (
    <div className="space-y-8 pb-16">
      {!paymentsEnabled && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-900">
          <AlertTriangle size={18} className="shrink-0 text-amber-700 mt-0.5" />
          <div>
            <div className="font-black">Payments temporarily unavailable</div>
            <p className="text-amber-800 mt-0.5">
              Financial settlement and bank payout drafts are disabled in staging (PAYMENTS_ENABLED=false). Displayed figures reflect isolated UI test fixtures only.
            </p>
          </div>
        </div>
      )}

      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl font-black text-slate-900 sm:text-3xl">Settlements & Payouts</h1>
        <p className="mt-1 text-xs text-slate-500">
          Review captured gross order allocations, escrow releases, and payout eligibility (staging fixture view).
        </p>
      </div>

      {/* Balance Summary Card */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Gross Sales Captured</div>
          <div className="text-2xl font-black text-slate-900">₦{totalEarned.toLocaleString('en-NG')}</div>
          <div className="text-[11px] text-slate-400">Total volume from fixture orders</div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Marketplace Fee (5%)</div>
          <div className="text-2xl font-black text-slate-500">₦{platformFee.toLocaleString('en-NG')}</div>
          <div className="text-[11px] text-slate-400">Platform infrastructure & escrow fees</div>
        </div>

        <div className="rounded-3xl border border-emerald-200 bg-emerald-50/60 p-6 shadow-sm space-y-1">
          <div className="text-xs font-bold text-emerald-800">Net Eligible Balance</div>
          <div className="text-2xl font-black text-[#0c5c36]">₦{netPayable.toLocaleString('en-NG')}</div>
          <div className="text-[11px] text-emerald-700">Disabled until live payment settlement</div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* Payout Action & Bank Info */}
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-sm font-black text-slate-900 border-b border-slate-100 pb-3">
            <Building2 size={18} className="text-[#0c5c36]" />
            <span>Settlement Bank Account</span>
          </div>

          <div className="rounded-2xl bg-slate-50 p-4 border border-slate-200 space-y-1 text-xs">
            <div className="text-slate-500 font-semibold">Bank Name:</div>
            <div className="font-black text-slate-900 text-sm">Zenith Bank Nigeria PLC</div>
            <div className="text-slate-500 font-semibold pt-1">Account Number:</div>
            <div className="font-mono font-black text-slate-900">1018294821</div>
            <div className="text-slate-500 font-semibold pt-1">Account Name:</div>
            <div className="font-bold text-slate-800">Olaoluwa Trends Ltd</div>
          </div>

          <button
            onClick={handleRequestPayout}
            disabled={!paymentsEnabled || payoutRequested || netPayable <= 0}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowUpRight size={16} />
            <span>
              {!paymentsEnabled
                ? 'Payouts Disabled (PAYMENTS_ENABLED=false)'
                : payoutRequested
                  ? 'Payout Draft Submitted (Pending Admin Batch)'
                  : 'Request Payout Draft'}
            </span>
          </button>
        </div>

        {/* Orders Allocations Table (2 Cols) */}
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900">Eligible Order Settlements</h3>
            <span className="text-xs text-slate-400">{sellerOrders.length} Completed Orders</span>
          </div>

          {sellerOrders.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              No orders eligible for settlement yet.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 text-xs">
              {sellerOrders.map((o) => (
                <div key={o.id} className="flex items-center justify-between py-3">
                  <div>
                    <div className="font-bold text-slate-900">{o.id}</div>
                    <div className="text-[11px] text-slate-400">Buyer: {o.buyerName}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-black text-[#0c5c36]">₦{o.total.toLocaleString('en-NG')}</div>
                    <div className="text-[10px] text-slate-400">Fee: -₦{Math.round(o.total * 0.05).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
