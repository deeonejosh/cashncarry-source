import React, { useState } from 'react';
import { useStore } from '../../../context/StoreContext';
import { Order } from '../../../types';
import { Truck, CheckCircle2, Package, MapPin, Search } from 'lucide-react';

export default function SellerOrdersPage() {
  const { orders, sellerFulfillOrder, currentUser, showToast } = useStore();

  const sellerOrders = orders.filter((o) =>
    o.items.some((i) => i.sellerId === currentUser.id)
  );

  const [dispatchingOrderId, setDispatchingOrderId] = useState<string | null>(null);
  const [carrier, setCarrier] = useState('GIG Logistics');
  const [trackingNumber, setTrackingNumber] = useState('GIG-LAG-' + Math.floor(100000 + Math.random() * 900000));

  const handleDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dispatchingOrderId) return;
    sellerFulfillOrder(dispatchingOrderId, trackingNumber, carrier);
    setDispatchingOrderId(null);
  };

  return (
    <div className="space-y-6 pb-16">
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl font-black text-slate-900 sm:text-3xl">Seller Order Fulfillment</h1>
        <p className="mt-1 text-xs text-slate-500">
          Process customer orders, pack items, and dispatch with verified Nigerian courier partners.
        </p>
      </div>

      <div className="space-y-4">
        {sellerOrders.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-slate-200 bg-white p-16 text-center text-slate-400">
            No customer orders received yet.
          </div>
        ) : (
          sellerOrders.map((order) => (
            <div
              key={order.id}
              className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3 text-xs">
                <div>
                  <span className="text-slate-400">Order Ref: </span>
                  <span className="font-mono font-black text-slate-900">{order.id}</span>
                  <span className="text-slate-400 ml-2">· {new Date(order.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-emerald-100 px-3 py-1 font-bold text-emerald-800 uppercase text-[10px]">
                    Status: {order.status}
                  </span>
                </div>
              </div>

              {/* Items in this order */}
              <div className="divide-y divide-slate-100">
                {order.items
                  .filter((i) => i.sellerId === currentUser.id)
                  .map((item) => (
                    <div key={item.productId} className="flex items-center justify-between py-2 text-xs">
                      <div>
                        <div className="font-bold text-slate-900">{item.name}</div>
                        <div className="text-[11px] text-slate-400">Quantity: {item.quantity}</div>
                      </div>
                      <div className="font-mono font-bold text-slate-900">
                        ₦{(item.price * item.quantity).toLocaleString('en-NG')}
                      </div>
                    </div>
                  ))}
              </div>

              {/* Address info & Fulfillment Action */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-100 pt-3 text-xs">
                <div className="text-slate-500 text-[11px]">
                  <span>Ship To: </span>
                  <b className="text-slate-800">{order.address.recipient}</b> ({order.address.phone}) — {order.address.line}, {order.address.city}
                </div>

                <div>
                  {order.status === 'paid' && (
                    <button
                      onClick={() => {
                        setDispatchingOrderId(order.id);
                        setTrackingNumber('GIG-LAG-' + Math.floor(100000 + Math.random() * 900000));
                      }}
                      className="flex items-center gap-1.5 rounded-xl bg-[#0c5c36] px-4 py-2 font-black text-white hover:bg-emerald-900 transition shadow"
                    >
                      <Truck size={14} />
                      <span>Dispatch Package</span>
                    </button>
                  )}
                  {order.status === 'shipped' && (
                    <div className="flex items-center gap-2 text-emerald-800 font-bold">
                      <CheckCircle2 size={15} />
                      <span>Dispatched via {order.carrier} ({order.trackingNumber})</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Dispatch Modal */}
      {dispatchingOrderId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div
            className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900">Dispatch Order {dispatchingOrderId}</h3>
              <button onClick={() => setDispatchingOrderId(null)}>✕</button>
            </div>

            <form onSubmit={handleDispatch} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700">Courier Partner</label>
                <select
                  value={carrier}
                  onChange={(e) => setCarrier(e.target.value)}
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 font-bold bg-white"
                >
                  <option>GIG Logistics</option>
                  <option>Kwik Delivery</option>
                  <option>DHL Express Nigeria</option>
                  <option>Red Star Express</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700">Waybill / Tracking Number</label>
                <input
                  type="text"
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  required
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 font-mono text-xs outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full rounded-2xl bg-[#0c5c36] py-3 text-xs font-black text-white hover:bg-emerald-900 transition"
              >
                Confirm Dispatch & Notify Buyer
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
