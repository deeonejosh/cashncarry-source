import React, { useState } from 'react';
import { ProductItem } from '../../types';
import { useStore } from '../../context/StoreContext';
import {
  Star,
  ShoppingBag,
  Heart,
  Truck,
  ShieldCheck,
  RotateCcw,
  CheckCircle2,
  ChevronLeft,
  Share2,
  MessageCircle,
  Plus,
  Minus,
} from 'lucide-react';

interface ProductDetailsPageProps {
  product: ProductItem;
  onBack: () => void;
  onSelectProduct: (p: ProductItem) => void;
  onProceedToCheckout: () => void;
}

export default function ProductDetailsPage({
  product,
  onBack,
  onSelectProduct,
  onProceedToCheckout,
}: ProductDetailsPageProps) {
  const { addToCart, wishlist, toggleWishlist, products, sendMessage, showToast } = useStore();

  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'specs' | 'shipping' | 'reviews'>('description');
  const isWishlisted = wishlist.includes(product.id);

  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const discountPercent = product.compareAt > product.price
    ? Math.round(((product.compareAt - product.price) / product.compareAt) * 100)
    : null;

  const handleBuyNow = () => {
    addToCart(product, quantity);
    onProceedToCheckout();
  };

  const handleContactSeller = () => {
    sendMessage(product.sellerId, `Hello, I'm inquiring about ${product.title} (₦${product.price.toLocaleString()})`);
    showToast(`Sent inquiry to ${product.sellerName}`);
  };

  return (
    <div className="space-y-10 pb-16">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-[#0c5c36] transition"
      >
        <ChevronLeft size={16} />
        <span>Back to products</span>
      </button>

      {/* Main Product Showcase */}
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        {/* Left: Product Image */}
        <div className="space-y-4">
          <div className="relative aspect-square w-full overflow-hidden rounded-3xl bg-slate-100 border border-slate-200 shadow-md">
            <img
              src={product.image}
              alt={product.title}
              className="h-full w-full object-cover"
            />
            {discountPercent && (
              <span className="absolute left-4 top-4 rounded-xl bg-orange-600 px-3 py-1 text-xs font-black text-white shadow-md">
                -{discountPercent}% OFF
              </span>
            )}
            <button
              onClick={() => toggleWishlist(product.id)}
              className="absolute right-4 top-4 rounded-full bg-white/90 p-3 text-slate-700 shadow-md hover:bg-white transition"
            >
              <Heart size={20} className={isWishlisted ? 'fill-rose-500 text-rose-500' : ''} />
            </button>
          </div>
        </div>

        {/* Right: Product Details & Actions */}
        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="uppercase tracking-wider text-slate-400">{product.brand}</span>
              <span className="flex items-center gap-1 text-emerald-800">
                <CheckCircle2 size={14} className="text-emerald-600" />
                Verified Merchant
              </span>
            </div>

            <h1 className="mt-2 text-2xl font-black text-slate-900 sm:text-3xl leading-snug">
              {product.title}
            </h1>

            {/* Ratings & SKU */}
            <div className="mt-3 flex items-center gap-3 text-xs">
              <div className="flex items-center text-amber-500 font-extrabold">
                <Star size={15} className="fill-amber-400" />
                <span className="ml-1 text-slate-900">{product.rating}</span>
              </div>
              <span className="text-slate-400">·</span>
              <span className="font-semibold text-slate-600">{product.reviews} customer reviews</span>
              <span className="text-slate-400">·</span>
              <span className="font-mono text-slate-400 text-[11px]">SKU: {product.slug}</span>
            </div>
          </div>

          {/* Pricing Box */}
          <div className="rounded-2xl bg-emerald-50/60 p-4 border border-emerald-100 flex items-baseline justify-between">
            <div>
              <div className="text-xs font-semibold text-slate-500">Price in Naira (NGN):</div>
              <div className="mt-1 flex items-baseline gap-3">
                <span className="text-3xl font-black text-slate-900">
                  ₦{product.price.toLocaleString('en-NG')}
                </span>
                {product.compareAt > product.price && (
                  <span className="text-base text-slate-400 line-through">
                    ₦{product.compareAt.toLocaleString('en-NG')}
                  </span>
                )}
              </div>
            </div>

            <div className="text-right">
              <span className="inline-block rounded-full bg-emerald-600 px-3 py-1 text-[11px] font-black text-white">
                In Stock ({product.stock} units)
              </span>
            </div>
          </div>

          {/* Quantity Selector & Purchase CTAs */}
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-4">
              <span className="text-xs font-bold text-slate-700">Quantity:</span>
              <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 p-1">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="rounded-lg p-2 text-slate-600 hover:bg-white transition"
                >
                  <Minus size={14} />
                </button>
                <span className="w-10 text-center font-black text-sm text-slate-900">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="rounded-lg p-2 text-slate-600 hover:bg-white transition"
                  disabled={quantity >= product.stock}
                >
                  <Plus size={14} />
                </button>
              </div>
              <span className="text-xs text-slate-400 font-medium">
                Total: <b>₦{(product.price * quantity).toLocaleString('en-NG')}</b>
              </span>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <button
                onClick={() => addToCart(product, quantity)}
                disabled={product.stock <= 0}
                className="flex items-center justify-center gap-2 rounded-2xl border-2 border-[#0c5c36] bg-emerald-50/50 py-3.5 text-xs font-black text-[#0c5c36] hover:bg-[#0c5c36] hover:text-white transition shadow-sm"
              >
                <ShoppingBag size={17} />
                <span>Add to Shopping Cart</span>
              </button>

              <button
                onClick={handleBuyNow}
                disabled={product.stock <= 0}
                className="flex items-center justify-center gap-2 rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow-lg"
              >
                <span>Instant Checkout</span>
              </button>
            </div>
          </div>

          {/* Seller Storefront Info Card */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-800 font-black text-white text-base">
                  {product.sellerName.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <h4 className="text-xs font-black text-slate-900">{product.sellerName}</h4>
                    <CheckCircle2 size={13} className="text-[#0c5c36]" />
                  </div>
                  <div className="text-[11px] text-slate-500">Verified Seller · Dispatch: Lagos</div>
                </div>
              </div>

              <button
                onClick={handleContactSeller}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 transition shadow-sm"
              >
                <MessageCircle size={14} />
                <span>Message</span>
              </button>
            </div>
          </div>

          {/* Guarantees Box */}
          <div className="grid grid-cols-3 gap-2 border-t border-slate-100 pt-4 text-center">
            <div className="p-2">
              <Truck size={18} className="mx-auto text-[#0c5c36]" />
              <div className="mt-1 text-[11px] font-bold text-slate-900">Fast Delivery</div>
              <div className="text-[10px] text-slate-400">1-3 Days in Lagos</div>
            </div>
            <div className="p-2">
              <ShieldCheck size={18} className="mx-auto text-[#0c5c36]" />
              <div className="mt-1 text-[11px] font-bold text-slate-900">Flutterwave Escrow</div>
              <div className="text-[10px] text-slate-400">100% Secure Payment</div>
            </div>
            <div className="p-2">
              <RotateCcw size={18} className="mx-auto text-[#0c5c36]" />
              <div className="mt-1 text-[11px] font-bold text-slate-900">7-Day Returns</div>
              <div className="text-[10px] text-slate-400">Money-back Guarantee</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs: Description, Specs, Shipping, Reviews */}
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex border-b border-slate-100 pb-3 gap-6 text-xs font-black">
          <button
            onClick={() => setActiveTab('description')}
            className={`pb-2 border-b-2 transition ${
              activeTab === 'description' ? 'border-[#0c5c36] text-[#0c5c36]' : 'border-transparent text-slate-500'
            }`}
          >
            Product Overview
          </button>
          <button
            onClick={() => setActiveTab('specs')}
            className={`pb-2 border-b-2 transition ${
              activeTab === 'specs' ? 'border-[#0c5c36] text-[#0c5c36]' : 'border-transparent text-slate-500'
            }`}
          >
            Specifications
          </button>
          <button
            onClick={() => setActiveTab('shipping')}
            className={`pb-2 border-b-2 transition ${
              activeTab === 'shipping' ? 'border-[#0c5c36] text-[#0c5c36]' : 'border-transparent text-slate-500'
            }`}
          >
            Delivery & Returns
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`pb-2 border-b-2 transition ${
              activeTab === 'reviews' ? 'border-[#0c5c36] text-[#0c5c36]' : 'border-transparent text-slate-500'
            }`}
          >
            Reviews ({product.reviews})
          </button>
        </div>

        <div className="pt-6 text-xs leading-relaxed text-slate-600">
          {activeTab === 'description' && (
            <div className="space-y-3">
              <p className="text-sm font-bold text-slate-900">{product.title}</p>
              <p>{product.description}</p>
              <p>
                All items sold on Cash N Carry Nigeria are sourced directly from registered businesses and verified
                manufacturers. Each package is inspected prior to carrier pickup.
              </p>
            </div>
          )}

          {activeTab === 'specs' && (
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2 border-b border-slate-100 py-2">
                <span className="font-bold text-slate-800">Brand</span>
                <span>{product.brand}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 border-b border-slate-100 py-2">
                <span className="font-bold text-slate-800">Category</span>
                <span className="capitalize">{product.category}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 border-b border-slate-100 py-2">
                <span className="font-bold text-slate-800">Authenticity Guarantee</span>
                <span className="text-emerald-700 font-bold">100% Genuine Nigerian Stock</span>
              </div>
            </div>
          )}

          {activeTab === 'shipping' && (
            <div className="space-y-3">
              <h4 className="font-black text-slate-800">Nationwide Logistics with GIG and DHL</h4>
              <p>
                Orders placed before 2:00 PM West Africa Time are dispatched same day. Delivery across Lagos takes
                24-48 hours. Other Nigerian states take 2-4 business days.
              </p>
              <p>
                Returns are accepted within 7 calendar days of delivery if the product remains in its original packaging.
              </p>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-4">
              <div className="flex items-center gap-4 rounded-2xl bg-amber-50/50 p-4 border border-amber-100">
                <div className="text-3xl font-black text-amber-600">{product.rating}</div>
                <div>
                  <div className="flex text-amber-400">★★★★★</div>
                  <div className="text-[11px] text-slate-500">Based on {product.reviews} verified buyer reviews</div>
                </div>
              </div>

              <div className="divide-y divide-slate-100 space-y-3">
                <div className="pt-3 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">Babajide A. (Lagos)</span>
                    <span className="text-[10px] text-slate-400">3 days ago</span>
                  </div>
                  <p>“Delivered on time and item is exactly as pictured. Very satisfied!”</p>
                </div>
                <div className="pt-3 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">Amina M. (Abuja)</span>
                    <span className="text-[10px] text-slate-400">1 week ago</span>
                  </div>
                  <p>“High quality product from a trustworthy seller. Will definitely buy again.”</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-black text-slate-900">Similar Products You May Like</h3>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {relatedProducts.map((p) => (
              <div
                key={p.id}
                onClick={() => {
                  onSelectProduct(p);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="cursor-pointer rounded-2xl border border-slate-200 bg-white p-3 shadow-sm hover:shadow-md transition"
              >
                <img src={p.image} alt={p.title} className="aspect-square w-full rounded-xl object-cover" />
                <h4 className="mt-2 text-xs font-bold text-slate-900 truncate">{p.title}</h4>
                <div className="mt-1 text-xs font-black text-[#0c5c36]">
                  ₦{p.price.toLocaleString('en-NG')}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
