import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { Order, Address } from '../../types';
import FlutterwaveModal from '../ui/FlutterwaveModal';
import {
  ShieldCheck,
  MapPin,
  Clock,
  Plus,
  ShoppingBag,
  CreditCard,
  Lock,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';

interface CheckoutPageProps {
  onSuccessOrder: (order: Order) => void;
  onBackToCart: () => void;
}

export default function CheckoutPage({ onSuccessOrder, onBackToCart }: CheckoutPageProps) {
  const {
    stagingConfig,
    cart,
    cartSubtotal,
    addresses,
    addAddress,
    createOrderFromCart,
    showToast,
  } = useStore();
  const paymentsEnabled = stagingConfig.paymentsEnabled;

  const [selectedAddressId, setSelectedAddressId] = useState<string>(
    addresses[0]?.id || ''
  );

  const [showNewAddressForm, setShowNewAddressForm] = useState(false);
  const [newRecipient, setNewRecipient] = useState('Chidi Okafor');
  const [newPhone, setNewPhone] = useState('+234 803 123 4567');
  const [newLine, setNewLine] = useState('14 Adeola Odeku Street, Victoria Island');
  const [newCity, setNewCity] = useState('Lagos');
  const [newState, setNewState] = useState('Lagos State');

  // Reservation countdown timer simulation (15 mins)
  const [timeLeft, setTimeLeft] = useState(15 * 60);

  // Active created order awaiting payment
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [flutterwaveModalOpen, setFlutterwaveModalOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const shipping = cartSubtotal > 50000 ? 0 : cart.length > 0 ? 2500 : 0;
  const total = cartSubtotal + shipping;

  const handleAddNewAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRecipient || !newLine || !newCity) {
      showToast('Please fill out all address fields');
      return;
    }
    const created = addAddress({
      recipient: newRecipient,
      phone: newPhone,
      line: newLine,
      city: newCity,
      state: newState,
    });
    setSelectedAddressId(created.id);
    setShowNewAddressForm(false);
  };

  const handleInitiateOrder = () => {
    if (!selectedAddressId) {
      showToast('Please select or add a delivery address');
      return;
    }

    const order = createOrderFromCart(selectedAddressId);
    if (order) {
      setCurrentOrder(order);
      if (paymentsEnabled) {
        setFlutterwaveModalOpen(true);
      } else {
        onSuccessOrder(order);
      }
    }
  };

  const handlePaymentSuccess = (_orderId: string, txRef: string) => {
    setFlutterwaveModalOpen(false);
    if (currentOrder && paymentsEnabled && txRef) {
      onSuccessOrder({
        ...currentOrder,
        status: 'paid',
        flutterwaveRef: txRef,
      });
    }
  };

  if (cart.length === 0 && !currentOrder) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <ShoppingBag size={48} className="text-slate-300" />
        <h2 className="mt-4 text-lg font-black text-slate-800">No items ready for checkout</h2>
        <button
          onClick={onBackToCart}
          className="mt-5 rounded-full bg-[#0c5c36] px-6 py-2.5 text-xs font-bold text-white hover:bg-emerald-900"
        >
          Return to Shop
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-16">
      {!paymentsEnabled && (
        <div className="flex items-start gap-3 rounded-2xl bg-rose-50 p-4 border border-rose-200 text-xs text-rose-900">
          <AlertCircle size={18} className="shrink-0 mt-0.5 text-rose-700" />
          <div>
            <div className="font-black text-sm">Payments temporarily unavailable</div>
            <p className="mt-0.5 text-rose-800">
              Flutterwave payment initiation and real checkout confirmation are disabled in private staging
              (<code className="font-mono">PAYMENTS_ENABLED=false</code>). You can inspect your cart, delivery
              addresses, and save an unpaid test order (<code className="font-mono">awaiting_payment</code>) for non-financial UI review.
            </p>
          </div>
        </div>
      )}

      {/* Reservation Expiry Notice */}
      <div className="flex items-center justify-between rounded-2xl bg-amber-50 p-4 border border-amber-200 text-xs text-amber-900">
        <div className="flex items-center gap-2">
          <Clock size={16} className="text-amber-700" />
          <span>
            <b>Inventory Reserved:</b> Items in your checkout are reserved for{' '}
            <span className="font-mono font-black text-amber-800">{formatTimer(timeLeft)}</span> before returning to stock.
          </span>
        </div>
        <span className="hidden sm:inline text-[11px] text-amber-700 font-semibold">
          D1 Migration 0008 Active
        </span>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* Left 2 Cols: Delivery Address & Payment Channel */}
        <div className="space-y-6 lg:col-span-2">
          {/* Address Section */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-black text-slate-900">
                <MapPin size={18} className="text-[#0c5c36]" />
                <span>1. Select Delivery Address (Nigeria)</span>
              </div>
              <button
                onClick={() => setShowNewAddressForm(!showNewAddressForm)}
                className="flex items-center gap-1 text-xs font-bold text-[#0c5c36] hover:underline"
              >
                <Plus size={14} /> Add New Address
              </button>
            </div>

            {/* Existing Addresses */}
            <div className="grid gap-3 sm:grid-cols-2">
              {addresses.map((addr) => (
                <div
                  key={addr.id}
                  onClick={() => setSelectedAddressId(addr.id)}
                  className={`cursor-pointer rounded-2xl border p-4 transition ${
                    selectedAddressId === addr.id
                      ? 'border-[#0c5c36] bg-emerald-50/40 shadow-sm'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-xs font-black text-slate-900">{addr.recipient}</span>
                    {addr.isDefault && (
                      <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[9px] font-bold text-slate-500">
                        DEFAULT
                      </span>
                    )}
                  </div>
                  <div className="mt-1 text-xs text-slate-600 leading-relaxed">{addr.line}</div>
                  <div className="mt-0.5 text-xs font-bold text-slate-700">{addr.city}, {addr.state}</div>
                  <div className="mt-1 text-[11px] text-slate-400">{addr.phone}</div>
                </div>
              ))}
            </div>

            {/* New Address Form */}
            {showNewAddressForm && (
              <form onSubmit={handleAddNewAddress} className="rounded-2xl border border-dashed border-emerald-300 bg-emerald-50/30 p-4 space-y-3">
                <h4 className="text-xs font-black text-[#0c5c36]">Add New Delivery Address</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700">Recipient Name</label>
                    <input
                      type="text"
                      value={newRecipient}
                      onChange={(e) => setNewRecipient(e.target.value)}
                      required
                      className="mt-1 h-9 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none focus:border-emerald-600"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-700">Phone (WhatsApp / Call)</label>
                    <input
                      type="text"
                      value={newPhone}
                      onChange={(e) => setNewPhone(e.target.value)}
                      required
                      className="mt-1 h-9 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none focus:border-emerald-600"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700">Street Address</label>
                  <input
                    type="text"
                    value={newLine}
                    onChange={(e) => setNewLine(e.target.value)}
                    required
                    className="mt-1 h-9 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none focus:border-emerald-600"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700">City</label>
                    <input
                      type="text"
                      value={newCity}
                      onChange={(e) => setNewCity(e.target.value)}
                      required
                      className="mt-1 h-9 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none focus:border-emerald-600"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-700">State</label>
                    <select
                      value={newState}
                      onChange={(e) => setNewState(e.target.value)}
                      className="mt-1 h-9 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none focus:border-emerald-600 bg-white"
                    >
                      <option>Lagos State</option>
                      <option>FCT Abuja</option>
                      <option>Rivers State</option>
                      <option>Oyo State</option>
                      <option>Kano State</option>
                      <option>Delta State</option>
                      <option>Edo State</option>
                      <option>Enugu State</option>
                      <option>Ogun State</option>
                    </select>
                  </div>
                </div>
                <div className="flex gap-2 pt-1">
                  <button
                    type="submit"
                    className="rounded-xl bg-[#0c5c36] px-4 py-2 text-xs font-black text-white hover:bg-emerald-900"
                  >
                    Save Address
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowNewAddressForm(false)}
                    className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Payment Method Selector */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-sm font-black text-slate-900">
              <CreditCard size={18} className="text-[#0c5c36]" />
              <span>2. Payment Gateway Integration</span>
            </div>

            <div className={`rounded-2xl border-2 p-4 ${paymentsEnabled ? 'border-[#0c5c36] bg-emerald-50/40' : 'border-amber-200 bg-amber-50/40'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-xl font-black text-white text-xs ${paymentsEnabled ? 'bg-[#0c5c36]' : 'bg-slate-500'}`}>
                    FLW
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-900">Flutterwave Payment Escrow</h4>
                    <p className="text-[11px] text-slate-500">
                      Card (Visa/Mastercard/Verve), Bank Transfer, or USSD in NGN
                    </p>
                  </div>
                </div>
                {paymentsEnabled ? (
                  <span className="rounded-full bg-emerald-100 px-3 py-1 text-[10px] font-black uppercase text-emerald-800">
                    SANDBOX ACTIVE
                  </span>
                ) : (
                  <span className="rounded-full bg-amber-100 px-3 py-1 text-[10px] font-black uppercase text-amber-900">
                    PAYMENTS DISABLED
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 text-[11px] text-slate-500">
              <ShieldCheck size={16} className="text-emerald-700" />
              <span>
                {paymentsEnabled
                  ? 'Protected under Flutterwave Sandbox Escrow. Funds are only settled to the merchant upon delivery confirmation.'
                  : 'Payments temporarily unavailable. Orders created in staging remain unpaid (awaiting_payment) until Flutterwave integration is enabled.'}
              </span>
            </div>
          </div>
        </div>

        {/* Right Col: Order Summary */}
        <div className="space-y-4">
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-3">
              Order Summary ({cart.length} items)
            </h3>

            {/* Items list */}
            <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 space-y-2 pr-1">
              {cart.map((item) => (
                <div key={item.productId} className="flex items-center justify-between gap-3 pt-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <img src={item.image} alt={item.title} className="h-10 w-10 rounded-lg object-cover shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-900 truncate">{item.title}</div>
                      <div className="text-[10px] text-slate-400">Qty: {item.quantity} × ₦{item.price.toLocaleString()}</div>
                    </div>
                  </div>
                  <div className="text-xs font-black text-slate-900 shrink-0">
                    ₦{(item.price * item.quantity).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>

            {/* Calculations */}
            <div className="space-y-2 border-t border-slate-100 pt-3 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span className="font-bold text-slate-900">₦{cartSubtotal.toLocaleString('en-NG')}</span>
              </div>
              <div className="flex justify-between">
                <span>Nationwide Shipping:</span>
                <span className="font-bold">
                  {shipping === 0 ? <span className="text-emerald-700">FREE</span> : `₦${shipping.toLocaleString()}`}
                </span>
              </div>
              <div className="flex justify-between border-t border-slate-100 pt-2 text-base font-black text-slate-900">
                <span>Total:</span>
                <span className="text-[#0c5c36]">₦{total.toLocaleString('en-NG')}</span>
              </div>
            </div>

            {/* Primary Checkout CTA */}
            {paymentsEnabled ? (
              <button
                onClick={handleInitiateOrder}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#0c5c36] py-4 text-xs font-black text-white shadow-xl transition hover:bg-emerald-900 hover:shadow-2xl"
              >
                <Lock size={15} />
                <span>Complete Payment with Flutterwave</span>
                <ArrowRight size={15} />
              </button>
            ) : (
              <div className="mt-4 space-y-2">
                <button
                  type="button"
                  disabled
                  className="flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-200 py-3.5 text-xs font-black text-slate-500 cursor-not-allowed"
                >
                  <Lock size={15} />
                  <span>Payments Temporarily Unavailable</span>
                </button>
                <button
                  type="button"
                  onClick={handleInitiateOrder}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-300 bg-white py-3 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
                >
                  <span>Prepare Unpaid Test Order (awaiting_payment)</span>
                  <ArrowRight size={14} />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Flutterwave Modal */}
      {currentOrder && (
        <FlutterwaveModal
          order={currentOrder}
          isOpen={flutterwaveModalOpen}
          onClose={() => setFlutterwaveModalOpen(false)}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
}
