import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { ShortVideo, ProductItem } from '../../types';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ShoppingBag,
  Zap,
  CheckCircle2,
  Plus,
  Radio,
  X,
  Send,
  Flag,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Maximize2,
  Minimize2,
  ArrowLeft,
} from 'lucide-react';

interface ForYouVideoFeedProps {
  onSelectProduct: (product: ProductItem) => void;
  onProceedToCheckout: () => void;
  onOpenLiveStream?: () => void;
  onBack?: () => void;
}

export default function ForYouVideoFeedPage({
  onSelectProduct,
  onProceedToCheckout,
  onOpenLiveStream,
  onBack,
}: ForYouVideoFeedProps) {
  const {
    shortVideos,
    likeVideo,
    saveVideo,
    followSeller,
    unfollowSeller,
    addVideoComment,
    reportVideo,
    addToCart,
    showToast,
  } = useStore();

  const [feedMode, setFeedMode] = useState<'for-you' | 'following'>('for-you');
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const [touchStartY, setTouchStartY] = useState<number | null>(null);

  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);

  const filteredVideos = shortVideos.filter((v) => {
    if (feedMode === 'following') {
      return v.following;
    }
    return true;
  });

  const activeVideo = filteredVideos[activeIndex] || filteredVideos[0] || shortVideos[0];

  // Sync autoplay / pause when activeIndex changes
  useEffect(() => {
    videoRefs.current.forEach((vid, idx) => {
      if (!vid) return;
      if (idx === activeIndex && isPlaying) {
        vid.muted = isMuted;
        vid.play().catch(() => {
          // Autoplay fallback: browsers may restrict unmuted video playback
          vid.muted = true;
          vid.play().catch(() => {});
        });
      } else {
        vid.pause();
      }
    });
  }, [activeIndex, isPlaying, isMuted, filteredVideos.length]);

  // Keyboard navigation: Up/Down arrow keys, Space, M
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        handlePrev();
      } else if (e.key === ' ' || e.key === 'Spacebar') {
        e.preventDefault();
        togglePlayPause();
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        setIsMuted((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, filteredVideos.length, isPlaying]);

  const handleNext = () => {
    if (activeIndex < filteredVideos.length - 1) {
      setActiveIndex((prev) => prev + 1);
      setIsPlaying(true);
    } else {
      showToast('You are all caught up! Replaying from top.');
      setActiveIndex(0);
      setIsPlaying(true);
    }
  };

  const handlePrev = () => {
    if (activeIndex > 0) {
      setActiveIndex((prev) => prev - 1);
      setIsPlaying(true);
    }
  };

  const togglePlayPause = () => {
    const currentVideo = videoRefs.current[activeIndex];
    if (!currentVideo) return;

    if (isPlaying) {
      currentVideo.pause();
      setIsPlaying(false);
    } else {
      currentVideo.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  // Touch swipe handling for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartY(e.touches[0].clientY);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartY === null) return;
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStartY - touchEndY;

    // Threshold of 50px for vertical swipe
    if (diff > 50) {
      handleNext();
    } else if (diff < -50) {
      handlePrev();
    }
    setTouchStartY(null);
  };

  const handleShare = async (video: ShortVideo) => {
    const shareUrl = window.location.origin + `/product/${video.taggedProduct.slug || video.taggedProduct.id}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: video.taggedProduct.title,
          text: `${video.caption} – Shop on Cash N Carry Nigeria!`,
          url: shareUrl,
        });
        showToast('Shared successfully!');
      } catch {
        // User dismissed
      }
    } else {
      navigator.clipboard.writeText(shareUrl);
      showToast('Video link copied to clipboard! 📋');
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !activeVideo) return;
    addVideoComment(activeVideo.id, commentInput.trim());
    setCommentInput('');
  };

  const handleBuyNow = (product: ProductItem) => {
    addToCart(product, 1);
    onProceedToCheckout();
  };

  if (!activeVideo) {
    return (
      <div className="flex h-[80vh] flex-col items-center justify-center p-6 text-center">
        <Sparkles size={48} className="text-emerald-700 animate-pulse" />
        <h2 className="mt-4 text-xl font-black text-slate-900">No videos in this feed yet</h2>
        <p className="mt-1 text-xs text-slate-500 max-w-xs">
          {feedMode === 'following'
            ? 'Follow more verified Nigerian merchants to see their short video drops here.'
            : 'Check back shortly for new video reviews and unboxings.'}
        </p>
        <button
          onClick={() => setFeedMode('for-you')}
          className="mt-4 rounded-full bg-[#0c5c36] px-6 py-2.5 text-xs font-black text-white shadow-md hover:bg-emerald-900"
        >
          Explore For You Feed
        </button>
      </div>
    );
  }

  return (
    <div
      className={
        isFullscreen
          ? 'fixed inset-0 z-50 h-[100dvh] w-screen bg-black text-white select-none overflow-hidden flex items-center justify-center p-0 m-0'
          : 'relative w-full h-[100dvh] md:h-[100vh] bg-black text-white select-none overflow-hidden flex items-center justify-center p-0 m-0'
      }
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Main Video Viewport (Strict 9:16 aspect ratio & cover to fully fill viewport without gaps) */}
      <div
        className="relative h-[100dvh] md:h-[100vh] w-full [aspect-ratio:9/16] md:max-w-[calc(100vh*9/16)] mx-auto cursor-pointer overflow-hidden bg-black flex items-center justify-center p-0 m-0"
        onClick={togglePlayPause}
      >
        <video
          ref={(el) => {
            videoRefs.current[activeIndex] = el;
          }}
          src={activeVideo.videoUrl}
          poster={activeVideo.posterUrl}
          loop
          playsInline
          muted={isMuted}
          className="absolute inset-0 h-full w-full object-cover [object-fit:cover]"
        />

        {/* Center Pause/Play overlay animation */}
        {!isPlaying && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/25 backdrop-blur-[2px]">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white/20 text-white backdrop-blur-md border border-white/30 animate-in zoom-in-75 duration-150">
              <Play size={32} className="fill-white translate-x-0.5" />
            </div>
          </div>
        )}
      </div>

      {/* Top Floating Overlay: Back Button, Following | For You Tabs, Audio Mute & Fullscreen */}
      <div className="absolute top-0 inset-x-0 z-30 flex items-center justify-between px-4 pt-4 pb-8 bg-gradient-to-b from-black/85 via-black/40 to-transparent">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onBack();
              }}
              className="flex items-center gap-1.5 rounded-full bg-black/40 backdrop-blur-md px-3 py-1.5 text-xs font-bold text-white border border-white/20 hover:bg-black/60 transition active:scale-95"
              title="Back to Marketplace"
              aria-label="Back to Marketplace"
            >
              <ArrowLeft size={16} />
              <span className="hidden sm:inline">Shop</span>
            </button>
          )}

          {activeVideo.isLiveNow && onOpenLiveStream && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onOpenLiveStream();
              }}
              className="flex items-center gap-1 rounded-full bg-rose-600/90 backdrop-blur-md px-2.5 py-1 text-[10px] font-black uppercase text-white shadow animate-pulse hover:bg-rose-700 transition"
              title="Seller is streaming live now"
            >
              <Radio size={12} />
              <span>LIVE</span>
            </button>
          )}
        </div>

        {/* Following | For You Tabs */}
        <div className="flex items-center gap-4 text-sm font-bold">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setFeedMode('following');
              setActiveIndex(0);
            }}
            className={`transition ${
              feedMode === 'following'
                ? 'font-black text-white border-b-2 border-white pb-0.5'
                : 'text-white/60 hover:text-white'
            }`}
          >
            Following
          </button>
          <span className="text-white/30 text-xs">|</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setFeedMode('for-you');
              setActiveIndex(0);
            }}
            className={`transition ${
              feedMode === 'for-you'
                ? 'font-black text-white border-b-2 border-orange-500 text-orange-400 pb-0.5'
                : 'text-white/60 hover:text-white'
            }`}
          >
            For You
          </button>
        </div>

        {/* Top Right Controls: Fullscreen + Audio Mute */}
        <div className="flex items-center gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsFullscreen((prev) => !prev);
            }}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-black/40 backdrop-blur-md text-white border border-white/20 hover:bg-black/60 transition active:scale-95"
            aria-label={isFullscreen ? 'Exit full screen' : 'Full screen video'}
            title={isFullscreen ? 'Exit full screen' : 'Full screen video'}
          >
            {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsMuted((prev) => !prev);
            }}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-black/40 backdrop-blur-md text-white border border-white/20 hover:bg-black/60 transition active:scale-95"
            aria-label={isMuted ? 'Unmute video' : 'Mute video'}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
        </div>
      </div>

      {/* Up / Down Desktop Navigation Arrows */}
      <div className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 flex-col gap-2 z-20">
        <button
          onClick={(e) => {
            e.stopPropagation();
            handlePrev();
          }}
          disabled={activeIndex === 0}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur-md hover:bg-black/80 disabled:opacity-30 disabled:pointer-events-none"
          title="Previous video (Up Arrow)"
        >
          <ChevronUp size={18} />
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleNext();
          }}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur-md hover:bg-black/80"
          title="Next video (Down Arrow)"
        >
          <ChevronDown size={18} />
        </button>
      </div>

      {/* Right Sidebar Interaction Controls */}
      <div className="absolute right-3 bottom-[calc(9.8rem+env(safe-area-inset-bottom))] md:bottom-32 z-20 flex flex-col items-center gap-3.5">
        {/* Seller Avatar with Follow Button */}
        <div className="relative mb-2 flex flex-col items-center">
          <img
            src={activeVideo.sellerAvatar}
            alt={activeVideo.sellerName}
            className="h-11 w-11 rounded-full border-2 border-white object-cover shadow-lg"
          />
          {!activeVideo.following ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                followSeller(activeVideo.sellerId);
              }}
              className="absolute -bottom-2 flex h-5 w-5 items-center justify-center rounded-full bg-orange-500 text-white shadow-md hover:bg-orange-600 transition"
              title="Follow seller"
            >
              <Plus size={13} className="stroke-[3]" />
            </button>
          ) : (
            <button
              onClick={(e) => {
                e.stopPropagation();
                unfollowSeller(activeVideo.sellerId);
              }}
              className="absolute -bottom-2 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-600 text-white shadow-md hover:bg-emerald-700 transition"
              title="Following"
            >
              <CheckCircle2 size={13} className="stroke-[3]" />
            </button>
          )}
        </div>

        {/* Like Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            likeVideo(activeVideo.id);
          }}
          className="flex flex-col items-center gap-1 text-white hover:scale-110 active:scale-95 transition"
          aria-label="Like video"
        >
          <div
            className={`flex h-11 w-11 items-center justify-center rounded-full backdrop-blur-md transition ${
              activeVideo.liked
                ? 'bg-rose-500/90 text-white shadow-lg shadow-rose-500/40'
                : 'bg-black/40 text-white hover:bg-black/60'
            }`}
          >
            <Heart
              size={22}
              className={activeVideo.liked ? 'fill-white stroke-none' : 'stroke-[2]'}
            />
          </div>
          <span className="text-[11px] font-black drop-shadow">
            {activeVideo.likesCount.toLocaleString()}
          </span>
        </button>

        {/* Comments Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setCommentsOpen(true);
          }}
          className="flex flex-col items-center gap-1 text-white hover:scale-110 active:scale-95 transition"
          aria-label="View comments"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-black/40 backdrop-blur-md text-white hover:bg-black/60">
            <MessageCircle size={22} className="stroke-[2]" />
          </div>
          <span className="text-[11px] font-black drop-shadow">
            {activeVideo.commentsCount.toLocaleString()}
          </span>
        </button>

        {/* Save / Bookmark Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            saveVideo(activeVideo.id);
          }}
          className="flex flex-col items-center gap-1 text-white hover:scale-110 active:scale-95 transition"
          aria-label="Bookmark video"
        >
          <div
            className={`flex h-11 w-11 items-center justify-center rounded-full backdrop-blur-md transition ${
              activeVideo.saved
                ? 'bg-amber-500/90 text-white shadow-lg shadow-amber-500/40'
                : 'bg-black/40 text-white hover:bg-black/60'
            }`}
          >
            <Bookmark
              size={21}
              className={activeVideo.saved ? 'fill-white stroke-none' : 'stroke-[2]'}
            />
          </div>
          <span className="text-[11px] font-black drop-shadow">
            {activeVideo.savesCount.toLocaleString()}
          </span>
        </button>

        {/* Share Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleShare(activeVideo);
          }}
          className="flex flex-col items-center gap-1 text-white hover:scale-110 active:scale-95 transition"
          aria-label="Share video"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-black/40 backdrop-blur-md text-white hover:bg-black/60">
            <Share2 size={20} className="stroke-[2]" />
          </div>
          <span className="text-[11px] font-black drop-shadow">
            {activeVideo.sharesCount.toLocaleString()}
          </span>
        </button>

        {/* Report Content Flag */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setReportOpen(true);
          }}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-black/30 text-white/70 hover:text-white hover:bg-black/50 transition"
          title="Report content"
        >
          <Flag size={14} />
        </button>
      </div>

      {/* Bottom Overlay: Seller info, Caption, Sound, Tagged Product Card */}
      <div className="absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black via-black/85 to-transparent px-4 pt-12 pb-[calc(4.5rem+env(safe-area-inset-bottom))] md:pb-6 space-y-2.5">
        {/* Seller Info & Caption */}
        <div className="pr-16 space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-black text-white hover:underline cursor-pointer">
              {activeVideo.sellerName}
            </span>
            {activeVideo.sellerVerified && (
              <span className="flex items-center gap-0.5 rounded-full bg-emerald-700/80 px-1.5 py-0.5 text-[9px] font-bold text-white">
                <CheckCircle2 size={10} /> Verified
              </span>
            )}
          </div>
          <p className="text-xs text-white/90 line-clamp-2 leading-relaxed">
            {activeVideo.caption}
          </p>
          {activeVideo.soundTitle && (
            <div className="flex items-center gap-1.5 text-[10px] text-white/70">
              <span className="inline-block animate-spin text-amber-400">🎵</span>
              <span className="truncate">{activeVideo.soundTitle}</span>
            </div>
          )}
        </div>

        {/* Tagged Product Pill Card */}
        <div className="rounded-2xl border border-white/20 bg-white/15 backdrop-blur-md p-2.5 shadow-xl transition hover:bg-white/20">
          <div className="flex items-center justify-between gap-3">
            {/* Product Thumbnail & Details */}
            <div
              onClick={() => onSelectProduct(activeVideo.taggedProduct)}
              className="flex items-center gap-2.5 min-w-0 flex-1 cursor-pointer"
            >
              <img
                src={activeVideo.taggedProduct.image}
                alt={activeVideo.taggedProduct.title}
                className="h-12 w-12 rounded-xl object-cover shrink-0 border border-white/20"
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-black text-amber-300 uppercase">
                    ⭐ {activeVideo.taggedProduct.rating}
                  </span>
                  {activeVideo.taggedProduct.badge && (
                    <span className="rounded bg-orange-500/90 px-1 py-0.2 text-[9px] font-extrabold text-white">
                      {activeVideo.taggedProduct.badge}
                    </span>
                  )}
                </div>
                <div className="text-xs font-black text-white truncate">
                  {activeVideo.taggedProduct.title}
                </div>
                <div className="text-xs font-black text-emerald-400">
                  ₦{activeVideo.taggedProduct.price.toLocaleString()}
                  {activeVideo.taggedProduct.compareAt > activeVideo.taggedProduct.price && (
                    <span className="ml-1.5 text-[10px] text-white/60 line-through">
                      ₦{activeVideo.taggedProduct.compareAt.toLocaleString()}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Action Buttons: Add to Cart & Buy Now */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  addToCart(activeVideo.taggedProduct, 1);
                }}
                className="flex items-center gap-1 rounded-xl bg-white/20 hover:bg-white/30 text-white px-2.5 py-2 text-xs font-black backdrop-blur-md transition active:scale-95"
                title="Add to shopping bag"
              >
                <ShoppingBag size={14} />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleBuyNow(activeVideo.taggedProduct);
                }}
                className="flex items-center gap-1 rounded-xl bg-orange-500 hover:bg-orange-600 text-white px-3 py-2 text-xs font-black shadow-md shadow-orange-500/30 transition active:scale-95"
              >
                <Zap size={14} className="fill-white" />
                <span>Buy</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Slide-Up Comments Drawer */}
      {commentsOpen && (
        <div
          onClick={() => setCommentsOpen(false)}
          className="absolute inset-0 z-40 flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="flex max-h-[70%] flex-col rounded-t-3xl bg-white text-slate-900 shadow-2xl animate-in slide-in-from-bottom duration-200"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 p-4">
              <div className="text-sm font-black text-slate-900">
                Comments ({activeVideo.comments?.length || 0})
              </div>
              <button
                onClick={() => setCommentsOpen(false)}
                className="rounded-full p-1 text-slate-400 hover:bg-slate-100"
              >
                <X size={18} />
              </button>
            </div>

            {/* Comments List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 divide-y divide-slate-100">
              {!activeVideo.comments || activeVideo.comments.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No comments yet. Be the first Nigerian shopper to ask a question!
                </div>
              ) : (
                activeVideo.comments.map((comment) => (
                  <div key={comment.id} className="pt-3 first:pt-0 flex items-start gap-3">
                    <img
                      src={
                        comment.userAvatar ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'
                      }
                      alt={comment.userName}
                      className="h-8 w-8 rounded-full object-cover shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                        <span>{comment.userName}</span>
                        <span className="text-[10px] text-slate-400">{comment.createdAt}</span>
                      </div>
                      <p className="mt-0.5 text-xs text-slate-600 leading-relaxed">
                        {comment.content}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Comment Form Input */}
            <form onSubmit={handleAddComment} className="border-t border-slate-100 p-3 flex gap-2">
              <input
                type="text"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                placeholder="Ask seller about size, delivery, or stock..."
                className="flex-1 rounded-full border border-slate-200 bg-slate-50 px-4 py-2 text-xs outline-none focus:border-emerald-600 focus:bg-white"
              />
              <button
                type="submit"
                disabled={!commentInput.trim()}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-[#0c5c36] text-white disabled:opacity-40"
              >
                <Send size={15} />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Report Modal */}
      {reportOpen && (
        <div
          onClick={() => setReportOpen(false)}
          className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xs rounded-2xl bg-white p-5 text-slate-900 shadow-2xl"
          >
            <h3 className="text-sm font-black text-slate-900">Report Inappropriate Video</h3>
            <p className="mt-1 text-xs text-slate-500">
              Help us maintain authentic, safe Nigerian commerce. Select reason:
            </p>
            <div className="mt-3 space-y-1.5 text-xs font-semibold text-slate-700">
              {[
                'Counterfeit / Non-genuine brand',
                'Misleading price or specs',
                'Inappropriate / Offensive visuals',
                'Spam / Scam seller',
              ].map((reason) => (
                <button
                  key={reason}
                  onClick={() => {
                    reportVideo(activeVideo.id, reason);
                    setReportOpen(false);
                  }}
                  className="w-full rounded-xl bg-slate-50 p-2 text-left hover:bg-rose-50 hover:text-rose-700 transition"
                >
                  {reason}
                </button>
              ))}
            </div>
            <button
              onClick={() => setReportOpen(false)}
              className="mt-4 w-full rounded-xl border border-slate-200 py-2 text-xs font-bold text-slate-500 hover:bg-slate-50"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
