import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Order } from '../../types';
import { RotateCcw, CheckCircle2, ShieldAlert, ArrowLeft } from 'lucide-react';

interface ReturnsPageProps {
  initialOrder?: Order | null;
  onBack: () => void;
}

export default function ReturnsPage({ initialOrder, onBack }: ReturnsPageProps) {
  const { orders, showToast } = useStore();

  const [selectedOrderId, setSelectedOrderId] = useState<string>(
    initialOrder?.id || orders[0]?.id || ''
  );
  const [reason, setReason] = useState('Item arrived with damaged packaging');
  const [comments, setComments] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    showToast('Return claim logged with Escrow Resolution Desk.');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-16">
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-[#0c5c36]"
      >
        <ArrowLeft size={16} /> Back
      </button>

      <div className="rounded-3xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-teal-50 text-teal-800">
            <RotateCcw size={22} />
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900">7-Day Free Returns Request</h1>
            <p className="text-xs text-slate-500">
              Cash N Carry Nigeria Buyer Protection & Dispute Resolution.
            </p>
          </div>
        </div>

        {submitted ? (
          <div className="rounded-2xl bg-emerald-50 p-6 text-center space-y-3 border border-emerald-200">
            <CheckCircle2 size={36} className="mx-auto text-emerald-700" />
            <h3 className="text-base font-black text-emerald-900">Return Claim Submitted</h3>
            <p className="text-xs text-emerald-800 max-w-md mx-auto">
              Your return request for order <b>{selectedOrderId}</b> is logged. Our Lagos dispatch team will arrange courier pickup within 48 hours.
            </p>
            <button
              onClick={onBack}
              className="mt-2 rounded-xl bg-[#0c5c36] px-5 py-2 text-xs font-bold text-white"
            >
              Back to Orders
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-slate-700">Select Order</label>
              <select
                value={selectedOrderId}
                onChange={(e) => setSelectedOrderId(e.target.value)}
                className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 bg-white font-mono font-bold"
              >
                {orders.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.id} — Total: ₦{o.total.toLocaleString()} ({o.status})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700">Reason for Return</label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 bg-white font-bold"
              >
                <option>Item arrived with damaged packaging</option>
                <option>Received wrong item or size</option>
                <option>Item defective or not functioning as described</option>
                <option>Changed mind (within 7 days)</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700">Additional Details / Explanation</label>
              <textarea
                rows={3}
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder="Describe the issue with the item received..."
                className="mt-1 w-full rounded-xl border border-slate-200 p-3 outline-none"
              />
            </div>

            <div className="rounded-xl bg-slate-50 p-3 text-[11px] text-slate-500">
              Escrow funds for this item will remain frozen until warehouse return verification is completed.
            </div>

            <button
              type="submit"
              className="w-full rounded-2xl bg-[#0c5c36] py-3.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow"
            >
              Submit Return Claim
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
