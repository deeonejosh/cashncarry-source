import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Order } from '../../types';
import FlutterwaveModal from '../ui/FlutterwaveModal';
import {
  Package,
  Clock,
  CheckCircle2,
  Truck,
  RotateCcw,
  XCircle,
  ExternalLink,
  CreditCard,
  AlertCircle,
  Search,
} from 'lucide-react';

interface OrdersPageProps {
  onTrackOrder: (trackingNumber: string) => void;
  onOpenReturns: (order: Order) => void;
}

export default function OrdersPage({ onTrackOrder, onOpenReturns }: OrdersPageProps) {
  const { stagingConfig, orders, cancelOrder, showToast } = useStore();
  const paymentsEnabled = stagingConfig.paymentsEnabled;

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedOrderForPay, setSelectedOrderForPay] = useState<Order | null>(null);

  const filteredOrders = orders.filter((o) => {
    if (filterStatus === 'all') return true;
    return o.status === filterStatus;
  });

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'paid':
        return <span className="rounded-full bg-emerald-100 px-3 py-0.5 text-xs font-bold text-emerald-800">Paid & Confirmed</span>;
      case 'awaiting_payment':
        return <span className="rounded-full bg-amber-100 px-3 py-0.5 text-xs font-bold text-amber-800">Awaiting Payment</span>;
      case 'processing':
        return <span className="rounded-full bg-blue-100 px-3 py-0.5 text-xs font-bold text-blue-800">Processing</span>;
      case 'shipped':
        return <span className="rounded-full bg-indigo-100 px-3 py-0.5 text-xs font-bold text-indigo-800">In Transit</span>;
      case 'delivered':
        return <span className="rounded-full bg-teal-100 px-3 py-0.5 text-xs font-bold text-teal-800">Delivered</span>;
      case 'cancelled':
        return <span className="rounded-full bg-slate-100 px-3 py-0.5 text-xs font-bold text-slate-500">Cancelled / Restored</span>;
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 sm:text-3xl">My Orders & Purchases</h1>
        <p className="mt-1 text-xs text-slate-500 sm:text-sm">
          Track packages, resume reserved checkouts, manage returns, and review receipts.
        </p>
      </div>

      {!paymentsEnabled && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-900">
          <AlertCircle size={18} className="shrink-0 text-amber-700 mt-0.5" />
          <div>
            <div className="font-black">Payments temporarily unavailable</div>
            <p className="text-amber-800 mt-0.5">
              Payment confirmation is disabled in staging (PAYMENTS_ENABLED=false). You can inspect prepared unpaid orders and release reserved stock safely.
            </p>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex border-b border-slate-200 pb-2 gap-2 overflow-x-auto text-xs font-bold text-slate-600">
        {[
          { id: 'all', label: 'All Orders' },
          { id: 'awaiting_payment', label: 'Awaiting Payment' },
          { id: 'paid', label: 'Paid' },
          { id: 'shipped', label: 'Shipped' },
          { id: 'delivered', label: 'Delivered' },
          { id: 'cancelled', label: 'Cancelled' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterStatus(tab.id)}
            className={`whitespace-nowrap rounded-xl px-4 py-2 transition ${
              filterStatus === tab.id
                ? 'bg-[#0c5c36] text-white shadow-sm'
                : 'hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Orders List */}
      {filteredOrders.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-slate-200 bg-white p-16 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-slate-400">
            <Package size={32} />
          </div>
          <h3 className="mt-4 text-base font-black text-slate-800">No orders found</h3>
          <p className="mt-1 text-xs text-slate-500">
            You don’t have any orders matching the "{filterStatus}" filter.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <div
              key={order.id}
              className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:shadow-md"
            >
              {/* Order Top Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 bg-slate-50/70 p-4 text-xs">
                <div className="flex items-center gap-3">
                  <div>
                    <span className="text-slate-400">Order ID: </span>
                    <span className="font-mono font-black text-slate-900">{order.id}</span>
                  </div>
                  <span className="text-slate-300">·</span>
                  <div className="text-slate-500">
                    Placed: {new Date(order.createdAt).toLocaleDateString('en-NG', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {getStatusBadge(order.status)}
                </div>
              </div>

              {/* Order Items */}
              <div className="p-5 space-y-4">
                <div className="divide-y divide-slate-100">
                  {order.items.map((item) => (
                    <div key={item.productId} className="flex items-center justify-between py-3">
                      <div className="flex items-center gap-3">
                        {item.image && (
                          <img src={item.image} alt={item.name} className="h-14 w-14 rounded-xl object-cover border border-slate-100" />
                        )}
                        <div>
                          <h4 className="text-xs font-bold text-slate-900">{item.name}</h4>
                          <div className="text-[11px] text-slate-400">
                            Vendor: <b>{item.sellerName}</b> · Quantity: {item.quantity}
                          </div>
                          <div className="text-xs font-black text-slate-800 mt-0.5">
                            ₦{item.price.toLocaleString('en-NG')}
                          </div>
                        </div>
                      </div>

                      <div className="text-right text-xs font-black text-slate-900">
                        ₦{(item.price * item.quantity).toLocaleString('en-NG')}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Shipping & Payment Meta */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-100 pt-4 text-xs">
                  <div className="text-slate-500 text-[11px] space-y-0.5">
                    <div>Delivery to: <b>{order.address.recipient}</b>, {order.address.city}</div>
                    {order.flutterwaveRef && (
                      <div className="font-mono text-emerald-800 font-bold">
                        Flutterwave TX Ref: {order.flutterwaveRef}
                      </div>
                    )}
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-slate-500">Total Amount: </span>
                    <span className="text-base font-black text-[#0c5c36]">
                      ₦{order.total.toLocaleString('en-NG')}
                    </span>
                  </div>
                </div>

                {/* Action Buttons based on status */}
                <div className="flex flex-wrap items-center justify-end gap-2 border-t border-slate-100 pt-4">
                  {order.status === 'awaiting_payment' && (
                    <>
                      <button
                        onClick={() => cancelOrder(order.id)}
                        className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-rose-600 transition"
                      >
                        Cancel & Release Stock
                      </button>

                      {paymentsEnabled ? (
                        <button
                          onClick={() => setSelectedOrderForPay(order)}
                          className="flex items-center gap-1.5 rounded-xl bg-[#0c5c36] px-4 py-2 text-xs font-black text-white hover:bg-emerald-900 transition shadow-sm"
                        >
                          <CreditCard size={14} />
                          <span>Resume Checkout (Pay Now)</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled
                          className="flex items-center gap-1.5 rounded-xl bg-slate-200 px-4 py-2 text-xs font-bold text-slate-500 cursor-not-allowed"
                        >
                          <CreditCard size={14} />
                          <span>Payments Temporarily Unavailable</span>
                        </button>
                      )}
                    </>
                  )}

                  {order.trackingNumber && (
                    <button
                      onClick={() => onTrackOrder(order.trackingNumber!)}
                      className="flex items-center gap-1.5 rounded-xl border border-[#0c5c36] bg-emerald-50 px-4 py-2 text-xs font-bold text-[#0c5c36] hover:bg-emerald-100 transition"
                    >
                      <Truck size={14} />
                      <span>Track Shipment ({order.carrier || 'GIG'})</span>
                    </button>
                  )}

                  {(order.status === 'delivered' || order.status === 'shipped') && (
                    <button
                      onClick={() => onOpenReturns(order)}
                      className="flex items-center gap-1.5 rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
                    >
                      <RotateCcw size={14} />
                      <span>Request Return / Refund</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Flutterwave Resume Modal */}
      {selectedOrderForPay && (
        <FlutterwaveModal
          order={selectedOrderForPay}
          isOpen={true}
          onClose={() => setSelectedOrderForPay(null)}
          onSuccess={() => {
            setSelectedOrderForPay(null);
            showToast('Order payment completed and status updated to PAID!');
          }}
        />
      )}
    </div>
  );
}
