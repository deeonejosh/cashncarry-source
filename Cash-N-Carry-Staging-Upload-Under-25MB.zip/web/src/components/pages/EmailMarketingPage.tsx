import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  EMAIL_TEMPLATES,
  generateHtmlEmail,
  EmailRenderOptions,
} from '../../lib/emailTemplates';
import {
  EmailTemplateId,
  EmailCampaign,
  NewsletterSubscriber,
  ProductItem,
} from '../../types';
import {
  Mail,
  Send,
  Users,
  Copy,
  Download,
  Smartphone,
  Monitor,
  CheckCircle2,
  Sparkles,
  Search,
  Filter,
  Plus,
  ArrowRight,
  ExternalLink,
  RefreshCw,
  Gift,
  Eye,
  FileCode,
  Tag,
  Zap,
  BarChart3,
  Calendar,
  AlertCircle,
  X,
} from 'lucide-react';

interface EmailMarketingPageProps {
  onSelectProduct?: (product: ProductItem) => void;
  onOpenNewsletterModal?: () => void;
}

export default function EmailMarketingPage({
  onSelectProduct,
  onOpenNewsletterModal,
}: EmailMarketingPageProps) {
  const {
    products,
    newsletterSubscribers,
    emailCampaigns,
    createEmailCampaign,
    sendEmailCampaign,
    sendTestEmail,
    subscribeToNewsletter,
    unsubscribeFromNewsletter,
    currentUser,
    showToast,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'designer' | 'campaigns' | 'subscribers'>('designer');
  const [selectedTemplateId, setSelectedTemplateId] = useState<EmailTemplateId>('welcome');
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [testEmailAddress, setTestEmailAddress] = useState<string>('ogundiyatemidayo@gmail.com');
  const [isSendingTest, setIsSendingTest] = useState(false);
  const [copiedHtml, setCopiedHtml] = useState(false);
  const [newCampaignModalOpen, setNewCampaignModalOpen] = useState(false);
  const [addSubscriberModalOpen, setAddSubscriberModalOpen] = useState(false);

  // Customizer form values
  const currentTemplate = EMAIL_TEMPLATES.find((t) => t.id === selectedTemplateId) || EMAIL_TEMPLATES[0];
  const [customSubject, setCustomSubject] = useState(currentTemplate.defaultSubject);
  const [customPreheader, setCustomPreheader] = useState(currentTemplate.defaultPreheader);
  const [customHeadline, setCustomHeadline] = useState(currentTemplate.defaultHeadline);
  const [customBody, setCustomBody] = useState(currentTemplate.defaultBody);
  const [customCtaText, setCustomCtaText] = useState(currentTemplate.defaultCtaText);
  const [customCtaUrl, setCustomCtaUrl] = useState(currentTemplate.defaultCtaUrl);
  const [recipientName, setRecipientName] = useState('Temidayo');
  const [voucherCode, setVoucherCode] = useState('WELCOME2500');
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>(['p1', 'p2']);

  // Update form fields when template changes
  const handleSelectTemplate = (id: EmailTemplateId) => {
    setSelectedTemplateId(id);
    const tmpl = EMAIL_TEMPLATES.find((t) => t.id === id) || EMAIL_TEMPLATES[0];
    setCustomSubject(tmpl.defaultSubject);
    setCustomPreheader(tmpl.defaultPreheader);
    setCustomHeadline(tmpl.defaultHeadline);
    setCustomBody(tmpl.defaultBody);
    setCustomCtaText(tmpl.defaultCtaText);
    setCustomCtaUrl(tmpl.defaultCtaUrl);
    setVoucherCode(id === 'welcome' ? 'WELCOME2500' : id === 'flash_sale' ? 'FLASH40' : '');
  };

  // Products featured in preview
  const featuredProducts = useMemo(() => {
    return products.filter((p) => selectedProductIds.includes(p.id));
  }, [products, selectedProductIds]);

  // Generate responsive HTML
  const generatedHtml = useMemo(() => {
    return generateHtmlEmail(selectedTemplateId, {
      recipientName,
      recipientEmail: testEmailAddress,
      headline: customHeadline,
      body: customBody,
      ctaText: customCtaText,
      ctaUrl: customCtaUrl,
      previewText: customPreheader,
      voucherCode: voucherCode || undefined,
      featuredProducts,
    });
  }, [
    selectedTemplateId,
    recipientName,
    testEmailAddress,
    customHeadline,
    customBody,
    customCtaText,
    customCtaUrl,
    customPreheader,
    voucherCode,
    featuredProducts,
  ]);

  // Test Email dispatch handler
  const handleSendTest = async () => {
    if (!testEmailAddress || !testEmailAddress.includes('@')) {
      showToast('Please enter a valid recipient email address');
      return;
    }
    setIsSendingTest(true);
    await sendTestEmail(selectedTemplateId, testEmailAddress, {
      recipientName,
      headline: customHeadline,
      body: customBody,
      ctaText: customCtaText,
      ctaUrl: customCtaUrl,
      voucherCode,
      featuredProducts,
    });
    setIsSendingTest(false);
  };

  // Copy HTML
  const handleCopyHtml = () => {
    navigator.clipboard.writeText(generatedHtml);
    setCopiedHtml(true);
    showToast('Responsive email HTML copied to clipboard!');
    setTimeout(() => setCopiedHtml(false), 2500);
  };

  // Download HTML file
  const handleDownloadHtml = () => {
    const blob = new Blob([generatedHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cashncarry-${selectedTemplateId}-template.html`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Downloaded cashncarry-${selectedTemplateId}-template.html`);
  };

  // Subscribers search & filter
  const [subscriberSearch, setSubscriberSearch] = useState('');
  const [subscriberFilter, setSubscriberFilter] = useState<'all' | 'subscribed' | 'unsubscribed'>('all');

  const filteredSubscribers = newsletterSubscribers.filter((sub) => {
    const matchesSearch =
      sub.email.toLowerCase().includes(subscriberSearch.toLowerCase()) ||
      (sub.name && sub.name.toLowerCase().includes(subscriberSearch.toLowerCase()));
    const matchesFilter = subscriberFilter === 'all' || sub.status === subscriberFilter;
    return matchesSearch && matchesFilter;
  });

  // Export Subscribers to CSV
  const handleExportCsv = () => {
    const headers = 'ID,Email,Name,Status,Preferences,Source,SubscribedAt\n';
    const rows = newsletterSubscribers
      .map(
        (s) =>
          `"${s.id}","${s.email}","${s.name || ''}","${s.status}","${s.preferences.join(';')}","${s.source}","${s.subscribedAt}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cashncarry-subscribers-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Exported ${newsletterSubscribers.length} newsletter subscribers to CSV!`);
  };

  // Metrics computation
  const totalSubscribersCount = newsletterSubscribers.length;
  const activeSubscribersCount = newsletterSubscribers.filter((s) => s.status === 'subscribed').length;
  const totalEmailsSent = emailCampaigns.reduce((acc, c) => acc + (c.status === 'sent' ? c.recipientsCount : 0), 0);
  const totalOpens = emailCampaigns.reduce((acc, c) => acc + c.openedCount, 0);
  const avgOpenRate = totalEmailsSent > 0 ? ((totalOpens / totalEmailsSent) * 100).toFixed(1) : '38.4';

  return (
    <div className="space-y-8 pb-20">
      
      {/* Studio Header Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0c5c36] via-[#09472a] to-[#042415] p-6 sm:p-10 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-white/10 px-3 py-1 text-[11px] font-black uppercase tracking-wider text-emerald-200 border border-white/15">
              EMAIL MARKETING & NEWSLETTER STUDIO
            </span>
            <span className="hidden sm:inline text-xs font-bold text-orange-300">
              NDPR & CAN-SPAM Compliant
            </span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight">
            Design Branded Emails & Broadcast Campaigns
          </h1>

          <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed max-w-xl">
            Deliver responsive, high-converting Nigerian shopping newsletters, daily flash drops, welcome vouchers, and real-time order tracking notifications.
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap items-center gap-3 shrink-0">
          <button
            onClick={() => onOpenNewsletterModal?.()}
            className="flex items-center gap-2 rounded-full bg-orange-500 px-5 py-2.5 text-xs font-black text-white shadow-lg hover:bg-orange-600 transition"
          >
            <Gift size={15} />
            <span>Shopper Subscribe Modal</span>
          </button>

          <button
            onClick={() => setNewCampaignModalOpen(true)}
            className="flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-5 py-2.5 text-xs font-bold text-white hover:bg-white/20 transition backdrop-blur-sm"
          >
            <Plus size={15} />
            <span>New Campaign</span>
          </button>
        </div>
      </section>

      {/* Real Performance Metrics Cards */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Total Subscribers</div>
          <div className="text-2xl font-black text-slate-900 tabular-nums">
            {totalSubscribersCount.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-700 font-semibold">
            {activeSubscribersCount} active opt-ins
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Avg. Open Rate</div>
          <div className="text-2xl font-black text-[#0c5c36] tabular-nums">
            {avgOpenRate}%
          </div>
          <div className="text-[11px] text-slate-500">
            Across Nigerian mobile clients
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Campaigns Broadcast</div>
          <div className="text-2xl font-black text-slate-900 tabular-nums">
            {emailCampaigns.filter((c) => c.status === 'sent').length}
          </div>
          <div className="text-[11px] text-slate-500">
            {totalEmailsSent.toLocaleString()} total deliveries
          </div>
        </div>

        <div className="rounded-3xl border border-amber-200 bg-amber-50/50 p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-amber-900">Welcome Vouchers Claimed</div>
          <div className="text-2xl font-black text-amber-700 tabular-nums">
            {newsletterSubscribers.filter((s) => s.welcomeVoucherSent).length}
          </div>
          <div className="text-[11px] text-amber-800">
            ₦2,500 promo code unlocked
          </div>
        </div>
      </section>

      {/* Main Feature Tabs */}
      <div className="flex border-b border-slate-200 pb-3 gap-2 overflow-x-auto text-xs font-bold text-slate-600">
        <button
          onClick={() => setActiveTab('designer')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2.5 transition ${
            activeTab === 'designer'
              ? 'bg-[#0c5c36] text-white shadow-sm'
              : 'hover:bg-slate-100'
          }`}
        >
          <FileCode size={15} />
          <span>Email Template Designer & Previewer</span>
        </button>

        <button
          onClick={() => setActiveTab('campaigns')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2.5 transition ${
            activeTab === 'campaigns'
              ? 'bg-[#0c5c36] text-white shadow-sm'
              : 'hover:bg-slate-100'
          }`}
        >
          <Send size={15} />
          <span>Marketing Campaigns ({emailCampaigns.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('subscribers')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2.5 transition ${
            activeTab === 'subscribers'
              ? 'bg-[#0c5c36] text-white shadow-sm'
              : 'hover:bg-slate-100'
          }`}
        >
          <Users size={15} />
          <span>Newsletter Subscribers ({totalSubscribersCount})</span>
        </button>
      </div>

      {/* TAB 1: EMAIL TEMPLATE DESIGNER & PREVIEWER */}
      {activeTab === 'designer' && (
        <div className="space-y-6">
          
          {/* Template Selection Cards */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-slate-900">Choose Email Template</h3>
              <span className="text-xs text-slate-500">
                5 Cross-Client Tested HTML Templates
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {EMAIL_TEMPLATES.map((tmpl) => {
                const isSelected = tmpl.id === selectedTemplateId;
                return (
                  <button
                    key={tmpl.id}
                    onClick={() => handleSelectTemplate(tmpl.id)}
                    className={`flex flex-col text-left rounded-2xl border p-4 transition duration-200 ${
                      isSelected
                        ? 'border-[#0c5c36] bg-emerald-50/60 shadow-md ring-2 ring-[#0c5c36]/20'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 mb-2">
                      <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800">
                        {tmpl.category}
                      </span>
                      {isSelected && (
                        <CheckCircle2 size={14} className="text-[#0c5c36]" />
                      )}
                    </div>
                    <div className="text-xs font-black text-slate-900 line-clamp-1 mb-1">
                      {tmpl.name}
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                      {tmpl.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Designer 2-Column Split: Customizer on Left, Live Viewport Preview on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left Column: Template Editor Controls (5 cols) */}
            <div className="lg:col-span-5 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                  Content Customizer
                </h4>
                <button
                  onClick={() => handleSelectTemplate(selectedTemplateId)}
                  className="text-xs text-[#0c5c36] font-bold hover:underline"
                >
                  Reset Defaults
                </button>
              </div>

              {/* Subject Line */}
              <div>
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">Subject Line</label>
                  <span className="text-[10px] text-slate-400">{customSubject.length} chars</span>
                </div>
                <input
                  type="text"
                  value={customSubject}
                  onChange={(e) => setCustomSubject(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
                />
              </div>

              {/* Preheader Preview Snippet */}
              <div>
                <label className="text-xs font-bold text-slate-700">Inbox Preheader Text</label>
                <input
                  type="text"
                  value={customPreheader}
                  onChange={(e) => setCustomPreheader(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
                />
              </div>

              {/* Recipient Name Personalization */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">Recipient Name</label>
                  <input
                    type="text"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    placeholder="e.g. Temidayo"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">Voucher Code</label>
                  <input
                    type="text"
                    value={voucherCode}
                    onChange={(e) => setVoucherCode(e.target.value)}
                    placeholder="e.g. WELCOME2500"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 font-mono text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
                  />
                </div>
              </div>

              {/* Main Headline */}
              <div>
                <label className="text-xs font-bold text-slate-700">Headline</label>
                <input
                  type="text"
                  value={customHeadline}
                  onChange={(e) => setCustomHeadline(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
                />
              </div>

              {/* Body Text */}
              <div>
                <label className="text-xs font-bold text-slate-700">Body Copy</label>
                <textarea
                  rows={4}
                  value={customBody}
                  onChange={(e) => setCustomBody(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white leading-relaxed resize-none"
                />
              </div>

              {/* CTA Customization */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">CTA Button Text</label>
                  <input
                    type="text"
                    value={customCtaText}
                    onChange={(e) => setCustomCtaText(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">CTA Destination</label>
                  <input
                    type="text"
                    value={customCtaUrl}
                    onChange={(e) => setCustomCtaUrl(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
                  />
                </div>
              </div>

              {/* Tag Products from Catalog */}
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1.5 block">
                  Tag Products From Catalog
                </label>
                <div className="space-y-1.5 max-h-40 overflow-y-auto border border-slate-100 rounded-xl p-2 bg-slate-50">
                  {products.slice(0, 6).map((prod) => {
                    const isTagged = selectedProductIds.includes(prod.id);
                    return (
                      <button
                        type="button"
                        key={prod.id}
                        onClick={() => {
                          setSelectedProductIds((prev) =>
                            prev.includes(prod.id)
                              ? prev.filter((id) => id !== prod.id)
                              : [...prev, prod.id]
                          );
                        }}
                        className={`flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-xs transition ${
                          isTagged
                            ? 'bg-[#0c5c36] text-white font-bold'
                            : 'bg-white text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <span className="truncate pr-2">{prod.title}</span>
                        <span className="shrink-0">₦{prod.price.toLocaleString()}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Send Test Email Drawer */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <label className="text-xs font-bold text-slate-700">Dispatch Live Test Email</label>
                <div className="flex items-center gap-2">
                  <input
                    type="email"
                    value={testEmailAddress}
                    onChange={(e) => setTestEmailAddress(e.target.value)}
                    placeholder="Enter recipient email..."
                    className="flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
                  />
                  <button
                    onClick={handleSendTest}
                    disabled={isSendingTest}
                    className="flex items-center gap-1.5 rounded-xl bg-[#0c5c36] px-4 py-2 text-xs font-bold text-white hover:bg-emerald-900 transition disabled:opacity-50 shrink-0 shadow"
                  >
                    {isSendingTest ? (
                      <RefreshCw size={13} className="animate-spin" />
                    ) : (
                      <Send size={13} />
                    )}
                    <span>{isSendingTest ? 'Sending...' : 'Send Test'}</span>
                  </button>
                </div>
                <div className="text-[10px] text-slate-400">
                  Pre-filled with your verified session address: <b>ogundiyatemidayo@gmail.com</b>
                </div>
              </div>

            </div>

            {/* Right Column: Live Viewport Preview (7 cols) */}
            <div className="lg:col-span-7 space-y-3">
              
              {/* Preview Controls Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-sm">
                
                {/* Device Toggle */}
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  <button
                    onClick={() => setPreviewDevice('desktop')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition ${
                      previewDevice === 'desktop'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    <Monitor size={14} />
                    <span>Desktop (600px)</span>
                  </button>

                  <button
                    onClick={() => setPreviewDevice('mobile')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition ${
                      previewDevice === 'mobile'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    <Smartphone size={14} />
                    <span>Mobile (375px)</span>
                  </button>
                </div>

                {/* Export & Copy Actions */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyHtml}
                    className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition shadow-sm"
                    title="Copy cross-client inline HTML for Mailchimp or Klaviyo"
                  >
                    <Copy size={13} />
                    <span>{copiedHtml ? 'Copied HTML! ✓' : 'Copy HTML'}</span>
                  </button>

                  <button
                    onClick={handleDownloadHtml}
                    className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-slate-800 transition shadow-sm"
                    title="Download template .html file"
                  >
                    <Download size={13} />
                    <span>Download .html</span>
                  </button>
                </div>

              </div>

              {/* Viewport Frame */}
              <div className="flex justify-center rounded-3xl border border-slate-200 bg-slate-100/90 p-4 sm:p-6 min-h-[640px] overflow-hidden">
                <div
                  className={`transition-all duration-300 w-full overflow-hidden shadow-2xl rounded-2xl bg-white border border-slate-200 ${
                    previewDevice === 'mobile' ? 'max-w-[375px]' : 'max-w-[620px]'
                  }`}
                >
                  {/* Fake Email Client Header */}
                  <div className="border-b border-slate-200 bg-slate-50 px-4 py-2.5 text-xs text-slate-600 flex items-center justify-between">
                    <div className="flex items-center gap-2 truncate">
                      <div className="h-3 w-3 rounded-full bg-rose-400" />
                      <div className="h-3 w-3 rounded-full bg-amber-400" />
                      <div className="h-3 w-3 rounded-full bg-emerald-400" />
                      <span className="font-semibold truncate text-[11px] text-slate-700 ml-1">
                        From: Cash N Carry &lt;noreply@cashncarryng.com&gt;
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono shrink-0">HTML5</span>
                  </div>

                  {/* Rendered Email Frame */}
                  <iframe
                    title="Email Template Live Preview"
                    srcDoc={generatedHtml}
                    className="w-full h-[760px] border-none bg-slate-50"
                  />
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* TAB 2: MARKETING CAMPAIGNS */}
      {activeTab === 'campaigns' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-black text-slate-900">Email Marketing Campaigns</h3>
              <p className="text-xs text-slate-500">
                Track broadcasts, review open and click metrics, and send targeted updates to Nigerian shoppers.
              </p>
            </div>

            <button
              onClick={() => setNewCampaignModalOpen(true)}
              className="flex items-center gap-2 rounded-xl bg-[#0c5c36] px-5 py-2.5 text-xs font-black text-white shadow hover:bg-emerald-900 transition"
            >
              <Plus size={15} />
              <span>Create Campaign</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100 rounded-3xl border border-slate-200 bg-white shadow-sm overflow-hidden">
            {emailCampaigns.map((camp) => {
              const isSent = camp.status === 'sent';
              const isScheduled = camp.status === 'scheduled';
              const openRate = camp.recipientsCount > 0 ? ((camp.openedCount / camp.recipientsCount) * 100).toFixed(1) : '0';
              const clickRate = camp.openedCount > 0 ? ((camp.clickedCount / camp.openedCount) * 100).toFixed(1) : '0';

              return (
                <div key={camp.id} className="p-6 transition hover:bg-slate-50/60 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1.5 max-w-xl">
                    <div className="flex items-center gap-2">
                      <span
                        className={`rounded-full px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider ${
                          isSent
                            ? 'bg-emerald-100 text-emerald-800'
                            : isScheduled
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {camp.status}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Audience: <b className="text-slate-700 capitalize">{camp.audienceSegment}</b>
                      </span>
                      {camp.sentAt && (
                        <span className="text-[11px] text-slate-400">
                          · Sent on {new Date(camp.sentAt).toLocaleDateString()}
                        </span>
                      )}
                    </div>

                    <h4 className="text-sm font-black text-slate-900">{camp.title}</h4>
                    <p className="text-xs text-slate-600 line-clamp-1">{camp.subject}</p>
                  </div>

                  {/* Metrics & Actions */}
                  <div className="flex items-center gap-6 shrink-0">
                    {isSent ? (
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-xs font-black text-slate-900 tabular-nums">
                            {camp.recipientsCount.toLocaleString()}
                          </div>
                          <div className="text-[10px] text-slate-400">Delivered</div>
                        </div>
                        <div>
                          <div className="text-xs font-black text-emerald-700 tabular-nums">
                            {openRate}%
                          </div>
                          <div className="text-[10px] text-slate-400">Opens ({camp.openedCount})</div>
                        </div>
                        <div>
                          <div className="text-xs font-black text-orange-600 tabular-nums">
                            {clickRate}%
                          </div>
                          <div className="text-[10px] text-slate-400">Clicks ({camp.clickedCount})</div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-500">
                        Targeting <b>{activeSubscribersCount}</b> active subscribers
                      </div>
                    )}

                    <div className="flex items-center gap-2">
                      {!isSent && (
                        <button
                          onClick={() => sendEmailCampaign(camp.id)}
                          className="flex items-center gap-1.5 rounded-xl bg-[#0c5c36] px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-emerald-900 transition"
                        >
                          <Send size={13} />
                          <span>Broadcast Now</span>
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setSelectedTemplateId(camp.templateId);
                          setActiveTab('designer');
                          setCustomSubject(camp.subject);
                          setCustomHeadline(camp.content.headline);
                          setCustomBody(camp.content.body);
                          setCustomCtaText(camp.content.ctaText);
                          setCustomCtaUrl(camp.content.ctaUrl);
                          if (camp.content.voucherCode) setVoucherCode(camp.content.voucherCode);
                        }}
                        className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50"
                      >
                        Preview / Duplicate
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: NEWSLETTER SUBSCRIBERS */}
      {activeTab === 'subscribers' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-black text-slate-900">Newsletter Subscriber Directory</h3>
              <p className="text-xs text-slate-500">
                Manage opt-in shoppers, export email addresses, and review preference tags.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportCsv}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition shadow-sm"
              >
                <Download size={14} />
                <span>Export CSV</span>
              </button>

              <button
                onClick={() => setAddSubscriberModalOpen(true)}
                className="flex items-center gap-1.5 rounded-xl bg-[#0c5c36] px-4 py-2.5 text-xs font-black text-white hover:bg-emerald-900 transition shadow"
              >
                <Plus size={14} />
                <span>Add Subscriber</span>
              </button>
            </div>
          </div>

          {/* Search & Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
            <div className="relative w-full sm:w-80">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={subscriberSearch}
                onChange={(e) => setSubscriberSearch(e.target.value)}
                placeholder="Search by email or name..."
                className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-3 py-2 text-xs text-slate-900 outline-none focus:border-[#0c5c36] focus:bg-white"
              />
            </div>

            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl w-full sm:w-auto">
              {(['all', 'subscribed', 'unsubscribed'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setSubscriberFilter(status)}
                  className={`flex-1 sm:flex-none px-3 py-1.5 text-xs font-bold rounded-lg transition capitalize ${
                    subscriberFilter === status
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>

          {/* Subscriber Table */}
          <div className="rounded-3xl border border-slate-200 bg-white shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-[11px] font-black uppercase text-slate-400 border-b border-slate-100">
                  <tr>
                    <th className="px-6 py-3.5">Subscriber</th>
                    <th className="px-6 py-3.5">Status</th>
                    <th className="px-6 py-3.5">Deal Interests</th>
                    <th className="px-6 py-3.5">Source</th>
                    <th className="px-6 py-3.5">Joined Date</th>
                    <th className="px-6 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-600">
                  {filteredSubscribers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-xs text-slate-400">
                        No subscribers matching filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredSubscribers.map((sub) => {
                      const isSub = sub.status === 'subscribed';
                      return (
                        <tr key={sub.id} className="hover:bg-slate-50/70 transition">
                          <td className="px-6 py-4">
                            <div className="font-bold text-slate-900">{sub.name || 'Anonymous Shopper'}</div>
                            <div className="text-[11px] text-slate-400 font-mono">{sub.email}</div>
                          </td>
                          <td className="px-6 py-4">
                            <span
                              className={`rounded-full px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider ${
                                isSub
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {sub.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-[11px] text-slate-600 flex items-center gap-1.5 flex-wrap">
                              {sub.preferences.map((pref) => (
                                <span key={pref} className="capitalize">
                                  {pref.replace('-', ' ')}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="px-6 py-4 uppercase text-[10px] font-bold text-slate-400">
                            {sub.source}
                          </td>
                          <td className="px-6 py-4 text-[11px] text-slate-500 tabular-nums">
                            {new Date(sub.subscribedAt).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 text-right">
                            {isSub ? (
                              <button
                                onClick={() => unsubscribeFromNewsletter(sub.email)}
                                className="text-xs font-bold text-rose-600 hover:underline"
                              >
                                Unsubscribe
                              </button>
                            ) : (
                              <button
                                onClick={() =>
                                  subscribeToNewsletter(sub.email, {
                                    name: sub.name,
                                    preferences: sub.preferences,
                                    source: 'admin',
                                  })
                                }
                                className="text-xs font-bold text-[#0c5c36] hover:underline"
                              >
                                Re-subscribe
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* CREATE NEW CAMPAIGN MODAL */}
      {newCampaignModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 sm:p-8 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900">Launch New Marketing Campaign</h3>
                <p className="text-xs text-slate-500">Broadcast an update to registered Nigerian shoppers.</p>
              </div>
              <button onClick={() => setNewCampaignModalOpen(false)} className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100">
                <X size={18} />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const title = formData.get('title') as string;
                const subject = formData.get('subject') as string;
                const segment = formData.get('segment') as any;

                createEmailCampaign({
                  title,
                  subject,
                  preheader: 'Exclusive deals from Cash N Carry Nigeria.',
                  templateId: selectedTemplateId,
                  status: 'draft',
                  audienceSegment: segment,
                  content: {
                    headline: customHeadline,
                    body: customBody,
                    ctaText: customCtaText,
                    ctaUrl: customCtaUrl,
                    voucherCode,
                    featuredProductIds: selectedProductIds,
                  },
                });

                setNewCampaignModalOpen(false);
              }}
              className="space-y-4 text-xs"
            >
              <div>
                <label className="font-bold text-slate-700 block mb-1">Campaign Internal Title</label>
                <input
                  name="title"
                  required
                  placeholder="e.g. Flash Friday Electronics Drop"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 outline-none focus:border-[#0c5c36]"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Email Subject Line</label>
                <input
                  name="subject"
                  required
                  defaultValue={customSubject}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 outline-none focus:border-[#0c5c36]"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Target Audience Segment</label>
                <select
                  name="segment"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 outline-none focus:border-[#0c5c36]"
                >
                  <option value="all">All Active Subscribers ({activeSubscribersCount})</option>
                  <option value="flash_deals">Flash Deals Interested</option>
                  <option value="tech">Tech & Electronics Shoppers</option>
                  <option value="fashion">Fashion & Ankara Shoppers</option>
                  <option value="vip">VIP Shoppers</option>
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setNewCampaignModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 font-bold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-[#0c5c36] px-5 py-2 font-black text-white hover:bg-emerald-900 transition shadow"
                >
                  Save Campaign
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD SUBSCRIBER MODAL */}
      {addSubscriberModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900">Add Newsletter Subscriber</h3>
              <button onClick={() => setAddSubscriberModalOpen(false)} className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100">
                <X size={18} />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const email = formData.get('email') as string;
                const name = formData.get('name') as string;

                subscribeToNewsletter(email, {
                  name,
                  preferences: ['flash-deals', 'livestreams'],
                  source: 'admin',
                });

                setAddSubscriberModalOpen(false);
              }}
              className="space-y-4 text-xs"
            >
              <div>
                <label className="font-bold text-slate-700 block mb-1">Email Address *</label>
                <input
                  name="email"
                  type="email"
                  required
                  placeholder="subscriber@domain.com"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 outline-none focus:border-[#0c5c36]"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Full Name</label>
                <input
                  name="name"
                  placeholder="e.g. Amina Bello"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 outline-none focus:border-[#0c5c36]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setAddSubscriberModalOpen(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 font-bold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-[#0c5c36] px-5 py-2 font-black text-white hover:bg-emerald-900 transition shadow"
                >
                  Add & Send Voucher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
