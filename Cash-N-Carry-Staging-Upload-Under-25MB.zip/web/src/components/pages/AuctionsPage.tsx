import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { AuctionItem } from '../../types';
import LiveAuctionCard from '../ui/LiveAuctionCard';
import { Gavel, Clock, Trophy, Plus, CheckCircle2, AlertCircle, ArrowRight, ShieldCheck } from 'lucide-react';

interface AuctionsPageProps {
  onCheckoutAuctionOrder: () => void;
  onOpenStorefront?: (sellerId: string) => void;
}

export default function AuctionsPage({ onCheckoutAuctionOrder, onOpenStorefront }: AuctionsPageProps) {
  const {
    auctions,
    placeBid,
    checkoutWinningAuction,
    currentUser,
    addresses,
    products,
    createSellerAuction,
    stagingConfig,
    showToast,
  } = useStore();

  const paymentsEnabled = stagingConfig.paymentsEnabled;

  const [biddingAuction, setBiddingAuction] = useState<AuctionItem | null>(null);
  const [bidAmount, setBidAmount] = useState<number>(0);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [startBidKobo, setStartBidKobo] = useState<number>(10000);
  const [durationMins, setDurationMins] = useState<number>(60);

  const handleOpenBidModal = (auction: AuctionItem) => {
    setBiddingAuction(auction);
    const minRequired = auction.currentBid ? auction.currentBid + 500 : auction.startingBid;
    setBidAmount(minRequired);
  };

  const handleSubmitBid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!biddingAuction) return;
    const res = placeBid(biddingAuction.id, bidAmount);
    if (res.success) {
      setBiddingAuction(null);
    } else {
      showToast(res.message || 'Bid rejected');
    }
  };

  const handleWinCheckout = (auctionId: string) => {
    if (!paymentsEnabled) {
      showToast('Payments temporarily unavailable in staging (PAYMENTS_ENABLED=false)');
      return;
    }
    const order = checkoutWinningAuction(auctionId, addresses[0]?.id || 'addr_1');
    if (order) {
      onCheckoutAuctionOrder();
    }
  };

  const handleCreateAuction = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = createSellerAuction(selectedProductId, startBidKobo, durationMins);
    if (ok) {
      setShowCreateModal(false);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {!paymentsEnabled && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-900">
          <AlertCircle size={18} className="shrink-0 text-amber-700 mt-0.5" />
          <div>
            <div className="font-black">Payments temporarily unavailable</div>
            <p className="text-amber-800 mt-0.5">
              Auction winner payment settlement is disabled in staging (PAYMENTS_ENABLED=false). Bidding remains open for non-financial UI testing, and no auction will be marked paid without verified payment.
            </p>
          </div>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-3xl bg-gradient-to-r from-amber-950 via-[#451a03] to-[#78350f] p-8 text-white shadow-lg">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-amber-400/20 px-3 py-1 text-xs font-black text-amber-300 border border-amber-400/30">
            <Gavel size={14} />
            <span>REAL-TIME D1 AUCTION BIDDING</span>
          </div>
          <h1 className="text-2xl font-black sm:text-3xl">Live Marketplace Auctions</h1>
          <p className="max-w-xl text-xs text-amber-100 sm:text-sm">
            Bid on authentic rare fashion, luxury electronics, and verified artisan products.
            High bids are legally locked and winners complete checkout with guaranteed escrow.
          </p>
        </div>

        {currentUser.role === 'seller' && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 rounded-2xl bg-amber-500 px-5 py-3 text-xs font-black text-white hover:bg-amber-600 transition shadow-md shrink-0"
          >
            <Plus size={16} />
            <span>Create Auction</span>
          </button>
        )}
      </div>

      {/* Auctions Grid matching Android LiveAuctionCard */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {auctions.map((auction) => (
          <LiveAuctionCard
            key={auction.id}
            auction={auction}
            currentUserId={currentUser.id}
            paymentsEnabled={paymentsEnabled}
            onPlaceBid={(auctionId, amount) => {
              const target = auctions.find((a) => a.id === auctionId);
              if (target) {
                setBiddingAuction(target);
                setBidAmount(amount);
              }
            }}
            onClaimWin={(auctionId) => handleWinCheckout(auctionId)}
            onInspectSeller={(sellerId) => onOpenStorefront?.(sellerId)}
          />
        ))}
      </div>
      {/* Place Bid Modal */}
      {biddingAuction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div
            className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Gavel className="text-amber-600" size={18} />
                <h3 className="text-sm font-black text-slate-900">Enter Your Bid</h3>
              </div>
              <button onClick={() => setBiddingAuction(null)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600">{biddingAuction.title}</p>

            <form onSubmit={handleSubmitBid} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700">Bid Amount in Naira (₦)</label>
                <input
                  type="number"
                  min={biddingAuction.currentBid ? biddingAuction.currentBid + 500 : biddingAuction.startingBid}
                  step={500}
                  value={bidAmount}
                  onChange={(e) => setBidAmount(Number(e.target.value))}
                  required
                  className="mt-1 h-12 w-full rounded-2xl border border-slate-200 px-4 font-mono text-base font-black text-slate-900 outline-none focus:border-amber-600"
                />
              </div>

              <div className="rounded-xl bg-amber-50 p-3 text-[11px] text-amber-900 space-y-1">
                <div className="flex items-center gap-1 font-bold">
                  <ShieldCheck size={14} className="text-amber-700" />
                  <span>Binding Bid Policy</span>
                </div>
                <p>
                  Placing a winning bid reserves the inventory. If you are the leader when the auction timer ends,
                  an order will be generated for immediate checkout.
                </p>
              </div>

              <button
                type="submit"
                className="w-full rounded-2xl bg-amber-600 py-3.5 text-xs font-black text-white hover:bg-amber-700 transition shadow-lg"
              >
                Confirm Bid of ₦{bidAmount.toLocaleString('en-NG')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Seller Create Auction Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div
            className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-black text-slate-900">Create Seller Auction</h3>
              <button onClick={() => setShowCreateModal(false)}>✕</button>
            </div>

            <form onSubmit={handleCreateAuction} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700">Select Published Product</label>
                <select
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  className="mt-1 h-11 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none focus:border-amber-600 bg-white"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} (Stock: {p.stock})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">Starting Bid (₦)</label>
                  <input
                    type="number"
                    value={startBidKobo}
                    onChange={(e) => setStartBidKobo(Number(e.target.value))}
                    required
                    className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">Duration (Minutes)</label>
                  <input
                    type="number"
                    value={durationMins}
                    onChange={(e) => setDurationMins(Number(e.target.value))}
                    required
                    className="mt-1 h-10 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full rounded-2xl bg-amber-600 py-3.5 text-xs font-black text-white hover:bg-amber-700 transition"
              >
                Launch Auction
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
