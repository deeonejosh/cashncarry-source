import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, MapPin, Play, Radio, ShieldCheck, Star, Users } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { sellers } from '../../lib/data';
import type { ProductItem } from '../../types';
import ProductCard from '../ui/ProductCard';

interface StorefrontPageProps {
  sellerId: string;
  onBack: () => void;
  onSelectProduct: (product: ProductItem) => void;
  onOpenLive: () => void;
  onOpenVideo: () => void;
}

export default function StorefrontPage({
  sellerId,
  onBack,
  onSelectProduct,
  onOpenLive,
  onOpenVideo,
}: StorefrontPageProps) {
  const {
    products,
    liveRooms,
    shortVideos,
    followingSellers,
    followSeller,
    unfollowSeller,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'products' | 'live' | 'videos' | 'about'>('products');
  const sellerMeta = sellers.find((s) => s.id === sellerId || s.slug === sellerId) || {
    id: sellerId,
    slug: sellerId,
    name: products.find((p) => p.sellerId === sellerId)?.sellerName || sellers[0].name,
    location: 'Lagos',
    rating: 4.8,
    followers: '4.2K',
    sold: 420,
    avatar: sellers[0].avatar,
    badge: 'Verified Store',
    focus: 'Verified Cash N Carry Merchant',
  };
  const storeSummary = `${sellerMeta.focus} — Verified Nigerian Merchant in ${sellerMeta.location}`;
  const sellerProducts = products.filter((p) => p.sellerId === sellerId && !p.archived && p.publication === 'published');
  const sellerLives = liveRooms.filter((r) => r.sellerId === sellerId);
  const sellerVideos = shortVideos.filter((v) => v.sellerId === sellerId);
  const isFollowing = followingSellers.includes(sellerId);

  return (
    <div className="space-y-6 pb-20">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50"
      >
        <ArrowLeft size={14} />
        <span>Back to Marketplace</span>
      </button>

      {/* Storefront Banner matching Android StorefrontScreen */}
      <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="bg-gradient-to-r from-[#093B22] via-[#0E6B38] to-[#084B26] p-6 sm:p-8 text-white">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black">{sellerMeta.name}</h1>
                <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-2.5 py-0.5 text-[11px] font-bold text-emerald-100">
                  <CheckCircle2 size={12} /> Verified Store
                </span>
              </div>
              <p className="text-xs sm:text-sm text-emerald-100/90 max-w-2xl">
                {storeSummary}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-xs text-emerald-100 pt-1">
                <span className="inline-flex items-center gap-1">
                  <MapPin size={13} /> {sellerMeta.location}, Nigeria
                </span>
                <span className="inline-flex items-center gap-1">
                  <Star size={13} className="fill-amber-400 text-amber-400" /> {sellerMeta.rating} rating
                </span>
                <span className="inline-flex items-center gap-1">
                  <Users size={13} /> {sellerProducts.length} active listings
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => (isFollowing ? unfollowSeller(sellerId) : followSeller(sellerId))}
              className={`min-h-[44px] rounded-2xl px-6 text-xs font-black shadow transition ${
                isFollowing
                  ? 'bg-white/15 text-white border border-white/25 hover:bg-white/25'
                  : 'bg-[#FF6B00] text-white hover:bg-orange-600'
              }`}
            >
              {isFollowing ? 'Following Store' : '+ Follow Store'}
            </button>
          </div>
        </div>

        {/* Storefront Tabs matching Android */}
        <div className="flex border-b border-slate-200 px-4 overflow-x-auto">
          {[
            { id: 'products', label: `Products (${sellerProducts.length})` },
            { id: 'live', label: `Livestreams (${sellerLives.length})` },
            { id: 'videos', label: `Shoppable Videos (${sellerVideos.length})` },
            { id: 'about', label: 'About & Policies' },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={`whitespace-nowrap border-b-2 px-4 py-3.5 text-xs font-black transition ${
                activeTab === t.id
                  ? 'border-[#0E6B38] text-[#0E6B38]'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </section>

      {activeTab === 'products' && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {sellerProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelectProduct={onSelectProduct}
            />
          ))}
          {sellerProducts.length === 0 && (
            <div className="col-span-full rounded-2xl border border-slate-200 bg-slate-50 p-10 text-center text-sm text-slate-500">
              No published products for this seller yet.
            </div>
          )}
        </div>
      )}

      {activeTab === 'live' && (
        <div className="grid gap-4 sm:grid-cols-2">
          {sellerLives.map((room) => (
            <div key={room.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm flex items-center justify-between gap-4">
              <div>
                <span className="inline-flex items-center gap-1 rounded-full bg-rose-600 px-2.5 py-0.5 text-[10px] font-black uppercase text-white">
                  <Radio size={11} /> {room.status}
                </span>
                <h3 className="mt-2 font-black text-slate-900">{room.title}</h3>
                <p className="text-xs text-slate-500">{room.viewerCount.toLocaleString()} viewers watching</p>
              </div>
              <button
                type="button"
                onClick={onOpenLive}
                className="rounded-xl bg-[#0E6B38] px-4 py-2.5 text-xs font-black text-white hover:bg-[#084B26]"
              >
                Watch Live
              </button>
            </div>
          ))}
          {sellerLives.length === 0 && (
            <div className="col-span-full rounded-2xl border border-slate-200 bg-slate-50 p-10 text-center text-sm text-slate-500">
              No livestreams scheduled for this seller right now.
            </div>
          )}
        </div>
      )}

      {activeTab === 'videos' && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {sellerVideos.map((vid) => (
            <button
              key={vid.id}
              type="button"
              onClick={onOpenVideo}
              className="group relative aspect-[9/14] overflow-hidden rounded-2xl border border-slate-200 bg-slate-900 text-left shadow-sm"
            >
              <img src={vid.posterUrl} alt={vid.caption} className="h-full w-full object-cover group-hover:scale-105 transition duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
              <div className="absolute top-3 right-3 rounded-full bg-black/50 p-1.5 text-white backdrop-blur-sm">
                <Play size={14} className="fill-white" />
              </div>
              <div className="absolute bottom-3 left-3 right-3 text-white space-y-1">
                <p className="line-clamp-2 text-xs font-bold">{vid.caption}</p>
                <span className="inline-block rounded bg-[#FF6B00] px-2 py-0.5 text-[10px] font-black">
                  ₦{vid.taggedProduct.price.toLocaleString('en-NG')}
                </span>
              </div>
            </button>
          ))}
          {sellerVideos.length === 0 && (
            <div className="col-span-full rounded-2xl border border-slate-200 bg-slate-50 p-10 text-center text-sm text-slate-500">
              No shoppable videos posted by this seller yet.
            </div>
          )}
        </div>
      )}

      {activeTab === 'about' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-6 space-y-3">
          <div className="flex items-center gap-2 text-sm font-black text-slate-900">
            <ShieldCheck size={18} className="text-[#0E6B38]" />
            <span>Merchant Verification &amp; Nationwide Shipping Policy</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            {storeSummary} Nationwide dispatch across all 36 Nigerian states &amp; FCT Abuja within 24–72 hours via verified logistics partners, backed by Cash N Carry Buyer Protection.
          </p>
        </div>
      )}
    </div>
  );
}
