import React, { useState } from 'react';
import { useStore } from '../../../context/StoreContext';
import { categories, sellers } from '../../../lib/data';
import {
  ShieldCheck,
  Package,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  DollarSign,
  AlertTriangle,
  RotateCcw,
  Coins,
  Search,
  Eye,
  FileText,
  Lock,
  Globe,
  Download,
  Copy,
  ExternalLink,
  Mail,
} from 'lucide-react';

interface AdminDashboardPageProps {
  onNavigate?: (tab: string) => void;
}

export default function AdminDashboardPage({ onNavigate }: AdminDashboardPageProps) {
  const {
    products,
    kycSubmissions,
    orders,
    adminApproveProduct,
    adminRejectProduct,
    adminApproveKYC,
    adminRejectKYC,
    adminRefundOrder,
    claimTestCoins,
    stagingConfig,
    showToast,
  } = useStore();
  const paymentsEnabled = stagingConfig.paymentsEnabled;
  const coinsEnabled = paymentsEnabled && stagingConfig.coinsPurchasesEnabled;
  const kycEnabled = stagingConfig.kycUploadsEnabled;

  const [activeTab, setActiveTab] = useState<'products' | 'kyc' | 'orders' | 'coins' | 'sitemap'>('products');
  const [sitemapXmlPreview, setSitemapXmlPreview] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const pendingProducts = products.filter((p) => p.publication === 'pending');
  const pendingKYC = kycSubmissions.filter((k) => k.status === 'pending');
  const totalVolume = orders.reduce((acc, o) => acc + o.total, 0);

  const generateLiveSitemap = () => {
    const baseUrl = 'https://www.cashncarryng.com';
    const now = new Date().toISOString().split('T')[0];
    const approvedProducts = products.filter((p) => p.publication === 'published' && !p.archived);

    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    xml += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"\n`;
    xml += `        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n\n`;

    // Static pages
    const staticPages = [
      { path: '', priority: '1.0', freq: 'daily' },
      { path: '/shop', priority: '0.9', freq: 'hourly' },
      { path: '/for-you', priority: '0.9', freq: 'hourly' },
      { path: '/live', priority: '0.9', freq: 'always' },
      { path: '/flash-deals', priority: '0.8', freq: 'hourly' },
      { path: '/auctions', priority: '0.8', freq: 'hourly' },
    ];

    staticPages.forEach(({ path, priority, freq }) => {
      xml += `  <url>\n    <loc>${baseUrl}${path}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>${freq}</changefreq>\n    <priority>${priority}</priority>\n  </url>\n`;
    });

    // Categories
    categories.forEach((cat) => {
      xml += `  <url>\n    <loc>${baseUrl}/shop?category=${cat.id}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>0.8</priority>\n  </url>\n`;
    });

    // Products
    approvedProducts.forEach((prod) => {
      xml += `  <url>\n    <loc>${baseUrl}/product/${prod.id}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>0.7</priority>\n`;
      if (prod.image) {
        xml += `    <image:image>\n      <image:loc>${prod.image}</image:loc>\n      <image:title>${prod.title.replace(/&/g, '&amp;')}</image:title>\n    </image:image>\n`;
      }
      xml += `  </url>\n`;
    });

    xml += `</urlset>`;
    setSitemapXmlPreview(xml);
    showToast(`Dynamic sitemap generated: ${staticPages.length + categories.length + approvedProducts.length} URLs indexed`);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-3xl bg-gradient-to-r from-purple-950 via-slate-900 to-[#073c22] p-8 text-white shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-purple-500/20 px-3 py-1 text-[10px] font-black uppercase text-purple-300 border border-purple-400/30">
              CASH N CARRY ADMIN CONSOLE
            </span>
            <span className="flex items-center gap-1 text-xs font-bold text-emerald-300">
              <Lock size={12} /> Staging MFA Verified (15-min TTL)
            </span>
          </div>
          <h1 className="text-2xl font-black sm:text-3xl">Platform Administration & Compliance</h1>
          <p className="max-w-xl text-xs text-slate-300 sm:text-sm">
            Review seller listings, verify corporate CAC documents, audit Flutterwave transactions, and enforce marketplace integrity.
          </p>
        </div>

        {onNavigate && (
          <div className="shrink-0 flex items-center gap-2">
            <button
              onClick={() => onNavigate('email-marketing')}
              className="flex items-center gap-1.5 rounded-full bg-orange-500 px-5 py-2.5 text-xs font-black text-white hover:bg-orange-600 transition shadow-lg"
            >
              <Mail size={14} />
              <span>Email Marketing Studio →</span>
            </button>
          </div>
        )}
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-slate-400">Platform GMV Volume</div>
          <div className="text-2xl font-black text-slate-900">₦{totalVolume.toLocaleString('en-NG')}</div>
          <div className="text-[11px] text-slate-500">{orders.length} total orders recorded</div>
        </div>

        <div className="rounded-3xl border border-amber-200 bg-amber-50/50 p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-amber-800">Pending Product Reviews</div>
          <div className="text-2xl font-black text-amber-700">{pendingProducts.length}</div>
          <div className="text-[11px] text-amber-800">Waiting for moderation</div>
        </div>

        <div className="rounded-3xl border border-purple-200 bg-purple-50/50 p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-purple-800">Pending KYC Submissions</div>
          <div className="text-2xl font-black text-purple-700">{pendingKYC.length}</div>
          <div className="text-[11px] text-purple-800">Awaiting compliance verification</div>
        </div>

        <div className="rounded-3xl border border-emerald-200 bg-emerald-50/50 p-5 shadow-sm space-y-1">
          <div className="text-xs font-bold text-emerald-800">Published Listings</div>
          <div className="text-2xl font-black text-emerald-700">
            {products.filter((p) => p.publication === 'published').length}
          </div>
          <div className="text-[11px] text-emerald-800">Live in marketplace catalog</div>
        </div>
      </div>

      {/* Admin Module Tabs */}
      <div className="flex border-b border-slate-200 pb-3 gap-3 overflow-x-auto text-xs font-bold text-slate-600">
        <button
          onClick={() => setActiveTab('products')}
          className={`flex items-center gap-1.5 rounded-xl px-4 py-2 transition ${
            activeTab === 'products' ? 'bg-[#0c5c36] text-white shadow' : 'hover:bg-slate-100'
          }`}
        >
          <Package size={15} />
          <span>Product Moderation ({pendingProducts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('kyc')}
          className={`flex items-center gap-1.5 rounded-xl px-4 py-2 transition ${
            activeTab === 'kyc' ? 'bg-[#0c5c36] text-white shadow' : 'hover:bg-slate-100'
          }`}
        >
          <ShieldCheck size={15} />
          <span>Seller KYC Approvals ({pendingKYC.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-1.5 rounded-xl px-4 py-2 transition ${
            activeTab === 'orders' ? 'bg-[#0c5c36] text-white shadow' : 'hover:bg-slate-100'
          }`}
        >
          <DollarSign size={15} />
          <span>Orders & Refunds ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('coins')}
          className={`flex items-center gap-1.5 rounded-xl px-4 py-2 transition ${
            activeTab === 'coins' ? 'bg-[#0c5c36] text-white shadow' : 'hover:bg-slate-100'
          }`}
        >
          <Coins size={15} />
          <span>Coin Gifting Treasury</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('sitemap');
            if (!sitemapXmlPreview) generateLiveSitemap();
          }}
          className={`flex items-center gap-1.5 rounded-xl px-4 py-2 transition ${
            activeTab === 'sitemap' ? 'bg-[#0c5c36] text-white shadow' : 'hover:bg-slate-100'
          }`}
        >
          <Globe size={15} />
          <span>SEO & Dynamic Sitemap</span>
        </button>

        {onNavigate && (
          <button
            onClick={() => onNavigate('email-marketing')}
            className="flex items-center gap-1.5 rounded-xl px-4 py-2 transition text-orange-600 hover:bg-orange-50 font-bold ml-auto"
          >
            <Mail size={15} />
            <span>Launch Email Studio ↗</span>
          </button>
        )}
      </div>

      {/* Tab 1: Product Moderation Queue */}
      {activeTab === 'products' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-black text-slate-900">Product Moderation Queue</h3>
              <p className="text-xs text-slate-500">
                Review listings submitted by sellers. Approved items appear immediately in the public shop.
              </p>
            </div>
            <span className="text-xs font-bold text-amber-700">
              {pendingProducts.length} Listings Pending
            </span>
          </div>

          {pendingProducts.length === 0 ? (
            <div className="p-12 text-center text-xs text-slate-400">
              No products currently awaiting moderation. All seller listings are reviewed.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {pendingProducts.map((p) => (
                <div key={p.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-4">
                  <div className="flex items-center gap-3">
                    <img src={p.image} alt={p.title} className="h-14 w-14 rounded-2xl object-cover border border-slate-100 shrink-0" />
                    <div>
                      <h4 className="text-xs font-black text-slate-900">{p.title}</h4>
                      <div className="text-[11px] text-slate-400">
                        Seller: <b>{p.sellerName}</b> · Category: <span className="capitalize">{p.category}</span> · Stock: {p.stock}
                      </div>
                      <div className="text-xs font-black text-[#0c5c36] mt-0.5">
                        ₦{p.price.toLocaleString('en-NG')}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => adminApproveProduct(p.id)}
                      className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-black text-white hover:bg-emerald-500 shadow"
                    >
                      <CheckCircle2 size={14} />
                      <span>Approve & Publish</span>
                    </button>
                    <button
                      onClick={() => adminRejectProduct(p.id)}
                      className="flex items-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-rose-600"
                    >
                      <XCircle size={14} />
                      <span>Reject</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Seller KYC Reviews */}
      {activeTab === 'kyc' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900">Corporate CAC Registration Reviews</h3>
            <p className="text-xs text-slate-500">
              Inspect submitted CAC documents. Verified merchants gain the official green badge.
            </p>
          </div>

          {!kycEnabled && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
              <strong>KYC Uploads Disabled in Staging:</strong> Private R2 storage is not provisioned (<code>KYC_UPLOADS_ENABLED=false</code>). Existing entries shown below are isolated test fixtures.
            </div>
          )}

          <div className="divide-y divide-slate-100">
            {kycSubmissions.map((sub) => (
              <div key={sub.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-4 text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-slate-900">{sub.businessName}</span>
                    <span className="font-mono text-emerald-800 font-bold">({sub.cacNumber})</span>
                  </div>
                  <div className="text-slate-500 text-[11px]">
                    Vendor: <b>{sub.sellerName}</b> · Document: {sub.documentName} ({sub.documentSize})
                  </div>
                  <div className="flex items-center gap-3 text-[10px]">
                    <span className="text-emerald-700 font-bold">✓ ClamAV Scan: Clean</span>
                    <span className="text-purple-700 font-bold">🔒 AES-256-GCM Encrypted</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {sub.status === 'pending' ? (
                    <>
                      <button
                        onClick={() => adminApproveKYC(sub.id)}
                        className="rounded-xl bg-purple-700 px-4 py-2 font-black text-white hover:bg-purple-600 shadow"
                      >
                        Approve CAC
                      </button>
                      <button
                        onClick={() => adminRejectKYC(sub.id)}
                        className="rounded-xl border border-slate-200 px-3 py-2 font-bold text-slate-600 hover:bg-slate-50"
                      >
                        Reject
                      </button>
                    </>
                  ) : (
                    <span className="rounded-full bg-emerald-100 px-3 py-1 font-bold text-emerald-800 uppercase text-[10px]">
                      {sub.status}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Orders & Refund Reversals */}
      {activeTab === 'orders' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900">All Marketplace Orders & Reversals</h3>
            <p className="text-xs text-slate-500">
              Audit Flutterwave transaction references and financial reversal status.
            </p>
          </div>

          {!paymentsEnabled && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
              <strong>Payments temporarily unavailable:</strong> Financial reversals and settlement operations are disabled in staging (<code>PAYMENTS_ENABLED=false</code>).
            </div>
          )}

          <div className="divide-y divide-slate-100 text-xs">
            {orders.map((o) => (
              <div key={o.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-900">{o.id}</span>
                    <span className="rounded bg-slate-100 px-2 py-0.5 text-[9px] font-bold uppercase text-slate-600">
                      {o.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Buyer: {o.buyerName} · Total: ₦{o.total.toLocaleString()}
                  </div>
                  {o.flutterwaveRef && (
                    <div className="font-mono text-[10px] text-emerald-800 font-bold">
                      FLW Ref: {o.flutterwaveRef}
                    </div>
                  )}
                </div>

                <div>
                  {o.status !== 'cancelled' && (
                    <button
                      onClick={() => adminRefundOrder(o.id)}
                      disabled={!paymentsEnabled}
                      className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-1.5 font-bold text-rose-700 hover:bg-rose-100 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {paymentsEnabled ? 'Issue Reversal & Restore Stock' : 'Reversals Disabled (Staging)'}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Coins Treasury */}
      {activeTab === 'coins' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900">Promotional Coins Treasury</h3>
            <p className="text-xs text-slate-500">
              Coin purchases and promotional wallet credits are controlled by server-side staging flags.
            </p>
          </div>

          {!coinsEnabled && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
              <strong>Paid coin purchases & minting disabled:</strong> Disabled in staging (<code>PAYMENTS_ENABLED=false</code>, <code>COINS_PURCHASES_ENABLED=false</code>).
            </div>
          )}

          <button
            onClick={() => claimTestCoins(1000)}
            disabled={!coinsEnabled}
            className="flex items-center gap-2 rounded-xl bg-amber-600 px-5 py-2.5 font-black text-white hover:bg-amber-700 shadow disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Coins size={15} />
            <span>{coinsEnabled ? 'Mint +1,000 Promotional Staging Coins' : 'Coin Minting Disabled in Staging'}</span>
          </button>
        </div>
      )}

      {/* Tab 5: SEO & Dynamic Sitemap Engine */}
      {activeTab === 'sitemap' && (
        <div className="space-y-6">
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black text-slate-900">Dynamic XML Sitemap & Crawl Directives</h3>
                  <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-bold text-emerald-800">
                    Active Indexer
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Generated in real-time based on approved catalog items, categories, and marketplace routes.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={generateLiveSitemap}
                  className="flex items-center gap-1.5 rounded-xl bg-[#0c5c36] px-4 py-2 text-xs font-black text-white hover:bg-emerald-900 transition shadow"
                >
                  <Globe size={14} />
                  <span>Regenerate Sitemap</span>
                </button>

                <a
                  href="/sitemap.xml"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 transition"
                >
                  <ExternalLink size={14} />
                  <span>Open /sitemap.xml</span>
                </a>
              </div>
            </div>

            {/* Sitemap Info Cards */}
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 pt-2">
              <div className="rounded-2xl border border-slate-100 bg-slate-50 p-3.5">
                <div className="text-[11px] font-bold text-slate-400">Canonical Base URL</div>
                <div className="font-mono text-xs font-black text-[#0c5c36] truncate">https://www.cashncarryng.com</div>
              </div>
              <div className="rounded-2xl border border-slate-100 bg-slate-50 p-3.5">
                <div className="text-[11px] font-bold text-slate-400">Published Products</div>
                <div className="text-base font-black text-slate-900">
                  {products.filter((p) => p.publication === 'published' && !p.archived).length} URLs
                </div>
              </div>
              <div className="rounded-2xl border border-slate-100 bg-slate-50 p-3.5">
                <div className="text-[11px] font-bold text-slate-400">Shop Categories</div>
                <div className="text-base font-black text-slate-900">{categories.length} URLs</div>
              </div>
              <div className="rounded-2xl border border-slate-100 bg-slate-50 p-3.5">
                <div className="text-[11px] font-bold text-slate-400">Robots.txt Rules</div>
                <div className="text-base font-black text-emerald-800">6 Disallow Rules</div>
              </div>
            </div>

            {/* Live XML Output */}
            <div className="pt-2 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase tracking-wider text-slate-400">
                  Live XML Sitemap Content (public/sitemap.xml)
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      if (!sitemapXmlPreview) generateLiveSitemap();
                      navigator.clipboard.writeText(sitemapXmlPreview);
                      setCopied(true);
                      showToast('Sitemap XML copied to clipboard!');
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="flex items-center gap-1 text-xs font-bold text-[#0c5c36] hover:underline"
                  >
                    <Copy size={13} />
                    <span>{copied ? 'Copied!' : 'Copy XML'}</span>
                  </button>
                  <button
                    onClick={() => {
                      const blob = new Blob([sitemapXmlPreview || ''], { type: 'application/xml' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'sitemap.xml';
                      a.click();
                      URL.revokeObjectURL(url);
                      showToast('Downloaded sitemap.xml');
                    }}
                    className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-slate-900"
                  >
                    <Download size={13} />
                    <span>Download</span>
                  </button>
                </div>
              </div>

              <div className="max-h-72 overflow-y-auto rounded-2xl bg-slate-950 p-4 font-mono text-[11px] text-emerald-400 shadow-inner">
                <pre>{sitemapXmlPreview || 'Click "Regenerate Sitemap" to preview dynamic XML...'}</pre>
              </div>
            </div>

            {/* Robots.txt Card */}
            <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase tracking-wider text-slate-400">
                  Search Engine Directives (public/robots.txt)
                </span>
                <a
                  href="/robots.txt"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-xs font-bold text-[#0c5c36] hover:underline"
                >
                  <ExternalLink size={12} />
                  <span>View /robots.txt</span>
                </a>
              </div>
              <div className="rounded-2xl bg-slate-900 p-4 font-mono text-[11px] text-slate-300">
                <p>User-agent: *</p>
                <p>Allow: /</p>
                <p>Allow: /shop</p>
                <p>Allow: /product/*</p>
                <p className="text-rose-400">Disallow: /admin/*</p>
                <p className="text-rose-400">Disallow: /seller/*</p>
                <p className="text-rose-400">Disallow: /checkout/*</p>
                <p className="text-rose-400">Disallow: /profile/*</p>
                <p className="text-rose-400">Disallow: /orders/*</p>
                <p className="text-rose-400">Disallow: /messages/*</p>
                <p className="pt-2 text-emerald-400">Sitemap: https://www.cashncarryng.com/sitemap.xml</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
