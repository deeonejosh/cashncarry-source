import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductItem } from '../../types';
import { Zap, Clock, ShoppingBag, Flame, Sparkles } from 'lucide-react';

interface FlashDealsPageProps {
  onSelectProduct: (p: ProductItem) => void;
  onProceedToCheckout: () => void;
}

export default function FlashDealsPage({ onSelectProduct, onProceedToCheckout }: FlashDealsPageProps) {
  const { products, addToCart } = useStore();
  const [timeLeft, setTimeLeft] = useState(4 * 3600 + 18 * 60 + 32);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatHours = () => Math.floor(timeLeft / 3600).toString().padStart(2, '0');
  const formatMins = () => Math.floor((timeLeft % 3600) / 60).toString().padStart(2, '0');
  const formatSecs = () => (timeLeft % 60).toString().padStart(2, '0');

  const flashItems = products.slice(0, 6);

  return (
    <div className="space-y-8 pb-16">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-3xl bg-gradient-to-r from-orange-600 via-rose-600 to-amber-600 p-8 text-white shadow-xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-xs font-black backdrop-blur-md">
            <Flame size={14} className="text-yellow-300" />
            <span>EXCLUSIVE WHOLESALE PRICING</span>
          </div>
          <h1 className="text-2xl font-black sm:text-4xl">Limited-Time Flash Deals</h1>
          <p className="max-w-md text-xs text-orange-100 sm:text-sm">
            Grab steep discounts directly from verified Lagos and Abuja suppliers. Prices reset once time expires.
          </p>
        </div>

        {/* Big Countdown Box */}
        <div className="flex items-center gap-2 rounded-2xl bg-black/40 p-4 backdrop-blur-md border border-white/20 text-center">
          <div>
            <div className="font-mono text-2xl font-black">{formatHours()}</div>
            <div className="text-[10px] text-orange-200">HOURS</div>
          </div>
          <span className="font-mono text-2xl font-black">:</span>
          <div>
            <div className="font-mono text-2xl font-black">{formatMins()}</div>
            <div className="text-[10px] text-orange-200">MINS</div>
          </div>
          <span className="font-mono text-2xl font-black">:</span>
          <div>
            <div className="font-mono text-2xl font-black">{formatSecs()}</div>
            <div className="text-[10px] text-orange-200">SECS</div>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {flashItems.map((prod, idx) => {
          const discount = Math.round(((prod.compareAt - prod.price) / prod.compareAt) * 100);
          const percentClaimed = 60 + (idx * 7) % 35;

          return (
            <div
              key={prod.id}
              className="overflow-hidden rounded-3xl border border-orange-100 bg-white p-4 shadow-sm hover:shadow-lg transition space-y-3"
            >
              <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-slate-100">
                <img src={prod.image} alt={prod.title} className="h-full w-full object-cover" />
                <span className="absolute left-3 top-3 rounded-md bg-orange-600 px-2 py-0.5 text-xs font-black text-white shadow">
                  -{discount}% OFF
                </span>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {prod.brand}
                </span>
                <h3
                  onClick={() => onSelectProduct(prod)}
                  className="mt-0.5 text-xs font-black text-slate-900 line-clamp-1 cursor-pointer hover:text-orange-600"
                >
                  {prod.title}
                </h3>

                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-base font-black text-slate-900">
                    ₦{prod.price.toLocaleString('en-NG')}
                  </span>
                  <span className="text-xs text-slate-400 line-through">
                    ₦{prod.compareAt.toLocaleString('en-NG')}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="mt-3 space-y-1">
                  <div className="flex justify-between text-[11px] font-bold text-slate-600">
                    <span>{percentClaimed}% claimed</span>
                    <span className="text-orange-600">Only {prod.stock} left</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-orange-500 to-rose-500"
                      style={{ width: `${percentClaimed}%` }}
                    />
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => addToCart(prod, 1)}
                    className="flex items-center justify-center gap-1 rounded-xl border border-orange-500 bg-orange-50 py-2.5 text-xs font-bold text-orange-700 hover:bg-orange-500 hover:text-white transition"
                  >
                    <ShoppingBag size={14} /> Add
                  </button>
                  <button
                    onClick={() => {
                      addToCart(prod, 1);
                      onProceedToCheckout();
                    }}
                    className="rounded-xl bg-orange-600 py-2.5 text-xs font-black text-white hover:bg-orange-700 transition shadow"
                  >
                    Claim Deal
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
