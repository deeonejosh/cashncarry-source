import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductItem } from '../../types';
import {
  Radio,
  Video,
  VideoOff,
  Mic,
  MicOff,
  Heart,
  MessageCircle,
  ShoppingBag,
  Send,
  Pin,
  Sparkles,
  Users,
  Settings,
  Share2,
  X,
  Plus,
  Coins,
  CheckCircle2,
  AlertCircle,
  Play,
  Maximize2,
} from 'lucide-react';

interface LiveShoppingPageProps {
  onSelectProduct: (p: ProductItem) => void;
  onProceedToCheckout: () => void;
}

interface ChatComment {
  id: string;
  sender: string;
  text: string;
  isBroadcaster?: boolean;
}

export default function LiveShoppingPage({ onSelectProduct, onProceedToCheckout }: LiveShoppingPageProps) {
  const {
    currentUser,
    liveRooms,
    activeLiveRoom,
    setActiveLiveRoom,
    products,
    addToCart,
    coinBalance,
    sendLiveGift,
    stagingConfig,
    showToast,
  } = useStore();

  const isSeller = currentUser.role === 'seller';
  const [streamMode, setStreamMode] = useState<'broadcaster' | 'viewer'>(isSeller ? 'broadcaster' : 'viewer');

  // Media capture state for WHIP Broadcaster
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState(false);
  const [cameraActive, setCameraActive] = useState(true);
  const [micActive, setMicActive] = useState(true);
  const [isLiveBroadcasting, setIsLiveBroadcasting] = useState(false);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);

  // Live Engagement
  const [comments, setComments] = useState<ChatComment[]>([
    { id: '1', sender: 'Amina Lagos', text: 'Love that fabric! Is the size 12 in stock?' },
    { id: '2', sender: 'Olaoluwa Trends', text: 'Yes Amina! Only 4 units left of size 12. Pinned on screen now.', isBroadcaster: true },
    { id: '3', sender: 'Emeka PH', text: 'Can this deliver to Port Harcourt before Friday?' },
    { id: '4', sender: 'Ziva Glow', text: 'Sent you 100 stars! Keep rocking!' },
  ]);
  const [newComment, setNewComment] = useState('');
  const [heartsCount, setHeartsCount] = useState(activeLiveRoom?.heartsCount || 8940);
  const [floatingHearts, setFloatingHearts] = useState<{ id: number; left: number }[]>([]);
  const [viewersCount, setViewersCount] = useState(activeLiveRoom?.viewerCount || 1420);

  // Broadcaster Pinned Product
  const [pinnedProduct, setPinnedProduct] = useState<ProductItem | null>(
    activeLiveRoom?.pinnedProduct || products[4]
  );
  const [productBagModalOpen, setProductBagModalOpen] = useState(false);
  const [giftingModalOpen, setGiftingModalOpen] = useState(false);

  // Setup camera stream on broadcaster mode
  useEffect(() => {
    let stream: MediaStream | null = null;
    if (streamMode === 'broadcaster') {
      navigator.mediaDevices
        ?.getUserMedia({ video: true, audio: true })
        .then((s) => {
          stream = s;
          setMediaStream(s);
          setHasCameraPermission(true);
          if (videoRef.current) {
            videoRef.current.srcObject = s;
          }
        })
        .catch((err) => {
          console.warn('Camera/mic access error (or permissions denied):', err);
          setHasCameraPermission(false);
        });
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [streamMode]);

  const toggleCamera = () => {
    if (mediaStream) {
      const videoTrack = mediaStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setCameraActive(videoTrack.enabled);
      }
    }
  };

  const toggleMic = () => {
    if (mediaStream) {
      const audioTrack = mediaStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setMicActive(audioTrack.enabled);
      }
    }
  };

  const startWhipBroadcast = () => {
    setIsLiveBroadcasting(true);
    showToast('🔴 WHIP Signaling connected to Cloudflare Stream! You are LIVE!');
  };

  const endWhipBroadcast = () => {
    setIsLiveBroadcasting(false);
    showToast('Broadcast ended.');
  };

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    const comment: ChatComment = {
      id: Date.now().toString(),
      sender: currentUser.name,
      text: newComment.trim(),
      isBroadcaster: streamMode === 'broadcaster',
    };
    setComments((prev) => [...prev, comment]);
    setNewComment('');
  };

  const triggerHeartReaction = () => {
    setHeartsCount((prev) => prev + 1);
    const newHeart = { id: Date.now() + Math.random(), left: 60 + Math.random() * 30 };
    setFloatingHearts((prev) => [...prev, newHeart]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 2000);
  };

  const handleSendGift = (giftType: 'rose' | 'star' | 'lion') => {
    const res = sendLiveGift('olaoluwa', giftType);
    if (res.success) {
      triggerHeartReaction();
      setGiftingModalOpen(false);
      setComments((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          sender: currentUser.name,
          text: `🎁 Sent ${giftType.toUpperCase()} gift to the stream!`,
        },
      ]);
    } else {
      showToast(res.message || 'Gift failed');
    }
  };

  const handleBuyPinnedProduct = () => {
    if (pinnedProduct) {
      addToCart(pinnedProduct, 1);
      onProceedToCheckout();
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Stream Controls Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl bg-slate-900 p-4 text-white shadow-md">
        <div className="flex items-center gap-3">
          <span className="flex h-3 w-3 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black">Cloudflare Stream WHIP/WHEP Integration</h2>
              <span className="rounded bg-rose-500/20 px-2 py-0.5 text-[10px] font-bold text-rose-300 border border-rose-400/30">
                {stagingConfig.streamConfigured ? 'Live Stream Active' : 'Staging UI Fixture Mode'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {stagingConfig.streamConfigured
                ? 'Low-latency WebRTC streaming for Cash N Carry Nigeria sellers and shoppers.'
                : 'Non-financial UI preview mode. Configure STREAM_WHIP_URL and STREAM_WHEP_URL secrets for live broadcast.'}
            </p>
          </div>
        </div>

        {/* Mode Toggle */}
        <div className="flex items-center gap-2">
          <div className="rounded-xl bg-slate-800 p-1 flex text-xs font-bold">
            <button
              onClick={() => setStreamMode('viewer')}
              className={`rounded-lg px-3 py-1.5 transition ${
                streamMode === 'viewer' ? 'bg-[#0c5c36] text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Buyer View (WHEP)
            </button>
            <button
              onClick={() => setStreamMode('broadcaster')}
              className={`rounded-lg px-3 py-1.5 transition ${
                streamMode === 'broadcaster' ? 'bg-orange-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Seller Host (WHIP)
            </button>
          </div>
        </div>
      </div>

      {/* Main Livestream Screen (16:9 or Vertical Layout) */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Stream Canvas / Video Area (2 Cols) */}
        <div className="relative aspect-[4/3] sm:aspect-video w-full overflow-hidden rounded-3xl bg-slate-950 shadow-2xl lg:col-span-2 border border-slate-800 flex items-center justify-center">
          {/* Broadcaster Camera View */}
          {streamMode === 'broadcaster' ? (
            hasCameraPermission ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="h-full w-full object-cover transform -scale-x-100"
              />
            ) : (
              <div className="flex flex-col items-center justify-center p-8 text-center text-white">
                <Video size={48} className="text-slate-600 mb-3" />
                <h3 className="text-base font-bold">Webcam & Microphone Required</h3>
                <p className="max-w-md text-xs text-slate-400 mt-1">
                  Cash N Carry WHIP broadcaster uses WebRTC to stream directly to Cloudflare Stream.
                  Allow camera permissions in your browser to start.
                </p>
                <button
                  onClick={() => {
                    navigator.mediaDevices?.getUserMedia({ video: true, audio: true })
                      .then((s) => {
                        setMediaStream(s);
                        setHasCameraPermission(true);
                        if (videoRef.current) videoRef.current.srcObject = s;
                      });
                  }}
                  className="mt-4 rounded-full bg-emerald-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-emerald-500"
                >
                  Enable Camera & Mic
                </button>
              </div>
            )
          ) : (
            /* Buyer WHEP Playback View */
            <div className="relative h-full w-full">
              <img
                src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=1200&auto=format&fit=crop&q=80"
                alt="WHEP Stream Feed"
                className="h-full w-full object-cover opacity-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/60" />
            </div>
          )}

          {/* Floating Hearts Animation Overlay */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            {floatingHearts.map((h) => (
              <span
                key={h.id}
                style={{ left: `${h.left}%` }}
                className="absolute bottom-16 text-3xl animate-bounce text-rose-500 drop-shadow-lg opacity-90"
              >
                ❤️
              </span>
            ))}
          </div>

          {/* Top Glass Overlay: Streamer Badge & Live Metrics */}
          <div className="absolute top-4 inset-x-4 flex items-center justify-between z-20">
            <div className="flex items-center gap-3 rounded-full bg-black/60 px-3.5 py-1.5 backdrop-blur-md border border-white/10 text-white">
              <img
                src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80"
                alt="Seller"
                className="h-7 w-7 rounded-full object-cover border border-emerald-400"
              />
              <div>
                <div className="flex items-center gap-1">
                  <span className="text-xs font-black">Olaoluwa Trends</span>
                  <CheckCircle2 size={12} className="text-emerald-400" />
                </div>
                <div className="text-[10px] text-emerald-300">Lagos · Fashion</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 rounded-full bg-rose-600 px-3 py-1 text-[11px] font-black uppercase text-white shadow-md">
                <span className="h-2 w-2 animate-pulse rounded-full bg-white" />
                <span>LIVE</span>
              </div>

              <div className="flex items-center gap-1 rounded-full bg-black/60 px-3 py-1 text-xs font-bold text-white backdrop-blur-md border border-white/10">
                <Users size={13} className="text-emerald-300" />
                <span>{viewersCount.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Pinned Product Floating Overlay (Bottom Left of Video) */}
          {pinnedProduct && (
            <div className="absolute bottom-4 left-4 z-20 flex max-w-xs items-center gap-3 rounded-2xl bg-black/80 p-2.5 backdrop-blur-md border border-white/20 text-white shadow-2xl animate-in slide-in-from-bottom duration-300">
              <img
                src={pinnedProduct.image}
                alt={pinnedProduct.title}
                className="h-14 w-14 rounded-xl object-cover border border-white/15 shrink-0"
              />
              <div className="min-w-0 flex-1">
                <span className="rounded bg-orange-600 px-1.5 py-0.5 text-[9px] font-black uppercase text-white">
                  PINNED DEAL
                </span>
                <h4 className="mt-0.5 text-xs font-bold truncate">{pinnedProduct.title}</h4>
                <div className="text-xs font-black text-emerald-400">
                  ₦{pinnedProduct.price.toLocaleString('en-NG')}
                </div>
              </div>

              <button
                onClick={handleBuyPinnedProduct}
                className="shrink-0 rounded-xl bg-orange-600 px-3 py-2 text-xs font-black text-white hover:bg-orange-500 shadow-md transition"
              >
                Buy Now
              </button>
            </div>
          )}

          {/* Broadcaster Bar (Bottom Controls when hosting) */}
          {streamMode === 'broadcaster' && (
            <div className="absolute bottom-4 right-4 z-20 flex items-center gap-2 bg-black/80 px-3 py-2 rounded-2xl backdrop-blur-md border border-white/20">
              <button
                onClick={toggleCamera}
                className={`rounded-xl p-2 text-white transition ${cameraActive ? 'bg-white/10 hover:bg-white/20' : 'bg-rose-600'}`}
                title={cameraActive ? 'Turn Off Camera' : 'Turn On Camera'}
              >
                {cameraActive ? <Video size={16} /> : <VideoOff size={16} />}
              </button>
              <button
                onClick={toggleMic}
                className={`rounded-xl p-2 text-white transition ${micActive ? 'bg-white/10 hover:bg-white/20' : 'bg-rose-600'}`}
                title={micActive ? 'Mute Mic' : 'Unmute Mic'}
              >
                {micActive ? <Mic size={16} /> : <MicOff size={16} />}
              </button>

              {isLiveBroadcasting ? (
                <button
                  onClick={endWhipBroadcast}
                  className="rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-black text-white hover:bg-rose-700"
                >
                  End Stream
                </button>
              ) : (
                <button
                  onClick={startWhipBroadcast}
                  className="rounded-xl bg-emerald-600 px-4 py-1.5 text-xs font-black text-white hover:bg-emerald-500 shadow"
                >
                  Go Live (WHIP)
                </button>
              )}
            </div>
          )}
        </div>

        {/* Right Col: Live Chat & Interactivity */}
        <div className="flex h-[520px] flex-col rounded-3xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          {/* Chat Header */}
          <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-4 py-3">
            <div className="flex items-center gap-2 text-xs font-black text-slate-800">
              <MessageCircle size={15} className="text-[#0c5c36]" />
              <span>Live Audience Chat</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setProductBagModalOpen(true)}
                className="flex items-center gap-1 rounded-xl bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-800 hover:bg-emerald-100"
                title="View all products featured in this stream"
              >
                <ShoppingBag size={13} />
                <span>Bag ({products.length})</span>
              </button>
            </div>
          </div>

          {/* Chat Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {comments.map((c) => (
              <div
                key={c.id}
                className={`rounded-2xl p-2.5 text-xs leading-relaxed ${
                  c.isBroadcaster
                    ? 'bg-emerald-50/80 border border-emerald-200 text-emerald-950'
                    : 'bg-slate-50 text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between font-bold text-[11px] mb-0.5">
                  <span className={c.isBroadcaster ? 'text-emerald-800 flex items-center gap-1 font-black' : 'text-slate-900'}>
                    {c.sender}
                    {c.isBroadcaster && <span className="rounded bg-emerald-200 px-1 py-0.2 text-[9px] uppercase">HOST</span>}
                  </span>
                </div>
                <div>{c.text}</div>
              </div>
            ))}
          </div>

          {/* Quick Gifting & Reaction Bar */}
          <div className="flex items-center justify-between border-t border-slate-100 bg-slate-50/70 px-4 py-2">
            <button
              onClick={() => setGiftingModalOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-amber-100 px-3 py-1.5 text-xs font-extrabold text-amber-900 hover:bg-amber-200 transition"
            >
              <Coins size={14} className="text-amber-600" />
              <span>Send Gift ({coinBalance} coins)</span>
            </button>

            <button
              onClick={triggerHeartReaction}
              className="flex items-center gap-1.5 rounded-xl bg-rose-50 px-3 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-100 transition active:scale-95"
            >
              <Heart size={15} className="fill-rose-500 text-rose-500" />
              <span>{heartsCount.toLocaleString()}</span>
            </button>
          </div>

          {/* Chat Input */}
          <form onSubmit={handleSendComment} className="border-t border-slate-200 p-3 flex gap-2">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Ask the seller a question..."
              className="h-10 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs outline-none focus:border-emerald-600"
            />
            <button
              type="submit"
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0c5c36] text-white hover:bg-emerald-900 transition"
            >
              <Send size={15} />
            </button>
          </form>
        </div>
      </div>

      {/* Featured Products Bag Modal */}
      {productBagModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div
            className="flex h-[80vh] w-full max-w-lg flex-col overflow-hidden rounded-3xl bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 p-5">
              <div className="flex items-center gap-2">
                <ShoppingBag size={18} className="text-[#0c5c36]" />
                <h3 className="text-base font-black text-slate-900">Featured Stream Products</h3>
              </div>
              <button
                onClick={() => setProductBagModalOpen(false)}
                className="rounded-full p-2 text-slate-400 hover:bg-slate-100"
              >
                <X size={18} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 divide-y divide-slate-100 space-y-3">
              {products.slice(0, 6).map((prod) => (
                <div key={prod.id} className="flex items-center justify-between pt-3">
                  <div className="flex items-center gap-3">
                    <img src={prod.image} alt={prod.title} className="h-14 w-14 rounded-xl object-cover" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{prod.title}</h4>
                      <div className="text-xs font-black text-[#0c5c36]">
                        ₦{prod.price.toLocaleString('en-NG')}
                      </div>
                      <div className="text-[10px] text-slate-400">{prod.stock} units available</div>
                    </div>
                  </div>

                  <div className="flex gap-1.5">
                    {streamMode === 'broadcaster' ? (
                      <button
                        onClick={() => {
                          setPinnedProduct(prod);
                          setProductBagModalOpen(false);
                          showToast(`Pinned "${prod.title}" to stream overlay!`);
                        }}
                        className="rounded-xl border border-[#0c5c36] bg-emerald-50 px-3 py-1.5 text-xs font-bold text-[#0c5c36]"
                      >
                        Pin to Screen
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          addToCart(prod, 1);
                          setProductBagModalOpen(false);
                        }}
                        className="rounded-xl bg-[#0c5c36] px-3 py-1.5 text-xs font-black text-white hover:bg-emerald-900"
                      >
                        Add to Cart
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Gifting Modal */}
      {giftingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in">
          <div
            className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl text-center space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900">Send Live Shopping Gift</h3>
              <button onClick={() => setGiftingModalOpen(false)}>
                <X size={18} className="text-slate-400" />
              </button>
            </div>
            <p className="text-xs text-slate-500">
              Gifts are deducted from your promotional coin balance and displayed on the stream!
            </p>

            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => handleSendGift('rose')}
                className="flex flex-col items-center rounded-2xl border border-rose-200 bg-rose-50/50 p-3 hover:bg-rose-100 transition"
              >
                <span className="text-3xl">🌹</span>
                <span className="mt-1 text-xs font-bold text-slate-800">Rose</span>
                <span className="text-[11px] font-black text-rose-700">10 coins</span>
              </button>

              <button
                onClick={() => handleSendGift('star')}
                className="flex flex-col items-center rounded-2xl border border-amber-200 bg-amber-50/50 p-3 hover:bg-amber-100 transition"
              >
                <span className="text-3xl">⭐</span>
                <span className="mt-1 text-xs font-bold text-slate-800">Star</span>
                <span className="text-[11px] font-black text-amber-700">100 coins</span>
              </button>

              <button
                onClick={() => handleSendGift('lion')}
                className="flex flex-col items-center rounded-2xl border border-orange-200 bg-orange-50/50 p-3 hover:bg-orange-100 transition"
              >
                <span className="text-3xl">🦁</span>
                <span className="mt-1 text-xs font-bold text-slate-800">Lion</span>
                <span className="text-[11px] font-black text-orange-700">1,000 coins</span>
              </button>
            </div>

            <div className="rounded-xl bg-slate-50 p-2 text-xs text-slate-600">
              Your promotional coin balance: <b>{coinBalance} coins</b>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
