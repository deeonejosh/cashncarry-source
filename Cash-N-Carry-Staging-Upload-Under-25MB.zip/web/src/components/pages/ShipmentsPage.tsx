import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Truck, CheckCircle2, Clock, MapPin, Search, ShieldCheck, RefreshCw } from 'lucide-react';

interface ShipmentsPageProps {
  initialTracking?: string;
}

export default function ShipmentsPage({ initialTracking = 'GIG-LAG-782194' }: ShipmentsPageProps) {
  const { carrierTrackings, showToast } = useStore();
  const [searchTracking, setSearchTracking] = useState(initialTracking);
  const [activeTrackingNumber, setActiveTrackingNumber] = useState(initialTracking);

  const activeTracking = carrierTrackings[activeTrackingNumber] || Object.values(carrierTrackings)[0];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (carrierTrackings[searchTracking.trim()]) {
      setActiveTrackingNumber(searchTracking.trim());
    } else {
      showToast(`Tracking code "${searchTracking}" not found in staging registry`);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="rounded-3xl bg-[#0c5c36] p-8 text-white shadow-lg space-y-4">
        <div>
          <span className="rounded-full bg-white/20 px-3 py-1 text-[10px] font-black uppercase tracking-wider text-emerald-200">
            NATIONWIDE LOGISTICS PARTNER
          </span>
          <h1 className="mt-2 text-2xl font-black sm:text-3xl">Carrier Shipment Tracking</h1>
          <p className="mt-1 text-xs text-emerald-100 sm:text-sm">
            Real-time delivery milestones powered by signed carrier integration webhooks.
          </p>
        </div>

        {/* Tracking Input */}
        <form onSubmit={handleSearch} className="max-w-xl flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
            <input
              type="text"
              value={searchTracking}
              onChange={(e) => setSearchTracking(e.target.value)}
              placeholder="Enter tracking number (e.g. GIG-LAG-782194)..."
              className="h-11 w-full rounded-2xl bg-white pl-10 pr-4 text-xs font-mono font-bold text-slate-900 outline-none"
            />
          </div>
          <button
            type="submit"
            className="rounded-2xl bg-orange-500 px-5 text-xs font-black text-white hover:bg-orange-600 shadow"
          >
            Track
          </button>
        </form>
      </div>

      {activeTracking ? (
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {/* Main Timeline Card (2 Cols) */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-6 lg:col-span-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <div className="text-xs text-slate-400 font-bold uppercase">Shipment Tracking</div>
                <div className="font-mono text-lg font-black text-slate-900">{activeTracking.trackingNumber}</div>
              </div>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800">
                  {activeTracking.currentStatus}
                </span>
                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-700">
                  {activeTracking.carrier}
                </span>
              </div>
            </div>

            {/* Timeline */}
            <div className="relative pl-6 space-y-8 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-emerald-200">
              {activeTracking.events.map((event, idx) => (
                <div key={idx} className="relative space-y-1">
                  <div className="absolute -left-6 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-white border-2 border-[#0c5c36]">
                    <div className="h-2 w-2 rounded-full bg-[#0c5c36]" />
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-black text-slate-900">{event.status}</span>
                    <span className="text-[11px] text-slate-400 font-medium">{event.timestamp}</span>
                  </div>
                  <div className="text-xs font-semibold text-emerald-800">{event.location}</div>
                  <p className="text-xs text-slate-500">{event.note}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery Meta Sidebar */}
          <div className="space-y-4">
            <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-3">
                Estimated Delivery
              </h3>
              <div className="text-2xl font-black text-[#0c5c36]">
                {activeTracking.estimatedDelivery}
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Courier will contact you on the phone number provided in your delivery address prior to final drop-off.
              </p>

              <div className="rounded-2xl bg-emerald-50 p-4 border border-emerald-100 space-y-2 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-emerald-900">
                  <ShieldCheck size={16} className="text-emerald-700" />
                  <span>Escrow Protection Active</span>
                </div>
                <p className="text-slate-600 text-[11px]">
                  Funds remain securely held in escrow until you verify the package contents.
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center text-xs text-slate-500">No active tracking record found.</div>
      )}
    </div>
  );
}
