import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import ProductCard from '../ui/ProductCard';
import LiveAuctionCard from '../ui/LiveAuctionCard';
import { ProductItem } from '../../types';
import { categories, heroStats, sellers } from '../../lib/data';
import {
  Sparkles,
  ArrowRight,
  Radio,
  Zap,
  ShieldCheck,
  CheckCircle2,
  Play,
  Heart,
  ShoppingBag,
  Truck,
  RotateCcw,
  Headphones,
  Star,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  Clock,
  Eye,
  Store,
} from 'lucide-react';

interface HomePageProps {
  setCurrentTab: (tab: string) => void;
  onSelectProduct: (product: ProductItem) => void;
  onSelectCategory?: (category: string) => void;
  onOpenStorefront?: (sellerId: string) => void;
}

export default function HomePage({ setCurrentTab, onSelectProduct, onSelectCategory, onOpenStorefront }: HomePageProps) {
  const { products, auctions, currentUser, stagingConfig, placeBid, followSeller, unfollowSeller, followingSellers, showToast } = useStore();

  const [activeProductFilter, setActiveProductFilter] = useState<string>('all');
  const [activeCarouselSlide, setActiveCarouselSlide] = useState(0);

  const publishedProducts = products.filter((p) => p.publication === 'published' && !p.archived);

  // Filter products by category for Popular Products section
  const filteredProducts = publishedProducts.filter((p) => {
    if (activeProductFilter === 'all') return true;
    if (activeProductFilter === 'phones') return p.category === 'tech' && p.title.toLowerCase().includes('phone');
    if (activeProductFilter === 'electronics') return p.category === 'tech';
    if (activeProductFilter === 'fashion') return p.category === 'fashion';
    if (activeProductFilter === 'home') return p.category === 'home';
    if (activeProductFilter === 'beauty') return p.category === 'beauty';
    return true;
  });

  const productFilterTabs = [
    { id: 'all', label: 'All' },
    { id: 'phones', label: 'Phones' },
    { id: 'electronics', label: 'Electronics' },
    { id: 'fashion', label: 'Fashion' },
    { id: 'home', label: 'Home' },
    { id: 'beauty', label: 'Beauty' },
  ];

  return (
    <div className="space-y-10 pb-16">
      
      {/* MOBILE ONLY: Top Notification Sub-banner */}
      <div className="flex md:hidden items-center justify-between py-1 px-1">
        <button
          onClick={() => setCurrentTab('live')}
          className="rounded-full bg-[#0c5c36] px-3 py-1 text-[11px] font-black text-white shadow-sm flex items-center gap-1.5"
        >
          <span>Watch Live for Hot Deals</span>
        </button>

        <button
          onClick={() => setCurrentTab('live')}
          className="flex items-center gap-1.5 text-xs font-bold text-rose-600 hover:text-rose-700 transition"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
          </span>
          <span>12 Live Now</span>
          <ChevronRight size={14} />
        </button>
      </div>

      {/* HERO SECTION: Wide Green Card + 2 Stacked Right Promo Cards on Desktop */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12 items-stretch">
        
        {/* Main Green Hero Banner (7 cols on desktop) */}
        <section className="lg:col-span-8 relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0c5c36] via-[#09472a] to-[#042415] p-6 sm:p-10 md:p-12 text-white shadow-xl flex flex-col justify-between">
          <div className="relative z-10 max-w-xl space-y-4">
            
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3.5 py-1 text-[11px] font-black tracking-wide text-emerald-200 backdrop-blur-md border border-white/15">
              <span>🇳🇬</span>
              <span className="uppercase">Nigeria's Live Shopping Marketplace</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl font-black tracking-tight sm:text-5xl sm:leading-[1.12]">
              Watch live. <br />
              <span className="text-white">Discover. </span>
              <span className="text-orange-400">Shop.</span>
            </h1>

            {/* Subtitle */}
            <p className="text-xs sm:text-sm leading-relaxed text-emerald-100/90 max-w-md">
              Shop from trusted Nigerian sellers, discover amazing deals, enjoy live shopping, auctions and exclusive offers — all in one place.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setCurrentTab('shop')}
                className="flex items-center gap-2 rounded-full bg-orange-500 px-6 py-3 text-xs font-black text-white shadow-lg transition hover:bg-orange-600 hover:scale-105"
              >
                <span>Start Shopping</span>
                <ArrowRight size={15} />
              </button>

              <button
                onClick={() => setCurrentTab('live')}
                className="flex items-center gap-2 rounded-full bg-white/10 px-5 py-3 text-xs font-bold text-white backdrop-blur-md border border-white/20 transition hover:bg-white/20"
              >
                <Play size={14} className="fill-white" />
                <span>Watch Live</span>
              </button>
            </div>

            {/* Hero Stats */}
            <div className="mt-6 grid grid-cols-3 gap-4 border-t border-white/15 pt-5">
              {heroStats.map((stat) => (
                <div key={stat.label}>
                  <div className="text-xl sm:text-2xl font-black text-white">{stat.value}</div>
                  <div className="text-[11px] text-emerald-200/80">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Smiling Nigerian Shopper Image Right Graphic */}
          <div className="absolute right-0 bottom-0 top-0 w-1/2 hidden sm:flex items-end justify-end pointer-events-none select-none overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80"
              alt="Happy Nigerian Shopper with Cash N Carry Bags"
              className="h-full w-full object-cover object-top opacity-85 mask-radial"
              style={{
                maskImage: 'linear-gradient(to left, black 65%, transparent 100%)',
                WebkitMaskImage: 'linear-gradient(to left, black 65%, transparent 100%)',
              }}
            />
          </div>
        </section>

        {/* Desktop Right Stacked Promo Cards (4 cols on desktop) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          
          {/* Card 1: Flash Deals Banner */}
          <div
            onClick={() => setCurrentTab('flash-deals')}
            className="flex-1 cursor-pointer rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 p-6 text-white shadow-lg transition hover:scale-[1.01] flex flex-col justify-between relative overflow-hidden group"
          >
            <div className="space-y-1 relative z-10 max-w-[75%]">
              <h3 className="text-xl font-black tracking-tight">Flash deals</h3>
              <p className="text-xs text-amber-100">Limited-time offers on top products</p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-black text-white group-hover:underline">
                <span>Shop Now</span>
                <ArrowRight size={14} />
              </div>
            </div>

            <div className="absolute right-3 bottom-2 text-white/30 group-hover:text-white/40 transition">
              <Zap size={80} className="fill-white/30 stroke-none" />
            </div>
          </div>

          {/* Card 2: Shop Nigerian / Shop Local */}
          <div
            onClick={() => setCurrentTab('shop')}
            className="flex-1 cursor-pointer rounded-3xl border border-slate-200 bg-white p-6 shadow-md transition hover:border-[#0c5c36] hover:shadow-lg flex flex-col justify-between relative overflow-hidden group"
          >
            <div className="space-y-1 relative z-10 max-w-[75%]">
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800">Shop Nigerian</span>
              <h3 className="text-lg font-black text-slate-900 tracking-tight leading-snug">
                Shop local. <br />Find something special.
              </h3>
              <p className="text-xs text-slate-500">Support Nigerian sellers and businesses.</p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-black text-[#0c5c36] group-hover:underline">
                <span>Explore Now</span>
                <ArrowRight size={14} />
              </div>
            </div>

            {/* Nigerian Flag Visual */}
            <div className="absolute right-5 bottom-5 flex flex-col items-center">
              <div className="flex h-12 w-16 overflow-hidden rounded-lg shadow-md border border-slate-200">
                <div className="flex-1 bg-[#0c5c36]" />
                <div className="flex-1 bg-white" />
                <div className="flex-1 bg-[#0c5c36]" />
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* MOBILE ONLY: Carousel Pagination Dots */}
      <div className="flex md:hidden justify-center items-center gap-1.5 pt-1">
        {[0, 1, 2, 3].map((dot) => (
          <span
            key={dot}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              dot === 0 ? 'w-5 bg-[#0c5c36]' : 'w-1.5 bg-slate-300'
            }`}
          />
        ))}
      </div>

      {/* SECTION 2: SHOP BY CATEGORY */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg sm:text-xl font-black text-slate-900">Shop by category</h2>
          <button
            onClick={() => setCurrentTab('shop')}
            className="text-xs font-bold text-[#0c5c36] hover:underline flex items-center gap-1"
          >
            <span>View all categories</span>
            <ArrowRight size={13} />
          </button>
        </div>

        {/* Responsive Grid: 8 on Desktop, 6 on Mobile */}
        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {categories.slice(0, 8).map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                onSelectCategory?.(cat.id);
                setCurrentTab('shop');
              }}
              className="group flex flex-col items-center justify-center rounded-2xl p-3 sm:p-4 text-white shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-md text-center"
              style={{ backgroundColor: cat.bgHex }}
            >
              <span className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center text-2xl drop-shadow-sm group-hover:scale-110 transition">
                {cat.icon}
              </span>
              <span className="mt-2 text-xs sm:text-sm font-black tracking-tight leading-tight">
                {cat.name}
              </span>
              <span className="hidden lg:block text-[10px] text-white/80 line-clamp-1 mt-0.5">
                {cat.subtitle}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* SECTION 3: FEATURED SELLERS */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg sm:text-xl font-black text-slate-900">Featured sellers</h2>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentTab('shop')}
              className="text-xs font-bold text-[#0c5c36] hover:underline"
            >
              View all sellers →
            </button>
            <div className="hidden sm:flex items-center gap-1 text-slate-400">
              <button className="h-7 w-7 rounded-full border border-slate-200 flex items-center justify-center hover:bg-slate-50">
                <ChevronLeft size={16} />
              </button>
              <button className="h-7 w-7 rounded-full border border-slate-200 flex items-center justify-center hover:bg-slate-50">
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {sellers.slice(0, 3).map((seller) => {
            const isFollowing = followingSellers.includes(seller.id);
            return (
              <div
                key={seller.id}
                className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-[#0c5c36] hover:shadow-md space-y-4"
              >
                {/* Seller Top Row */}
                <div className="flex items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => onOpenStorefront?.(seller.id)}
                    className="flex items-center gap-3 min-w-0 text-left group/seller"
                  >
                    <img
                      src={seller.avatar}
                      alt={seller.name}
                      className="h-12 w-12 rounded-2xl object-cover border border-slate-100"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-xs font-black text-slate-900 truncate group-hover/seller:text-[#0E6B38]">{seller.name}</h3>
                        <CheckCircle2 size={13} className="text-emerald-700 shrink-0" />
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">{seller.focus}</div>
                      <div className="text-[11px] font-bold text-slate-600">{seller.followers} followers</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      if (isFollowing) {
                        unfollowSeller(seller.id);
                        showToast(`Unfollowed ${seller.name}`);
                      } else {
                        followSeller(seller.id);
                        showToast(`Now following ${seller.name}!`);
                      }
                    }}
                    className={`rounded-full px-4 py-1.5 text-xs font-bold transition shrink-0 ${
                      isFollowing
                        ? 'border border-slate-200 bg-slate-100 text-slate-700'
                        : 'bg-[#0c5c36] text-white hover:bg-emerald-900 shadow-sm'
                    }`}
                  >
                    {isFollowing ? 'Following' : 'Follow'}
                  </button>
                </div>

                {/* Seller Showcase Thumbnails */}
                {seller.sampleProducts && (
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                    {seller.sampleProducts.map((img, i) => (
                      <div key={i} className="aspect-[4/3] rounded-xl overflow-hidden bg-slate-50 border border-slate-100">
                        <img src={img} alt="Showcase" className="h-full w-full object-cover transition hover:scale-105" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* SECTION 4: LIVE SHOPPING (Cloudflare Stream WHIP/WHEP Preview) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-rose-600 font-black flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
              <span className="text-lg sm:text-xl font-black text-slate-900">Live shopping</span>
            </span>
            <span className="rounded-full bg-rose-600 px-2 py-0.5 text-[10px] font-black uppercase text-white shadow-sm animate-pulse">
              ● LIVE NOW
            </span>
          </div>

          <button
            onClick={() => setCurrentTab('live')}
            className="text-xs font-bold text-[#0c5c36] hover:underline"
          >
            View all live streams →
          </button>
        </div>

        {/* Live Stream Room Cards (Matching Image 2) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Live Card 1 */}
          <div className="relative overflow-hidden rounded-3xl bg-slate-950 text-white min-h-[240px] shadow-lg group flex flex-col justify-between p-6">
            <img
              src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800&auto=format&fit=crop&q=80"
              alt="Mega Powerbank unboxing"
              className="absolute inset-0 h-full w-full object-cover opacity-50 transition duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

            {/* Top Bar */}
            <div className="relative z-10 flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-rose-600 px-3 py-1 text-[10px] font-black uppercase tracking-wider backdrop-blur-md">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
                LIVE 1.2K
              </span>
              <span className="rounded-full bg-black/50 px-2.5 py-1 text-[10px] font-bold backdrop-blur-md border border-white/10 text-emerald-300">
                WHIP Stream Active
              </span>
            </div>

            {/* Bottom Info */}
            <div className="relative z-10 space-y-2">
              <h3 className="text-lg font-black leading-snug">
                Mega Powerbank unboxing & Flash sale
              </h3>
              <div className="text-xs text-emerald-300 font-bold">By NaijaTechMarket</div>
              <div className="pt-2">
                <button
                  onClick={() => setCurrentTab('live')}
                  className="flex items-center gap-2 rounded-full bg-emerald-800 px-5 py-2 text-xs font-black text-white hover:bg-emerald-700 transition shadow-md"
                >
                  <Play size={13} className="fill-white" />
                  <span>Watch Live</span>
                </button>
              </div>
            </div>
          </div>

          {/* Live Card 2 */}
          <div className="relative overflow-hidden rounded-3xl bg-slate-950 text-white min-h-[240px] shadow-lg group flex flex-col justify-between p-6">
            <img
              src="https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800&auto=format&fit=crop&q=80"
              alt="Streetwear Deals"
              className="absolute inset-0 h-full w-full object-cover opacity-50 transition duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

            {/* Top Bar */}
            <div className="relative z-10 flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-rose-600 px-3 py-1 text-[10px] font-black uppercase tracking-wider backdrop-blur-md">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
                LIVE 640
              </span>
              <span className="rounded-full bg-black/50 px-2.5 py-1 text-[10px] font-bold backdrop-blur-md border border-white/10 text-amber-300">
                Flash Vouchers
              </span>
            </div>

            {/* Bottom Info */}
            <div className="relative z-10 space-y-2">
              <h3 className="text-lg font-black leading-snug">
                Streetwear Deals – Up to 40% Off
              </h3>
              <div className="text-xs text-orange-300 font-bold">By UrbanWear NG</div>
              <div className="pt-2">
                <button
                  onClick={() => setCurrentTab('live')}
                  className="flex items-center gap-2 rounded-full bg-emerald-800 px-5 py-2 text-xs font-black text-white hover:bg-emerald-700 transition shadow-md"
                >
                  <Play size={13} className="fill-white" />
                  <span>Watch Live</span>
                </button>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* SECTION 5: POPULAR PRODUCTS */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900">Popular products</h2>
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-3">
            {/* Filter Pills */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
              {productFilterTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveProductFilter(tab.id)}
                  className={`rounded-full px-3.5 py-1 text-xs font-bold transition whitespace-nowrap ${
                    activeProductFilter === tab.id
                      ? 'bg-[#0c5c36] text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => setCurrentTab('shop')}
              className="text-xs font-bold text-[#0c5c36] hover:underline whitespace-nowrap"
            >
              View more products →
            </button>
          </div>
        </div>

        {/* 6 Products Grid Matching Image 2 */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {filteredProducts.slice(0, 6).map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelectProduct={onSelectProduct}
            />
          ))}
        </div>
      </section>

      {/* SECTION 5B: LIVE AUCTIONS HIGHLIGHT */}
      {auctions.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900">Live Marketplace Auctions</h2>
              <p className="text-xs text-slate-500">Synchronized countdown timers & instant bid increments</p>
            </div>
            <button
              onClick={() => setCurrentTab('auctions')}
              className="text-xs font-bold text-[#0c5c36] hover:underline"
            >
              View all auctions →
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {auctions.slice(0, 3).map((auction) => (
              <LiveAuctionCard
                key={auction.id}
                auction={auction}
                currentUserId={currentUser.id}
                paymentsEnabled={stagingConfig.paymentsEnabled}
                onPlaceBid={(auctionId, amount) => placeBid(auctionId, amount)}
                onClaimWin={() => setCurrentTab('auctions')}
                onInspectSeller={(sellerId) => onOpenStorefront?.(sellerId)}
              />
            ))}
          </div>
        </section>
      )}

      {/* SECTION 6: TRUST BADGES HORIZONTAL BAR */}
      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6 text-center sm:text-left">
          
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-emerald-50 text-[#0c5c36]">
              <Truck size={20} />
            </div>
            <div>
              <div className="text-xs font-black text-slate-900">Nationwide Delivery</div>
              <div className="text-[11px] text-slate-500">Across Nigeria</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-emerald-50 text-[#0c5c36]">
              <ShieldCheck size={20} />
            </div>
            <div>
              <div className="text-xs font-black text-slate-900">Secure Payments</div>
              <div className="text-[11px] text-slate-500">Powered by Flutterwave</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-emerald-50 text-[#0c5c36]">
              <RotateCcw size={20} />
            </div>
            <div>
              <div className="text-xs font-black text-slate-900">Easy Returns</div>
              <div className="text-[11px] text-slate-500">Hassle-free process</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-emerald-50 text-[#0c5c36]">
              <Headphones size={20} />
            </div>
            <div>
              <div className="text-xs font-black text-slate-900">Reliable Support</div>
              <div className="text-[11px] text-slate-500">We're here to help</div>
            </div>
          </div>

          <div className="col-span-2 sm:col-span-1 flex items-center gap-3 justify-center sm:justify-start">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-emerald-50 text-[#0c5c36]">
              <Star size={20} />
            </div>
            <div>
              <div className="text-xs font-black text-slate-900">Trusted Marketplace</div>
              <div className="text-[11px] text-slate-500">Verified sellers & quality products</div>
            </div>
          </div>

        </div>
      </section>

      {/* SECTION 7: GROW YOUR BUSINESS ON CASH N CARRY CALLOUT BANNER */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#073c22] via-[#0c5c36] to-[#073c22] p-8 md:p-12 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="relative z-10 max-w-2xl space-y-2 text-center md:text-left">
          <span className="text-[10px] font-black uppercase tracking-widest text-emerald-300">
            GROW YOUR BUSINESS ON CASH N CARRY
          </span>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Sell on Cash N Carry. Reach more customers.
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed max-w-xl">
            Set up your store, list your products, go live, run auctions and grow your business with thousands of active shoppers across Nigeria.
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap items-center justify-center gap-3 shrink-0">
          <button
            onClick={() => {
              setCurrentTab('seller-kyc');
            }}
            className="rounded-full bg-orange-500 px-6 py-3 text-xs font-black text-white hover:bg-orange-600 transition shadow-lg"
          >
            Become a Seller →
          </button>
          <button
            onClick={() => {
              setCurrentTab('policies');
            }}
            className="rounded-full border border-white/30 bg-white/10 px-5 py-3 text-xs font-bold text-white hover:bg-white/20 transition backdrop-blur-sm"
          >
            Learn How It Works
          </button>
        </div>

        {/* Background decorative emblem */}
        <div className="absolute right-[-20px] bottom-[-20px] opacity-10 pointer-events-none select-none">
          <Store size={260} />
        </div>
      </section>

    </div>
  );
}
