import React, { useState, useEffect } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { ProductItem, Order } from './types';
import Navbar from './components/ui/Navbar';
import MobileNav from './components/ui/MobileNav';
import Footer from './components/ui/Footer';
import CartDrawer from './components/ui/CartDrawer';
import QADiagnosticModal from './components/ui/QADiagnosticModal';
import ZipExportModal from './components/ui/ZipExportModal';
import SEOHead from './components/seo/SEOHead';

// Pages
import HomePage from './components/pages/HomePage';
import ShopPage from './components/pages/ShopPage';
import ForYouVideoFeedPage from './components/pages/ForYouVideoFeedPage';
import ProductDetailsPage from './components/pages/ProductDetailsPage';
import CheckoutPage from './components/pages/CheckoutPage';
import CheckoutCompletePage from './components/pages/CheckoutCompletePage';
import OrdersPage from './components/pages/OrdersPage';
import ProfilePage from './components/pages/ProfilePage';
import CreateModal from './components/ui/CreateModal';
import LiveShoppingPage from './components/pages/LiveShoppingPage';
import AuctionsPage from './components/pages/AuctionsPage';
import CoinsPage from './components/pages/CoinsPage';
import FlashDealsPage from './components/pages/FlashDealsPage';
import WishlistPage from './components/pages/WishlistPage';
import ShipmentsPage from './components/pages/ShipmentsPage';
import MessagesPage from './components/pages/MessagesPage';
import NotificationsPage from './components/pages/NotificationsPage';
import ReturnsPage from './components/pages/ReturnsPage';
import EmailMarketingPage from './components/pages/EmailMarketingPage';
import NewsletterModal from './components/ui/NewsletterModal';

// Seller Centre Pages
import SellerDashboardPage from './components/pages/seller/SellerDashboardPage';
import SellerProductsPage from './components/pages/seller/SellerProductsPage';
import SellerOrdersPage from './components/pages/seller/SellerOrdersPage';
import SellerKYCPage from './components/pages/seller/SellerKYCPage';
import SellerSettlementsPage from './components/pages/seller/SellerSettlementsPage';

// Admin Pages
import AdminDashboardPage from './components/pages/admin/AdminDashboardPage';
import PolicyPage from './components/pages/PolicyPage';
import StorefrontPage from './components/pages/StorefrontPage';
import AuthModal from './components/ui/AuthModal';

function MainApp() {
  const {
    cartDrawerOpen,
    setCartDrawerOpen,
    toastMessage,
    products,
    orders,
    authModalOpen,
    setAuthModalOpen,
    refreshAuthSession,
    selectedStorefrontId,
    setSelectedStorefrontId,
  } = useStore();

  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);
  const [lastCompletedOrder, setLastCompletedOrder] = useState<Order | null>(null);
  const [activeTrackingNumber, setActiveTrackingNumber] = useState<string>('GIG-LAG-782194');
  const [returnOrder, setReturnOrder] = useState<Order | null>(null);

  // Modals
  const [qaModalOpen, setQaModalOpen] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newsletterModalOpen, setNewsletterModalOpen] = useState(false);

  // Deep linking: read initial URL parameters on mount
  useEffect(() => {
    try {
      const searchParams = new URLSearchParams(window.location.search);
      const tabParam = searchParams.get('tab');
      const catParam = searchParams.get('category');
      const idParam = searchParams.get('id') || searchParams.get('productId');

      if (tabParam) {
        setCurrentTab(tabParam);
      }
      if (catParam) {
        setSelectedCategory(catParam);
      }
      if (idParam && products.length > 0) {
        const found = products.find((p) => p.id === idParam || p.slug === idParam);
        if (found) {
          setSelectedProduct(found);
          if (!tabParam) setCurrentTab('product-detail');
        }
      }
    } catch {
      // In-sandbox iframe fallback
    }
  }, [products]);

  // Synchronize browser URL bar and history state for shareability and clean indexing
  useEffect(() => {
    try {
      const params = new URLSearchParams();
      if (currentTab !== 'home') {
        params.set('tab', currentTab);
      }
      if (currentTab === 'shop' && selectedCategory !== 'all') {
        params.set('category', selectedCategory);
      }
      if (currentTab === 'product-detail' && selectedProduct) {
        params.set('id', selectedProduct.slug || selectedProduct.id);
      }

      const queryString = params.toString();
      const newUrl = queryString ? `?${queryString}` : window.location.pathname;
      window.history.replaceState({ tab: currentTab, category: selectedCategory }, '', newUrl);
    } catch {
      // ignore in environments without history support
    }
  }, [currentTab, selectedCategory, selectedProduct]);

  const handleSelectProduct = (product: ProductItem) => {
    setSelectedProduct(product);
    setCurrentTab('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCategory = (category: string) => {
    setSelectedCategory(category);
    setCurrentTab('shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenStorefront = (sellerId: string) => {
    setSelectedStorefrontId(sellerId);
    setCurrentTab('storefront');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleProceedToCheckout = () => {
    setCurrentTab('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOrderSuccess = (order: Order) => {
    setLastCompletedOrder(order);
    setCurrentTab('checkout-complete');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTrackShipment = (trackingNumber: string) => {
    setActiveTrackingNumber(trackingNumber);
    setCurrentTab('shipments');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenReturns = (order: Order) => {
    setReturnOrder(order);
    setCurrentTab('returns');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans ${currentTab === 'for-you' ? 'h-[100dvh] md:h-[100vh] overflow-hidden bg-black p-0 m-0' : 'bg-white text-slate-900'}`}>
      {/* Dynamic SEO Meta Tags, OpenGraph, Twitter Cards & JSON-LD Structured Data */}
      <SEOHead
        currentTab={currentTab}
        selectedProduct={selectedProduct}
        selectedCategory={selectedCategory}
        products={products}
      />

      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        selectedCategory={selectedCategory}
        onSelectCategory={handleSelectCategory}
        onOpenQA={() => setQaModalOpen(true)}
        onOpenExport={() => setExportModalOpen(true)}
      />

      {/* Main Viewport Container */}
      <main className={currentTab === 'for-you' ? 'w-full h-[100dvh] md:h-[100vh] p-0 m-0 overflow-hidden bg-black flex-1' : 'flex-1 mx-auto max-w-7xl w-full px-4 pt-6 md:px-8'}>
        {currentTab === 'for-you' && (
          <ForYouVideoFeedPage
            onSelectProduct={handleSelectProduct}
            onProceedToCheckout={handleProceedToCheckout}
            onBack={() => setCurrentTab('shop')}
          />
        )}

        {currentTab === 'home' && (
          <HomePage
            setCurrentTab={setCurrentTab}
            onSelectProduct={handleSelectProduct}
            onSelectCategory={handleSelectCategory}
            onOpenStorefront={handleOpenStorefront}
          />
        )}

        {currentTab === 'shop' && (
          <ShopPage
            onSelectProduct={handleSelectProduct}
            onQuickBuy={handleProceedToCheckout}
            selectedCategory={selectedCategory}
            onSelectCategory={(cat) => setSelectedCategory(cat)}
          />
        )}

        {currentTab === 'product-detail' && (
          <ProductDetailsPage
            product={selectedProduct || products[0]}
            onBack={() => setCurrentTab('shop')}
            onSelectProduct={handleSelectProduct}
            onProceedToCheckout={handleProceedToCheckout}
          />
        )}

        {currentTab === 'checkout' && (
          <CheckoutPage
            onSuccessOrder={handleOrderSuccess}
            onBackToCart={() => setCartDrawerOpen(true)}
          />
        )}

        {currentTab === 'checkout-complete' && (
          <CheckoutCompletePage
            order={lastCompletedOrder || orders[0]}
            onGoToOrders={() => setCurrentTab('orders')}
            onContinueShopping={() => setCurrentTab('shop')}
            onTrackOrder={handleTrackShipment}
          />
        )}

        {currentTab === 'orders' && (
          <OrdersPage
            onTrackOrder={handleTrackShipment}
            onOpenReturns={handleOpenReturns}
          />
        )}

        {currentTab === 'profile' && <ProfilePage onNavigate={setCurrentTab} />}

        {currentTab === 'live' && (
          <LiveShoppingPage
            onSelectProduct={handleSelectProduct}
            onProceedToCheckout={handleProceedToCheckout}
          />
        )}

        {currentTab === 'auctions' && (
          <AuctionsPage
            onCheckoutAuctionOrder={() => setCurrentTab('orders')}
            onOpenStorefront={handleOpenStorefront}
          />
        )}

        {currentTab === 'coins' && <CoinsPage />}

        {currentTab === 'flash-deals' && (
          <FlashDealsPage
            onSelectProduct={handleSelectProduct}
            onProceedToCheckout={handleProceedToCheckout}
          />
        )}

        {currentTab === 'wishlist' && (
          <WishlistPage
            onSelectProduct={handleSelectProduct}
            onExplore={() => setCurrentTab('shop')}
          />
        )}

        {currentTab === 'shipments' && (
          <ShipmentsPage initialTracking={activeTrackingNumber} />
        )}

        {currentTab === 'messages' && (
          <MessagesPage
            onSelectProduct={handleSelectProduct}
            onNavigateOrder={handleTrackShipment}
          />
        )}

        {currentTab === 'notifications' && <NotificationsPage />}

        {currentTab === 'returns' && (
          <ReturnsPage
            initialOrder={returnOrder}
            onBack={() => setCurrentTab('orders')}
          />
        )}

        {/* Seller Centre Views */}
        {currentTab === 'seller-dashboard' && (
          <SellerDashboardPage onNavigate={setCurrentTab} />
        )}

        {currentTab === 'seller-products' && <SellerProductsPage />}

        {currentTab === 'seller-orders' && <SellerOrdersPage />}

        {currentTab === 'seller-kyc' && <SellerKYCPage />}

        {currentTab === 'seller-settlements' && <SellerSettlementsPage />}

        {/* Admin Console Views */}
        {currentTab === 'admin-dashboard' && <AdminDashboardPage onNavigate={setCurrentTab} />}

        {/* Email Marketing & Newsletter Studio */}
        {currentTab === 'email-marketing' && (
          <EmailMarketingPage
            onSelectProduct={handleSelectProduct}
            onOpenNewsletterModal={() => setNewsletterModalOpen(true)}
          />
        )}

        {currentTab === 'storefront' && (
          <StorefrontPage
            sellerId={selectedStorefrontId || 'obimart'}
            onBack={() => setCurrentTab('shop')}
            onSelectProduct={handleSelectProduct}
            onOpenLive={() => setCurrentTab('live')}
            onOpenVideo={() => setCurrentTab('for-you')}
          />
        )}

        {/* Legal & Consumer Policies */}
        {currentTab === 'policies' && (
          <PolicyPage onBack={() => setCurrentTab('home')} />
        )}
      </main>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        onProceedToCheckout={handleProceedToCheckout}
      />

      {/* QA Diagnostic Modal */}
      <QADiagnosticModal
        isOpen={qaModalOpen}
        onClose={() => setQaModalOpen(false)}
      />

      {/* Source Code Export Modal */}
      <ZipExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
      />

      {/* Shopper Newsletter & ₦2,500 Voucher Modal */}
      <NewsletterModal
        isOpen={newsletterModalOpen}
        onClose={() => setNewsletterModalOpen(false)}
        onOpenEmailPreview={() => {
          setCurrentTab('email-marketing');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Mobile Sticky Navigation */}
      <MobileNav
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenCreate={() => setIsCreateModalOpen(true)}
      />

      {/* Creation Modal for (+) Button */}
      <CreateModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onNavigate={setCurrentTab}
      />

      {/* Real Cloudflare Auth Modal (Sign In / Register / Verify / Reset) */}
      <AuthModal
        open={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onAuthenticated={() => {
          refreshAuthSession().catch(() => {});
        }}
      />

      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 z-50 -translate-x-1/2 rounded-full bg-slate-900/95 px-6 py-3 text-xs font-bold text-white shadow-2xl backdrop-blur-md animate-in fade-in duration-200 md:bottom-6 border border-white/10 flex items-center gap-2">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Footer (hidden on immersive vertical video feed) */}
      {currentTab !== 'for-you' && (
        <Footer
          setCurrentTab={setCurrentTab}
          onOpenQA={() => setQaModalOpen(true)}
          onOpenExport={() => setExportModalOpen(true)}
        />
      )}
    </div>
  );
}

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error?.message || 'Unexpected rendering error' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
          <div className="max-w-md w-full rounded-3xl border border-slate-200 bg-white p-6 shadow-lg space-y-3 text-center">
            <h1 className="text-lg font-black text-slate-900">Unable to display view</h1>
            <p className="text-xs text-slate-600">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="rounded-xl bg-[#0c5c36] px-5 py-2.5 text-xs font-bold text-white hover:bg-emerald-900 transition"
            >
              Reload preview
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <AppErrorBoundary>
      <StoreProvider>
        <MainApp />
      </StoreProvider>
    </AppErrorBoundary>
  );
}
