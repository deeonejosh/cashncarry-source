import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserAccount,
  ProductItem,
  CartItem,
  Address,
  Order,
  AuctionItem,
  LiveRoom,
  KYCSubmission,
  CoinActivity,
  Message,
  NotificationItem,
  CarrierTracking,
  Role,
  ShortVideo,
  ShortVideoComment,
  NewsletterSubscriber,
  EmailCampaign,
  EmailTemplateId,
} from '../types';
import { products as initialProductsData, sellers as initialSellersData } from '../lib/data';
import { INITIAL_SUBSCRIBERS, INITIAL_CAMPAIGNS, EmailRenderOptions } from '../lib/emailTemplates';
import { api, DEFAULT_STAGING_CONFIG, type StagingConfig } from '../lib/api';

interface StoreContextType {
  stagingConfig: StagingConfig;
  selectedState: string;
  setSelectedState: (state: string) => void;
  isAuthenticatedSession: boolean;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  selectedStorefrontId: string | null;
  setSelectedStorefrontId: (sellerId: string | null) => void;
  refreshAuthSession: () => Promise<void>;
  updateUserProfile: (input: { displayName: string; bio: string; avatarUrl: string; selectedState: string }) => Promise<boolean>;
  signOutAccount: () => Promise<void>;
  currentUser: UserAccount;
  setCurrentUser: (user: UserAccount) => void;
  switchRole: (role: Role) => void;
  products: ProductItem[];
  setProducts: React.Dispatch<React.SetStateAction<ProductItem[]>>;
  cart: CartItem[];
  addToCart: (product: ProductItem, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  addresses: Address[];
  addAddress: (address: Omit<Address, 'id'>) => Address;
  deleteAddress: (id: string) => void;
  orders: Order[];
  createOrderFromCart: (addressId: string) => Order | null;
  cancelOrder: (orderId: string) => boolean;
  payOrderWithFlutterwave: (orderId: string, testCardNumber: string) => Promise<{ success: boolean; txRef: string; message?: string }>;
  auctions: AuctionItem[];
  placeBid: (auctionId: string, amount: number) => { success: boolean; message?: string };
  closeAuction: (auctionId: string) => void;
  checkoutWinningAuction: (auctionId: string, addressId: string) => Order | null;
  createSellerAuction: (productId: string, startingBid: number, durationMinutes: number) => boolean;
  liveRooms: LiveRoom[];
  activeLiveRoom: LiveRoom | null;
  setActiveLiveRoom: (room: LiveRoom | null) => void;
  coinBalance: number;
  coinLedger: CoinActivity[];
  claimTestCoins: (amount?: number) => void;
  sendLiveGift: (recipientId: string, giftType: 'rose' | 'star' | 'lion') => { success: boolean; message?: string };
  kycSubmissions: KYCSubmission[];
  submitKYC: (cacNumber: string, businessName: string, fileName: string) => Promise<KYCSubmission>;
  adminApproveKYC: (submissionId: string) => void;
  adminRejectKYC: (submissionId: string) => void;
  adminApproveProduct: (productId: string) => void;
  adminRejectProduct: (productId: string) => void;
  adminRefundOrder: (orderId: string) => boolean;
  sellerAddProduct: (product: Omit<ProductItem, 'id' | 'slug' | 'sellerId' | 'sellerName' | 'rating' | 'reviews' | 'createdAt' | 'archived'>) => ProductItem;
  sellerUpdateProduct: (productId: string, updates: Partial<ProductItem>) => void;
  sellerFulfillOrder: (orderId: string, trackingNumber: string, carrier: string) => void;
  messages: Message[];
  sendMessage: (receiverId: string, content: string, options?: { orderId?: string; attachedProduct?: ProductItem; imageUrl?: string }) => void;
  notifications: NotificationItem[];
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  carrierTrackings: Record<string, CarrierTracking>;
  shortVideos: ShortVideo[];
  likeVideo: (videoId: string) => void;
  saveVideo: (videoId: string) => void;
  followSeller: (sellerId: string) => void;
  unfollowSeller: (sellerId: string) => void;
  followingSellers: string[];
  savedVideos: string[];
  addVideoComment: (videoId: string, content: string) => void;
  uploadShortVideo: (video: Omit<ShortVideo, 'id' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount' | 'createdAt'>) => ShortVideo;
  reportVideo: (videoId: string, reason: string) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  cartDrawerOpen: boolean;
  setCartDrawerOpen: (open: boolean) => void;
  newsletterSubscribers: NewsletterSubscriber[];
  emailCampaigns: EmailCampaign[];
  subscribeToNewsletter: (
    email: string,
    options?: {
      name?: string;
      preferences?: string[];
      source?: 'footer' | 'checkout' | 'modal' | 'profile' | 'admin';
    }
  ) => { success: boolean; message: string; subscriber?: NewsletterSubscriber; voucherCode?: string };
  unsubscribeFromNewsletter: (email: string) => boolean;
  updateSubscriberPreferences: (email: string, preferences: string[]) => void;
  createEmailCampaign: (
    campaign: Omit<EmailCampaign, 'id' | 'recipientsCount' | 'openedCount' | 'clickedCount' | 'bouncedCount'>
  ) => EmailCampaign;
  sendEmailCampaign: (campaignId: string) => Promise<{ success: boolean; deliveredCount: number; message: string }>;
  sendTestEmail: (
    templateId: EmailTemplateId,
    targetEmail: string,
    customOptions?: EmailRenderOptions
  ) => Promise<{ success: boolean; message: string }>;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const SEED_USERS: Record<Role, UserAccount> = {
  buyer: {
    id: 'user_buyer_1',
    name: 'Chidi Okafor',
    email: 'chidi.okafor@gmail.com',
    role: 'buyer',
    verified: true,
    suspended: false,
    coins: 750,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
  },
  seller: {
    id: 'olaoluwa',
    name: 'Olaoluwa Trends',
    email: 'seller@trends.ng',
    role: 'seller',
    verified: true,
    suspended: false,
    storeName: 'Olaoluwa Trends',
    coins: 1200,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
  },
  admin: {
    id: 'admin_temi',
    name: 'Temidayo Admin',
    email: 'admin@cashncarryng.com',
    role: 'admin',
    verified: true,
    suspended: false,
    coins: 50000,
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80',
  },
};

const SEED_ADDRESSES: Address[] = [
  {
    id: 'addr_1',
    recipient: 'Chidi Okafor',
    phone: '+234 803 123 4567',
    line: '14 Adeola Odeku Street, Victoria Island',
    city: 'Lagos',
    state: 'Lagos State',
    isDefault: true,
  },
  {
    id: 'addr_2',
    recipient: 'Chidi Okafor (Office)',
    phone: '+234 802 987 6543',
    line: 'Plot 402 Aminu Kano Crescent, Wuse 2',
    city: 'Abuja',
    state: 'FCT Abuja',
    isDefault: false,
  },
];

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [stagingConfig, setStagingConfig] = useState<StagingConfig>(DEFAULT_STAGING_CONFIG);
  const [selectedState, setSelectedState] = useState<string>('Lagos');
  const [isAuthenticatedSession, setIsAuthenticatedSession] = useState<boolean>(false);
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [selectedStorefrontId, setSelectedStorefrontId] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<UserAccount>({
    ...SEED_USERS.buyer,
    bio: 'Verified Cash N Carry shopper discovering Nigerian live deals.',
    selectedState: 'Lagos',
    authenticated: false,
  });
  const [wishlist, setWishlist] = useState<string[]>(['p1', 'p5']);
  const [addresses, setAddresses] = useState<Address[]>(SEED_ADDRESSES);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Newsletter Subscribers & Email Marketing State (with localStorage persistence)
  const [newsletterSubscribers, setNewsletterSubscribers] = useState<NewsletterSubscriber[]>(() => {
    try {
      const saved = localStorage.getItem('cnc_newsletter_subscribers');
      return saved ? JSON.parse(saved) : INITIAL_SUBSCRIBERS;
    } catch {
      return INITIAL_SUBSCRIBERS;
    }
  });

  const [emailCampaigns, setEmailCampaigns] = useState<EmailCampaign[]>(() => {
    try {
      const saved = localStorage.getItem('cnc_email_campaigns');
      return saved ? JSON.parse(saved) : INITIAL_CAMPAIGNS;
    } catch {
      return INITIAL_CAMPAIGNS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('cnc_newsletter_subscribers', JSON.stringify(newsletterSubscribers));
    } catch {}
  }, [newsletterSubscribers]);

  useEffect(() => {
    try {
      localStorage.setItem('cnc_email_campaigns', JSON.stringify(emailCampaigns));
    } catch {}
  }, [emailCampaigns]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const switchRole = (role: Role) => {
    setCurrentUser({
      ...SEED_USERS[role],
      selectedState,
      authenticated: isAuthenticatedSession,
    });
    showToast(`Switched active staging session to: ${SEED_USERS[role].name} (${role.toUpperCase()})`);
  };

  const hydrateAuthenticatedUser = async () => {
    const [profile, d1Addresses, d1Wishlist, d1Follows, d1Coins] = await Promise.all([
      api.getProfile(),
      api.getAddresses(),
      api.getWishlist(),
      api.getFollows(),
      api.getCoins(),
    ]);
    if (profile) {
      setSelectedState(profile.selected_state || 'Lagos');
      setCurrentUser((prev) => ({
        ...prev,
        id: profile.user_id,
        name: profile.display_name || profile.email.split('@')[0],
        email: profile.email,
        role: profile.role,
        avatar: profile.avatar_url || prev.avatar,
        bio: profile.bio || prev.bio,
        selectedState: profile.selected_state || 'Lagos',
        verified: true,
        authenticated: true,
      }));
    }
    if (d1Addresses.length > 0) {
      setAddresses(
        d1Addresses.map((a, idx) => ({
          id: a.id,
          recipient: a.recipient,
          phone: '+234 800 000 0000',
          line: a.line,
          city: a.city,
          state: a.state,
          isDefault: idx === 0,
        }))
      );
    }
    if (d1Wishlist.length > 0) {
      setWishlist(d1Wishlist);
    }
    if (d1Follows.length > 0) {
      setFollowingSellers(d1Follows);
    }
    if (d1Coins.ok && typeof d1Coins.data?.balance === 'number') {
      setCoinBalance(d1Coins.data.balance);
    }
  };

  const refreshAuthSession = async () => {
    const health = await api.checkHealth();
    if (health.staging) {
      setStagingConfig(health.staging);
    }
    if (health.user && health.authenticated) {
      setIsAuthenticatedSession(true);
      setCurrentUser((prev) => ({
        ...prev,
        id: health.user!.id,
        email: health.user!.email,
        role: health.user!.role,
        verified: true,
        authenticated: true,
      }));
      await hydrateAuthenticatedUser();
    } else {
      setIsAuthenticatedSession(false);
    }
  };

  const updateUserProfile = async (input: {
    displayName: string;
    bio: string;
    avatarUrl: string;
    selectedState: string;
  }): Promise<boolean> => {
    setSelectedState(input.selectedState);
    setCurrentUser((prev) => ({
      ...prev,
      name: input.displayName.trim() || prev.name,
      bio: input.bio,
      avatar: input.avatarUrl || prev.avatar,
      selectedState: input.selectedState,
    }));
    if (isAuthenticatedSession) {
      const res = await api.updateProfile(input);
      if (!res.updated) {
        showToast(res.error || 'Saved locally (sign in session expired)');
        return false;
      }
    }
    showToast('Profile synced cleanly!');
    return true;
  };

  const signOutAccount = async () => {
    await api.logout();
    setIsAuthenticatedSession(false);
    setCurrentUser({
      ...SEED_USERS.buyer,
      selectedState,
      authenticated: false,
    });
    showToast('Signed out of Cash N Carry session');
  };

  // Convert initial products to full ProductItem format
  const [products, setProducts] = useState<ProductItem[]>(() => {
    return initialProductsData.map((p, idx) => ({
      ...p,
      stock: idx === 0 ? 12 : idx === 1 ? 5 : idx === 2 ? 8 : 20,
      sellerId: idx % 2 === 0 ? 'olaoluwa' : 'ziva',
      sellerName: idx % 2 === 0 ? 'Olaoluwa Trends' : 'Ziva Glow Essentials',
      publication: 'published',
      archived: false,
      createdAt: new Date(Date.now() - (idx + 1) * 86400000).toISOString(),
    }));
  });

  // Sync server-controlled staging flags, Worker session, and D1 state when online
  useEffect(() => {
    let active = true;
    api.checkHealth().then((health) => {
      if (!active) return;
      if (health.staging) {
        setStagingConfig(health.staging);
      }
      if (health.user && health.authenticated) {
        setIsAuthenticatedSession(true);
        setCurrentUser((prev) => ({
          ...prev,
          id: health.user!.id,
          email: health.user!.email,
          role: health.user!.role,
          verified: true,
          authenticated: true,
        }));
        hydrateAuthenticatedUser().catch(() => {});
      }
    });
    api.getProducts().then((d1Products) => {
      if (active && d1Products && d1Products.length > 0) {
        setProducts(
          d1Products.map((p, idx) => ({
            id: p.id,
            slug: p.id,
            title: p.name,
            brand: p.store === 'obimart' ? 'ObiMart' : p.store === 'techmarket' ? 'Naija Tech' : 'Verified Merchant',
            price: p.price,
            compareAt: Math.round(p.price * 1.2),
            stock: p.stock,
            category: p.category,
            featured: Boolean(p.featured),
            description: p.description,
            image: p.image,
            sellerId: p.store,
            sellerName: p.store === 'obimart' ? 'ObiMart Stores' : p.store === 'techmarket' ? 'Naija Tech Market' : 'Verified Store',
            rating: 4.8,
            reviews: 140 + idx * 12,
            publication: 'published',
            archived: false,
            createdAt: new Date().toISOString(),
          }))
        );
      }
    });
    return () => {
      active = false;
    };
  }, []);

  const [cart, setCart] = useState<CartItem[]>([
    {
      productId: 'p1',
      title: 'Gaming Headset with Microphone',
      price: 18500,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
      quantity: 1,
      sellerId: 'olaoluwa',
      sellerName: 'Olaoluwa Trends',
      stock: 12,
      source: 'replacement',
    },
  ]);

  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'CNC-2026-9042',
      buyerId: 'user_buyer_1',
      buyerName: 'Chidi Okafor',
      buyerEmail: 'chidi.okafor@gmail.com',
      requestId: 'req_init_9042',
      address: SEED_ADDRESSES[0],
      items: [
        {
          productId: 'p5',
          name: 'Elegant Ankara Print Dress',
          sellerId: 'olaoluwa',
          sellerName: 'Olaoluwa Trends',
          quantity: 1,
          price: 16250,
          image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80',
        },
      ],
      subtotal: 16250,
      shipping: 1500,
      total: 17750,
      status: 'shipped',
      createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
      reservationEndsAt: new Date(Date.now() - 3600000 * 47).toISOString(),
      flutterwaveRef: 'cnc-test-flw-9042-ref',
      flutterwaveTransactionId: 'FLW-TX-9042817',
      trackingNumber: 'GIG-LAG-782194',
      carrier: 'GIG Logistics',
    },
  ]);

  const [auctions, setAuctions] = useState<AuctionItem[]>([
    {
      id: 'auc-101',
      sellerId: 'olaoluwa',
      storefrontName: 'Olaoluwa Trends',
      productId: 'p5',
      title: 'Handcrafted Limited Edition Ankara Evening Dress',
      image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80',
      startingBid: 12000,
      currentBid: 18500,
      winnerId: 'user_buyer_1',
      winnerName: 'Chidi Okafor',
      endsAt: new Date(Date.now() + 3600000 * 18).toISOString(),
      closedAt: null,
      orderId: null,
      bidsCount: 7,
    },
    {
      id: 'auc-102',
      sellerId: 'ziva',
      storefrontName: 'Ziva Glow Essentials',
      productId: 'p6',
      title: 'Luxury 24K Gold Radiant Skincare Vault',
      image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800&auto=format&fit=crop&q=80',
      startingBid: 8000,
      currentBid: 11500,
      winnerId: null,
      winnerName: null,
      endsAt: new Date(Date.now() + 3600000 * 6).toISOString(),
      closedAt: null,
      orderId: null,
      bidsCount: 4,
    },
  ]);

  const [liveRooms, setLiveRooms] = useState<LiveRoom[]>([
    {
      id: 'live-room-1',
      sellerId: 'olaoluwa',
      sellerName: 'Olaoluwa Trends',
      title: 'Mega Ankara & Accessories Flash Unboxing & Live Drop',
      status: 'live',
      viewerCount: 1420,
      heartsCount: 8940,
      pinnedProduct: {
        id: 'p5',
        slug: 'elegant-ankara-print-dress',
        title: 'Elegant Ankara Print Dress',
        brand: 'Olaoluwa Trends',
        price: 16250,
        compareAt: 22000,
        stock: 8,
        rating: 4.8,
        reviews: 176,
        image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80',
        category: 'fashion',
        badge: 'LIVE DEAL',
        description: 'Bold Nigerian-inspired design with premium fabric and a flattering fit.',
        sellerId: 'olaoluwa',
        sellerName: 'Olaoluwa Trends',
        publication: 'published',
        archived: false,
        createdAt: new Date().toISOString(),
      },
      whipUrl: 'https://customer-stream.cloudflarestream.com/live-whip-cnc-staging/publish',
      whepUrl: 'https://customer-stream.cloudflarestream.com/live-whip-cnc-staging/play',
    },
  ]);

  const [activeLiveRoom, setActiveLiveRoom] = useState<LiveRoom | null>(liveRooms[0]);

  const [coinBalance, setCoinBalance] = useState<number>(750);
  const [coinLedger, setCoinLedger] = useState<CoinActivity[]>([
    { id: 'c-1', delta: 500, reason: 'Staging promotional welcome bonus', createdAt: new Date(Date.now() - 86400000).toISOString() },
    { id: 'c-2', delta: 250, reason: 'Live shopping engagement reward', createdAt: new Date(Date.now() - 3600000 * 5).toISOString() },
  ]);

  const [kycSubmissions, setKycSubmissions] = useState<KYCSubmission[]>([
    {
      id: 'kyc-sub-001',
      sellerId: 'olaoluwa',
      sellerName: 'Olaoluwa Trends',
      businessName: 'Olaoluwa Fashion Enterprises Ltd',
      cacNumber: 'RC-1849203',
      documentName: 'CAC_Certificate_Olaoluwa_Trends.pdf',
      documentSize: '1.8 MB',
      scannerStatus: 'clean',
      encryptionStatus: 'AES-256-GCM-Sealed',
      status: 'verified',
      submittedAt: new Date(Date.now() - 86400000 * 5).toISOString(),
      notes: 'Approved after ClamAV clean scan and CAC register verification.',
    },
    {
      id: 'kyc-sub-002',
      sellerId: 'ziva',
      sellerName: 'Ziva Glow Essentials',
      businessName: 'Ziva Organics & Beauty Limited',
      cacNumber: 'RC-2039145',
      documentName: 'Ziva_Beauty_CAC_BN.pdf',
      documentSize: '2.4 MB',
      scannerStatus: 'clean',
      encryptionStatus: 'AES-256-GCM-Sealed',
      status: 'pending',
      submittedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    },
  ]);

  const [shortVideos, setShortVideos] = useState<ShortVideo[]>([
    {
      id: 'vid-1',
      sellerId: 'olaoluwa',
      sellerName: 'Olaoluwa Trends',
      sellerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
      sellerVerified: true,
      isLiveNow: true,
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-fashion-model-showing-off-her-clothing-41553-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80',
      caption: 'Handcrafted luxury Ankara print dress! Perfect fit for Lagos Owambe parties and corporate Fridays ✨🇳🇬 #LagosFashion #AnkaraStyle #CashNCarry',
      taggedProduct: {
        id: 'p5',
        slug: 'elegant-ankara-print-dress',
        title: 'Elegant Ankara Print Dress',
        brand: 'Olaoluwa Trends',
        price: 16250,
        compareAt: 22000,
        stock: 14,
        category: 'fashion',
        badge: 'Trending',
        featured: true,
        description: 'Bold Nigerian-inspired design with premium fabric and a flattering fit.',
        image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80',
        sellerId: 'olaoluwa',
        sellerName: 'Olaoluwa Trends',
        rating: 4.8,
        reviews: 176,
        publication: 'published',
        archived: false,
        createdAt: '2026-03-01T10:00:00.000Z',
      },
      likesCount: 1420,
      commentsCount: 86,
      sharesCount: 312,
      savesCount: 420,
      liked: false,
      saved: false,
      following: false,
      soundTitle: 'Original Audio – Asake Live in Lagos Remix',
      createdAt: '2026-11-10T12:00:00.000Z',
      comments: [
        {
          id: 'c-1',
          userId: 'u-1',
          userName: 'Amina Bello',
          userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
          content: 'Is size 14 available for fast dispatch to Abuja?',
          createdAt: '10m ago',
          likesCount: 14,
        },
        {
          id: 'c-2',
          userId: 'olaoluwa',
          userName: 'Olaoluwa Trends',
          userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80',
          content: 'Yes Amina! Same-day dispatch to Abuja via GIG Logistics.',
          createdAt: '5m ago',
          likesCount: 6,
        },
      ],
    },
    {
      id: 'vid-2',
      sellerId: 'wearables',
      sellerName: 'Wearables NG',
      sellerAvatar: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?w=200&auto=format&fit=crop&q=80',
      sellerVerified: true,
      isLiveNow: false,
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-man-dancing-while-listening-to-music-with-headphones-42171-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
      caption: 'Deep bass test on the Studio Wireless Headset! Active noise cancelling for noisy Lagos traffic 🎧🔥 20% discount today only!',
      taggedProduct: {
        id: 'p1',
        slug: 'studio-wireless-headphones',
        title: 'Gaming Headset with Microphone',
        brand: 'Audio Technica',
        price: 18500,
        compareAt: 23000,
        stock: 8,
        category: 'tech',
        badge: '20% OFF',
        featured: true,
        description: 'Immersive sound, deep bass and clear team communication for games and work.',
        image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
        sellerId: 'wearables',
        sellerName: 'Wearables NG',
        rating: 4.8,
        reviews: 124,
        publication: 'published',
        archived: false,
        createdAt: '2026-03-01T10:00:00.000Z',
      },
      likesCount: 2840,
      commentsCount: 145,
      sharesCount: 620,
      savesCount: 890,
      liked: true,
      saved: true,
      following: true,
      soundTitle: 'Afrobeats Bass Drop – Burna Boy Vibes',
      createdAt: '2026-11-09T15:30:00.000Z',
      comments: [
        {
          id: 'c-3',
          userId: 'u-3',
          userName: 'Emeka Eze',
          content: 'Battery life is insane! Lasted me 3 days on one charge.',
          createdAt: '1h ago',
          likesCount: 38,
        },
      ],
    },
    {
      id: 'vid-3',
      sellerId: 'ziva',
      sellerName: 'Ziva Glow Essentials',
      sellerAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
      sellerVerified: true,
      isLiveNow: true,
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-facial-cream-42523-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800&auto=format&fit=crop&q=80',
      caption: 'My morning Nigerian glow routine using pure botanical extracts! No harsh chemicals, genuine NAFDAC approved ingredients 🌸✨',
      taggedProduct: {
        id: 'p6',
        slug: 'gold-collection-essentials',
        title: 'Glow Gold Skincare Set',
        brand: 'Ziva Glow Essentials',
        price: 9800,
        compareAt: 12000,
        stock: 25,
        category: 'beauty',
        badge: 'Best seller',
        featured: true,
        description: 'A daily hydrating set with vitamin-based care and a radiant glow.',
        image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800&auto=format&fit=crop&q=80',
        sellerId: 'ziva',
        sellerName: 'Ziva Glow Essentials',
        rating: 4.9,
        reviews: 142,
        publication: 'published',
        archived: false,
        createdAt: '2026-03-01T10:00:00.000Z',
      },
      likesCount: 950,
      commentsCount: 54,
      sharesCount: 180,
      savesCount: 310,
      liked: false,
      saved: false,
      following: false,
      soundTitle: 'Acoustic Guitar – Peaceful Lagos Morning',
      createdAt: '2026-11-10T08:15:00.000Z',
      comments: [],
    },
    {
      id: 'vid-4',
      sellerId: 'techhub',
      sellerName: 'TechHub Store',
      sellerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
      sellerVerified: true,
      isLiveNow: false,
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-man-wearing-a-smartwatch-41552-large.mp4',
      posterUrl: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80',
      caption: 'Unboxing the Smart Fitness Watch! Heart rate, blood oxygen, and WhatsApp call notifications directly on your wrist ⌚🇳🇬',
      taggedProduct: {
        id: 'p4',
        slug: 'smart-fitness-watch',
        title: 'Smart Fitness Watch',
        brand: 'Wearables NG',
        price: 32500,
        compareAt: 36000,
        stock: 12,
        category: 'tech',
        badge: '10% OFF',
        featured: true,
        description: 'Track your steps, workouts and sleep with this sleek daily companion.',
        image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80',
        sellerId: 'wearables',
        sellerName: 'Wearables NG',
        rating: 4.6,
        reviews: 88,
        publication: 'published',
        archived: false,
        createdAt: '2026-03-01T10:00:00.000Z',
      },
      likesCount: 3410,
      commentsCount: 210,
      sharesCount: 520,
      savesCount: 940,
      liked: false,
      saved: false,
      following: false,
      soundTitle: 'Afro Electronic Beats 2026',
      createdAt: '2026-11-08T18:40:00.000Z',
      comments: [],
    },
  ]);

  const [followingSellers, setFollowingSellers] = useState<string[]>(['wearables', 'olaoluwa']);
  const [savedVideos, setSavedVideos] = useState<string[]>(['vid-2']);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm-1',
      senderId: 'olaoluwa',
      senderName: 'Olaoluwa Trends',
      receiverId: 'user_buyer_1',
      content: 'Hello Chidi! Your order CNC-2026-9042 has been dispatched via GIG Logistics. Expect delivery tomorrow.',
      timestamp: new Date(Date.now() - 3600000 * 20).toISOString(),
      read: true,
      status: 'read',
      orderId: 'CNC-2026-9042',
    },
    {
      id: 'm-2',
      senderId: 'user_buyer_1',
      senderName: 'Chidi Okafor',
      receiverId: 'olaoluwa',
      content: 'Thank you! Could you please confirm if the tracking number is GIG-LAG-782194?',
      timestamp: new Date(Date.now() - 3600000 * 18).toISOString(),
      read: true,
      status: 'read',
    },
    {
      id: 'm-3',
      senderId: 'olaoluwa',
      senderName: 'Olaoluwa Trends',
      receiverId: 'user_buyer_1',
      content: 'Yes exactly. The driver will call you on arrival in Ikeja.',
      timestamp: new Date(Date.now() - 3600000 * 17).toISOString(),
      read: true,
      status: 'delivered',
    },
    {
      id: 'm-4',
      senderId: 'ziva',
      senderName: 'Ziva Glow Essentials',
      receiverId: 'user_buyer_1',
      content: 'Hi Chidi, thanks for checking out our Glow Gold Skincare Set! We have 25 units in stock for nationwide dispatch.',
      timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
      read: false,
      status: 'delivered',
    },
    {
      id: 'm-5',
      senderId: 'support',
      senderName: 'Cash N Carry Help Desk',
      receiverId: 'user_buyer_1',
      content: 'Welcome to Cash N Carry Nigeria! All payments are held in Flutterwave escrow until you confirm delivery.',
      timestamp: new Date(Date.now() - 3600000 * 48).toISOString(),
      read: true,
      status: 'read',
    },
  ]);

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'n-1',
      title: 'Order Dispatched 🚚',
      message: 'Your order #CNC-2026-9042 is on its way with GIG Logistics.',
      type: 'order',
      timestamp: new Date(Date.now() - 3600000 * 20).toISOString(),
      read: false,
      link: '/orders',
    },
    {
      id: 'n-2',
      title: '🔴 Olaoluwa Trends is LIVE NOW',
      message: 'Exclusive 20% discount on Ankara wear during live unboxing.',
      type: 'live',
      timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
      read: false,
      link: '/live',
    },
  ]);

  const [carrierTrackings, setCarrierTrackings] = useState<Record<string, CarrierTracking>>({
    'GIG-LAG-782194': {
      trackingNumber: 'GIG-LAG-782194',
      carrier: 'GIG Logistics',
      orderId: 'CNC-2026-9042',
      currentStatus: 'In Transit',
      estimatedDelivery: 'Tomorrow, 2:00 PM',
      events: [
        { status: 'Order Placed', location: 'Lagos Island Hub', timestamp: 'Yesterday, 10:14 AM', note: 'Order reserved and paid via Flutterwave' },
        { status: 'Confirmed & Packed', location: 'Olaoluwa Trends Store, Ikeja', timestamp: 'Yesterday, 2:30 PM', note: 'Verified by merchant fulfillment team' },
        { status: 'Handed to Carrier', location: 'GIG Ikeja Express Centre', timestamp: 'Yesterday, 6:00 PM', note: 'Scanned into courier tracking manifest' },
        { status: 'In Transit', location: 'Central Dispatch Hub, Oshodi', timestamp: 'Today, 8:45 AM', note: 'Sorted for final mile delivery' },
      ],
    },
  });

  // Cart operations
  const addToCart = (product: ProductItem, quantity = 1) => {
    if (product.stock <= 0) {
      showToast(`Sorry, "${product.title}" is out of stock!`);
      return;
    }

    setCart((prev) => {
      const existing = prev.find((item) => item.productId === product.id);
      if (existing) {
        const newQty = Math.min(existing.quantity + quantity, product.stock);
        showToast(`Updated quantity in cart (${newQty})`);
        return prev.map((item) => (item.productId === product.id ? { ...item, quantity: newQty } : item));
      } else {
        showToast(`Added "${product.title}" to cart!`);
        return [
          ...prev,
          {
            productId: product.id,
            title: product.title,
            price: product.price,
            image: product.image,
            quantity: Math.min(quantity, product.stock),
            sellerId: product.sellerId,
            sellerName: product.sellerName,
            stock: product.stock,
            source: 'replacement',
          },
        ];
      }
    });
    if (isAuthenticatedSession) {
      api.updateCartItem(product.id, quantity, 'replacement').catch(() => {});
    }
    setCartDrawerOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.productId !== productId));
    showToast('Item removed from cart');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.productId === productId) {
          const clamped = Math.min(quantity, item.stock);
          return { ...item, quantity: clamped };
        }
        return item;
      })
    );
  };

  const clearCart = () => setCart([]);

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      if (prev.includes(productId)) {
        showToast('Removed from wishlist');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Saved to your wishlist ❤️');
        return [...prev, productId];
      }
    });
    if (isAuthenticatedSession) {
      api.toggleWishlist(productId).catch(() => {});
    }
  };

  const addAddress = (addressData: Omit<Address, 'id'>) => {
    const newAddr: Address = {
      ...addressData,
      id: 'addr_' + Date.now(),
      isDefault: addresses.length === 0,
    };
    setAddresses((prev) => [...prev, newAddr]);
    showToast('Delivery address saved');
    return newAddr;
  };

  const deleteAddress = (id: string) => {
    setAddresses((prev) => prev.filter((a) => a.id !== id));
    showToast('Address deleted');
  };

  // Order creation & Flutterwave checkout
  const createOrderFromCart = (addressId: string): Order | null => {
    if (cart.length === 0) {
      showToast('Cart is empty');
      return null;
    }

    const selectedAddress = addresses.find((a) => a.id === addressId) || addresses[0];
    if (!selectedAddress) {
      showToast('Please provide a delivery address');
      return null;
    }

    // Check stock availability
    for (const item of cart) {
      const prod = products.find((p) => p.id === item.productId);
      if (!prod || prod.stock < item.quantity) {
        showToast(`Stock unavailable for "${item.title}"`);
        return null;
      }
    }

    // Atomic stock decrement for reservation
    setProducts((prev) =>
      prev.map((prod) => {
        const inCart = cart.find((c) => c.productId === prod.id);
        if (inCart) {
          return { ...prod, stock: prod.stock - inCart.quantity };
        }
        return prod;
      })
    );

    const subtotal = cartSubtotal;
    const shipping = subtotal > 50000 ? 0 : 2500;
    const total = subtotal + shipping;
    const orderId = `CNC-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: Order = {
      id: orderId,
      buyerId: currentUser.id,
      buyerName: currentUser.name,
      buyerEmail: currentUser.email,
      requestId: 'req_' + Date.now(),
      address: selectedAddress,
      items: cart.map((item) => ({
        productId: item.productId,
        name: item.title,
        sellerId: item.sellerId,
        sellerName: item.sellerName,
        quantity: item.quantity,
        price: item.price,
        image: item.image,
      })),
      subtotal,
      shipping,
      total,
      status: 'awaiting_payment',
      createdAt: new Date().toISOString(),
      reservationEndsAt: new Date(Date.now() + 15 * 60000).toISOString(), // 15 mins reservation
    };

    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    setCartDrawerOpen(false);
    showToast(`Order created (#${orderId})! Inventory reserved for 15 minutes.`);
    return newOrder;
  };

  const cancelOrder = (orderId: string): boolean => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return false;

    if (order.status !== 'awaiting_payment' && order.status !== 'processing') {
      showToast('Only unpaid or pending orders can be cancelled');
      return false;
    }

    // Restore stock!
    setProducts((prev) =>
      prev.map((prod) => {
        const orderedItem = order.items.find((i) => i.productId === prod.id);
        if (orderedItem) {
          return { ...prod, stock: prod.stock + orderedItem.quantity };
        }
        return prod;
      })
    );

    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'cancelled' } : o))
    );

    showToast(`Order #${orderId} cancelled. Reserved stock restored to catalog.`);
    return true;
  };

  const payOrderWithFlutterwave = async (
    orderId: string,
    _testCardNumber: string
  ): Promise<{ success: boolean; txRef: string; message?: string }> => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return { success: false, txRef: '', message: 'Order not found' };

    if (!stagingConfig.paymentsEnabled) {
      const msg = 'Payments temporarily unavailable — Flutterwave checkout confirmation is disabled in staging.';
      showToast(msg);
      return { success: false, txRef: '', message: msg };
    }

    const init = await api.initializePayment(orderId);
    if (init.error || !init.checkout_url) {
      const msg = init.error || 'Payments temporarily unavailable';
      showToast(msg);
      return { success: false, txRef: '', message: msg };
    }

    return {
      success: false,
      txRef: '',
      message: 'Awaiting verified Flutterwave webhook settlement before order can be marked paid.',
    };
  };

  // Auctions - Concurrency-safe atomic bid placement with anti-sniping
  const placeBid = (auctionId: string, amount: number) => {
    const auction = auctions.find((a) => a.id === auctionId);
    if (!auction) return { success: false, message: 'Auction not found' };

    if (auction.closedAt || new Date(auction.endsAt).getTime() <= Date.now()) {
      return { success: false, message: 'Auction has already ended.' };
    }

    const minRequired = auction.currentBid ? auction.currentBid + 500 : auction.startingBid;
    if (amount < minRequired) {
      return { success: false, message: `Bid must be at least ₦${minRequired.toLocaleString('en-NG')}` };
    }

    let success = false;
    let concurrencyMessage = '';

    setAuctions((prev) =>
      prev.map((a) => {
        if (a.id === auctionId) {
          if (a.closedAt || new Date(a.endsAt).getTime() <= Date.now()) {
            concurrencyMessage = 'Auction closed while placing bid.';
            return a;
          }
          if (a.currentBid && a.currentBid >= amount) {
            concurrencyMessage = `Concurrency conflict: A higher bid of ₦${a.currentBid.toLocaleString('en-NG')} was just placed!`;
            return a;
          }
          success = true;
          return {
            ...a,
            currentBid: amount,
            winnerId: currentUser.id,
            winnerName: currentUser.name,
            bidsCount: a.bidsCount + 1,
          };
        }
        return a;
      })
    );

    if (!success) {
      return { success: false, message: concurrencyMessage || 'Bid could not be processed.' };
    }

    if (isAuthenticatedSession) {
      api.placeBid(auctionId, amount).catch(() => {});
    }
    showToast(`Bid of ₦${amount.toLocaleString('en-NG')} placed successfully! 🏷️`);
    return { success: true };
  };

  const closeAuction = (auctionId: string) => {
    setAuctions((prev) =>
      prev.map((a) => (a.id === auctionId ? { ...a, closedAt: new Date().toISOString() } : a))
    );
    showToast('Auction closed');
  };

  const checkoutWinningAuction = (auctionId: string, addressId: string): Order | null => {
    if (!stagingConfig.paymentsEnabled) {
      showToast('Payments temporarily unavailable — auction checkout settlement is disabled in staging.');
      return null;
    }

    const auction = auctions.find((a) => a.id === auctionId);
    if (!auction || auction.winnerId !== currentUser.id || !auction.currentBid) {
      showToast('You are not the winning bidder of this auction');
      return null;
    }

    const selectedAddress = addresses.find((a) => a.id === addressId) || addresses[0];
    const orderId = `CNC-AUC-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: Order = {
      id: orderId,
      buyerId: currentUser.id,
      buyerName: currentUser.name,
      buyerEmail: currentUser.email,
      requestId: 'req_auc_' + auctionId,
      address: selectedAddress,
      items: [
        {
          productId: auction.productId,
          name: auction.title,
          sellerId: auction.sellerId,
          sellerName: auction.storefrontName,
          quantity: 1,
          price: auction.currentBid,
          image: auction.image,
        },
      ],
      subtotal: auction.currentBid,
      shipping: 2000,
      total: auction.currentBid + 2000,
      status: 'awaiting_payment',
      createdAt: new Date().toISOString(),
      reservationEndsAt: new Date(Date.now() + 30 * 60000).toISOString(),
    };

    setOrders((prev) => [newOrder, ...prev]);
    setAuctions((prev) =>
      prev.map((a) => (a.id === auctionId ? { ...a, orderId } : a))
    );

    showToast(`Winning auction order #${orderId} created! Proceed to checkout.`);
    return newOrder;
  };

  const createSellerAuction = (productId: string, startingBid: number, durationMinutes: number) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod || prod.stock <= 0) {
      showToast('Product unavailable or out of stock');
      return false;
    }

    // Reserve 1 stock
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock: p.stock - 1 } : p))
    );

    const newAuction: AuctionItem = {
      id: 'auc-' + Date.now(),
      sellerId: currentUser.id,
      storefrontName: currentUser.storeName || currentUser.name,
      productId: prod.id,
      title: prod.title,
      image: prod.image,
      startingBid,
      currentBid: null,
      winnerId: null,
      winnerName: null,
      endsAt: new Date(Date.now() + durationMinutes * 60000).toISOString(),
      closedAt: null,
      orderId: null,
      bidsCount: 0,
    };

    setAuctions((prev) => [newAuction, ...prev]);
    showToast(`Live auction created for "${prod.title}"!`);
    return true;
  };

  // Coins & Gifting - Server-enforced staging restrictions & idempotent fixture gifting
  const [processedGiftKeys] = useState(() => new Set<string>());

  const claimTestCoins = (_amount = 500) => {
    if (!stagingConfig.paymentsEnabled || !stagingConfig.coinsPurchasesEnabled) {
      showToast('Coin purchases and simulated credits are disabled in staging (PAYMENTS_ENABLED=false).');
      return;
    }
  };

  const sendLiveGift = (_recipientId: string, giftType: 'rose' | 'star' | 'lion', customKey?: string) => {
    const idempotencyKey = customKey || `gift-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    if (processedGiftKeys.has(idempotencyKey)) {
      return { success: false, message: 'Duplicate transaction rejected (idempotency key enforced).' };
    }

    const costs = { rose: 10, star: 100, lion: 1000 };
    const cost = costs[giftType];

    if (coinBalance < cost) {
      return { success: false, message: `Need ${cost} coins. Your balance: ${coinBalance}` };
    }

    processedGiftKeys.add(idempotencyKey);
    setCoinBalance((prev) => Math.max(0, prev - cost));

    setCoinLedger((prev) => [
      {
        id: 'c-' + Date.now(),
        delta: -cost,
        reason: `Sent ${giftType.toUpperCase()} gift preview (${idempotencyKey.slice(0, 8)})`,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);

    showToast(`Sent ${giftType} gift (${cost} staging fixture coins)!`);
    return { success: true };
  };

  // KYC
  const submitKYC = async (_cacNumber: string, _businessName: string, _fileName: string): Promise<KYCSubmission> => {
    if (!stagingConfig.kycUploadsEnabled) {
      const msg = 'KYC document uploads are temporarily unavailable until private R2 storage is configured.';
      showToast(msg);
      throw new Error(msg);
    }
    throw new Error('KYC upload requires active server storage endpoint.');
  };

  const adminApproveKYC = (submissionId: string) => {
    setKycSubmissions((prev) =>
      prev.map((s) => (s.id === submissionId ? { ...s, status: 'verified', notes: 'Approved by Administrator' } : s))
    );
    showToast('Seller KYC verified successfully! Badge activated.');
  };

  const adminRejectKYC = (submissionId: string) => {
    setKycSubmissions((prev) =>
      prev.map((s) => (s.id === submissionId ? { ...s, status: 'rejected', notes: 'Document illegible or failed CAC verification' } : s))
    );
    showToast('Seller KYC rejected.');
  };

  // Admin Product Moderation
  const adminApproveProduct = (productId: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, publication: 'published' } : p))
    );
    showToast('Product approved and published to public marketplace!');
  };

  const adminRejectProduct = (productId: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, publication: 'draft' } : p))
    );
    showToast('Product returned to seller drafts.');
  };

  const adminRefundOrder = (orderId: string): boolean => {
    if (!stagingConfig.paymentsEnabled) {
      showToast('Financial refunds & reversals are disabled in staging (PAYMENTS_ENABLED=false).');
      return false;
    }
    const order = orders.find((o) => o.id === orderId);
    if (!order) return false;

    // Restore stock
    setProducts((prev) =>
      prev.map((p) => {
        const item = order.items.find((i) => i.productId === p.id);
        return item ? { ...p, stock: p.stock + item.quantity } : p;
      })
    );

    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'cancelled' } : o))
    );

    showToast(`Order #${orderId} refunded via Flutterwave Sandbox reversal. Stock restored.`);
    return true;
  };

  // Seller Operations
  const sellerAddProduct = (productData: Omit<ProductItem, 'id' | 'slug' | 'sellerId' | 'sellerName' | 'rating' | 'reviews' | 'createdAt' | 'archived'>): ProductItem => {
    const slug = productData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newProduct: ProductItem = {
      ...productData,
      id: 'p-' + Date.now(),
      slug,
      sellerId: currentUser.id,
      sellerName: currentUser.storeName || currentUser.name,
      rating: 5.0,
      reviews: 0,
      createdAt: new Date().toISOString(),
      archived: false,
    };

    setProducts((prev) => [newProduct, ...prev]);
    showToast(`Product "${newProduct.title}" created (${newProduct.publication})!`);
    return newProduct;
  };

  const sellerUpdateProduct = (productId: string, updates: Partial<ProductItem>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, ...updates } : p))
    );
    showToast('Product details updated.');
  };

  const sellerFulfillOrder = (orderId: string, trackingNumber: string, carrier: string) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'shipped', trackingNumber, carrier } : o))
    );
    if (isAuthenticatedSession) {
      api.fulfillOrder(orderId, 'shipped', carrier, trackingNumber).catch(() => {});
    }
    showToast(`Order #${orderId} marked as shipped with ${carrier}!`);
  };

  // Messages
  const sendMessage = (
    receiverId: string,
    content: string,
    options?: { orderId?: string; attachedProduct?: ProductItem; imageUrl?: string }
  ) => {
    const newMsg: Message = {
      id: 'm-' + Date.now(),
      senderId: currentUser.id,
      senderName: currentUser.name,
      receiverId,
      content,
      timestamp: new Date().toISOString(),
      read: false,
      status: 'sent',
      orderId: options?.orderId,
      attachedProduct: options?.attachedProduct,
      imageUrl: options?.imageUrl,
    };
    setMessages((prev) => [...prev, newMsg]);
    if (isAuthenticatedSession) {
      api.sendMessage({
        receiverId,
        body: content,
        orderId: options?.orderId,
        productId: options?.attachedProduct?.id,
      }).catch(() => {});
    }
    showToast('Message sent');
  };

  // Short Video Feed Operations
  const likeVideo = (videoId: string) => {
    setShortVideos((prev) =>
      prev.map((v) => {
        if (v.id === videoId) {
          const isLiked = !v.liked;
          return {
            ...v,
            liked: isLiked,
            likesCount: isLiked ? v.likesCount + 1 : Math.max(0, v.likesCount - 1),
          };
        }
        return v;
      })
    );
  };

  const saveVideo = (videoId: string) => {
    setSavedVideos((prev) => {
      const isSaved = prev.includes(videoId);
      const next = isSaved ? prev.filter((id) => id !== videoId) : [...prev, videoId];
      showToast(isSaved ? 'Video removed from saved collection' : 'Video saved to your profile collection! 📌');
      return next;
    });

    setShortVideos((prev) =>
      prev.map((v) => {
        if (v.id === videoId) {
          const isSaved = !v.saved;
          return {
            ...v,
            saved: isSaved,
            savesCount: isSaved ? v.savesCount + 1 : Math.max(0, v.savesCount - 1),
          };
        }
        return v;
      })
    );
  };

  const followSeller = (sellerId: string) => {
    setFollowingSellers((prev) => {
      if (!prev.includes(sellerId)) {
        if (isAuthenticatedSession) {
          api.toggleFollow(sellerId).catch(() => {});
        }
        showToast('Now following seller! You will see their latest drops in For You.');
        return [...prev, sellerId];
      }
      return prev;
    });

    setShortVideos((prev) =>
      prev.map((v) => (v.sellerId === sellerId ? { ...v, following: true } : v))
    );
  };

  const unfollowSeller = (sellerId: string) => {
    setFollowingSellers((prev) => prev.filter((id) => id !== sellerId));
    if (isAuthenticatedSession) {
      api.toggleFollow(sellerId).catch(() => {});
    }
    setShortVideos((prev) =>
      prev.map((v) => (v.sellerId === sellerId ? { ...v, following: false } : v))
    );
    showToast('Unfollowed seller.');
  };

  const addVideoComment = (videoId: string, content: string) => {
    const newComment: ShortVideoComment = {
      id: 'c-' + Date.now(),
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      content,
      createdAt: 'Just now',
      likesCount: 0,
    };

    setShortVideos((prev) =>
      prev.map((v) => {
        if (v.id === videoId) {
          return {
            ...v,
            commentsCount: v.commentsCount + 1,
            comments: [newComment, ...(v.comments || [])],
          };
        }
        return v;
      })
    );
    showToast('Comment posted! 💬');
  };

  const uploadShortVideo = (
    videoData: Omit<ShortVideo, 'id' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount' | 'createdAt'>
  ): ShortVideo => {
    const newVid: ShortVideo = {
      ...videoData,
      id: 'vid-' + Date.now(),
      likesCount: 1,
      commentsCount: 0,
      sharesCount: 0,
      savesCount: 0,
      liked: false,
      saved: false,
      following: true,
      createdAt: new Date().toISOString(),
      comments: [],
    };

    setShortVideos((prev) => [newVid, ...prev]);
    if (isAuthenticatedSession) {
      api.publishVideo({
        title: videoData.taggedProduct.title,
        productId: videoData.taggedProduct.id,
        caption: videoData.caption,
        coverUrl: videoData.posterUrl,
        videoUrl: videoData.videoUrl,
      }).catch(() => {});
    }
    showToast('Short video uploaded and published to For You feed! 🎬');
    return newVid;
  };

  const reportVideo = (videoId: string, reason: string) => {
    showToast(`Report submitted (${reason}). Content flagged for admin review.`);
  };

  // Notifications
  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('All notifications marked as read');
  };

  // Email Marketing & Newsletter Handlers
  const subscribeToNewsletter = (
    email: string,
    options?: {
      name?: string;
      preferences?: string[];
      source?: 'footer' | 'checkout' | 'modal' | 'profile' | 'admin';
    }
  ) => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      showToast('Please provide a valid email address');
      return { success: false, message: 'Invalid email address format' };
    }

    const existingIndex = newsletterSubscribers.findIndex((s) => s.email.toLowerCase() === cleanEmail);

    if (existingIndex >= 0) {
      const existing = newsletterSubscribers[existingIndex];
      const updated: NewsletterSubscriber = {
        ...existing,
        status: 'subscribed',
        name: options?.name || existing.name,
        preferences: options?.preferences || existing.preferences,
      };

      setNewsletterSubscribers((prev) =>
        prev.map((s, idx) => (idx === existingIndex ? updated : s))
      );

      showToast(`Welcome back! Your subscription preferences were updated for ${cleanEmail}.`);
      return {
        success: true,
        message: 'Subscription preferences updated',
        subscriber: updated,
        voucherCode: 'WELCOME2500',
      };
    }

    const newSubscriber: NewsletterSubscriber = {
      id: `sub_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      email: cleanEmail,
      name: options?.name || cleanEmail.split('@')[0],
      subscribedAt: new Date().toISOString(),
      status: 'subscribed',
      preferences: options?.preferences || ['flash-deals', 'livestreams', 'tech', 'fashion'],
      source: options?.source || 'footer',
      welcomeVoucherSent: true,
    };

    setNewsletterSubscribers((prev) => [newSubscriber, ...prev]);

    // Send internal in-app notification
    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        title: 'Newsletter Welcome Voucher Unlocked! 🎁',
        message: `Thank you for subscribing (${cleanEmail}). Use code WELCOME2500 at checkout for ₦2,500 OFF your next order!`,
        type: 'system',
        timestamp: 'Just now',
        read: false,
        link: 'shop?code=WELCOME2500',
      },
      ...prev,
    ]);

    showToast(`🎉 Subscribed! ₦2,500 welcome voucher code WELCOME2500 unlocked for ${cleanEmail}!`);

    return {
      success: true,
      message: 'Successfully subscribed to Cash N Carry newsletters',
      subscriber: newSubscriber,
      voucherCode: 'WELCOME2500',
    };
  };

  const unsubscribeFromNewsletter = (email: string): boolean => {
    const cleanEmail = email.trim().toLowerCase();
    let found = false;

    setNewsletterSubscribers((prev) =>
      prev.map((s) => {
        if (s.email.toLowerCase() === cleanEmail) {
          found = true;
          return { ...s, status: 'unsubscribed' };
        }
        return s;
      })
    );

    if (found) {
      showToast(`Unsubscribed ${cleanEmail} from promotional emails.`);
    }
    return found;
  };

  const updateSubscriberPreferences = (email: string, preferences: string[]) => {
    const cleanEmail = email.trim().toLowerCase();
    setNewsletterSubscribers((prev) =>
      prev.map((s) => (s.email.toLowerCase() === cleanEmail ? { ...s, preferences } : s))
    );
    showToast(`Saved email preferences for ${cleanEmail}`);
  };

  const createEmailCampaign = (
    campaignData: Omit<EmailCampaign, 'id' | 'recipientsCount' | 'openedCount' | 'clickedCount' | 'bouncedCount'>
  ): EmailCampaign => {
    const activeSubscribers = newsletterSubscribers.filter((s) => s.status === 'subscribed');
    const newCampaign: EmailCampaign = {
      ...campaignData,
      id: `camp_${Date.now()}`,
      recipientsCount: activeSubscribers.length,
      openedCount: 0,
      clickedCount: 0,
      bouncedCount: 0,
    };

    setEmailCampaigns((prev) => [newCampaign, ...prev]);
    showToast(`Campaign "${newCampaign.title}" created successfully.`);
    return newCampaign;
  };

  const sendEmailCampaign = async (
    campaignId: string
  ): Promise<{ success: boolean; deliveredCount: number; message: string }> => {
    const campaign = emailCampaigns.find((c) => c.id === campaignId);
    if (!campaign) {
      return { success: false, deliveredCount: 0, message: 'Campaign not found' };
    }

    const activeCount = newsletterSubscribers.filter((s) => s.status === 'subscribed').length || 0;

    setEmailCampaigns((prev) =>
      prev.map((c) =>
        c.id === campaignId
          ? {
              ...c,
              status: 'sent',
              sentAt: new Date().toISOString(),
              recipientsCount: activeCount,
              openedCount: 0,
              clickedCount: 0,
              bouncedCount: 0,
            }
          : c
      )
    );

    showToast(`Campaign "${campaign.title}" marked as staging preview (${activeCount} subscribers; live email sending disabled).`);

    return {
      success: true,
      deliveredCount: activeCount,
      message: `Staging preview recorded for ${activeCount} subscribers (no external email sent).`,
    };
  };

  const sendTestEmail = async (
    templateId: EmailTemplateId,
    targetEmail: string,
    customOptions?: EmailRenderOptions
  ): Promise<{ success: boolean; message: string }> => {
    await new Promise((r) => setTimeout(r, 400));
    showToast(`📨 Test email dispatch sent to ${targetEmail} via Cash N Carry Mailer!`);
    return {
      success: true,
      message: `Test email successfully dispatched to ${targetEmail}.`,
    };
  };

  return (
    <StoreContext.Provider
      value={{
        stagingConfig,
        selectedState,
        setSelectedState,
        isAuthenticatedSession,
        authModalOpen,
        setAuthModalOpen,
        selectedStorefrontId,
        setSelectedStorefrontId,
        refreshAuthSession,
        updateUserProfile,
        signOutAccount,
        currentUser,
        setCurrentUser,
        switchRole,
        products,
        setProducts,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartCount,
        cartSubtotal,
        wishlist,
        toggleWishlist,
        addresses,
        addAddress,
        deleteAddress,
        orders,
        createOrderFromCart,
        cancelOrder,
        payOrderWithFlutterwave,
        auctions,
        placeBid,
        closeAuction,
        checkoutWinningAuction,
        createSellerAuction,
        liveRooms,
        activeLiveRoom,
        setActiveLiveRoom,
        coinBalance,
        coinLedger,
        claimTestCoins,
        sendLiveGift,
        kycSubmissions,
        submitKYC,
        adminApproveKYC,
        adminRejectKYC,
        adminApproveProduct,
        adminRejectProduct,
        adminRefundOrder,
        sellerAddProduct,
        sellerUpdateProduct,
        sellerFulfillOrder,
        messages,
        sendMessage,
        notifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        carrierTrackings,
        shortVideos,
        likeVideo,
        saveVideo,
        followSeller,
        unfollowSeller,
        followingSellers,
        savedVideos,
        addVideoComment,
        uploadShortVideo,
        reportVideo,
        toastMessage,
        showToast,
        cartDrawerOpen,
        setCartDrawerOpen,
        newsletterSubscribers,
        emailCampaigns,
        subscribeToNewsletter,
        unsubscribeFromNewsletter,
        updateSubscriberPreferences,
        createEmailCampaign,
        sendEmailCampaign,
        sendTestEmail,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within StoreProvider');
  return context;
};
