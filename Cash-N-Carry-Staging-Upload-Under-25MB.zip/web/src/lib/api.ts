/**
 * Cash N Carry Nigeria - Unified Cloudflare Worker & D1 API Client
 * Connects React frontend (and mirrors the Android client's /api/v1/* contracts)
 */

export interface ApiCategory {
  id: string;
  name: string;
  active?: number;
}

export interface ApiProduct {
  id: string;
  store: string;
  name: string;
  description: string;
  category: string;
  price: number;
  stock: number;
  image: string;
  featured: number;
}

export interface ApiStorefront {
  id: string;
  name: string;
  description: string;
  category: string;
  location: string;
  verified: number;
}

export interface StagingConfig {
  paymentsEnabled: boolean;
  coinsPurchasesEnabled: boolean;
  kycUploadsEnabled: boolean;
  orderReservationsEnabled: boolean;
  streamConfigured: boolean;
  r2Configured: boolean;
}

export const DEFAULT_STAGING_CONFIG: StagingConfig = {
  paymentsEnabled: false,
  coinsPurchasesEnabled: false,
  kycUploadsEnabled: false,
  orderReservationsEnabled: true,
  streamConfigured: false,
  r2Configured: false,
};

export interface ApiAuthUser {
  id: string;
  email: string;
  role: 'buyer' | 'seller' | 'admin';
}

export interface HealthResponse {
  ok: boolean;
  status?: string;
  service?: string;
  environment?: string;
  dbConnected?: boolean;
  authDbConnected?: boolean;
  authenticated?: boolean;
  user?: ApiAuthUser | null;
  staging?: StagingConfig;
  latencyMs: number;
}

export interface ApiUserProfile {
  user_id: string;
  display_name: string;
  bio: string;
  avatar_url: string;
  selected_state: string;
  email: string;
  role: 'buyer' | 'seller' | 'admin';
}

class ApiClient {
  private baseUrl: string;

  constructor() {
    this.baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
  }

  private async requestJson<T>(
    path: string,
    init?: RequestInit & { timeoutMs?: number }
  ): Promise<{ ok: boolean; status: number; data?: T; error?: string }> {
    try {
      const { timeoutMs = 4500, headers, ...rest } = init || {};
      const res = await fetch(`${this.baseUrl}${path}`, {
        credentials: 'include',
        headers: {
          ...(rest.body ? { 'Content-Type': 'application/json' } : {}),
          ...(headers || {}),
        },
        signal: AbortSignal.timeout(timeoutMs),
        ...rest,
      });
      const data = (await res.json().catch(() => ({}))) as T & { error?: string };
      return { ok: res.ok, status: res.status, data, error: data?.error };
    } catch (err: unknown) {
      return {
        ok: false,
        status: 0,
        error: err instanceof Error ? err.message : 'Network unreachable',
      };
    }
  }

  async checkHealth(): Promise<HealthResponse> {
    const start = performance.now();
    const res = await this.requestJson<Partial<HealthResponse>>('/api/health', { timeoutMs: 3500 });
    const latencyMs = Math.round(performance.now() - start);
    if (res.ok && res.data) {
      return {
        ok: true,
        status: res.data.status || 'ok',
        service: res.data.service,
        environment: res.data.environment,
        dbConnected: res.data.dbConnected,
        authDbConnected: res.data.authDbConnected,
        authenticated: Boolean(res.data.authenticated),
        user: res.data.user ?? null,
        staging: res.data.staging ? { ...DEFAULT_STAGING_CONFIG, ...res.data.staging } : DEFAULT_STAGING_CONFIG,
        latencyMs,
      };
    }
    return { ok: false, staging: DEFAULT_STAGING_CONFIG, latencyMs };
  }

  async login(email: string, password: string): Promise<{ signedIn?: boolean; user?: ApiAuthUser; error?: string }> {
    const res = await this.requestJson<{ signedIn?: boolean; user?: ApiAuthUser }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    return res.ok ? { signedIn: Boolean(res.data?.signedIn), user: res.data?.user } : { error: res.error || 'Sign-in failed' };
  }

  async register(email: string): Promise<{ accepted?: boolean; error?: string }> {
    const res = await this.requestJson<{ accepted?: boolean }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
    return res.ok ? { accepted: Boolean(res.data?.accepted) } : { error: res.error || 'Registration unavailable' };
  }

  async verifyAccount(
    token: string,
    password: string,
    role: 'buyer' | 'seller' = 'buyer'
  ): Promise<{ completed?: boolean; error?: string }> {
    const res = await this.requestJson<{ completed?: boolean }>('/api/auth/verify', {
      method: 'POST',
      body: JSON.stringify({ token, password, role }),
    });
    return res.ok ? { completed: Boolean(res.data?.completed) } : { error: res.error || 'Verification failed' };
  }

  async requestPasswordReset(email: string): Promise<{ accepted?: boolean; error?: string }> {
    const res = await this.requestJson<{ accepted?: boolean }>('/api/auth/request-reset', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
    return res.ok ? { accepted: Boolean(res.data?.accepted) } : { error: res.error || 'Reset unavailable' };
  }

  async logout(): Promise<void> {
    await this.requestJson('/api/auth/logout', { method: 'POST', body: '{}' });
  }

  async getAuthMe(): Promise<{ user: ApiAuthUser | null; error?: string }> {
    const res = await this.requestJson<{ user?: ApiAuthUser }>('/api/auth/me', { timeoutMs: 3500 });
    return { user: res.ok ? res.data?.user ?? null : null, error: res.error };
  }

  async getProfile(): Promise<ApiUserProfile | null> {
    const res = await this.requestJson<{ profile?: ApiUserProfile }>('/api/v1/profile');
    return res.ok ? res.data?.profile ?? null : null;
  }

  async updateProfile(input: {
    displayName: string;
    bio: string;
    avatarUrl: string;
    selectedState: string;
  }): Promise<{ updated: boolean; profile?: ApiUserProfile; error?: string }> {
    const res = await this.requestJson<{ updated?: boolean; profile?: ApiUserProfile }>('/api/v1/profile', {
      method: 'PUT',
      body: JSON.stringify(input),
    });
    return { updated: Boolean(res.ok && res.data?.updated), profile: res.data?.profile, error: res.error };
  }

  async getCategories(search = ''): Promise<ApiCategory[]> {
    const query = search ? `?q=${encodeURIComponent(search)}` : '';
    const res = await this.requestJson<{ categories?: ApiCategory[] } | ApiCategory[]>(`/api/categories${query}`);
    if (res.ok && res.data) {
      return Array.isArray(res.data) ? res.data : res.data.categories ?? [];
    }
    return [];
  }

  async getProducts(params?: { q?: string; store?: string; category?: string; offset?: number }): Promise<ApiProduct[]> {
    const sp = new URLSearchParams();
    if (params?.q) sp.set('q', params.q);
    if (params?.store) sp.set('store', params.store);
    if (params?.category) sp.set('category', params.category);
    if (params?.offset) sp.set('offset', String(params.offset));
    const qs = sp.toString();
    const res = await this.requestJson<{ products?: ApiProduct[] } | ApiProduct[]>(
      `/api/products${qs ? `?${qs}` : ''}`
    );
    if (res.ok && res.data) {
      return Array.isArray(res.data) ? res.data : res.data.products ?? [];
    }
    return [];
  }

  async getStorefront(storeId: string): Promise<ApiStorefront | null> {
    const res = await this.requestJson<{ storefront?: ApiStorefront } | ApiStorefront>(
      `/api/storefronts/${encodeURIComponent(storeId)}`
    );
    if (res.ok && res.data) {
      return 'storefront' in res.data ? res.data.storefront ?? null : (res.data as ApiStorefront);
    }
    return null;
  }

  async getAddresses(): Promise<Array<{ id: string; recipient: string; line: string; city: string; state: string }>> {
    const res = await this.requestJson<{ addresses?: Array<{ id: string; recipient: string; line: string; city: string; state: string }> }>('/api/v1/addresses');
    return res.ok ? res.data?.addresses ?? [] : [];
  }

  async createAddress(input: { recipient: string; line: string; city: string; state: string }) {
    return this.requestJson<{ address?: { id: string; recipient: string; line: string; city: string; state: string } }>(
      '/api/v1/addresses',
      { method: 'POST', body: JSON.stringify(input) }
    );
  }

  async deleteAddress(id: string) {
    return this.requestJson<{ deleted?: boolean }>('/api/v1/addresses', {
      method: 'DELETE',
      body: JSON.stringify({ id }),
    });
  }

  async updateCartItem(id: string, quantity: number, source: 'legacy' | 'replacement' = 'replacement') {
    return this.requestJson<{ updated?: boolean }>('/api/cart', {
      method: 'POST',
      body: JSON.stringify({ id, quantity, source }),
    });
  }

  async checkoutCart(requestId: string, addressId: string) {
    return this.requestJson<{ order?: { id: string; status: string } }>('/api/checkout', {
      method: 'POST',
      body: JSON.stringify({ request_id: requestId, address_id: addressId }),
    });
  }

  async getWishlist(): Promise<string[]> {
    const res = await this.requestJson<{ wishlist?: Array<{ product_id: string }> }>('/api/v1/wishlist');
    return res.ok ? (res.data?.wishlist ?? []).map((w) => w.product_id) : [];
  }

  async getFollows(): Promise<string[]> {
    const res = await this.requestJson<{ following?: Array<{ seller_id: string }> }>('/api/v1/follows');
    return res.ok ? (res.data?.following ?? []).map((f) => f.seller_id) : [];
  }

  async getMessages() {
    const res = await this.requestJson<{ messages?: Array<Record<string, unknown>> }>('/api/v1/messages');
    return res.ok ? res.data?.messages ?? [] : [];
  }

  async getNotifications() {
    const res = await this.requestJson<{ notifications?: Array<Record<string, unknown>> }>('/api/v1/notifications');
    return res.ok ? res.data?.notifications ?? [] : [];
  }

  async markNotificationsRead() {
    return this.requestJson<{ updated?: boolean }>('/api/v1/notifications', {
      method: 'PATCH',
      body: '{}',
    });
  }

  async toggleVideoLike(videoId: string) {
    return this.requestJson<{ liked?: boolean }>('/api/v1/videos/like', {
      method: 'POST',
      body: JSON.stringify({ videoId }),
    });
  }

  async addVideoComment(videoId: string, body: string) {
    return this.requestJson<{ success?: boolean; id?: string }>('/api/v1/videos/comments', {
      method: 'POST',
      body: JSON.stringify({ videoId, body }),
    });
  }

  async fulfillOrder(orderId: string, status: string, carrier: string, trackingNumber: string) {
    return this.requestJson<{ updated?: boolean }>('/api/v1/seller/orders/fulfil', {
      method: 'POST',
      body: JSON.stringify({ orderId, status, carrier, trackingNumber }),
    });
  }

  async toggleWishlist(productId: string) {
    return this.requestJson<{ wishlisted?: boolean }>('/api/v1/wishlist', {
      method: 'POST',
      body: JSON.stringify({ productId }),
    });
  }

  async toggleFollow(sellerId: string) {
    return this.requestJson<{ following?: boolean }>('/api/v1/follows', {
      method: 'POST',
      body: JSON.stringify({ sellerId }),
    });
  }

  async getVideos() {
    const res = await this.requestJson<{ videos?: Array<Record<string, unknown>> }>('/api/v1/videos');
    return res.ok ? res.data?.videos ?? [] : [];
  }

  async publishVideo(input: {
    title: string;
    productId: string;
    caption: string;
    coverUrl: string;
    videoUrl?: string;
  }) {
    return this.requestJson<{ success?: boolean; id?: string }>('/api/v1/videos', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async getLiveRooms() {
    const res = await this.requestJson<{ rooms?: Array<Record<string, unknown>> }>('/api/v1/live');
    return res.ok ? res.data?.rooms ?? [] : [];
  }

  async createLiveRoom(input: { title: string; category: string; pinnedProductId?: string }) {
    return this.requestJson<{ success?: boolean; roomId?: string }>('/api/v1/live', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async sendMessage(input: { receiverId: string; body: string; orderId?: string; productId?: string }) {
    return this.requestJson<{ success?: boolean; id?: string }>('/api/v1/messages', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async getKycStatus(): Promise<{ uploadsEnabled: boolean; r2Configured?: boolean; reason?: string }> {
    const res = await this.requestJson<{ uploadsEnabled: boolean; r2Configured?: boolean; reason?: string }>(
      '/api/sellers/kyc',
      { timeoutMs: 3500 }
    );
    if (res.ok && res.data) return res.data;
    return {
      uploadsEnabled: false,
      r2Configured: false,
      reason: 'KYC document uploads are temporarily unavailable in staging.',
    };
  }

  async getAuctions(): Promise<{ paymentsEnabled: boolean; auctions: unknown[] }> {
    const res = await this.requestJson<{ paymentsEnabled?: boolean; auctions?: unknown[] }>('/api/auctions', {
      timeoutMs: 3500,
    });
    if (res.ok && res.data) {
      return {
        paymentsEnabled: Boolean(res.data.paymentsEnabled),
        auctions: res.data.auctions ?? [],
      };
    }
    return { paymentsEnabled: false, auctions: [] };
  }

  async placeBid(auctionId: string, amountNaira: number) {
    return this.requestJson<{ success?: boolean; bidId?: string }>('/api/auctions', {
      method: 'PATCH',
      body: JSON.stringify({ action: 'bid', id: auctionId, amountKobo: Math.round(amountNaira * 100) }),
    });
  }

  async getCoins() {
    return this.requestJson<{ balance?: number; purchasesEnabled?: boolean; activity?: unknown[] }>('/api/coins');
  }

  async sendGift(recipientId: string, gift: 'rose' | 'star' | 'lion', requestId: string) {
    return this.requestJson<{ success?: boolean; giftId?: string }>('/api/coins', {
      method: 'POST',
      body: JSON.stringify({ action: 'gift', recipientId, gift, requestId }),
    });
  }

  async initializePayment(orderId: string): Promise<{ checkout_url?: string; error?: string; code?: string }> {
    const res = await this.requestJson<{ checkout_url?: string; error?: string; code?: string }>(
      '/api/payments/initialize',
      {
        method: 'POST',
        body: JSON.stringify({ order_id: orderId }),
      }
    );
    return res.data ?? { error: res.error || 'Payments temporarily unavailable', code: 'PAYMENTS_DISABLED' };
  }

  async getPaymentStatus(orderId: string): Promise<{ status?: string; paymentsEnabled?: boolean; error?: string }> {
    const res = await this.requestJson<{ status?: string; paymentsEnabled?: boolean; error?: string }>(
      `/api/payments/status?order_id=${encodeURIComponent(orderId)}`,
      { timeoutMs: 3500 }
    );
    return res.data ?? { error: 'Payment status unavailable', paymentsEnabled: false };
  }
}

export const api = new ApiClient();
