export type Category = {
  id: string;
  name: string;
  slug: string;
  count: number;
  subtitle: string;
  accent: string;
  bgHex: string;
  icon: string;
};

export type Product = {
  id: string;
  slug: string;
  title: string;
  brand: string;
  price: number;
  compareAt: number;
  rating: number;
  reviews: number;
  image: string;
  category: string;
  badge?: string;
  featured?: boolean;
  description: string;
};

export type Seller = {
  id: string;
  slug: string;
  name: string;
  location: string;
  rating: number;
  followers: string;
  sold: number;
  avatar: string;
  badge?: string;
  focus: string;
  sampleProducts?: string[];
};

export const categories: Category[] = [
  { id: 'fashion', name: 'Fashion', slug: 'fashion', count: 142, subtitle: 'Clothing & accessories', accent: 'bg-rose-500', bgHex: '#EF4444', icon: '👗' },
  { id: 'beauty', name: 'Beauty', slug: 'beauty', count: 98, subtitle: 'Skincare & makeup', accent: 'bg-pink-500', bgHex: '#EC4899', icon: '💄' },
  { id: 'phones', name: 'Phones', slug: 'phones', count: 115, subtitle: 'Mobiles & accessories', accent: 'bg-amber-500', bgHex: '#F59E0B', icon: '📱' },
  { id: 'tech', name: 'Electronics', slug: 'electronics', count: 86, subtitle: 'Gadgets & devices', accent: 'bg-blue-500', bgHex: '#3B82F6', icon: '💻' },
  { id: 'home', name: 'Home & Living', slug: 'home', count: 74, subtitle: 'Furniture, decor & more', accent: 'bg-amber-800', bgHex: '#854D0E', icon: '🛋️' },
  { id: 'baby', name: 'Baby & Kids', slug: 'baby', count: 62, subtitle: 'Essentials & toys', accent: 'bg-purple-500', bgHex: '#8B5CF6', icon: '🧸' },
  { id: 'health', name: 'Health', slug: 'health', count: 53, subtitle: 'Wellness & fitness', accent: 'bg-emerald-600', bgHex: '#10B981', icon: '🌿' },
  { id: 'services', name: 'Services', slug: 'services', count: 41, subtitle: 'Digital & everyday services', accent: 'bg-indigo-600', bgHex: '#4F46E5', icon: '⚡' },
];

export const sellers: Seller[] = [
  {
    id: 'obimart',
    slug: 'obimart-stores',
    name: 'ObiMart Stores',
    location: 'Lagos',
    rating: 4.9,
    followers: '12.4K',
    sold: 3420,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80',
    badge: 'Official Store',
    focus: 'Official Store',
    sampleProducts: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=400&auto=format&fit=crop&q=80',
    ],
  },
  {
    id: 'zeeglow',
    slug: 'zee-glow-cosmetics',
    name: 'Zee Glow Cosmetics',
    location: 'Abuja',
    rating: 4.8,
    followers: '8.9K',
    sold: 1890,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop&q=80',
    badge: 'Verified CAC',
    focus: 'Beauty & Personal Care',
    sampleProducts: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400&auto=format&fit=crop&q=80',
    ],
  },
  {
    id: 'naijatech',
    slug: 'naija-tech-market',
    name: 'Naija Tech Market',
    location: 'Lagos',
    rating: 4.9,
    followers: '21.6K',
    sold: 5120,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&auto=format&fit=crop&q=80',
    badge: 'Top Rated',
    focus: 'Electronics & Gadgets',
    sampleProducts: [
      'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&auto=format&fit=crop&q=80',
    ],
  },
  {
    id: 'classiclooks',
    slug: 'classic-looks',
    name: 'Classic Looks',
    location: 'Lagos',
    rating: 4.8,
    followers: '15.1K',
    sold: 2750,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80',
    badge: 'Verified Fashion',
    focus: 'Fashion store',
    sampleProducts: [
      'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=400&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&auto=format&fit=crop&q=80',
    ],
  },
];

export const products: Product[] = [
  {
    id: 'p1',
    slug: 'studio-wireless-headphones',
    title: 'Studio Wireless Headphones',
    brand: 'Audio Technica',
    price: 18500,
    compareAt: 23000,
    rating: 4.8,
    reviews: 236,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
    category: 'tech',
    badge: '-20%',
    featured: true,
    description: 'Active noise cancellation, punchy bass and up to 40 hours wireless battery life.',
  },
  {
    id: 'p2',
    slug: 'android-tablet-10-1-128gb',
    title: 'Android Tablet 10.1" 128GB',
    brand: 'Naija Tech Market',
    price: 69000,
    compareAt: 80000,
    rating: 4.7,
    reviews: 118,
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80',
    category: 'tech',
    badge: 'Hot Deal',
    featured: true,
    description: 'Vibrant 10.1-inch IPS display with 128GB storage, quad-core processor and 4G LTE SIM support.',
  },
  {
    id: 'p3',
    slug: 'wireless-earbuds-anc',
    title: 'Wireless Earbuds (ANC)',
    brand: 'Soundcore Lagos',
    price: 14000,
    compareAt: 16500,
    rating: 4.6,
    reviews: 492,
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
    category: 'tech',
    badge: '-15%',
    featured: true,
    description: 'Crystal clear phone calls in noisy traffic, quick USB-C charging and sweat resistance.',
  },
  {
    id: 'p4',
    slug: 'smart-fitness-watch',
    title: 'Smart Fitness Watch',
    brand: 'Wearables NG',
    price: 32500,
    compareAt: 36000,
    rating: 4.7,
    reviews: 301,
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80',
    category: 'tech',
    badge: 'Best Seller',
    featured: true,
    description: 'Real-time heart rate, blood oxygen monitor, steps tracker and WhatsApp notifications.',
  },
  {
    id: 'p5',
    slug: 'womens-handbag-leather',
    title: "Women's Handbag (Leather)",
    brand: 'Classic Looks',
    price: 24500,
    compareAt: 35000,
    rating: 4.8,
    reviews: 107,
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop&q=80',
    category: 'fashion',
    badge: '-30%',
    featured: true,
    description: 'Premium handcrafted leather handbag with gold metallic hardware and adjustable shoulder strap.',
  },
  {
    id: 'p6',
    slug: 'mens-sneakers',
    title: "Men's Sneakers",
    brand: 'UrbanWear NG',
    price: 28000,
    compareAt: 37500,
    rating: 4.7,
    reviews: 563,
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800&auto=format&fit=crop&q=80',
    category: 'fashion',
    badge: '-25%',
    featured: true,
    description: 'Lightweight cushioned athletic running sneakers designed for maximum comfort and style.',
  },
  {
    id: 'p7',
    slug: 'elegant-ankara-print-dress',
    title: 'Elegant Ankara Print Dress',
    brand: 'Olaoluwa Trends',
    price: 16250,
    compareAt: 22000,
    rating: 4.8,
    reviews: 176,
    image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&auto=format&fit=crop&q=80',
    category: 'fashion',
    badge: 'New',
    featured: true,
    description: 'Bold Nigerian-inspired design with premium fabric and a flattering fit.',
  },
  {
    id: 'p8',
    slug: 'glow-gold-skincare-set',
    title: 'Glow Gold Skincare Set',
    brand: 'Zee Glow Cosmetics',
    price: 9800,
    compareAt: 12000,
    rating: 4.9,
    reviews: 142,
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800&auto=format&fit=crop&q=80',
    category: 'beauty',
    badge: 'Best seller',
    featured: true,
    description: 'A daily hydrating set with vitamin-based care and a radiant glow.',
  },
];

export const heroStats = [
  { label: 'Active Sellers', value: '12K+' },
  { label: 'Products', value: '250K+' },
  { label: 'User Rating', value: '4.7★' },
];

export const marketplaceTabs = ['For You', 'Shop', 'Fashion', 'Beauty', 'Phones', 'Electronics', 'Home & Living', 'Live shopping', 'Sell with us'];

export const currency = (value: number) => `₦${value.toLocaleString('en-NG')}`;

export const findProductBySlug = (slug: string) => products.find((product) => product.slug === slug || product.id === slug) ?? products[0];

export const findSellerBySlug = (slug: string) => sellers.find((seller) => seller.slug === slug || seller.id === slug) ?? sellers[0];
