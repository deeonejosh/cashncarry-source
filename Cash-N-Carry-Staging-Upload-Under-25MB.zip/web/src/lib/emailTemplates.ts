import { EmailTemplate, EmailTemplateId, EmailCampaign, NewsletterSubscriber, ProductItem } from '../types';

export const EMAIL_TEMPLATES: EmailTemplate[] = [
  {
    id: 'welcome',
    name: 'Welcome & ₦2,500 Voucher Onboarding',
    category: 'onboarding',
    description: 'Sent immediately when a shopper joins the newsletter or registers on Cash N Carry Nigeria. Includes a ₦2,500 discount code.',
    defaultSubject: 'Welcome to Cash N Carry Nigeria! Claim your ₦2,500 welcome voucher 🎁',
    defaultPreheader: 'Enjoy verified Nigerian shopping, live streams, and ₦2,500 off your first order.',
    defaultHeadline: 'Watch Live. Discover. Shop.',
    defaultBody: 'Welcome to Nigeria’s premier live commerce marketplace! Whether you are hunting for daily flash deals, joining interactive seller livestreams, or shopping for authentic tech and fashion, we have got you covered with nationwide delivery and Flutterwave buyer protection.',
    defaultCtaText: 'Claim ₦2,500 & Start Shopping',
    defaultCtaUrl: 'https://www.cashncarryng.com/shop?voucher=WELCOME2500',
    thumbnail: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=500&auto=format&fit=crop&q=80',
  },
  {
    id: 'flash_sale',
    name: 'Weekly Live Shopping & Flash Sale Blast',
    category: 'promotional',
    description: 'Weekly digest showcasing upcoming live streams, exclusive flash discounts up to 40% off, and limited-time stock.',
    defaultSubject: '⚡ 40% OFF Flash Sale + 12 Live Shopping Streams Now Active!',
    defaultPreheader: 'Top deals on Android tablets, wireless ANC earbuds, and Ankara dresses live now.',
    defaultHeadline: 'Don’t Miss This Week’s Hottest Deals',
    defaultBody: 'Top verified Nigerian sellers are broadcasting live right now with unboxing discounts, instant auction drops, and limited flash vouchers. Grab your favorites before stocks clear!',
    defaultCtaText: 'Enter Live Shopping Arena',
    defaultCtaUrl: 'https://www.cashncarryng.com/live',
    thumbnail: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=500&auto=format&fit=crop&q=80',
  },
  {
    id: 'order_confirmation',
    name: 'Order Confirmation & Escrow Delivery Receipt',
    category: 'transactional',
    description: 'Sent when an order is paid via Flutterwave. Outlines ordered items, delivery tracking number, and escrow release terms.',
    defaultSubject: 'Your Cash N Carry Order #CNC-90821 is Confirmed! 📦',
    defaultPreheader: 'Your payment is safely secured in Flutterwave escrow until delivery.',
    defaultHeadline: 'Order Confirmed & Preparing for Dispatch',
    defaultBody: 'Thank you for your order! Your payment has been securely confirmed via Flutterwave Sandbox Escrow. The verified merchant is packaging your items. Tracking updates will be delivered as your package travels across Nigeria.',
    defaultCtaText: 'Track Your Package in Real-Time',
    defaultCtaUrl: 'https://www.cashncarryng.com/orders',
    thumbnail: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=500&auto=format&fit=crop&q=80',
  },
  {
    id: 'abandoned_cart',
    name: 'Abandoned Cart & Stock Alert',
    category: 're-engagement',
    description: 'Triggered when a shopper leaves items in their bag without finishing checkout. Creates urgency with low stock notices.',
    defaultSubject: 'Did you leave something behind? Your bag is waiting! 🛒',
    defaultPreheader: 'Items in your cart are in high demand and stocks are selling fast.',
    defaultHeadline: 'Complete Your Order Before It Sells Out',
    defaultBody: 'You left some amazing items in your Cash N Carry cart! With verified seller guarantees, nationwide delivery, and 7-day hassle-free returns, you can shop with total peace of mind.',
    defaultCtaText: 'Return to Cart & Complete Order',
    defaultCtaUrl: 'https://www.cashncarryng.com/checkout',
    thumbnail: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=500&auto=format&fit=crop&q=80',
  },
  {
    id: 'seller_weekly',
    name: 'Seller Weekly Payout & Analytics Digest',
    category: 'seller',
    description: 'Weekly report sent to registered merchants summarizing sales volume, escrow disbursements, and livestream viewer engagement.',
    defaultSubject: 'Your Weekly Seller Digest: ₦428,500 Gross Volume & New Followers 📈',
    defaultPreheader: 'Review your sales growth, completed deliveries, and payout schedules on Cash N Carry.',
    defaultHeadline: 'Your Merchant Performance This Week',
    defaultBody: 'Congratulations on a successful week on Cash N Carry Nigeria! Your store saw strong engagement across live streams and catalog sales. Here is your operational summary and upcoming settlement schedule.',
    defaultCtaText: 'Open Seller Centre Dashboard',
    defaultCtaUrl: 'https://www.cashncarryng.com/seller-dashboard',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=80',
  },
];

export const INITIAL_SUBSCRIBERS: NewsletterSubscriber[] = [
  {
    id: 'sub_1',
    email: 'ogundiyatemidayo@gmail.com',
    name: 'Temidayo Ogundiya',
    subscribedAt: '2026-11-10T14:32:00Z',
    status: 'subscribed',
    preferences: ['flash-deals', 'livestreams', 'tech', 'fashion'],
    source: 'modal',
    welcomeVoucherSent: true,
  },
  {
    id: 'sub_2',
    email: 'chidi.okafor@gmail.com',
    name: 'Chidi Okafor',
    subscribedAt: '2026-11-08T09:15:00Z',
    status: 'subscribed',
    preferences: ['tech', 'flash-deals'],
    source: 'checkout',
    welcomeVoucherSent: true,
  },
  {
    id: 'sub_3',
    email: 'amina.bello@abuja-ventures.ng',
    name: 'Amina Bello',
    subscribedAt: '2026-11-07T18:45:00Z',
    status: 'subscribed',
    preferences: ['fashion', 'beauty', 'livestreams'],
    source: 'footer',
    welcomeVoucherSent: true,
  },
  {
    id: 'sub_4',
    email: 'tunde.bakare@lagostech.com',
    name: 'Tunde Bakare',
    subscribedAt: '2026-11-05T11:20:00Z',
    status: 'subscribed',
    preferences: ['tech', 'gadgets'],
    source: 'footer',
    welcomeVoucherSent: true,
  },
  {
    id: 'sub_5',
    email: 'kemi.adeyemi@ibadanmarket.ng',
    name: 'Kemi Adeyemi',
    subscribedAt: '2026-11-02T16:10:00Z',
    status: 'subscribed',
    preferences: ['fashion', 'beauty'],
    source: 'profile',
    welcomeVoucherSent: true,
  },
  {
    id: 'sub_6',
    email: 'emeka.nnamdi@ph-logistics.com',
    name: 'Emeka Nnamdi',
    subscribedAt: '2026-10-28T08:05:00Z',
    status: 'unsubscribed',
    preferences: ['flash-deals'],
    source: 'checkout',
    welcomeVoucherSent: true,
  },
];

export const INITIAL_CAMPAIGNS: EmailCampaign[] = [
  {
    id: 'camp_1',
    title: 'Black Friday Naija Earlybird Warmup',
    subject: '🔥 Black Friday Early Access: Up to 45% OFF Top Nigerian Brands',
    preheader: 'First pick on wireless audio, Android tablets, and designer sneakers.',
    templateId: 'flash_sale',
    status: 'sent',
    audienceSegment: 'all',
    sentAt: '2026-11-09T10:00:00Z',
    recipientsCount: 4820,
    openedCount: 1980,
    clickedCount: 712,
    bouncedCount: 14,
    content: {
      headline: 'Early Access Black Friday Deals Are Live!',
      body: 'Get exclusive first access to our biggest markdown event before public release. Stocks are strictly limited to the first 500 orders.',
      ctaText: 'Shop Black Friday Earlybird',
      ctaUrl: 'https://www.cashncarryng.com/flash-deals',
      voucherCode: 'EARLYBIRD45',
      featuredProductIds: ['p1', 'p2', 'p3'],
    },
  },
  {
    id: 'camp_2',
    title: 'Weekend Live Shopping Fest Announcement',
    subject: '🎬 Meet Naija’s Top Creators Live This Saturday (+ Flash Drops!)',
    preheader: 'Unboxing streams, interactive Q&A, and live voucher drops starting at 2 PM.',
    templateId: 'flash_sale',
    status: 'sent',
    audienceSegment: 'livestreams' as any,
    sentAt: '2026-11-06T15:00:00Z',
    recipientsCount: 2340,
    openedCount: 1120,
    clickedCount: 489,
    bouncedCount: 8,
    content: {
      headline: 'Join 10+ Livestreams with Live Unboxings',
      body: 'Get ready for our weekend live creator marathon featuring Naija Tech Market and Zee Glow Cosmetics with live product trials.',
      ctaText: 'Set Live Reminder',
      ctaUrl: 'https://www.cashncarryng.com/live',
      voucherCode: 'LIVESATURDAY',
    },
  },
  {
    id: 'camp_3',
    title: 'New User Onboarding Welcome Sequence',
    subject: 'Welcome to Cash N Carry Nigeria! Claim your ₦2,500 welcome voucher 🎁',
    preheader: 'Enjoy verified Nigerian shopping, live streams, and ₦2,500 off your first order.',
    templateId: 'welcome',
    status: 'scheduled',
    audienceSegment: 'all',
    scheduledFor: '2026-11-15T09:00:00Z',
    recipientsCount: 890,
    openedCount: 0,
    clickedCount: 0,
    bouncedCount: 0,
    content: {
      headline: 'Watch Live. Discover. Shop.',
      body: 'Welcome to Cash N Carry Nigeria! Explore authentic goods from top verified vendors with 7-day returns and Flutterwave escrow protection.',
      ctaText: 'Claim ₦2,500 Voucher & Shop',
      ctaUrl: 'https://www.cashncarryng.com/shop?code=WELCOME2500',
      voucherCode: 'WELCOME2500',
      featuredProductIds: ['p1', 'p2', 'p5'],
    },
  },
];

export interface EmailRenderOptions {
  recipientName?: string;
  recipientEmail?: string;
  headline?: string;
  body?: string;
  ctaText?: string;
  ctaUrl?: string;
  voucherCode?: string;
  featuredProducts?: ProductItem[];
  orderId?: string;
  orderTotal?: number;
  trackingNumber?: string;
  previewText?: string;
}

export function generateHtmlEmail(templateId: EmailTemplateId, options: EmailRenderOptions = {}): string {
  const template = EMAIL_TEMPLATES.find((t) => t.id === templateId) || EMAIL_TEMPLATES[0];
  const name = options.recipientName || 'Valued Shopper';
  const headline = options.headline || template.defaultHeadline;
  const body = options.body || template.defaultBody;
  const ctaText = options.ctaText || template.defaultCtaText;
  const ctaUrl = options.ctaUrl || template.defaultCtaUrl;
  const preview = options.previewText || template.defaultPreheader;
  const voucherCode = options.voucherCode || (templateId === 'welcome' ? 'WELCOME2500' : undefined);
  const products = options.featuredProducts || [];

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${template.defaultSubject}</title>
  <!--[if mso]>
  <style type="text/css">
    body, table, td, a { font-family: Arial, sans-serif !important; }
  </style>
  <![endif]-->
  <style>
    body { margin: 0; padding: 0; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b; }
    table { border-collapse: collapse; mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
    img { border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; max-width: 100%; display: block; }
    a { color: #0c5c36; text-decoration: none; }
    .btn-primary { background-color: #0c5c36; color: #ffffff !important; font-weight: 800; padding: 14px 28px; border-radius: 9999px; display: inline-block; text-align: center; font-size: 14px; text-decoration: none; letter-spacing: 0.2px; }
    .btn-primary:hover { background-color: #09472a !important; }
    @media only screen and (max-width: 620px) {
      .container { width: 100% !important; padding: 12px !important; }
      .col-half { width: 100% !important; display: block !important; margin-bottom: 12px !important; }
      .headline { font-size: 24px !important; line-height: 1.25 !important; }
    }
  </style>
</head>
<body style="margin: 0; padding: 24px 0; background-color: #f4f6f8;">
  
  <!-- Preheader text for inbox preview -->
  <div style="display: none; max-height: 0px; overflow: hidden;">
    ${preview} &nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;
  </div>

  <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center">
        
        <!-- Main Card Container (600px standard) -->
        <table role="presentation" class="container" width="600" border="0" cellspacing="0" cellpadding="0" style="background-color: #ffffff; border-radius: 20px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);">
          
          <!-- Brand Header -->
          <tr>
            <td style="background-color: #073c22; padding: 20px 32px; text-align: left;">
              <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td>
                    <span style="font-size: 22px; font-weight: 900; color: #ffffff; letter-spacing: -0.5px;">
                      Cash <span style="color: #fb923c;">N</span> Carry
                    </span>
                    <span style="display: block; font-size: 10px; font-weight: 700; color: #86efac; letter-spacing: 1.5px; text-transform: uppercase; margin-top: 2px;">
                      Nigeria · Live Shopping Marketplace
                    </span>
                  </td>
                  <td align="right">
                    <span style="background-color: rgba(255, 255, 255, 0.12); border: 1px solid rgba(255, 255, 255, 0.2); padding: 5px 12px; border-radius: 9999px; font-size: 11px; font-weight: 800; color: #ffffff;">
                      🇳🇬 Official Dispatch
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Hero Banner Section -->
          <tr>
            <td style="background: linear-gradient(135deg, #0c5c36 0%, #06311c 100%); padding: 36px 32px; color: #ffffff; text-align: left;">
              <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td>
                    <span style="background-color: rgba(251, 146, 60, 0.2); border: 1px solid rgba(251, 146, 60, 0.4); color: #fed7aa; padding: 4px 10px; border-radius: 9999px; font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px;">
                      Verified Newsletter
                    </span>
                    <h1 class="headline" style="font-size: 30px; font-weight: 900; margin: 12px 0 8px 0; line-height: 1.15; color: #ffffff; letter-spacing: -0.5px;">
                      ${headline}
                    </h1>
                    <p style="font-size: 14px; line-height: 1.5; color: #d1fae5; margin: 0 0 16px 0;">
                      Hello ${name}, ${body}
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          ${voucherCode ? `
          <!-- Exclusive Voucher Code Card -->
          <tr>
            <td style="padding: 24px 32px 12px 32px;">
              <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #fff7ed; border: 2px dashed #f97316; border-radius: 16px; padding: 20px; text-align: center;">
                <tr>
                  <td>
                    <span style="font-size: 11px; font-weight: 900; color: #c2410c; text-transform: uppercase; letter-spacing: 1px;">
                      Exclusive Shopper Voucher
                    </span>
                    <div style="font-size: 26px; font-weight: 900; color: #ea580c; margin: 6px 0; letter-spacing: 2px; font-family: monospace;">
                      ${voucherCode}
                    </div>
                    <span style="font-size: 12px; color: #7c2d12; font-weight: 600;">
                      Apply at checkout for ₦2,500 OFF on orders above ₦10,000 across all verified stores.
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>` : ''}

          <!-- Call to Action Button -->
          <tr>
            <td align="center" style="padding: 24px 32px;">
              <a href="${ctaUrl}" class="btn-primary" target="_blank" style="background-color: #0c5c36; color: #ffffff !important; font-weight: 800; padding: 14px 32px; border-radius: 9999px; display: inline-block; text-align: center; font-size: 14px; text-decoration: none;">
                ${ctaText} &rarr;
              </a>
            </td>
          </tr>

          ${products.length > 0 ? `
          <!-- Featured Products Section -->
          <tr>
            <td style="padding: 12px 32px 24px 32px;">
              <div style="border-top: 1px solid #e2e8f0; padding-top: 24px; margin-bottom: 16px;">
                <span style="font-size: 11px; font-weight: 900; color: #64748b; text-transform: uppercase; letter-spacing: 1px;">
                  Featured Marketplace Highlights
                </span>
                <h3 style="font-size: 18px; font-weight: 900; color: #0f172a; margin: 4px 0 16px 0;">
                  Popular on Cash N Carry Nigeria
                </h3>
              </div>

              <!-- Product Row -->
              <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  ${products.slice(0, 2).map((prod) => `
                  <td class="col-half" width="48%" valign="top" style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 14px; padding: 14px;">
                    <img src="${prod.image}" alt="${prod.title}" style="width: 100%; height: 160px; object-fit: cover; border-radius: 10px; margin-bottom: 10px;" />
                    <span style="font-size: 10px; font-weight: 800; color: #0c5c36; text-transform: uppercase;">
                      ${prod.brand}
                    </span>
                    <h4 style="font-size: 13px; font-weight: 800; color: #1e293b; margin: 2px 0 6px 0; line-height: 1.3; height: 34px; overflow: hidden;">
                      ${prod.title}
                    </h4>
                    <div style="font-size: 15px; font-weight: 900; color: #0f172a;">
                      ₦${prod.price.toLocaleString('en-NG')}
                      ${prod.compareAt > prod.price ? `<span style="font-size: 11px; color: #94a3b8; text-decoration: line-through; margin-left: 4px;">₦${prod.compareAt.toLocaleString('en-NG')}</span>` : ''}
                    </div>
                    <div style="margin-top: 10px;">
                      <a href="https://www.cashncarryng.com/shop?id=${prod.id}" style="display: block; text-align: center; background-color: #0c5c36; color: #ffffff; padding: 8px 12px; border-radius: 8px; font-size: 11px; font-weight: 800;">
                        Add to Cart
                      </a>
                    </div>
                  </td>
                  <td width="4%">&nbsp;</td>
                  `).join('')}
                </tr>
              </table>
            </td>
          </tr>` : ''}

          <!-- 3 Trust Badges Strip -->
          <tr>
            <td style="padding: 16px 32px 24px 32px; background-color: #f8fafc; border-top: 1px solid #f1f5f9;">
              <table role="presentation" width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="center" width="33%" style="padding: 6px;">
                    <span style="font-size: 16px;">🚚</span>
                    <div style="font-size: 11px; font-weight: 800; color: #0f172a; margin-top: 2px;">Nationwide Delivery</div>
                    <div style="font-size: 10px; color: #64748b;">All 36 States in Nigeria</div>
                  </td>
                  <td align="center" width="33%" style="padding: 6px;">
                    <span style="font-size: 16px;">🔒</span>
                    <div style="font-size: 11px; font-weight: 800; color: #0f172a; margin-top: 2px;">Flutterwave Escrow</div>
                    <div style="font-size: 10px; color: #64748b;">Funds released on delivery</div>
                  </td>
                  <td align="center" width="33%" style="padding: 6px;">
                    <span style="font-size: 16px;">🔄</span>
                    <div style="font-size: 11px; font-weight: 800; color: #0f172a; margin-top: 2px;">7-Day Returns</div>
                    <div style="font-size: 10px; color: #64748b;">Hassle-free guarantee</div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer & Unsubscribe Compliance (CAN-SPAM & NDPR) -->
          <tr>
            <td style="background-color: #0f172a; color: #94a3b8; padding: 28px 32px; text-align: center; font-size: 11px; line-height: 1.6;">
              <div style="margin-bottom: 8px;">
                <strong style="color: #ffffff;">Cash N Carry Nigeria Marketplace</strong><br>
                Plot 14 Adeola Odeku Street, Victoria Island, Lagos, Nigeria<br>
                Official Support: <a href="mailto:support@cashncarryng.com" style="color: #86efac;">support@cashncarryng.com</a>
              </div>
              <div style="border-top: 1px solid rgba(255, 255, 255, 0.1); padding-top: 12px; margin-top: 12px; color: #64748b;">
                You are receiving this email because you subscribed to Cash N Carry updates or hold an active account.<br>
                <a href="https://www.cashncarryng.com/profile?tab=newsletter" style="color: #cbd5e1; text-decoration: underline;">Manage Preferences</a> ·
                <a href="https://www.cashncarryng.com/profile?action=unsubscribe" style="color: #cbd5e1; text-decoration: underline;">Unsubscribe</a> ·
                <a href="https://www.cashncarryng.com/privacy" style="color: #cbd5e1; text-decoration: underline;">Privacy Policy</a>
              </div>
              <div style="margin-top: 8px; color: #475569; font-size: 10px;">
                © 2026 Cash N Carry Nigeria. All rights reserved.
              </div>
            </td>
          </tr>

        </table>
        
      </td>
    </tr>
  </table>
</body>
</html>`;
}
