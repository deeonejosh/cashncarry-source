export type Role = 'buyer' | 'seller' | 'admin';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: Role;
  verified: boolean;
  suspended: boolean;
  storeName?: string;
  avatar?: string;
  bio?: string;
  selectedState?: string;
  authenticated?: boolean;
  coins?: number;
}

export interface ProductItem {
  id: string;
  slug: string;
  title: string;
  brand: string;
  price: number;
  compareAt: number;
  stock: number;
  category: string;
  badge?: string;
  featured?: boolean;
  description: string;
  image: string;
  sellerId: string;
  sellerName: string;
  rating: number;
  reviews: number;
  publication: 'draft' | 'pending' | 'published';
  archived: boolean;
  createdAt: string;
}

export interface CartItem {
  productId: string;
  title: string;
  price: number;
  image: string;
  quantity: number;
  sellerId: string;
  sellerName: string;
  stock: number;
  source: 'legacy' | 'replacement';
}

export interface Address {
  id: string;
  recipient: string;
  phone: string;
  line: string;
  city: string;
  state: string;
  isDefault?: boolean;
}

export interface OrderItem {
  productId: string;
  name: string;
  sellerId: string;
  sellerName: string;
  quantity: number;
  price: number;
  image?: string;
}

export interface Order {
  id: string;
  buyerId: string;
  buyerName: string;
  buyerEmail: string;
  requestId: string;
  address: Address;
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  total: number;
  status: 'awaiting_payment' | 'paid' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: string;
  reservationEndsAt: string;
  flutterwaveRef?: string;
  flutterwaveTransactionId?: string;
  paymentUrl?: string;
  trackingNumber?: string;
  carrier?: string;
}

export interface AuctionItem {
  id: string;
  sellerId: string;
  storefrontName: string;
  productId: string;
  title: string;
  image: string;
  startingBid: number;
  currentBid: number | null;
  winnerId: string | null;
  winnerName: string | null;
  endsAt: string;
  closedAt: string | null;
  orderId: string | null;
  bidsCount: number;
}

export interface LiveRoom {
  id: string;
  sellerId: string;
  sellerName: string;
  title: string;
  status: 'live' | 'ended';
  viewerCount: number;
  heartsCount: number;
  pinnedProduct: ProductItem | null;
  whipUrl?: string;
  whepUrl?: string;
}

export interface CoinActivity {
  id: string;
  delta: number;
  reason: string;
  createdAt: string;
}

export interface KYCSubmission {
  id: string;
  sellerId: string;
  sellerName: string;
  businessName: string;
  cacNumber: string;
  documentName: string;
  documentSize: string;
  scannerStatus: 'clean' | 'scanning' | 'infected';
  encryptionStatus: 'AES-256-GCM-Sealed';
  status: 'pending' | 'verified' | 'rejected';
  submittedAt: string;
  notes?: string;
}

export interface CarrierEvent {
  status: 'Order Placed' | 'Confirmed & Packed' | 'Handed to Carrier' | 'In Transit' | 'Out for Delivery' | 'Delivered';
  location: string;
  timestamp: string;
  note: string;
}

export interface CarrierTracking {
  trackingNumber: string;
  carrier: 'GIG Logistics' | 'Kwik Delivery' | 'DHL Express' | 'Red Star';
  orderId: string;
  currentStatus: string;
  estimatedDelivery: string;
  events: CarrierEvent[];
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
  orderId?: string;
  attachedProduct?: ProductItem;
  imageUrl?: string;
  status?: 'sent' | 'delivered' | 'read';
}

export interface ShortVideoComment {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  createdAt: string;
  likesCount: number;
  liked?: boolean;
}

export interface ShortVideo {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  sellerVerified: boolean;
  isLiveNow?: boolean;
  videoUrl: string;
  posterUrl: string;
  caption: string;
  taggedProduct: ProductItem;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  savesCount: number;
  liked?: boolean;
  saved?: boolean;
  following?: boolean;
  createdAt: string;
  soundTitle?: string;
  comments?: ShortVideoComment[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'live' | 'system' | 'gift' | 'auction';
  timestamp: string;
  read: boolean;
  link?: string;
}

export type EmailTemplateId =
  | 'welcome'
  | 'flash_sale'
  | 'order_confirmation'
  | 'abandoned_cart'
  | 'seller_weekly';

export interface NewsletterSubscriber {
  id: string;
  email: string;
  name?: string;
  subscribedAt: string;
  status: 'subscribed' | 'unconfirmed' | 'unsubscribed';
  preferences: string[];
  source: 'footer' | 'checkout' | 'modal' | 'profile' | 'admin';
  welcomeVoucherSent?: boolean;
}

export interface EmailTemplate {
  id: EmailTemplateId;
  name: string;
  category: 'onboarding' | 'promotional' | 'transactional' | 're-engagement' | 'seller';
  description: string;
  defaultSubject: string;
  defaultPreheader: string;
  defaultHeadline: string;
  defaultBody: string;
  defaultCtaText: string;
  defaultCtaUrl: string;
  thumbnail: string;
}

export interface EmailCampaign {
  id: string;
  title: string;
  subject: string;
  preheader: string;
  templateId: EmailTemplateId;
  status: 'draft' | 'scheduled' | 'sent';
  audienceSegment: 'all' | 'vip' | 'flash_deals' | 'fashion' | 'tech' | 'sellers';
  scheduledFor?: string;
  sentAt?: string;
  recipientsCount: number;
  openedCount: number;
  clickedCount: number;
  bouncedCount: number;
  content: {
    headline: string;
    body: string;
    ctaText: string;
    ctaUrl: string;
    voucherCode?: string;
    featuredProductIds?: string[];
  };
}
