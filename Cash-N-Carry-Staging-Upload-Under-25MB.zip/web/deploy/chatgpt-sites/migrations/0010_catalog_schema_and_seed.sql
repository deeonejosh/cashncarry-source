-- Cash N Carry Staging V17 D1 Migration 0010: Foundation Catalog Schema & Verified Seed Data
-- Creates categories, stores, and products tables queried by deploy/chatgpt-sites/catalog.ts

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
);

CREATE TABLE IF NOT EXISTS stores (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT,
  location TEXT,
  verified INTEGER NOT NULL DEFAULT 1 CHECK(verified IN (0,1)),
  suspended INTEGER NOT NULL DEFAULT 0 CHECK(suspended IN (0,1)),
  phone TEXT
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  store TEXT NOT NULL REFERENCES stores(id),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  price INTEGER NOT NULL CHECK(price > 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
  image TEXT NOT NULL,
  featured INTEGER NOT NULL DEFAULT 0 CHECK(featured IN (0,1)),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
);

CREATE INDEX IF NOT EXISTS idx_products_store ON products(store);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(featured);

-- Seed Categories matching Image 2 & Official Reference
INSERT OR IGNORE INTO categories (id, name, active) VALUES
  ('fashion', 'Fashion', 1),
  ('beauty', 'Beauty', 1),
  ('phones', 'Phones', 1),
  ('electronics', 'Electronics', 1),
  ('home', 'Home & Living', 1),
  ('kids', 'Baby & Kids', 1),
  ('health', 'Health', 1),
  ('services', 'Services', 1);

-- Seed Verified Stores / Sellers
INSERT OR IGNORE INTO stores (id, name, description, category, location, verified, suspended, phone) VALUES
  ('obimart', 'ObiMart Stores', 'Official Store with verified consumer electronics and accessories', 'electronics', 'Lagos', 1, 0, '+234 803 111 2233'),
  ('zeeglow', 'Zee Glow Cosmetics', 'Beauty & Personal Care specialist in Lagos', 'beauty', 'Lagos', 1, 0, '+234 802 222 3344'),
  ('techmarket', 'Naija Tech Market', 'Electronics & Gadgets hub in Computer Village', 'electronics', 'Lagos', 1, 0, '+234 805 333 4455'),
  ('classiclooks', 'Classic Looks', 'Premium Nigerian fashion and streetwear', 'fashion', 'Abuja', 1, 0, '+234 809 444 5566'),
  ('olaoluwa', 'Olaoluwa Trends', 'Authentic apparel and footwear boutique', 'fashion', 'Lagos', 1, 0, '+234 807 555 6677');

-- Seed Official Marketplace Products (Matching Image 2 Reference)
INSERT OR IGNORE INTO products (id, store, name, description, category, price, stock, image, featured, active) VALUES
  ('p1', 'obimart', 'Studio Wireless Headphones', 'High fidelity wireless over-ear headphones with ANC and 40h battery life', 'electronics', 18500, 12, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80', 1, 1),
  ('p2', 'techmarket', 'Android Tablet 10.1" 128GB', 'Crisp 10.1-inch IPS display with 128GB storage and octa-core processor', 'phones', 69000, 8, 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=800&auto=format&fit=crop&q=80', 1, 1),
  ('p3', 'obimart', 'Wireless Earbuds (ANC)', 'Active noise cancelling wireless earbuds with fast charging case', 'electronics', 14000, 25, 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80', 1, 1),
  ('p4', 'techmarket', 'Smart Fitness Watch', 'Waterproof fitness smartwatch with heart rate monitoring and GPS tracking', 'electronics', 32500, 15, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80', 0, 1),
  ('p5', 'classiclooks', 'Women''s Handbag (Leather)', 'Handcrafted genuine leather handbag designed in Nigeria', 'fashion', 24500, 10, 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop&q=80', 0, 1),
  ('p6', 'olaoluwa', 'Men''s Sneakers', 'Breathable athletic streetwear running sneakers with cushioned soles', 'fashion', 28000, 18, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80', 0, 1),
  ('p7', 'classiclooks', 'Elegant Ankara Print Dress', 'Vibrant authentic Ankara fabric evening dress with tailored fit', 'fashion', 16250, 14, 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=800&auto=format&fit=crop&q=80', 0, 1),
  ('p8', 'zeeglow', 'Glow Gold Skincare Set', 'Hydrating organic skincare set with Vitamin C serum and moisturiser', 'beauty', 9800, 30, 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800&auto=format&fit=crop&q=80', 0, 1);
