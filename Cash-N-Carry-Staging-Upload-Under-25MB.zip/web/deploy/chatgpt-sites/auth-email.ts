export interface EmailEnvironment {
  AUTH_EMAIL?: { fetch(request: Request): Promise<Response> };
  AUTH_RESEND_API_KEY?: string;
  AUTH_EMAIL_FROM?: string;
}

export function emailConfigured(env: EmailEnvironment) {
  return Boolean(env.AUTH_EMAIL || (env.AUTH_RESEND_API_KEY && env.AUTH_EMAIL_FROM));
}

export async function deliverAuthEmail(
  env: EmailEnvironment, email: string, token: string, purpose: 'verify' | 'reset', requestId: string,
) {
  const signal = AbortSignal.timeout(8000);
  const response = env.AUTH_EMAIL
    ? await env.AUTH_EMAIL.fetch(new Request('https://auth-mail.internal/send', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email, token, purpose }), signal,
    }))
    : await fetch('https://api.resend.com/emails', {
      method: 'POST', redirect: 'manual', signal,
      headers: {
        authorization: `Bearer ${env.AUTH_RESEND_API_KEY}`,
        'content-type': 'application/json', 'idempotency-key': `cashncarry-auth/${requestId}`,
      },
      body: JSON.stringify({
        from: env.AUTH_EMAIL_FROM, to: [email],
        subject: purpose === 'verify' ? 'Verify your Cash N Carry account' : 'Reset your Cash N Carry password',
        text: `Your Cash N Carry code is ${token}. It expires in 15 minutes. If you did not request this code, you can ignore this email.`,
      }),
    });
  await response.body?.cancel();
  if (!response.ok) throw new Error('Authentication email provider rejected delivery');
}
