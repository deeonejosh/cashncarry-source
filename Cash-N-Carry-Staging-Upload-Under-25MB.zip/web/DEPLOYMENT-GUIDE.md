# Cash N Carry Nigeria — Cloudflare Staging Deployment Guide (V17 Repaired)

This guide covers private Cloudflare staging deployment for `cashncarry-d1-staging-worker` and D1 database `cashncarry-d1-staging`.

> **Safety**: Never deploy to `cashncarryng.com`, alter production DNS/databases, or enable real charges without full Flutterwave onboarding.

---

## 1. Pre-Configured Staging Bindings (`wrangler.jsonc`)

`wrangler.jsonc` is pre-bound to your Cloudflare staging resources:

- **Worker name**: `cashncarry-d1-staging-worker`
- **D1 database**: `cashncarry-d1-staging`
- **Database UUID**: `9a2cdbee-e030-4b10-908b-b10b8142d2aa`
- **Bindings**: Both `AUTH_DB` (`cnc_*` tables) and `DB` (`categories`, `stores`, `products`) share `cashncarry-d1-staging` with zero table collisions.
- **Staging Flags**: `PAYMENTS_ENABLED=false`, `COINS_PURCHASES_ENABLED=false`, `KYC_UPLOADS_ENABLED=false`, `FLW_MODE=disabled`, `ORDER_RESERVATIONS=enabled`.
- **R2 Storage**: Disabled in `wrangler.jsonc` until `cashncarry-staging-private` is provisioned; uncomment the `r2_buckets` block after running `npx wrangler r2 bucket create cashncarry-staging-private`.

---

## 2. Apply Migrations & Catalog Seed Data

### Option A: Standard D1 Migrations (Recommended)
Runs `0001_new_auth.sql` through `0010_catalog_schema_and_seed.sql`:
```bash
# Run local D1 migrations check
npx wrangler d1 migrations apply AUTH_DB --local

# Apply migrations to remote Cloudflare staging
npx wrangler d1 migrations apply AUTH_DB --remote
```

### Option B: Single-Command SQL Bootstrap
```bash
npx wrangler d1 execute cashncarry-d1-staging --file=deploy/chatgpt-sites/staging-init-complete.sql --remote
```

---

## 3. Optional Secrets (Only When Enabling Features)

```bash
# Flutterwave sandbox/live secrets (leave unset or PAYMENTS_ENABLED=false until ready)
npx wrangler secret put FLW_SECRET_KEY
npx wrangler secret put FLW_WEBHOOK_HASH

# KYC R2 envelope encryption key (required when KYC_UPLOADS_ENABLED=true)
npx wrangler secret put KYC_DOCUMENT_KEY

# Cloudflare Stream WHIP/WHEP URLs (optional for live video broadcast)
npx wrangler secret put STREAM_WHIP_URL
npx wrangler secret put STREAM_WHEP_URL
```

---

## 4. Build, Verify & Deploy to Private Staging

```bash
# 1. TypeScript + Automated Suite + Worker Smoke Checks
npm run lint
npm test

# 2. Build Frontend + Worker Bundle + Package Verified Source ZIP
npm run build:sites-candidate

# 3. Validate Wrangler Bundle (Dry Run)
npx wrangler deploy --dry-run --outdir .wrangler-dry-run

# 4. Deploy ONLY to Private Staging
npx wrangler deploy --env staging
```

---

## 5. Verify Live Staging Endpoints

```bash
BASE="https://cashncarry-d1-staging-worker.cashncarry-workforce-2026.workers.dev"

# 1. Health & Staging Flag Status
curl -s "$BASE/api/health"

# 2. Categories & Products Catalog
curl -s "$BASE/api/categories"
curl -s "$BASE/api/products"

# 3. Verify Payments & Coins Fail Closed (HTTP 503)
curl -i -X POST "$BASE/api/payments/initialize"
curl -i -X POST "$BASE/api/coins" -H "Content-Type: application/json" -d '{"action":"credit","amount":500}'
```
