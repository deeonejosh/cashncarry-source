# Cash N Carry integrated staging source — verification report

Date: 2026-11-15
Input: `cash-n-carry (2).zip`

## Verified by direct file inspection
- Android project extracted from root of uploaded archive.
- Cloudflare web/Worker project extracted from `public/assets/aistudio/Cash-N-Carry-Web-Integrated-Cloudflare.zip`.
- Cloudflare Wrangler config: `web/wrangler.jsonc`, staging Worker `cashncarry-d1-staging-worker`, D1 `cashncarry-d1-staging` (database ID `9a2cdbee-e030-4b10-908b-b10b8142d2aa`).
- Staging variables: PAYMENTS_ENABLED=false, COINS_PURCHASES_ENABLED=false, KYC_UPLOADS_ENABLED=false, FLW_MODE=disabled.
- Existing web `dist/_worker.js` is present (151082 bytes), but not rebuilt or verified.
- Migration `0011_unified_mobile_sync.sql` is present. Remote D1 migration history was NOT checked; no migration applied.
- Zero case-insensitive `firebase` matches in Android `app/src/main`, `gradle`, root and app Gradle files searched.
- Android `applicationId` is `com.aistudio.cashncarry.vqmzkw` and signingConfigs are defined.
- Android `app/src/test` includes Robolectric and Cloudflare repository tests.

## Blockers / not yet verified
- `npm install --legacy-peer-deps --no-audit --no-fund` timed out; lint, tests, build and Worker bundle could not run.
- No `gradlew` or `debug.keystore` exists in extracted archive. Do not fabricate or alter signing material.
- Remote D1 backup, migrations, live authentication, and staging deployment were NOT performed.
- No GitHub commits, CI pass, or APK artifact were produced.

## Safety
- Production was not touched.
- Staging payment and KYC flags were not changed.
- No remote database writes or Worker deployments were made.
