package com.example.data.remote

import com.example.data.model.Livestream
import com.example.data.model.MarketplaceOrder
import com.example.data.model.Product
import com.example.data.model.SellerStorefront
import com.example.data.model.ShortVideo
import com.example.data.model.WishlistItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class CloudflareSyncRepository(
    private val storage: SessionStorage,
    private val baseUrl: String = CloudflareEndpoints.STAGING_BASE_URL,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val normalizedBase = baseUrl.trimEnd('/')
    private val tokenHexRegex = Regex("^[a-f0-9]{64}$", RegexOption.IGNORE_CASE)
    private val emailRegex = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")

    fun currentSessionSnapshot(): CloudflareSessionSnapshot {
        val token = storage.getToken()
        val cookie = storage.getSessionCookie()
        val hasCredential = !token.isNullOrBlank() || !cookie.isNullOrBlank()
        return CloudflareSessionSnapshot(
            signedIn = hasCredential && storage.getUserId().isNotBlank(),
            userId = storage.getUserId(),
            email = storage.getEmail(),
            role = storage.getRole(),
            displayName = storage.getDisplayName(),
            bio = storage.getBio(),
            selectedState = storage.getSelectedState(),
            hasCookieSession = !cookie.isNullOrBlank(),
            hasBearerToken = !token.isNullOrBlank()
        )
    }

    fun currentStagingFlags(): StagingFeatureFlags = storage.getStagingFlags()

    suspend fun fetchHealth(): CloudflareHealthSnapshot = withContext(Dispatchers.IO) {
        try {
            val req = newRequestBuilder("/api/health").get().build()
            client.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful || raw.isBlank()) {
                    return@withContext CloudflareHealthSnapshot(
                        ok = false,
                        staging = storage.getStagingFlags(),
                        error = "Health check HTTP ${res.code}"
                    )
                }
                val obj = JSONObject(raw)
                val stagingObj = obj.optJSONObject("staging") ?: JSONObject()
                val flags = StagingFeatureFlags(
                    paymentsEnabled = stagingObj.optBoolean("paymentsEnabled", false),
                    coinsPurchasesEnabled = stagingObj.optBoolean("coinsPurchasesEnabled", false),
                    kycUploadsEnabled = stagingObj.optBoolean("kycUploadsEnabled", false),
                    orderReservationsEnabled = stagingObj.optBoolean("orderReservationsEnabled", true),
                    streamConfigured = stagingObj.optBoolean("streamConfigured", false),
                    r2Configured = stagingObj.optBoolean("r2Configured", false)
                )
                storage.saveStagingFlags(flags)
                CloudflareHealthSnapshot(
                    ok = obj.optBoolean("ok", false),
                    service = obj.optString("service", "cashncarry-d1-staging-worker"),
                    environment = obj.optString("environment", "staging"),
                    dbConnected = obj.optBoolean("dbConnected", false),
                    authDbConnected = obj.optBoolean("authDbConnected", false),
                    authenticated = obj.optBoolean("authenticated", false),
                    staging = flags
                )
            }
        } catch (t: Throwable) {
            CloudflareHealthSnapshot(
                ok = false,
                staging = storage.getStagingFlags(),
                error = t.message ?: "Unable to reach staging worker"
            )
        }
    }

    suspend fun registerAccount(email: String): CloudflareResult<String> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.length > 254 || !emailRegex.matches(cleanEmail)) {
            return@withContext CloudflareResult.Failure(400, "INVALID_EMAIL", "Please enter a valid email address.")
        }
        val payload = JSONObject().put("email", cleanEmail).toString()
        when (val res = executeJson("POST", "/api/auth/register", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(
                "If this address can register, a verification link and token have been sent."
            )
        }
    }

    suspend fun verifyEmailAndSetPassword(
        token: String,
        password: String,
        role: String = "buyer"
    ): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val cleanToken = token.trim().lowercase()
        if (!tokenHexRegex.matches(cleanToken)) {
            return@withContext CloudflareResult.Failure(400, "INVALID_TOKEN", "Enter the 64-character verification token from your email.")
        }
        if (password.length < CloudflareEndpoints.MIN_PASSWORD_LENGTH || password.length > CloudflareEndpoints.MAX_PASSWORD_LENGTH) {
            return@withContext CloudflareResult.Failure(400, "INVALID_PASSWORD", "Password must be between 12 and 128 characters.")
        }
        val safeRole = if (role.equals("seller", ignoreCase = true)) "seller" else "buyer"
        val payload = JSONObject()
            .put("token", cleanToken)
            .put("password", password)
            .put("role", safeRole)
            .toString()

        when (val res = executeJson("POST", "/api/auth/verify", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(res.data.optBoolean("completed", true))
        }
    }

    suspend fun signInWithPassword(
        email: String,
        password: String
    ): CloudflareResult<CloudflareSessionSnapshot> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (!emailRegex.matches(cleanEmail)) {
            return@withContext CloudflareResult.Failure(400, "INVALID_EMAIL", "Enter a valid email address.")
        }
        if (password.length < CloudflareEndpoints.MIN_PASSWORD_LENGTH || password.length > CloudflareEndpoints.MAX_PASSWORD_LENGTH) {
            return@withContext CloudflareResult.Failure(400, "INVALID_PASSWORD", "Password must be at least 12 characters.")
        }

        val payload = JSONObject()
            .put("email", cleanEmail)
            .put("password", password)
            .toString()

        when (val res = executeJsonWithHeaders("POST", "/api/auth/login", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val (obj, setCookies) = res.data
                val signedIn = obj.optBoolean("signedIn", false)
                val token = obj.optString("token", "").takeIf { tokenHexRegex.matches(it) }
                val cookieValue = extractSessionCookie(setCookies)?.takeIf { tokenHexRegex.matches(it) }
                val userObj = obj.optJSONObject("user") ?: JSONObject()
                val userId = userObj.optString("id", "")
                val userEmail = userObj.optString("email", cleanEmail).ifBlank { cleanEmail }
                val role = userObj.optString("role", "buyer").lowercase()

                if (!signedIn || role !in setOf("buyer", "seller") || userId.isBlank() || (token == null && cookieValue == null)) {
                    storage.clearSession()
                    return@withContext CloudflareResult.Failure(
                        statusCode = 403,
                        code = "MOBILE_AUTH_REJECTED",
                        message = "Mobile sign-in requires a verified buyer or seller account."
                    )
                }

                try {
                    storage.saveSession(
                        token = token,
                        sessionCookie = cookieValue,
                        userId = userId,
                        email = userEmail,
                        role = if (role == "seller") "seller" else "buyer"
                    )
                } catch (_: IllegalStateException) {
                    storage.clearSession()
                    return@withContext CloudflareResult.Failure(
                        503, "SECURE_STORAGE_UNAVAILABLE", "Secure session storage is unavailable on this device"
                    )
                }
                fetchProfile()
                CloudflareResult.Success(currentSessionSnapshot())
            }
        }
    }

    suspend fun restoreSession(): CloudflareResult<CloudflareSessionSnapshot> = withContext(Dispatchers.IO) {
        val existingToken = storage.getToken()
        val existingCookie = storage.getSessionCookie()
        if (existingToken.isNullOrBlank() && existingCookie.isNullOrBlank()) {
            return@withContext CloudflareResult.Failure(401, "NO_SESSION", "No saved session")
        }

        when (val res = executeJson("GET", "/api/auth/me", null)) {
            is CloudflareResult.Failure -> {
                if (res.statusCode == 401 || res.statusCode == 403) {
                    storage.clearSession()
                }
                res
            }
            is CloudflareResult.Success -> {
                val obj = res.data
                // The Worker returns {"user": {...}} for a verified session.
                // Accept the explicit authenticated flag when present, but never
                // infer authentication from cached identifiers alone.
                val liveUser = obj.optJSONObject("user")
                val authenticated = obj.optBoolean("authenticated", liveUser != null)
                val userObj = liveUser ?: JSONObject()
                val userId = userObj.optString("id", "")
                val userEmail = userObj.optString("email", "")
                val role = userObj.optString("role", "").lowercase()

                if (!authenticated || liveUser == null || role !in setOf("buyer", "seller") || userId.isBlank() || userEmail.isBlank()) {
                    storage.clearSession()
                    return@withContext CloudflareResult.Failure(401, "SESSION_EXPIRED", "Session expired. Please sign in again.")
                }

                storage.saveSession(
                    token = existingToken,
                    sessionCookie = existingCookie,
                    userId = userId,
                    email = userEmail,
                    role = if (role == "seller") "seller" else "buyer"
                )
                fetchProfile()
                CloudflareResult.Success(currentSessionSnapshot())
            }
        }
    }

    suspend fun requestPasswordReset(email: String): CloudflareResult<String> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.length > 254 || !emailRegex.matches(cleanEmail)) {
            return@withContext CloudflareResult.Failure(400, "INVALID_EMAIL", "Enter a valid email address.")
        }
        val payload = JSONObject().put("email", cleanEmail).toString()
        when (val res = executeJson("POST", "/api/auth/request-reset", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(
                "If this account exists and is verified, a password reset email has been sent."
            )
        }
    }

    suspend fun resetPassword(
        token: String,
        newPassword: String
    ): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val cleanToken = token.trim().lowercase()
        if (!tokenHexRegex.matches(cleanToken)) {
            return@withContext CloudflareResult.Failure(400, "INVALID_TOKEN", "Enter a valid 64-character reset token.")
        }
        if (newPassword.length < CloudflareEndpoints.MIN_PASSWORD_LENGTH || newPassword.length > CloudflareEndpoints.MAX_PASSWORD_LENGTH) {
            return@withContext CloudflareResult.Failure(400, "INVALID_PASSWORD", "New password must be between 12 and 128 characters.")
        }
        val payload = JSONObject()
            .put("token", cleanToken)
            .put("password", newPassword)
            .toString()

        when (val res = executeJson("POST", "/api/auth/reset", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                storage.clearSession()
                CloudflareResult.Success(res.data.optBoolean("completed", true))
            }
        }
    }

    suspend fun signOut(): Unit = withContext(Dispatchers.IO) {
        runCatching {
            executeJson("POST", "/api/auth/logout", "{}")
        }
        storage.clearSession()
    }

    suspend fun fetchProfile(): CloudflareResult<CloudflareSessionSnapshot> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/v1/profile", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val profile = res.data.optJSONObject("profile") ?: res.data
                val displayName = profile.optString("display_name", "")
                val bio = profile.optString("bio", "")
                val state = profile.optString("selected_state", "Lagos").ifBlank { "Lagos" }
                storage.saveProfileMetadata(displayName, bio, state)
                CloudflareResult.Success(currentSessionSnapshot())
            }
        }
    }

    suspend fun updateProfile(
        displayName: String,
        bio: String,
        avatarUrl: String,
        selectedState: String
    ): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("displayName", displayName.trim())
            .put("bio", bio.trim())
            .put("avatarUrl", avatarUrl.trim())
            .put("selectedState", selectedState.trim())
            .toString()

        when (val res = executeJson("PUT", "/api/v1/profile", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                storage.saveProfileMetadata(displayName.trim(), bio.trim(), selectedState.trim())
                CloudflareResult.Success(res.data.optBoolean("updated", true))
            }
        }
    }

    suspend fun fetchCatalogProducts(): CloudflareResult<List<Product>> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/products", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val arr = res.data.optJSONArray("products") ?: JSONArray()
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val priceKoboOrNaira = obj.optLong("price_naira", obj.optLong("priceNaira", 0L))
                        val origPrice = obj.optLong("original_price_naira", priceKoboOrNaira)
                        add(
                            Product(
                                id = obj.optString("id"),
                                sellerId = obj.optString("seller_id", obj.optString("sellerId", "")),
                                sellerName = obj.optString("seller_name", obj.optString("sellerName", "Verified Seller")),
                                title = obj.optString("title", "Marketplace Item"),
                                description = obj.optString("description", ""),
                                category = obj.optString("category", "Electronics"),
                                brand = obj.optString("brand", "CashNCarry"),
                                priceNaira = priceKoboOrNaira.coerceAtLeast(100L),
                                originalPriceNaira = origPrice.coerceAtLeast(priceKoboOrNaira),
                                stockCount = obj.optLong("stock", obj.optLong("stockCount", 10L)),
                                rating = obj.optDouble("rating", 4.8),
                                reviewCount = obj.optLong("review_count", 12L),
                                imageKey = obj.optString("image_key", "hero_marketplace"),
                                status = obj.optString("status", "active")
                            )
                        )
                    }
                }
                CloudflareResult.Success(list)
            }
        }
    }

    suspend fun fetchStorefronts(): CloudflareResult<List<SellerStorefront>> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/storefronts", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val arr = res.data.optJSONArray("storefronts") ?: JSONArray()
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        add(
                            SellerStorefront(
                                id = obj.optString("id"),
                                ownerId = obj.optString("owner_id", obj.optString("id")),
                                businessName = obj.optString("business_name", obj.optString("name", "Cash N Carry Seller")),
                                tagline = obj.optString("tagline", "Verified Nigerian Marketplace Vendor"),
                                stateLocation = obj.optString("state", "Lagos"),
                                verified = obj.optInt("verified", 0) == 1 || obj.optBoolean("verified", false),
                                rating = obj.optDouble("rating", 4.8),
                                followersCount = obj.optLong("followers_count", 0L),
                                status = obj.optString("status", "active")
                            )
                        )
                    }
                }
                CloudflareResult.Success(list)
            }
        }
    }

    suspend fun fetchLivestreams(): CloudflareResult<List<Livestream>> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/v1/live", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val arr = res.data.optJSONArray("rooms") ?: JSONArray()
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        add(
                            Livestream(
                                id = obj.optString("room_id"),
                                sellerId = obj.optString("seller_id"),
                                sellerName = obj.optString("seller_name", "Live Seller"),
                                title = obj.optString("title", "Live Showcase"),
                                category = obj.optString("category", "Fashion"),
                                status = obj.optString("status", "live"),
                                viewerCount = obj.optLong("viewer_count", 0L),
                                likesCount = obj.optLong("hearts_count", 0L),
                                pinnedProductId = obj.optString("pinned_product_id", "")
                            )
                        )
                    }
                }
                CloudflareResult.Success(list)
            }
        }
    }

    suspend fun fetchVideos(): CloudflareResult<List<ShortVideo>> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/v1/videos", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val arr = res.data.optJSONArray("videos") ?: JSONArray()
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        add(
                            ShortVideo(
                                id = obj.optString("id"),
                                sellerId = obj.optString("seller_id"),
                                sellerName = obj.optString("seller_name", "Creator"),
                                title = obj.optString("title", "Shoppable Video"),
                                caption = obj.optString("caption", ""),
                                productId = obj.optString("product_id", ""),
                                likesCount = obj.optLong("likes_count", 0L),
                                commentsCount = obj.optLong("comments_count", 0L)
                            )
                        )
                    }
                }
                CloudflareResult.Success(list)
            }
        }
    }

    suspend fun fetchWishlist(): CloudflareResult<List<WishlistItem>> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/v1/wishlist", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val arr = res.data.optJSONArray("items") ?: JSONArray()
                val userId = storage.getUserId()
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val pid = obj.optString("product_id", obj.optString("productId"))
                        if (pid.isBlank()) continue
                        add(
                            WishlistItem(
                                id = pid,
                                userId = userId,
                                productId = pid,
                                productTitle = obj.optString("title", "Saved Item"),
                                priceNaira = obj.optLong("price_naira", 0L),
                                sellerName = obj.optString("seller_name", "Seller"),
                                imageKey = "hero_marketplace"
                            )
                        )
                    }
                }
                CloudflareResult.Success(list)
            }
        }
    }

    suspend fun fetchFollows(): CloudflareResult<List<String>> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/v1/follows", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val arr = res.data.optJSONArray("sellerIds") ?: JSONArray()
                val ids = buildList {
                    for (i in 0 until arr.length()) {
                        val id = arr.optString(i)
                        if (id.isNotBlank()) add(id)
                    }
                }
                CloudflareResult.Success(ids)
            }
        }
    }

    suspend fun fetchOrders(): CloudflareResult<List<MarketplaceOrder>> = withContext(Dispatchers.IO) {
        when (val res = executeJson("GET", "/api/orders", null)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val arr = res.data.optJSONArray("orders") ?: JSONArray()
                val list = buildList {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        add(
                            MarketplaceOrder(
                                id = obj.optString("id"),
                                buyerId = obj.optString("buyer_id", storage.getUserId()),
                                sellerId = obj.optString("seller_id", ""),
                                sellerName = obj.optString("seller_name", "Verified Seller"),
                                itemsSummary = obj.optString("items_summary", "Order #${obj.optString("id")}"),
                                totalNaira = obj.optLong("total_naira", 0L),
                                deliveryState = obj.optString("delivery_state", "Lagos"),
                                deliveryAddress = obj.optString("delivery_address", ""),
                                paymentStatus = obj.optString("payment_status", "awaiting_payment"),
                                orderStatus = obj.optString("status", "awaiting_payment")
                            )
                        )
                    }
                }
                CloudflareResult.Success(list)
            }
        }
    }

    suspend fun updateCart(
        productId: String,
        quantity: Int,
        source: String = "replacement"
    ): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("id", productId)
            .put("quantity", quantity)
            .put("source", source)
            .toString()

        when (val res = executeJson("POST", "/api/cart", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(true)
        }
    }

    suspend fun checkoutCart(
        requestId: String,
        addressId: String
    ): CloudflareResult<String> = withContext(Dispatchers.IO) {
        if (!storage.getStagingFlags().paymentsEnabled) {
            return@withContext CloudflareResult.Failure(
                statusCode = 503,
                code = "PAYMENTS_DISABLED",
                message = "Checkout is disabled in staging while PAYMENTS_ENABLED=false"
            )
        }
        val payload = JSONObject()
            .put("request_id", requestId)
            .put("address_id", addressId)
            .toString()

        when (val res = executeJson("POST", "/api/checkout", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val orderId = res.data.optJSONObject("order")?.optString("id")
                    ?: res.data.optString("orderId", "")
                CloudflareResult.Success(orderId)
            }
        }
    }

    suspend fun initializePayment(orderId: String): CloudflareResult<String> = withContext(Dispatchers.IO) {
        if (!storage.getStagingFlags().paymentsEnabled) {
            return@withContext CloudflareResult.Failure(
                statusCode = 503,
                code = "PAYMENTS_DISABLED",
                message = "Payments are disabled in staging (PAYMENTS_ENABLED=false)"
            )
        }
        val payload = JSONObject().put("order_id", orderId).toString()
        when (val res = executeJson("POST", "/api/payments/initialize", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> {
                val checkoutUrl = res.data.optString("checkout_url", "")
                if (checkoutUrl.isBlank()) {
                    CloudflareResult.Failure(503, "PAYMENTS_DISABLED", "Payments temporarily unavailable")
                } else {
                    CloudflareResult.Success(checkoutUrl)
                }
            }
        }
    }

    suspend fun toggleWishlist(productId: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("productId", productId).toString()
        when (val res = executeJson("POST", "/api/v1/wishlist", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(res.data.optBoolean("wishlisted", true))
        }
    }

    suspend fun toggleFollowSeller(sellerId: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("sellerId", sellerId).toString()
        when (val res = executeJson("POST", "/api/v1/follows", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(res.data.optBoolean("following", true))
        }
    }

    suspend fun submitReview(productId: String, rating: Long, comment: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("productId", productId)
            .put("rating", rating.coerceIn(1L, 5L))
            .put("comment", comment.trim())
            .toString()
        when (val res = executeJson("POST", "/api/v1/reviews", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(true)
        }
    }

    suspend fun publishShortVideo(
        productId: String,
        title: String,
        caption: String
    ): CloudflareResult<String> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("productId", productId)
            .put("title", title.trim())
            .put("caption", caption.trim())
            .toString()
        when (val res = executeJson("POST", "/api/v1/videos", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(res.data.optString("id", ""))
        }
    }

    suspend fun likeVideo(videoId: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("videoId", videoId).toString()
        when (val res = executeJson("POST", "/api/v1/videos/like", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(true)
        }
    }

    suspend fun commentVideo(videoId: String, body: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("videoId", videoId)
            .put("body", body.trim())
            .toString()
        when (val res = executeJson("POST", "/api/v1/videos/comments", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(true)
        }
    }

    suspend fun sendLiveComment(roomId: String, body: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("roomId", roomId)
            .put("body", body.trim())
            .toString()
        when (val res = executeJson("POST", "/api/v1/live/comments", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(true)
        }
    }

    suspend fun createLivestream(title: String, category: String, pinnedProductId: String?): CloudflareResult<String> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("title", title.trim())
            .put("category", category)
            .put("pinnedProductId", pinnedProductId.orEmpty())
            .toString()
        when (val res = executeJson("POST", "/api/v1/live", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(res.data.optString("roomId", ""))
        }
    }

    suspend fun endLivestream(roomId: String): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("roomId", roomId)
            .put("status", "ended")
            .toString()
        when (val res = executeJson("PATCH", "/api/v1/live", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(true)
        }
    }

    suspend fun fulfilSellerOrder(orderId: String, status: String, trackingNumber: String = ""): CloudflareResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("orderId", orderId)
            .put("status", status)
            .put("trackingNumber", trackingNumber)
            .toString()
        when (val res = executeJson("POST", "/api/v1/seller/orders/fulfil", payload)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(true)
        }
    }

    private fun extractSessionCookie(setCookieHeaders: List<String>): String? {
        val prefix = "${CloudflareEndpoints.SESSION_COOKIE_NAME}="
        for (header in setCookieHeaders) {
            val idx = header.indexOf(prefix)
            if (idx >= 0) {
                val afterPrefix = header.substring(idx + prefix.length)
                val endIdx = afterPrefix.indexOf(';')
                val rawVal = (if (endIdx >= 0) afterPrefix.substring(0, endIdx) else afterPrefix).trim()
                if (rawVal.isNotBlank()) return rawVal
            }
        }
        return null
    }

    private fun newRequestBuilder(path: String): Request.Builder {
        val builder = Request.Builder()
            .url("$normalizedBase$path")
            .header(CloudflareEndpoints.CLIENT_TYPE_HEADER, CloudflareEndpoints.CLIENT_TYPE_MOBILE)
            .header("Accept", "application/json")
        val token = storage.getToken()
        val cookie = storage.getSessionCookie()
        if (!token.isNullOrBlank()) {
            // Worker rejects requests carrying both Bearer and ambient cookies together
            builder.header("Authorization", "Bearer $token")
        } else if (!cookie.isNullOrBlank()) {
            builder.header("Cookie", "${CloudflareEndpoints.SESSION_COOKIE_NAME}=$cookie")
        }
        return builder
    }

    private fun executeJson(
        method: String,
        path: String,
        jsonBody: String?
    ): CloudflareResult<JSONObject> {
        return when (val res = executeJsonWithHeaders(method, path, jsonBody)) {
            is CloudflareResult.Failure -> res
            is CloudflareResult.Success -> CloudflareResult.Success(res.data.first)
        }
    }

    private fun executeJsonWithHeaders(
        method: String,
        path: String,
        jsonBody: String?
    ): CloudflareResult<Pair<JSONObject, List<String>>> {
        return try {
            val builder = newRequestBuilder(path)
            when (method) {
                "GET" -> builder.get()
                "POST" -> builder.post((jsonBody ?: "{}").toRequestBody(jsonMediaType))
                "PUT" -> builder.put((jsonBody ?: "{}").toRequestBody(jsonMediaType))
                "PATCH" -> builder.patch((jsonBody ?: "{}").toRequestBody(jsonMediaType))
                "DELETE" -> builder.delete((jsonBody ?: "{}").toRequestBody(jsonMediaType))
                else -> builder.method(method, jsonBody?.toRequestBody(jsonMediaType))
            }
            client.newCall(builder.build()).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val contentType = res.header("Content-Type").orEmpty()
                val parsed = runCatching {
                    if (raw.isNotBlank()) JSONObject(raw) else JSONObject()
                }
                if (res.isSuccessful && (!contentType.contains("json", ignoreCase = true) || parsed.isFailure || raw.isBlank())) {
                    return CloudflareResult.Failure(
                        statusCode = res.code,
                        code = "INVALID_RESPONSE",
                        message = "Cloudflare returned a non-JSON or empty API response"
                    )
                }
                val obj = parsed.getOrDefault(JSONObject())

                if (!res.isSuccessful) {
                    return CloudflareResult.Failure(
                        statusCode = res.code,
                        code = obj.optString("code", "HTTP_${res.code}"),
                        message = obj.optString("error", "Request failed (${res.code})")
                    )
                }
                CloudflareResult.Success(obj to res.headers.values("Set-Cookie"))
            }
        } catch (t: Throwable) {
            CloudflareResult.Failure(
                statusCode = 0,
                code = "NETWORK_ERROR",
                message = t.message ?: "Network error communicating with Cloudflare Worker"
            )
        }
    }
}
