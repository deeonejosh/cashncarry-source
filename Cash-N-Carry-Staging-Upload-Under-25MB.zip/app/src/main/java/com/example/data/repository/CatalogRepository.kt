package com.example.data.repository

import com.example.data.model.CartItem
import com.example.data.model.MarketplaceOrder
import com.example.data.model.Product
import com.example.data.model.ProductReview
import com.example.data.model.SellerStorefront
import com.example.data.model.UserPrivateInfo
import com.example.data.model.UserProfile
import com.example.data.model.WishlistItem
import com.example.data.remote.CloudflareResult
import com.example.data.remote.CloudflareSyncRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import java.util.UUID

class CatalogRepository(
    private val syncRepo: CloudflareSyncRepository? = null
) {
    private val _products = MutableStateFlow<List<Product>>(emptyList())
    private val _sellers = MutableStateFlow<List<SellerStorefront>>(emptyList())
    private val _reviewsByProduct = MutableStateFlow<Map<String, List<ProductReview>>>(emptyMap())
    private val _profilesByUser = MutableStateFlow<Map<String, UserProfile>>(emptyMap())
    private val _privateInfoByUser = MutableStateFlow<Map<String, UserPrivateInfo>>(emptyMap())
    private val _cartByUser = MutableStateFlow<Map<String, List<CartItem>>>(emptyMap())
    private val _wishlistByUser = MutableStateFlow<Map<String, List<WishlistItem>>>(emptyMap())
    private val _orders = MutableStateFlow<List<MarketplaceOrder>>(emptyList())

    fun observeActiveProducts(): Flow<List<Product>> =
        _products.map { list -> list.filter { it.status == "active" } }

    fun observeSellerProducts(sellerId: String): Flow<List<Product>> =
        _products.map { list -> list.filter { it.sellerId == sellerId } }

    fun observeActiveSellers(): Flow<List<SellerStorefront>> =
        _sellers.map { list -> list.filter { it.status == "active" } }

    fun observeProductReviews(productId: String): Flow<List<ProductReview>> =
        _reviewsByProduct.map { map -> map[productId].orEmpty().filter { it.visibility == "public" } }

    fun observeUserProfile(userId: String): Flow<UserProfile?> =
        _profilesByUser.map { it[userId] }

    fun observeUserPrivateInfo(userId: String): Flow<UserPrivateInfo?> =
        _privateInfoByUser.map { it[userId] }

    fun observeCart(userId: String): Flow<List<CartItem>> =
        _cartByUser.map { it[userId].orEmpty() }

    fun observeWishlist(userId: String): Flow<List<WishlistItem>> =
        _wishlistByUser.map { it[userId].orEmpty() }

    fun observeBuyerOrders(buyerId: String): Flow<List<MarketplaceOrder>> =
        _orders.map { list -> list.filter { it.buyerId == buyerId }.sortedByDescending { it.createdAtEpochMs } }

    fun observeSellerOrders(sellerId: String): Flow<List<MarketplaceOrder>> =
        _orders.map { list -> list.filter { it.sellerId == sellerId }.sortedByDescending { it.createdAtEpochMs } }

    suspend fun ensureUserInitialized(
        userId: String,
        displayName: String,
        email: String
    ): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        val snap = syncRepo?.currentSessionSnapshot()
        val existing = _profilesByUser.value[userId]
        if (existing == null) {
            val profile = UserProfile(
                id = userId,
                userId = userId,
                displayName = snap?.displayName?.ifBlank { displayName } ?: displayName.ifBlank { "Shopper" },
                bio = snap?.bio?.ifBlank { "Social shopper on Cash N Carry Nigeria." }
                    ?: "Social shopper on Cash N Carry Nigeria.",
                selectedState = snap?.selectedState?.ifBlank { "Lagos" } ?: "Lagos",
                role = snap?.role ?: "buyer",
                createdAtEpochMs = now,
                updatedAtEpochMs = now
            )
            _profilesByUser.value = _profilesByUser.value + (userId to profile)
        }
        if (_privateInfoByUser.value[userId] == null) {
            _privateInfoByUser.value = _privateInfoByUser.value + (
                userId to UserPrivateInfo(
                    id = userId,
                    userId = userId,
                    email = email.take(160),
                    shippingState = snap?.selectedState?.ifBlank { "Lagos" } ?: "Lagos",
                    createdAtEpochMs = now,
                    updatedAtEpochMs = now
                )
            )
        }
        syncFromCloudflare(userId)
        Unit
    }

    suspend fun syncFromCloudflare(userId: String) {
        val remote = syncRepo ?: return
        when (val prodRes = remote.fetchCatalogProducts()) {
            is CloudflareResult.Success -> if (prodRes.data.isNotEmpty()) {
                _products.value = prodRes.data
            }
            is CloudflareResult.Failure -> Unit
        }
        when (val sellerRes = remote.fetchStorefronts()) {
            is CloudflareResult.Success -> if (sellerRes.data.isNotEmpty()) {
                _sellers.value = sellerRes.data
            }
            is CloudflareResult.Failure -> Unit
        }
        when (val profRes = remote.fetchProfile()) {
            is CloudflareResult.Success -> {
                val cur = _profilesByUser.value[userId] ?: UserProfile(id = userId, userId = userId)
                _profilesByUser.value = _profilesByUser.value + (
                    userId to cur.copy(
                        displayName = profRes.data.displayName.ifBlank { cur.displayName },
                        bio = profRes.data.bio.ifBlank { cur.bio },
                        selectedState = profRes.data.selectedState.ifBlank { cur.selectedState },
                        role = profRes.data.role
                    )
                )
            }
            is CloudflareResult.Failure -> Unit
        }
        when (val wishRes = remote.fetchWishlist()) {
            is CloudflareResult.Success -> {
                _wishlistByUser.value = _wishlistByUser.value + (userId to wishRes.data)
            }
            is CloudflareResult.Failure -> Unit
        }
        when (val followRes = remote.fetchFollows()) {
            is CloudflareResult.Success -> {
                val cur = _profilesByUser.value[userId] ?: UserProfile(id = userId, userId = userId)
                _profilesByUser.value = _profilesByUser.value + (
                    userId to cur.copy(followingSellerIds = followRes.data)
                )
            }
            is CloudflareResult.Failure -> Unit
        }
        when (val orderRes = remote.fetchOrders()) {
            is CloudflareResult.Success -> if (orderRes.data.isNotEmpty()) {
                _orders.value = orderRes.data
            }
            is CloudflareResult.Failure -> Unit
        }
    }

    suspend fun updateUserProfileDetails(
        userId: String,
        displayName: String,
        bio: String,
        avatarKey: String
    ): Result<Unit> = runCatching {
        val current = _profilesByUser.value[userId] ?: UserProfile(id = userId, userId = userId)
        val cleanName = displayName.trim().ifBlank { "Shopper" }.take(80)
        val cleanBio = bio.trim().take(240)
        val cleanAvatar = avatarKey.trim().ifBlank { "seller_banner" }.take(400)
        _profilesByUser.value = _profilesByUser.value + (
            userId to current.copy(
                displayName = cleanName,
                bio = cleanBio,
                avatarKey = cleanAvatar,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        )
        val remoteRes = syncRepo?.updateProfile(
            displayName = cleanName,
            bio = cleanBio,
            avatarUrl = cleanAvatar,
            selectedState = current.selectedState
        )
        if (remoteRes is CloudflareResult.Failure && remoteRes.statusCode in 400..499) {
            throw IllegalStateException(remoteRes.message)
        }
        Unit
    }

    suspend fun updateSelectedState(userId: String, state: String): Result<Unit> = runCatching {
        val current = _profilesByUser.value[userId] ?: UserProfile(id = userId, userId = userId)
        _profilesByUser.value = _profilesByUser.value + (
            userId to current.copy(selectedState = state, updatedAtEpochMs = System.currentTimeMillis())
        )
        syncRepo?.updateProfile(
            displayName = current.displayName,
            bio = current.bio,
            avatarUrl = current.avatarKey,
            selectedState = state
        )
        Unit
    }

    suspend fun recordRecentlyViewed(
        userId: String,
        currentRecent: List<String>,
        productId: String
    ): Result<Unit> = runCatching {
        val updated = (listOf(productId) + currentRecent.filterNot { it == productId }).take(12)
        val current = _profilesByUser.value[userId] ?: UserProfile(id = userId, userId = userId)
        _profilesByUser.value = _profilesByUser.value + (
            userId to current.copy(recentProductIds = updated, updatedAtEpochMs = System.currentTimeMillis())
        )
        Unit
    }

    suspend fun toggleFollowSeller(
        userId: String,
        sellerId: String,
        currentlyFollowing: List<String>
    ): Result<Boolean> = runCatching {
        val rawOwnerId = sellerId.removePrefix("seller_")
        val isFollowing = currentlyFollowing.contains(rawOwnerId) || currentlyFollowing.contains(sellerId)
        val updated = if (isFollowing) {
            currentlyFollowing.filterNot { it == rawOwnerId || it == sellerId }
        } else {
            (currentlyFollowing + rawOwnerId).distinct().take(190)
        }
        val current = _profilesByUser.value[userId] ?: UserProfile(id = userId, userId = userId)
        _profilesByUser.value = _profilesByUser.value + (
            userId to current.copy(followingSellerIds = updated, updatedAtEpochMs = System.currentTimeMillis())
        )
        _sellers.value = _sellers.value.map { seller ->
            if (seller.id == sellerId || seller.ownerId == rawOwnerId) {
                val delta = if (isFollowing) -1L else 1L
                seller.copy(followersCount = (seller.followersCount + delta).coerceAtLeast(0L))
            } else {
                seller
            }
        }
        syncRepo?.toggleFollowSeller(rawOwnerId)
        !isFollowing
    }

    suspend fun saveShippingAndPaymentSetup(
        userId: String,
        phone: String,
        address: String,
        state: String
    ): Result<Unit> = runCatching {
        val current = _privateInfoByUser.value[userId] ?: UserPrivateInfo(id = userId, userId = userId)
        _privateInfoByUser.value = _privateInfoByUser.value + (
            userId to current.copy(
                phone = phone.trim().take(30),
                shippingAddress = address.trim().take(300),
                shippingState = state,
                savedPaymentReady = true,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        )
        Unit
    }

    suspend fun addToCart(
        userId: String,
        product: Product,
        variantLabel: String,
        quantity: Long = 1L
    ): Result<Unit> = runCatching {
        val docId = "${product.id}_${variantLabel.replace(Regex("[^a-zA-Z0-9_-]"), "_")}".take(120)
        val currentCart = _cartByUser.value[userId].orEmpty().toMutableList()
        val existingIdx = currentCart.indexOfFirst { it.id == docId }
        val now = System.currentTimeMillis()
        if (existingIdx >= 0) {
            val prev = currentCart[existingIdx]
            currentCart[existingIdx] = prev.copy(
                quantity = (prev.quantity + quantity).coerceAtMost(99L),
                unitPriceNaira = product.priceNaira,
                updatedAtEpochMs = now
            )
        } else {
            currentCart.add(
                CartItem(
                    id = docId,
                    userId = userId,
                    productId = product.id,
                    sellerId = product.sellerId,
                    sellerName = product.sellerName,
                    productTitle = product.title,
                    variantLabel = variantLabel.ifBlank { "Standard" },
                    unitPriceNaira = product.priceNaira,
                    quantity = quantity.coerceIn(1L, 99L),
                    imageKey = product.imageKey,
                    createdAtEpochMs = now,
                    updatedAtEpochMs = now
                )
            )
        }
        _cartByUser.value = _cartByUser.value + (userId to currentCart)
        syncRepo?.updateCart(product.id, quantity.toInt())
        Unit
    }

    suspend fun updateCartQuantity(userId: String, cartItemId: String, newQty: Long): Result<Unit> = runCatching {
        val currentCart = _cartByUser.value[userId].orEmpty()
        val target = currentCart.find { it.id == cartItemId }
        val updated = if (newQty <= 0L) {
            currentCart.filterNot { it.id == cartItemId }
        } else {
            currentCart.map {
                if (it.id == cartItemId) it.copy(quantity = newQty.coerceAtMost(99L)) else it
            }
        }
        _cartByUser.value = _cartByUser.value + (userId to updated)
        if (target != null) {
            syncRepo?.updateCart(target.productId, newQty.toInt().coerceAtLeast(0))
        }
        Unit
    }

    suspend fun toggleWishlist(userId: String, product: Product, isSaved: Boolean): Result<Boolean> = runCatching {
        val current = _wishlistByUser.value[userId].orEmpty()
        val next = if (isSaved) {
            current.filterNot { it.productId == product.id }
        } else {
            current + WishlistItem(
                id = product.id,
                userId = userId,
                productId = product.id,
                productTitle = product.title,
                priceNaira = product.priceNaira,
                sellerName = product.sellerName,
                imageKey = product.imageKey,
                createdAtEpochMs = System.currentTimeMillis()
            )
        }
        _wishlistByUser.value = _wishlistByUser.value + (userId to next)
        syncRepo?.toggleWishlist(product.id)
        !isSaved
    }

    suspend fun submitReview(
        userId: String,
        userName: String,
        productId: String,
        rating: Long,
        comment: String
    ): Result<Unit> = runCatching {
        val review = ProductReview(
            id = "rev_${UUID.randomUUID().toString().take(10)}",
            productId = productId,
            userId = userId,
            userName = userName.ifBlank { "Verified Buyer" },
            rating = rating.coerceIn(1L, 5L),
            comment = comment.trim().take(500),
            visibility = "public",
            createdAtEpochMs = System.currentTimeMillis()
        )
        val cur = _reviewsByProduct.value[productId].orEmpty()
        _reviewsByProduct.value = _reviewsByProduct.value + (productId to (listOf(review) + cur))
        syncRepo?.submitReview(productId, rating, comment)
        Unit
    }

    suspend fun checkoutCartWithFlutterwave(
        userId: String,
        cartItems: List<CartItem>,
        deliveryState: String,
        deliveryAddress: String,
        paymentMethod: String,
        sourceType: String = "marketplace"
    ): Result<List<String>> = runCatching {
        require(cartItems.isNotEmpty()) { "Cart is empty" }
        val paymentsEnabled = syncRepo?.currentStagingFlags()?.paymentsEnabled ?: false
        if (!paymentsEnabled) {
            val idemReq = "req_${UUID.randomUUID().toString().take(12)}"
            val remoteCheckout = syncRepo?.checkoutCart(idemReq, deliveryAddress)
            if (remoteCheckout is CloudflareResult.Success && remoteCheckout.data.isNotBlank()) {
                val now = System.currentTimeMillis()
                val order = MarketplaceOrder(
                    id = remoteCheckout.data,
                    idempotencyKey = idemReq,
                    buyerId = userId,
                    sellerId = cartItems.first().sellerId,
                    sellerName = cartItems.first().sellerName,
                    itemsSummary = cartItems.joinToString(", ") { "${it.quantity}x ${it.productTitle}" },
                    totalNaira = cartItems.sumOf { it.unitPriceNaira * it.quantity },
                    deliveryState = deliveryState,
                    deliveryAddress = deliveryAddress,
                    paymentMethod = paymentMethod,
                    paymentReference = "STAGING-RESERVED-${remoteCheckout.data.take(8)}",
                    paymentStatus = "awaiting_payment",
                    orderStatus = "awaiting_payment",
                    sourceType = sourceType,
                    createdAtEpochMs = now,
                    updatedAtEpochMs = now
                )
                _orders.value = listOf(order) + _orders.value
                _cartByUser.value = _cartByUser.value + (userId to emptyList())
                return@runCatching listOf(remoteCheckout.data)
            }
            throw IllegalStateException("Checkout payment failed closed: PAYMENTS_ENABLED=false in staging.")
        }

        val idemReq = "req_${UUID.randomUUID().toString().take(12)}"
        val orderRes = syncRepo?.checkoutCart(idemReq, deliveryAddress)
            ?: throw IllegalStateException("Cloudflare sync unavailable")
        when (orderRes) {
            is CloudflareResult.Failure -> throw IllegalStateException(orderRes.message)
            is CloudflareResult.Success -> {
                _cartByUser.value = _cartByUser.value + (userId to emptyList())
                listOf(orderRes.data)
            }
        }
    }

    suspend fun payExistingOrderWithFlutterwave(
        orderId: String,
        paymentMethod: String
    ): Result<String> = runCatching {
        val sync = syncRepo ?: throw IllegalStateException("Payments unavailable offline")
        when (val initRes = sync.initializePayment(orderId)) {
            is CloudflareResult.Failure -> throw IllegalStateException(initRes.message)
            is CloudflareResult.Success -> initRes.data
        }
    }

    suspend fun createOrUpdateSellerStorefront(
        ownerId: String,
        businessName: String,
        tagline: String,
        stateLocation: String,
        themeId: String,
        policies: String
    ): Result<String> = runCatching {
        val sellerId = "seller_$ownerId"
        val now = System.currentTimeMillis()
        val updated = SellerStorefront(
            id = sellerId,
            ownerId = ownerId,
            businessName = businessName.trim().take(100),
            tagline = tagline.trim().take(200),
            stateLocation = stateLocation,
            themeId = themeId,
            policies = policies.trim().take(1000),
            verified = false,
            rating = 4.9,
            followersCount = 1L,
            status = "active",
            createdAtEpochMs = now,
            updatedAtEpochMs = now
        )
        val without = _sellers.value.filterNot { it.id == sellerId || it.ownerId == ownerId }
        _sellers.value = listOf(updated) + without
        sellerId
    }

    suspend fun createProductListing(
        sellerId: String,
        sellerName: String,
        title: String,
        description: String,
        category: String,
        brand: String,
        priceNaira: Long,
        originalPriceNaira: Long,
        stockCount: Long,
        variants: List<String>,
        isFlashDeal: Boolean,
        imageKey: String = "hero_marketplace"
    ): Result<String> = runCatching {
        val id = "prod_${UUID.randomUUID().toString().take(10)}"
        val now = System.currentTimeMillis()
        val flashEnd = if (isFlashDeal) now + 6L * 3600_000L else 0L
        val prod = Product(
            id = id,
            sellerId = sellerId,
            sellerName = sellerName.ifBlank { "Verified Vendor" },
            title = title.trim().take(160),
            description = description.trim().take(2000),
            category = category,
            brand = brand.ifBlank { "CashNCarry" },
            priceNaira = priceNaira.coerceAtLeast(100L),
            originalPriceNaira = originalPriceNaira.coerceAtLeast(priceNaira),
            stockCount = stockCount.coerceAtLeast(1L),
            imageKey = imageKey,
            variants = variants.ifEmpty { listOf("Standard") },
            isFlashDeal = isFlashDeal,
            flashDealEndEpochMs = flashEnd,
            status = "active",
            createdAtEpochMs = now,
            updatedAtEpochMs = now
        )
        _products.value = listOf(prod) + _products.value
        id
    }

    suspend fun updateProductStockAndPrice(
        productId: String,
        newPriceNaira: Long,
        newStock: Long,
        isFlashDeal: Boolean
    ): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        val flashEnd = if (isFlashDeal) now + 4L * 3600_000L else 0L
        _products.value = _products.value.map {
            if (it.id == productId) {
                it.copy(
                    priceNaira = newPriceNaira.coerceAtLeast(100L),
                    stockCount = newStock.coerceAtLeast(0L),
                    isFlashDeal = isFlashDeal,
                    flashDealEndEpochMs = flashEnd,
                    updatedAtEpochMs = now
                )
            } else it
        }
        Unit
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String): Result<Unit> = runCatching {
        _orders.value = _orders.value.map {
            if (it.id == orderId) it.copy(orderStatus = newStatus, updatedAtEpochMs = System.currentTimeMillis()) else it
        }
        syncRepo?.fulfilSellerOrder(orderId, newStatus)
        Unit
    }

    suspend fun bootstrapInitialMarketplaceCatalog(currentUserId: String, currentUserName: String): Result<Unit> = runCatching {
        if (_products.value.isNotEmpty()) return@runCatching

        val starterSellerName = "${currentUserName.ifBlank { "Lagos" }.take(60)} Flagship Hub"
        val sellerId = "seller_$currentUserId"
        val now = System.currentTimeMillis()
        if (_sellers.value.isEmpty()) {
            _sellers.value = listOf(
                SellerStorefront(
                    id = sellerId,
                    ownerId = currentUserId,
                    businessName = starterSellerName,
                    tagline = "Authentic Nigerian & Global Luxury Essentials",
                    stateLocation = "Lagos",
                    verified = true,
                    rating = 4.9,
                    followersCount = 128L,
                    status = "active",
                    createdAtEpochMs = now,
                    updatedAtEpochMs = now
                )
            )
        }

        _products.value = listOf(
            Product(
                id = "prod_starter_anc",
                sellerId = currentUserId,
                sellerName = starterSellerName,
                title = "SonicPulse ANC Wireless Studio Headphones",
                description = "45dB adaptive noise cancellation, 60-hour battery life, USB-C fast charge, and studio spatial audio.",
                category = "Electronics",
                subcategory = "Audio",
                brand = "SonicPulse",
                priceNaira = 84500L,
                originalPriceNaira = 115000L,
                stockCount = 24L,
                rating = 4.9,
                reviewCount = 42L,
                imageKey = "hero_marketplace",
                variants = listOf("Obsidian Black", "Champagne Gold", "Emerald Edition"),
                deliveryStates = listOf("Lagos", "Abuja (FCT)", "Rivers", "Oyo", "Kano", "Enugu"),
                isFlashDeal = true,
                flashDealEndEpochMs = now + 5L * 3600_000L,
                liveStreamId = "stream_starter_tech"
            ),
            Product(
                id = "prod_starter_tote",
                sellerId = currentUserId,
                sellerName = starterSellerName,
                title = "Eko Luxe Handcrafted Leather Tote Bag",
                description = "Full-grain Italian-finished leather tote tailored for everyday executive style and weekend travel.",
                category = "Fashion",
                subcategory = "Bags",
                brand = "EkoCraft",
                priceNaira = 62000L,
                originalPriceNaira = 78000L,
                stockCount = 15L,
                rating = 4.8,
                reviewCount = 29L,
                imageKey = "live_fashion",
                variants = listOf("Cognac Tan", "Midnight Black", "Forest Emerald"),
                deliveryStates = listOf("Lagos", "Abuja (FCT)", "Ogun", "Oyo", "Rivers"),
                isFlashDeal = true,
                flashDealEndEpochMs = now + 3L * 3600_000L,
                liveStreamId = "stream_starter_fashion"
            ),
            Product(
                id = "prod_starter_phone",
                sellerId = currentUserId,
                sellerName = starterSellerName,
                title = "NovaPro 5G 256GB Flagship Smartphone",
                description = "120Hz AMOLED display, 50MP OIS triple camera, 5000mAh battery with 67W turbo adapter.",
                category = "Phones & Tablets",
                subcategory = "Smartphones",
                brand = "NovaMobile",
                priceNaira = 485000L,
                originalPriceNaira = 540000L,
                stockCount = 9L,
                rating = 4.9,
                reviewCount = 67L,
                imageKey = "live_tech",
                variants = listOf("256GB Titanium", "512GB Emerald"),
                deliveryStates = listOf("Lagos", "Abuja (FCT)", "Rivers", "Kano", "Enugu", "Delta"),
                liveStreamId = "stream_starter_tech"
            ),
            Product(
                id = "prod_starter_sneakers",
                sellerId = currentUserId,
                sellerName = starterSellerName,
                title = "VeloRun Carbon Knit Street Sneakers",
                description = "Breathable knit upper with dual-density rebound sole built for all-day urban comfort.",
                category = "Sneakers",
                subcategory = "Lifestyle",
                brand = "VeloRun",
                priceNaira = 54000L,
                originalPriceNaira = 68000L,
                stockCount = 31L,
                rating = 4.7,
                reviewCount = 53L,
                imageKey = "live_fashion",
                variants = listOf("EU 41", "EU 42", "EU 43", "EU 44"),
                deliveryStates = listOf("Lagos", "Abuja (FCT)", "Oyo", "Rivers", "Anambra"),
                liveStreamId = "stream_starter_fashion"
            ),
            Product(
                id = "prod_starter_skincare",
                sellerId = currentUserId,
                sellerName = starterSellerName,
                title = "Radiance Botanical Glow Skincare Set",
                description = "Vitamin C brightening serum, niacinamide essence, and SPF50 invisible daily moisturizer.",
                category = "Beauty",
                subcategory = "Skincare",
                brand = "ZuriGlow",
                priceNaira = 28500L,
                originalPriceNaira = 35000L,
                stockCount = 40L,
                rating = 4.9,
                reviewCount = 88L,
                imageKey = "seller_banner",
                variants = listOf("Complete 3-Piece Set", "Travel Duo"),
                deliveryStates = listOf("Lagos", "Abuja (FCT)", "Rivers", "Ogun", "Enugu", "Kaduna"),
                isFlashDeal = true,
                flashDealEndEpochMs = now + 7L * 3600_000L
            )
        )
    }
}
