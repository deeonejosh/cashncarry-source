package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.UiState
import com.example.data.remote.CloudflareResult
import com.example.data.remote.CloudflareSessionSnapshot
import com.example.data.remote.CloudflareSyncRepository
import com.example.data.remote.SharedPreferencesSessionStorage
import com.example.data.repository.AdminRepository
import com.example.data.repository.AiRecommendationRepository
import com.example.data.repository.CatalogRepository
import com.example.data.repository.LiveCommerceRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.LogoutConfirmationDialog
import com.example.ui.auth.SessionLoadingScreen
import com.example.ui.components.MiniPiPStreamBar
import com.example.ui.screens.AdminConsoleScreen
import com.example.ui.screens.BroadcastStudioScreen
import com.example.ui.screens.CartCheckoutOrdersScreen
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.HomeMarketplaceScreen
import com.example.ui.screens.LiveHubScreen
import com.example.ui.screens.LivePlayerScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.SellerCentreScreen
import com.example.ui.screens.StorefrontScreen
import com.example.ui.screens.UserProfileScreen
import com.example.ui.screens.VideoFeedScreen
import com.example.ui.theme.BrandBorder
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandEmeraldSoft
import com.example.ui.theme.BrandMuted
import com.example.ui.theme.BrandOrange
import com.example.ui.theme.BrandSlate
import com.example.ui.theme.CashNCarryTheme
import com.example.ui.theme.LiveCrimson
import com.example.ui.theme.SurfaceSoft
import com.example.ui.viewmodel.LiveCommerceViewModel
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.SellerAdminViewModel
import kotlinx.coroutines.launch

object Routes {
    const val HOME = "home"
    const val DISCOVER = "discover"
    const val LIVE = "live"
    const val REELS = "reels"
    const val ORDERS = "orders/{tab}"
    const val PRODUCT = "product/{productId}"
    const val LIVE_PLAYER = "live_player/{streamId}"
    const val STUDIO = "broadcast_studio"
    const val STOREFRONT = "storefront/{sellerId}"
    const val SELLER_CENTRE = "seller_centre"
    const val ADMIN_CONSOLE = "admin_console"
    const val PROFILE = "profile"

    fun orders(tab: Int = 0) = "orders/$tab"
    fun product(productId: String) = "product/$productId"
    fun livePlayer(streamId: String) = "live_player/$streamId"
    fun storefront(sellerId: String) = "storefront/$sellerId"
}

private data class TopTab(
    val route: String,
    val matchPrefix: String,
    val label: String,
    val icon: ImageVector,
    val tag: String
)

private sealed interface AuthGateState {
    data object Loading : AuthGateState
    data object Unauthenticated : AuthGateState
    data class Authenticated(val session: CloudflareSessionSnapshot) : AuthGateState
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CashNCarryTheme {
                val context = LocalContext.current
                val cloudflareSyncRepo = remember(context) {
                    CloudflareSyncRepository(SharedPreferencesSessionStorage(context))
                }
                var authState by remember { mutableStateOf<AuthGateState>(AuthGateState.Loading) }

                LaunchedEffect(cloudflareSyncRepo) {
                    val cached = cloudflareSyncRepo.currentSessionSnapshot()
                    if (!cached.signedIn || cached.role.equals("admin", ignoreCase = true)) {
                        authState = AuthGateState.Unauthenticated
                    } else {
                        authState = when (val restored = cloudflareSyncRepo.restoreSession()) {
                            is CloudflareResult.Success -> AuthGateState.Authenticated(restored.data)
                            // Never unlock account-scoped screens based only on an old
                            // cached token when the Worker cannot validate the session.
                            is CloudflareResult.Failure -> AuthGateState.Unauthenticated
                        }
                    }
                }

                when (val current = authState) {
                    AuthGateState.Loading -> SessionLoadingScreen()
                    AuthGateState.Unauthenticated -> AuthScreen(
                        cloudflareSyncRepo = cloudflareSyncRepo,
                        onAuthSuccess = { snapshot ->
                            authState = AuthGateState.Authenticated(snapshot)
                        }
                    )
                    is AuthGateState.Authenticated -> {
                        key(current.session.userId) {
                            CashNCarryAuthenticatedShell(
                                session = current.session,
                                cloudflareSyncRepo = cloudflareSyncRepo,
                                onSignedOut = {
                                    authState = AuthGateState.Unauthenticated
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CashNCarryAuthenticatedShell(
    session: CloudflareSessionSnapshot,
    cloudflareSyncRepo: CloudflareSyncRepository,
    onSignedOut: () -> Unit
) {
    var showCreateSheet by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val catalogRepo = remember(cloudflareSyncRepo) { CatalogRepository(cloudflareSyncRepo) }
    val liveRepo = remember(cloudflareSyncRepo) { LiveCommerceRepository(cloudflareSyncRepo) }
    val adminRepo = remember { AdminRepository() }
    val aiRepo = remember { AiRecommendationRepository() }

    val currentUserId = session.userId
    val displayName = session.displayName.takeIf { it.isNotBlank() }
        ?: session.email.substringBefore("@").ifBlank { "Shopper" }
    val userEmail = session.email

    val marketplaceVm: MarketplaceViewModel = viewModel(
        key = "mkt_${currentUserId}",
        factory = viewModelFactory {
            initializer {
                MarketplaceViewModel(
                    catalogRepository = catalogRepo,
                    aiRepository = aiRepo,
                    currentUserId = currentUserId,
                    currentUserName = displayName,
                    currentUserEmail = userEmail,
                    cloudflareSyncRepository = cloudflareSyncRepo
                )
            }
        }
    )

    val liveVm: LiveCommerceViewModel = viewModel(
        key = "live_${currentUserId}",
        factory = viewModelFactory {
            initializer {
                LiveCommerceViewModel(
                    liveRepo = liveRepo,
                    adminRepo = adminRepo,
                    currentUserId = currentUserId,
                    currentUserName = displayName
                )
            }
        }
    )

    val sellerAdminVm: SellerAdminViewModel = viewModel(
        key = "seller_${currentUserId}",
        factory = viewModelFactory {
            initializer {
                SellerAdminViewModel(
                    catalogRepo = catalogRepo,
                    liveRepo = liveRepo,
                    adminRepo = adminRepo,
                    currentUserId = currentUserId,
                    currentUserName = displayName,
                    currentUserEmail = userEmail
                )
            }
        }
    )

    val productsState by marketplaceVm.productsState.collectAsStateWithLifecycle()
    val sellersState by marketplaceVm.sellersState.collectAsStateWithLifecycle()
    val cartState by marketplaceVm.cartState.collectAsStateWithLifecycle()
    val wishlistState by marketplaceVm.wishlistState.collectAsStateWithLifecycle()
    val ordersState by marketplaceVm.buyerOrdersState.collectAsStateWithLifecycle()
    val userProfile by marketplaceVm.userProfile.collectAsStateWithLifecycle()
    val privateInfo by marketplaceVm.userPrivateInfo.collectAsStateWithLifecycle()
    val selectedReviews by marketplaceVm.selectedProductReviews.collectAsStateWithLifecycle()
    val searchQuery by marketplaceVm.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by marketplaceVm.selectedCategory.collectAsStateWithLifecycle()
    val selectedBrand by marketplaceVm.selectedBrand.collectAsStateWithLifecycle()
    val selectedSellerFilterId by marketplaceVm.selectedSellerFilterId.collectAsStateWithLifecycle()
    val sortOption by marketplaceVm.sortOption.collectAsStateWithLifecycle()
    val inStockOnly by marketplaceVm.inStockOnly.collectAsStateWithLifecycle()
    val deliveryStateFilterEnabled by marketplaceVm.deliveryStateFilterEnabled.collectAsStateWithLifecycle()
    val compareIds by marketplaceVm.compareProductIds.collectAsStateWithLifecycle()
    val aiAdviceState by marketplaceVm.aiAdviceState.collectAsStateWithLifecycle()
    val mktMessage by marketplaceVm.actionMessage.collectAsStateWithLifecycle()

    val livestreamsState by liveVm.livestreamsState.collectAsStateWithLifecycle()
    val auctionsState by liveVm.auctionsState.collectAsStateWithLifecycle()
    val shortVideosState by liveVm.shortVideosState.collectAsStateWithLifecycle()
    val userShortVideos by liveVm.userShortVideos.collectAsStateWithLifecycle()
    val wallet by liveVm.walletState.collectAsStateWithLifecycle()
    val walletLedger by liveVm.walletLedgerState.collectAsStateWithLifecycle()
    val virtualGifts by liveVm.virtualGifts.collectAsStateWithLifecycle()
    val activeStreamMessages by liveVm.activeStreamMessages.collectAsStateWithLifecycle()
    val activeTopGifters by liveVm.activeTopGifters.collectAsStateWithLifecycle()
    val activeAuctionBids by liveVm.activeAuctionBids.collectAsStateWithLifecycle()
    val activeVideoComments by liveVm.activeVideoComments.collectAsStateWithLifecycle()
    val usePromoCoins by liveVm.usePromoCoins.collectAsStateWithLifecycle()
    val giftBanner by liveVm.giftBanner.collectAsStateWithLifecycle()
    val minimizedStreamId by liveVm.minimizedStreamId.collectAsStateWithLifecycle()
    val liveMessage by liveVm.statusBanner.collectAsStateWithLifecycle()

    val sellerProducts by sellerAdminVm.sellerProducts.collectAsStateWithLifecycle()
    val sellerOrders by sellerAdminVm.sellerOrders.collectAsStateWithLifecycle()
    val sellerGiftTx by sellerAdminVm.sellerGiftTransactions.collectAsStateWithLifecycle()
    val adminDisputes by sellerAdminVm.adminDisputes.collectAsStateWithLifecycle()
    val adminAuditLogs by sellerAdminVm.adminAuditLogs.collectAsStateWithLifecycle()
    val sellerFeedback by sellerAdminVm.feedback.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(mktMessage) {
        mktMessage?.let {
            snackbarHostState.showSnackbar(it)
            marketplaceVm.clearMessage()
        }
    }
    LaunchedEffect(liveMessage) {
        liveMessage?.let {
            snackbarHostState.showSnackbar(it)
            liveVm.clearStatusBanner()
        }
    }
    LaunchedEffect(sellerFeedback) {
        sellerFeedback?.let {
            snackbarHostState.showSnackbar(it)
            sellerAdminVm.clearFeedback()
        }
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: Routes.HOME

    val allProducts = (productsState as? UiState.Success)?.data ?: emptyList()
    val allSellers = (sellersState as? UiState.Success)?.data ?: emptyList()
    val allStreams = (livestreamsState as? UiState.Success)?.data ?: emptyList()
    val allAuctions = (auctionsState as? UiState.Success)?.data ?: emptyList()
    val allVideos = (shortVideosState as? UiState.Success)?.data ?: emptyList()
    val cartItems = (cartState as? UiState.Success)?.data ?: emptyList()
    val wishlistItems = (wishlistState as? UiState.Success)?.data ?: emptyList()
    val orders = (ordersState as? UiState.Success)?.data ?: emptyList()

    val cartCount = cartItems.sumOf { it.quantity }.toInt()
    val wishlistIds = remember(wishlistItems) { wishlistItems.map { it.productId }.toSet() }
    val selectedState = userProfile?.selectedState ?: "Lagos"
    val followingSellerIds = userProfile?.followingSellerIds ?: emptyList()
    val recentIds = userProfile?.recentProductIds ?: emptyList()
    val hasSavedShippingReady = privateInfo?.savedPaymentReady == true

    val showChromeBars = !currentRoute.startsWith("live_player/") &&
        currentRoute != Routes.STUDIO &&
        !currentRoute.startsWith("product/")

    val minimizedStream = remember(allStreams, minimizedStreamId) {
        minimizedStreamId?.let { id -> allStreams.find { it.id == id } }
    }

    val topTabs = listOf(
        TopTab(Routes.HOME, Routes.HOME, "Home", Icons.Default.Home, "nav_home"),
        TopTab(Routes.DISCOVER, Routes.DISCOVER, "Discover", Icons.Default.Search, "nav_discover"),
        TopTab(Routes.LIVE, Routes.LIVE, "LIVE", Icons.Default.LiveTv, "nav_live"),
        TopTab(Routes.REELS, Routes.REELS, "Reels", Icons.Default.PlayCircle, "nav_reels"),
        TopTab(Routes.orders(0), "orders/", "Orders", Icons.Default.ShoppingBag, "nav_orders")
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth >= 680.dp

        Scaffold(
            containerColor = Color.White,
            contentWindowInsets = if (showChromeBars) WindowInsets.safeDrawing else WindowInsets(0.dp),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (showChromeBars && !isWide) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        if (minimizedStream != null) {
                            MiniPiPStreamBar(
                                stream = minimizedStream,
                                onExpand = {
                                    liveVm.openStream(minimizedStream.id)
                                    navController.navigate(Routes.livePlayer(minimizedStream.id))
                                },
                                onClose = { liveVm.dismissMiniPlayer() }
                            )
                        }
                        Surface(
                            color = Color.White,
                            shadowElevation = 10.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.navigationBarsPadding()) {
                                HorizontalDivider(color = BrandBorder, thickness = 0.8.dp)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceAround,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(66.dp)
                                        .padding(horizontal = 6.dp)
                                ) {
                                    MockupBottomNavItem(
                                        selected = currentRoute == Routes.REELS,
                                        icon = if (currentRoute == Routes.REELS) Icons.Default.PlayCircle else Icons.Outlined.PlayCircle,
                                        label = "For You",
                                        tag = "nav_reels",
                                        onClick = {
                                            navController.navigate(Routes.REELS) {
                                                popUpTo(Routes.HOME) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )

                                    MockupShopNavItem(
                                        selected = currentRoute == Routes.HOME,
                                        tag = "nav_home",
                                        onClick = {
                                            navController.navigate(Routes.HOME) {
                                                popUpTo(Routes.HOME) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )

                                    // Center Floating Orange + FAB (matches mockup)
                                    Surface(
                                        onClick = { showCreateSheet = true },
                                        shape = CircleShape,
                                        color = BrandOrange,
                                        shadowElevation = 6.dp,
                                        modifier = Modifier
                                            .size(50.dp)
                                            .testTag("nav_create_plus")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "Create, Go Live or Discover",
                                                tint = Color.White,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }

                                    MockupBottomNavItem(
                                        selected = currentRoute.startsWith("orders/"),
                                        icon = if (currentRoute.startsWith("orders/")) Icons.Default.ShoppingBag else Icons.Outlined.ShoppingBag,
                                        label = "Orders",
                                        badgeCount = cartCount,
                                        tag = "nav_orders",
                                        onClick = {
                                            navController.navigate(Routes.orders(0)) {
                                                popUpTo(Routes.HOME) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )

                                    MockupBottomNavItem(
                                        selected = currentRoute == Routes.PROFILE,
                                        icon = if (currentRoute == Routes.PROFILE) Icons.Default.Person else Icons.Outlined.Person,
                                        label = "Profile",
                                        tag = "nav_profile",
                                        onClick = {
                                            navController.navigate(Routes.PROFILE) {
                                                popUpTo(Routes.HOME) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showChromeBars && isWide) {
                    NavigationRail(
                        containerColor = Color.White,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        topTabs.forEach { tab ->
                            val selected = currentRoute == tab.route || currentRoute.startsWith(tab.matchPrefix)
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(Routes.HOME) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = Routes.HOME
                    ) {
                        composable(Routes.HOME) {
                            HomeMarketplaceScreen(
                                productsState = productsState,
                                sellersState = sellersState,
                                livestreamsState = livestreamsState,
                                shortVideosState = shortVideosState,
                                selectedState = selectedState,
                                selectedCategory = selectedCategory,
                                searchQuery = searchQuery,
                                cartCount = cartCount,
                                wishlistProductIds = wishlistIds,
                                compareProductIds = compareIds.toSet(),
                                recentProductIds = recentIds,
                                wallet = wallet,
                                isAdmin = sellerAdminVm.isAdmin,
                                onSearchChange = marketplaceVm::setSearchQuery,
                                onTriggerSearch = {
                                    marketplaceVm.runAiSearchAdvice()
                                    navController.navigate(Routes.DISCOVER)
                                },
                                onSelectCategory = marketplaceVm::setCategory,
                                onUpdateNigerianState = marketplaceVm::updateNigerianState,
                                onOpenProduct = { prod ->
                                    marketplaceVm.selectProductForDetail(prod.id)
                                    navController.navigate(Routes.product(prod.id))
                                },
                                onAddToCart = { prod ->
                                    marketplaceVm.addToCart(prod, prod.variants.firstOrNull() ?: "Standard")
                                },
                                onToggleWishlist = marketplaceVm::toggleWishlist,
                                onToggleCompare = { prod -> marketplaceVm.toggleCompareProduct(prod.id) },
                                onOpenLivestream = { streamId ->
                                    liveVm.openStream(streamId)
                                    navController.navigate(Routes.livePlayer(streamId))
                                },
                                onOpenLiveHub = { navController.navigate(Routes.LIVE) },
                                onOpenVideoFeed = { navController.navigate(Routes.REELS) },
                                onOpenStorefront = { sellerId -> navController.navigate(Routes.storefront(sellerId)) },
                                onOpenCart = { navController.navigate(Routes.orders(0)) },
                                onOpenWallet = { navController.navigate(Routes.orders(2)) },
                                onOpenSellerCentre = { navController.navigate(Routes.SELLER_CENTRE) },
                                onOpenAdminConsole = { navController.navigate(Routes.ADMIN_CONSOLE) },
                                onOpenProfile = { navController.navigate(Routes.PROFILE) },
                                liveAuctions = allAuctions.filter { it.status == "live" },
                                currentUserId = currentUserId,
                                onPlaceAuctionBid = liveVm::placeBid,
                                onClaimAuctionWin = { auc ->
                                    liveVm.claimWonAuction(
                                        auction = auc,
                                        deliveryState = selectedState,
                                        deliveryAddress = privateInfo?.shippingAddress.orEmpty()
                                    ) {
                                        navController.navigate(Routes.orders(1))
                                    }
                                }
                            )
                        }

                        composable(Routes.DISCOVER) {
                            DiscoverScreen(
                                products = allProducts,
                                sellers = allSellers,
                                selectedState = selectedState,
                                searchQuery = searchQuery,
                                selectedCategory = selectedCategory,
                                selectedBrand = selectedBrand,
                                selectedSellerId = selectedSellerFilterId,
                                sortOption = sortOption,
                                inStockOnly = inStockOnly,
                                deliveryStateFilterEnabled = deliveryStateFilterEnabled,
                                wishlistIds = wishlistIds,
                                compareIds = compareIds,
                                aiAdviceState = aiAdviceState,
                                onSearchChange = marketplaceVm::setSearchQuery,
                                onRunAiSearch = marketplaceVm::runAiSearchAdvice,
                                onSelectCategory = marketplaceVm::setCategory,
                                onSelectBrand = marketplaceVm::setBrand,
                                onSelectSeller = marketplaceVm::setSellerFilter,
                                onSelectSort = marketplaceVm::setSortOption,
                                onToggleInStock = marketplaceVm::toggleInStockOnly,
                                onToggleDeliveryState = marketplaceVm::toggleDeliveryStateFilter,
                                onOpenProduct = { prod ->
                                    marketplaceVm.selectProductForDetail(prod.id)
                                    navController.navigate(Routes.product(prod.id))
                                },
                                onAddToCart = { prod ->
                                    marketplaceVm.addToCart(prod, prod.variants.firstOrNull() ?: "Standard")
                                },
                                onToggleWishlist = marketplaceVm::toggleWishlist,
                                onToggleCompare = { prod -> marketplaceVm.toggleCompareProduct(prod.id) },
                                onOpenLivestream = { streamId ->
                                    liveVm.openStream(streamId)
                                    navController.navigate(Routes.livePlayer(streamId))
                                }
                            )
                        }

                        composable(Routes.LIVE) {
                            LiveHubScreen(
                                livestreamsState = livestreamsState,
                                auctionsState = auctionsState,
                                activeAuctionBids = activeAuctionBids,
                                followingSellerIds = followingSellerIds,
                                currentUserId = currentUserId,
                                hasSavedShippingReady = hasSavedShippingReady,
                                selectedState = selectedState,
                                selectedAddress = privateInfo?.shippingAddress.orEmpty(),
                                onOpenStream = { streamId ->
                                    liveVm.openStream(streamId)
                                    navController.navigate(Routes.livePlayer(streamId))
                                },
                                onGoLive = { navController.navigate(Routes.STUDIO) },
                                onSelectAuction = liveVm::selectAuction,
                                onPlaceBid = liveVm::placeBid,
                                onClaimWonAuction = liveVm::claimWonAuction,
                                onOpenShippingSetup = { navController.navigate(Routes.orders(0)) },
                                onOrderCreated = { navController.navigate(Routes.orders(1)) }
                            )
                        }

                        composable(Routes.REELS) {
                            VideoFeedScreen(
                                shortVideosState = shortVideosState,
                                allProducts = allProducts,
                                followingSellerIds = followingSellerIds,
                                activeVideoComments = activeVideoComments,
                                onSelectVideoForComments = liveVm::selectVideoForComments,
                                onLikeVideo = liveVm::likeShortVideo,
                                onCommentVideo = liveVm::commentShortVideo,
                                onToggleFollowSeller = marketplaceVm::toggleFollowSeller,
                                onAddToCart = { prod ->
                                    marketplaceVm.addToCart(prod, prod.variants.firstOrNull() ?: "Standard")
                                },
                                onBuyNow = { prod ->
                                    marketplaceVm.addToCart(prod, prod.variants.firstOrNull() ?: "Standard")
                                    navController.navigate(Routes.orders(0))
                                },
                                onOpenProduct = { prod ->
                                    marketplaceVm.selectProductForDetail(prod.id)
                                    navController.navigate(Routes.product(prod.id))
                                },
                                onWatchLive = { streamId ->
                                    liveVm.openStream(streamId)
                                    navController.navigate(Routes.livePlayer(streamId))
                                }
                            )
                        }

                        composable(
                            route = Routes.ORDERS,
                            arguments = listOf(navArgument("tab") { type = NavType.IntType; defaultValue = 0 })
                        ) { entry ->
                            val initialTab = entry.arguments?.getInt("tab") ?: 0
                            CartCheckoutOrdersScreen(
                                initialTab = initialTab,
                                cartItems = cartItems,
                                orders = orders,
                                wishlistItems = wishlistItems,
                                wallet = wallet,
                                walletLedger = walletLedger,
                                privateInfo = privateInfo,
                                selectedState = selectedState,
                                userName = displayName,
                                userEmail = userEmail,
                                onUpdateCartQty = marketplaceVm::updateCartQuantity,
                                onCheckoutCart = { state, address, method ->
                                    marketplaceVm.checkoutCart(state, address, method) {}
                                },
                                onPayExistingOrder = marketplaceVm::payOrder,
                                onSaveShippingSetup = marketplaceVm::saveShippingSetup,
                                onBuyCoins = liveVm::buyCoins,
                                onClaimPromoCoins = liveVm::claimPromoCoins,
                                onSignOut = { showLogoutDialog = true }
                            )
                        }

                        composable(
                            route = Routes.PRODUCT,
                            arguments = listOf(navArgument("productId") { type = NavType.StringType })
                        ) { entry ->
                            val productId = entry.arguments?.getString("productId").orEmpty()
                            val product = allProducts.find { it.id == productId }
                            if (product != null) {
                                val seller = allSellers.find { it.ownerId == product.sellerId }
                                val related = allProducts.filter { it.category == product.category && it.id != product.id }
                                ProductDetailScreen(
                                    product = product,
                                    seller = seller,
                                    reviews = selectedReviews,
                                    relatedProducts = related,
                                    selectedState = selectedState,
                                    isWishlisted = wishlistIds.contains(product.id),
                                    isFollowingSeller = followingSellerIds.contains(product.sellerId),
                                    onBack = { navController.popBackStack() },
                                    onAddToCart = { variant -> marketplaceVm.addToCart(product, variant) },
                                    onBuyNow = { variant ->
                                        marketplaceVm.addToCart(product, variant)
                                        navController.navigate(Routes.orders(0))
                                    },
                                    onToggleWishlist = { marketplaceVm.toggleWishlist(product) },
                                    onToggleFollowSeller = { marketplaceVm.toggleFollowSeller(product.sellerId) },
                                    onWatchLive = { streamId ->
                                        liveVm.openStream(streamId)
                                        navController.navigate(Routes.livePlayer(streamId))
                                    },
                                    onOpenStorefront = { sellerId -> navController.navigate(Routes.storefront(sellerId)) },
                                    onOpenProduct = { rel ->
                                        marketplaceVm.selectProductForDetail(rel.id)
                                        navController.navigate(Routes.product(rel.id))
                                    },
                                    onSubmitReview = { rating, comment ->
                                        marketplaceVm.submitReview(product.id, rating, comment)
                                    }
                                )
                            } else {
                                MissingEntityFallback(
                                    title = "Product not found",
                                    subtitle = "This item may have been removed or is still syncing.",
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = Routes.LIVE_PLAYER,
                            arguments = listOf(navArgument("streamId") { type = NavType.StringType })
                        ) { entry ->
                            val streamId = entry.arguments?.getString("streamId").orEmpty()
                            val stream = allStreams.find { it.id == streamId } ?: allStreams.firstOrNull()
                            if (stream != null) {
                                LaunchedEffect(stream.id) { liveVm.openStream(stream.id) }
                                val streamProducts = allProducts.filter { it.sellerId == stream.sellerId || it.liveStreamId == stream.id }
                                    .ifEmpty { allProducts.take(4) }
                                val streamAuction = allAuctions.firstOrNull { it.sellerId == stream.sellerId && it.status == "live" }
                                LivePlayerScreen(
                                    stream = stream,
                                    streamProducts = streamProducts,
                                    activeAuction = streamAuction,
                                    messages = activeStreamMessages,
                                    topGifters = activeTopGifters,
                                    virtualGifts = virtualGifts,
                                    wallet = wallet,
                                    usePromoCoins = usePromoCoins,
                                    giftBanner = giftBanner,
                                    isFollowingSeller = followingSellerIds.contains(stream.sellerId),
                                    currentUserId = currentUserId,
                                    isAdmin = sellerAdminVm.isAdmin,
                                    onBack = { navController.popBackStack() },
                                    onMinimizePiP = {
                                        liveVm.minimizeStream(stream.id)
                                        navController.popBackStack()
                                    },
                                    onToggleFollowSeller = { marketplaceVm.toggleFollowSeller(stream.sellerId) },
                                    onSendLike = { liveVm.sendLike(stream.id) },
                                    onSendChat = { text -> liveVm.sendChatMessage(stream.id, text) },
                                    onModerateDeleteMessage = { msgId -> liveVm.moderateDeleteMessage(stream.id, msgId) },
                                    onTogglePromoCoins = liveVm::setUsePromoCoins,
                                    onSendGift = { gift -> liveVm.sendGift(stream, gift) },
                                    onClearGiftBanner = liveVm::clearGiftBanner,
                                    onClaimPromoCoins = liveVm::claimPromoCoins,
                                    onOpenWalletTopUp = { navController.navigate(Routes.orders(2)) },
                                    onAddToCart = { prod ->
                                        marketplaceVm.addToCart(prod, prod.variants.firstOrNull() ?: "Standard")
                                    },
                                    onBuyNow = { prod ->
                                        marketplaceVm.addToCart(prod, prod.variants.firstOrNull() ?: "Standard")
                                        liveVm.minimizeStream(stream.id)
                                        navController.navigate(Routes.orders(0))
                                    },
                                    onOpenProductDetail = { prod ->
                                        liveVm.minimizeStream(stream.id)
                                        marketplaceVm.selectProductForDetail(prod.id)
                                        navController.navigate(Routes.product(prod.id))
                                    },
                                    onPlaceAuctionBid = liveVm::placeBid,
                                    onReportStream = { reason -> liveVm.reportLivestream(stream.id, reason) }
                                )
                            } else {
                                MissingEntityFallback(
                                    title = "Broadcast has ended",
                                    subtitle = "This livestream is no longer active.",
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(Routes.STUDIO) {
                            val myLiveStream = allStreams.firstOrNull { it.sellerId == currentUserId && it.status == "live" }
                            BroadcastStudioScreen(
                                sellerProducts = sellerProducts.ifEmpty { allProducts.take(4) },
                                activeStream = myLiveStream,
                                streamMessages = activeStreamMessages,
                                onBack = { navController.popBackStack() },
                                onStartLive = liveVm::startBroadcast,
                                onPinProduct = liveVm::pinProduct,
                                onLaunchFlashDeal = liveVm::triggerFlashDeal,
                                onLaunchAuction = { prod, startBid, minInc, mins ->
                                    sellerAdminVm.launchAuction(displayName, prod, startBid, minInc, mins)
                                },
                                onSendHostChat = liveVm::sendChatMessage,
                                onModeratorDeleteChat = liveVm::moderateDeleteMessage,
                                onEndLive = { id ->
                                    liveVm.endBroadcast(id) { navController.popBackStack() }
                                }
                            )
                        }

                        composable(
                            route = Routes.STOREFRONT,
                            arguments = listOf(navArgument("sellerId") { type = NavType.StringType })
                        ) { entry ->
                            val sellerId = entry.arguments?.getString("sellerId").orEmpty()
                            val seller = allSellers.find { it.ownerId == sellerId || it.id == sellerId }
                            if (seller != null) {
                                StorefrontScreen(
                                    seller = seller,
                                    sellerProducts = allProducts.filter { it.sellerId == seller.ownerId },
                                    sellerStreams = allStreams.filter { it.sellerId == seller.ownerId },
                                    sellerVideos = allVideos.filter { it.sellerId == seller.ownerId },
                                    wishlistIds = wishlistIds,
                                    compareIds = compareIds,
                                    isFollowing = followingSellerIds.contains(seller.ownerId),
                                    onBack = { navController.popBackStack() },
                                    onToggleFollow = { marketplaceVm.toggleFollowSeller(seller.ownerId) },
                                    onOpenProduct = { prod ->
                                        marketplaceVm.selectProductForDetail(prod.id)
                                        navController.navigate(Routes.product(prod.id))
                                    },
                                    onAddToCart = { prod ->
                                        marketplaceVm.addToCart(prod, prod.variants.firstOrNull() ?: "Standard")
                                    },
                                    onToggleWishlist = marketplaceVm::toggleWishlist,
                                    onToggleCompare = { prod -> marketplaceVm.toggleCompareProduct(prod.id) },
                                    onOpenStream = { streamId ->
                                        liveVm.openStream(streamId)
                                        navController.navigate(Routes.livePlayer(streamId))
                                    },
                                    onOpenVideos = { navController.navigate(Routes.REELS) }
                                )
                            } else {
                                MissingEntityFallback(
                                    title = "Storefront not found",
                                    subtitle = "Unable to load this seller storefront right now.",
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(Routes.SELLER_CENTRE) {
                            val myStore = allSellers.find { it.ownerId == currentUserId }
                            SellerCentreScreen(
                                sellerStorefront = myStore,
                                sellerProducts = sellerProducts,
                                sellerOrders = sellerOrders,
                                giftTransactions = sellerGiftTx,
                                defaultSellerName = displayName,
                                onBack = { navController.popBackStack() },
                                onOpenBroadcastStudio = { navController.navigate(Routes.STUDIO) },
                                onSaveStorefront = sellerAdminVm::saveStorefront,
                                onAddProduct = sellerAdminVm::addProduct,
                                onUpdateProduct = sellerAdminVm::updateStockAndFlash,
                                onFulfilOrder = sellerAdminVm::fulfilOrder,
                                onLaunchAuction = sellerAdminVm::launchAuction,
                                onPublishShortVideo = sellerAdminVm::publishShoppableVideo
                            )
                        }

                        composable(Routes.ADMIN_CONSOLE) {
                            AdminConsoleScreen(
                                isAdmin = sellerAdminVm.isAdmin,
                                sellers = allSellers,
                                products = allProducts,
                                gifts = virtualGifts,
                                disputes = adminDisputes,
                                auditLogs = adminAuditLogs,
                                onBack = { navController.popBackStack() },
                                onVerifySeller = sellerAdminVm::adminVerifySeller,
                                onModerateProduct = sellerAdminVm::adminModerateProduct,
                                onSaveGift = sellerAdminVm::adminSaveGift,
                                onResolveDispute = sellerAdminVm::adminResolveDispute
                            )
                        }

                        composable(Routes.PROFILE) {
                            val cfHealth by marketplaceVm.cloudflareHealth.collectAsStateWithLifecycle()
                            val cfSession by marketplaceVm.cloudflareSession.collectAsStateWithLifecycle()
                            UserProfileScreen(
                                userProfile = userProfile,
                                fallbackName = displayName,
                                userEmail = userEmail,
                                avatarUrl = null,
                                wallet = wallet,
                                uploadedVideos = userShortVideos,
                                catalogProducts = allProducts,
                                onBack = { navController.popBackStack() },
                                onSaveProfile = marketplaceVm::updateUserProfile,
                                onUploadShoppableVideo = liveVm::publishUserShortVideo,
                                onWatchVideoFeed = { navController.navigate(Routes.REELS) },
                                onOpenProduct = { prod ->
                                    marketplaceVm.selectProductForDetail(prod.id)
                                    navController.navigate(Routes.product(prod.id))
                                },
                                onOpenWallet = { navController.navigate(Routes.orders(2)) },
                                onSignOut = { showLogoutDialog = true },
                                cloudflareHealth = cfHealth,
                                cloudflareSession = cfSession,
                                onLinkCloudflareAccount = marketplaceVm::signInCloudflareAccount,
                                onSignOutCloudflare = { showLogoutDialog = true }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCreateSheet = false },
            containerColor = Color.White
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "Create & Explore",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = BrandSlate
                )
                CreateSheetItem(
                    icon = Icons.Default.Sensors,
                    title = "Live Shopping & Auctions",
                    subtitle = "Watch active sellers or place real-time Naira bids",
                    tint = LiveCrimson
                ) {
                    showCreateSheet = false
                    navController.navigate(Routes.LIVE)
                }
                CreateSheetItem(
                    icon = Icons.Default.VideoCall,
                    title = "Go Live (Broadcast Studio)",
                    subtitle = "Start a live stream, pin products & run flash deals",
                    tint = BrandEmerald
                ) {
                    showCreateSheet = false
                    navController.navigate(Routes.STUDIO)
                }
                CreateSheetItem(
                    icon = Icons.Default.PlayCircle,
                    title = "Post a Shoppable Video",
                    subtitle = "Upload a reel linked to a marketplace product",
                    tint = BrandOrange
                ) {
                    showCreateSheet = false
                    navController.navigate(Routes.PROFILE)
                }
                CreateSheetItem(
                    icon = Icons.Default.Storefront,
                    title = "Seller Centre",
                    subtitle = "Manage listings, orders & custom storefront",
                    tint = BrandSlate
                ) {
                    showCreateSheet = false
                    navController.navigate(Routes.SELLER_CENTRE)
                }
                CreateSheetItem(
                    icon = Icons.Default.Search,
                    title = "Discover & AI Search",
                    subtitle = "Filter by brand, category, price & state delivery",
                    tint = BrandEmerald
                ) {
                    showCreateSheet = false
                    navController.navigate(Routes.DISCOVER)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showLogoutDialog) {
        LogoutConfirmationDialog(
            onConfirmLogout = {
                showLogoutDialog = false
                scope.launch {
                    cloudflareSyncRepo.signOut()
                    onSignedOut()
                }
            },
            onDismiss = { showLogoutDialog = false }
        )
    }
}

@Composable
private fun MockupBottomNavItem(
    selected: Boolean,
    icon: ImageVector,
    label: String,
    tag: String,
    badgeCount: Int = 0,
    onClick: () -> Unit
) {
    val tint = if (selected) BrandEmerald else BrandSlate
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .testTag(tag)
    ) {
        if (badgeCount > 0) {
            BadgedBox(
                badge = {
                    Badge(containerColor = BrandOrange) {
                        Text("$badgeCount", color = Color.White)
                    }
                }
            ) {
                Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(23.dp))
            }
        } else {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = tint
        )
        Spacer(Modifier.height(2.dp))
        Box(
            modifier = Modifier
                .width(24.dp)
                .height(3.dp)
                .clip(RoundedCornerShape(50))
                .background(if (selected) BrandEmerald else Color.Transparent)
        )
    }
}

@Composable
private fun MockupShopNavItem(
    selected: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    val tint = if (selected) BrandEmerald else BrandSlate
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .testTag(tag)
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo_cashncarry_mark),
            contentDescription = "Shop",
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(24.dp)
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = "Shop",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = tint
        )
        Spacer(Modifier.height(2.dp))
        Box(
            modifier = Modifier
                .width(28.dp)
                .height(3.dp)
                .clip(RoundedCornerShape(50))
                .background(if (selected) BrandEmerald else Color.Transparent)
        )
    }
}

@Composable
private fun CreateSheetItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = SurfaceSoft,
        border = BorderStroke(1.dp, BrandBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.14f))
            ) {
                Icon(icon, contentDescription = title, tint = tint, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = BrandSlate)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = BrandMuted)
            }
        }
    }
}

@Composable
private fun MissingEntityFallback(
    title: String,
    subtitle: String,
    onBack: () -> Unit
) {
    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(24.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = BrandSlate
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = BrandMuted
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onBack,
            colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald, contentColor = Color.White),
            modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .testTag("fallback_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text("Go Back")
        }
    }
}
