package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Comment
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.formatCompactCount
import com.example.core.formatNaira
import com.example.data.model.Product
import com.example.data.model.ShortVideo
import com.example.data.model.UiState
import com.example.data.model.VideoComment
import com.example.ui.components.resolveDrawableRes
import com.example.ui.theme.BrandEmerald
import com.example.ui.theme.BrandMuted
import com.example.ui.theme.BrandSlate
import com.example.ui.theme.LiveCrimson
import com.example.ui.theme.SurfaceSoft

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoFeedScreen(
    shortVideosState: UiState<List<ShortVideo>>,
    allProducts: List<Product>,
    followingSellerIds: List<String>,
    activeVideoComments: List<VideoComment>,
    onSelectVideoForComments: (String) -> Unit,
    onLikeVideo: (String) -> Unit,
    onCommentVideo: (String, String) -> Unit,
    onToggleFollowSeller: (String) -> Unit,
    onAddToCart: (Product) -> Unit,
    onBuyNow: (Product) -> Unit,
    onOpenProduct: (Product) -> Unit,
    onWatchLive: (String) -> Unit
) {
    val context = LocalContext.current
    var feedFilter by remember { mutableStateOf("For You") }
    var commentSheetVideoId by remember { mutableStateOf<String?>(null) }
    var newComment by remember { mutableStateOf("") }

    val allVideos = (shortVideosState as? UiState.Success)?.data ?: emptyList()
    val displayVideos = remember(allVideos, feedFilter, followingSellerIds) {
        when (feedFilter) {
            "Following" -> allVideos.filter { followingSellerIds.contains(it.sellerId) }
            "Trending" -> allVideos.sortedByDescending { it.likesCount + it.commentsCount }
            else -> allVideos
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (displayVideos.isEmpty()) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                Text("No shoppable videos in $feedFilter yet", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Spacer(Modifier.height(8.dp))
                Text("Switch to For You or follow more Nigerian sellers.", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.7f))
            }
        } else {
            val pagerState = rememberPagerState(pageCount = { displayVideos.size })
            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val video = displayVideos[page]
                val linkedProduct = allProducts.find { it.id == video.productId }
                val isFollowing = followingSellerIds.contains(video.sellerId)

                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = resolveDrawableRes(video.coverKey)),
                        contentDescription = video.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.45f),
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.88f)
                                    )
                                )
                            )
                    )

                    // Right action rail
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 12.dp, bottom = 146.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = { onLikeVideo(video.id) },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .testTag("video_like_${video.id}")
                            ) {
                                Icon(Icons.Default.Favorite, contentDescription = "Like video", tint = LiveCrimson)
                            }
                            Text(formatCompactCount(video.likesCount), style = MaterialTheme.typography.labelSmall, color = Color.White)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = {
                                    onSelectVideoForComments(video.id)
                                    commentSheetVideoId = video.id
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .testTag("video_comment_${video.id}")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Comment, contentDescription = "Comments", tint = Color.White)
                            }
                            Text(formatCompactCount(video.commentsCount), style = MaterialTheme.typography.labelSmall, color = Color.White)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = {
                                    val share = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "Watch ${video.title} on Cash N Carry: https://www.cashncarryng.com/reels/${video.id}")
                                    }
                                    context.startActivity(Intent.createChooser(share, "Share Video"))
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share video", tint = Color.White)
                            }
                            Text("Share", style = MaterialTheme.typography.labelSmall, color = Color.White)
                        }
                    }

                    // Bottom Info & Shoppable Product Card
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 74.dp, bottom = 18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "@${video.sellerName}",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(10.dp))
                            Surface(
                                color = if (isFollowing) Color.White.copy(alpha = 0.2f) else BrandEmerald,
                                shape = RoundedCornerShape(50),
                                modifier = Modifier.clickable { onToggleFollowSeller(video.sellerId) }
                            ) {
                                Text(
                                    text = if (isFollowing) "Following" else "Follow",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(video.title, style = MaterialTheme.typography.titleSmall, color = Color.White)
                        Text(video.caption, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f), maxLines = 2)
                        Spacer(Modifier.height(10.dp))

                        Surface(
                            color = Color.White.copy(alpha = 0.94f),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (linkedProduct != null) onOpenProduct(linkedProduct)
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(10.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(video.productTitle, style = MaterialTheme.typography.titleSmall, color = BrandSlate, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(formatNaira(video.productPriceNaira), style = MaterialTheme.typography.labelLarge, color = BrandEmerald, fontWeight = FontWeight.Bold)
                                }
                                if (linkedProduct != null) {
                                    if (linkedProduct.liveStreamId.isNotBlank()) {
                                        IconButton(onClick = { onWatchLive(linkedProduct.liveStreamId) }) {
                                            Icon(Icons.Default.LiveTv, contentDescription = "Watch Live", tint = LiveCrimson)
                                        }
                                    }
                                    IconButton(onClick = { onAddToCart(linkedProduct) }) {
                                        Icon(Icons.Default.AddShoppingCart, contentDescription = "Add to cart", tint = BrandEmerald)
                                    }
                                    Button(
                                        onClick = { onBuyNow(linkedProduct) },
                                        colors = ButtonDefaults.buttonColors(containerColor = BrandEmerald),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Text("Buy", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Top Feed Switcher Pills
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
        ) {
            listOf("Following", "For You", "Trending").forEach { tab ->
                FilterChip(
                    selected = feedFilter == tab,
                    onClick = { feedFilter = tab },
                    label = { Text(tab) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color.White,
                        selectedLabelColor = BrandSlate,
                        containerColor = Color.Black.copy(alpha = 0.5f),
                        labelColor = Color.White
                    )
                )
            }
        }
    }

    if (commentSheetVideoId != null) {
        val vid = commentSheetVideoId!!
        ModalBottomSheet(
            onDismissRequest = { commentSheetVideoId = null },
            containerColor = Color.White
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Video Comments", style = MaterialTheme.typography.titleLarge, color = BrandSlate)
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                ) {
                    if (activeVideoComments.isEmpty()) {
                        item {
                            Text("No comments yet. Ask the seller about sizing, delivery, or warranty!", color = BrandMuted)
                        }
                    } else {
                        items(activeVideoComments, key = { it.id }) { comment ->
                            Surface(
                                color = SurfaceSoft,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(comment.userName, style = MaterialTheme.typography.titleSmall, color = BrandSlate)
                                    Text(comment.text, style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newComment,
                        onValueChange = { newComment = it },
                        placeholder = { Text("Add a comment...") },
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            if (newComment.isNotBlank()) {
                                onCommentVideo(vid, newComment)
                                newComment = ""
                            }
                        }
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Post comment", tint = BrandEmerald)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
