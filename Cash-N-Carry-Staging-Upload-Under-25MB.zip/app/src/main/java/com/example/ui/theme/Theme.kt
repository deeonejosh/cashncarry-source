package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val CashNCarryLightScheme = lightColorScheme(
    primary = BrandEmerald,
    onPrimary = Color.White,
    primaryContainer = BrandEmeraldSoft,
    onPrimaryContainer = BrandEmeraldDark,
    secondary = BrandOrange,
    onSecondary = Color.White,
    secondaryContainer = BrandOrangeSoft,
    onSecondaryContainer = BrandOrange,
    tertiary = LiveCrimson,
    onTertiary = Color.White,
    tertiaryContainer = LiveCrimsonSoft,
    onTertiaryContainer = LiveCrimson,
    background = SurfaceWhite,
    onBackground = BrandSlate,
    surface = SurfaceWhite,
    onSurface = BrandSlate,
    surfaceVariant = SurfaceSoft,
    onSurfaceVariant = BrandMuted,
    outline = BrandBorder,
    outlineVariant = Color(0xFFF1F5F9),
    error = LiveCrimson,
    onError = Color.White
)

private val CashNCarryShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun CashNCarryTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CashNCarryLightScheme,
        typography = CashNCarryTypography,
        shapes = CashNCarryShapes,
        content = content
    )
}
