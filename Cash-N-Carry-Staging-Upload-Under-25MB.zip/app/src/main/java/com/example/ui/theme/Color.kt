package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cash N Carry Brand Palette (Forest Green + Vibrant Orange)
val BrandEmerald = Color(0xFF0E6B38)
val BrandEmeraldDark = Color(0xFF084B26)
val BrandEmeraldSoft = Color(0xFFEAF7EF)

val BrandOrange = Color(0xFFFF6B00)
val BrandOrangeBright = Color(0xFFFF8F1F)
val BrandOrangeSoft = Color(0xFFFFF4EB)

val BrandNavy = Color(0xFF093B22)
val BrandSlate = Color(0xFF0F172A)
val BrandMuted = Color(0xFF64748B)
val BrandBorder = Color(0xFFE5E7EB)

val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceSoft = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)

val LiveCrimson = Color(0xFFE11D48)
val LiveCrimsonSoft = Color(0xFFFFF1F2)
val FlashAmber = Color(0xFFFF6B00)
val FlashAmberSoft = Color(0xFFFFF4EB)
val GoldCoin = Color(0xFFF59E0B)
val PromoViolet = Color(0xFF6D28D9)

// Category Tile & Seller Header Accents
val CategoryFashion = Color(0xFFD61F4B)
val CategoryBeauty = Color(0xFFE02F7D)
val CategoryElectronics = Color(0xFFF59E0B)
val CategoryHome = Color(0xFF1A73E8)
val CategoryGroceries = Color(0xFF5C3409)
val CategoryMore = Color(0xFF6D28D9)
val SellerMagenta = Color(0xFFDF236E)
