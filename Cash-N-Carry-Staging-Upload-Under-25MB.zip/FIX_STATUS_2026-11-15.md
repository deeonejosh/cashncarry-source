# Cash N Carry — staging source repair report

**Date:** 2026-11-15  
**Input:** `Cash-N-Carry-Staging-Migration-0017-Fixed.zip`, based on user upload `cash-n-carry (2).zip`  
**Target:** Cloudflare staging Worker `cashncarry-d1-staging-worker` and D1 `cashncarry-d1-staging`; Android app ID `com.aistudio.cashncarry.vqmzkw`.

## Fixes made directly to integrated source files

1. **Android session restore:** `CloudflareSyncRepository.kt` now accepts `/api/auth/me` responses with a live `user` object and no `authenticated` field, matching the previously deployed Worker contract. It also checks server-provided ID/email/role rather than trusting stale cached identity/role values.
2. **Worker authentication contract:** `new-auth.ts` now explicitly returns `authenticated: true` on a valid `/api/auth/me` response and false for a missing session. It blocks mobile-header access to admin login and admin session checks.
3. **Android checkout guard:** `checkoutCart()` returns `PAYMENTS_DISABLED` before the network call when staging payments are off.
4. **API content type checking:** Android now rejects non-JSON HTTP 2xx SPA responses with `INVALID_RESPONSE`, instead of treating them as successful API calls.
5. **Session credential protection:** Android session storage no longer falls back to Base64 plaintext when Android Keystore fails. Old insecure/unprotected session entries are not restored. A keystore failure produces `SECURE_STORAGE_UNAVAILABLE`, not a silently insecure session. Tests use in-memory session state.
6. **Android auth gate:** `MainActivity.kt` no longer unlocks account-scoped screens solely from a cached token when the Worker is unreachable.
7. **Migration test repair:** `web/scripts/run-automated-tests.ts` now expects `0017_unified_mobile_sync.sql`, not the conflicting local `0011` number. Mobile-auth contract assertion also checks `authenticated: true`.
8. **Regression tests:** Updated Android Robolectric tests for valid Worker response shape, HTML fallback rejection and local no-network checkout guard; Worker smoke test now checks that a mobile-tagged admin login returns HTTP 403.
9. **Reproducible CI:** Added `.github/workflows/verify-integrated-staging.yml` for fresh web tests/build/Worker bundle, Android tests and APK artifact. It requires the **existing** debug keystore via a secure Actions secret; it never generates a replacement key. This workflow has **not** yet run on GitHub.
10. **Release instructions:** Added `STAGING_BUILD_AND_DEPLOY.md` with explicit staging-only steps, migration backup prerequisite and necessary auth email provider binding.
11. **Old Worker artifact:** Removed the prebuilt `web/dist/` output so nobody can deploy a stale bundle as though it contains these changes.

## Checks performed and actual results

| Check | Actual result |
|---|---|
| Offline source contract / security / migration tests | **9 passed** (`python3 -m unittest discover -s scripts -p 'test_*.py' -v`) |
| TypeScript syntax parsing | **101 files parsed**, 0 syntax errors (not a TypeScript type-check) |
| SQLite migration application | **0001–0010 + 0017 passed** in ephemeral SQLite; repeat of 0017 passed, 37 tables (not remote D1 execution) |
| Android Kotlin Firebase / Credential Manager scan | **0 matches** in Kotlin source and active Gradle/version files |
| Wrangler staging identity/flags | Source configuration matches expected staging name, D1 ID and disabled flags |
| Android signing configuration and application ID | Existing configuration unchanged |
| Deployed staging migration ledger | Read-only confirmed `0001`–`0016`; remote `0011` is `0011_wallet_guard.sql` |
| Existing staging Worker binding inspection | **Mismatch:** deployed `FLW_MODE=sandbox`, source requires disabled; deployed Worker lacks explicit `PAYMENTS_ENABLED`, `COINS_PURCHASES_ENABLED`, `KYC_UPLOADS_ENABLED` |
| Staging email configuration | **Blocked:** deployed Worker lists no secrets and no `AUTH_EMAIL` service binding, so email verification/reset delivery is not configured |
| `npm install`, `npm run lint`, `npm test`, fresh web bundle | **Not passed** in this environment (npm registry/network dependency access unavailable) |
| Android assembleDebug / Robolectric | **Not run**; Android SDK/Gradle distribution/original debug keystore unavailable here |
| Remote staging D1 backup, migration, Worker deployment | **Not performed**; cannot safely apply untested source/migrations without backup |
| GitHub staging branch update / GitHub Actions | **Not performed**; container cannot reach GitHub, integrated source has not been committed to remote branch |
| Installable staging APK | **Not produced** |

## Important notes

- Security-related session storage changes intentionally require users with previously stored plaintext-format credentials to sign in again.
- The delivered ZIP is an **updated source package**, not a verified release or an APK.
- Deployment of the current live Worker must not be considered fixed until the staging source passes a fresh build, the email provider is configured, backup is retained, and a staging-only deploy succeeds.
- No production Worker, DNS, production D1, or payment integration was modified. **No remote D1 writes or Worker deploys** were performed during this repair.
