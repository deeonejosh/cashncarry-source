CASH N CARRY STAGING - COMPACT UPLOAD

This ZIP contains all files from the repaired integrated staging source
EXCEPT the five nested ZIP backup/source archives under public/assets/aistudio/.
Those files were archived reference copies, not active Android or web source.
The extracted Android and Cloudflare web source, staging configuration,
D1 migration 0017 and GitHub workflow are preserved unchanged.

Original reference ZIP (keep as your backup):
Cash-N-Carry-Integrated-Staging-Source-Repaired-2026-11-15.zip

Excluded nested backups:
- public/assets/aistudio/Cash-N-Carry-Android-Integrated.zip (6,290,785 bytes)
- public/assets/aistudio/Cash-N-Carry-Web-Integrated-Cloudflare.zip (12,059,908 bytes)
- public/assets/aistudio/cash-n-carry-batch6_f50a3123.zip (6,353,823 bytes)
- public/assets/aistudio/cash-n-carry-nov-13-2026-10-09-42-pm_f646278e.zip (7,254,742 bytes)
- public/assets/aistudio/cash-n-carry-source__3__c657b719.zip (6,003,759 bytes)

IMPORTANT: Uploading a ZIP to GitHub does NOT extract it into the repository.
GitHub Actions must explicitly unzip this ZIP before running Gradle/npm builds,
or the extracted files must be uploaded separately.
No deployment, build, or signing verification is implied by this package.
