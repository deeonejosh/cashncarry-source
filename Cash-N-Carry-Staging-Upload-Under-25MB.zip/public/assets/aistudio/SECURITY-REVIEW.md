# Cash N Carry Nigeria — Security Review

## 1. Authentication & Session Isolation
- **Browser Cookie Sessions**: Maintained `__Host-cnc_session` (`Secure; HttpOnly; SameSite=Strict`) with SHA-256 token digests stored in `cnc_auth_sessions` (`new-auth.ts`). Password credentials use `@noble/hashes/scrypt` (`N=32768, r=8, p=3`) with 32-byte random per-user salts and constant-time digest comparison.
- **Mobile Bearer Token Isolation**:
  - `POST /api/auth/login` issues an opaque 64-hex Bearer token ONLY when `X-Client-Type: mobile` is supplied AND the user is an active, email-verified `buyer` or `seller`.
  - Bearer tokens are stored hashed (SHA-256) in `cnc_auth_sessions` (raw tokens are never stored in D1) and stored in private Android `SharedPreferences` (`Context.MODE_PRIVATE`).
  - `currentAccount(request, env, true)` (Admin MFA routes) unconditionally rejects any request bearing an `Authorization` header (`403`/`503`), and `CloudflareSessionStore` refuses to persist `"admin"` role tokens on Android.
- **CSRF & Origin Hardening (`hasValidMutationOrigin`)**:
  - Cookie-authenticated browser mutations across `unified-sync.ts`, `orders.ts`, `auctions.ts`, `coins.ts`, `marketplace.ts`, and `flutterwave.ts` strictly require `Origin === env.AUTH_ORIGIN`.
  - Mobile Bearer requests are immune to ambient browser cookie CSRF only when carrying both `Authorization: Bearer <64-hex>` AND `X-Client-Type: mobile`.

## 2. Fail-Closed Staging Safety Flags
Verified in `wrangler.jsonc`, `/api/health`, Miniflare automated tests, and Android `CloudflareSyncRepository`:
- `PAYMENTS_ENABLED = "false"` -> `/api/payments/initialize`, `/api/payments/webhooks/flutterwave`, and auction winner checkout return **`503 PAYMENTS_DISABLED`**.
- `COINS_PURCHASES_ENABLED = "false"` -> `/api/coins` credit minting returns **`503 COINS_DISABLED`**.
- `KYC_UPLOADS_ENABLED = "false"` -> `/api/sellers/kyc` POST fails closed with **`503 KYC_UPLOADS_DISABLED`**.
- `FLW_MODE = "disabled"` -> No simulated paid statuses or wallet credits are permitted in web UI or Android UI.

## 3. Data Privacy & Input Validation
- SQL queries across Cloudflare D1 use parameterized `.bind(...)` statements and explicit SQL `LIKE` wildcard escaping (`[\\%_]`).
- Ownership checks prevent cross-user tampering:
  - Addresses scoped to `user_id = account.id`
  - Live host actions (`pin`, `end`) verify `cnc_live_room_state.seller_id === account.id`
  - Seller order fulfilment verifies `JOIN cnc_order_items WHERE i.seller = account.id`
- Android uses `PasswordVisualTransformation()` on web-sync credential inputs, Google Play compliant Photo Picker / zero broad media storage permissions, and Firebase App Check (`configureAppCheck`).
