# Cash N Carry Nigeria — Staging & Production Deployment Guide

## 1. Deliverables Produced
- **Website Integrated Archive**: `Cash-N-Carry-Web-Integrated-Cloudflare.zip`
- **Android Integrated Archive**: `Cash-N-Carry-Android-Integrated.zip`
- **Android Debug/Staging APK**: `.build-outputs/app-debug.apk`
- **Documentation**: `WORKFLOW-COMPARISON.md`, `INTEGRATION-REPORT.md`, `API-CONTRACTS.md`, `DATABASE-MIGRATION-PLAN.md`, `TEST-RESULTS.md`, `SECURITY-REVIEW.md`

## 2. Deployment Gate Status
- **Live Staging & Production Untouched**: Per release policy, `wrangler deploy`, remote D1 schema mutations, and production domain changes were **NOT** executed from this build environment.
- Reason: Remote `cashncarry-d1-staging` holds migrations `0001`–`0016` while the base archive ended at `0010`; schema reconciliation (`0011_unified_mobile_sync.sql` -> `0017_unified_mobile_sync.sql` if `0011`–`0016` exist in `d1_migrations`) must be confirmed with a remote D1 snapshot before deploying.

## 3. Step-by-Step Staging Deployment (After Approval)
1. **Unpack Website Archive & Install Dependencies**:
   ```bash
   unzip Cash-N-Carry-Web-Integrated-Cloudflare.zip -d cnc-web-staging
   cd cnc-web-staging
   npm install --legacy-peer-deps
   ```
2. **Verify Local Build & Worker Test Suite**:
   ```bash
   npm run lint
   npm test
   npm run build
   npm run bundle:worker
   ```
3. **Reconcile & Back Up Staging D1 (`cashncarry-d1-staging`)**:
   - Follow `DATABASE-MIGRATION-PLAN.md`: export `staging-pre-unified-backup.sql`, verify `d1_migrations`, rename `0011_unified_mobile_sync.sql` to `0017_unified_mobile_sync.sql` if `0011`–`0016` are present remotely, then apply:
   ```bash
   wrangler d1 migrations apply cashncarry-d1-staging --remote
   ```
4. **Deploy Staging Worker (`cashncarry-d1-staging-worker`)**:
   ```bash
   wrangler deploy --env staging
   ```
   Confirm fail-closed flags on live `/api/health`:
   `paymentsEnabled: false`, `coinsPurchasesEnabled: false`, `kycUploadsEnabled: false`.

## 4. Android Staging Build & Release Preparation
1. Open the extracted `Cash-N-Carry-Android-Integrated.zip` workspace and verify `.env` / Secrets (no API keys committed in source).
2. Run verification suite:
   ```bash
   gradle :app:assembleDebug :app:testDebugUnitTest
   ```
3. Only after explicit staging sign-off and production credential/webhook verification should `PAYMENTS_ENABLED`, `COINS_PURCHASES_ENABLED`, or `KYC_UPLOADS_ENABLED` be enabled in Cloudflare secrets/vars.
