# Cash N Carry Nigeria — Database Migration & Reconciliation Plan

## 1. Staging Schema State Audit
- **Target Database**: Cloudflare D1 `cashncarry-d1-staging` (`9a2cdbee-e030-4b10-908b-b10b8142d2aa`)
- **Finding**: Live staging D1 currently has migrations up through `0016` applied from prior deployments, whereas Source A (`cash-n-carry-source__3__c657b719.zip`) contains migrations `0001_new_auth.sql` through `0010_catalog_schema_and_seed.sql`.
- **Action Taken**: New unified mobile/web schema extensions are isolated into a strictly additive migration `deploy/chatgpt-sites/migrations/0011_unified_mobile_sync.sql` using `CREATE TABLE IF NOT EXISTS` and `CREATE INDEX IF NOT EXISTS` **without altering any existing `cnc_orders`, `cnc_auth_users`, or trigger definitions** (`0004`, `0007`, `0008`).

## 2. Additive Tables Included in `0011_unified_mobile_sync.sql`
1. `cnc_user_profiles` (`user_id`, `display_name`, `bio`, `avatar_url`, `selected_state`, `updated_at`)
2. `cnc_wishlist` (`user_id`, `product_id`, `created`, composite PK)
3. `cnc_seller_follows` (`follower_id`, `seller_id`, `created`, composite PK)
4. `cnc_short_videos` (`id`, `seller_id`, `seller_name`, `product_id`, `title`, `caption`, `video_url`, `cover_url`, `likes_count`, `comments_count`, `created`)
5. `cnc_video_likes` (`video_id`, `user_id`, `created`, composite PK)
6. `cnc_video_comments` (`id`, `video_id`, `user_id`, `author_name`, `body`, `created`)
7. `cnc_live_room_state` (`room_id`, `seller_id`, `seller_name`, `title`, `category`, `status`, `viewer_count`, `hearts_count`, `pinned_product_id`, `stream_url`, `created`, `ended_at`)
8. `cnc_live_comments` (`id`, `room_id`, `user_id`, `author_name`, `body`, `is_reaction`, `created`)
9. `cnc_messages` (`id`, `sender_id`, `receiver_id`, `order_id`, `product_id`, `body`, `read_at`, `created`)
10. `cnc_notifications` (`id`, `user_id`, `title`, `body`, `kind`, `read_at`, `created`)
11. `cnc_product_reviews_buyer` (`id`, `product_id`, `user_id`, `author_name`, `rating`, `comment`, `created`)
12. `cnc_order_fulfilments` (`order_id`, `seller_id`, `status`, `carrier`, `tracking_number`, `updated_at`)

## 3. Safe Reconciliation Procedure Before Applying to Staging D1
**DO NOT run `wrangler d1 migrations apply` blindly before completing these verification steps:**
1. Export existing remote migration history and table schema from staging D1:
   ```bash
   wrangler d1 execute cashncarry-d1-staging --remote --command "SELECT name, applied_at FROM d1_migrations ORDER BY id;"
   wrangler d1 execute cashncarry-d1-staging --remote --command "SELECT name, type FROM sqlite_master WHERE type IN ('table','trigger') ORDER BY name;"
   ```
2. Capture an on-demand D1 snapshot/export before schema changes:
   ```bash
   wrangler d1 export cashncarry-d1-staging --remote --output=staging-pre-unified-backup.sql
   ```
3. Check whether any table names in `0011_unified_mobile_sync.sql` overlap with `0011`–`0016` on remote staging. If `0011`–`0016` already exist in `d1_migrations`, rename `0011_unified_mobile_sync.sql` -> `0017_unified_mobile_sync.sql` prior to `wrangler d1 migrations apply --remote`.
4. Verify post-migration row integrity across `cnc_orders`, `categories`, `products`, and `d1_migrations`.
