# Cash N Carry Nigeria — Unified API Contracts

**Base URL (Staging Worker)**: `https://cashncarry-d1-staging-worker.cashncarry-workforce-2026.workers.dev`
**Auth Modes**:
- **Web**: Cookie `__Host-cnc_session` (`HttpOnly`, `SameSite=Strict`) + matching `Origin` header on mutations.
- **Mobile**: Headers `X-Client-Type: mobile` + `Authorization: Bearer <64-hex-token>` (buyer/seller roles only).

## 1. Health & Feature Flags
- **`GET /api/health`**
  - Response `200`: `{ ok, service, environment, dbConnected, authDbConnected, authenticated, user: { id, email, role } | null, staging: { paymentsEnabled, coinsPurchasesEnabled, kycUploadsEnabled, orderReservationsEnabled, streamConfigured, r2Configured } }`

## 2. Authentication
- **`POST /api/auth/register`** — Body: `{ email }` -> `202 { accepted: true }`
- **`POST /api/auth/verify`** — Body: `{ token, password, role: "buyer" | "seller" }` -> `200 { completed: true }`
- **`POST /api/auth/login`** — Body: `{ email, password }`
  - Web: sets `__Host-cnc_session`, returns `{ signedIn: true, user }`.
  - Mobile (`X-Client-Type: mobile`): returns `{ signedIn: true, token, expiresInSeconds: 28800, user }`. Rejects `admin` role (`401`).
- **`POST /api/auth/request-reset`** / **`POST /api/auth/reset`**
- **`POST /api/auth/logout`** — Invalidates active session hash in `cnc_auth_sessions`.
- **`GET /api/auth/me`** — Returns `{ authenticated, user }`.

## 3. Unified Profile, Addresses, Wishlist & Follows (`/api/v1/*`)
- **`GET /api/v1/profile`** — Returns buyer/seller `display_name`, `bio`, `avatar_url`, `selected_state`, `email`, `role`.
- **`PUT /api/v1/profile`** — Body: `{ displayName, bio, avatarUrl, selectedState }` -> Upserts `cnc_user_profiles`.
- **`GET / POST / DELETE /api/v1/addresses`** — Manage saved Nigerian delivery addresses (all 37 states supported).
- **`GET / POST /api/v1/wishlist`** — Body `{ productId }` toggles `cnc_wishlist` (`201` added / `200` removed).
- **`GET / POST /api/v1/follows`** — Body `{ sellerId }` toggles `cnc_seller_follows`.

## 4. Short Videos & Livestreams
- **`GET /api/v1/videos`** — Public list of latest shoppable clips (`cnc_short_videos`).
- **`POST /api/v1/videos`** — Authenticated seller publish `{ title, productId, caption, coverUrl, videoUrl }`.
- **`POST /api/v1/videos/like`** — Authenticated toggle `{ videoId }`.
- **`GET / POST /api/v1/videos/comments`** — Comment thread (`video_id`).
- **`GET /api/v1/live`** — Active & recent live rooms (`cnc_live_room_state`).
- **`POST / PATCH /api/v1/live`** — Seller start broadcast, pin product, end stream; buyer `like` or `join`.
- **`GET / POST /api/v1/live/comments`** — Live room chat (`room_id`).

## 5. Catalog, Cart, Orders, Auctions & Fail-Closed Financial Guards
- **`GET /api/categories`**, **`GET /api/products`**, **`GET /api/storefronts/:id`**
- **`POST /api/cart`** — Body `{ id, quantity, source }`
- **`POST /api/checkout`** — Body `{ request_id, address_id }` (idempotent `request_id` key)
- **`GET /api/v1/seller/orders`** & **`POST /api/v1/seller/orders/fulfil`** — Seller order status + carrier tracking updates (`GIG Logistics`, `Kwik Delivery`, etc.)
- **`GET / PATCH /api/auctions`** — Bid placement `{ action: 'bid', id, amountKobo }`; `{ action: 'checkout' }` returns **`503 PAYMENTS_DISABLED`** in staging.
- **`GET / POST /api/coins`** — Gift spending (`{ action: 'gift', ... }`); credit minting returns **`503 COINS_DISABLED`** in staging.
- **`GET / POST /api/sellers/kyc`** — Upload returns **`503 KYC_UPLOADS_DISABLED`** in staging.
- **`POST /api/payments/initialize`** & **`POST /api/payments/webhooks/flutterwave`** — Return **`503 PAYMENTS_DISABLED`** in staging.

## 6. Messaging, Notifications & Reviews
- **`GET / POST / PATCH /api/v1/messages`** — Buyer-to-seller messaging & read receipts.
- **`GET / PATCH /api/v1/notifications`** — Fetch & mark read.
- **`GET / POST /api/v1/reviews`** — Product star rating (1–5) & comment.
