# Cash N Carry — integrated staging release instructions

This source ZIP contains the Android project at the root and Cloudflare/Vite/Worker project in `web/`. Do not upload the ZIP itself into the former ZIP-based Android workflow without replacing that workflow's extraction logic.

## 1. Build without changing production

Create or update the GitHub `feature/openai-chat-staging` branch with the **extracted project files**, not merely this ZIP or the old `cash-n-carry-android-build-source.zip`. Remove superseded Android patch scripts and workflows that would reintroduce Firebase. The included `.github/workflows/verify-integrated-staging.yml` performs source checks, web tests, Worker bundling, Android tests, and APK assembly; it does **not** deploy anything.

Provide repository Actions secret `CNC_DEBUG_KEYSTORE_BASE64` containing **the existing Android debug.keystore** encoded as base64, or keep the unchanged `debug.keystore` in the build environment. The workflow deliberately refuses to generate a new key. Preserve `signingConfigs` and `applicationId`.

Run locally when dependencies are available:

```sh
python3 -m unittest discover -s scripts -p 'test_*.py' -v
cd web
npm install --legacy-peer-deps --no-audit --no-fund
npm run lint
npm test
npm run build
npm run bundle:worker
test -s dist/_worker.js
node deploy/chatgpt-sites/worker-smoke.mjs
node deploy/chatgpt-sites/new-auth-smoke.mjs
cd ..
gradle :app:assembleDebug :app:testDebugUnitTest
```

## 2. Fix current staging binding drift before end-to-end authentication

Current deployed staging Worker settings (read 2026-11-15) include `FLW_MODE=sandbox`, but the source requires `FLW_MODE=disabled`. Currently deployed settings lack explicit `PAYMENTS_ENABLED`, `COINS_PURCHASES_ENABLED`, and `KYC_UPLOADS_ENABLED` binding values. Do not copy existing deployed bindings back into the source.

Current Worker has **no secret bindings** and no `AUTH_EMAIL` service binding. Therefore live registration and password-reset email delivery cannot be verified or expected to work. Configure `AUTH_RESEND_API_KEY` (secret) and `AUTH_EMAIL_FROM` (verified sender), or provision an authorized `AUTH_EMAIL` service binding, for **staging only**. Never commit secrets into the ZIP or GitHub. Do not weaken the Worker to expose verification/reset tokens in API responses.

## 3. Back up and migrate staging D1 (only after tests pass)

Target staging D1: `cashncarry-d1-staging`, database ID `9a2cdbee-e030-4b10-908b-b10b8142d2aa`.

The deployed `d1_migrations` contains `0001`–`0016`, including `0011_wallet_guard.sql`. The only new schema file is `web/deploy/chatgpt-sites/migrations/0017_unified_mobile_sync.sql`. Before applying it, **download and securely retain a complete staging D1 export** and check the remote migration list. Consult the Wrangler version's export syntax, e.g. `npx wrangler d1 export cashncarry-d1-staging --remote --env staging --output=./staging-backup.sql`. Avoid committing backups, especially if they contain accounts or personal data. Review migration SQL for additive-only changes, then run:

```sh
cd web
npx wrangler d1 migrations list cashncarry-d1-staging --remote --env staging
npx wrangler d1 migrations apply cashncarry-d1-staging --remote --env staging
```

Do not apply migrations against production. Never rerun older local `0011` migration over remote `0011_wallet_guard.sql`.

## 4. Staging Worker only

After tests and backup, with staging-only Cloudflare credentials, run from `web/`:

```sh
npx wrangler deploy --env staging
```

Verify `/api/health` returns JSON with `dbConnected=true`, `authDbConnected=true` and payment/coin/KYC flags false. Run browser + Android registration, verification, login, session restoration, reset, cart, wishlist, and admin-block tests using dedicated staging accounts. Do not infer the API works from an HTML SPA fallback. Never change production worker, routes, DNS, or live payment settings.

## Verification limits

The local environment used for this repair has no reachable npm registry, Android SDK, Gradle distribution, or original debug keystore. It ran **offline source contract checks** and **SQLite schema checks**, not a fresh web bundle, Miniflare suite, Robolectric tests, staging D1 migration, or APK compilation. The included `web/dist/_worker.js` is an OLD artifact, not built from these changes.
