# Livestream redesign design QA

**Source visual truth**

- Seller studio reference: `/workspace/scratch/a88885a4d833/generated_images/exec-53e0faed-1913-4b68-b3fd-a4a8da4359d2.png` (853 × 1844 px).
- Buyer viewer reference with viewer count: `/workspace/scratch/a88885a4d833/generated_images/exec-20563d00-4daa-42d7-af2e-854c2d43e008.png` (853 × 1844 px).

**Implementation target**

- Project: `cashncarry-site-sync`, seller studio at `/workspace?studio=1` and buyer viewer at the live stream route.
- Intended mobile viewport: 393 × 852 CSS px.
- Implementation screenshot: not captured.
- Browser comparison: blocked. `sites-preview start` reports a different Vinext dev server at `/site` owns preview port 4173; the preview service could not start this project. Direct Vite on 4174 is blocked by the cloud browser. No screenshot from the modified implementation is available.
- State: seller private preflight and active stream; buyer active stream.
- Density normalization: not possible without the implementation screenshot. Source art is 853 × 1844 px; its CSS capture size and device scale are unspecified.

**Evidence and comparison**

- Full-view comparison: not performed because the rendered implementation could not be opened.
- Focused comparison: not performed for the same reason.
- Interactions tested: automated livestream controls and stream API tests; no rendered browser interactions.
- Console errors: not checked because the modified page could not be opened in the browser.
- Typography, spacing/layout rhythm, colors/tokens, image quality, and app-specific copy: not visually assessed. Code changes use existing product assets and existing Cash N Carry styles; that is not a substitute for rendered comparison.

**Findings**

- Visual acceptance is blocked pending a browser-rendered screenshot of the updated seller and buyer stream screens at the target mobile viewport. The preview port conflict must be resolved before comparing, fixing visual differences, and verifying key controls.

**Implementation checklist**

- [x] Add explicit viewer counts on both buyer and seller screens.
- [x] Add seller private preflight fields and device/configuration status.
- [x] Add stream-scoped flash-deal and auction cards with live countdowns.
- [x] Run automated tests and production build.
- [ ] Capture updated screens in the cloud browser at 393 × 852.
- [ ] Compare source and rendered screens, address P0/P1/P2 differences, and verify primary interactions and console.

final result: blocked
