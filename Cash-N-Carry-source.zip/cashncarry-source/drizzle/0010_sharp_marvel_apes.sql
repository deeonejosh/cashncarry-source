CREATE TABLE `live_blocks` (
	`stream` text NOT NULL,
	`user` text NOT NULL,
	PRIMARY KEY(`stream`, `user`),
	FOREIGN KEY (`stream`) REFERENCES `streams`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `live_viewers` (
	`stream` text NOT NULL,
	`session` text NOT NULL,
	`seen` text NOT NULL,
	PRIMARY KEY(`stream`, `session`),
	FOREIGN KEY (`stream`) REFERENCES `streams`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `live_viewers_seen` ON `live_viewers` (`seen`);--> statement-breakpoint
ALTER TABLE `streams` ADD `featured` text DEFAULT '[]' NOT NULL;