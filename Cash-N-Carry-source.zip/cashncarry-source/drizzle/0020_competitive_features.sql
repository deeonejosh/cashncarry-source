CREATE TABLE livestream_deals ( id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), product TEXT NOT NULL REFERENCES products(id), stream TEXT NOT NULL REFERENCES streams(id), promo_price INTEGER NOT NULL CHECK(promo_price>0), max_quantity INTEGER NOT NULL CHECK(max_quantity>0), sold_quantity INTEGER NOT NULL DEFAULT 0 CHECK(sold_quantity>=0), starts_at TEXT NOT NULL, ends_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','active','ended','cancelled','disabled')), created TEXT NOT NULL, updated TEXT NOT NULL, CHECK(ends_at>starts_at) );
--> statement-breakpoint
CREATE INDEX live_deals_stream_status ON livestream_deals(stream,status,starts_at,ends_at);
--> statement-breakpoint
CREATE TRIGGER live_deal_insert_guard BEFORE INSERT ON livestream_deals WHEN NOT EXISTS(SELECT 1 FROM products p JOIN streams s ON s.id=NEW.stream WHERE p.id=NEW.product AND p.store=NEW.store AND s.store=NEW.store AND NEW.promo_price<p.price AND NEW.max_quantity<=p.stock) BEGIN SELECT RAISE(ABORT,'Live deal product, price or quantity is invalid'); END;
--> statement-breakpoint
CREATE TRIGGER live_deal_insert_overlap_guard BEFORE INSERT ON livestream_deals WHEN NEW.status IN ('active','scheduled') AND EXISTS(SELECT 1 FROM livestream_deals d WHERE d.product=NEW.product AND d.stream=NEW.stream AND d.status IN ('active','scheduled') AND d.starts_at<NEW.ends_at AND d.ends_at>NEW.starts_at) BEGIN SELECT RAISE(ABORT,'Overlapping livestream deal'); END;
--> statement-breakpoint
CREATE TRIGGER live_deal_update_guard BEFORE UPDATE ON livestream_deals WHEN NEW.status IN ('active','scheduled') AND NOT EXISTS(SELECT 1 FROM products p JOIN streams s ON s.id=NEW.stream WHERE p.id=NEW.product AND p.store=NEW.store AND s.store=NEW.store AND NEW.promo_price<p.price AND NEW.max_quantity<=p.stock) BEGIN SELECT RAISE(ABORT,'Live deal product, price or quantity is invalid'); END;
--> statement-breakpoint
CREATE TRIGGER live_deal_update_overlap_guard BEFORE UPDATE ON livestream_deals WHEN NEW.status IN ('active','scheduled') AND EXISTS(SELECT 1 FROM livestream_deals d WHERE d.id!=NEW.id AND d.product=NEW.product AND d.stream=NEW.stream AND d.status IN ('active','scheduled') AND d.starts_at<NEW.ends_at AND d.ends_at>NEW.starts_at) BEGIN SELECT RAISE(ABORT,'Overlapping livestream deal'); END;
--> statement-breakpoint
CREATE TABLE seller_analytics_events ( id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), product TEXT NOT NULL DEFAULT '', stream TEXT NOT NULL DEFAULT '', visitor TEXT NOT NULL, event TEXT NOT NULL CHECK(event IN ('product_view','store_view','livestream_view','product_click','add_to_cart','buy_now','checkout_start','livestream_like','follow')), day TEXT NOT NULL, order_id TEXT NOT NULL DEFAULT '', created TEXT NOT NULL );
--> statement-breakpoint
CREATE UNIQUE INDEX seller_analytics_daily_dedupe ON seller_analytics_events(store,product,stream,visitor,event,day);
--> statement-breakpoint
CREATE INDEX seller_analytics_store_day ON seller_analytics_events(store,day,event);
--> statement-breakpoint
CREATE TABLE livestream_peak_metrics (stream TEXT NOT NULL REFERENCES streams(id),day TEXT NOT NULL,peak_viewers INTEGER NOT NULL DEFAULT 0,sampled_at TEXT NOT NULL,PRIMARY KEY(stream,day));
--> statement-breakpoint
CREATE TABLE product_bundles ( id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), product TEXT NOT NULL UNIQUE REFERENCES products(id), title TEXT NOT NULL, description TEXT NOT NULL, image TEXT NOT NULL, price INTEGER NOT NULL CHECK(price>0), active INTEGER NOT NULL DEFAULT 0 CHECK(active IN (0,1)), created TEXT NOT NULL, updated TEXT NOT NULL );
--> statement-breakpoint
CREATE INDEX product_bundles_store_active ON product_bundles(store,active);
--> statement-breakpoint
CREATE TABLE product_bundle_items ( bundle TEXT NOT NULL REFERENCES product_bundles(id), product TEXT NOT NULL REFERENCES products(id), quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 99), name_snapshot TEXT NOT NULL, price_snapshot INTEGER NOT NULL CHECK(price_snapshot>0), PRIMARY KEY(bundle,product) );
--> statement-breakpoint
CREATE TRIGGER bundle_component_owner_guard BEFORE INSERT ON product_bundle_items WHEN NOT EXISTS(SELECT 1 FROM product_bundles b JOIN products p ON p.id=NEW.product WHERE b.id=NEW.bundle AND p.store=b.store AND p.id!=b.product AND p.active=1 AND json_array_length(p.variants)=0) BEGIN SELECT RAISE(ABORT,'Invalid bundle component'); END;
--> statement-breakpoint
CREATE TABLE bundle_order_snapshots ( order_id TEXT NOT NULL REFERENCES orders(id), bundle TEXT NOT NULL, title TEXT NOT NULL, contents TEXT NOT NULL, bundle_price INTEGER NOT NULL, PRIMARY KEY(order_id,bundle) );
--> statement-breakpoint
CREATE TABLE order_deal_snapshots ( order_id TEXT NOT NULL REFERENCES orders(id), deal TEXT NOT NULL REFERENCES livestream_deals(id), product TEXT NOT NULL REFERENCES products(id), quantity INTEGER NOT NULL, price INTEGER NOT NULL, PRIMARY KEY(order_id,deal) );
--> statement-breakpoint
CREATE TABLE order_stream_snapshots (order_id TEXT NOT NULL REFERENCES orders(id),stream TEXT NOT NULL REFERENCES streams(id),product TEXT NOT NULL REFERENCES products(id),PRIMARY KEY(order_id,product));
--> statement-breakpoint
CREATE TRIGGER order_deal_validate BEFORE INSERT ON order_deal_snapshots WHEN NOT EXISTS(SELECT 1 FROM livestream_deals d WHERE d.id=NEW.deal AND d.product=NEW.product AND d.promo_price=NEW.price AND NEW.quantity>0 AND d.status IN ('active','scheduled') AND d.starts_at<=strftime('%Y-%m-%dT%H:%M:%fZ','now') AND d.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now') AND d.sold_quantity+NEW.quantity<=d.max_quantity) BEGIN SELECT RAISE(ABORT,'Live deal expired or promotional quantity unavailable'); END;
--> statement-breakpoint
CREATE TRIGGER order_deal_reserve AFTER INSERT ON order_deal_snapshots BEGIN UPDATE livestream_deals SET sold_quantity=sold_quantity+NEW.quantity,updated=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=NEW.deal; END;
--> statement-breakpoint
CREATE TRIGGER order_deal_restock AFTER UPDATE OF status ON orders WHEN NEW.status='cancelled' AND OLD.status!='cancelled' BEGIN UPDATE livestream_deals SET sold_quantity=MAX(0,sold_quantity-COALESCE((SELECT SUM(quantity) FROM order_deal_snapshots WHERE order_id=NEW.id AND deal=livestream_deals.id),0)),updated=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id IN (SELECT deal FROM order_deal_snapshots WHERE order_id=NEW.id); END;
--> statement-breakpoint
CREATE TRIGGER bundle_component_stock_guard BEFORE INSERT ON order_items WHEN EXISTS(SELECT 1 FROM product_bundles b WHERE b.product=NEW.product AND b.active=1) AND EXISTS(SELECT 1 FROM product_bundle_items bi JOIN products p ON p.id=bi.product WHERE bi.bundle=(SELECT id FROM product_bundles WHERE product=NEW.product) AND (p.active!=1 OR p.stock<bi.quantity*NEW.quantity OR json_array_length(p.variants)>0)) BEGIN SELECT RAISE(ABORT,'Bundle component stock changed'); END;
--> statement-breakpoint
CREATE TRIGGER bundle_component_stock_decrement AFTER INSERT ON order_items WHEN EXISTS(SELECT 1 FROM product_bundles WHERE product=NEW.product AND active=1) BEGIN UPDATE products SET stock=stock-COALESCE((SELECT SUM(bi.quantity*NEW.quantity) FROM product_bundle_items bi JOIN product_bundles b ON b.id=bi.bundle WHERE b.product=NEW.product AND b.active=1 AND bi.product=products.id),0) WHERE id IN (SELECT bi.product FROM product_bundle_items bi JOIN product_bundles b ON b.id=bi.bundle WHERE b.product=NEW.product AND b.active=1); END;
--> statement-breakpoint
CREATE TRIGGER bundle_stock_recalc AFTER UPDATE OF stock ON products WHEN EXISTS(SELECT 1 FROM product_bundle_items WHERE product=NEW.id) BEGIN UPDATE products SET stock=COALESCE((SELECT MIN(CAST(p.stock/bi.quantity AS INTEGER)) FROM product_bundle_items bi JOIN product_bundles b ON b.id=bi.bundle JOIN products p ON p.id=bi.product WHERE b.product=products.id AND b.active=1),0) WHERE id IN (SELECT b.product FROM product_bundles b JOIN product_bundle_items bi ON bi.bundle=b.id WHERE bi.product=NEW.id AND b.active=1); END;
--> statement-breakpoint
CREATE TRIGGER bundle_component_restock AFTER UPDATE OF status ON orders WHEN NEW.status='cancelled' AND OLD.status!='cancelled' BEGIN UPDATE products SET stock=stock+COALESCE((SELECT SUM(i.quantity*CAST(json_extract(component.value,'$.quantity') AS INTEGER)) FROM bundle_order_snapshots bos JOIN order_items i ON i.order_id=bos.order_id AND i.product=(SELECT product FROM product_bundles WHERE id=bos.bundle) JOIN json_each(bos.contents) component WHERE bos.order_id=NEW.id AND json_extract(component.value,'$.id')=products.id),0) WHERE id IN (SELECT json_extract(component.value,'$.id') FROM bundle_order_snapshots bos JOIN order_items i ON i.order_id=bos.order_id AND i.product=(SELECT product FROM product_bundles WHERE id=bos.bundle) JOIN json_each(bos.contents) component WHERE bos.order_id=NEW.id); END;
--> statement-breakpoint
CREATE TABLE creator_profiles ( user TEXT PRIMARY KEY, display_name TEXT NOT NULL, social_links TEXT NOT NULL DEFAULT '[]', categories TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','suspended')), note TEXT NOT NULL DEFAULT '', created TEXT NOT NULL, updated TEXT NOT NULL );
--> statement-breakpoint
CREATE TABLE affiliate_partnerships ( id TEXT PRIMARY KEY, creator TEXT NOT NULL REFERENCES creator_profiles(user), store TEXT NOT NULL REFERENCES stores(id), product TEXT NOT NULL REFERENCES products(id), commission_bps INTEGER NOT NULL CHECK(commission_bps BETWEEN 0 AND 3000), status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','revoked','suspended')), created TEXT NOT NULL, updated TEXT NOT NULL, UNIQUE(creator,product) );
--> statement-breakpoint
CREATE INDEX affiliate_store_status ON affiliate_partnerships(store,status);
--> statement-breakpoint
CREATE TABLE affiliate_clicks ( id TEXT PRIMARY KEY, partnership TEXT NOT NULL REFERENCES affiliate_partnerships(id), visitor TEXT NOT NULL, created TEXT NOT NULL, UNIQUE(partnership,visitor) );
--> statement-breakpoint
CREATE TABLE affiliate_commissions ( id TEXT PRIMARY KEY, partnership TEXT NOT NULL REFERENCES affiliate_partnerships(id), order_id TEXT NOT NULL REFERENCES orders(id), amount INTEGER NOT NULL CHECK(amount>=0), status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','reversed','eligible','paid')), created TEXT NOT NULL, updated TEXT NOT NULL, UNIQUE(partnership,order_id) );
--> statement-breakpoint
CREATE TRIGGER affiliate_commission_reconcile AFTER UPDATE OF status,payment_status ON orders BEGIN UPDATE affiliate_commissions SET status=CASE WHEN NEW.status='cancelled' OR NEW.payment_status IN ('failed','refunded') THEN 'reversed' WHEN NEW.status='delivered' AND EXISTS(SELECT 1 FROM payments pay WHERE pay.order_id=NEW.id AND pay.mode='live' AND pay.status='paid') THEN 'eligible' WHEN NEW.payment_status='paid' AND EXISTS(SELECT 1 FROM payments pay WHERE pay.order_id=NEW.id AND pay.mode='live' AND pay.status='paid') THEN 'confirmed' ELSE status END,updated=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE order_id=NEW.id; END;
--> statement-breakpoint
CREATE TABLE live_auctions ( id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), product TEXT NOT NULL REFERENCES products(id), stream TEXT NOT NULL REFERENCES streams(id), start_price INTEGER NOT NULL CHECK(start_price>0), increment INTEGER NOT NULL CHECK(increment>0), reserve_price INTEGER CHECK(reserve_price IS NULL OR reserve_price>0), starts_at TEXT NOT NULL, ends_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','active','ended','cancelled','suspended')), winning_bid TEXT NOT NULL DEFAULT '', order_id TEXT NOT NULL DEFAULT '', created TEXT NOT NULL, updated TEXT NOT NULL, CHECK(ends_at>starts_at) );
--> statement-breakpoint
CREATE INDEX live_auctions_stream_status ON live_auctions(stream,status,ends_at);
--> statement-breakpoint
CREATE TABLE auction_bids ( id TEXT PRIMARY KEY, auction TEXT NOT NULL REFERENCES live_auctions(id), bidder TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), request_id TEXT NOT NULL UNIQUE, created TEXT NOT NULL );
--> statement-breakpoint
CREATE INDEX auction_bids_rank ON auction_bids(auction,amount,created);
--> statement-breakpoint
CREATE TABLE founding_program ( id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)), duration_days INTEGER NOT NULL DEFAULT 30 CHECK(duration_days BETWEEN 1 AND 365), max_participants INTEGER NOT NULL DEFAULT 100 CHECK(max_participants BETWEEN 1 AND 100000), eligibility TEXT NOT NULL DEFAULT 'Verified sellers approved by an administrator.', updated TEXT NOT NULL );
--> statement-breakpoint
INSERT OR IGNORE INTO founding_program(id,enabled,duration_days,max_participants,eligibility,updated) VALUES(1,0,30,100,'Verified sellers approved by an administrator.',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
--> statement-breakpoint
INSERT OR IGNORE INTO platform_settings(key,value,updated) VALUES('seller_subscription_mode','test',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
--> statement-breakpoint
CREATE TABLE founding_enrollments ( id TEXT PRIMARY KEY, store TEXT NOT NULL UNIQUE REFERENCES stores(id), status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','revoked','expired')), starts_at TEXT NOT NULL DEFAULT '', ends_at TEXT NOT NULL DEFAULT '', approved_by TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '', created TEXT NOT NULL, updated TEXT NOT NULL );
--> statement-breakpoint
CREATE INDEX founding_enrollments_status_end ON founding_enrollments(status,ends_at);
--> statement-breakpoint
DROP TRIGGER seller_new_order_activation;
--> statement-breakpoint
CREATE TRIGGER seller_new_order_activation BEFORE INSERT ON orders WHEN NEW.seller_activation_required=1 AND NOT EXISTS ( SELECT 1 FROM stores s WHERE s.id=NEW.store AND s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.id=s.owner AND p.suspended=1) AND (EXISTS(SELECT 1 FROM seller_subscriptions ss WHERE ss.store=s.id AND ss.mode=COALESCE((SELECT value FROM platform_settings WHERE key='seller_subscription_mode'),'test') AND ss.status='active' AND ss.paid_until>strftime('%Y-%m-%dT%H:%M:%fZ','now')) OR EXISTS(SELECT 1 FROM founding_enrollments fe JOIN founding_program fp ON fp.id=1 WHERE fe.store=s.id AND fp.enabled=1 AND fe.status='active' AND fe.starts_at<=strftime('%Y-%m-%dT%H:%M:%fZ','now') AND fe.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now'))) ) BEGIN SELECT RAISE(ABORT,'Seller activation expired or verification missing'); END;
--> statement-breakpoint
DROP TRIGGER item_stock_guard;
--> statement-breakpoint
CREATE TRIGGER item_stock_guard BEFORE INSERT ON order_items WHEN NEW.quantity<=0 OR NOT EXISTS(SELECT 1 FROM products p WHERE p.id=NEW.product AND p.active=1 AND ((NEW.variant='' AND json_array_length(p.variants)=0 AND ((p.price=NEW.price AND p.stock>=NEW.quantity) OR (EXISTS(SELECT 1 FROM orders o JOIN live_auctions a ON a.order_id=o.id JOIN auction_bids b ON b.id=a.winning_bid WHERE o.id=NEW.order_id AND o.payment='auction' AND a.status='ended' AND a.product=p.id AND b.amount=NEW.price) AND p.stock>=NEW.quantity) OR (EXISTS(SELECT 1 FROM order_deal_snapshots ds JOIN livestream_deals d ON d.id=ds.deal WHERE ds.order_id=NEW.order_id AND ds.product=p.id AND ds.price=NEW.price AND ds.quantity=NEW.quantity AND d.product=p.id AND d.status IN ('active','scheduled')) AND p.stock>=NEW.quantity))) OR (NEW.variant!='' AND EXISTS(SELECT 1 FROM json_each(p.variants) v WHERE json_extract(v.value,'$.name')=NEW.variant AND json_extract(v.value,'$.price')=NEW.price AND json_extract(v.value,'$.stock')>=NEW.quantity)))) BEGIN SELECT RAISE(ABORT,'Stock or price changed'); END;
