CREATE TABLE storefronts (
  store TEXT PRIMARY KEY NOT NULL REFERENCES stores(id),
  slug TEXT NOT NULL UNIQUE,
  logo TEXT NOT NULL DEFAULT '',
  banner TEXT NOT NULL DEFAULT '',
  template TEXT NOT NULL DEFAULT 'market',
  accent TEXT NOT NULL DEFAULT '#164B35',
  featured_products TEXT NOT NULL DEFAULT '[]',
  published INTEGER NOT NULL DEFAULT 0,
  updated TEXT NOT NULL
);
CREATE UNIQUE INDEX storefronts_slug ON storefronts(slug);
ALTER TABLE storefronts ADD display_name TEXT NOT NULL DEFAULT '';
ALTER TABLE storefronts ADD description TEXT NOT NULL DEFAULT '';
ALTER TABLE storefronts ADD category TEXT NOT NULL DEFAULT '';

CREATE TABLE videos (
  id TEXT PRIMARY KEY NOT NULL,
  store TEXT NOT NULL REFERENCES stores(id),
  owner TEXT NOT NULL,
  media TEXT NOT NULL,
  thumbnail TEXT NOT NULL DEFAULT '',
  caption TEXT NOT NULL DEFAULT '',
  hashtags TEXT NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'draft',
  published INTEGER NOT NULL DEFAULT 0,
  created TEXT NOT NULL,
  updated TEXT NOT NULL,
  moderation_note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX videos_feed ON videos(status,published,created);
CREATE INDEX videos_store ON videos(store,created);

CREATE TABLE video_products (
  video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  product TEXT NOT NULL REFERENCES products(id),
  PRIMARY KEY(video,product)
);
CREATE INDEX video_products_product ON video_products(product);

CREATE TABLE video_likes (
  video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user TEXT NOT NULL,
  created TEXT NOT NULL,
  PRIMARY KEY(video,user)
);
CREATE TABLE video_saves (
  video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user TEXT NOT NULL,
  created TEXT NOT NULL,
  PRIMARY KEY(video,user)
);
CREATE TABLE video_comments (
  id TEXT PRIMARY KEY NOT NULL,
  video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user TEXT NOT NULL,
  parent TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL,
  hidden INTEGER NOT NULL DEFAULT 0,
  created TEXT NOT NULL
);
CREATE INDEX video_comments_visible ON video_comments(video,hidden,created);
CREATE TABLE video_events (
  id TEXT PRIMARY KEY NOT NULL,
  video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  visitor TEXT NOT NULL,
  kind TEXT NOT NULL,
  day TEXT NOT NULL,
  created TEXT NOT NULL,
  UNIQUE(video,visitor,kind,day)
);
CREATE INDEX video_events_video ON video_events(video,kind,created);

CREATE TABLE video_moderation_history (
  id TEXT PRIMARY KEY NOT NULL,
  video TEXT NOT NULL REFERENCES videos(id),
  actor TEXT NOT NULL,
  status TEXT NOT NULL,
  note TEXT NOT NULL,
  created TEXT NOT NULL
);
