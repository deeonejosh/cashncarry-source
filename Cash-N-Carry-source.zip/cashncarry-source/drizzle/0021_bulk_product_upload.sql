ALTER TABLE products ADD COLUMN sku TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
CREATE UNIQUE INDEX products_store_sku ON products(store, lower(sku)) WHERE sku != '';
--> statement-breakpoint
CREATE TABLE seller_product_imports (
  id TEXT PRIMARY KEY,
  store TEXT NOT NULL REFERENCES stores(id),
  fingerprint TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'processing' CHECK(status IN ('processing','completed','partial')),
  total INTEGER NOT NULL DEFAULT 0,
  imported INTEGER NOT NULL DEFAULT 0,
  failed INTEGER NOT NULL DEFAULT 0,
  duplicates INTEGER NOT NULL DEFAULT 0,
  created TEXT NOT NULL,
  updated TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX seller_product_imports_store_created ON seller_product_imports(store, created DESC);
--> statement-breakpoint
CREATE TABLE seller_product_import_rows (
  import_id TEXT NOT NULL REFERENCES seller_product_imports(id),
  row_number INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('imported','failed','duplicate')),
  sku TEXT NOT NULL DEFAULT '',
  product_name TEXT NOT NULL DEFAULT '',
  product_id TEXT NOT NULL DEFAULT '',
  source_key TEXT NOT NULL DEFAULT '',
  errors TEXT NOT NULL DEFAULT '[]',
  created TEXT NOT NULL,
  PRIMARY KEY(import_id, row_number)
);
--> statement-breakpoint
CREATE UNIQUE INDEX seller_product_import_rows_source_key ON seller_product_import_rows(source_key) WHERE source_key!='' AND status='imported';
