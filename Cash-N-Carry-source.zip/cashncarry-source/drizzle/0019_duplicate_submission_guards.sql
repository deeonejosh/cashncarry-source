CREATE TRIGGER verification_single_pending_insert BEFORE INSERT ON verification_requests
WHEN NEW.status='pending' AND EXISTS(SELECT 1 FROM verification_requests WHERE store=NEW.store AND status='pending')
BEGIN SELECT RAISE(ABORT,'Application already pending review'); END;
--> statement-breakpoint
CREATE TRIGGER seller_bank_duplicate_insert BEFORE INSERT ON seller_banks
WHEN EXISTS(SELECT 1 FROM seller_banks WHERE id<>NEW.id AND store=NEW.store AND mode=NEW.mode AND bank_code=NEW.bank_code AND account_number=NEW.account_number)
BEGIN SELECT RAISE(ABORT,'Bank account already saved'); END;
