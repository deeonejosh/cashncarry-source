CREATE TABLE `cart_resumptions` (
	`id` text PRIMARY KEY NOT NULL,
	`user` text NOT NULL,
	`product` text NOT NULL,
	`variant` text NOT NULL,
	`quantity` integer NOT NULL,
	`created` text NOT NULL
);
