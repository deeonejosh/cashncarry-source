CREATE TABLE `auth_two_factor` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`secret` text NOT NULL,
	`backup_codes` text NOT NULL,
	`verified` integer DEFAULT false NOT NULL,
	`failed_verification_count` integer DEFAULT 0 NOT NULL,
	`locked_until` integer,
	FOREIGN KEY (`user_id`) REFERENCES `auth_user`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `two_factor_user` ON `auth_two_factor` (`user_id`);--> statement-breakpoint
ALTER TABLE `auth_user` ADD `two_factor_enabled` integer DEFAULT false NOT NULL;--> statement-breakpoint
CREATE TRIGGER admin_audit_no_update BEFORE UPDATE ON admin_audit BEGIN SELECT RAISE(ABORT, 'Audit records are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER admin_audit_no_delete BEFORE DELETE ON admin_audit BEGIN SELECT RAISE(ABORT, 'Audit records are append-only'); END;
--> statement-breakpoint
INSERT OR IGNORE INTO policies(id,title,content,reviewed,updated) VALUES('community','Community and Livestream Rules','OWNER REVIEW REQUIRED. Define truthful livestream commerce, prohibited content, reporting, moderation, replay/privacy handling and appeals. Complete operator identity, eligibility and monitored appeal contact before approval.',0,'2026-10-10');
