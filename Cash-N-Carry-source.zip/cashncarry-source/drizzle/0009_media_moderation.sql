CREATE TABLE media_blocks (key TEXT PRIMARY KEY NOT NULL,created TEXT NOT NULL);
--> statement-breakpoint
INSERT OR IGNORE INTO media_blocks SELECT substr(url,instr(url,'/api/media/')+11),datetime('now') FROM (SELECT image AS url FROM products WHERE active=0 UNION ALL SELECT video FROM products WHERE active=0 UNION ALL SELECT j.value FROM products p,json_each(p.images) j WHERE p.active=0) WHERE instr(url,'/api/media/')>0 AND substr(url,instr(url,'/api/media/')+11)!='';
--> statement-breakpoint
CREATE TRIGGER product_media_block AFTER UPDATE OF active ON products WHEN NEW.active=0 AND OLD.active=1 BEGIN
INSERT OR IGNORE INTO media_blocks SELECT substr(url,instr(url,'/api/media/')+11),datetime('now') FROM (SELECT OLD.image AS url UNION ALL SELECT OLD.video UNION ALL SELECT value FROM json_each(OLD.images)) WHERE instr(url,'/api/media/')>0 AND substr(url,instr(url,'/api/media/')+11)!='';
END;
--> statement-breakpoint
CREATE TRIGGER product_media_guard_insert BEFORE INSERT ON products WHEN NEW.active=1 AND EXISTS(SELECT 1 FROM (SELECT NEW.image AS url UNION ALL SELECT NEW.video UNION ALL SELECT value FROM json_each(NEW.images)) JOIN media_blocks ON media_blocks.key=substr(url,instr(url,'/api/media/')+11) WHERE instr(url,'/api/media/')>0) BEGIN SELECT RAISE(ABORT,'Media removed from public listings; admin review required'); END;
--> statement-breakpoint
CREATE TRIGGER product_media_guard_update BEFORE UPDATE ON products WHEN NEW.active=1 AND EXISTS(SELECT 1 FROM (SELECT NEW.image AS url UNION ALL SELECT NEW.video UNION ALL SELECT value FROM json_each(NEW.images)) JOIN media_blocks ON media_blocks.key=substr(url,instr(url,'/api/media/')+11) WHERE instr(url,'/api/media/')>0) BEGIN SELECT RAISE(ABORT,'Media removed from public listings; admin review required'); END;
