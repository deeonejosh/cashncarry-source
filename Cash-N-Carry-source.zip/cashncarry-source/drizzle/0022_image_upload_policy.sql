ALTER TABLE upload_usage ADD COLUMN image_count INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE upload_usage ADD COLUMN image_bytes INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE upload_usage ADD COLUMN image_reserved_count INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE upload_usage ADD COLUMN image_reserved_bytes INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
UPDATE upload_usage SET image_count=count,image_bytes=bytes;
--> statement-breakpoint
CREATE TABLE media_upload_requests (
  id TEXT PRIMARY KEY,
  user TEXT NOT NULL,
  day TEXT NOT NULL,
  bytes INTEGER NOT NULL,
  content_hash TEXT NOT NULL DEFAULT '',
  media_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL CHECK(status IN ('reserved','completed','failed','stale','rejected')),
  created TEXT NOT NULL,
  updated TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX media_upload_requests_cleanup ON media_upload_requests(status,created);
--> statement-breakpoint
CREATE UNIQUE INDEX media_upload_requests_owner_hash ON media_upload_requests(user,content_hash) WHERE content_hash!='' AND status='completed';
