ALTER TABLE `profiles` ADD `username` text;--> statement-breakpoint
CREATE UNIQUE INDEX `profiles_username_unique` ON `profiles` (`username`);