CREATE TABLE `policy_versions` (
	`id` text PRIMARY KEY NOT NULL,
	`policy_id` text NOT NULL,
	`version` integer NOT NULL,
	`title` text NOT NULL,
	`content` text NOT NULL,
	`status` text NOT NULL DEFAULT 'draft' CHECK (`status` IN ('draft','pending_review','approved','published')),
	`created_by` text NOT NULL,
	`created_by_email` text NOT NULL,
	`created_at` text NOT NULL,
	`submitted_at` text,
	`approved_by` text,
	`approved_by_email` text,
	`approved_at` text,
	`published_by` text,
	`published_by_email` text,
	`published_at` text,
	`effective_date` text,
	`reason` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `policy_versions_policy_version` ON `policy_versions` (`policy_id`,`version`);
--> statement-breakpoint
CREATE INDEX `policy_versions_status` ON `policy_versions` (`policy_id`,`status`,`version`);
--> statement-breakpoint
CREATE TABLE `policy_acceptances` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL REFERENCES `auth_user`(`id`),
	`policy_id` text NOT NULL,
	`version` integer NOT NULL,
	`accepted_at` text NOT NULL,
	UNIQUE (`user_id`,`policy_id`,`version`)
);
--> statement-breakpoint
CREATE INDEX `policy_acceptances_policy_version` ON `policy_acceptances` (`policy_id`,`version`,`accepted_at`);
--> statement-breakpoint
CREATE TRIGGER `policy_versions_no_delete_published` BEFORE DELETE ON `policy_versions` WHEN OLD.status='published' BEGIN SELECT RAISE(ABORT, 'Published policy versions are immutable'); END;
--> statement-breakpoint
CREATE TRIGGER `policy_versions_status_transitions` BEFORE UPDATE ON `policy_versions`
WHEN OLD.status='published' OR NOT (
	(OLD.status='draft' AND NEW.status='pending_review') OR
	(OLD.status='pending_review' AND NEW.status='approved') OR
	(OLD.status='approved' AND NEW.status='published')
)
BEGIN SELECT RAISE(ABORT, 'Invalid policy version transition'); END;
