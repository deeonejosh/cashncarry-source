CREATE TRIGGER item_stock_guard BEFORE INSERT ON order_items
WHEN NEW.quantity <= 0 OR NOT EXISTS (
 SELECT 1 FROM products WHERE id=NEW.product AND active=1 AND price=NEW.price AND stock >= NEW.quantity
)
BEGIN SELECT RAISE(ABORT,'Stock or price changed'); END;
--> statement-breakpoint
CREATE TRIGGER item_stock_decrement AFTER INSERT ON order_items
BEGIN UPDATE products SET stock=stock-NEW.quantity WHERE id=NEW.product; END;
