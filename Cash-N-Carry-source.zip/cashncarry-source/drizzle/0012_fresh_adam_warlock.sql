CREATE TABLE `stream_likes` (
	`stream` text NOT NULL,
	`user` text NOT NULL,
	`created` text NOT NULL,
	PRIMARY KEY(`stream`, `user`)
);
