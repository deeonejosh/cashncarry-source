CREATE TABLE `campaign_events` (
	`id` text PRIMARY KEY NOT NULL,
	`campaign` text NOT NULL,
	`visitor` text NOT NULL,
	`kind` text NOT NULL,
	`day` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `campaign_event_once` ON `campaign_events` (`campaign`,`visitor`,`kind`,`day`);