CREATE TRIGGER verification_review_once BEFORE UPDATE OF status ON verification_requests WHEN OLD.status!='pending' BEGIN SELECT RAISE(ABORT,'Application already reviewed'); END;
