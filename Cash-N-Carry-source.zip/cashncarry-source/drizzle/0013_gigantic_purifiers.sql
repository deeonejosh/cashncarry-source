CREATE TABLE `email_suppressions` (
	`recipient` text PRIMARY KEY NOT NULL,
	`reason` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `email_webhook_events` (
	`id` text PRIMARY KEY NOT NULL,
	`provider_id` text NOT NULL,
	`type` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
ALTER TABLE `email_outbox` ADD `provider_id` text;--> statement-breakpoint
ALTER TABLE `email_outbox` ADD `delivery_status` text DEFAULT 'unknown' NOT NULL;--> statement-breakpoint
ALTER TABLE `email_outbox` ADD `last_error` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `email_outbox` ADD `template` text DEFAULT 'notification' NOT NULL;