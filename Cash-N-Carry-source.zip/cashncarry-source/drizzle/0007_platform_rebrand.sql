-- Rebrand platform-owned policy wording only. Preserve seller content, commerce records and integration identifiers.
UPDATE policies SET title=replace(replace(replace(title,'ReVibe','Cash N Carry'),'Revibe','Cash N Carry'),'REVIBE','Cash N Carry'),content=replace(replace(replace(content,'ReVibe','Cash N Carry'),'Revibe','Cash N Carry'),'REVIBE','Cash N Carry');
