CREATE TABLE `upload_usage` (
	`user` text NOT NULL,
	`day` text NOT NULL,
	`bytes` integer DEFAULT 0 NOT NULL,
	`count` integer DEFAULT 0 NOT NULL,
	PRIMARY KEY(`user`, `day`)
);
--> statement-breakpoint
ALTER TABLE `email_outbox` ADD `first_attempt` text;--> statement-breakpoint
ALTER TABLE `email_outbox` ADD `lease_token` text;--> statement-breakpoint
ALTER TABLE `email_outbox` ADD `retry_at` text;--> statement-breakpoint
CREATE INDEX `email_outbox_delivery` ON `email_outbox` (`status`,`retry_at`,`updated`);--> statement-breakpoint
CREATE INDEX `products_catalog` ON `products` (`active`,`created`,`id`);