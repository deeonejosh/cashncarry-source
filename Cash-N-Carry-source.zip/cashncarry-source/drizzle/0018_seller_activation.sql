CREATE TABLE seller_subscriptions (
 store TEXT NOT NULL REFERENCES stores(id), mode TEXT NOT NULL CHECK(mode IN ('test','live')),
 status TEXT NOT NULL DEFAULT 'inactive', paid_until TEXT NOT NULL DEFAULT '', cancel_at_end INTEGER NOT NULL DEFAULT 0,
 provider_subscription TEXT NOT NULL DEFAULT '', provider_plan TEXT NOT NULL DEFAULT '', customer_email TEXT NOT NULL DEFAULT '',
 updated TEXT NOT NULL, PRIMARY KEY(store,mode)
);
--> statement-breakpoint
CREATE TABLE seller_subscription_payments (
 id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), owner TEXT NOT NULL, mode TEXT NOT NULL CHECK(mode IN ('test','live')),
 amount_minor INTEGER NOT NULL CHECK(amount_minor>0), status TEXT NOT NULL DEFAULT 'pending', provider_id TEXT NOT NULL DEFAULT '',
 provider_plan TEXT NOT NULL DEFAULT '', recurring INTEGER NOT NULL DEFAULT 0, link TEXT NOT NULL DEFAULT '',
 customer_email TEXT NOT NULL, terms_version TEXT NOT NULL, created TEXT NOT NULL, updated TEXT NOT NULL,
 period_start TEXT NOT NULL DEFAULT '', period_end TEXT NOT NULL DEFAULT ''
);
--> statement-breakpoint
CREATE UNIQUE INDEX seller_subscription_charge_unique ON seller_subscription_payments(mode,provider_id) WHERE provider_id!='';
--> statement-breakpoint
CREATE TABLE seller_banks (
 id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), mode TEXT NOT NULL, bank_code TEXT NOT NULL,
 bank_name TEXT NOT NULL, account_number TEXT NOT NULL, account_name TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'resolved', note TEXT NOT NULL DEFAULT '', created TEXT NOT NULL, updated TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE seller_earnings_releases (
 id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), payment TEXT NOT NULL REFERENCES payments(id), mode TEXT NOT NULL,
 amount_minor INTEGER NOT NULL CHECK(amount_minor>0), settlement_reference TEXT NOT NULL,
 evidence TEXT NOT NULL, actor TEXT NOT NULL, created TEXT NOT NULL, UNIQUE(payment)
);
--> statement-breakpoint
CREATE TABLE seller_adjustments (
 id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), mode TEXT NOT NULL,
 amount_minor INTEGER NOT NULL CHECK(amount_minor<0), reference TEXT NOT NULL UNIQUE, reason TEXT NOT NULL, actor TEXT NOT NULL, created TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE seller_withdrawals (
 id TEXT PRIMARY KEY, store TEXT NOT NULL REFERENCES stores(id), mode TEXT NOT NULL,
 bank TEXT NOT NULL REFERENCES seller_banks(id), amount_minor INTEGER NOT NULL CHECK(amount_minor>0), fee_minor INTEGER NOT NULL CHECK(fee_minor>=0),
 status TEXT NOT NULL DEFAULT 'requested' CHECK(status IN ('requested','under_review','processing','paid','failed','cancelled')),
 provider_id TEXT NOT NULL DEFAULT '', reference TEXT NOT NULL UNIQUE, note TEXT NOT NULL DEFAULT '', created TEXT NOT NULL, updated TEXT NOT NULL
);
--> statement-breakpoint
CREATE VIEW seller_released_credits AS
 SELECT r.id,r.store,r.mode,r.payment, MAX(0,r.amount_minor-COALESCE((SELECT CAST(ROUND(SUM(f.amount)*100) AS INTEGER) FROM refunds f WHERE f.payment=p.id AND f.status IN ('completed','refunded')),0)) AS amount_minor
 FROM seller_earnings_releases r JOIN payments p ON p.id=r.payment JOIN orders o ON o.id=p.order_id
 WHERE p.mode=r.mode AND p.status='paid' AND o.payment_status='paid' AND o.status='delivered'
 AND NOT EXISTS (SELECT 1 FROM refunds f WHERE f.payment=p.id AND f.status NOT IN ('rejected','failed','completed','refunded'))
 AND NOT EXISTS (SELECT 1 FROM reports t WHERE t.target=o.id AND t.target_type IN ('order','return') AND t.status IN ('open','in_review'));
--> statement-breakpoint
CREATE TRIGGER seller_withdrawal_balance BEFORE INSERT ON seller_withdrawals
 WHEN NEW.amount_minor+NEW.fee_minor >
 COALESCE((SELECT SUM(amount_minor) FROM seller_released_credits WHERE store=NEW.store AND mode=NEW.mode),0)
 +COALESCE((SELECT SUM(amount_minor) FROM seller_adjustments WHERE store=NEW.store AND mode=NEW.mode),0)
 -COALESCE((SELECT SUM(amount_minor+fee_minor) FROM seller_withdrawals WHERE store=NEW.store AND mode=NEW.mode AND status NOT IN ('failed','cancelled')),0)
 BEGIN SELECT RAISE(ABORT,'Insufficient reconciled earnings'); END;
--> statement-breakpoint
CREATE TRIGGER seller_release_no_update BEFORE UPDATE ON seller_earnings_releases BEGIN SELECT RAISE(ABORT,'Financial releases are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER seller_release_no_delete BEFORE DELETE ON seller_earnings_releases BEGIN SELECT RAISE(ABORT,'Financial releases are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER seller_adjustment_no_update BEFORE UPDATE ON seller_adjustments BEGIN SELECT RAISE(ABORT,'Adjustments are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER seller_adjustment_no_delete BEFORE DELETE ON seller_adjustments BEGIN SELECT RAISE(ABORT,'Adjustments are append-only'); END;
--> statement-breakpoint
CREATE TRIGGER seller_withdrawal_amount_immutable BEFORE UPDATE OF store,mode,bank,amount_minor,fee_minor,reference ON seller_withdrawals BEGIN SELECT RAISE(ABORT,'Withdrawal amounts and destinations are immutable'); END;
--> statement-breakpoint
DROP TRIGGER verification_review_once;
--> statement-breakpoint
CREATE TRIGGER verification_review_once BEFORE UPDATE OF status ON verification_requests WHEN OLD.status NOT IN ('pending','more_information') BEGIN SELECT RAISE(ABORT,'Application already reviewed'); END;
--> statement-breakpoint
ALTER TABLE verification_requests ADD seller_type TEXT NOT NULL DEFAULT 'individual';
--> statement-breakpoint
ALTER TABLE verification_requests ADD contact_email TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE verification_requests ADD contact_phone TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE verification_requests ADD appeal TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
INSERT OR IGNORE INTO platform_settings(key,value,updated) VALUES('seller_monthly_minor','200000','2026-10-12'),('seller_price_confirmed','0','2026-10-12'),('seller_withdrawal_fee_minor','0','2026-10-12'),('seller_release_days','7','2026-10-12'),('seller_fund_flow','unconfirmed','2026-10-12');
--> statement-breakpoint
ALTER TABLE orders ADD delivered_at TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
CREATE TRIGGER seller_delivery_stamp AFTER UPDATE OF status ON orders WHEN NEW.status='delivered' AND OLD.status!='delivered' BEGIN UPDATE orders SET delivered_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=NEW.id; END;
--> statement-breakpoint
ALTER TABLE orders ADD seller_activation_required INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
CREATE TRIGGER seller_new_order_activation BEFORE INSERT ON orders
 WHEN NEW.seller_activation_required=1 AND NOT EXISTS (
 SELECT 1 FROM stores s JOIN seller_subscriptions ss ON ss.store=s.id WHERE s.id=NEW.store AND s.verified=1 AND s.suspended=0 AND ss.status='active' AND ss.paid_until>strftime('%Y-%m-%dT%H:%M:%fZ','now')
 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.id=s.owner AND p.suspended=1)
 ) BEGIN SELECT RAISE(ABORT,'Seller activation expired or verification missing'); END;
--> statement-breakpoint
INSERT INTO policy_versions(id,policy_id,version,title,content,status,created_by,created_by_email,created_at,reason)
 SELECT 'seller-monetisation-draft-2026-10-12','sellers',COALESCE(MAX(version),0)+1,'Seller Terms — subscription and payout draft',
 COALESCE((SELECT content FROM policy_versions WHERE policy_id='sellers' AND status='published' ORDER BY version DESC LIMIT 1),(SELECT content FROM policies WHERE id='sellers'),'') || char(10) || char(10) ||
 'DRAFT ADDENDUM — OWNER AND LEGAL REVIEW REQUIRED. Proposed Cash N Carry Seller plan: NGN 2,000 per calendar month, configurable before live billing. Verification and an active paid subscription are required to publish listings, accept new orders or broadcast. Individual sellers may provide identity evidence without CAC registration; registered businesses supply applicable registration and representative evidence. Verification is human reviewed and may require additional information. Subscription payments require independent provider verification. Current sandbox implementation uses manual renewal; cancellation retains access until the paid period ends. Automatic renewal is unavailable pending provider capability confirmation. Expiry pauses new selling without deleting listings or preventing fulfilment of existing orders. Seller earnings are accounting records, not a stored-value wallet. Buyer payment confirmation is not proof of processor settlement. Any future withdrawal model requires provider marketplace approval, reconciled settlement, verified bank ownership, a documented holding period, fees, reserves, dispute and refund handling, and authorised administrative review. Direct provider settlements must not be represented as withdrawable platform funds. Live billing and payouts remain disabled. Before publication, the owner must confirm operator registration and merchant eligibility, tax and consumer obligations, data retention, price and fee disclosures, withdrawal timelines, cancellation and refund rights, complaints and appeal channels, and the actual fund-flow model.',
 'draft','implementation','',strftime('%Y-%m-%dT%H:%M:%fZ','now'),'Draft seller monetisation terms; no live billing or payout approval implied' FROM policy_versions WHERE policy_id='sellers';
