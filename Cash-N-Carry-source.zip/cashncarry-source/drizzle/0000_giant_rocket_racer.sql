CREATE TABLE `campaigns` (
	`id` text PRIMARY KEY NOT NULL,
	`store` text NOT NULL,
	`title` text NOT NULL,
	`goal` text NOT NULL,
	`budget` integer NOT NULL,
	`days` integer NOT NULL,
	`location` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `carts` (
	`id` text PRIMARY KEY NOT NULL,
	`user` text NOT NULL,
	`product` text NOT NULL,
	`quantity` integer NOT NULL,
	FOREIGN KEY (`product`) REFERENCES `products`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `carts_user_product` ON `carts` (`user`,`product`);--> statement-breakpoint
CREATE TABLE `chats` (
	`id` text PRIMARY KEY NOT NULL,
	`stream` text NOT NULL,
	`user` text NOT NULL,
	`name` text NOT NULL,
	`message` text NOT NULL,
	`created` text NOT NULL,
	FOREIGN KEY (`stream`) REFERENCES `streams`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `chats_stream` ON `chats` (`stream`,`created`);--> statement-breakpoint
CREATE TABLE `follows` (
	`id` text PRIMARY KEY NOT NULL,
	`user` text NOT NULL,
	`store` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `follows_user_store` ON `follows` (`user`,`store`);--> statement-breakpoint
CREATE TABLE `order_items` (
	`id` text PRIMARY KEY NOT NULL,
	`order_id` text NOT NULL,
	`product` text NOT NULL,
	`name` text NOT NULL,
	`price` integer NOT NULL,
	`quantity` integer NOT NULL,
	FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `items_order` ON `order_items` (`order_id`);--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`buyer` text NOT NULL,
	`store` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`address` text NOT NULL,
	`total` integer NOT NULL,
	`status` text DEFAULT 'placed' NOT NULL,
	`payment` text DEFAULT 'cash_on_delivery' NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `orders_buyer` ON `orders` (`buyer`);--> statement-breakpoint
CREATE INDEX `orders_store` ON `orders` (`store`);--> statement-breakpoint
CREATE TABLE `products` (
	`id` text PRIMARY KEY NOT NULL,
	`store` text NOT NULL,
	`name` text NOT NULL,
	`description` text NOT NULL,
	`category` text NOT NULL,
	`price` integer NOT NULL,
	`stock` integer NOT NULL,
	`image` text NOT NULL,
	`video` text DEFAULT '' NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`created` text NOT NULL,
	FOREIGN KEY (`store`) REFERENCES `stores`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "products_stock_nonnegative" CHECK("products"."stock" >= 0),
	CONSTRAINT "products_price_positive" CHECK("products"."price" > 0)
);
--> statement-breakpoint
CREATE INDEX `products_store` ON `products` (`store`);--> statement-breakpoint
CREATE TABLE `reviews` (
	`id` text PRIMARY KEY NOT NULL,
	`buyer` text NOT NULL,
	`product` text NOT NULL,
	`order_id` text NOT NULL,
	`name` text NOT NULL,
	`rating` integer NOT NULL,
	`comment` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `reviews_buyer_product_order` ON `reviews` (`buyer`,`product`,`order_id`);--> statement-breakpoint
CREATE TABLE `stores` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`category` text NOT NULL,
	`location` text NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `stores_owner` ON `stores` (`owner`);--> statement-breakpoint
CREATE TABLE `streams` (
	`id` text PRIMARY KEY NOT NULL,
	`store` text NOT NULL,
	`title` text NOT NULL,
	`url` text NOT NULL,
	`product` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'live' NOT NULL,
	`created` text NOT NULL,
	FOREIGN KEY (`store`) REFERENCES `stores`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `streams_store` ON `streams` (`store`);--> statement-breakpoint
CREATE TRIGGER order_transition_guard BEFORE UPDATE OF status ON orders
WHEN NOT ((OLD.status='placed' AND NEW.status IN ('confirmed','cancelled')) OR (OLD.status='confirmed' AND NEW.status IN ('shipped','cancelled')) OR (OLD.status='shipped' AND NEW.status='delivered'))
BEGIN SELECT RAISE(ABORT,'Invalid order transition'); END;
--> statement-breakpoint
CREATE TRIGGER order_cancel_restock AFTER UPDATE OF status ON orders WHEN NEW.status='cancelled'
BEGIN UPDATE products SET stock=stock+COALESCE((SELECT SUM(quantity) FROM order_items WHERE order_id=NEW.id AND product=products.id),0) WHERE id IN (SELECT product FROM order_items WHERE order_id=NEW.id); END;
