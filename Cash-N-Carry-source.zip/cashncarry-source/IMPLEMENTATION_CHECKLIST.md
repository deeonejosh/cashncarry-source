# Cash N Carry upgrade checklist

The existing Vinext/React/Cloudflare Worker, D1, R2 and Sites hosting are retained. Applied migrations remain immutable. Existing working products, uploads, cart, cash-on-delivery orders, reviews, follows, location filtering and order transitions are preserved.

## Audit findings
- Public customer authentication was absent; only ChatGPT sign-in existed.
- Consumer account, saved addresses, favourites and notification preferences were absent.
- Product variants, seller delivery coverage/fees, pagination and sorting were absent.
- Managed native livestream broadcasting and scheduled/replay states were absent.
- Flutterwave initiation, server verification, webhook deduplication and refunds were absent.
- Admin and document-verification work was in progress, not yet published.
- Policies, operational runbooks, rate limiting and backup documentation were absent.
- Previous browser evidence was missing. Native browser inspection now validates desktop rendering/navigation/filter/empty states; full signed and phone-device journeys still require verification.

## Implementation
- [x] Protected admin, verification evidence and customer reports.
- [x] Public email accounts, verified-email sessions, password reset and transactional email adapter.
- [x] Product variants, images, delivery rules and single-seller checkout.
- [x] Catalog sorting/pagination and Nigerian state/area filters.
- [x] Profiles, addresses, favourites and notification preferences.
- [x] Managed Cloudflare Stream adapters, schedule/replay retrieval and TikTok outbound links (provider credentials and real device tests remain gated).
- [x] Flutterwave test-mode initiation, verification, signed webhook processing, reservation/release and refunds.
- [x] Ad submissions, placements, dates, pricing and sponsored delivery conditions.
- [x] Admin category/featured/settings management and payment/refund oversight.
- [x] Editable policies and owner-review flags.
- [x] Rate limiting, logs, migrations and backup/restore runbook.
- [x] Automated API/media/provider-fixture checks; desktop browser rendering and filter checks. Signed and phone/provider journeys remain release gates.
- [x] Built and published privately; live D1 schema confirmed. Service blockers documented in README.

## Release gate
The result must not be described as ready to accept real customers/payments until public access, real identity flows, provider credentials, live merchant checkout and critical browser journeys have been validated. Never simulate provider payments, payouts, live viewers, reviews or verified badges.
