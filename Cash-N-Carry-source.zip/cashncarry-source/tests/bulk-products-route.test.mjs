import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import { sourceModule } from "./load-route.mjs";
import { onboardFixtureSellers } from "./seller-fixture.mjs";
import { parseBulkProductWorkbook } from "../app/bulk-product-parser.mjs";

const db = new DatabaseSync(":memory:");
for (const file of readdirSync("drizzle").filter((name) => name.endsWith(".sql")).sort()) db.exec(readFileSync("drizzle/" + file, "utf8"));
class Query {
  constructor(sql, args = []) { this.sql = sql; this.args = args; }
  bind(...args) { return new Query(this.sql, args); }
  async all() { return { results: db.prepare(this.sql).all(...this.args) }; }
  async first() { return db.prepare(this.sql).get(...this.args) || null; }
  async run() { return { meta: { changes: Number(db.prepare(this.sql).run(...this.args).changes) } }; }
}
globalThis.bulkProductsEnv = {
  FLW_MODE: "test",
  DB: {
    prepare: (sql) => new Query(sql),
    async batch(statements) {
      db.exec("BEGIN");
      try { const results = []; for (const statement of statements) results.push(await statement.run()); db.exec("COMMIT"); return results; }
      catch (error) { db.exec("ROLLBACK"); throw error; }
    },
  },
};
globalThis.bulkProductsUser = null;
const api = await import(sourceModule("app/api/seller/bulk-products/route.ts", "bulkProductsEnv", "bulkProductsUser"));
const makeRequest = (body, user = "seller", origin = "https://cashncarry.test") => {
  globalThis.bulkProductsUser = user ? { userId: user, email: `${user}@test.invalid`, displayName: user } : null;
  return new Request(origin + "/api/seller/bulk-products", { method: "POST", headers: { origin, "Content-Type": "application/json" }, body: JSON.stringify(body) });
};
const sample = (values = {}) => ({ rowNumber: 2, name: "Cotton shirt", description: "Breathable cotton shirt", category: "Fashion", price: 2500, sku: "SHIRT-001", stock: 8, image: "https://images.example.org/shirt.jpg", images: [], status: "Draft", ...values });

test("seller preview validates real categories, price, image sources, duplicate SKU and server-owned access", async () => {
  db.exec("INSERT INTO stores(id,owner,name,category,location,verified,created) VALUES('bulk-store','seller','Seller shop','Fashion','Lagos',1,'now'),('other-store','other','Other shop','Fashion','Lagos',1,'now'); INSERT OR IGNORE INTO categories(id,name,active) VALUES('cat-fashion','Fashion',1),('cat-tech','Tech',1); INSERT INTO seller_subscriptions(store,mode,status,paid_until,updated) VALUES('bulk-store','test','active','2999-01-01T00:00:00Z','now'),('other-store','test','active','2999-01-01T00:00:00Z','now');");
  onboardFixtureSellers(db);
  db.prepare("UPDATE stores SET verified=0 WHERE id='other-store'").run();
  db.prepare("INSERT INTO products(id,store,name,sku,description,category,price,stock,image,created) VALUES('existing','bulk-store','Existing','TAKEN-1','x','Fashion',1000,1,'https://images.example.org/a.jpg','now')").run();
  const response = await api.POST(makeRequest({ action: "preview", rows: [sample(), sample({ rowNumber: 3, sku: "taken-1" }), sample({ rowNumber: 4, sku: "DUP" }), sample({ rowNumber: 5, sku: "dup" }), sample({ rowNumber: 6, price: 99 }), sample({ rowNumber: 7, image: "https://127.0.0.1/private.jpg" }), sample({ rowNumber: 8, category: "Unknown" })] }));
  assert.equal(response.status, 200);
  const preview = await response.json();
  assert.equal(preview.canImport, true);
  assert.equal(preview.rows[0].statusCode, "ready");
  assert.equal(preview.rows[1].statusCode, "duplicate");
  assert.equal(preview.rows[3].statusCode, "duplicate");
  assert.match(preview.rows[4].errors.join(" "), /at least ₦100/);
  assert.match(preview.rows[5].errors.join(" "), /public hostname/);
  assert.match(preview.rows[6].errors.join(" "), /active Cash N Carry category/);
  const repeatedRow = await api.POST(makeRequest({ action: "preview", rows: [sample({ rowNumber: 2, sku: "ROW-TEST-1" }), sample({ rowNumber: 2, sku: "ROW-TEST-2" })] }));
  const repeatedPreview = await repeatedRow.json();
  assert.notEqual(repeatedPreview.rows[0].rowNumber, repeatedPreview.rows[1].rowNumber);
  globalThis.bulkProductsUser = null;
  assert.equal((await api.POST(makeRequest({ action: "preview", rows: [sample()] }, null))).status, 401);
});

test("the supplied 20-row technology workbook previews and imports without image URLs", async () => {
  const file = readFileSync("tests/fixtures/Cash_N_Carry_Tech_Products_Test.xlsx");
  const rows = parseBulkProductWorkbook(file.buffer.slice(file.byteOffset, file.byteOffset + file.byteLength));
  assert.equal(rows.length, 20);
  assert(rows.every((row) => !row.image && row.images.length === 0));
  rows[0].status = "Publish";
  const previewResponse = await api.POST(makeRequest({ action: "preview", rows }));
  const preview = await previewResponse.json();
  assert.equal(previewResponse.status, 200);
  assert.deepEqual({ total: preview.total, valid: preview.valid, invalid: preview.invalid, duplicates: preview.duplicates }, { total: 20, valid: 20, invalid: 0, duplicates: 0 });
  assert(preview.rows.every((row) => row.category === "Tech" && row.statusCode === "ready" && row.image === ""));
  const importId = "998d323f-4e1d-42bb-8c70-7b97b711f6af";
  const response = await api.POST(makeRequest({ action: "import", importId, rows }));
  const events = (await response.text()).trim().split("\n").map((line) => JSON.parse(line));
  assert.equal(events.find((event) => event.type === "complete").import.imported, 20);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM products WHERE store='bulk-store' AND sku LIKE 'CNC-TECH-%' AND image=''").get().n, 20);
  assert.equal(db.prepare("SELECT active FROM products WHERE store='bulk-store' AND sku='CNC-TECH-001'").get().active, 1);
});

test("import is idempotent, seller scoped, keeps drafts inactive and publishes only confirmed rows", async () => {
  const importId = "a398db57-92e5-4e7f-9f3b-ecad79e31d71";
  const rows = [sample({ rowNumber: 2, sku: "BULK-01", status: "Publish" }), sample({ rowNumber: 3, name: "Draft item", sku: "BULK-02", status: "Draft" })];
  const response = await api.POST(makeRequest({ action: "import", importId, rows }));
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type"), /application\/x-ndjson/);
  const lines = (await response.text()).trim().split("\n").map((line) => JSON.parse(line));
  const completed = lines.find((event) => event.type === "complete");
  assert.equal(completed.import.imported, 2);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM products WHERE store='bulk-store' AND sku IN ('BULK-01','BULK-02')").get().n, 2);
  assert.equal(db.prepare("SELECT active FROM products WHERE store='bulk-store' AND sku='BULK-01'").get().active, 1);
  assert.equal(db.prepare("SELECT active FROM products WHERE store='bulk-store' AND sku='BULK-02'").get().active, 0);
  const retry = await api.POST(makeRequest({ action: "import", importId, rows }));
  assert.equal(retry.headers.get("content-type"), "application/json");
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM products WHERE store='bulk-store' AND sku IN ('BULK-01','BULK-02')").get().n, 2);
  const retryWithNewId = await api.POST(makeRequest({ action: "import", importId: "b65f98df-f15f-48c5-af5f-714295a0f6af", rows }));
  assert.equal(retryWithNewId.headers.get("content-type"), "application/json");
  assert.equal((await retryWithNewId.json()).duplicateImport, true);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM products WHERE store='bulk-store' AND sku IN ('BULK-01','BULK-02')").get().n, 2);
  const otherRequest = await api.POST(makeRequest({ action: "import", importId, rows }, "other"));
  assert.equal(otherRequest.status, 403);
});

test("a corrected workbook cannot reimport unchanged no-SKU products", async () => {
  const first = sample({ name: "Plain black mug", sku: "", status: "Draft" });
  const firstImport = await api.POST(makeRequest({ action: "import", importId: "af3de158-2827-4a79-8da2-9f04a590cc06", rows: [first] }));
  const firstEvents = (await firstImport.text()).trim().split("\n").map((line) => JSON.parse(line));
  assert.equal(firstEvents.find((event) => event.type === "complete").import.imported, 1);
  const updatedSheet = [first, sample({ rowNumber: 3, name: "Another item", sku: "FIXED-ROW", price: 2500 })];
  const secondImport = await api.POST(makeRequest({ action: "import", importId: "54f2831e-87d0-462a-9a40-37fbe2c24ad6", rows: updatedSheet }));
  const secondEvents = (await secondImport.text()).trim().split("\n").map((line) => JSON.parse(line));
  const completed = secondEvents.find((event) => event.type === "complete");
  assert.equal(completed.import.imported, 1);
  assert.equal(completed.import.duplicates, 1);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM products WHERE store='bulk-store' AND name='Plain black mug'").get().n, 1);
});

test("seller verification and active subscription gate bulk import, regardless of requested status", async () => {
  const unverified = await api.POST(makeRequest({ action: "import", importId: "d1162599-e648-4ba8-9a0e-b4dd98eecf6e", rows: [sample({ sku: "NO-ACCESS" })] }, "other"));
  assert.equal(unverified.status, 403);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM products WHERE sku='NO-ACCESS'").get().n, 0);
});

test("server processes 1, 10, 100 and 500 products in bounded atomic batches", async () => {
  for (const count of [1, 10, 100, 500]) {
    db.prepare("DELETE FROM rate_limits WHERE key='bulk-products:seller'").run();
    const start = db.prepare("SELECT COUNT(*) AS n FROM products WHERE store='bulk-store'").get().n;
    const rows = Array.from({ length: count }, (_, index) => sample({ rowNumber: index + 2, name: `Batch ${count} item ${index}`, sku: `BATCH-${count}-${index}`, status: "Draft" }));
    const response = await api.POST(makeRequest({ action: "import", importId: crypto.randomUUID(), rows }));
    assert.equal(response.status, 200);
    const events = (await response.text()).trim().split("\n").map((line) => JSON.parse(line));
    const complete = events.find((event) => event.type === "complete");
    assert.equal(complete.import.imported, count);
    assert.equal(db.prepare("SELECT COUNT(*) AS n FROM products WHERE store='bulk-store'").get().n - start, count);
  }
});

test("row failures are recorded, partial imports remain idempotent and changed retry payloads are rejected", async () => {
  db.exec("INSERT INTO stores(id,owner,name,category,location,verified,created) VALUES('partial-store','partial-seller','Partial seller shop','Fashion','Lagos',1,'now'); INSERT INTO seller_subscriptions(store,mode,status,paid_until,updated) VALUES('partial-store','test','active','2999-01-01T00:00:00Z','now');");
  const importId = "36c1ac85-9bdb-4c9d-9120-2058188eeb17";
  const rows = [sample({ rowNumber: 2, sku: "PARTIAL-OK" }), sample({ rowNumber: 3, sku: "PARTIAL-BAD", price: 50 })];
  const response = await api.POST(makeRequest({ action: "import", importId, rows }, "partial-seller"));
  const events = (await response.text()).trim().split("\n").map((line) => JSON.parse(line));
  const complete = events.find((event) => event.type === "complete");
  assert.equal(complete.import.status, "partial");
  assert.equal(complete.import.imported, 1);
  assert.equal(complete.import.failed, 1);
  assert.match(complete.rows.find((row) => row.rowNumber === 3).errors.join(" "), /at least ₦100/);
  const retry = await api.POST(makeRequest({ action: "import", importId, rows }, "partial-seller"));
  assert.equal(retry.status, 200);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM products WHERE sku='PARTIAL-OK'").get().n, 1);
  const changed = await api.POST(makeRequest({ action: "import", importId, rows: [sample({ sku: "CHANGED" })] }, "partial-seller"));
  assert.equal(changed.status, 409);
});

test("wrong origin and oversized row lists are rejected", async () => {
  globalThis.bulkProductsUser = { userId: "seller", email: "seller@test.invalid", displayName: "seller" };
  assert.equal((await api.POST(new Request("https://cashncarry.test/api/seller/bulk-products", { method: "POST", headers: { origin: "https://evil.test", "Content-Type": "application/json" }, body: JSON.stringify({ action: "preview", rows: [sample()] }) }))).status, 403);
  const response = await api.POST(makeRequest({ action: "preview", rows: Array.from({ length: 501 }, (_, index) => sample({ rowNumber: index + 2 })) }));
  assert.equal(response.status, 400);
});


test("twenty technology fixture products import without image URLs and retry without duplicates", async () => {
  db.exec("INSERT OR IGNORE INTO categories(id,name,active) VALUES('tech-audit','Tech',1)");
  db.exec("DELETE FROM rate_limits");
  const names = ['Wireless Bluetooth Earbuds','Over-Ear Headphones','USB-C Power Bank','Slim Power Bank','Fast Charger','Charging Cable','Bluetooth Speaker','Smart Fitness Watch','Wireless Mouse','Bluetooth Keyboard','Laptop Stand','USB-C Hub','USB Flash Drive','Memory Card','Phone Tripod','Ring Light','Webcam','Gaming Headset','Lavalier Microphone','Tablet Stand'];
  const rows = names.map((name,index)=>sample({rowNumber:index+2,name,category:'Tech',sku:`AUDIT-TECH-${index+1}`,price:1000+index*100,stock:20,image:'',images:[],status:'Publish'}));
  const preview=await api.POST(makeRequest({action:'preview',rows}));
  const validated=await preview.json(); assert.equal(validated.valid,20); assert.equal(validated.invalid,0);
  const importId='cc0ba91c-e8f4-4a52-bf98-a2f395a37d51';
  const imported=await api.POST(makeRequest({action:'import',importId,rows}));
  assert.equal(imported.status,200); await imported.text();
  assert.equal(db.prepare("SELECT COUNT(*) n FROM products WHERE store='bulk-store' AND sku LIKE 'AUDIT-TECH-%' AND image='' AND active=1").get().n,20);
  const retry=await api.POST(makeRequest({action:'import',importId,rows})); await retry.text();
  assert.equal(db.prepare("SELECT COUNT(*) n FROM products WHERE store='bulk-store' AND sku LIKE 'AUDIT-TECH-%'").get().n,20);
});
