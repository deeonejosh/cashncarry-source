import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync,backup} from 'node:sqlite';
import {mkdtempSync,readFileSync,readdirSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
test('additive MFA migration preserves baseline records and isolated backup restores all safeguards',async()=>{
 const db=new DatabaseSync(':memory:'),migrations=readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort();
 for(const f of migrations.filter(f=>!f.startsWith('0016_')))db.exec(readFileSync('drizzle/'+f,'utf8'));
 db.exec("INSERT INTO auth_user(id,name,email,email_verified,created_at,updated_at) VALUES('u','Controlled','controlled@example.invalid',1,1,1); INSERT INTO profiles(id,email,name,created,last_seen) VALUES('u','controlled@example.invalid','Controlled','now','now'); INSERT INTO stores(id,owner,name,category,location,created) VALUES('s','u','Controlled store','Tech','Lagos','now'); INSERT INTO products(id,store,name,description,category,price,stock,image,created) VALUES('p','s','Controlled product','Fixture only','Tech',1000,3,'https://example.invalid/image','now'); INSERT INTO orders(id,buyer,store,name,phone,address,total,delivery_fee,created) VALUES('o','u','s','Controlled','08000000000','Fixture address',1100,100,'now'); INSERT INTO order_items(id,order_id,product,name,price,quantity) VALUES('i','o','p','Controlled product',1000,1);");
 const before=JSON.stringify(db.prepare('SELECT * FROM orders').all()), stockBefore=db.prepare('SELECT stock FROM products').get().stock;
 db.exec(readFileSync('drizzle/'+migrations.find(f=>f.startsWith('0016_')),'utf8'));
 assert.equal(JSON.stringify(db.prepare('SELECT * FROM orders').all()),before);assert.equal(db.prepare('SELECT stock FROM products').get().stock,stockBefore);assert.equal(db.prepare('SELECT two_factor_enabled FROM auth_user').get().two_factor_enabled,0);
 db.exec("INSERT INTO auth_two_factor(id,user_id,secret,backup_codes,verified) VALUES('m','u','encrypted-fixture-secret','encrypted-fixture-recovery',1)");
 const folder=mkdtempSync(join(tmpdir(),'cnc-recovery-'));
 try{await backup(db,join(folder,'snapshot.sqlite'));const restored=new DatabaseSync(join(folder,'snapshot.sqlite'));assert.equal(restored.prepare('PRAGMA integrity_check').get().integrity_check,'ok');assert.equal(restored.prepare('PRAGMA foreign_key_check').all().length,0);assert.equal(JSON.stringify(restored.prepare('SELECT * FROM orders').all()),before);assert.equal(restored.prepare('SELECT secret FROM auth_two_factor').get().secret,'encrypted-fixture-secret');assert.equal(restored.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE type='trigger' AND name LIKE 'admin_audit_no_%'").get().n,2);restored.close();}finally{db.close();rmSync(folder,{recursive:true,force:true});}
});
