import test from 'node:test';
import assert from 'node:assert/strict';
import {sourceModule} from './load-route.mjs';
const {subscriptionDisplay}=await import(sourceModule('app/subscription-display.ts'));
const {emailTemplates,renderEmail,sampleEmail}=await import(sourceModule('app/email-templates.ts'));
test('subscription display labels expiry, remaining time and appropriate renewal actions',()=>{
 const now=Date.parse('2026-10-12T10:00:00.000Z');
 let d=subscriptionDisplay({subscription:'active',paidUntil:'2026-10-15T10:00:00.000Z'},now);assert.equal(d.state,'expiring');assert.equal(d.days,3);assert.equal(d.action,'Renew subscription');assert.match(d.expiry,/15 October 2026/);assert.match(d.expiry,/WAT/);
 d=subscriptionDisplay({subscription:'active',paidUntil:'2026-10-12T09:59:00.000Z'},now);assert.equal(d.state,'expired');assert.equal(d.action,'Resubscribe');assert.equal(d.days,0);
 d=subscriptionDisplay({subscription:'inactive'},now);assert.equal(d.action,'Activate subscription');assert.match(d.expiry,/No paid subscription/);
 d=subscriptionDisplay({subscription:'active',paidUntil:'2026-11-12T10:00:00.000Z'},now);assert.equal(d.state,'active');assert.equal(d.days,31);
});
test('expiry uses Nigerian time across a UTC date boundary and invalid dates do not render as active',()=>{
 const d=subscriptionDisplay({subscription:'active',paidUntil:'2026-10-12T23:30:00.000Z'},Date.parse('2026-10-12T10:00:00Z'));assert.match(d.expiry,/13 October 2026/);
 const invalid=subscriptionDisplay({subscription:'active',paidUntil:'not-a-date'},0);assert.equal(invalid.state,'inactive');assert.equal(invalid.days,null);assert.doesNotMatch(invalid.expiry,/Invalid Date/);
});
test('six subscription email previews contain expiry, renewal link and honest sandbox labels without enabling delivery',()=>{
 const templates=emailTemplates.filter(t=>t.id.startsWith('seller-subscription-'));assert.equal(templates.length,6);
 for(const t of templates){assert.equal(t.connected,true);const r=renderEmail(t.id,sampleEmail(t.id));assert.match(r.text,/Access expires:/);assert.match(r.text,/WAT/);assert.match(r.text,/SAMPLE/);assert.match(r.text,/https:\/\/cashncarryng.com\/seller\/finance\?tab=Subscription/);assert.match(r.text,/provider confirmation determines renewal status/);}
 const failed=renderEmail('seller-subscription-payment-failed',sampleEmail('seller-subscription-payment-failed'));assert.match(failed.text,/unsuccessful renewal attempt/);assert.match(failed.text,/will not make a separate card charge/);
 const expired=renderEmail('seller-subscription-expired',sampleEmail('seller-subscription-expired'));assert.match(expired.text,/existing orders remain manageable/i);
});
