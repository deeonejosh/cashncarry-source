import {onboardFixtureSellers} from "./seller-fixture.mjs";
import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {sourceModule} from './load-route.mjs';
globalThis.auditEnv={}; globalThis.auditUser=null;
const commerce=await import(sourceModule('app/api/commerce/route.ts','auditEnv','auditUser'));
const streams=await import(sourceModule('app/api/streams/route.ts','auditEnv','auditUser'));
const admin=await import(sourceModule('app/api/admin/route.ts','auditEnv','auditUser'));
function fixture(){
 const db=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+f,'utf8'));
 class Q{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Q(this.sql,args);}async first(){return db.prepare(this.sql).get(...this.args)||null;}async all(){return {results:db.prepare(this.sql).all(...this.args)};}async run(){return db.prepare(this.sql).run(...this.args);}}
 Object.assign(globalThis.auditEnv,{DB:{prepare:s=>new Q(s),batch:async stmts=>{db.exec('BEGIN');try{const out=[];for(const s of stmts)out.push(await s.run());db.exec('COMMIT');return out;}catch(e){db.exec('ROLLBACK');throw e;}}},REVIBE_ADMIN_EMAIL:'admin@test.invalid',STREAM_ACCOUNT_ID:'fixture',STREAM_API_TOKEN:'fixture'});
 globalThis.auditUser={userId:'seller',email:'seller@test.invalid',displayName:'Seller'};
 db.exec("INSERT INTO stores(id,owner,name,category,location,phone,created) VALUES('store','seller','Test Store','Tech','Lagos','08012345678','now'); INSERT INTO profiles(id,email,name,created,last_seen) VALUES('seller','seller@test.invalid','Seller','now','now'); INSERT INTO products(id,store,name,description,category,price,stock,image,created) VALUES('product','store','Item','Item','Tech',1000,3,'https://example.invalid/image.jpg','now'); INSERT INTO orders(id,buyer,store,name,phone,address,total,created) VALUES('order','buyer','store','Buyer','08012345678','Lagos',1000,'now'); INSERT INTO order_items(id,order_id,product,name,price,quantity) VALUES('item','order','product','Item',1000,1);");
 onboardFixtureSellers(db);
 return db;
}
const req=(path,body)=>new Request('https://audit.test'+path,{method:'POST',headers:{origin:'https://audit.test','Content-Type':'application/json'},body:JSON.stringify(body)});
const post=b=>commerce.POST(req('/api/commerce',b));
const native=b=>streams.POST(req('/api/streams',b));
test('stale seller cancellation returns a conflict without restocking twice',async()=>{
 const db=fixture();const original=globalThis.auditEnv.DB.batch;
 globalThis.auditEnv.DB.batch=async stmts=>{if(stmts.some(s=>s.sql.includes("UPDATE orders"))) db.exec("UPDATE orders SET status='cancelled' WHERE id='order'");return original(stmts);};
 const r=await post({action:'status',id:'order',status:'cancelled'});
 assert.equal(db.prepare("SELECT stock FROM products WHERE id='product'").get().stock,3);
 assert.equal(r.status,409);db.close();
});
test('stale seller confirmation returns a conflict without resurrecting cancelled order',async()=>{
 const db=fixture();const original=globalThis.auditEnv.DB.batch;
 globalThis.auditEnv.DB.batch=async stmts=>{if(stmts.some(s=>s.sql.includes("UPDATE orders"))) db.exec("UPDATE orders SET status='cancelled' WHERE id='order'");return original(stmts);};
 assert.equal((await post({action:'status',id:'order',status:'confirmed'})).status,409);
 assert.equal(db.prepare("SELECT status FROM orders WHERE id='order'").get().status,'cancelled');db.close();
});
test('normalized variant names cannot collide',async()=>{
 const db=fixture();const r=await post({action:'product',name:'Shirt',description:'Sizes',category:'Fashion',price:1000,stock:0,image:'https://example.invalid/shirt.jpg',variants:JSON.stringify([{name:'Small',price:1000,stock:1},{name:' Small ',price:1000,stock:1}])});
 assert.equal(r.status,400);assert.match((await r.json()).error,/unique/);db.close();
});
test('seller can end broadcast when provider configuration is missing',async()=>{
 const db=fixture();db.exec("INSERT INTO streams(id,store,title,url,status,provider,publish_url,created) VALUES('live','store','Test','https://example.invalid/play','live','native','private','now')");
 delete globalThis.auditEnv.STREAM_ACCOUNT_ID;delete globalThis.auditEnv.STREAM_API_TOKEN;
 assert.equal((await native({action:'end',id:'live'})).status,200);
 assert.equal(db.prepare("SELECT status,publish_url FROM streams WHERE id='live'").get().status,'ended');db.close();
});
test('only one native broadcast per seller can become live',async()=>{
 const db=fixture();db.exec("INSERT INTO streams(id,store,title,url,status,provider,provider_id,publish_url,created) VALUES('one','store','One','https://example.invalid/play','live','native','one','private','now'),('two','store','Two','https://example.invalid/play','scheduled','native','two','private','now')");
 db.prepare("UPDATE streams SET heartbeat=? WHERE id='one'").run(new Date().toISOString());
 const previous=globalThis.fetch;globalThis.fetch=async()=>Response.json({success:true,result:{status:'connected'}});
 try{assert.equal((await native({action:'connected',id:'two'})).status,409);assert.equal(db.prepare("SELECT status FROM streams WHERE id='two'").get().status,'scheduled');}finally{globalThis.fetch=previous;db.close();}
});
test('concurrent verification review cannot overwrite completed review',async()=>{
 const db=fixture();db.exec("UPDATE stores SET verified=0");globalThis.auditUser={userId:'admin',email:'admin@test.invalid'};
 db.exec("INSERT INTO verification_requests(id,store,owner,legal_name,file_key,file_type,created,updated) VALUES('verification','store','seller','Seller','private/document','application/pdf','now','now')");
 const original=globalThis.auditEnv.DB.batch;
 globalThis.auditEnv.DB.batch=async stmts=>{db.exec("UPDATE verification_requests SET status='rejected' WHERE id='verification'");return original(stmts);};
 const r=await admin.POST(req('/api/admin',{action:'verification',id:'verification',value:'approved',reason:'Test review'}));
 assert.equal(r.status,409);assert.equal(db.prepare("SELECT status FROM verification_requests WHERE id='verification'").get().status,'rejected');assert.equal(db.prepare("SELECT verified FROM stores WHERE id='store'").get().verified,0);db.close();
});
test('suspended seller products cannot be added to cart',async()=>{
 const db=fixture();db.exec("UPDATE profiles SET suspended=1 WHERE id='seller'");globalThis.auditUser={userId:'buyer',email:'buyer@test.invalid'};
 assert.equal((await post({action:'cart',product:'product',quantity:1})).status,400);assert.equal(db.prepare('SELECT count(*) AS n FROM carts').get().n,0);db.close();
});
test('invalid checkout payment method is rejected',async()=>{
 const db=fixture();globalThis.auditUser={userId:'buyer',email:'buyer@test.invalid'};await post({action:'cart',product:'product',quantity:1});
 assert.equal((await post({action:'checkout',key:crypto.randomUUID(),name:'Buyer',phone:'08012345678',address:'Lagos',delivery_state:'Lagos',payment:'fake'})).status,400);db.close();
});
test('concurrent preparation creates one provider input and retry reuses it',async()=>{
 const db=fixture();db.exec("INSERT INTO streams(id,store,title,url,status,provider,created) VALUES('scheduled','store','Test','','scheduled','native','now')");
 const previous=globalThis.fetch;let release;let calls=0;const wait=new Promise(resolve=>release=resolve);
 globalThis.fetch=async()=>{calls++;await wait;return Response.json({success:true,result:{uid:'provider',webRTC:{url:'https://example.invalid/publish'},webRTCPlayback:{url:'https://example.invalid/play'}}});};
 try{
  const first=native({action:'prepare',id:'scheduled'});
  while(!calls)await new Promise(resolve=>setImmediate(resolve));
  assert.equal((await native({action:'prepare',id:'scheduled'})).status,409);
  release();assert.equal((await first).status,200);
  assert.equal((await native({action:'prepare',id:'scheduled'})).status,200);assert.equal(calls,1);
  assert.equal(db.prepare("SELECT provider_id FROM streams WHERE id='scheduled'").get().provider_id,'provider');
 }finally{release();globalThis.fetch=previous;db.close();}
});

test('admin monitoring excludes stale native heartbeats from LIVE without changing stored records',async()=>{
 const db=fixture();globalThis.auditUser={userId:'admin',email:'admin@test.invalid'};
 db.exec("INSERT INTO streams(id,store,title,url,status,provider,created,heartbeat) VALUES('stale','store','Old','','live','native','now','2000-01-01T00:00:00Z'),('fresh','store','Current','','live','native','now',''),('scheduled','store','Later','','scheduled','native','now','')");
 db.prepare("UPDATE streams SET heartbeat=? WHERE id='fresh'").run(new Date().toISOString());
 const response=await admin.GET();assert.equal(response.status,200);const data=await response.json();
 assert.equal(data.streams.find(s=>s.id==='stale').status,'ended');assert.equal(data.streams.find(s=>s.id==='fresh').status,'live');assert.equal(data.streams.find(s=>s.id==='scheduled').status,'scheduled');
 assert.equal(db.prepare("SELECT status FROM streams WHERE id='stale'").get().status,'live');db.close();
});
