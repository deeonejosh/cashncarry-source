import test from "node:test";
import assert from "node:assert/strict";
import { sourceModule } from "./load-route.mjs";

const { videoEventPayload, VIDEO_VISITOR_KEY } = await import(sourceModule("app/video-event-analytics.ts"));

function storage(initial = {}) {
  const values = new Map(Object.entries(initial));
  return {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    values,
  };
}

test("video analytics stay off until the optional analytics choice is accepted", () => {
  for (const choice of [null, "rejected"]) {
    let generated = 0;
    const store = storage(choice ? { "cnc:analytics-consent:v1": choice } : {});
    assert.equal(videoEventPayload("video-1", "view", store, () => { generated++; return "visitor-1"; }), null);
    assert.equal(generated, 0);
    assert.equal(store.values.has(VIDEO_VISITOR_KEY), false);
  }
});

test("accepted video analytics reuse one persistent device token", () => {
  const store = storage({ "cnc:analytics-consent:v1": "accepted" });
  let generated = 0;
  const createId = () => { generated++; return "visitor-1"; };
  assert.deepEqual(videoEventPayload("video-1", "view", store, createId), {
    action: "event", video: "video-1", kind: "view", visitor: "visitor-1",
  });
  assert.deepEqual(videoEventPayload("video-2", "view", store, createId), {
    action: "event", video: "video-2", kind: "view", visitor: "visitor-1",
  });
  assert.equal(generated, 1);
});
