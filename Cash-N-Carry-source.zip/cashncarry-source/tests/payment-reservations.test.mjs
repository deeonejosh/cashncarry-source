import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { sourceModule } from './load-route.mjs';
const db = new DatabaseSync(':memory:');
for (const file of readdirSync('drizzle').filter(f => f.endsWith('.sql')).sort()) db.exec(readFileSync('drizzle/' + file, 'utf8'));
class Query {
  constructor(sql, args=[]) { this.sql=sql; this.args=args; }
  bind(...args) { return new Query(this.sql,args); }
  async first() { return db.prepare(this.sql).get(...this.args)||null; }
  async all() { return {results:db.prepare(this.sql).all(...this.args)}; }
  async run() { return db.prepare(this.sql).run(...this.args); }
}
const batch=async statements=>{ db.exec('BEGIN'); try { const results=[]; for(const s of statements) results.push(await s.run()); db.exec('COMMIT'); return results; } catch(e) {db.exec('ROLLBACK'); throw e;} };
globalThis.testEnv={DB:{prepare:sql=>new Query(sql),batch},FLW_SECRET_KEY:'FLWSECK_TEST-fixture',FLW_WEBHOOK_HASH:'fixture',SITE_URL:'https://shop.test'};
const payment=await import(sourceModule('app/payments.ts'));
db.prepare("INSERT INTO stores(id,owner,name,category,location,created) VALUES('store','seller','Fixture','Tech','Lagos','now')").run();
function fixture(id,expires=new Date(Date.now()-3600000).toISOString()) {
  db.prepare("INSERT INTO products(id,store,name,description,category,price,stock,image,created) VALUES(?,'store','Fixture','Test','Tech',1000,2,'','now')").run(id);
  db.prepare("INSERT INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,created) VALUES(?,'buyer','store','Fixture','08012345678','Lagos',1000,'placed','flutterwave','pending','now')").run(id);
  db.prepare("INSERT INTO order_items(id,order_id,product,name,price,quantity) VALUES(?,?,?,'Fixture',1000,1)").run(id,id,id);
  db.prepare("INSERT INTO payments(id,order_id,buyer,amount,currency,mode,status,link,expires,created,updated) VALUES(?,?,'buyer',1000,'NGN','test','pending','https://checkout.flutterwave.com/fixture',?,'now','now')").run(id,id,expires);
}
for(const id of ['failed','successful','uncertain']) fixture(id);
fixture('future',new Date(Date.now()+3600000).toISOString());
const calls=[];const originalFetch=globalThis.fetch;
globalThis.fetch=async(url)=>{
  calls.push(String(url));
  if(String(url).endsWith('payments/link/disable')) return Response.json({status:'success',data:true});
  const ref=new URL(String(url)).searchParams.get('tx_ref') || String(url).split('/').at(-2);
  if(ref==='uncertain') throw Error('Provider timeout');
  const status=ref==='successful'?'successful':'failed';
  const id=ref==='successful'?'222':'111';
  const txRef=ref==='222'?'successful':ref==='111'?'failed':ref;
  return Response.json({status:'success',data:{id:ref==='222'?222:ref==='111'?111:Number(id),tx_ref:txRef,status:ref==='222'?'successful':status,amount:1000,currency:'NGN'}});
};
const results=await Promise.all([payment.reconcileExpiredPayments(),payment.reconcileExpiredPayments()]);
assert.equal(results.reduce((s,r)=>s+r.checked,0),3);
assert.equal(db.prepare("SELECT status FROM orders WHERE id='failed'").get().status,'cancelled');
assert.equal(db.prepare("SELECT stock FROM products WHERE id='failed'").get().stock,2);
assert.equal(db.prepare("SELECT payment_status FROM orders WHERE id='successful'").get().payment_status,'paid');
assert.equal(db.prepare("SELECT stock FROM products WHERE id='successful'").get().stock,1);
assert.equal(db.prepare("SELECT status FROM orders WHERE id='uncertain'").get().status,'placed');
assert.equal(db.prepare("SELECT stock FROM products WHERE id='uncertain'").get().stock,1);
assert.equal(db.prepare("SELECT status FROM payments WHERE id='future'").get().status,'pending');
assert(!calls.some(c=>c.includes('tx_ref=future')));
await assert.rejects(()=>payment.initiatePayment({id:'uncertain'},'test@example.invalid'),/expired/);
// Simulate cancellation completing after a successful verification read, before its batch.
fixture('race');
globalThis.fetch=async()=>Response.json({status:'success',data:{id:333,tx_ref:'race',status:'successful',amount:1000,currency:'NGN'}});
globalThis.testEnv.DB.batch=async statements=>{
  db.prepare("UPDATE orders SET status='cancelled',payment_status='failed' WHERE id='race'").run();
  db.prepare("UPDATE payments SET status='failed' WHERE id='race'").run();
  globalThis.testEnv.DB.batch=batch; return batch(statements);
};
assert.equal((await payment.verifyPayment('333','race')).status,'review_required');
assert.equal(db.prepare("SELECT stock FROM products WHERE id='race'").get().stock,2);
assert.equal(db.prepare("SELECT COUNT(*) n FROM notifications WHERE body='Order race has been paid.'").get().n,0);
// A paid webhook wins before the cancellation batch: do not release stock.
fixture('paid-race');
globalThis.fetch=async()=>Response.json({status:'success',data:{id:444,tx_ref:'paid-race',status:'failed',amount:1000,currency:'NGN'}});
globalThis.testEnv.DB.batch=async statements=>{
  db.prepare("UPDATE payments SET status='paid' WHERE id='paid-race'").run();
  db.prepare("UPDATE orders SET payment_status='paid' WHERE id='paid-race'").run();
  globalThis.testEnv.DB.batch=batch; return batch(statements);
};
assert.equal((await payment.verifyPayment('444','paid-race',undefined,true)).status,'paid');
assert.equal(db.prepare("SELECT stock FROM products WHERE id='paid-race'").get().stock,1);
assert.equal(db.prepare("SELECT status FROM orders WHERE id='paid-race'").get().status,'placed');
// An unattempted checkout is not an outage and must remain usable after cancellation fails.
fixture('not-found',new Date(Date.now()+3600000).toISOString());
const cancellationCalls=[];
globalThis.fetch=async(url)=>{
  cancellationCalls.push(String(url));
  return Response.json({status:'error',message:'No transaction was found for this id',data:null},{status:400});
};
await assert.rejects(()=>payment.cancelOnlineOrder({id:'not-found'}),/Cancellation becomes available/);
assert.equal(cancellationCalls.length,1);
assert(cancellationCalls[0].includes('verify_by_reference'));
assert.equal(db.prepare("SELECT stock FROM products WHERE id='not-found'").get().stock,1);
assert.equal(db.prepare("SELECT status FROM orders WHERE id='not-found'").get().status,'placed');
fixture('processing');
globalThis.fetch=async(url)=>{
  assert(!String(url).includes('link/disable'));
  return Response.json({status:'success',data:{id:555,tx_ref:'processing',status:'pending',amount:1000,currency:'NGN'}});
};
await assert.rejects(()=>payment.cancelOnlineOrder({id:'processing'}),/Payment is still pending/);
assert.equal(db.prepare("SELECT stock FROM products WHERE id='processing'").get().stock,1);
// Do not restock when the provider has not positively confirmed link closure.
fixture('disable-unconfirmed');
globalThis.fetch=async(url)=>String(url).includes('link/disable')
  ? Response.json({status:'success',data:false})
  : Response.json({status:'success',data:{id:666,tx_ref:'disable-unconfirmed',status:'failed',amount:1000,currency:'NGN'}});
await assert.rejects(()=>payment.cancelOnlineOrder({id:'disable-unconfirmed'}),/not confirmed that checkout is closed/);
assert.equal(db.prepare("SELECT status FROM orders WHERE id='disable-unconfirmed'").get().status,'placed');
assert.equal(db.prepare("SELECT stock FROM products WHERE id='disable-unconfirmed'").get().stock,1);
globalThis.fetch=async()=>Response.json({status:'error',message:'upstream error'},{status:503});
await assert.rejects(()=>payment.flutterwave('payments'),/provider is unavailable/);
globalThis.fetch=async()=>Response.json({status:'error',message:'Invalid Link'},{status:400});
await assert.rejects(()=>payment.flutterwave('payments/link/disable',{link:'fixture'}),/could not confirm this request/);
// Failed callbacks keep a retryable checkout open; a subsequent success settles it.
fixture('retry-webhook');
globalThis.fetch=async()=>Response.json({status:'success',data:{id:777,tx_ref:'retry-webhook',status:'failed',amount:1000,currency:'NGN'}});
assert.equal((await payment.verifyPayment('777','retry-webhook')).status,'pending');
assert.equal(db.prepare("SELECT stock FROM products WHERE id='retry-webhook'").get().stock,1);
globalThis.fetch=async()=>Response.json({status:'success',data:{id:778,tx_ref:'retry-webhook',status:'successful',amount:1000,currency:'NGN'}});
assert.equal((await payment.verifyPayment('778','retry-webhook')).status,'paid');
// Expired unused checkout: closure plus second missing-transaction check, once-only restock.
fixture('unused-expired');
globalThis.fetch=async url=>String(url).includes('link/disable') ? Response.json({status:'success',data:true}) : Response.json({status:'error',message:'No transaction was found for this id'},{status:400});
await payment.cancelOnlineOrder({id:'unused-expired'});
assert.equal(db.prepare("SELECT status FROM orders WHERE id='unused-expired'").get().status,'cancelled');
assert.equal(db.prepare("SELECT stock FROM products WHERE id='unused-expired'").get().stock,2);
await payment.cancelOnlineOrder({id:'unused-expired'});
assert.equal(db.prepare("SELECT stock FROM products WHERE id='unused-expired'").get().stock,2);
globalThis.fetch=async()=>Response.json({status:'success',data:{id:779,tx_ref:'unused-expired',status:'successful',amount:1000,currency:'NGN'}});
assert.equal((await payment.verifyPayment('779','unused-expired')).status,'review_required');
fixture('unused-unconfirmed');
globalThis.fetch=async url=>String(url).includes('link/disable') ? Response.json({status:'success',data:false}) : Response.json({status:'error',message:'No transaction was found for this id'},{status:400});
await assert.rejects(()=>payment.cancelOnlineOrder({id:'unused-unconfirmed'}),/not confirmed/);
assert.equal(db.prepare("SELECT stock FROM products WHERE id='unused-unconfirmed'").get().stock,1);
fixture('unused-timeout');
let lookups=0;
globalThis.fetch=async url=>{
 if(String(url).includes('link/disable')) return Response.json({status:'success',data:true});
 if(++lookups===1) return Response.json({status:'error',message:'No transaction was found for this id'},{status:400});
 throw Error('timeout');
};
await assert.rejects(()=>payment.cancelOnlineOrder({id:'unused-timeout'}),/unavailable/);
assert.equal(db.prepare("SELECT stock FROM products WHERE id='unused-timeout'").get().stock,1);
globalThis.fetch=originalFetch;
console.log('PASS: expiry sweep, verified failure restock, success settlement, payment races, missing and processing transactions retain usable checkout, unconfirmed link closure retains stock, and provider error classification. Provider responses are fixtures.');
