import test from 'node:test';
import assert from 'node:assert/strict';
import ts from 'typescript';
import { readFileSync } from 'node:fs';
const source = ts.createSourceFile('workspace.tsx', readFileSync('app/workspace/page.tsx','utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
let body;
function visit(node) { if (ts.isFunctionDeclaration(node) && node.name?.text === 'switchCamera') body=node.body.getText(source); ts.forEachChild(node,visit); }
visit(source);
const compiled=ts.transpileModule('async function run() '+body,{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
const make = new Function('camera','pc','generation','switchPending','preview','setMessage','navigator','cameraFacing','stop',compiled+'; return run;');
function fixture() {
 let resolve; const pending=new Promise(r=>resolve=r);
 const old={getSettings:()=>({facingMode:'user'}),stop(){this.stopped=true;}};
 const tracks=[old]; const stream={getVideoTracks:()=>tracks,removeTrack(t){tracks.splice(tracks.indexOf(t),1);},addTrack(t){tracks.push(t);}};
 const camera={current:stream},generation={current:1},lock={current:false};
 let requests=0; let constraints; const run=make(camera,{current:null},generation,lock,{current:null},()=>{}, {mediaDevices:{getUserMedia(options){constraints=options;requests++;return pending;}}}, {current:"user"}, async()=>{});
 const next={stop(){this.stopped=true;}};
 return {run,camera,generation,lock,old,next,resolve:()=>resolve({getVideoTracks:()=>[next],getTracks:()=>[next]}),requests:()=>requests,constraints:()=>constraints};
}
test('ending during camera acquisition stops newly acquired track',async()=>{const f=fixture();const p=f.run();f.generation.current++;f.camera.current=null;f.resolve();await p;assert.equal(f.next.stopped,true);assert.equal(f.lock.current,false);});
test('repeated switch clicks acquire only one camera',async()=>{const f=fixture();const p=f.run();await f.run();assert.equal(f.requests(),1);f.resolve();await p;assert.equal(f.old.stopped,true);assert.equal(f.camera.current.getVideoTracks()[0],f.next);});

test('switch releases camera before acquisition and requires portrait rear camera', async()=>{
 const f=fixture(); const p=f.run(); assert.equal(f.old.stopped,true); assert.deepEqual(f.constraints().video.facingMode,{exact:"environment"}); assert.equal(f.constraints().video.aspectRatio.ideal,9/16); f.resolve(); await p;
});
