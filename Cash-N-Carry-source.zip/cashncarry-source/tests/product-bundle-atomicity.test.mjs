import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {sourceModule} from './load-route.mjs';
const db=new DatabaseSync(':memory:');
for(const file of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+file,'utf8'));
class Q{constructor(sql,args=[]){this.sql=sql;this.args=args}bind(...args){return new Q(this.sql,args)}async first(){return db.prepare(this.sql).get(...this.args)||null}async all(){return{results:db.prepare(this.sql).all(...this.args)}}async run(){return{meta:db.prepare(this.sql).run(...this.args)}}}
globalThis.atomicBundleEnv={FLW_MODE:'test',DB:{prepare:sql=>new Q(sql),async batch(rows){db.exec('BEGIN');try{const result=[];for(const row of rows)result.push(await row.run());db.exec('COMMIT');return result}catch(e){db.exec('ROLLBACK');throw e}}}};
globalThis.atomicBundleUser={userId:'qa-seller'};
const api=await import(sourceModule('app/api/product-bundles/route.ts','atomicBundleEnv','atomicBundleUser'));
const post=body=>api.POST(new Request('https://app.test/api/product-bundles',{method:'POST',headers:{origin:'https://app.test'},body:JSON.stringify(body)}));
const body=(extra={})=>({action:'save',id:'qa-bundle',productId:'qa-bundle-product',title:'QA bundle',description:'Original description',price:1000,publish:true,image:'https://example.invalid/image.jpg',items:[{product:'qa-one',quantity:2},{product:'qa-two',quantity:1}],...extra});
const snapshot=()=>JSON.stringify({products:db.prepare('SELECT * FROM products ORDER BY id').all(),bundles:db.prepare('SELECT * FROM product_bundles ORDER BY id').all(),items:db.prepare('SELECT * FROM product_bundle_items ORDER BY bundle,product').all()});
async function withFailure(sql,work){db.exec(sql);try{await work()}finally{db.exec('DROP TRIGGER qa_failure')}}
test('seller bundle create, edit and archive are atomic under actual SQLite statement failures',async()=>{
 await api.GET(new Request('https://app.test/api/product-bundles'));
 db.exec("INSERT INTO stores(id,owner,name,category,location,verified,created) VALUES('qa-store','qa-seller','QA store','Tech','Lagos',1,'now'); INSERT INTO seller_subscriptions(store,mode,status,paid_until,updated) VALUES('qa-store','test','active','2999-01-01T00:00:00Z','now'); INSERT INTO products(id,store,name,description,category,price,stock,image,active,created) VALUES('qa-one','qa-store','One','','Tech',800,10,'https://example.invalid/one.jpg',1,'now'),('qa-two','qa-store','Two','','Tech',700,4,'https://example.invalid/two.jpg',1,'now')");
 const initial=snapshot();
 await withFailure("CREATE TRIGGER qa_failure BEFORE INSERT ON product_bundle_items WHEN NEW.product='qa-two' BEGIN SELECT RAISE(ABORT,'QA item failure'); END",async()=>{assert.equal((await post(body())).status,400);assert.equal(snapshot(),initial,'failed create must not leave bundle product, metadata or first item')});
 const created=await post(body());assert.equal(created.status,200);const result=await created.json();assert.equal(result.available,4);assert.equal(result.individualTotal,2300);assert.equal(result.savings,1300);assert.equal(db.prepare('SELECT COUNT(*) n FROM product_bundle_items').get().n,2);
 const original=snapshot();
 await withFailure("CREATE TRIGGER qa_failure BEFORE INSERT ON product_bundle_items WHEN NEW.product='qa-two' BEGIN SELECT RAISE(ABORT,'QA replacement failure'); END",async()=>{assert.equal((await post(body({title:'Changed bundle',price:900,items:[{product:'qa-one',quantity:1},{product:'qa-two',quantity:2}]}))).status,400);assert.equal(snapshot(),original,'failed edit must restore metadata, product and deleted original items')});
 assert.equal((await post(body({title:'Edited bundle',price:900,items:[{product:'qa-one',quantity:1},{product:'qa-two',quantity:2}]}))).status,200);assert.equal(db.prepare("SELECT stock FROM products WHERE id='qa-bundle-product'").get().stock,2);assert.equal(db.prepare("SELECT quantity FROM product_bundle_items WHERE product='qa-two'").get().quantity,2);
 const edited=snapshot();
 await withFailure("CREATE TRIGGER qa_failure BEFORE UPDATE OF active ON products WHEN NEW.id='qa-bundle-product' AND NEW.active=0 BEGIN SELECT RAISE(ABORT,'QA visibility failure'); END",async()=>{assert.equal((await post({action:'archive',id:'qa-bundle'})).status,400);assert.equal(snapshot(),edited,'failed archive must preserve both bundle and product visibility')});
 assert.equal((await post({action:'archive',id:'qa-bundle'})).status,200);assert.equal(db.prepare("SELECT active FROM products WHERE id='qa-bundle-product'").get().active,0);assert.equal(db.prepare("SELECT active FROM product_bundles WHERE id='qa-bundle'").get().active,0);assert.equal(db.prepare("SELECT stock FROM products WHERE id='qa-one'").get().stock,10);assert.equal(db.prepare("SELECT stock FROM products WHERE id='qa-two'").get().stock,4);
});
test('bundle mutations retain seller access and store ownership restrictions',async()=>{const before=snapshot();db.exec("INSERT INTO stores(id,owner,name,category,location,verified,created) VALUES('other-store','other-seller','Other store','Tech','Lagos',1,'now'); INSERT INTO seller_subscriptions(store,mode,status,paid_until,updated) VALUES('other-store','test','active','2999-01-01T00:00:00Z','now')");globalThis.atomicBundleUser={userId:'other-seller'};assert.equal((await post({action:'archive',id:'qa-bundle'})).status,400);globalThis.atomicBundleUser={userId:'qa-seller'};db.exec("UPDATE stores SET verified=0 WHERE id='qa-store'");assert.equal((await post(body())).status,400);assert.equal((await post({action:'archive',id:'qa-bundle'})).status,400);assert.equal(snapshot(),before);db.exec("UPDATE stores SET verified=1 WHERE id='qa-store'")});
