import assert from 'node:assert/strict';
import { sourceModule } from './load-route.mjs';
const {paymentCheckoutUrl}=await import(sourceModule('app/payment-checkout-url.ts'));
for(const host of ['checkout.flutterwave.com','checkout-v2.dev-flutterwave.com']) assert.equal(paymentCheckoutUrl(`https://${host}/test`,true),`https://${host}/test`);
assert.throws(()=>paymentCheckoutUrl('https://checkout-v2.dev-flutterwave.com/test',false));
for(const bad of [null,'invalid','http://checkout.flutterwave.com/pay','https://checkout-v2.dev-flutterwave.com.evil.test/pay','https://evil.test/pay','https://checkout.flutterwave.com@evil.test/pay','https://user:secret@checkout.flutterwave.com/pay','https://checkout.flutterwave.com:8443/pay','https://unrelated.flutterwave.com/pay']) assert.throws(()=>paymentCheckoutUrl(bad,true));
console.log('PASS: official checkout and observed sandbox hostname accepted; unsafe schemes, lookalikes, credentials, ports and unrelated hosts rejected.');
