import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync,readdirSync } from 'node:fs';
import { sourceModule } from './load-route.mjs';

const sqlite = new DatabaseSync(':memory:');
for (const file of readdirSync('drizzle').filter((x)=>x.endsWith('.sql')).sort()) sqlite.exec(readFileSync('drizzle/'+file,'utf8'));
class Query { constructor(sql,args=[]){this.sql=sql;this.args=args;} bind(...args){return new Query(this.sql,args);} async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};} async first(){return sqlite.prepare(this.sql).get(...this.args)||null;} async run(){return sqlite.prepare(this.sql).run(...this.args);} }
const objects=new Map();
globalThis.videoEnv={FLW_MODE:'test',REVIBE_ADMIN_EMAIL:'admin@test.invalid',DB:{prepare:(sql)=>new Query(sql),batch:async(statements)=>{sqlite.exec('BEGIN');try{const out=[];for(const q of statements)out.push(await q.run());sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}}},BUCKET:{head:async(key)=>objects.get(key)||null}};
globalThis.videoUser=null;
globalThis.fixtureAdminRole=null;
const user=(id)=>globalThis.videoUser=id?{userId:id,email:id+'@test.invalid',displayName:id}:null;
const [storefrontApi,videoApi,adminApi]=await Promise.all([
  import(sourceModule('app/api/storefront/route.ts','videoEnv','videoUser')),
  import(sourceModule('app/api/videos/route.ts','videoEnv','videoUser')),
  import(sourceModule('app/api/admin/route.ts','videoEnv','videoUser')),
]);
const postAt=(api,path,body)=>api.POST(new Request('https://cashncarry.test'+path,{method:'POST',headers:{origin:'https://cashncarry.test','Content-Type':'application/json'},body:JSON.stringify(body)}));

test('storefronts enforce owner, slug uniqueness, draft privacy and public publishing',async()=>{
  const stamp=new Date().toISOString();
  sqlite.prepare("INSERT INTO profiles(id,email,name,suspended,created,last_seen) VALUES(?,?,?,0,?,?)").run('seller','seller@test.invalid','seller',stamp,stamp);
  sqlite.prepare("INSERT INTO stores(id,owner,name,description,category,location,phone,verified,created) VALUES('store-1','seller','Seller Store','Base description','Tech','Lagos','08012345678',1,?)").run(stamp);
  user('seller');
  let r=await postAt(storefrontApi,'/api/storefront',{slug:'seller-store',name:'Seller Store Online',description:'A custom shop',category:'Tech',template:'market',accent:'#164B35',published:false});
  assert.equal(r.status,200);assert.equal((await r.json()).url,'/store/seller-store');
  r=await storefrontApi.GET(new Request('https://cashncarry.test/api/storefront?slug=seller-store'));
  assert.equal(r.status,404,'draft is not public');
  r=await storefrontApi.GET(new Request('https://cashncarry.test/api/storefront?preview=1'));
  assert.equal(r.status,200);assert.equal((await r.json()).storefront.display_name,'Seller Store Online');
  user('other');assert.equal((await storefrontApi.GET(new Request('https://cashncarry.test/api/storefront?preview=1'))).status,404,'another seller cannot discover a private draft');
  user('seller');
  assert.equal((await (await postAt(storefrontApi,'/api/storefront',{slug:'admin',published:true})).json()).error.includes('reserved'),true);
  r=await postAt(storefrontApi,'/api/storefront',{slug:'seller-store',name:'Seller Store Online',published:true});
  assert.equal(r.status,200);
  assert.equal((await storefrontApi.GET(new Request('https://cashncarry.test/api/storefront?slug=seller-store'))).status,200);
  assert.equal(sqlite.prepare("SELECT COUNT(*) AS n FROM storefronts WHERE store='store-1'").get().n,1);
});

test('approved videos share current product data, support following, event dedupe and moderation removal',async()=>{
  const stamp=new Date().toISOString();
  sqlite.prepare("INSERT INTO profiles(id,email,name,suspended,created,last_seen) VALUES(?,?,?,0,?,?)").run('seller2','seller2@test.invalid','seller2',stamp,stamp);
  sqlite.prepare("INSERT INTO stores(id,owner,name,description,category,location,phone,verified,created) VALUES('store-2','seller2','Second Seller','','Tech','Lagos','08012345678',1,?)").run(stamp);
  sqlite.prepare("INSERT INTO seller_subscriptions(store,mode,status,paid_until,updated) VALUES('store-2','test','active','2999-01-01T00:00:00.000Z',?)").run(stamp);
  sqlite.prepare("INSERT INTO products(id,store,name,description,category,price,stock,image,created) VALUES('product-2','store-2','Headphones','Wireless','Tech',25000,4,'https://example.test/p.jpg',?)").run(stamp);
  objects.set('seller-video',{size:500,httpMetadata:{contentType:'video/mp4'},customMetadata:{owner:'seller2'}});
  user('seller2');
  let response=await postAt(videoApi,'/api/videos',{action:'create',media:'/api/media/seller-video',caption:'Fresh headphones #demo',hashtags:['tech','demo'],products:['product-2'],publish:true});
  assert.equal(response.status,200);const created=await response.json();assert.equal(created.status,'pending');
  sqlite.prepare("INSERT INTO video_comments(id,video,user,parent,body,created) VALUES('private-comment',?,'seller2','', 'private moderation comment',?)").run(created.id,stamp);
  assert.equal((await videoApi.GET(new Request('https://cashncarry.test/api/videos'))).status,200);
  let feed=await (await videoApi.GET(new Request('https://cashncarry.test/api/videos?id='+created.id))).json();assert.equal(feed.videos.length,0);assert.equal(feed.comments.length,0,'comments on moderation-held videos stay private');
  user('stranger');assert.equal((await postAt(videoApi,'/api/videos',{action:'delete',id:created.id})).status,403);
  globalThis.fixtureAdminRole='owner';user('admin');
  response=await postAt(adminApi,'/api/admin',{action:'video',id:created.id,value:'approved',reason:'Product and video match'});assert.equal(response.status,200,await response.text());
  user(null);
  feed=await (await videoApi.GET(new Request('https://cashncarry.test/api/videos'))).json();assert.equal(feed.videos.length,1);assert.equal(feed.videos[0].products[0].price,25000);assert.equal(feed.videos[0].products[0].stock,4);
  assert.equal((await postAt(videoApi,'/api/videos',{action:'comment',video:created.id,body:'A public comment'})).status,401,'commenting requires a signed-in buyer');
  sqlite.prepare("INSERT INTO profiles(id,email,name,username,suspended,created,last_seen) VALUES(?,?,?,'buyer',0,?,?)").run('buyer','buyer@test.invalid','Buyer',stamp,stamp);
  user('buyer');
  response=await postAt(videoApi,'/api/videos',{action:'comment',video:created.id,body:'A public comment'});assert.equal(response.status,200,await response.text());
  feed=await (await videoApi.GET(new Request('https://cashncarry.test/api/videos?id='+created.id))).json();assert.ok(feed.comments.some((comment)=>comment.body==='A public comment'&&comment.username==='buyer'));assert.equal(feed.videos[0].comments,feed.comments.length);
  user(null);
  sqlite.prepare("UPDATE products SET price=22000,stock=2 WHERE id='product-2'").run();
  feed=await (await videoApi.GET(new Request('https://cashncarry.test/api/videos'))).json();assert.equal(feed.videos[0].products[0].price,22000);assert.equal(feed.videos[0].products[0].stock,2);
  const visitor='0123456789abcdef0123456789abcdef';
  for(let i=0;i<2;i++) assert.equal((await postAt(videoApi,'/api/videos',{action:'event',video:created.id,kind:'view',visitor})).status,200);
  assert.equal(sqlite.prepare("SELECT COUNT(*) AS n FROM video_events WHERE video=? AND kind='view'").get(created.id).n,1);
  sqlite.prepare("UPDATE video_events SET day='2000-01-01' WHERE video=? AND visitor=? AND kind='view'").run(created.id,visitor);
  assert.equal((await postAt(videoApi,'/api/videos',{action:'event',video:created.id,kind:'view',visitor})).status,200,'a later-day repeat from the same device is accepted without adding a second view');
  assert.equal(sqlite.prepare("SELECT COUNT(*) AS n FROM video_events WHERE video=? AND kind='view'").get(created.id).n,1,'one browser/device contributes at most one lifetime view per video');
  feed=await (await videoApi.GET(new Request('https://cashncarry.test/api/videos?id='+created.id))).json();assert.equal(feed.videos[0].views,1);
  user('buyer');sqlite.prepare("INSERT INTO follows(id,user,store) VALUES('follow-1','buyer','store-2')").run();
  feed=await (await videoApi.GET(new Request('https://cashncarry.test/api/videos?following=1'))).json();assert.equal(feed.videos.length,1);
  user('admin');response=await postAt(adminApi,'/api/admin',{action:'video',id:created.id,value:'removed',reason:'Reported content'});assert.equal(response.status,200);
  user(null);feed=await (await videoApi.GET(new Request('https://cashncarry.test/api/videos'))).json();assert.equal(feed.videos.length,0);
  assert.equal(sqlite.prepare("SELECT COUNT(*) AS n FROM video_moderation_history WHERE video=?").get(created.id).n,2);
});
