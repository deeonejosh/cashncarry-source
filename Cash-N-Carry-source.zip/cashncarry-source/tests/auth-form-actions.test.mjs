import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import ts from "typescript";
import * as React from "react";
let state = [],
  refs = [],
  cursor = 0,
  refCursor = 0;
globalThis.authFormHarness = {
  React,
  useEffect() {},
  useState(initial) {
    const i = cursor++;
    if (!(i in state)) state[i] = initial;
    return [
      state[i],
      (value) =>
        (state[i] = typeof value === "function" ? value(state[i]) : value),
    ];
  },
  useRef(initial) {
    const i = refCursor++;
    return (refs[i] ??= { current: initial });
  },
};
const source = readFileSync("app/account/auth-form.tsx", "utf8").replace(
  /import[\s\S]*?from\s*["'][^"']+["'];/g,
  "",
);
const prefix =
  "const {React,useEffect,useState,useRef}=globalThis.authFormHarness;const Link=({children,...props})=>React.createElement('a',props,children);const MIN_PASSWORD_LENGTH=12,safeReturnPath=x=>x;const ArrowLeft=()=>null,Eye=()=>null,EyeOff=()=>null,BrandLogo=()=>null,Sessions=()=>null;";
const js = ts.transpileModule(prefix + source, {
  compilerOptions: {
    module: ts.ModuleKind.ESNext,
    target: ts.ScriptTarget.ES2023,
    jsx: ts.JsxEmit.React,
  },
}).outputText;
const { default: Form } = await import(
  "data:text/javascript;base64," + Buffer.from(js).toString("base64")
);
function nodes(node, result = []) {
  if (Array.isArray(node)) {
    node.forEach((n) => nodes(n, result));
  } else if (node && typeof node === "object") {
    result.push(node);
    nodes(node.props?.children, result);
  }
  return result;
}
function setup(initialMode, search = "") {
  state = [];
  refs = [];
  cursor = 0;
  refCursor = 0;
  let assigned = "",
    replaced = "",
    focused = "";
  globalThis.location = { search, origin: "https://shop.example" };
  globalThis.window = {
    location: { assign: (x) => (assigned = x) },
    history: { replaceState: (a, b, x) => (replaced = x) },
  };
  globalThis.localStorage = { setItem() {} };
  const render = () => {
    cursor = 0;
    refCursor = 0;
    return nodes(
      Form({ available: true, initialMode, destination: "/order/123" }),
    );
  };
  const form = (values) => ({
    values,
    reset() {},
    querySelector(selector) {
      return {
        focus() {
          focused = selector;
        },
      };
    },
  });
  return {
    render,
    form,
    get assigned() {
      return assigned;
    },
    get replaced() {
      return replaced;
    },
    get focused() {
      return focused;
    },
  };
}
const NativeFormData = globalThis.FormData;
function fixtureFormData() {
  globalThis.FormData = class {
    constructor(form) {
      this.form = form;
    }
    get(key) {
      return this.form.values[key] ?? null;
    }
  };
}
test("password mismatch prevents signup request and focuses confirmation", async () => {
  fixtureFormData();
  try {
    const h = setup("sign-up");
    let calls = 0;
    globalThis.fetch = async () => {
      calls++;
      return Response.json({});
    };
    await h
      .render()
      .find((n) => n.type === "form")
      .props.onSubmit({
        preventDefault() {},
        currentTarget: h.form({
          name: "Buyer",
          email: "buyer@example.test",
          password: "strong-password-123",
          confirmPassword: "different",
          terms: "on",
        }),
      });
    assert.equal(calls, 0);
    assert.match(h.focused, /confirmPassword/);
    assert.match(state[7].confirmPassword, /do not match/);
  } finally {
    globalThis.FormData = NativeFormData;
  }
});
test("password reset removes used token, returns to sign in and preserves order destination", async () => {
  fixtureFormData();
  try {
    const h = setup("password", "?token=one-use-token");
    let request;
    globalThis.fetch = async (url, options) => {
      request = { url, body: JSON.parse(options.body) };
      return Response.json({ status: true });
    };
    await h
      .render()
      .find((n) => n.type === "form")
      .props.onSubmit({
        preventDefault() {},
        currentTarget: h.form({
          password: "strong-password-123",
          confirmPassword: "strong-password-123",
        }),
      });
    assert.equal(request.url, "/api/auth/reset-password");
    assert.equal(request.body.token, "one-use-token");
    assert.equal(state[0], "sign-in");
    assert.equal(h.replaced, "/sign-in?returnTo=%2Forder%2F123");
    assert.doesNotMatch(h.replaced, /token/);
    assert.equal(h.assigned, "");
  } finally {
    globalThis.FormData = NativeFormData;
  }
});
test("unverified sign in cannot redirect and offers actual verification resend", async () => {
  fixtureFormData();
  try {
    const h = setup("sign-in");
    globalThis.fetch = async () =>
      Response.json({ code: "EMAIL_NOT_VERIFIED" }, { status: 403 });
    await h
      .render()
      .find((n) => n.type === "form")
      .props.onSubmit({
        preventDefault() {},
        currentTarget: h.form({
          email: "buyer@example.test",
          password: "strong-password-123",
        }),
      });
    assert.equal(h.assigned, "");
    assert.equal(state[2], "buyer@example.test");
    h.render()
      .find((n) => n.type === "button" && n.props.className === "entry-resend")
      .props.onClick();
    let request;
    globalThis.fetch = async (url, options) => {
      request = { url, body: JSON.parse(options.body) };
      return Response.json({ status: true });
    };
    await h
      .render()
      .find((n) => n.type === "form")
      .props.onSubmit({
        preventDefault() {},
        currentTarget: h.form({ email: "buyer@example.test" }),
      });
    assert.equal(request.url, "/api/auth/send-verification-email");
    assert.match(request.body.callbackURL, /returnTo=%2Forder%2F123/);
    assert.equal(h.assigned, "");
  } finally {
    globalThis.FormData = NativeFormData;
  }
});
test("in-flight signup disables fields and suppresses duplicate submissions", async () => {
  fixtureFormData();
  try {
    const h = setup("sign-up");
    let release,
      calls = 0;
    globalThis.fetch = (url) => {
      if (url === "/api/policies/terms") return Promise.resolve(Response.json({version:1}));
      calls++;
      return new Promise(
        (resolve) =>
          (release = () => resolve(Response.json({ user: { id: "fixture" } }))),
      );
    };
    const event = {
      preventDefault() {},
      currentTarget: h.form({
        name: "Buyer",
        email: "buyer@example.test",
        password: "strong-password-123",
        confirmPassword: "strong-password-123",
        terms: "on",
      }),
    };
    const pending = h
      .render()
      .find((n) => n.type === "form")
      .props.onSubmit(event);
    assert.equal(
      h.render().find((n) => n.type === "fieldset").props.disabled,
      true,
    );
    await new Promise((resolve) => setImmediate(resolve));
    await h
      .render()
      .find((n) => n.type === "form")
      .props.onSubmit(event);
    assert.equal(calls, 1);
    release();
    await pending;
    assert.equal(h.assigned, "");
    assert.match(state[5], /verify your account/);
  } finally {
    globalThis.FormData = NativeFormData;
  }
});

test("empty and non-JSON auth responses never claim success or redirect", async () => {
  fixtureFormData();
  try {
    for (const mode of ['sign-up','sign-in']) {
      for (const status of [200,500]) {
        const h=setup(mode);
        globalThis.fetch=async(url)=>url==="/api/policies/terms"?Response.json({version:1}):new Response(status===200?'':'<html>Unavailable</html>',{status});
        await h.render().find(n=>n.type==='form').props.onSubmit({preventDefault(){},currentTarget:h.form({name:'Buyer',email:'buyer@example.test',password:'strong-password-123',confirmPassword:'strong-password-123',terms:'on'})});
        assert.equal(h.assigned,'');
        assert.equal(state[6],false);
        assert.match(state[5],/server could not confirm/);
        assert.doesNotMatch(state[5],/JSON|Unexpected end/);
      }
    }
  } finally { globalThis.FormData=NativeFormData; }
});
