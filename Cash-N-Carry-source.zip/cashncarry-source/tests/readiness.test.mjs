import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import assert from 'node:assert/strict';
import { sourceModule } from './load-route.mjs';
const db = new DatabaseSync(':memory:');
for (const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort()) db.exec(readFileSync('drizzle/'+file,'utf8'));
let batches = 0, individualReads = 0;
class Query {
  constructor(sql,args=[]){this.sql=sql;this.args=args;}
  bind(...args){return new Query(this.sql,args);}
  async all(){individualReads++;return {results:db.prepare(this.sql).all(...this.args)};}
  async first(){return db.prepare(this.sql).get(...this.args)||null;}
  async run(){return db.prepare(this.sql).run(...this.args);}
}
globalThis.testEnv={REVIBE_ADMIN_EMAIL:'admin@test.invalid',DB:{prepare:sql=>new Query(sql),batch:async queries=>{
  batches++;db.exec('BEGIN');
  try {const result=queries.map(q=>({results:db.prepare(q.sql).all(...q.args)}));db.exec('COMMIT');return result;}
  catch(e){db.exec('ROLLBACK');throw e;}
}}};
globalThis.testUser=null;
const backup=await import(sourceModule('app/api/admin/backup/route.ts'));
const request=(body={confirm:'EXPORT PRIVATE BACKUP'},origin='https://app.test')=>new Request('https://app.test/api/admin/backup',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
assert.equal((await backup.POST(request())).status,403);
globalThis.testUser={userId:'buyer',email:'buyer@test.invalid'};
assert.equal((await backup.POST(request())).status,403);
globalThis.testUser={userId:'admin',email:'admin@test.invalid'};
assert.equal((await backup.POST(request({},'https://attacker.test'))).status,403);
assert.equal((await backup.POST(request({}))).status,400);
assert.equal(batches,0);
db.prepare("INSERT INTO profiles(id,email,name,created,last_seen) VALUES('buyer','buyer@test.invalid','Buyer','now','now')").run();
const result=await backup.POST(request());assert.equal(result.status,200);
const body=await result.json();assert.equal(body.format,'revibe-backup-v1');assert(Array.isArray(body.tables.live_blocks));assert(Array.isArray(body.tables.live_viewers));assert.equal(body.tables.profiles[0].id,'buyer');
assert.equal(batches,1);assert.equal(individualReads,0);assert.equal(result.headers.get('Cache-Control'),'no-store');
assert.equal(db.prepare("SELECT COUNT(*) AS count FROM admin_audit WHERE action='backup_export' AND actor='admin'").get().count,1);
console.log('PASS: admin/origin/confirmation gated backup, one transactional read snapshot, no-store and export audit.');
const verify=await import(sourceModule('app/api/payments/verify/route.ts'));
const verification=body=>new Request('https://app.test/api/payments/verify',{method:'POST',headers:{origin:'https://app.test','Content-Type':'application/json'},body:JSON.stringify(body)});
globalThis.testUser=null;assert.equal((await verify.POST(verification({reference:'id',transaction:'123'}))).status,401);
globalThis.testUser={userId:'buyer',email:'buyer@test.invalid'};
let providerCalls=0;const originalFetch=globalThis.fetch;globalThis.fetch=async()=>{providerCalls++;throw Error('Unexpected provider request');};
try{
  assert.equal((await verify.POST(verification({reference:'x'.repeat(101),transaction:'123'}))).status,400);
  assert.equal((await verify.POST(verification({reference:'id',transaction:'../secret'}))).status,400);
  assert.equal((await verify.POST(verification({reference:'id',transaction:'123'}))).status,404);
  for(let n=0;n<12;n++)assert.equal((await verify.POST(verification({reference:'id',transaction:'123'}))).status,404);
  const limited=await verify.POST(verification({reference:'id',transaction:'123'}));assert.equal(limited.status,429);assert.equal(limited.headers.get('Retry-After'),'60');
  assert.equal(providerCalls,0);
}finally{globalThis.fetch=originalFetch;}
console.log('PASS: payment verification rejects invalid/unowned references and limits attempts without contacting provider.');
