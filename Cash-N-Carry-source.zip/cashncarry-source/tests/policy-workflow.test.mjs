import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import { sourceModule } from "./load-route.mjs";

const db = new DatabaseSync(":memory:");
for (const file of readdirSync("drizzle").filter((file) => file.endsWith(".sql")).sort()) db.exec(readFileSync(`drizzle/${file}`, "utf8"));
class Query {
  constructor(sql, args = []) { this.sql = sql; this.args = args; }
  bind(...args) { return new Query(this.sql, args); }
  async first() { return db.prepare(this.sql).get(...this.args) || null; }
  async all() { return { results: db.prepare(this.sql).all(...this.args) }; }
  async run() { return db.prepare(this.sql).run(...this.args); }
}
globalThis.testEnv = { REVIBE_ADMIN_EMAIL: "owner@example.invalid", DB: {
  prepare: (sql) => new Query(sql),
  batch: async (queries) => { db.exec("BEGIN"); try { const rows = []; for (const query of queries) rows.push(await query.run()); db.exec("COMMIT"); return rows; } catch (error) { db.exec("ROLLBACK"); throw error; } },
} };
globalThis.testUser = { userId: "staff", email: "staff@example.invalid" };
globalThis.fixtureAdminRole = "admin";
const api = await import(sourceModule("app/api/admin/policies/route.ts"));
const owner = { userId: "owner", email: "owner@example.invalid" };
const post = (body, user = globalThis.testUser) => {
  globalThis.testUser = user;
  return api.POST(new Request("https://app.test/api/admin/policies", { method: "POST", headers: { origin: "https://app.test", "Content-Type": "application/json" }, body: JSON.stringify(body) }));
};

test("policy versions seed as private drafts and enforce review, owner approval, and publication transitions", async () => {
  const seeded = await (await api.GET()).json();
  assert.equal(seeded.policies.length, 6);
  assert.ok(seeded.policies.every((policy) => policy.versions[0].status === "draft"));
  const privacy = seeded.policies.find((policy) => policy.id === "privacy");
  const review = await post({ action: "submit-review", policyId: "privacy", versionId: privacy.versions[0].id, reason: "Submit exact draft", confirm: true });
  assert.equal(review.status, 409);
  assert.equal((await (await api.GET()).json()).policies.find((p) => p.id === "privacy").versions[0].status, "draft");
  const unresolved = await post({ action: "approve", policyId: "privacy", versionId: privacy.versions[0].id, reason: "Owner approval", confirm: true }, owner);
  assert.equal(unresolved.status, 409);
  assert.equal(db.prepare("SELECT reviewed FROM policies WHERE id='privacy'").get()?.reviewed ?? 0, 0);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM admin_audit WHERE action='policy-approve'").get().n, 0);
});

test("public page routes select published versions only and stay noindex until publication", () => {
  const source = readFileSync("app/policy-page.tsx", "utf8");
  assert.match(source, /status='published'/);
  assert.match(source, /if \(!record\) \{/);
  assert.match(source, /No draft policy text is shown on this page/);
  assert.doesNotMatch(source, /if \(!record\) notFound\(\)/);
  assert.match(source, /robots: record \? \{ index: true, follow: true \} : \{ index: false, follow: false \}/);
});

test("help uses the confirmed customer support address and discloses pending response coverage", () => {
  const source = readFileSync("app/help/page.tsx", "utf8");
  assert.match(source, /const email = "support@cashncarryng\.com"/);
  assert.match(source, /Support response coverage is being confirmed/);
  assert.doesNotMatch(source, /notifications@cashncarryng\.com/);
});

test("clean replacement requires owner MFA identity and records approval and publication evidence", async () => {
  const clean = "Effective date: 2026-10-10\n\n1. Privacy process\nThis is a fully resolved test fixture policy text. It contains no unresolved placeholders, proposals, or unverified commitments and is used only to exercise approval controls.";
  const saved = await post({ action: "save-draft", policyId: "privacy", content: clean, reason: "Resolve review blockers" });
  assert.equal(saved.status, 200);
  const submitted = await post({ action: "submit-review", policyId: "privacy", versionId: (await (await api.GET()).json()).policies.find((p) => p.id === "privacy").versions[0].id, reason: "Submit resolved text", confirm: true });
  assert.equal(submitted.status, 200);
  const version = (await (await api.GET()).json()).policies.find((p) => p.id === "privacy").versions[0];
  const approval = await post({ action: "approve", policyId: "privacy", versionId: version.id, reason: "Owner approved test fixture", confirm: true }, owner);
  assert.equal(approval.status, 200);
  assert.equal(db.prepare("SELECT reviewed FROM policies WHERE id='privacy'").get().reviewed, 1);
  const checklist = { legalReview: true, operationalReview: true, supportMailbox: true, privacyInventory: true, addressReview: true };
  const publication = await post({ action: "publish", policyId: "privacy", versionId: version.id, reason: "Publish test fixture", confirm: true, effectiveDate: "2026-10-10", checklist }, owner);
  assert.equal(publication.status, 200);
  const recorded = db.prepare("SELECT status,approved_by_email,published_by_email,effective_date FROM policy_versions WHERE id=?").get(version.id);
  assert.equal(recorded.status, "published");
  assert.equal(recorded.approved_by_email, owner.email);
  assert.equal(recorded.published_by_email, owner.email);
  assert.equal(recorded.effective_date, "2026-10-10");
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM admin_audit WHERE action IN ('policy-approve','policy-publish')").get().n, 2);
});

test("policy links cover footer, registration, checkout, seller workspace, and help", () => {
  const footer = readFileSync("app/revibe.tsx", "utf8");
  const footerStart = footer.indexOf("<footer>");
  const footerMarkup = footer.slice(footerStart, footer.indexOf("</footer>", footerStart));
  const auth = readFileSync("app/account/auth-form.tsx", "utf8");
  const help = readFileSync("app/help/page.tsx", "utf8");
  const requiredRoutes = ["/privacy", "/terms", "/delivery", "/refunds", "/seller-terms", "/community-guidelines"];
  for (const route of requiredRoutes) {
    assert.ok(footerMarkup.includes(`href=\"${route}\"`), `${route} should be in the website footer`);
    assert.ok(help.includes(`href=\"${route}\"`), `${route} should be in Help`);
  }
  assert.match(footer, /checkout-policy-links[\s\S]*?href=\"\/terms\"/);
  assert.match(footer, /seller-policy-links[\s\S]*?href=\"\/seller-terms\"/);
  assert.match(auth, /href="\/terms"/);
  assert.match(auth, /href="\/privacy"/);
  assert.match(auth, /termsAccepted: true/);
  assert.doesNotMatch(auth, /marketing.*required|agree.*marketing/i);
  assert.match(help, /href="\/community-guidelines"/);
  const css = readFileSync("app/premium.css", "utf8");
  assert.match(css, /policy-editor-heading\{display:flex/);
  assert.match(css, /policy-editor-heading\{padding:16px;flex-direction:column/);
  assert.match(readFileSync("app/policies/[id]/page.tsx", "utf8"), /returns: "\/refunds"/);
});
