import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import { onboardFixtureSellers } from "./seller-fixture.mjs";
import { sourceModule } from "./load-route.mjs";

function database() {
  const db = new DatabaseSync(":memory:");
  for (const file of readdirSync("drizzle").filter((name) => name.endsWith(".sql")).sort())
    db.exec(readFileSync(`drizzle/${file}`, "utf8"));
  db.exec("INSERT INTO profiles(id,email,name,created,last_seen) VALUES('seller','seller@example.invalid','Seller','now','now'),('buyer','buyer@example.invalid','Buyer','now','now'); INSERT INTO stores(id,owner,name,category,location,created) VALUES('store','seller','Shop','Goods','Lagos','now');");
  onboardFixtureSellers(db);
  db.exec("INSERT INTO streams(id,store,title,url,status,provider,heartbeat,created) VALUES('stream','store','Live','','live','external','now','now');");
  return db;
}

function testEnvironment(db){
  class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args);}async first(){return db.prepare(this.sql).get(...this.args)||null;}async all(){return{results:db.prepare(this.sql).all(...this.args)};}async run(){return{meta:db.prepare(this.sql).run(...this.args)};}}
  return{FLW_MODE:"test",DB:{prepare(sql){return new Statement(sql);},async batch(statements){db.exec("BEGIN");try{const result=[];for(const statement of statements)result.push(await statement.run());db.exec("COMMIT");return result;}catch(error){db.exec("ROLLBACK");throw error;}}}};
}

function addProduct(db, id, price, stock) {
  db.prepare("INSERT INTO products(id,store,name,description,category,price,stock,image,active,created) VALUES(?, 'store', ?, '', 'Goods', ?, ?, '/image',1,'now')").run(id, id, price, stock);
}

function addOrder(db, id, payment = "flutterwave") {
  db.prepare("INSERT INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,delivery_fee,delivery_state,created,seller_activation_required) VALUES(?,'buyer','store','Buyer','','',1000,'placed',?,'pending',0,'Lagos','now',1)").run(id, payment);
}

test("migration installs six competitive feature domains without destructive changes", () => {
  const db = database();
  const tables = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((x) => x.name));
  for (const table of ["livestream_deals", "seller_analytics_events", "product_bundles", "creator_profiles", "affiliate_partnerships", "affiliate_commissions", "live_auctions", "auction_bids", "founding_enrollments"])
    assert(tables.has(table), `missing ${table}`);
  assert.equal(db.prepare("SELECT enabled,duration_days FROM founding_program WHERE id=1").get().enabled, 0);
  assert.equal(db.prepare("SELECT duration_days FROM founding_program WHERE id=1").get().duration_days, 30);
});

test("live deals reject invalid price, overlapping windows and promotional oversell; cancelled orders restore capacity", () => {
  const db = database(); addProduct(db, "item", 10000, 3);
  const start = new Date(Date.now() - 1000).toISOString(), end = new Date(Date.now() + 60000).toISOString();
  db.prepare("INSERT INTO livestream_deals(id,store,product,stream,promo_price,max_quantity,starts_at,ends_at,status,created,updated) VALUES('deal','store','item','stream',7000,2,?,?,'active','now','now')").run(start, end);
  assert.throws(() => db.prepare("INSERT INTO livestream_deals(id,store,product,stream,promo_price,max_quantity,starts_at,ends_at,status,created,updated) VALUES('overlap','store','item','stream',6000,1,?,?,'scheduled','now','now')").run(start, end), /Overlapping/);
  addOrder(db, "deal-order");
  db.prepare("INSERT INTO order_deal_snapshots(order_id,deal,product,quantity,price) VALUES('deal-order','deal','item',2,7000)").run();
  assert.equal(db.prepare("SELECT sold_quantity FROM livestream_deals WHERE id='deal'").get().sold_quantity, 2);
  addOrder(db, "deal-order-2");
  assert.throws(() => db.prepare("INSERT INTO order_deal_snapshots(order_id,deal,product,quantity,price) VALUES('deal-order-2','deal','item',1,7000)").run(), /unavailable/);
  db.prepare("UPDATE orders SET status='cancelled' WHERE id='deal-order'").run();
  assert.equal(db.prepare("SELECT sold_quantity FROM livestream_deals WHERE id='deal'").get().sold_quantity, 0);
});

test("bundle component ownership and inventory are enforced and immutable snapshots restore stock", () => {
  const db = database(); addProduct(db, "one", 2000, 5); addProduct(db, "two", 3000, 4); addProduct(db, "bundle-product", 4000, 2);
  db.exec("INSERT INTO product_bundles(id,store,product,title,description,image,price,active,created,updated) VALUES('bundle','store','bundle-product','Pair','','/image',4000,1,'now','now'); INSERT INTO product_bundle_items(bundle,product,quantity,name_snapshot,price_snapshot) VALUES('bundle','one',2,'one',2000),('bundle','two',1,'two',3000);");
  assert.throws(() => db.exec("INSERT INTO product_bundle_items(bundle,product,quantity,name_snapshot,price_snapshot) VALUES('bundle','bundle-product',1,'bundle',4000)"), /Invalid bundle component/);
  addOrder(db, "bundle-order");
  db.prepare("INSERT INTO bundle_order_snapshots(order_id,bundle,title,contents,bundle_price) VALUES('bundle-order','bundle','Pair',?,4000)").run(JSON.stringify([{id:"one",quantity:2},{id:"two",quantity:1}]));
  db.prepare("INSERT INTO order_items(id,order_id,product,name,price,quantity,variant) VALUES('oi','bundle-order','bundle-product','Pair',4000,1,'')").run();
  assert.equal(db.prepare("SELECT stock FROM products WHERE id='one'").get().stock, 3);
  assert.equal(db.prepare("SELECT stock FROM products WHERE id='two'").get().stock, 3);
  db.prepare("UPDATE orders SET status='cancelled' WHERE id='bundle-order'").run();
  assert.equal(db.prepare("SELECT stock FROM products WHERE id='one'").get().stock, 5);
  assert.equal(db.prepare("SELECT stock FROM products WHERE id='two'").get().stock, 4);
});

test("analytics deduplication and affiliate commission states exclude unpaid orders", () => {
  const db = database(); addProduct(db, "item", 10000, 3);
  db.prepare("INSERT INTO seller_analytics_events(id,store,product,stream,visitor,event,day,created) VALUES('e1','store','item','stream','visitor','product_view','2026-10-13','now')").run();
  assert.throws(() => db.prepare("INSERT INTO seller_analytics_events(id,store,product,stream,visitor,event,day,created) VALUES('e2','store','item','stream','visitor','product_view','2026-10-13','now')").run(), /UNIQUE/);
  db.exec("INSERT INTO creator_profiles(user,display_name,created,updated) VALUES('creator','Creator','now','now'); INSERT INTO affiliate_partnerships(id,creator,store,product,commission_bps,status,created,updated) VALUES('partnership','creator','store','item',1000,'approved','now','now');");
  addOrder(db, "affiliate-order");
  db.prepare("INSERT INTO affiliate_commissions(id,partnership,order_id,amount,created,updated) VALUES('commission','partnership','affiliate-order',1000,'now','now')").run();
  assert.equal(db.prepare("SELECT status FROM affiliate_commissions WHERE id='commission'").get().status, "pending");
  db.prepare("UPDATE orders SET status='cancelled' WHERE id='affiliate-order'").run();
  assert.equal(db.prepare("SELECT status FROM affiliate_commissions WHERE id='commission'").get().status, "reversed");
});

test("auction API validates authenticated bids, deduplicates requests and creates only an unpaid winner order", async () => {
  const db=database();addProduct(db,"auction-item",10000,2);
  globalThis.testEnv=testEnvironment(db);
  const api=await import(sourceModule("app/api/live-auctions/route.ts"));
  const user=(id)=>globalThis.testUser=id?{userId:id,email:`${id}@example.invalid`,displayName:id,fullName:id}:null;
  const post=async(body)=>{const response=await api.POST(new Request("https://shop.test/api/live-auctions",{method:"POST",headers:{origin:"https://shop.test","Content-Type":"application/json"},body:JSON.stringify(body)}));return{status:response.status,body:await response.json()};};
  const get=async(path)=>{const response=await api.GET(new Request(`https://shop.test${path}`));return{status:response.status,body:await response.json()};};
  user("seller");
  const startsAt=new Date(Date.now()+1000).toISOString(),endsAt=new Date(Date.now()+8000).toISOString();
  const created=await post({action:"create",product:"auction-item",stream:"stream",startPrice:1000,increment:100,reservePrice:1200,startsAt,endsAt});
  assert.equal(created.status,200,JSON.stringify(created.body));
  const auction=created.body.id;
  db.prepare("UPDATE live_auctions SET starts_at=? WHERE id=?").run(new Date(Date.now()-1000).toISOString(),auction);
  await new Promise(resolve=>setTimeout(resolve,1100));
  user(null);assert.equal((await get("/api/live-auctions")).body.auctions.length,0,"signed-out buyers get no public auction catalogue");
  user("buyer");assert.equal((await get("/api/live-auctions?stream=stream")).body.auctions.length,1,"buyers see the auction inside its live broadcast");const requestId=crypto.randomUUID();
  const first=await post({action:"bid",auction,amount:1000,requestId});assert.equal(first.status,200,JSON.stringify(first.body));
  const duplicate=await post({action:"bid",auction,amount:1000,requestId});assert.equal(duplicate.status,200);assert.equal(duplicate.body.duplicate,true);
  const below=await post({action:"bid",auction,amount:1050,requestId:crypto.randomUUID()});assert.equal(below.status,400);assert.match(below.body.error,/at least/i);
  const winning=await post({action:"bid",auction,amount:1200,requestId:crypto.randomUUID()});assert.equal(winning.status,200,JSON.stringify(winning.body));
  user("seller");const ended=await post({action:"end",auction});assert.equal(ended.status,200,JSON.stringify(ended.body));assert(ended.body.orderId);
  const order=db.prepare("SELECT payment,payment_status,total FROM orders WHERE id=?").get(ended.body.orderId);assert.deepEqual({...order},{payment:"auction",payment_status:"pending",total:1200});
  assert.equal(db.prepare("SELECT status FROM live_auctions WHERE id=?").get(auction).status,"ended");
  db.prepare("UPDATE streams SET status='ended' WHERE id='stream'").run();
  user(null);assert.equal((await get("/api/live-auctions?stream=stream")).body.auctions.length,0,"offline broadcasts expose no auctions");
  user("buyer");const offlineBid=await post({action:"bid",auction,amount:1300,requestId:crypto.randomUUID()});assert.equal(offlineBid.status,400);assert.match(offlineBid.body.error,/only available while its livestream is live/i);
  user(null);const settled=await post({action:"settle",auction});assert.equal(settled.status,200);assert.equal(db.prepare("SELECT COUNT(*) n FROM orders WHERE id=?").get(ended.body.orderId).n,1);
});

test("founding sellers must be verified, admin-approved and inside their configured access period",async()=>{
 const db=database();db.prepare("DELETE FROM seller_subscriptions WHERE store='store'").run();
 globalThis.foundingEnv=testEnvironment(db);globalThis.foundingEnv.REVIBE_ADMIN_EMAIL="admin@example.invalid";
 const api=await import(sourceModule("app/api/founding-sellers/route.ts","foundingEnv","foundingUser"));const {sellerActivation}=await import(sourceModule("app/seller-activation.ts","foundingEnv","foundingUser"));const user=id=>globalThis.foundingUser=id?{userId:id,email:`${id}@example.invalid`,displayName:id}:null;
 const post=async(body)=>{const response=await api.POST(new Request("https://shop.test/api/founding-sellers",{method:"POST",headers:{origin:"https://shop.test","Content-Type":"application/json"},body:JSON.stringify(body)}));return{status:response.status,body:await response.json()};};
 user("admin");assert.equal((await post({action:"configure",enabled:true,durationDays:30,maxParticipants:1,eligibility:"Verified sellers only"})).status,200);
 user("seller");let result=await post({action:"apply"});assert.equal(result.status,200);assert.equal(result.body.status,"pending",JSON.stringify(result.body));
 user("admin");result=await post({action:"approve",store:"store"});assert.equal(result.status,200,JSON.stringify(result.body));
 const access=await sellerActivation("store");assert.equal(access.foundingActive,true);assert.equal(access.canSell,true);
 db.prepare("UPDATE founding_enrollments SET ends_at=? WHERE store='store'").run(new Date(Date.now()-1000).toISOString());
 const expired=await sellerActivation("store");assert.equal(expired.foundingActive,false);assert.equal(expired.canSell,false);
});
