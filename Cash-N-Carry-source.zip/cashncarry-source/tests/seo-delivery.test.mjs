import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import assert from 'node:assert/strict';
import {sourceModule} from './load-route.mjs';
const db=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+f,'utf8'));
class Q{constructor(s,a=[]){this.s=s;this.a=a;}bind(...a){return new Q(this.s,a);}async all(){return {results:db.prepare(this.s).all(...this.a)};}}
globalThis.testEnv={SITE_URL:'https://cashncarryng.com',DB:{prepare:s=>new Q(s)}};
const sitemap=await import(sourceModule('app/sitemap.xml/route.ts'));
const r=await sitemap.GET();assert.equal(r.status,200);assert.match(r.headers.get('content-type'),/application\/xml/);assert.match(await r.text(),/<loc>https:\/\/cashncarryng.com\/help<\/loc>/);
const robots=await import(sourceModule('app/robots.txt/route.ts'));assert.match(await robots.GET().text(),/Sitemap: https:\/\/cashncarryng.com\/sitemap.xml/);
const llms=await import(sourceModule('app/llms.txt/route.ts'));assert.equal(llms.GET().status,200);assert.match(await llms.GET().text(),/Independent sellers/);
console.log('PASS: sitemap XML, crawler discovery and public information route');

globalThis.testEnv.DB.prepare = () => ({all:async()=>{throw Error('temporary outage')}});
const degraded=await sitemap.GET();assert.equal(degraded.status,200);const fallback=await degraded.text();assert.match(fallback,/<loc>https:\/\/cashncarryng.com\/help<\/loc>/);assert.doesNotMatch(fallback,/\/product\//);
console.log('PASS: crawler sitemap survives transient database failures without advertising unavailable products');
