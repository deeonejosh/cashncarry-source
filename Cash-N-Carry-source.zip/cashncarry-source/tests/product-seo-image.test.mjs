import assert from "node:assert/strict";
import { sourceModule } from "./load-route.mjs";

const seo = await import(sourceModule("app/product-seo.ts"));
assert.equal(seo.productSeoDescription("Silk scarf", "Soft &amp; washable scarf <b>for daily wear</b>"), "Silk scarf: Soft & washable scarf for daily wear");
assert.equal(seo.productSeoDescription("A", "x".repeat(300)).length, 153);
assert.equal(seo.absoluteProductImage("", "https://cashncarryng.com"), undefined);
assert.equal(seo.absoluteProductImage("/api/media/photo", "https://cashncarryng.com"), "https://cashncarryng.com/api/media/photo");
assert.equal(seo.absoluteProductImage("javascript:alert(1)", "https://cashncarryng.com"), undefined);

const optimizer = await import(sourceModule("app/optimize-product-image.ts"));
const originalBitmap = globalThis.createImageBitmap;
const originalDocument = globalThis.document;
try {
  let closed = false;
  let dimensions;
  globalThis.createImageBitmap = async () => ({ width: 4000, height: 2000, close() { closed = true; } });
  globalThis.document = { createElement() { return {
    set width(value) { dimensions = { ...dimensions, width: value }; },
    set height(value) { dimensions = { ...dimensions, height: value }; },
    getContext() { return { drawImage() {} }; },
    toBlob(callback, type, quality) { assert.equal(type, "image/webp"); assert.equal(quality, 0.84); callback(new Blob([new Uint8Array(100_000)], { type })); },
  }; } };
  const source = new File([new Uint8Array(2_000_000)], "camera.jpg", { type: "image/jpeg", lastModified: 123 });
  const optimized = await optimizer.optimizeProductImage(source);
  assert.equal(optimized.type, "image/webp");
  assert.equal(optimized.name, "camera.webp");
  assert.equal(optimized.size, 100_000);
  assert.deepEqual(dimensions, { width: 1200, height: 600 });
  assert.equal(closed, true);

  const qualities = [];
  globalThis.createImageBitmap = async () => ({ width: 1059, height: 1071, close() {} });
  globalThis.document = { createElement() { return {
    set width(_) {},
    set height(_) {},
    getContext() { return { drawImage() {} }; },
    toBlob(callback, type, quality) {
      qualities.push(quality);
      callback(new Blob([new Uint8Array(quality === 0.84 ? 150_000 : 110_000)], { type }));
    },
  }; } };
  const medium = new File([new Uint8Array(167_700)], "product.jpg", { type: "image/jpeg" });
  const optimizedMedium = await optimizer.optimizeProductImage(medium);
  assert.equal(optimizedMedium.type, "image/webp");
  assert.equal(optimizedMedium.size, 110_000);
  assert.deepEqual(qualities, [0.84, 0.76, 0.68]);

  globalThis.document = { createElement() { return {
    set width(_) {},
    set height(_) {},
    getContext() { return { drawImage() {} }; },
    toBlob(callback, type) { callback(new Blob([new Uint8Array(160_000)], { type })); },
  }; } };
  assert.equal(await optimizer.optimizeProductImage(medium), medium);

  globalThis.createImageBitmap = undefined;
  assert.equal(await optimizer.optimizeProductImage(source), source);
} finally {
  globalThis.createImageBitmap = originalBitmap;
  globalThis.document = originalDocument;
}

console.log("PASS: concise product metadata, safe omission of empty-image metadata, and client-side image optimization with browser fallback.");
