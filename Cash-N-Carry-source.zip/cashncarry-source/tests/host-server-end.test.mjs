import test from 'node:test';
import assert from 'node:assert/strict';
import ts from 'typescript';
import {readFileSync} from 'node:fs';
const source=ts.createSourceFile('workspace.tsx',readFileSync('app/workspace/page.tsx','utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
let callback;
function visit(n){if(ts.isCallExpression(n)&&n.expression.getText(source)==='useEffect'&&n.arguments[0].getText(source).includes('setHostChat'))callback=n.arguments[0].getText(source);ts.forEachChild(n,visit);}
visit(source);
const code=ts.transpileModule('const run='+callback+'; return run();',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
const drain=()=>new Promise(r=>setImmediate(r));
function fixture({status='ended',deferred=false}={}){
 const state={};let resolve;const response=new Promise(r=>resolve=r);
 const broadcast={current:'host'},generation={current:4};let released=0;
 const run=new Function('active','broadcast','generation','releaseMedia','setActive','setPreviewId','setStarting','setConnectionLabel','setMessage','setHostChat','setHostViewers','fetch','setInterval','clearInterval',code);
 const put=key=>value=>{state[key]=value};
 const cleanup=run('host',broadcast,generation,()=>{released++;broadcast.current=''},put('active'),put('preview'),put('starting'),put('connection'),put('message'),put('chat'),put('viewers'),async()=>deferred?response:Response.json({stream:{status},chats:[],viewers:2}),()=>1,()=>{});
 return {state,broadcast,generation,cleanup,released:()=>released,resolve:()=>resolve(Response.json({stream:{status},chats:[],viewers:2}))};
}
test('server-ended broadcast stops local media without another server end request',async()=>{
 const f=fixture();await drain();assert.equal(f.released(),1);assert.equal(f.generation.current,5);assert.equal(f.state.active,'');assert.equal(f.state.starting,false);assert.equal(f.state.connection,'Ended');assert.match(f.state.message,/Camera and microphone stopped/);f.cleanup();
});
test('live status retains camera and updates actual viewer data',async()=>{
 const f=fixture({status:'live'});await drain();assert.equal(f.released(),0);assert.equal(f.state.viewers,2);assert.deepEqual(f.state.chat,[]);f.cleanup();
});
test('late ended response cannot stop a newer broadcast',async()=>{
 const f=fixture({deferred:true});f.broadcast.current='new-host';f.resolve();await drain();assert.equal(f.released(),0);assert.deepEqual(f.state,{});f.cleanup();
});
