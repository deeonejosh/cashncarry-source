import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const marketplace=readFileSync('app/revibe.tsx','utf8');
const storefront=readFileSync('app/store-product-actions.tsx','utf8');
const storePage=readFileSync('app/store/[id]/page.tsx','utf8');

test('marketplace product cards expose independent direct-buy and cart actions',()=>{
  assert.match(marketplace,/className="product-card-buy"/);
  assert.match(marketplace,/className="product-card-add"/);
  assert.match(marketplace,/buyNow\(p\)/);
  assert.match(marketplace,/onClick=\{\(\) => add\(p\)\}/);
  assert.match(marketplace,/if \(variants\.length\) \{\s*setModal\(\{ type: "product", p \}\)/);
});

test('storefront product actions preserve cart on direct checkout and add cart independently',()=>{
  assert.match(storefront,/buyNow: product\.id/);
  assert.match(storefront,/preserveCartForSignIn\(product\.id, variant, 1, "\/store\/" \+ storeId, "buy-now"\)/);
  assert.match(storefront,/action: "cart"/);
  assert.match(storefront,/variants\.map/);
  assert.match(storePage,/StoreProductActions/);
  assert.match(storePage,/stock,variants/);
});
