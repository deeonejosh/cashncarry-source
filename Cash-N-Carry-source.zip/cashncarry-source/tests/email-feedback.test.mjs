import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import ts from "typescript";
import * as React from "react";
let state = [],
  refs = [],
  cursor = 0,
  refCursor = 0;
globalThis.emailFeedbackHarness = {
  React,
  useEffect() {},
  useState(initial) {
    const i = cursor++;
    if (!(i in state)) state[i] = initial;
    return [
      state[i],
      (value) =>
        (state[i] = typeof value === "function" ? value(state[i]) : value),
    ];
  },
  useRef(initial) {
    const i = refCursor++;
    return (refs[i] ??= { current: initial });
  },
};
const source = readFileSync("app/admin/settings/email.tsx", "utf8").replace(
  /import[\s\S]*?from\s*["'][^"']+["'];/g,
  "",
);
const js = ts.transpileModule(
  "const {React,useEffect,useState,useRef}=globalThis.emailFeedbackHarness;" +
    source,
  {
    compilerOptions: {
      module: ts.ModuleKind.ESNext,
      target: ts.ScriptTarget.ES2023,
      jsx: ts.JsxEmit.React,
    },
  },
).outputText;
const { default: Email } = await import(
  "data:text/javascript;base64," + Buffer.from(js).toString("base64")
);
function nodes(node, result = []) {
  if (Array.isArray(node)) node.forEach((n) => nodes(n, result));
  else if (node && typeof node === "object") {
    result.push(node);
    nodes(node.props?.children, result);
  }
  return result;
}
function setup() {
  state = [
    { configured: false, from: "sender@example.invalid", setupAvailable: true },
    "sender@example.invalid",
    "re_private_fixture_key_123456789",
  ];
  refs = [];
  cursor = refCursor = 0;
  return () => {
    cursor = refCursor = 0;
    return nodes(Email());
  };
}
const NativeFormData = globalThis.FormData;
function event(consent = true) {
  return { preventDefault() {}, currentTarget: { consent } };
}
function formData() {
  globalThis.FormData = class {
    constructor(form) {
      this.form = form;
    }
    get() {
      return this.form.consent ? "on" : null;
    }
  };
}
test("missing consent and demo sender display explicit error without a provider request", async () => {
  formData();
  try {
    const render = setup();
    let calls = 0;
    globalThis.fetch = async () => {
      calls++;
      return Response.json({});
    };
    await render()
      .find((n) => n.type === "form")
      .props.onSubmit(event(false));
    assert.equal(calls, 0);
    assert.match(state[4], /Not saved.*confirmation/);
    assert.equal(
      render().find((n) => n.props.role === "alert").props.className,
      "email-setup-feedback is-error",
    );
    state[1] = "onboarding@resend.dev";
    await render()
      .find((n) => n.type === "form")
      .props.onSubmit(event());
    assert.equal(calls, 0);
    assert.match(state[4], /verified sender domain/);
  } finally {
    globalThis.FormData = NativeFormData;
  }
});
test("server rejection is an alert above the form and preserves the entered key", async () => {
  formData();
  try {
    const render = setup();
    const key = state[2];
    globalThis.fetch = async () =>
      Response.json(
        { error: "Sender domain is not verified." },
        { status: 400 },
      );
    await render()
      .find((n) => n.type === "form")
      .props.onSubmit(event());
    const elements = render();
    const alert = elements.find((n) => n.props.role === "alert");
    assert.match(alert.props.children, /Not confirmed as saved.*not verified/);
    assert(
      elements.indexOf(alert) <
        elements.indexOf(elements.find((n) => n.type === "form")),
    );
    assert.equal(state[2], key);
    assert.equal(state[0].configured, false);
  } finally {
    globalThis.FormData = NativeFormData;
  }
});
test("rate limited responses display cooldown and prevent another submission", async () => {
  formData();
  try {
    const render = setup();
    let calls = 0;
    globalThis.fetch = async () => {
      calls++;
      return Response.json(
        { error: "Too many setup attempts." },
        { status: 429 },
      );
    };
    await render()
      .find((n) => n.type === "form")
      .props.onSubmit(event());
    assert.equal(state[6], 60);
    assert.equal(
      render().find((n) => n.type === "fieldset").props.disabled,
      true,
    );
    await render()
      .find((n) => n.type === "form")
      .props.onSubmit(event());
    assert.equal(calls, 1);
  } finally {
    globalThis.FormData = NativeFormData;
  }
});
test("confirmed success clears the browser key and displays saved status", async () => {
  formData();
  try {
    const render = setup();
    globalThis.fetch = async () =>
      Response.json({
        ok: true,
        configured: true,
        from: "sender@example.invalid",
        acceptedAt: "2026-10-10T06:00:00Z",
        message: "Encrypted settings saved.",
      });
    await render()
      .find((n) => n.type === "form")
      .props.onSubmit(event());
    assert.equal(state[0].configured, true);
    assert.equal(state[2], "");
    assert.equal(state[5], false);
    assert.match(state[4], /saved/);
  } finally {
    globalThis.FormData = NativeFormData;
  }
});
