import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync, existsSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { sourceModule } from "./load-route.mjs";
const db = new DatabaseSync(":memory:");
for (const f of readdirSync("drizzle")
  .filter((f) => f.endsWith(".sql"))
  .sort())
  db.exec(readFileSync("drizzle/" + f, "utf8"));
class Query {
  constructor(sql, args = []) {
    this.sql = sql;
    this.args = args;
  }
  bind(...args) {
    return new Query(this.sql, args);
  }
  async first() {
    return db.prepare(this.sql).get(...this.args) || null;
  }
  async all() {
    return { results: db.prepare(this.sql).all(...this.args) };
  }
  async run() {
    return db.prepare(this.sql).run(...this.args);
  }
}
globalThis.emailFixtures = {
  SITE_URL: "https://cashncarryng.com",
  REVIBE_ADMIN_EMAIL: "admin@example.invalid",
  DB: {
    prepare: (sql) => new Query(sql),
    batch: async (statements) => {
      db.exec("BEGIN");
      try {
        const results = [];
        for (const s of statements) results.push(await s.run());
        db.exec("COMMIT");
        return results;
      } catch (e) {
        db.exec("ROLLBACK");
        throw e;
      }
    },
  },
};
globalThis.emailFixtureUser = null;
const templates = await import(
  sourceModule("app/email-templates.ts", "emailFixtures")
);
const notifications = await import(
  sourceModule("app/notifications.ts", "emailFixtures")
);
const events = await import(
  sourceModule("app/email-events.ts", "emailFixtures")
);
const admin = await import(
  sourceModule(
    "app/api/admin/email-templates/route.ts",
    "emailFixtures",
    "emailFixtureUser",
  )
);
const webhook = await import(
  sourceModule("app/api/emails/webhook/route.ts", "emailFixtures")
);
const requests = (body, origin = "https://cashncarryng.com") =>
  new Request("https://cashncarryng.com/api/admin/email-templates", {
    method: "POST",
    headers: { origin, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
const user = (id, email, name) =>
  db
    .prepare(
      "INSERT INTO profiles(id,email,name,created,last_seen) VALUES(?,?,?,?,?)",
    )
    .run(id, email, name, "now", "now");
user("buyer", "buyer@example.invalid", "Real buyer");
user("seller", "seller@example.invalid", "Real seller");
db.prepare(
  "INSERT INTO stores(id,owner,name,category,location,created) VALUES('store','seller','Actual store','Tech','Stored location','now')",
).run();
db.prepare(
  "INSERT INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,delivery_fee,created) VALUES('order','buyer','store','Buyer','000000000','Private address',27500,'placed','flutterwave','pending',2500,'now')",
).run();
db.prepare(
  "INSERT INTO products(id,store,name,description,category,price,stock,image,variants,created) VALUES('product','store','Stored product','Stored description','Tech',12500,10,'https://example.invalid/product.png','[{\"name\":\"Stored variant\",\"price\":12500,\"stock\":10}]','now')",
).run();
db.prepare(
  "INSERT INTO order_items(id,order_id,product,name,price,quantity,variant) VALUES('item','order','product','Stored product',12500,2,'Stored variant')",
).run();
db.prepare(
  "INSERT INTO payments(id,order_id,buyer,amount,currency,mode,status,expires,created,updated) VALUES('payment','order','buyer',27500,'NGN','test','pending','later','now','now')",
).run();
test("every template renders email-safe HTML and text, real logo, canonical private links and labelled samples", () => {
  assert.equal(templates.emailTemplates.length, 41);
  assert(existsSync("public/brand/cash-n-carry-logo.png"));
  for (const t of templates.emailTemplates) {
    const r = templates.renderEmail(t.id, templates.sampleEmail(t.id), 2030);
    assert.match(r.html, /#FFF8EF/);
    assert.match(r.html, /#164B35/);
    assert.match(r.html, /SAMPLE PREVIEW/);
    assert.match(r.html, /© 2030 Cash N Carry/);
    assert.match(r.html, /alt="Cash N Carry"/);
    assert.match(r.text, /Watch Live\. Discover\. Shop\./);
    assert.match(r.text, /https:\/\/cashncarryng.com\/help/);
    assert.match(r.text, /\/privacy/);
    assert.doesNotMatch(r.text, /undefined|API key|card number/);
    assert(r.preview.length > 0);
    assert(r.html.length < 60000);
  }
  const unsafe = templates.renderEmail("support-response", {
    name: "<script>bad</script>",
    message: "<img src=x onerror=bad>",
    actionUrl: "https://evil.example",
    details: [["Reason", "<b>unsafe</b>"]],
  });
  assert.doesNotMatch(unsafe.html, /<script>|onerror=bad>/);
  assert.match(unsafe.html, /&lt;script&gt;/);
  assert.doesNotMatch(unsafe.html, /href="https:\/\/evil/);
  assert.equal(
    templates.emailLink(
      "https://revibe-commerce.ogundiyatemidayo1.chatgpt.site/order/123",
    ),
    "https://cashncarryng.com/order/123",
  );
});
test("order emails snapshot stored items and fees, gate seller fulfilment and receipt on verified payment and deduplicate retries", async () => {
  await events.orderEmail("order", "created");
  await events.orderEmail("order", "created");
  let rows = db.prepare("SELECT * FROM email_outbox").all();
  assert.equal(rows.length, 1);
  const data = JSON.parse(rows[0].body).data;
  assert.equal(data.items[0].name, "Stored product");
  assert.equal(data.items[0].variant, "Stored variant");
  assert(
    data.details.some(([k, v]) => k === "Delivery fee" && v === "₦2,500.00"),
  );
  assert.equal(rows[0].template, "order-confirmation");
  await events.orderEmail("order", "paid");
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE template='payment-receipt'",
      )
      .get().n,
    0,
  );
  db.prepare("UPDATE orders SET payment_status='paid' WHERE id='order'").run();
  db.prepare(
    "UPDATE payments SET status='paid',provider_id='verified-id' WHERE id='payment'",
  ).run();
  await events.orderEmail("order", "paid");
  await events.orderEmail("order", "paid");
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE template='payment-receipt'",
      )
      .get().n,
    1,
  );
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE template='seller-order'",
      )
      .get().n,
    1,
  );
  assert.match(
    db
      .prepare(
        "SELECT subject FROM email_outbox WHERE template='payment-receipt'",
      )
      .get().subject,
    /\[TEST\]/,
  );
  db.prepare("UPDATE orders SET status='confirmed' WHERE id='order'").run();
  db.prepare("UPDATE orders SET status='shipped' WHERE id='order'").run();
  db.prepare("UPDATE orders SET status='delivered' WHERE id='order'").run();
  await events.orderEmail("order", "delivered");
  await events.orderEmail("order", "delivered");
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE template='review-request'",
      )
      .get().n,
    1,
  );
});
test("refund approval never claims completion; case and seller events use stored references and responses", async () => {
  db.prepare(
    "INSERT INTO refunds(id,payment,order_id,amount,reason,status,created,updated) VALUES('refund','payment','order',27500,'Stored reason','approved_for_processing','now','now')",
  ).run();
  await events.refundEmail("refund", "Reviewer reason");
  const r = JSON.parse(
    db
      .prepare("SELECT body FROM email_outbox WHERE template='refund-update'")
      .get().body,
  );
  assert(r.data.details.some(([, v]) => /not yet been refunded/.test(v)));
  assert(r.data.details.some(([, v]) => v === "Reviewer reason"));
  db.prepare(
    "INSERT INTO reports(id,reporter,target_type,target,reason,details,status,resolution,created,updated) VALUES('case','buyer','return','order','Return reason','Stored detail','open','','now','now')",
  ).run();
  await events.caseEmail("case");
  await events.caseEmail("case");
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE template='return-request'",
      )
      .get().n,
    1,
  );
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE template='seller-return'",
      )
      .get().n,
    1,
  );
  db.prepare(
    "UPDATE reports SET status='resolved',resolution='Stored response',updated='later' WHERE id='case'",
  ).run();
  await events.caseEmail("case");
  assert.match(
    db
      .prepare("SELECT body FROM email_outbox WHERE template='return-decision'")
      .get().body,
    /Stored response/,
  );
  db.prepare(
    "INSERT INTO verification_requests(id,store,owner,legal_name,registration,file_key,file_type,status,note,created,updated) VALUES('verify','store','seller','Legal name','','PRIVATE-DOCUMENT','application/pdf','pending','','now','now')",
  ).run();
  await events.verificationEmail("verify");
  const verification = db
    .prepare(
      "SELECT body FROM email_outbox WHERE template='seller-verification'",
    )
    .get().body;
  assert.doesNotMatch(verification, /PRIVATE-DOCUMENT|Legal name/);
});
test("admin previews and sending require role, origin, explicit test recipient and consent; test retries cannot flush customers", async () => {
  assert.equal(
    (
      await admin.GET(
        new Request("https://cashncarryng.com/api/admin/email-templates"),
      )
    ).status,
    403,
  );
  globalThis.emailFixtureUser = {
    userId: "buyer",
    email: "buyer@example.invalid",
  };
  assert.equal((await admin.POST(requests({}))).status, 403);
  globalThis.emailFixtureUser = {
    userId: "admin",
    email: "admin@example.invalid",
  };
  assert.equal(
    (await admin.POST(requests({}, "https://evil.example"))).status,
    403,
  );
  let page = await (
    await admin.GET(
      new Request("https://cashncarryng.com/api/admin/email-templates"),
    )
  ).json();
  assert.equal(page.configuration.configured, false);
  assert.equal(page.configuration.replyTo, null);
  assert.doesNotMatch(JSON.stringify(page), /Private address/);
  assert.equal(
    (
      await admin.POST(
        requests({
          action: "reply-to",
          recipient: "reply@example.invalid",
          confirmed: false,
        }),
      )
    ).status,
    400,
  );
  assert.equal(
    (
      await admin.POST(
        requests({
          action: "reply-to",
          recipient: "reply@example.invalid",
          confirmed: true,
        }),
      )
    ).status,
    200,
  );
  globalThis.emailFixtures.RESEND_API_KEY = "fixture";
  globalThis.emailFixtures.EMAIL_FROM = "notifications@cashncarryng.com";
  db.prepare("DELETE FROM rate_limits").run();
  const key = crypto.randomUUID(),
    body = {
      action: "test",
      template: "verification",
      recipient: "controlled@example.invalid",
      confirmed: true,
      requestId: key,
    };
  let sends = [];
  globalThis.testSendEmail = async (...args) => {
    sends.push(args);
    return "provider-test";
  };
  assert.equal(
    (await admin.POST(requests({ ...body, confirmed: false }))).status,
    400,
  );
  assert.equal((await admin.POST(requests(body))).status, 200);
  assert.equal((await admin.POST(requests(body))).status, 200);
  assert.equal(sends.length, 1);
  assert.equal(sends[0][0], "controlled@example.invalid");
  assert.match(sends[0][1], /SAMPLE TEST/);
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE recipient='buyer@example.invalid' AND status='sent'",
      )
      .get().n,
    0,
  );
});
async function signedWebhook(
  type,
  provider = "provider-test",
  id = crypto.randomUUID(),
  timestamp = Math.floor(Date.now() / 1000),
) {
  const secret = "whsec_" + btoa("01234567890123456789012345678901");
  globalThis.emailFixtures.RESEND_WEBHOOK_SECRET = secret;
  const raw = JSON.stringify({
      type,
      data: { email_id: provider, to: ["controlled@example.invalid"] },
    }),
    key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode("01234567890123456789012345678901"),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"],
    );
  const signature = btoa(
    String.fromCharCode(
      ...new Uint8Array(
        await crypto.subtle.sign(
          "HMAC",
          key,
          new TextEncoder().encode(`${id}.${timestamp}.${raw}`),
        ),
      ),
    ),
  );
  return new Request("https://cashncarryng.com/api/emails/webhook", {
    method: "POST",
    headers: {
      "svix-id": id,
      "svix-timestamp": String(timestamp),
      "svix-signature": "v1," + signature,
    },
    body: raw,
  });
}
test("delivery webhook verifies raw signatures, rejects replay timestamps, records delivery and suppresses bounces/complaints", async () => {
  assert.equal(
    (
      await webhook.POST(
        new Request("https://cashncarryng.com/api/emails/webhook", {
          method: "POST",
          body: "{}",
        }),
      )
    ).status,
    503,
  );
  assert.equal(
    (await webhook.POST(await signedWebhook("email.delivered"))).status,
    200,
  );
  assert.equal(
    db
      .prepare(
        "SELECT delivery_status FROM email_outbox WHERE provider_id='provider-test'",
      )
      .get().delivery_status,
    "delivered",
  );
  assert.equal(
    (await webhook.POST(await signedWebhook("email.sent"))).status,
    200,
  );
  assert.equal(
    db
      .prepare(
        "SELECT delivery_status FROM email_outbox WHERE provider_id='provider-test'",
      )
      .get().delivery_status,
    "delivered",
  );
  const bounced = await signedWebhook("email.bounced");
  const replay = bounced.clone();
  assert.equal((await webhook.POST(bounced)).status, 200);
  assert.equal((await webhook.POST(replay)).status, 200);
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_suppressions WHERE recipient='controlled@example.invalid'",
      )
      .get().n,
    1,
  );
  await webhook.POST(await signedWebhook("email.delivered"));
  assert.equal(
    db
      .prepare(
        "SELECT delivery_status FROM email_outbox WHERE provider_id='provider-test'",
      )
      .get().delivery_status,
    "bounced",
  );
  assert.equal(
    (
      await webhook.POST(
        await signedWebhook(
          "email.delivered",
          "provider-test",
          "old",
          Math.floor(Date.now() / 1000) - 3600,
        ),
      )
    ).status,
    401,
  );
  const tampered = await signedWebhook("email.delivered");
  const invalid = new Request(tampered.url, {
    method: "POST",
    headers: tampered.headers,
    body: "{}",
  });
  assert.equal((await webhook.POST(invalid)).status, 401);
  const id = await notifications.queueTemplate(
    "controlled@example.invalid",
    "blocked",
    "welcome",
    {},
  );
  await notifications.flushEmails(id);
  assert.equal(
    db.prepare("SELECT status FROM email_outbox WHERE id=?").get(id).status,
    "suppressed",
  );
});

test("private webhook secrets are encrypted, never returned, and reject tampered storage", async () => {
  const cryptoConfig = await import(
    sourceModule("app/email-webhook-config.ts", "emailFixtures")
  );
  const old = globalThis.emailFixtures.RESEND_WEBHOOK_SECRET;
  delete globalThis.emailFixtures.RESEND_WEBHOOK_SECRET;
  let saved;
  globalThis.emailFixtures.STREAM_CONFIG_KEY = btoa(
    "01234567890123456789012345678901",
  );
  globalThis.emailFixtures.BUCKET = {
    put: async (path, value) => {
      assert.equal(path, "private/email-webhook-configuration");
      saved = value;
    },
    get: async () => (saved ? { json: async () => JSON.parse(saved) } : null),
  };
  const secret = "whsec_" + btoa("abcdefghijklmnopqrstuvwxyz123456");
  await cryptoConfig.saveEmailWebhookSecret(secret);
  assert(!saved.includes(secret));
  assert.equal(await cryptoConfig.emailWebhookSecret(), secret);
  const encoded = JSON.parse(saved);
  encoded.cipher[0] ^= 1;
  saved = JSON.stringify(encoded);
  await assert.rejects(() => cryptoConfig.emailWebhookSecret());
  globalThis.emailFixtures.RESEND_WEBHOOK_SECRET = old;
  delete globalThis.emailFixtures.BUCKET;
  delete globalThis.emailFixtures.STREAM_CONFIG_KEY;
});
test("early provider feedback is retained when acceptance arrives after the webhook", async () => {
  const id = await notifications.queueTemplate(
    "early@example.invalid",
    "early-feedback",
    "welcome",
    {},
  );
  globalThis.testSendEmail = async () => {
    await webhook.POST(
      await signedWebhook("email.delivered", "early-provider"),
    );
    return "early-provider";
  };
  await notifications.flushEmails(id);
  assert.equal(
    db.prepare("SELECT delivery_status FROM email_outbox WHERE id=?").get(id)
      .delivery_status,
    "delivered",
  );
});

test("domain inspection is read-only and does not equate receiving capability with a monitored inbox", async () => {
  const previous = globalThis.fetch;
  try {
    globalThis.fetch = async (url, options) => {
      assert.equal(url, "https://api.resend.com/domains");
      assert.equal(options.method, undefined);
      return Response.json({
        data: [
          {
            name: "cashncarryng.com",
            status: "verified",
            capabilities: { receiving: "enabled" },
          },
        ],
      });
    };
    let r = await (
      await admin.POST(requests({ action: "check-domain" }))
    ).json();
    assert.equal(r.domain.status, "verified");
    assert.match(r.message, /does not prove this mailbox is monitored/);
    assert.doesNotMatch(JSON.stringify(r), /fixture-sending-key/);
    globalThis.fetch = async () =>
      Response.json(
        { message: "private provider account detail" },
        { status: 403 },
      );
    r = await (await admin.POST(requests({ action: "check-domain" }))).json();
    assert.match(r.message, /cannot inspect domains/);
    assert.doesNotMatch(JSON.stringify(r), /private provider account detail/);
  } finally {
    globalThis.fetch = previous;
  }
});
test("refund failures and completions notify only after matching provider ID and amount; paid and refunded remain distinct", async () => {
  const payments = await import(
    sourceModule("app/payments.ts", "emailFixtures")
  );
  globalThis.emailFixtures.FLW_MODE = "test";
  globalThis.emailFixtures.FLW_WEBHOOK_HASH = "fixture-hash";
  globalThis.emailFixtures.FLW_SECRET_KEY = "FLWSECK_TEST_fixture";
  db.prepare(
    "UPDATE refunds SET status='processing',provider_id='provider-refund' WHERE id='refund'",
  ).run();
  const previous = globalThis.fetch;
  try {
    globalThis.fetch = async (url) => {
      assert.match(url, /\/refunds\/provider-refund$/);
      return Response.json({
        status: "success",
        data: {
          id: "provider-refund",
          amount_refunded: 27500,
          status: "failed",
        },
      });
    };
    assert.equal((await payments.reconcileRefund("refund")).status, "failed");
    assert.equal(
      db.prepare("SELECT status FROM refunds WHERE id='refund'").get().status,
      "failed",
    );
    assert.equal(
      db.prepare("SELECT payment_status FROM orders WHERE id='order'").get()
        .payment_status,
      "paid",
    );
    assert.equal(
      db
        .prepare(
          "SELECT count(*) n FROM email_outbox WHERE body LIKE '%Failed — contact support%'",
        )
        .get().n,
      1,
    );
    globalThis.fetch = async () =>
      Response.json({
        status: "success",
        data: {
          id: "provider-refund",
          amount_refunded: 1,
          status: "completed",
        },
      });
    await assert.rejects(
      () => payments.reconcileRefund("refund"),
      /do not match/,
    );
    assert.equal(
      db.prepare("SELECT payment_status FROM orders WHERE id='order'").get()
        .payment_status,
      "paid",
    );
    globalThis.fetch = async () =>
      Response.json({
        status: "success",
        data: {
          id: "provider-refund",
          amount_refunded: 27500,
          status: "completed",
        },
      });
    assert.equal(
      (await payments.reconcileRefund("refund")).status,
      "completed",
    );
    assert.equal(
      db.prepare("SELECT payment_status FROM orders WHERE id='order'").get()
        .payment_status,
      "refunded",
    );
  } finally {
    globalThis.fetch = previous;
  }
});
