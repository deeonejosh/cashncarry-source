import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import ts from "typescript";
import * as React from "react";
const url = (source) =>
  "data:text/javascript;base64," +
  Buffer.from(
    ts.transpileModule(source, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2023,
        jsx: ts.JsxEmit.React,
      },
    }).outputText,
  ).toString("base64");
let state = [],
  cursor = 0,
  refs = [],
  refCursor = 0;
const hooks = {
  useState(initial) {
    const i = cursor++;
    if (!(i in state)) state[i] = initial;
    return [
      state[i],
      (next) => (state[i] = typeof next === "function" ? next(state[i]) : next),
    ];
  },
  useRef(initial) {
    const i = refCursor++;
    return (refs[i] ??= { current: initial });
  },
  useEffect() {},
};
globalThis.liveTest = { React, ...hooks };
const icons =
  "Heart,ShoppingBag,ShoppingCart,Share2,Flag,X,Check,Send,MoreHorizontal,Maximize,ChevronDown,ChevronUp,Video,VideoOff,Zap,Settings,ArrowLeft,Radio,ShieldCheck,Mic,MicOff,SwitchCamera,Pin,BarChart3,MessageCircle".split(
    ",",
  );
const stub = (name) => {
  function IconStub() {
    return React.createElement("span", { "data-icon": name });
  }
  IconStub.displayName = `IconStub(${name})`;
  return IconStub;
};
for (const name of icons) globalThis.liveTest[name] = stub(name);
const prefix =
  "const React=globalThis.liveTest.React;const {useState,useRef,useEffect," +
  icons.join(",") +
  "}=globalThis.liveTest;";
const strip = (source) =>
  source.replace(/import[\s\S]*?from\s*["'][^"']+["'];/g, "");
const overlays = await import(
  url(prefix + strip(readFileSync("app/live-overlay.tsx", "utf8")))
);
Object.assign(globalThis.liveTest, overlays, {
  WebRTCVideo: () => null,
  LiveVideo: () => null,
  ScheduleInfo: () => null,
  ImageAsset: (p) => React.createElement("img", p),
  BrandLogo: () => null,
  VerifiedSellerBadge: () => null,
  brand: { name: "Cash N Carry" },
  safeReturnPath: (x) => x,
  workspaceTab: (x) => x,
  broadcastLabel: (s) => s.status.toUpperCase(),
  deliveryQuote: () => 1000,
  deliveryFee: () => 1000,
});
Object.assign(globalThis.liveTest, await import(url(readFileSync("app/live-product-selection.ts", "utf8"))));
const deps =
  "const {liveProductSelection,LiveAction,LiveSheet,ElapsedBroadcast,WebRTCVideo,LiveVideo,ScheduleInfo,ImageAsset,BrandLogo,VerifiedSellerBadge,brand,safeReturnPath,workspaceTab,broadcastLabel,deliveryQuote,deliveryFee}=globalThis.liveTest;";
const { default: Viewer } = await import(
  url(prefix + deps + strip(readFileSync("app/live-shopping.tsx", "utf8")))
);
const { default: Host } = await import(
  url(
    prefix +
      deps +
      "const createPortraitPublisher=()=>null,completeIceOffer=()=>null;" +
      strip(readFileSync("app/workspace/page.tsx", "utf8")),
  )
);
function flatten(node, out = []) {
  if (!node || typeof node !== "object") return out;
  if (Array.isArray(node)) {
    node.forEach((n) => flatten(n, out));
    return out;
  }
  if (typeof node.type === "function")
    return flatten(node.type(node.props), out);
  out.push(node);
  flatten(node.props?.children, out);
  return out;
}
const text = (n) =>
  typeof n === "string" || typeof n === "number"
    ? String(n)
    : Array.isArray(n)
      ? n.map(text).join("")
      : text(n?.props?.children ?? "");
const find = (tree, p) => flatten(tree).find(p);
const button = (tree, label) =>
  find(
    tree,
    (n) =>
      n.type === "button" &&
      (n.props["aria-label"] === label || text(n) === label),
  );
const render = (Component, props = {}) => {
  cursor = 0;
  refCursor = 0;
  return Component(props);
};
const product = {
  id: "p",
  store: "s",
  name: "Stored product",
  image: "/api/media/real",
  price: 1200,
  stock: 4,
  active: 1,
  variants: "[]",
};
const stream = {
  id: "live",
  store: "s",
  seller: "Stored seller",
  title: "Real title",
  status: "live",
  provider: "native",
  product: "p",
};
const chat = { id: "c", name: "Viewer", message: "Actual message" };
let calls = [],
  clipboard = "";
globalThis.location = { origin: "https://app.test" };
Object.defineProperty(globalThis, "navigator", {
  configurable: true,
  value: {
    clipboard: { writeText: async (x) => (clipboard = x) },
    mediaDevices: { getUserMedia: async () => media },
  },
});
const fixture = {
  user: { id: "seller" },
  myStore: { id: "s", name: "Stored seller" },
  myStreams: [stream],
  myProducts: [product],
  services: { stream: true },
  cart: [],
  stores: [],
  follows: [],
};
globalThis.fetch = async (path, options) => {
  if (options?.method === "POST")
    calls.push({ path, body: JSON.parse(options.body) });
  return Response.json(
    options?.method === "POST"
      ? { ok: true }
      : path.includes("?stream=")
        ? { likes: 13, liked: true }
        : fixture,
  );
};
let confirmResult = false;
globalThis.confirm = () => confirmResult;
const audio = {
    enabled: true,
    stop() {
      this.stopped = true;
    },
  },
  video = {
    getSettings: () => ({ facingMode: "user" }),
    stop() {
      this.stopped = true;
    },
  };
const media = {
  getTracks: () => [audio, video],
  getAudioTracks: () => [audio],
  getVideoTracks: () => [video],
  removeTrack() {},
  addTrack() {},
};
const event = { preventDefault() {}, stopPropagation() {} };
function viewerState(sheet = "") {
  state = [
    stream,
    [product],
    [chat],
    12,
    false,
    sheet,
    "",
    {},
    {},
    "Question",
    "",
    false,
    "",
    false,
    false,
    12,
    false,
    "Concern",
  ];
  refs = [];
  calls = [];
}
const viewerProps = {
  initial: stream,
  data: { cart: [{ ...product, quantity: 2 }], stores: [], follows: [] },
  busy: false,
  act: async (body) => {
    calls.push(body);
    return true;
  },
  onClose: () => calls.push("closed"),
};
test("viewer rail order, follow, real counts, product selection, cart, share, comment and report handlers", async () => {
  viewerState();
  let tree = render(Viewer, viewerProps);
  const rail = find(tree, (n) => n.props.className === "live-viewer-tools");
  assert.deepEqual(
    flatten(rail)
      .filter((n) => n.type === "button")
      .map((n) => text(n)),
    ["12", "Share", "1Products", "More"],
  );
  assert.equal(button(tree, "Open cart, 2 items") !== undefined, true);
  assert(!button(tree, "Switch camera"));
  assert(!button(tree, "End Live"));
  await button(tree, "Follow").props.onClick();
  assert.equal(calls.at(-1).action, "follow");
  await button(tree, "Share broadcast").props.onClick();
  assert.equal(clipboard, "https://app.test/?stream=live");
  await button(tree, "Like broadcast, 12 likes").props.onClick();
  assert.deepEqual(calls.at(-1), {
    action: "stream-like",
    stream: "live",
    liked: true,
  });
  assert.equal(state[15], 13);
  button(tree, "Browse 1 featured product").props.onClick();
  assert.equal(state[5], "products");
  const before = calls.length;
  find(tree, n => n.props.className === "live-premium-product-info").props.onClick();
  assert.equal(state[5], "product");
  assert.equal(state[6], "p");
  assert.equal(calls.length, before);
  button(tree, "Open cart, 2 items").props.onClick();
  assert.equal(state[5], "checkout");
  assert(state[12]);
  await find(tree, (n) => n.type === "form").props.onSubmit(event);
  assert.equal(calls.at(-1).action, "chat");
  button(tree, "More broadcast options").props.onClick();
  assert.equal(state[5], "more");
  tree = render(Viewer, viewerProps);
  const stage = find(tree, (n) => n.props.className === "live-stage");
  assert.equal(stage.props.inert, true);
  await find(
    tree,
    (n) => n.type === "form" && n.props.children?.length,
  ).props.onSubmit(event);
  assert.equal(calls.at(-1).action, "report");
  button(tree, "Close Broadcast options").props.onClick();
  assert.equal(state[5], "");
});
function hostState(sheet = "") {
  state = [
    fixture,
    "Connected",
    false,
    "Broadcasts",
    "live",
    false,
    "",
    "LIVE — provider confirmed",
    false,
    [chat],
    12,
    "Reply",
    sheet,
    Date.now() - 65000,
    false,
    "/workspace",
  ];
  refs = [
    { current: null },
    { current: media },
    { current: null },
    { current: false },
    { current: false },
    { current: false },
    { current: "user" },
    { current: "" },
    { current: "live" },
    { current: 1 },
    { current: null },
  ];
  calls = [];
  audio.enabled = true;
}
test("host rail, microphone, product management, moderation and explicit confirmed close/end handlers", async () => {
  hostState();
  let tree = render(Host);
  const rail = find(tree, (n) => n.props.className === "host-live-tools");
  assert.deepEqual(
    flatten(rail)
      .filter((n) => n.type === "button")
      .map((n) => text(n)),
    ["Mic", "Flip", "Camera", "Products", "Pin", "Deals", "More"],
  );
  button(tree, "Mute microphone").props.onClick();
  assert.equal(audio.enabled, false);
  assert.equal(state[8], true);
  tree = render(Host);
  button(tree, "Unmute microphone").props.onClick();
  assert.equal(audio.enabled, true);
  button(tree, "Manage broadcast products").props.onClick();
  assert.equal(state[12], "products");
  tree = render(Host);
  await find(tree, (n) => n.type === "select").props.onChange({
    target: { value: "p" },
  });
  assert.equal(calls.filter(c=>c.body?.action==="pin").length,0);
  tree=render(Host);await button(tree,"Pin selected product").props.onClick();
  assert.equal(calls.at(-1).body.action, "pin");
  assert.equal(calls.at(-1).body.id, "live");
  hostState("more");
  tree = render(Host);
  button(tree, "Moderate comments").props.onClick();
  assert.equal(state[12], "moderation");
  tree = render(Host);
  await button(tree, "Hide message").props.onClick();
  assert.equal(calls.at(-1).body.action, "moderate-chat");
  hostState();
  tree = render(Host);
  await find(
    tree,
    (n) => n.type === "form" && n.props.className === "host-live-reply",
  ).props.onSubmit(event);
  assert.equal(calls.at(-1).body.action, "chat");
  calls = [];
  button(tree, "End livestream").props.onClick();
  assert.equal(state[12], "leave");
  assert.equal(calls.length, 0);
  tree = render(Host);
  button(tree, "Cancel").props.onClick();
  assert.equal(state[12], "");
  assert.equal(calls.length, 0);
  button(render(Host), "End livestream").props.onClick();
  tree = render(Host);
  const end=button(tree,"End Live");
  end.props.onClick();
  end.props.onClick();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(calls[0].body.action, "end");
  assert.equal(calls[0].path, "/api/streams");
  assert.equal(calls.filter(c=>c.body?.action==="end").length,1);
});
test("ended viewer hides composer and empty products while retaining a cart", () => {
  viewerState();
  state[0] = { ...stream, status: "ended", product: "" };
  state[1] = [];
  const tree = render(Viewer, viewerProps);
  assert(
    !find(
      tree,
      (n) => n.type === "input" && n.props.placeholder === "Ask the seller…",
    ),
  );
  assert(!find(tree, (n) => n.props.className === "live-premium-product"));
  assert(!button(tree, "Browse 0 featured products"));
  assert(
    find(tree, (n) => n.props.className === "live-cart-button live-ended-cart"),
  );
  assert.equal(button(tree, "Like broadcast, 12 likes").props.disabled, true);
});
test("sheets close with Escape and trap focus without propagating to outer dialog", () => {
  state = [];
  refs = [];
  let closed = false;
  const tree = render(overlays.LiveSheet, {
    title: "Options",
    onClose: () => (closed = true),
    children: null,
  });
  const dialog = find(tree, (n) => n.props.role === "dialog");
  let stopped = false,
    prevented = false;
  dialog.props.onKeyDown({
    key: "Escape",
    preventDefault() {
      prevented = true;
    },
    stopPropagation() {
      stopped = true;
    },
  });
  assert(closed && stopped && prevented);
});

test("repositioned camera, close and fullscreen actions invoke their existing operations", async () => {
  hostState();
  let tree = render(Host);
  let captured;
  navigator.mediaDevices.getUserMedia = async (options) => {
    captured = options;
    return media;
  };
  await button(tree, "Switch camera").props.onClick();
  assert.equal(captured.video.facingMode.exact, "environment");
  assert.equal(captured.audio, false);
  hostState("more");
  state[14] = true;
  tree = render(Host);
  let fullscreen = 0;
  await button(tree, "Enter fullscreen").props.onClick({
    currentTarget: {
      closest: () => ({ requestFullscreen: async () => fullscreen++ }),
    },
  });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(fullscreen, 1);
  assert.equal(state[12], "");
  viewerState("more");
  state[14] = true;
  refs = [{ current: { requestFullscreen: async () => fullscreen++ } }];
  tree = render(Viewer, viewerProps);
  await button(tree, "Enter fullscreen").props.onClick();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(fullscreen, 2);
  assert.equal(state[5], "");
  viewerState();
  tree = render(Viewer, viewerProps);
  button(tree, "Close broadcast").props.onClick();
  assert.equal(calls.at(-1), "closed");
});
test("sheets trap both Tab boundaries and restore navigation remains guarded while broadcasting", () => {
  state = [];
  refs = [];
  const tree = render(overlays.LiveSheet, {
    title: "Options",
    onClose: () => {},
    children: null,
  });
  const dialog = find(tree, (n) => n.props.role === "dialog");
  let target = "",
    prevented = false;
  const first = { getClientRects: () => [1], focus: () => (target = "first") },
    last = { getClientRects: () => [1], focus: () => (target = "last") };
  globalThis.document = { activeElement: last };
  const key = {
    key: "Tab",
    shiftKey: false,
    preventDefault: () => (prevented = true),
    stopPropagation() {},
    currentTarget: { querySelectorAll: () => [first, last] },
  };
  dialog.props.onKeyDown(key);
  assert.equal(target, "first");
  assert(prevented);
  document.activeElement = first;
  key.shiftKey = true;
  dialog.props.onKeyDown(key);
  assert.equal(target, "last");
  const source = ts.createSourceFile(
    "workspace.tsx",
    readFileSync("app/workspace/page.tsx", "utf8"),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TSX,
  );
  let body;
  function visit(n) {
    if (
      ts.isVariableDeclaration(n) &&
      n.name.getText(source) === "warnBeforeLeaving"
    )
      body = n.initializer.body.getText(source);
    ts.forEachChild(n, visit);
  }
  visit(source);
  const guard = new Function("broadcast", "return (e)=>" + body);
  const broadcast = { current: "" };
  let warned = false;
  guard(broadcast)({ preventDefault: () => (warned = true) });
  assert.equal(warned, false);
  broadcast.current = "live";
  const event = { preventDefault: () => (warned = true) };
  guard(broadcast)(event);
  assert.equal(warned, true);
  assert.equal(event.returnValue, "");
});

test("camera preview exposes an enabled Go Live action and a working Cancel preview action", async () => {
  hostState();
  state[4] = "";
  state[6] = "live";
  state[7] = "Camera preview — not live";
  state[13] = null;
  refs[8].current = "";
  let tree = render(Host);
  const go = button(tree, "Go Live");
  assert(go);
  assert.equal(go.props.disabled, false);
  assert(button(tree, "Cancel preview"));
  assert(!button(tree, "End Live"));
  button(tree, "Cancel preview").props.onClick();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(state[6], "");
  assert.equal(calls.length, 0);
  hostState();
  state[4] = "";
  state[6] = "live";
  state[2] = true;
  tree = render(Host);
  assert.equal(button(tree, "Go Live").props.disabled, true);
});
test("host overlay containing block is the full stage rather than empty grid rows", () => {
  const css = readFileSync("app/design-system.css", "utf8");
  const start = css.indexOf("/* Portrait host stage,");
  const end = css.indexOf("/* Save controls", start);
  const stageRules = css.slice(start, end);
  assert.match(stageRules, /\.host-live-stage \{[\s\S]*?display: block;/);
  assert.doesNotMatch(stageRules, /grid-row:|grid-column:|grid-template-rows:/);
  const lastRules = css.slice(css.indexOf("/* Cash N Carry live overlays."));
  assert.match(
    lastRules,
    /\.host-live-stage \.host-live-lower \{[\s\S]*?position: absolute;[\s\S]*?bottom: 0;/,
  );
});

test("pinned product collapses without losing the broadcast and restores its purchase entry", () => {
  viewerState();
  let tree = render(Viewer, viewerProps);
  assert(find(tree, n => n.props.className === "live-premium-product"));
  button(tree, "Collapse pinned product").props.onClick();
  tree = render(Viewer, viewerProps);
  assert(!find(tree, n => n.props.className === "live-premium-product"));
  assert(find(tree, n => n.props.className === "live-stage"));
  assert.equal(button(tree, "Expand pinned product").props["aria-expanded"], false);
  button(tree, "Expand pinned product").props.onClick();
  tree = render(Viewer, viewerProps);
  assert(find(tree, n => n.props.className === "live-premium-product"));
  assert.equal(button(tree, "Collapse pinned product").props["aria-expanded"], true);
});

test("live product Buy Now opens direct checkout while Add to Cart remains independent", async () => {
  viewerState("product"); state[6] = product.id;
  let tree = render(Viewer, viewerProps);
  const buy = button(tree, "Buy Now");
  assert.equal(buy.props.className, "primary");
  buy.props.onClick();
  assert.equal(state[5], "checkout");
  assert.equal(state[18].product.id, product.id);
  assert.equal(calls.length, 0);
  viewerState("product"); state[6] = product.id;
  tree = render(Viewer, viewerProps);
  const add = button(tree, "Add to Cart");
  assert.equal(add.props.className, "secondary-button");
  await add.props.onClick();
  assert.equal(calls.at(-1).action, "cart");
  assert.equal(state[5], "product");
});

test("live deal price is shown on the pin and shopping controls are hidden under sheets", () => {
  viewerState(); state[19] = [{ product: product.id, promo_price: 700, max_quantity: 5, sold_quantity: 2, starts_at: new Date(Date.now()-10000).toISOString(), ends_at: new Date(Date.now()+10000).toISOString() }];
  const tree = render(Viewer, viewerProps);
  const pin = find(tree, n => n.props.className === "live-premium-product");
  assert.match(text(pin), /700/);
  assert.match(text(pin), /3 remaining/);
  state[5] = "products";
  const sheetTree = render(Viewer, viewerProps);
  assert(!find(sheetTree, n => n.props.className === "live-premium-product"));
  assert.equal(find(sheetTree, n => n.props.className === "live-stage").props.inert, true);
});

test("live discount matches Buy Now line item and total",()=>{viewerState('product');state[6]=product.id;state[19]=[{product:product.id,promo_price:700,max_quantity:5,sold_quantity:0,starts_at:new Date(Date.now()-1000).toISOString(),ends_at:new Date(Date.now()+60000).toISOString()}];button(render(Viewer,viewerProps),'Buy Now').props.onClick();const tree=render(Viewer,viewerProps);const lines=flatten(tree).filter(n=>n.type==='p').map(text);assert(lines.some(line=>line.includes('Stored product')&&line.includes('700')));assert(lines.some(line=>line.includes('Products')&&line.includes('700')));});

test('premium pinned Buy Now opens direct checkout and Add to Cart preserves the live stage', async()=>{
 viewerState();let tree=render(Viewer,viewerProps);
 button(tree,'Buy Now').props.onClick();assert.equal(state[5],'checkout');assert.equal(state[18].product.id,product.id);assert.equal(calls.length,0);
 viewerState();tree=render(Viewer,viewerProps);button(tree,'Add to Cart').props.onClick();await Promise.resolve();assert.equal(calls.at(-1).action,'cart');assert.equal(calls.at(-1).product,product.id);assert(!('price' in calls.at(-1)));assert.equal(state[5],'');assert(find(tree,n=>n.props.className==='live-stage'));
});

test('seller reference card unpins and thumbnail pins through existing ownership-checked actions',async()=>{
 hostState();let tree=render(Host);await button(tree,'Unpin').props.onClick();assert.equal(calls.at(-1).body.action,'pin');assert.equal(calls.at(-1).body.product,'');assert.equal(calls.at(-1).body.previousProduct,product.id);
 hostState();tree=render(Host);button(tree,`Select ${product.name}`).props.onClick();assert.equal(calls.length,0);tree=render(Host);await button(tree,'Pin selected product').props.onClick();assert.equal(calls.at(-1).body.action,'pin');assert.equal(calls.at(-1).body.product,product.id);
 assert(!button(tree,'Buy Now')); 
});
test('seller More menu opens real count panel rather than example sales metrics',()=>{
 hostState('more');let tree=render(Host);button(tree,'Live stats').props.onClick();assert.equal(state[12],'stats');tree=render(Host);assert.match(text(tree),/Current viewers/);assert.doesNotMatch(text(tree),/2\.4K|320 sold|Free delivery/);
});

test('selecting a valid product option clears the resolved variant prompt',()=>{
 viewerState('product');state[6]=product.id;state[10]='Choose an available product option first.';
 const original=product.variants;product.variants=JSON.stringify([{name:'Black',price:1200,stock:4}]);
 try{const tree=render(Viewer,viewerProps);find(tree,n=>n.type==='select').props.onChange({target:{value:'Black'}});assert.equal(state[7][product.id],'Black');assert.equal(state[10],'');}finally{product.variants=original;}
});

 test("pinned variant selector enables purchase and preserves the selected option",async()=>{
  const original=product.variants;product.variants=JSON.stringify([{name:"Black",price:1200,stock:4},{name:"Red",stock:0}]);
  try { viewerState();let tree=render(Viewer,viewerProps);
   assert.equal(button(tree,"Buy Now").props.disabled,true);
   const select=find(tree,n=>n.type==="select"&&n.props["aria-label"]===`Option for ${product.name}`);
   assert(select);select.props.onChange({target:{value:"Black"}});
   tree=render(Viewer,viewerProps);assert.equal(button(tree,"Buy Now").props.disabled,false);
   button(tree,"Buy Now").props.onClick();assert.equal(state[18].variant,"Black");
   viewerState();tree=render(Viewer,viewerProps);find(tree,n=>n.type==="select").props.onChange({target:{value:"Black"}});
   tree=render(Viewer,viewerProps);button(tree,"Add to Cart").props.onClick();await Promise.resolve();assert.equal(calls.at(-1).variant,"Black");
  } finally {product.variants=original;}
 });
 test("live selection rejects missing, stale and sold out options but permits plain products",()=>{
  const choose=globalThis.liveTest.liveProductSelection;
  assert.equal(choose({name:"Plain",stock:2,price:100}).error,"");
  const item={name:"Shirt",stock:8,variants:JSON.stringify([{name:"M",stock:2,price:200},{name:"L",stock:0}])};
  assert.match(choose(item).error,/Choose an available option for Shirt/);
  assert(choose(item,"Old").error);assert(choose(item,"L").error);
  assert.equal(choose(item,"M").price,200);assert.equal(choose(item,"M").error,"");
  for(const q of [-1,0,1.5,3])assert(choose(item,"M",q).error);
  assert(choose({...item,variants:"broken"}).error);
 });

test('compact host has one end entry, no bottom dock, and secondary tools in More',()=>{
 hostState();let tree=render(Host);
 assert.equal(flatten(tree).filter(n=>n.type==='button'&&n.props['aria-label']==='End livestream').length,1);
 assert(!button(tree,'End Live'));assert(!find(tree,n=>n.props.className==='seller-live-dock'));
 assert(!button(tree,'Camera settings and optional title'));
 button(tree,'More host options').props.onClick();tree=render(Host);
 for(const label of ['Camera settings and optional title','Live stats','Share broadcast','Moderate comments'])assert(button(tree,label));
 assert(!button(tree,'Closing and leaving'));
 assert(flatten(tree).some(n=>n.type==='a'&&String(n.props.href).includes('tab=Bundles')));
 assert(flatten(tree).some(n=>n.type==='a'&&String(n.props.href).includes('tab=Auctions')));
});
test('buyer exit only closes local viewing and all comments remain accessible',()=>{
 viewerState();let tree=render(Viewer,viewerProps);button(tree,'Close broadcast').props.onClick();
 assert.deepEqual(calls,['closed']);assert(!button(tree,'End Live'));assert(!button(tree,'Mute microphone'));
 viewerState('more');tree=render(Viewer,viewerProps);button(tree,'View all comments').props.onClick();
 tree=render(Viewer,viewerProps);assert.match(text(tree),/Actual message/);assert.equal(state[5],'comments');
});
test('failed provider ending releases local tracks and exposes a recovery state',async()=>{
 const previous=globalThis.fetch;hostState('leave');audio.stopped=false;video.stopped=false;
 globalThis.fetch=async(path,options)=>{if(options?.method==='POST'){calls.push({path,body:JSON.parse(options.body)});return Response.json({error:'Provider unavailable'},{status:503});}return Response.json(fixture);};
 try{await button(render(Host),'End Live').props.onClick();assert.equal(audio.stopped,true);assert.equal(video.stopped,true);assert.equal(state[4],'');assert.equal(state[7],'End not confirmed — camera stopped');assert.match(state[1],/retry safely/);assert.equal(calls.filter(c=>c.body.action==='end').length,3);}finally{globalThis.fetch=previous;}
});

test('seller collapsed pin keeps identity without unpinning; selection needs an explicit Pin',async()=>{
 hostState();let tree=render(Host);assert.match(text(find(tree,n=>n.props.className==='host-live-pin')),/Stored product/);
 button(tree,'Collapse pinned product').props.onClick();tree=render(Host);assert(!find(tree,n=>n.props.className==='host-live-pin'));assert.match(text(button(tree,'Expand pinned product')),/Stored product/);assert.equal(calls.length,0);
 button(tree,'Expand pinned product').props.onClick();tree=render(Host);assert(button(tree,'Unpin'));
 button(tree,`Select ${product.name}`).props.onClick();assert.equal(calls.length,0);
});
test('unpin is immediate, locked during flight, and rolls back on failure',async()=>{
 const previous=globalThis.fetch;hostState();let resolve;const waiting=new Promise(r=>resolve=r);
 globalThis.fetch=async(path,options)=>{if(options?.method==='POST'){calls.push({path,body:JSON.parse(options.body)});await waiting;return Response.json({error:'Network failed'},{status:503});}return Response.json(fixture);};
 try{const unpin=button(render(Host),'Unpin');const pending=unpin.props.onClick();unpin.props.onClick();assert.equal(state[0].myStreams[0].product,'');assert.equal(calls.length,1);resolve();await pending;assert.equal(state[0].myStreams[0].product,'p');assert.match(state[1],/Network failed/);}finally{resolve();globalThis.fetch=previous;}
});
test('buyer pin presentation excludes seller actions and blocks stale shopping while disconnected',()=>{
 viewerState();state[4]=true;let tree=render(Viewer,viewerProps);assert.equal(button(tree,'Buy Now').props.disabled,true);assert.equal(button(tree,'Add to Cart').props.disabled,true);assert(!button(tree,'Unpin'));assert(!text(tree).includes('Manage product'));
 button(tree,'Collapse pinned product').props.onClick();tree=render(Viewer,viewerProps);assert.match(text(button(tree,'Expand pinned product')),/Stored product/);
});
