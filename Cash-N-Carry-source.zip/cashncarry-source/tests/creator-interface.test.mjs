import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as React from 'react';
function fixture(data) {
 let states=[data,'','',false],cursor=0,refs=[],refCursor=0;
 const hooks={...React,useState(initial){const i=cursor++;if(!(i in states))states[i]=initial;return[states[i],next=>states[i]=typeof next==='function'?next(states[i]):next]},useRef(value){return refs[refCursor++]??=( {current:value} )},useCallback(fn){return fn},useEffect(){}};
 const exports={};
 const context={React,exports,require(name){if(name==='react')return hooks;if(name==='next/link')return{default:'a'};if(name==='lucide-react')return new Proxy({},{get:()=>()=>null});if(name.includes('verified-seller-badge'))return{default:()=>null};if(name.includes('customer-shell'))return{CustomerHeader:()=>null,CustomerNavigation:()=>null,PageHeading:()=>null};throw Error(name)},fetch:(...args)=>context.request(...args),AbortSignal,Intl,navigator:{clipboard:{writeText:async value=>context.copied=value}}};
 const source=ts.transpileModule(readFileSync('app/creator/panel.tsx','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.React,target:ts.ScriptTarget.ES2023}}).outputText;
 vm.runInNewContext(source,context);
 const render=()=>{cursor=0;refCursor=0;return exports.default()};
 return{render,states,context};
}
function flatten(node){if(!node||typeof node!=='object')return[];if(Array.isArray(node))return node.flatMap(flatten);return[node,...flatten(node.props?.children)]}
function text(node){if(node==null||typeof node==='boolean')return'';if(Array.isArray(node))return node.map(text).join('');if(typeof node==='object')return text(node.props?.children);return String(node)}
const data={profile:{display_name:'Creator',status:'approved'},creatorPartnerships:[{id:'ref &/1',product_name:'Bag',store_name:'Lagos Shop',status:'approved',clicks:12,attributed_orders:3,estimated_commission:900,commission_bps:1000}],commissions:[]};
test('creator renders recorded totals, safe referral URL and no payout action',async()=>{
 const f=fixture(data),tree=f.render();assert.match(text(tree),/12/);assert.match(text(tree),/900/);assert.match(text(tree),/payouts are disabled/);
 const nodes=flatten(tree);const link=nodes.find(n=>n.type==='input'&&n.props.readOnly);assert.equal(link.props.value,'https://cashncarryng.com/affiliate/go?ref=ref%20%26%2F1');
 await nodes.find(n=>n.type==='button'&&text(n).includes('Copy link')).props.onClick();assert.equal(f.context.copied,link.props.value);
 assert(!nodes.some(n=>n.type==='button'&&/withdraw|pay out|request payout/i.test(text(n))));
});
test('pending creator sees review status without active affiliate links',()=>{
 const f=fixture({...data,profile:{display_name:'Creator',status:'pending'}}),nodes=flatten(f.render());assert(!nodes.some(n=>n.type==='input'&&n.props.readOnly));assert.match(text(f.render()),/application is being reviewed/);
});
test('partnership acceptance is guarded against duplicate clicks and refreshes real data',async()=>{
 const f=fixture({...data,creatorPartnerships:[{...data.creatorPartnerships[0],status:'pending'}]});let posts=0,release;
 f.context.request=async(_,options)=>{if(options?.method==='POST'){posts++;await new Promise(resolve=>release=resolve);assert.equal(JSON.parse(options.body).status,'approved');return Response.json({ok:true})}return Response.json(data)};
 const accept=flatten(f.render()).find(n=>n.type==='button'&&text(n)==='Accept partnership');accept.props.onClick();accept.props.onClick();assert.equal(posts,1);release();await new Promise(resolve=>setTimeout(resolve,20));assert.equal(f.states[3],false);assert.equal(f.states[0].creatorPartnerships[0].status,'approved');
});
test('creator request failure reports error and retains current partnership',async()=>{
 const f=fixture({...data,creatorPartnerships:[{...data.creatorPartnerships[0],status:'pending'}]});f.context.request=async()=>Response.json({error:'Partnership is no longer available'},{status:409});
 flatten(f.render()).find(n=>n.type==='button'&&text(n)==='Accept partnership').props.onClick();await new Promise(resolve=>setTimeout(resolve,20));assert.equal(f.states[1],'Partnership is no longer available');assert.equal(f.states[3],false);assert.equal(f.states[0].creatorPartnerships[0].status,'pending');
});
