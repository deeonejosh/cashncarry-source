import test from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {betterAuth} from 'better-auth';
import {twoFactor} from 'better-auth/plugins';
import {memoryAdapter} from 'better-auth/adapters/memory';
import {DatabaseSync} from 'node:sqlite';
import {sourceModule} from './load-route.mjs';
const proofDb=new DatabaseSync(':memory:');proofDb.exec('CREATE TABLE platform_settings(key TEXT PRIMARY KEY,value TEXT,updated TEXT)');
globalThis.testEnv={DB:{prepare:sql=>({bind:(...args)=>({first:async()=>proofDb.prepare(sql).get(...args)||null,run:async()=>proofDb.prepare(sql).run(...args)})})}};
const {recordMfaSession,sessionHasMfa,mfaResponseHeaders}=await import(sourceModule('app/mfa-proof.ts'));
const memory={user:[],session:[],account:[],verification:[],twoFactor:[]};
const auth=betterAuth({secret:'isolated-mfa-fixture-secret-32-bytes-long',baseURL:'https://mfa.test',database:memoryAdapter(memory),emailAndPassword:{enabled:true,minPasswordLength:12},plugins:[twoFactor({issuer:'Cash N Carry'})],advanced:{useSecureCookies:true},rateLimit:{enabled:false},logger:{disabled:true}});
const jar=new Map();
async function post(path,body){const request=new Request('https://mfa.test/api/auth/'+path,{method:'POST',headers:{origin:'https://mfa.test','Content-Type':'application/json',cookie:[...jar].map(([k,v])=>k+'='+v).join('; ')},body:JSON.stringify(body)});const r=await auth.handler(request);if(r.ok && /two-factor\/verify-(totp|backup-code)/.test(path)){const session=await auth.api.getSession({headers:mfaResponseHeaders(request,r)});assert(session);await recordMfaSession(session);assert.equal(await sessionHasMfa(session),true);}for(const c of r.headers.getSetCookie()){const [pair]=c.split(';');const at=pair.indexOf('=');jar.set(pair.slice(0,at),pair.slice(at+1));}return r;}
function totp(secret){const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';let bits='';for(const c of secret.toUpperCase().replace(/=+$/,''))bits+=alphabet.indexOf(c).toString(2).padStart(5,'0');const bytes=[];for(let n=0;n+8<=bits.length;n+=8)bytes.push(parseInt(bits.slice(n,n+8),2));const counter=Buffer.alloc(8);counter.writeBigUInt64BE(BigInt(Math.floor(Date.now()/30000)));const hash=createHmac('sha1',Buffer.from(bytes)).update(counter).digest();const off=hash.at(-1)&15;return ((hash.readUInt32BE(off)&0x7fffffff)%1000000).toString().padStart(6,'0');}
test('real Better Auth MFA enrolment, challenge, invalid code denial and single-use recovery',async()=>{
 const credentials={email:'controlled-mfa@example.invalid',password:'isolated-mfa-password-123'};
 assert.equal((await post('sign-up/email',{...credentials,name:'Controlled MFA'})).status,200);memory.user[0].emailVerified=true;
 const oldSignin=await auth.api.signInEmail({body:credentials});const oldSession=memory.session.find(s=>s.token===oldSignin.token);
 let r=await post('two-factor/enable',{password:credentials.password});assert.equal(r.status,200);const setup=await r.json();assert(setup.totpURI);assert(setup.backupCodes.length>0);assert(!memory.user[0].twoFactorEnabled);
 const secret=new URL(setup.totpURI).searchParams.get('secret');
 assert.equal((await post('two-factor/verify-totp',{code:'000000',trustDevice:false})).status,401);
 r=await post('two-factor/verify-totp',{code:totp(secret),trustDevice:false});assert.equal(r.status,200);assert.equal(memory.user[0].twoFactorEnabled,true);assert.equal(await sessionHasMfa({session:oldSession,user:memory.user[0]}),false);
 await post('sign-out',{});jar.clear();r=await post('sign-in/email',credentials);assert.equal(r.status,200);assert.equal((await r.json()).twoFactorRedirect,true);
 assert.equal((await post('two-factor/verify-totp',{code:'bad',trustDevice:false})).status,401);
 assert.equal((await post('two-factor/verify-backup-code',{code:setup.backupCodes[0],trustDevice:false})).status,200);
 await post('sign-out',{});jar.clear();await post('sign-in/email',credentials);
 assert.equal((await post('two-factor/verify-backup-code',{code:setup.backupCodes[0],trustDevice:false})).status,401);
 for(const row of proofDb.prepare('SELECT key,value FROM platform_settings').all()){const proof=JSON.parse(row.value);proof.expiresAt=Date.now()-1;proofDb.prepare('UPDATE platform_settings SET value=? WHERE key=?').run(JSON.stringify(proof),row.key);}
 assert.equal(await sessionHasMfa({session:memory.session.at(-1),user:memory.user[0]}),false);
});
