import test from 'node:test';
import assert from 'node:assert/strict';
import ts from 'typescript';
import {readFileSync} from 'node:fs';
const source=ts.createSourceFile('viewer.tsx',readFileSync('app/webrtc-video.tsx','utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
let callback;function visit(n){if(ts.isCallExpression(n)&&n.expression.getText(source)==='useEffect')callback=n.arguments[0].getText(source);ts.forEachChild(n,visit);}visit(source);
const code=ts.transpileModule('const run='+callback+'; return run();',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
function fixture({offer=async()=>'offer',fetchOffer}={}){
 const handlers=new Map(),timers=new Map();let timerId=0;const errors=[],prompts=[];let plays=0,deleted=0;
 const video={readyState:0,srcObject:null,addEventListener:(key,fn)=>handlers.set(key,fn),removeEventListener:(key)=>handlers.delete(key),pause(){this.paused=true},play:()=>{plays++;return Promise.reject(new DOMException('Autoplay blocked','NotAllowedError'));}};
 const connection={addTransceiver(){},async setRemoteDescription(){},close(){this.closed=true;}};class PC{constructor(){return connection;}}
 const tracks=[];class Media{addTrack(t){tracks.push(t);}getTracks(){return tracks;}}
 const run=new Function('ref','setError','setNeedsPlay','RTCPeerConnection','MediaStream','completeIceOffer','url','fetch','setTimeout','clearTimeout',code);
 const cleanup=run({current:video},x=>errors.push(x),x=>prompts.push(x),PC,Media,offer,'https://stream.invalid/play',async(url,opts)=>{if(opts.method==='DELETE')deleted++;if(opts.method==='POST'&&fetchOffer)return fetchOffer();return new Response('answer',{headers:{location:'/session'}});},(fn,ms)=>{const id=++timerId;timers.set(id,{fn,ms});return id},id=>timers.delete(id));
 return {cleanup,video,handlers,timers,errors,prompts,plays:()=>plays,deleted:()=>deleted,connection:()=>connection};
}
const drain=()=>new Promise(r=>setImmediate(r));
test('blocked autoplay offers a user gesture instead of pretending playback started',async()=>{
 const f=fixture();await drain();f.video.readyState=2;f.handlers.get('loadedmetadata')();await drain();assert.equal(f.plays(),1);assert.equal(f.prompts.at(-1),true);
 f.handlers.get('playing')();assert.equal(f.prompts.at(-1),false);assert(![...f.timers.values()].some(t=>t.ms===30000));f.cleanup();
});
test('viewer with no media times out and releases provider connection',async()=>{
 const f=fixture();await drain();[...f.timers.values()].find(t=>t.ms===30000).fn();await drain();assert.match(f.errors.at(-1),/No picture or sound/);assert.equal(f.connection().closed,true);assert.equal(f.deleted(),1);f.cleanup();
});
test('leaving viewer removes media listeners and clears attached media',async()=>{
 const f=fixture();await drain();f.cleanup();assert.equal(f.handlers.size,0);assert.equal(f.timers.size,0);assert.equal(f.video.srcObject,null);assert.equal(f.connection().closed,true);assert.equal(f.deleted(),1);
});

test('terminal connection failure releases attached tracks, listeners and provider session',async()=>{
 const f=fixture();await drain();const track={stop(){this.stopped=true}};
 f.connection().ontrack({track});f.connection().connectionState='failed';f.connection().onconnectionstatechange();await drain();
 assert.match(f.errors.at(-1),/Connection failed/);assert.equal(track.stopped,true);
 assert.equal(f.handlers.size,0);assert.equal(f.timers.size,0);assert.equal(f.video.srcObject,null);assert.equal(f.deleted(),1);f.cleanup();assert.equal(f.deleted(),1);
});
test('temporary disconnection clears feedback and its timeout on reconnection',async()=>{
 const f=fixture();await drain();f.connection().connectionState='disconnected';f.connection().onconnectionstatechange();
 assert.match(f.errors.at(-1),/reconnect/);assert([...f.timers.values()].some(t=>t.ms===8000));
 f.connection().connectionState='connected';f.connection().onconnectionstatechange();assert.equal(f.errors.at(-1),'');assert(![...f.timers.values()].some(t=>t.ms===8000));assert(!f.connection().closed);f.cleanup();
});
test('a late provider response after playback timeout is deleted without reopening playback',async()=>{
 let resolve;const response=new Promise(r=>resolve=r);const f=fixture({fetchOffer:()=>response});await drain();
 [...f.timers.values()].find(t=>t.ms===30000).fn();
 resolve(new Response('late answer',{headers:{location:'/session'}}));await drain();
 assert.equal(f.connection().closed,true);assert.equal(f.video.srcObject,null);assert.equal(f.deleted(),1);assert.match(f.errors.at(-1),/No picture or sound/);f.cleanup();
});
