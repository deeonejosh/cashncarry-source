import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
const text = ts.transpileModule(
  fs.readFileSync("app/portrait-publisher.ts", "utf8"),
  {
    compilerOptions: {
      module: ts.ModuleKind.ESNext,
      target: ts.ScriptTarget.ES2022,
    },
  },
).outputText;
const { portraitCrop, createPortraitPublisher } = await import(
  "data:text/javascript;base64," + Buffer.from(text).toString("base64")
);
test("landscape and rotated frames are centred and cropped without distortion", () => {
  for (const [w, h] of [
    [1920, 1080],
    [720, 1280],
    [1080, 1920],
    [1080, 1080],
  ]) {
    const c = portraitCrop(w, h);
    assert.equal(c.width / c.height, 9 / 16);
    assert.equal(c.x * 2 + c.width, w);
    assert.equal(c.y * 2 + c.height, h);
    assert.ok(c.width <= w && c.height <= h);
  }
});
test("outgoing portrait video uses current camera frames, retains native audio and cleans up", () => {
  let next,
    cancelled,
    draws = [];
  const videoTrack = {
    stop() {
      this.stopped = true;
    },
  };
  const audio = { kind: "audio" };
  const canvas = {
    getContext: () => ({
      drawImage(...args) {
        draws.push(args);
      },
    }),
    captureStream(fps) {
      assert.equal(fps, 30);
      return {
        getVideoTracks: () => [videoTrack],
        getTracks: () => [videoTrack],
      };
    },
  };
  globalThis.document = { createElement: () => canvas };
  globalThis.requestAnimationFrame = (fn) => ((next = fn), 7);
  globalThis.cancelAnimationFrame = (id) => (cancelled = id);
  globalThis.MediaStream = class {
    constructor(tracks) {
      this.tracks = tracks;
    }
  };
  const video = { readyState: 2, videoWidth: 1920, videoHeight: 1080 };
  const p = createPortraitPublisher(video, { getAudioTracks: () => [audio] });
  assert.equal(canvas.width, 720);
  assert.equal(canvas.height, 1280);
  assert.deepEqual(p.stream.tracks, [videoTrack, audio]);
  assert.equal(draws[0][3] / draws[0][4], 9 / 16);
  video.videoWidth = 720;
  video.videoHeight = 1280;
  next();
  assert.equal(draws.at(-1)[3], 720);
  p.stop();
  assert.equal(videoTrack.stopped, true);
  assert.equal(cancelled, 7);
  const before = draws.length;
  next();
  assert.equal(draws.length, before);
});
