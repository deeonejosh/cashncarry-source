import test from 'node:test';
import assert from 'node:assert/strict';
import {sourceModule} from './load-route.mjs';
const {completeIceOffer}=await import(sourceModule('app/webrtc-offer.ts'));
test('offer contains gathered candidates rather than initial SDP',async()=>{
 const pc=new EventTarget();
 Object.assign(pc,{iceGatheringState:'gathering',signalingState:'have-local-offer',createOffer:async()=>({sdp:'initial'}),setLocalDescription:async()=>{pc.localDescription={sdp:'initial'};setTimeout(()=>{pc.localDescription={sdp:'complete-candidates'};pc.iceGatheringState='complete';pc.dispatchEvent(new Event('icegatheringstatechange'));},5);}});
 assert.equal(await completeIceOffer(pc),'complete-candidates');
});
test('closed connections cannot submit an offer',async()=>{
 const pc={iceGatheringState:'complete',signalingState:'closed',createOffer:async()=>({sdp:'initial'}),setLocalDescription:async()=>{}};
 await assert.rejects(completeIceOffer(pc),/closed/);
});
