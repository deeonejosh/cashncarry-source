import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {sourceModule} from './load-route.mjs';
import {onboardFixtureSellers} from './seller-fixture.mjs';
const db=new DatabaseSync(':memory:');
for(const f of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+f,'utf8'));
class Q{constructor(s,a=[]){this.s=s;this.a=a}bind(...a){return new Q(this.s,a)}async first(){return db.prepare(this.s).get(...this.a)||null}async all(){return {results:db.prepare(this.s).all(...this.a)}}async run(){return db.prepare(this.s).run(...this.a)}}
globalThis.testEnv={DB:{prepare:s=>new Q(s),batch:async ss=>{db.exec('BEGIN');try{const out=[];for(const s of ss)out.push(await s.run());db.exec('COMMIT');return out}catch(e){db.exec('ROLLBACK');throw e}}},FLW_SECRET_KEY:'FLWSECK_TEST-isolated-fixture',FLW_WEBHOOK_HASH:'fixture',SITE_URL:'https://shop.test'};
globalThis.testUser={userId:'buyer',email:'buyer@example.invalid',displayName:'Test buyer'};
const api=await import(sourceModule('app/api/commerce/route.ts'));
const payments=await import(sourceModule('app/payments.ts'));
const calls=[];let verification;
globalThis.fetch=async(url,opt)=>{if(String(url).endsWith('/payments')){calls.push(JSON.parse(opt.body));return Response.json({status:'success',data:{link:'https://checkout.flutterwave.com/isolated-fixture'}})}return Response.json({status:'success',data:verification})};
db.exec(`INSERT INTO stores(id,owner,name,category,location,coverage,shipping_fee,created) VALUES('s','seller','Test store','Tech','Lagos','["Lagos"]',1500,'now'); INSERT INTO products(id,store,name,description,category,price,stock,image,created) VALUES('p','s','Test product','Fixture','Tech',20000,50,'','now');`);
onboardFixtureSellers(db);
async function post(body,status=200){const r=await api.POST(new Request('https://shop.test/api/commerce',{method:'POST',headers:{origin:'https://shop.test','Content-Type':'application/json'},body:JSON.stringify(body)}));const b=await r.json();assert.equal(r.status,status,JSON.stringify(b));return b}
const checkout=(extra={})=>({action:'checkout',key:crypto.randomUUID(),payment:'flutterwave',product:'p',quantity:1,name:'Test buyer',phone:'08012345678',address:'Test fixture address',delivery_state:'Lagos',...extra});
test('forged direct and cart amounts, currency and free shipping never change server payable total',async()=>{
 const b=await post(checkout({price:200,amount:200,total:200,shipping_fee:0,delivery_fee:0,currency:'USD',discount:99}));
 const o=db.prepare('SELECT total,delivery_fee FROM orders WHERE id=?').get(b.orderIds[0]);assert.deepEqual({...o},{total:21500,delivery_fee:1500});assert.equal(calls.at(-1).amount,21500);assert.equal(calls.at(-1).currency,'NGN');
 await post({action:'cart',product:'p',quantity:2,price:1,total:2});const c=await post(checkout({product:undefined,price:1,total:2,delivery_fee:0}));assert.equal(db.prepare('SELECT total FROM orders WHERE id=?').get(c.orderIds[0]).total,41500);assert.equal(calls.at(-1).amount,41500);
});
test('invalid quantities and unauthorised seller price editing are rejected',async()=>{
 for(const quantity of [-1,0,1.5,100])await post(checkout({quantity}),400);
 await post({action:'cart',product:'p',quantity:-1,price:1},400);
 await post({action:'product',id:'p',name:'Tampered',price:1,stock:50},400);
 assert.equal(db.prepare("SELECT price FROM products WHERE id='p'").get().price,20000);
});
test('variant price is loaded from the seller record rather than forged selected-option fields',async()=>{
 db.prepare("INSERT INTO products(id,store,name,description,category,price,stock,image,variants,created) VALUES('variant','s','Option fixture','Fixture','Tech',25000,4,'',?,'now')").run(JSON.stringify([{name:'Black',price:20000,stock:4}]));
 const b=await post(checkout({product:'variant',variant:'Black',price:200,variantPrice:200,amount:200,shipping_fee:0}));
 assert.equal(db.prepare('SELECT total FROM orders WHERE id=?').get(b.orderIds[0]).total,21500);
 assert.equal(db.prepare('SELECT price FROM order_items WHERE order_id=?').get(b.orderIds[0]).price,20000);
 await post(checkout({product:'variant',variant:'Forged',price:1}),400);
});
test('live checkout uses stored deal price and rejects expired promotional references',async()=>{
 db.exec(`INSERT INTO streams(id,store,title,url,product,status,created) VALUES('live','s','Fixture','','p','live','now'); INSERT INTO livestream_deals(id,store,product,stream,promo_price,max_quantity,starts_at,ends_at,status,created,updated) VALUES('deal','s','p','live',15000,5,'2020-01-01T00:00:00.000Z','2999-01-01T00:00:00.000Z','active','now','now');`);
 const b=await post(checkout({stream:'live',dealId:'deal',price:1,dealPrice:1,total:1}));assert.equal(db.prepare('SELECT total FROM orders WHERE id=?').get(b.orderIds[0]).total,16500);assert.equal(calls.at(-1).amount,16500);
 db.exec("UPDATE livestream_deals SET starts_at='2010-01-01T00:00:00.000Z',ends_at='2011-01-01T00:00:00.000Z' WHERE id='deal'");await post(checkout({stream:'live',dealId:'deal',price:1}),400);
});
test('payment amount/currency/reference mismatches cannot mark paid; replay cannot duplicate settlement',async()=>{
 const b=await post(checkout());const o=b.orderIds[0];const p=db.prepare('SELECT * FROM payments WHERE order_id=?').get(o);
 const valid={id:987654,tx_ref:p.id,status:'successful',amount:p.amount,currency:'NGN'};
 for(const change of [{amount:200},{currency:'USD'},{tx_ref:'another-order'}]){verification={...valid,...change};await assert.rejects(()=>payments.verifyPayment('987654',p.id),/match/);assert.equal(db.prepare('SELECT payment_status FROM orders WHERE id=?').get(o).payment_status,'pending')}
 verification=valid;assert.equal((await payments.verifyPayment('987654',p.id)).status,'paid');const stock=db.prepare("SELECT stock FROM products WHERE id='p'").get().stock;assert.equal((await payments.verifyPayment('987654',p.id)).status,'paid');assert.equal(db.prepare("SELECT stock FROM products WHERE id='p'").get().stock,stock);assert.equal(db.prepare('SELECT COUNT(*) n FROM payments WHERE order_id=?').get(o).n,1);
});
