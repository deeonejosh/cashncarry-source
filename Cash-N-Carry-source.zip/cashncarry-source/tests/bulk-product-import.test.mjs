import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import * as XLSX from "xlsx";
import { parseBulkProductWorkbook } from "../app/bulk-product-parser.mjs";
import { createBulkProductTemplate } from "../app/bulk-product-template.mjs";
import { BULK_PRODUCT_HEADERS, BULK_PRODUCT_MAX_ROWS, bulkDuplicateKey, isSafeBulkImageUrl, splitBulkImageUrls } from "../app/bulk-product-utils.mjs";

function workbook(rows, headers = BULK_PRODUCT_HEADERS) {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([headers, ...rows]), "Products");
  return XLSX.write(wb, { type: "array", bookType: "xlsx" });
}

const sampleRow = (override = {}) => ({
  "Product Name": "Cotton shirt",
  Description: "A breathable cotton shirt.",
  Category: "Fashion",
  "Price (NGN)": 2500,
  SKU: "SHIRT-001",
  "Stock Quantity": 8,
  "Main Image URL": "https://images.example.org/shirt.jpg",
  "Additional Image URLs": "https://images.example.org/back.jpg | https://images.example.org/label.jpg",
  "Product Status": "Draft",
  ...override,
});

test("download template uses the supported product schema and gives clear workbook instructions", () => {
  const template = createBulkProductTemplate();
  const wb = XLSX.read(template, { type: "array" });
  assert.deepEqual(XLSX.utils.sheet_to_json(wb.Sheets.Products, { header: 1 })[0], BULK_PRODUCT_HEADERS);
  const guide = XLSX.utils.sheet_to_json(wb.Sheets.Instructions, { header: 1 }).flat().join(" ");
  assert.match(guide, /Draft or Publish/);
  assert.match(guide, /Unsupported fields/);
  assert.match(guide, /do not import this row/i);
  assert.match(guide, /optional/i);
  assert.throws(() => parseBulkProductWorkbook(template), /Add at least one product row/);
});

test("xlsx parsing maps supported columns, preserves sheet row numbers and image lists", () => {
  const rows = parseBulkProductWorkbook(workbook([
    ["Cotton shirt", "Description", "Fashion", 2500, "SHIRT-001", 8, "https://images.example.org/shirt.jpg", "https://images.example.org/back.jpg | https://images.example.org/label.jpg", "Draft"],
    ["", "", "", "", "", "", "", "", ""],
    ["Leather bag", "Description", "Fashion", 8900, "BAG-009", 2, "https://images.example.org/bag.jpg", "", "Publish"],
  ]));
  assert.equal(rows.length, 2);
  assert.equal(rows[0].rowNumber, 2);
  assert.deepEqual(rows[0].images, ["https://images.example.org/back.jpg", "https://images.example.org/label.jpg"]);
  assert.equal(rows[1].rowNumber, 4);
  assert.equal(rows[1].status, "Publish");
});

test("image columns and values are optional", () => {
  const headers = BULK_PRODUCT_HEADERS.filter((header) => !header.includes("Image"));
  const rows = parseBulkProductWorkbook(workbook([["No photo", "A product without a photo", "Fashion", 2500, "NO-PHOTO-1", 3, "Draft"]], headers));
  assert.equal(rows[0].image, "");
  assert.deepEqual(rows[0].images, []);
  assert.equal(isSafeBulkImageUrl(""), "");
});

test("parser rejects unknown business fields and formula cells instead of silently discarding data", () => {
  const unsupportedHeaders = [...BULK_PRODUCT_HEADERS, "Sale Price (NGN)"];
  const unsupportedRow = [...Object.values(sampleRow()), 2000];
  assert.throws(() => parseBulkProductWorkbook(workbook([unsupportedRow], unsupportedHeaders)), /Unsupported spreadsheet columns: Sale Price/);
  const formula = workbook([["Cotton shirt", "Description", "Fashion", 2500, "SHIRT-001", 8, "https://images.example.org/shirt.jpg", "", "Draft"]]);
  const wb = XLSX.read(formula, { type: "array", cellFormula: true });
  wb.Sheets.Products.D2 = { t: "n", f: "1000+1500", v: 2500 };
  assert.throws(() => parseBulkProductWorkbook(XLSX.write(wb, { type: "array", bookType: "xlsx" })), /Remove spreadsheet formulas/);
});

test("parser caps rows and workbook bytes", () => {
  const values = Array.from({ length: BULK_PRODUCT_MAX_ROWS + 1 }, (_, index) => ["Item " + index, "Description", "Fashion", 1500, "SKU-" + index, 1, "https://images.example.org/item.jpg", "", "Draft"]);
  assert.throws(() => parseBulkProductWorkbook(workbook(values)), /no more than 500/);
  assert.throws(() => parseBulkProductWorkbook(new ArrayBuffer(5 * 1024 * 1024 + 1)), /smaller than 5 MB/);
});

test("bulk image URL validation allows public HTTPS hosts and rejects internal or unsafe sources", () => {
  assert.equal(isSafeBulkImageUrl("https://cdn.example.org/a.jpg"), "");
  for (const url of ["http://cdn.example.org/a.jpg", "https://127.0.0.1/a.jpg", "https://10.0.0.4/a.jpg", "https://localhost/a.jpg", "https://seller:secret@cdn.example.org/a.jpg", "https://router.local/image.png"]) {
    assert.notEqual(isSafeBulkImageUrl(url), "", url);
  }
  assert.equal(isSafeBulkImageUrl("/api/media/valid_123"), "");
  assert.notEqual(isSafeBulkImageUrl("/api/media/../private"), "");
  assert.deepEqual(splitBulkImageUrls("one | two; three\nfour"), ["one", "two", "three", "four"]);
});

test("duplicate comparison is seller SKU aware and case insensitive", () => {
  assert.equal(bulkDuplicateKey({ sku: "Bag-10" }), bulkDuplicateKey({ sku: "bag-10" }));
  assert.equal(bulkDuplicateKey({ name: "Cotton Tee", category: "Fashion", price: 2500 }), bulkDuplicateKey({ name: " cotton tee ", category: "fashion", price: 2500 }));
});

test("migration supports multiple blank SKUs and rejects duplicate non-empty SKUs only within the same store", () => {
  const db = new DatabaseSync(":memory:");
  for (const file of readdirSync("drizzle").filter((name) => name.endsWith(".sql")).sort()) db.exec(readFileSync("drizzle/" + file, "utf8"));
  db.exec("INSERT INTO stores(id,owner,name,category,location,created) VALUES('one','owner1','One','Fashion','Lagos','now'),('two','owner2','Two','Fashion','Lagos','now');");
  const insert = db.prepare("INSERT INTO products(id,store,name,sku,description,category,price,stock,image,created) VALUES(?,?,?,?,?,?,?,?,?,'now')");
  insert.run("p1", "one", "One", "SKU-1", "Desc", "Fashion", 1000, 1, "https://img.example.org/a.jpg");
  insert.run("p2", "one", "Two", "", "Desc", "Fashion", 1000, 1, "https://img.example.org/b.jpg");
  insert.run("p3", "one", "Three", "", "Desc", "Fashion", 1000, 1, "https://img.example.org/c.jpg");
  insert.run("p4", "two", "Other seller", "SKU-1", "Desc", "Fashion", 1000, 1, "https://img.example.org/d.jpg");
  assert.throws(() => insert.run("p5", "one", "Duplicate SKU", "sku-1", "Desc", "Fashion", 1000, 1, "https://img.example.org/e.jpg"), /UNIQUE constraint failed/);
  db.close();
});
