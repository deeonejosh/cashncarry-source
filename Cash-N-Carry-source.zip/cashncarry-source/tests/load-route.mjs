import ts from "typescript";
import { readFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { pathToFileURL } from "node:url";
export function sourceModule(path, env = "testEnv", user = "testUser") {
  let src = readFileSync(path, "utf8");
  src = src.replace(
    /import\s*\{\s*sendEmail\s*\}\s*from\s*["'][^"']*auth["'];?/g,
    "const sendEmail=async(...args)=>globalThis.testSendEmail?.(...args);",
  );
  src = src
    .replace(
      /import\s*\{\s*env\s*\}\s*from\s*["']cloudflare:workers["'];?/g,
      `const env=globalThis.${env};`,
    )
    .replace(
      /import\s*\{\s*getChatGPTUser\s*\}\s*from\s*["'][^"']*chatgpt-auth["'];?/g,
      `const getChatGPTUser=async()=>typeof globalThis.${user}==='function'?globalThis.${user}():globalThis.${user};`,
    )
    .replace(
      /import\s*\{[^}]*\bisAdmin\b[^}]*\}\s*from\s*["'][^"']*admin-access["'];?/g,
      `const adminRole=async(u)=>globalThis.fixtureAdminRole ?? (u&&env.REVIBE_ADMIN_EMAIL&&u.email===env.REVIBE_ADMIN_EMAIL?"owner":null); const isAdmin=async(u,p="overview")=>{const role=await adminRole(u);return role?globalThis.fixtureCanAdmin?.(role,p)??true:false;}; const isOwnerIdentity=(u)=>Boolean(u&&env.REVIBE_ADMIN_EMAIL&&u.email.toLowerCase()===env.REVIBE_ADMIN_EMAIL.toLowerCase()); const requireAdminMfa=async()=>{};`,
    );
  src = src.replace(
    /from\s*["'](\.\.?\/[^"']+)["']/g,
    (full, p) =>
      "from " +
      JSON.stringify(
        p.endsWith(".mjs") || p.endsWith(".js")
          ? pathToFileURL(resolve(dirname(path), p)).href
          : sourceModule(resolve(dirname(path), p) + ".ts", env, user),
      ),
  );
  src = src.replaceAll("console.error(e);", "");
  return (
    "data:text/javascript;base64," +
    Buffer.from(
      ts.transpileModule(src, {
        compilerOptions: {
          target: ts.ScriptTarget.ES2023,
          module: ts.ModuleKind.ESNext,
        },
      }).outputText,
    ).toString("base64")
  );
}
