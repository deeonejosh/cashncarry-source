import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const source = readFileSync("app/admin/panel.tsx", "utf8");

test("admin panel footer describes role-controlled access without claiming the current user is blocked", () => {
  assert.match(source, /<span>Access is role controlled\.<\/span>/);
  assert.doesNotMatch(source, /<span>Restricted administrator access<\/span>/);
});
