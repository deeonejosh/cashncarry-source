import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import ts from "typescript";
const encode = (source) =>
  "data:text/javascript;base64," +
  Buffer.from(
    ts.transpileModule(source, {
      compilerOptions: {
        target: ts.ScriptTarget.ES2023,
        module: ts.ModuleKind.ESNext,
      },
    }).outputText,
  ).toString("base64");
let source = readFileSync("app/chatgpt-auth.ts", "utf8").replace(
  /import[\s\S]*?from\s*["'][^"']+["'];/g,
  "",
);
const nav = encode(readFileSync("app/auth-navigation.ts", "utf8"));
source =
  `import {safeReturnPath} from ${JSON.stringify(nav)};const env={DB:{prepare:()=>({bind:()=>({first:async()=>globalThis.existingEmailProfile})})}};const headers=async()=>globalThis.privateLinkHeaders;const authAvailable=async()=>globalThis.privateLinkReady;const getAuth=async()=>({api:{getSession:async()=>globalThis.privateLinkSession}});const redirect=url=>{throw Error('redirect:'+url);};` +
  source;
const auth = await import(encode(source));
test("private email links use configured email entry, preserve destination and retain unavailable-email fallback", async () => {
  globalThis.privateLinkHeaders = new Headers();
  globalThis.privateLinkReady = true;
  globalThis.privateLinkSession = null;
  for (const destination of [
    "/order/123",
    "/admin/email-templates",
    "/workspace?tab=Support",
    "/account",
  ])
    await assert.rejects(
      () => auth.requireChatGPTUser(destination),
      (e) =>
        e.message ===
        "redirect:/sign-in?returnTo=" + encodeURIComponent(destination),
    );
  await assert.rejects(
    () => auth.requireChatGPTUser("https://evil.example"),
    (e) => e.message === "redirect:/sign-in?returnTo=%2F%23market",
  );
  globalThis.privateLinkReady = false;
  await assert.rejects(
    () => auth.requireChatGPTUser("/order/123"),
    (e) =>
      e.message === "redirect:/signin-with-chatgpt?return_to=%2Forder%2F123",
  );
});
test("existing email-account identity and hosted identity stay unchanged; unverified sessions do not gain access", async () => {
  globalThis.privateLinkReady = true;
  globalThis.privateLinkHeaders = new Headers();
  globalThis.existingEmailProfile = { id: "existing-customer" };
  globalThis.privateLinkSession = {
    user: {
      id: "email-auth-id",
      email: "buyer@example.invalid",
      name: "Buyer",
      emailVerified: true,
    },
  };
  assert.equal(
    (await auth.requireChatGPTUser("/order/123")).userId,
    "existing-customer",
  );
  globalThis.privateLinkSession.user.emailVerified = false;
  assert.equal(await auth.getChatGPTUser(), null);
  globalThis.privateLinkHeaders = new Headers({
    "oai-authenticated-user-id": "hosted-customer",
    "oai-authenticated-user-email": "hosted@example.invalid",
  });
  assert.equal(
    (await auth.requireChatGPTUser("/admin/email-templates")).userId,
    "hosted-customer",
  );
});
