import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const moduleUrl = src => 'data:text/javascript;base64,' + Buffer.from(ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2023}}).outputText).toString('base64');
const navigationSrc=fs.readFileSync('app/auth-navigation.ts','utf8');
const nav=await import(moduleUrl(navigationSrc));
for(const bad of [null,'https://evil.example','//evil.example','/\\evil.example','/signout-with-chatgpt','/api/auth/sign-out','/account?token=secret','/sign-in','/callback','/\nexample']) assert.equal(nav.safeReturnPath(bad),'/#market');
for(const good of ['/product/123','/order/123','/?stream=abc','#market','/#market?q=bag','/workspace?tab=Orders']) if(good.startsWith('/')) assert.equal(nav.safeReturnPath(good),good);
let route=fs.readFileSync('app/api/auth/[...all]/route.ts','utf8');
route=route.replace(/import \{ recordMfaSession[^;]+;/, "const recordMfaSession=async()=>{};const mfaResponseHeaders=(req)=>req.headers;");
route=route.replace(/import \{ MIN_PASSWORD_LENGTH, safeReturnPath \}[^;]+;/,navigationSrc.replaceAll('export ',''));
route=route.replace(/import \{ limit \}[^;]+;/,'const limit=async()=>{if(globalThis.authLimitError)throw Error(globalThis.authLimitError);};');
route=route.replace(/import \{ getAuth, authAvailable \}[^;]+;/,'const authAvailable=()=>globalThis.authReady; const getAuth=()=>({handler:async(req)=>{if(globalThis.authHandlerError)throw Error("Provider failed with private detail");globalThis.captured=await req.json();return Response.json({ok:true,user:{id:"fixture-user"}});}});');
route=route.replace(/import \{ env \}[^;]+;/,"const env=globalThis.authEnv;");
const acceptances=[];
globalThis.authEnv={DB:{prepare(sql){return {first:async()=>sql.startsWith("SELECT version")?{version:1}:null,bind(...args){return {run:async()=>{acceptances.push(args);return {changes:1};}};}};}}};
const {POST}=await import(moduleUrl(route));
globalThis.authReady=true;
const post=body=>POST(new Request('https://shop.example/api/auth/sign-up/email',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}));
const valid={name:'Test Customer',email:'buyer@example.test',password:'valid-password-123',termsAccepted:true,termsVersion:1,callbackURL:'/sign-in?verified=1&returnTo=%2Forder%2F123'};
assert.equal((await post({...valid,termsAccepted:false})).status,400);
assert.equal((await post({...valid,password:'short'})).status,400);
assert.equal((await post({...valid,name:' '})).status,400);
assert.equal((await post({...valid,role:'admin',seller:true})).status,200);
assert.equal(globalThis.captured.role,undefined);assert.equal(globalThis.captured.seller,undefined);assert.equal(globalThis.captured.termsAccepted,undefined);assert.equal(acceptances.length,1);assert.equal(acceptances[0][1],'fixture-user');assert.equal(acceptances[0][2],1);
assert.equal(globalThis.captured.callbackURL,'/sign-in?verified=1&returnTo=%2Forder%2F123');
await post({...valid,callbackURL:'https://evil.example'});assert.equal(globalThis.captured.callbackURL,'/sign-in?verified=1');
globalThis.authReady=false;assert.equal((await post(valid)).status,503);
console.log('PASS: safe shopping return paths, registration terms/password validation, customer-only payload, verification callback and missing-service errors. Provider delivery and real sessions untested.');

assert.equal(nav.shoppingReturnPath('/?browse=1#market?q=bag','cart'),'/?browse=1&open=cart#market?q=bag');
assert.equal(nav.shoppingReturnPath('/?browse=1#market','seller'),'/?browse=1#seller');
assert.equal(nav.shoppingReturnPath('/?browse=1#market','Orders'),'/?browse=1#orders');
assert.equal(nav.shoppingReturnPath('https://evil.test','cart'),'/?open=cart#market');
assert.equal(nav.shoppingReturnPath('/#market','https://evil.test'),'/#market');
await nav.signOutEmailSession(async()=>Response.json({ok:true}));
await assert.rejects(()=>nav.signOutEmailSession(async()=>new Response('',{status:503})),/Sign-out failed/);
await assert.rejects(()=>nav.signOutEmailSession(async()=>{throw Error('Offline')}),/Offline/);
assert.equal((await POST(new Request('https://shop.example/api/auth/sign-out',{method:'POST'}))).status,200);
console.log('PASS: recognised Cart/Seller/Orders return intents, unsafe return rejection, logout success/failure and ChatGPT-only logout.');

assert.equal(nav.workspaceTab('Delivery'),'Delivery');
assert.equal(nav.workspaceTab('Shipping'),'Account');
assert.equal(nav.workspaceTab(null),'Account');
assert.equal(nav.workspaceTab('Support'),'Support');

// A rejected asynchronous handler must be caught without disclosing private errors.
globalThis.authReady=true;
globalThis.authHandlerError=true;
let failure=await post(valid);
assert.equal(failure.status,503);
assert.equal(failure.headers.get('Cache-Control'),'no-store');
assert.doesNotMatch(JSON.stringify(await failure.json()),/private detail/);
globalThis.authHandlerError=false;
globalThis.authLimitError='Too many requests. Try again in a minute.';
failure=await post(valid);
assert.equal(failure.status,429);
assert.equal(failure.headers.get('Retry-After'),'60');
globalThis.authLimitError='Storage unavailable';
assert.equal((await post(valid)).status,503);
globalThis.authLimitError='';
console.log('PASS: asynchronous authentication failures become safe 503 responses; throttling uses 429 with Retry-After.');

assert.equal(nav.safeReturnPath('/account'),'/account');
assert.equal(nav.safeReturnPath('/seller'),'/seller');

const verification=body=>POST(new Request('https://shop.example/api/auth/send-verification-email',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}));
assert.equal((await verification({email:'invalid'})).status,400);
assert.equal((await verification({email:'buyer@example.test',callbackURL:'https://evil.example',role:'admin'})).status,200);
assert.equal(globalThis.captured.callbackURL,'/sign-in?verified=1');
assert.equal(globalThis.captured.role,undefined);
assert.equal((await verification({email:'buyer@example.test',callbackURL:'/sign-in?returnTo=%2Fseller'})).status,200);
assert.equal(globalThis.captured.callbackURL,'/sign-in?verified=1&returnTo=%2Fseller');
console.log('PASS: verification resends validate email, discard injected roles and preserve only safe sign-in destinations.');

// Emulate Workers rejecting a consumed Request constructor input (Node permits it).
const NativeRequest = globalThis.Request;
let forwardedHeaders;
globalThis.Request = class extends NativeRequest {
  constructor(input, init) {
    if (input instanceof NativeRequest && input.bodyUsed) throw TypeError('Consumed body');
    super(input, init);
    if (typeof input === 'string' && init?.headers instanceof Headers) forwardedHeaders = init.headers;
  }
};
try {
  const request = new Request('https://shop.example/api/auth/sign-up/email', {method:'POST', headers:{'Content-Type':'application/json','Content-Length':'999',Origin:'https://shop.example',Cookie:'fixture=session'},body:JSON.stringify(valid)});
  assert.equal((await POST(request)).status,200);
  assert.equal(forwardedHeaders.get('Content-Length'),null);
  assert.equal(forwardedHeaders.get('Origin'),'https://shop.example');
  assert.equal(forwardedHeaders.get('Cookie'),'fixture=session');
  assert.equal((await verification({email:'buyer@example.test'})).status,200);
  assert.equal((await post(null)).status,400);
} finally { globalThis.Request = NativeRequest; }
console.log('PASS: Workers consumed-body compatibility, preserved security headers, corrected content length and safe unexpected errors.');
