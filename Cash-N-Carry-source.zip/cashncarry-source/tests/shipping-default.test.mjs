import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import assert from 'node:assert/strict';
const sqlite=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sqlite.exec(readFileSync('drizzle/'+f,'utf8'));
class Query{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Query(this.sql,args);}async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}async first(){return sqlite.prepare(this.sql).get(...this.args)||null;}async run(){return sqlite.prepare(this.sql).run(...this.args);}}
globalThis.testEnv={DB:{prepare:s=>new Query(s),batch:async stmts=>{sqlite.exec('BEGIN');try{const results=[];for(const s of stmts)results.push(await s.run());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}}};
globalThis.testUser=null;
const {sourceModule}=await import('./load-route.mjs');
const api=await import(sourceModule('app/api/commerce/route.ts'));
const user=id=>globalThis.testUser=id?{userId:id,email:id+'@test.invalid',displayName:id,fullName:id}:null;
const post=async(b,expect=200,origin='https://revibe.test')=>{const r=await api.POST(new Request('https://revibe.test/api/commerce',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(b)}));const d=await r.json();assert.equal(r.status,expect,JSON.stringify(d));return d;};
const state=async()=>await (await api.GET(new Request('https://revibe.test/api/commerce'))).json();

user('seller'); await state();
await post({action:'store',name:'Shipping Store',location:'Lagos',phone:'08012345678',category:'Tech'});
assert.equal((await state()).myStore.delivery_fee,100);
const settings={action:'delivery-settings',state:'Lagos',area:'Ikeja',coverage:['Lagos'],delivery_days:'2–3 days',return_policy:'Contact the store'};
await post({...settings,delivery_fee:250});
assert.equal((await state()).myStore.delivery_fee,250);
assert.equal(sqlite.prepare("SELECT shipping_fee FROM stores WHERE owner='seller'").get().shipping_fee,250);
await post({...settings,delivery_fee:0});
assert.equal((await state()).myStore.delivery_fee,0);
await post({...settings,delivery_fee:-1},400);
assert.equal((await state()).myStore.delivery_fee,0);
console.log('PASS: default ₦100, seller edits persist, free shipping and invalid fee rejection.');
