import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {sourceModule} from './load-route.mjs';
import {onboardFixtureSellers} from './seller-fixture.mjs';
const db=new DatabaseSync(':memory:');
for(const file of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+file,'utf8'));
class Q{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Q(this.sql,args)}async first(){return db.prepare(this.sql).get(...this.args)||null}async all(){return{results:db.prepare(this.sql).all(...this.args)}}async run(){return{meta:db.prepare(this.sql).run(...this.args)}}}
globalThis.testEnv={DB:{prepare:sql=>new Q(sql),batch:async stmts=>{db.exec('BEGIN');try{const result=[];for(const stmt of stmts)result.push(await stmt.run());db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}}}};
globalThis.testUser={userId:'seller',email:'seller@test.invalid',displayName:'Seller',fullName:'Seller'};
db.exec("INSERT INTO profiles(id,email,name,created,last_seen) VALUES('seller','seller@test.invalid','Seller','now','now');INSERT INTO stores(id,owner,name,category,location,created) VALUES('store','seller','Shop','Tech','Lagos','now');INSERT INTO products(id,store,name,description,category,price,stock,image,created) VALUES('item','store','Item','Item','Tech',100,4,'https://image.test/item','now'),('bundle-product','store','Bundle','Includes two products','Bundles',150,2,'https://image.test/bundle','now');INSERT INTO streams(id,store,title,url,status,provider,created) VALUES('stream','store','Live','https://provider.test/play','live','external','now');");
onboardFixtureSellers(db);
const api=await import(sourceModule('app/api/commerce/route.ts'));
const end=async id=>api.POST(new Request('https://app.test/api/commerce',{method:'POST',headers:{origin:'https://app.test','content-type':'application/json'},body:JSON.stringify({action:'endstream',id})}));
test('legacy endstream cannot hide a native broadcast or leave publisher credentials active',async()=>{
 db.exec("INSERT INTO streams(id,store,title,url,status,provider,publish_url,provider_id,created) VALUES('native-live','store','Native','https://provider.test/play','live','native','https://provider.test/secret-publish','provider-input','now')");
 const response=await end('native-live');assert.equal(response.status,400);assert.match((await response.json()).error,/Live Studio/);
 const stream=db.prepare("SELECT status,publish_url FROM streams WHERE id='native-live'").get();assert.equal(stream.status,'live');assert.equal(stream.publish_url,'https://provider.test/secret-publish');
});
test('legacy endstream retains external session closure and enforces ownership',async()=>{
 assert.equal((await end('stream')).status,200);assert.equal(db.prepare("SELECT status FROM streams WHERE id='stream'").get().status,'ended');
 assert.equal((await end('not-owned')).status,400);
});
