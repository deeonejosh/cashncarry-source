import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
test('future bank and pending verification duplicates are blocked without deleting histories',()=>{
 const db=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+f,'utf8'));
 db.exec("INSERT INTO profiles(id,email,name,created,last_seen) VALUES('seller','seller@example.invalid','Seller','now','now'); INSERT INTO stores(id,owner,name,category,location,phone,created) VALUES('store','seller','Store','Tech','Lagos','000','now');");
 const bank=db.prepare("INSERT INTO seller_banks(id,store,mode,bank_code,bank_name,account_number,account_name,created,updated) VALUES(?,'store','test','044','Bank','0123456789','Seller','now','now')");bank.run('one');assert.throws(()=>bank.run('two'),/already saved/);assert.equal(db.prepare('SELECT count(*) n FROM seller_banks').get().n,1);
 const verification=db.prepare("INSERT INTO verification_requests(id,store,owner,legal_name,file_key,file_type,status,created,updated) VALUES(?,'store','seller','Seller',?,'application/pdf',?,'now','now')");verification.run('historical','private/history','approved');verification.run('pending','private/current','pending');assert.throws(()=>verification.run('duplicate','private/duplicate','pending'),/already pending/);assert.equal(db.prepare('SELECT count(*) n FROM verification_requests').get().n,2);assert.equal(db.prepare("SELECT file_key FROM verification_requests WHERE id='historical'").get().file_key,'private/history');db.close();
});
