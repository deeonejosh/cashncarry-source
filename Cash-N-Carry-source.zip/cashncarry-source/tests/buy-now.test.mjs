import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {sourceModule} from './load-route.mjs';
import {onboardFixtureSellers} from './seller-fixture.mjs';

const db=new DatabaseSync(':memory:');
for(const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+file,'utf8'));
class Query{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Query(this.sql,args);}async first(){return db.prepare(this.sql).get(...this.args)||null;}async all(){return {results:db.prepare(this.sql).all(...this.args)};}async run(){return db.prepare(this.sql).run(...this.args);}}
globalThis.testEnv={DB:{prepare:s=>new Query(s),batch:async statements=>{db.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(await statement.run());db.exec('COMMIT');return result;}catch(error){db.exec('ROLLBACK');throw error;}}},FLW_MODE:'test',FLW_SECRET_KEY:'FLWSECK_TEST-fixture',FLW_WEBHOOK_HASH:'fixturehash',SITE_URL:'https://shop.test'};
globalThis.testUser=null;
globalThis.fetch=async()=>Response.json({status:'success',data:{link:'https://checkout.flutterwave.com/test-fixture'}});
const api=await import(sourceModule('app/api/commerce/route.ts'));
const user=id=>globalThis.testUser=id?{userId:id,email:id+'@test.invalid',displayName:id,fullName:id}:null;
const post=async body=>{const response=await api.POST(new Request('https://shop.test/api/commerce',{method:'POST',headers:{origin:'https://shop.test','Content-Type':'application/json'},body:JSON.stringify(body)}));return {status:response.status,body:await response.json()};};

test('Buy Now checks out only the selected product and leaves the shopping cart untouched',async()=>{
  user('seller');
  assert.equal((await post({action:'store',name:'Direct Shop',location:'Lagos',phone:'08012345678',category:'Tech'})).status,200);
  onboardFixtureSellers(db);
  await post({action:'delivery-settings',state:'Lagos',area:'Lekki',coverage:['Lagos'],delivery_fee:1500,delivery_days:'2–3 days',return_policy:'Contact support'});
  await post({action:'product',name:'Pinned headphones',description:'Direct checkout item',category:'Tech',price:5000,stock:1,image:'https://example.com/pinned.jpg',variants:JSON.stringify([{name:'Blue',price:6000,stock:3},{name:'Black',price:5500,stock:2}])});
  await post({action:'product',name:'Cart item',description:'Keep this in the bag',category:'Tech',price:2000,stock:4,image:'https://example.com/cart.jpg'});
  const items=db.prepare('SELECT id,name FROM products ORDER BY rowid').all();
  user('buyer');
  assert.equal((await post({action:'cart',product:items[1].id,quantity:1})).status,200);
  const key=crypto.randomUUID();
  const result=await post({action:'checkout',key,product:items[0].id,variant:'Blue',quantity:2,name:'Buyer',phone:'08087654321',address:'Lekki, Lagos',delivery_state:'Lagos',payment:'flutterwave'});
  assert.equal(result.status,200,JSON.stringify(result.body));
  assert.equal(result.body.orderIds.length,1);
  const order=db.prepare('SELECT total FROM orders WHERE id=?').get(result.body.orderIds[0]);
  assert.equal(order.total,13500);
  const line=db.prepare('SELECT product,variant,quantity,price FROM order_items WHERE order_id=?').get(result.body.orderIds[0]);
  assert.deepEqual({...line},{product:items[0].id,variant:'Blue',quantity:2,price:6000});
  assert.deepEqual({...db.prepare('SELECT product,quantity FROM carts WHERE user=?').get('buyer')},{product:items[1].id,quantity:1});
  assert.equal(JSON.parse(db.prepare('SELECT variants FROM products WHERE id=?').get(items[0].id).variants).find(v=>v.name==='Blue').stock,1);
  assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(items[1].id).stock,4);
  const invalid=await post({action:'checkout',key:crypto.randomUUID(),product:items[0].id,variant:'Invalid',quantity:1,name:'Buyer',phone:'08087654321',address:'Lekki, Lagos',delivery_state:'Lagos',payment:'flutterwave'});
  assert.equal(invalid.status,400);
  assert.match(invalid.body.error,/variant is unavailable/i);
});
