import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import assert from 'node:assert/strict';
const sqlite=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sqlite.exec(readFileSync('drizzle/'+f,'utf8'));
class Query{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Query(this.sql,args);}async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}async first(){return sqlite.prepare(this.sql).get(...this.args)||null;}async run(){return sqlite.prepare(this.sql).run(...this.args);}}
globalThis.testEnv={DB:{prepare:s=>new Query(s),batch:async stmts=>{sqlite.exec('BEGIN');try{const results=[];for(const s of stmts)results.push(await s.run());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}}};
globalThis.testUser=null;
const {sourceModule}=await import('./load-route.mjs');
// Create legacy order fixtures only after exercising the current online checkout; historical COD fulfilment remains supported.
globalThis.testEnv.FLW_SECRET_KEY='FLWSECK_TEST-fixture';globalThis.testEnv.FLW_WEBHOOK_HASH='fixturehash';globalThis.testEnv.SITE_URL='https://revibe.test';
globalThis.fetch=async()=>Response.json({status:'success',data:{link:'https://checkout.flutterwave.com/test-fixture'}});

const setupModule=await import(sourceModule('app/business-setup.ts'));
const policies=await import(sourceModule('app/policy-drafts.ts'));
sqlite.prepare("INSERT INTO stores(id,owner,name,category,location,created) VALUES(?,?,?,?,?,?)").run('1a1edf07-38f9-4c3b-9a17-991e9d43f65b','gear','Gearpulse UK','Tech','Abia','now');
sqlite.prepare("INSERT INTO stores(id,owner,name,category,location,created) VALUES(?,?,?,?,?,?)").run('other','other','Other store','Tech','Lagos','now');
for(const [id,policy] of Object.entries(policies.policyDefinitions))sqlite.prepare('INSERT OR REPLACE INTO policies(id,title,content,reviewed,updated) VALUES(?,?,?,0,?)').run(id,policy.title,policy.content,'old');
sqlite.prepare("UPDATE policies SET content='Custom privacy draft' WHERE id='privacy'").run();
await setupModule.applyOwnerBusinessSetup();
const coverage=JSON.parse(sqlite.prepare("SELECT coverage FROM stores WHERE owner='gear'").get().coverage);
assert.equal(coverage.length,37);assert.ok(coverage.includes('FCT'));
assert.equal(sqlite.prepare("SELECT coverage FROM stores WHERE owner='other'").get().coverage,'[]');
assert.equal(sqlite.prepare("SELECT content FROM policies WHERE id='refunds'").get().content,policies.policyDefinitions.refunds.content);
assert.equal(sqlite.prepare("SELECT content FROM policies WHERE id='privacy'").get().content,'Custom privacy draft');
sqlite.prepare("UPDATE stores SET coverage=? WHERE owner='gear'").run(JSON.stringify(["Lagos"]));
await setupModule.applyOwnerBusinessSetup();
assert.equal(sqlite.prepare("SELECT coverage FROM stores WHERE owner='gear'").get().coverage,'["Lagos"]');
assert.equal(sqlite.prepare("SELECT reviewed FROM policies WHERE id='refunds'").get().reviewed,0);
console.log('PASS: nationwide Gearpulse setup, FCT, other store isolation, owner policy edits, draft status and later coverage changes preserved.');
