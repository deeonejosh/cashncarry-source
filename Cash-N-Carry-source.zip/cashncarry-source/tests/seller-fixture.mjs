/** Explicitly onboard existing integration-test sellers for the new mandatory gates. */
export function onboardFixtureSellers(db){
 db.exec("UPDATE stores SET verified=1; INSERT OR REPLACE INTO seller_subscriptions(store,mode,status,paid_until,updated) SELECT id,'test','active','2999-01-01T00:00:00.000Z','fixture' FROM stores;");
 db.exec("INSERT OR IGNORE INTO seller_banks(id,store,mode,bank_code,bank_name,account_number,account_name,status,created,updated) SELECT 'fixture-bank-'||id,id,'test','044','Fixture bank','0123456789',name,'verified','now','now' FROM stores;");
}
