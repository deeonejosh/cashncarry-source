import {onboardFixtureSellers} from "./seller-fixture.mjs";
import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import { sourceModule } from "./load-route.mjs";
const db = new DatabaseSync(":memory:");
for (const f of readdirSync("drizzle")
  .filter((f) => f.endsWith(".sql"))
  .sort())
  db.exec(readFileSync("drizzle/" + f, "utf8"));
class Query {
  constructor(sql, args = []) {
    this.sql = sql;
    this.args = args;
  }
  bind(...args) {
    return new Query(this.sql, args);
  }
  async first() {
    return db.prepare(this.sql).get(...this.args) || null;
  }
  async all() {
    return { results: db.prepare(this.sql).all(...this.args) };
  }
  async run() {
    return db.prepare(this.sql).run(...this.args);
  }
}
globalThis.testEnv = { DB: { prepare: (s) => new Query(s), batch: async (statements) => { db.exec("BEGIN"); try { const results=[]; for (const statement of statements) results.push(await statement.run()); db.exec("COMMIT"); return results; } catch (error) { db.exec("ROLLBACK"); throw error; } } } };
globalThis.testUser = null;
db.prepare(
  "INSERT INTO stores(id,owner,name,category,location,created) VALUES('s','seller','Shop','Tech','Lagos','now')",
).run();
db.prepare(
  "INSERT INTO streams(id,store,title,url,status,provider,heartbeat,created) VALUES('live','s','Test','https://example.invalid','live','native',?,'now')",
).run(new Date().toISOString());
onboardFixtureSellers(db);
const api = await import(sourceModule("app/api/commerce/route.ts"));
const post = async (body, expected = 200, origin = "https://app.test") => {
  const r = await api.POST(
    new Request("https://app.test/api/commerce", {
      method: "POST",
      headers: { origin, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }),
  );
  assert.equal(r.status, expected, JSON.stringify(await r.json()));
};
const read = async () =>
  await (
    await api.GET(new Request("https://app.test/api/commerce?stream=live"))
  ).json();
const user = (id) =>
  (globalThis.testUser = id
    ? { userId: id, email: id + "@example.invalid", displayName: id }
    : null);
test("broadcast likes use real, unique account records and reject unavailable or unauthorized reactions", async () => {
  assert.equal((await read()).likes, 0);
  await post({ action: "stream-like", stream: "live", liked: true }, 401);
  user("buyer");
  await post(
    { action: "stream-like", stream: "live", liked: true },
    403,
    "https://other.test",
  );
  await post({ action: "stream-like", stream: "live", liked: "true" }, 400);
  await post({ action: "stream-like", stream: "live", liked: true });
  await post({ action: "stream-like", stream: "live", liked: true });
  assert.equal((await read()).likes, 1);
  assert.equal((await read()).liked, true);
  user("second");
  await post({ action: "stream-like", stream: "live", liked: true });
  assert.equal((await read()).likes, 2);
  user("buyer");
  await post({ action: "stream-like", stream: "live", liked: false });
  assert.equal((await read()).likes, 1);
  assert.equal((await read()).liked, false);
  user(null);
  assert.equal((await read()).liked, false);
  user("buyer");
  for (const status of ["scheduled", "ended"]) {
    db.prepare("UPDATE streams SET status=?").run(status);
    await post({ action: "stream-like", stream: "live", liked: true }, 400);
  }
  db.prepare("UPDATE streams SET status='live'").run();
  db.prepare("UPDATE stores SET suspended=1").run();
  await post({ action: "stream-like", stream: "live", liked: true }, 400);
  db.prepare("UPDATE stores SET suspended=0").run();
  db.prepare("UPDATE profiles SET suspended=1 WHERE id='buyer'").run();
  await post({ action: "stream-like", stream: "live", liked: true }, 400);
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM stream_likes").get().n, 1);
});

test("host product pinning and moderation cannot change another seller broadcast", async () => {
  db.prepare("UPDATE stores SET suspended=0").run();
  db.prepare(
    "INSERT INTO stores(id,owner,name,category,location,created) VALUES('other','other-seller','Other','Tech','Lagos','now')",
  ).run();
  db.prepare(
    "INSERT INTO chats(id,stream,user,name,message,created) VALUES('chat','live','second','Viewer','Comment','now')",
  ).run();
  user("other-seller");
  await post({ action: "pin", id: "live", product: "" }, 400);
  await post({ action: "moderate-chat", id: "chat", block: true });
  assert.equal(
    db.prepare("SELECT hidden FROM chats WHERE id='chat'").get().hidden,
    0,
  );
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM live_blocks").get().n, 0);
  user("seller");
  await post({ action: "moderate-chat", id: "chat", block: true });
  assert.equal(
    db.prepare("SELECT hidden FROM chats WHERE id='chat'").get().hidden,
    1,
  );
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM live_blocks").get().n, 1);
});
