import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import assert from 'node:assert/strict';
const sqlite=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sqlite.exec(readFileSync('drizzle/'+f,'utf8'));
class Query{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Query(this.sql,args);}async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}async first(){return sqlite.prepare(this.sql).get(...this.args)||null;}async run(){return sqlite.prepare(this.sql).run(...this.args);}}
globalThis.testEnv={DB:{prepare:s=>new Query(s),batch:async stmts=>{sqlite.exec('BEGIN');try{const results=[];for(const s of stmts)results.push(await s.run());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}}};
globalThis.testUser=null;
const {sourceModule}=await import('./load-route.mjs');
const api=await import(sourceModule('app/api/commerce/route.ts'));
const user=id=>globalThis.testUser=id?{userId:id,email:id+'@test.invalid',displayName:id,fullName:id}:null;
const post=async(b,expect=200,origin='https://revibe.test')=>{const r=await api.POST(new Request('https://revibe.test/api/commerce',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(b)}));const d=await r.json();assert.equal(r.status,expect,JSON.stringify(d));return d;};
const state=async()=>await (await api.GET(new Request('https://revibe.test/api/commerce'))).json();

await post({action:'profile',name:'Anonymous',username:'visitor'},401);
user('one'); await state();
await post({action:'profile',name:'First User',username:'  Temidayo_1  '});
assert.equal((await state()).user.username,'temidayo_1');
user('two'); await state();
const collision=await post({action:'profile',name:'Changed Name',username:'TEMIDAYO_1'},400);
assert.match(collision.error,/taken/);
assert.equal(sqlite.prepare("SELECT name FROM profiles WHERE id='two'").get().name,'two');
for(const username of ['admin','support','ab','1abc','bad-name','bad name','x'.repeat(25)]) await post({action:'profile',name:'Second User',username},400);
await post({action:'profile',name:'Second User',username:'another_user'});
user('one');
await post({action:'profile',name:'Updated display name'});
assert.equal((await state()).user.username,'temidayo_1');
assert.equal(sqlite.prepare("SELECT username FROM profiles WHERE id='two'").get().username,'another_user');
user(null); assert.equal((await state()).user,null);
console.log('PASS: unique lowercase usernames, reserved/invalid rejection, atomic duplicate handling, legacy profile edits, authentication and user isolation.');
