import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { sourceModule } from './load-route.mjs';
const db=new DatabaseSync(':memory:');
for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+f,'utf8'));
class Q {constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Q(this.sql,args);}async first(){return db.prepare(this.sql).get(...this.args)||null;}async run(){return db.prepare(this.sql).run(...this.args);}}
globalThis.androidEnv={REVIBE_ADMIN_EMAIL:'admin@example.invalid',DB:{prepare:sql=>new Q(sql),batch:async statements=>{db.exec('BEGIN');try{const results=[];for(const s of statements)results.push(await s.run());db.exec('COMMIT');return results;}catch(e){db.exec('ROLLBACK');throw e;}}}};
globalThis.androidUser=null;
const {GET}=await import(sourceModule('app/.well-known/assetlinks.json/route.ts','androidEnv','androidUser'));
const {POST}=await import(sourceModule('app/api/admin/settings/route.ts','androidEnv','androidUser'));
const {androidPackage,androidLinkConfiguration}=await import(sourceModule('app/android-links.ts'));
const fingerprint=Array(32).fill('AB').join(':');
const body={action:'android-app-links',id:'android_app_links',packageName:androidPackage,fingerprints:fingerprint,confirmed:true,reason:'Owner confirmed Play certificate'};
const request=(data=body,origin='https://shop.test')=>new Request('https://shop.test/api/admin/settings',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(data)});
test('unconfigured public association is empty and only confirmed admins can publish signing certificates',async()=>{
  assert.deepEqual(await (await GET()).json(),[]);
  assert.equal((await POST(request())).status,403);
  globalThis.androidUser={userId:'seller',email:'seller@example.invalid'};assert.equal((await POST(request())).status,403);
  globalThis.androidUser={userId:'admin',email:'admin@example.invalid'};
  assert.equal((await POST(request(body,'https://evil.test'))).status,403);
  assert.equal((await POST(request({...body,confirmed:false}))).status,400);
  for(const invalid of [{...body,packageName:'bad-package'},{...body,fingerprints:'not-a-certificate'}])assert.equal((await POST(request(invalid))).status,400);
  assert.equal((await POST(request())).status,200);
  const response=await GET();assert.equal(response.status,200);
  assert.deepEqual(await response.json(),[{relation:['delegate_permission/common.handle_all_urls'],target:{namespace:'android_app',package_name:androidPackage,sha256_cert_fingerprints:[fingerprint]}}]);
  assert.equal(db.prepare("SELECT count(*) n FROM admin_audit WHERE action='android-app-links'").get().n,1);
});
test('fingerprints normalize and deduplicate; broken stored association fails closed',async()=>{
  assert.deepEqual(androidLinkConfiguration({packageName:androidPackage,fingerprints:fingerprint.toLowerCase()+'\n'+fingerprint}).fingerprints,[fingerprint]);
  db.prepare("UPDATE platform_settings SET value='broken' WHERE key='android_app_links'").run();
  const response=await GET();assert.equal(response.status,503);assert.equal(response.headers.get('Cache-Control'),'no-store');
});
test.after(()=>db.close());
