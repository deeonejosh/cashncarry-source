import test from 'node:test';
import assert from 'node:assert/strict';
import {sourceModule} from './load-route.mjs';
const {bankDetails}=await import(sourceModule('app/bank-details.ts'));
test('bank form errors identify the missing field and preserve valid formatted account numbers',()=>{
 assert.throws(()=>bankDetails({}),/Select your bank/);
 assert.throws(()=>bankDetails({bankCode:'044'}),/account holder name/);
 assert.throws(()=>bankDetails({bankCode:'044',accountName:'Seller',accountNumber:'01234'}),/10-digit/);
 assert.throws(()=>bankDetails({bankCode:'044',accountName:'Seller',accountNumber:'01234x6789'}),/10-digit/);
 assert.deepEqual(bankDetails({bankCode:'044',accountName:' Seller ',accountNumber:'012 345-6789'}),{bankCode:'044',accountName:'Seller',accountNumber:'0123456789'});
});
