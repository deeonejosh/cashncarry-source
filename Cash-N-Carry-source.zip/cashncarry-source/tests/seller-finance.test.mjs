import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {sourceModule} from './load-route.mjs';
const db=new DatabaseSync(':memory:');for(const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+file,'utf8'));
class Q {constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...a){return new Q(this.sql,a);}async first(){return db.prepare(this.sql).get(...this.args)||null;}async all(){return {results:db.prepare(this.sql).all(...this.args)};}async run(){const r=db.prepare(this.sql).run(...this.args);return {...r,meta:{changes:r.changes}};}}
globalThis.testEnv={DB:{prepare:s=>new Q(s),batch:async ss=>{db.exec('BEGIN');try{const out=[];for(const s of ss)out.push(await s.run());db.exec('COMMIT');return out;}catch(e){db.exec('ROLLBACK');throw e;}}},FLW_MODE:'test',FLW_SECRET_KEY:'FLWSECK_TEST-fixture',FLW_WEBHOOK_HASH:'fixture',SITE_URL:'https://shop.test',REVIBE_ADMIN_EMAIL:'owner@example.invalid'};
globalThis.testUser={userId:'seller',email:'seller@example.invalid'};
const {sellerActivation,requireSellerActive}=await import(sourceModule('app/seller-activation.ts'));
const finance=await import(sourceModule('app/seller-finance.ts'));
const seller=await import(sourceModule('app/api/seller-finance/route.ts'));
const admin=await import(sourceModule('app/api/admin/seller-finance/route.ts'));
const commerce=await import(sourceModule('app/api/commerce/route.ts'));
const streams=await import(sourceModule('app/api/streams/route.ts'));
const webhook=await import(sourceModule('app/api/payments/webhook/route.ts'));
const req=(path,body)=>new Request('https://shop.test'+path,{method:'POST',headers:{origin:'https://shop.test','Content-Type':'application/json'},body:JSON.stringify(body)});
const sellerPost=body=>seller.POST(req('/api/seller-finance',body));
const adminPost=body=>admin.POST(req('/api/admin/seller-finance',{reason:'Fixture review evidence',...body}));
const user=id=>globalThis.testUser={userId:id,email:id==='owner'?'owner@example.invalid':id+'@example.invalid'};
const grant=(end='2999-01-01T00:00:00.000Z')=>{db.prepare("UPDATE stores SET verified=1 WHERE id='store'").run();db.prepare("INSERT OR REPLACE INTO seller_subscriptions(store,mode,status,paid_until,updated) VALUES('store','test','active',?,'now')").run(end);};
const originalFetch=globalThis.fetch;
db.exec("INSERT INTO profiles(id,email,name,created,last_seen) VALUES('seller','seller@example.invalid','Private name','now','now'); INSERT INTO stores(id,owner,name,category,location,phone,created,coverage) VALUES('store','seller','Shop','Tech','Lagos','08012345678','now','[\"Lagos\"]');");
let tx={id:123,tx_ref:'',status:'successful',currency:'NGN',amount:2000};
let transferCalls=0,checkoutCalls=0;
globalThis.fetch=async(url,opts)=>{
 if(String(url).includes('transactions/'))return Response.json({status:'success',data:tx});
 if(String(url).includes('/subscriptions?transaction_id='))return Response.json({status:'success',data:[{id:456,plan:987,status:'active',customer:{customer_email:'seller@example.invalid'},next_due:'2026-11-12T00:00:00.000Z'}]});
 if(String(url).includes('/subscriptions/456/cancel')&&opts?.method==='PUT')return Response.json({status:'success',data:{id:456,status:'cancelled'}});
 if(String(url).includes('/subscriptions/456/activate')&&opts?.method==='PUT')return Response.json({status:'success',data:{id:456,status:'active',next_due:'2026-11-12T00:00:00.000Z'}});
 if(String(url).endsWith('/payment-plans')&&opts?.method==='GET')return Response.json({status:'success',data:[]});
 if(String(url).endsWith('/payment-plans')&&opts?.method==='POST')return Response.json({status:'success',data:{id:987,name:'Cash N Carry Seller 2000 NGN monthly test',amount:2000,currency:'NGN',interval:'monthly',status:'active'}});
 if(String(url).endsWith('/payments')){checkoutCalls++;return Response.json({status:'success',data:{link:'https://checkout.flutterwave.com/sandbox-fixture'}});}
 if(String(url).endsWith('/banks/NG'))return Response.json({status:'success',data:[{id:1,name:'Fixture Bank',code:'044'}]});
 if(String(url).endsWith('/accounts/resolve'))return Response.json({status:'success',data:{account_number:'0123456789',account_name:'Fixture Seller'}});
 if(String(url).endsWith('/transfers')&&opts?.method==='POST'){transferCalls++;throw Error('Transfer response lost');}
 if(String(url).includes('/transfers'))return Response.json({status:'success',data:[{id:999,reference:payoutRef,currency:'NGN',amount:500,account_number:'0123456789',bank_code:'044',status:transferStatus}]});
 throw Error('Unexpected provider URL');
};
let payoutRef='',transferStatus='SUCCESSFUL';
test('Nigerian bank list is available to sellers without an approved verification',async()=>{user('seller');const response=await seller.GET(new Request('https://shop.test/api/seller-finance?banks=1'));assert.equal(response.status,200);const data=await response.json();assert.deepEqual(data.banks,[{id:1,name:'Fixture Bank',code:'044'}]);});

test('bank details persist unverified, deduplicate retries, and cannot be approved or paid out',async()=>{
 user('seller');const body={action:'bank-save',bankCode:'044',accountNumber:' 1234567890 ',accountName:'Declared holder'};
 const first=await sellerPost(body);assert.equal(first.status,200);const record=await first.json();assert.equal(record.status,'pending_resolution');
 const row=db.prepare('SELECT * FROM seller_banks WHERE id=?').get(record.id);assert.equal(row.account_number,'1234567890');assert.equal(row.status,'pending_resolution');
 const retry=await (await sellerPost(body)).json();assert.equal(retry.id,record.id);
 user('owner');assert.equal((await adminPost({action:'bank-review',id:record.id,status:'verified'})).status,400);
 user('seller');const resolve=await sellerPost({action:'bank-resolve',id:record.id});assert.equal(resolve.status,400);assert.match((await resolve.json()).error,/did not match/);assert.equal(db.prepare('SELECT status FROM seller_banks WHERE id=?').get(record.id).status,'pending_resolution');
 user('outsider');assert.equal((await sellerPost({action:'bank-resolve',id:record.id})).status,400);
 db.prepare('DELETE FROM seller_banks WHERE id=?').run(record.id);user('seller');
});
test('identity review can approve without a bank; withdrawals still require approved bank ownership',async()=>{
 db.prepare("INSERT INTO verification_requests(id,store,owner,legal_name,file_key,file_type,status,created,updated) VALUES('identity-only','store','seller','Seller','private/evidence','application/pdf','pending','now','now')").run();
 user('outsider');assert.equal((await adminPost({action:'verification-review',id:'identity-only',status:'approved'})).status,403);
 user('owner');const response=await adminPost({action:'verification-review',id:'identity-only',status:'approved'});assert.equal(response.status,200);assert.equal(db.prepare("SELECT status FROM verification_requests WHERE id='identity-only'").get().status,'approved');assert.equal((await sellerActivation('store')).verification,'verified');
 db.exec("DELETE FROM verification_requests WHERE id='identity-only'; UPDATE stores SET verified=0 WHERE id='store'");user('seller');
});
test('a historical information request cannot overwrite the latest identity approval',async()=>{
 db.exec("INSERT INTO verification_requests(id,store,owner,legal_name,file_key,file_type,status,created,updated) VALUES('older-review','store','seller','Seller','private/older','application/pdf','more_information','2020','2020'),('newer-review','store','seller','Seller','private/newer','application/pdf','approved','2021','2021');");
 user('owner');const response=await adminPost({action:'verification-review',id:'older-review',status:'rejected'});assert.equal(response.status,400);assert.match((await response.json()).error,/newer application/);assert.equal(db.prepare("SELECT status FROM verification_requests WHERE id='newer-review'").get().status,'approved');db.exec("DELETE FROM verification_requests WHERE id IN ('older-review','newer-review')");user('seller');
});
test('unverified and inactive sellers cannot publish, schedule, pin or prepare broadcasts',async()=>{
 for(const action of ['product','stream','pin','schedule','tiktok','preview-session']){const r=await commerce.POST(req('/api/commerce',{action,title:'Test'}));assert.equal(r.status,400);assert.match((await r.json()).error,/verification/);}
 db.exec("INSERT INTO streams(id,store,title,url,status,provider,created) VALUES('session','store','Test','','scheduled','native','now')");
 assert.equal((await streams.POST(req('/api/streams',{action:'prepare',id:'session'}))).status,400);
 db.exec("UPDATE stores SET verified=1 WHERE id='store'");await assert.rejects(()=>requireSellerActive('store'),/subscription/);
});
test('provider-verified recurring subscription activates access, prevents duplicate checkouts, cancel/reactivate uses Flutterwave and duplicate webhooks are idempotent',async()=>{
 user('seller');const id=crypto.randomUUID();const start=await sellerPost({action:'subscription-checkout',id,acceptTerms:true,autoRenewConsent:true,termsVersion:finance.SELLER_TERMS_VERSION});assert.equal(start.status,200);
 const checkout=await start.json(),retry=await (await sellerPost({action:'subscription-checkout',id:crypto.randomUUID(),acceptTerms:true,autoRenewConsent:true,termsVersion:finance.SELLER_TERMS_VERSION})).json();assert.equal(retry.link,checkout.link);assert.equal(checkoutCalls,1);
 tx.tx_ref=id;tx.status='failed';assert.equal((await finance.verifySellerSubscription('123',id)).status,'failed');assert.equal((await sellerActivation('store')).canSell,false);
 tx.status='successful';tx.amount=1000;await assert.rejects(()=>finance.verifySellerSubscription('123',id),/mismatch/);tx.amount=2000;
 const body={event:'charge.completed',data:{id:123,tx_ref:id,status:'successful'}};
 const wh=()=>new Request('https://shop.test/api/payments/webhook',{method:'POST',headers:{'verif-hash':'fixture'},body:JSON.stringify(body)});
 assert.equal((await webhook.POST(wh())).status,200);const until=(await sellerActivation('store')).paidUntil;
 assert.equal((await sellerActivation('store')).autoRenewal,true);assert.equal((await webhook.POST(wh())).status,200);assert.equal((await sellerActivation('store')).paidUntil,until);assert.equal((await sellerActivation('store')).canSell,true);
 const duplicate=await sellerPost({action:'subscription-checkout',id:crypto.randomUUID(),acceptTerms:true,autoRenewConsent:true,termsVersion:finance.SELLER_TERMS_VERSION});assert.equal(duplicate.status,400);assert.match((await duplicate.json()).error,/already paid through/);assert.equal(checkoutCalls,1);
 tx={id:124,tx_ref:'flutterwave-renewal-fixture',status:'successful',currency:'NGN',amount:2000,payment_plan:987,customer:{email:'seller@example.invalid'}};
 body.data={id:124,tx_ref:'flutterwave-renewal-fixture',status:'successful',payment_plan:987,customer:{email:'seller@example.invalid'}};assert.equal((await webhook.POST(wh())).status,200);assert.notEqual((await sellerActivation('store')).paidUntil,until);
 assert.equal((await sellerPost({action:'subscription-cancel'})).status,200);assert.equal((await sellerActivation('store')).canSell,true);assert.equal((await sellerActivation('store')).cancelAtEnd,true);assert.equal((await sellerActivation('store')).autoRenewal,false);
 assert.equal((await sellerPost({action:'subscription-reactivate',autoRenewConsent:true,termsVersion:finance.SELLER_TERMS_VERSION})).status,200);assert.equal((await sellerActivation('store')).autoRenewal,true);
 assert.equal(finance.calendarMonthAfter('2026-01-31T12:00:00.000Z'),'2026-02-28T12:00:00.000Z');
});
test('verified active seller publishes and schedules; expiry pauses orders but preserves fulfilment',async()=>{
 user('seller');grant();const product={action:'product',name:'Test mic',description:'Fixture product',category:'Tech',price:1000,stock:10,image:'https://example.invalid/mic.jpg'};
 assert.equal((await commerce.POST(req('/api/commerce',product))).status,200);
 assert.equal((await commerce.POST(req('/api/commerce',{action:'schedule',title:'Future live',scheduled:new Date(Date.now()+3600000).toISOString()}))).status,200);
 const pid=db.prepare("SELECT id FROM products WHERE store='store'").get().id;
 db.prepare("INSERT INTO orders(id,buyer,store,name,phone,address,total,status,payment,created) VALUES('existing','buyer','store','Buyer','08012345678','Lagos',1000,'placed','cash_on_delivery','now')").run();
 grant('2020-01-01T00:00:00.000Z');assert.equal((await sellerActivation('store')).canSell,false);
 assert.equal((await commerce.POST(req('/api/commerce',product))).status,400);
 assert.equal((await commerce.POST(req('/api/commerce',{action:'status',id:'existing',status:'confirmed'}))).status,200);
 user('buyer');db.prepare("INSERT INTO carts(id,user,product,quantity) VALUES('cart','buyer',?,1)").run(pid);
 assert.equal((await commerce.POST(req('/api/commerce',{action:'checkout',key:crypto.randomUUID(),name:'Buyer',phone:'08012345678',address:'Lagos',delivery_state:'Lagos',payment:'flutterwave'}))).status,400);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM orders WHERE buyer='buyer'").get().n,1);
 user('seller');const id=crypto.randomUUID();await sellerPost({action:'subscription-checkout',id,acceptTerms:true,autoRenewConsent:true,termsVersion:finance.SELLER_TERMS_VERSION});tx={id:125,tx_ref:id,status:'successful',currency:'NGN',amount:2000};await finance.verifySellerSubscription('125',id);assert.equal((await sellerActivation('store')).canSell,true);
});
test('provider account resolution requires separate human review and private participant access',async()=>{
 user('seller');const br=await sellerPost({action:'bank-resolve',bankCode:'044',accountNumber:'0123456789'});assert.equal(br.status,200,await br.text());
 const bank=db.prepare('SELECT * FROM seller_banks').get();assert.equal(bank.status,'resolved');
 user('owner');assert.equal((await adminPost({action:'bank-review',id:bank.id,status:'verified'})).status,200);
 db.prepare("INSERT INTO verification_requests(id,store,owner,legal_name,file_key,file_type,status,created,updated) VALUES('verify','store','seller','Fixture Seller','private/document','application/pdf','pending','now','now')").run();
 assert.equal((await adminPost({action:'verification-review',id:'verify',status:'more_information'})).status,200);
 assert.equal((await adminPost({action:'verification-review',id:'verify',status:'approved'})).status,200);assert.equal(db.prepare("SELECT verified FROM stores WHERE id='store'").get().verified,1);assert.equal((await sellerActivation('store')).verification,'verified');
 user('outsider');assert.equal((await admin.GET()).status,403);assert.equal((await adminPost({action:'bank-review',id:bank.id,status:'verified'})).status,403);
});
test('available earnings require settlement release; atomic reservations prevent duplicate or excess withdrawal',async()=>{
 user('owner');assert.equal((await adminPost({action:'settings',priceMinor:200000,feeMinor:0,releaseDays:0,fundFlow:'sandbox_platform',confirmPrice:false})).status,200);
 db.exec("INSERT INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,created,delivered_at) VALUES('paidorder','buyer','store','Buyer','08012345678','Lagos',1100,'delivered','flutterwave','paid','2020-01-01','2020-01-01'); INSERT INTO payments(id,order_id,buyer,amount,currency,mode,status,provider_id,expires,created,updated) VALUES('payment','paidorder','buyer',1100,'NGN','test','paid','777','later','2020-01-01','2020-01-01');");
 assert.equal((await finance.earningsSummary('store')).availableMinor,0);
 assert.equal((await adminPost({action:'release',id:'payment',amountMinor:100000,settlementReference:'TEST-SETTLEMENT',confirm:true})).status,200);
 assert.equal((await finance.earningsSummary('store')).availableMinor,100000);
 user('seller');const bank=db.prepare("SELECT id FROM seller_banks WHERE status='verified'").get().id,id=crypto.randomUUID();payoutRef='cnc-payout-'+id;
 const body={action:'withdrawal-request',id,amountMinor:50000,bank};assert.equal((await sellerPost(body)).status,200);assert.equal((await sellerPost(body)).status,200);
 assert.equal(db.prepare('SELECT COUNT(*) n FROM seller_withdrawals').get().n,1);
 assert.equal((await finance.earningsSummary('store')).availableMinor,50000);
 assert.equal((await sellerPost({...body,id:crypto.randomUUID(),amountMinor:60000})).status,400);
 assert.equal((await sellerPost({...body,amountMinor:40000})).status,400);
 assert.throws(()=>db.prepare('UPDATE seller_withdrawals SET amount_minor=1 WHERE id=?').run(id),/immutable/);
});
test('payout timeout stays reserved; no duplicate transfer; only matched provider result completes or fails',async()=>{
 user('owner');const w=db.prepare('SELECT * FROM seller_withdrawals').get();
 assert.equal((await adminPost({action:'withdrawal-review',id:w.id,status:'under_review'})).status,200);
 assert.equal((await adminPost({action:'withdrawal-process',id:w.id,confirm:true})).status,400);assert.equal(db.prepare('SELECT status FROM seller_withdrawals').get().status,'processing');
 assert.equal((await adminPost({action:'withdrawal-process',id:w.id,confirm:true})).status,400);assert.equal(transferCalls,1);
 transferStatus='FAILED';assert.equal((await adminPost({action:'withdrawal-reconcile',id:w.id})).status,200);assert.equal(db.prepare('SELECT status FROM seller_withdrawals').get().status,'failed');assert.equal((await finance.earningsSummary('store')).availableMinor,100000);
 user('seller');const id=crypto.randomUUID();payoutRef='cnc-payout-'+id;const bank=db.prepare('SELECT id FROM seller_banks').get().id;await sellerPost({action:'withdrawal-request',id,amountMinor:50000,bank});
 db.prepare("UPDATE seller_withdrawals SET status='processing' WHERE id=?").run(id);transferStatus='SUCCESSFUL';await finance.reconcileSellerTransfer(id);assert.equal((await finance.earningsSummary('store')).withdrawnMinor,50000);
});
test('refunds and unresolved cases freeze eligible credit; no duplicate release and no live-money paths',async()=>{
 db.exec("INSERT INTO refunds(id,payment,order_id,amount,reason,status,created,updated) VALUES('refund','payment','paidorder',1100,'Fixture dispute','requested','now','now')");
 assert.equal((await finance.earningsSummary('store')).availableMinor,0);assert.equal((await finance.earningsSummary('store')).deficitMinor,50000);
 user('seller');const bank=db.prepare('SELECT id FROM seller_banks').get().id;assert.equal((await sellerPost({action:'withdrawal-request',id:crypto.randomUUID(),bank,amountMinor:10000})).status,400);
 db.exec("UPDATE refunds SET status='completed'; UPDATE payments SET status='refunded' WHERE id='payment'; UPDATE orders SET payment_status='refunded' WHERE id='paidorder';");assert.equal((await finance.earningsSummary('store')).refundsMinor,110000);assert.equal((await finance.earningsSummary('store')).availableMinor,0);
 globalThis.testEnv.FLW_MODE='live';assert.equal((await sellerActivation('store')).canSell,false);
 assert.equal((await sellerPost({action:'subscription-checkout',id:crypto.randomUUID(),acceptTerms:true,autoRenewConsent:true,termsVersion:finance.SELLER_TERMS_VERSION})).status,400);
 assert.equal((await sellerPost({action:'withdrawal-request',id:crypto.randomUUID(),bank,amountMinor:10000})).status,400);
 globalThis.testEnv.FLW_MODE='test';globalThis.fetch=originalFetch;
});
test('partial refunds reduce net releases and concurrent withdrawal requests cannot overdraw',async()=>{
 const name='parallel';db.exec("INSERT INTO profiles(id,email,name,created,last_seen) VALUES('parallel','parallel@example.invalid','Parallel seller','now','now'); INSERT INTO stores(id,owner,name,category,location,phone,verified,created) VALUES('parallel','parallel','Parallel Shop','Tech','Lagos','08012345678',1,'now'); INSERT INTO seller_banks(id,store,mode,bank_code,bank_name,account_number,account_name,status,created,updated) VALUES('parallel-bank','parallel','test','044','Bank','0123456789','Parallel seller','verified','now','now'); INSERT INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,created,delivered_at) VALUES('parallel-order','buyer','parallel','Buyer','08012345678','Lagos',1100,'delivered','flutterwave','paid','2020','2020'); INSERT INTO payments(id,order_id,buyer,amount,currency,mode,status,expires,created,updated) VALUES('parallel-payment','parallel-order','buyer',1100,'NGN','test','paid','later','2020','2020'); INSERT INTO seller_earnings_releases(id,store,payment,mode,amount_minor,settlement_reference,evidence,actor,created) VALUES('parallel-release','parallel','parallel-payment','test',100000,'TEST-REF','simulated','owner','now'); INSERT INTO refunds(id,payment,order_id,amount,reason,status,created,updated) VALUES('parallel-refund','parallel-payment','parallel-order',100,'Partial refund fixture','completed','now','now');");
 assert.equal((await finance.earningsSummary(name)).availableMinor,90000);
 user(name);const requests=[1,2].map(()=>sellerPost({action:'withdrawal-request',id:crypto.randomUUID(),bank:'parallel-bank',amountMinor:70000}));
 const responses=await Promise.all(requests);assert.deepEqual(responses.map(r=>r.status).sort(),[200,400]);assert.equal((await finance.earningsSummary(name)).availableMinor,20000);
 const w=db.prepare("SELECT id FROM seller_withdrawals WHERE store='parallel'").get();assert.equal((await sellerPost({action:'withdrawal-cancel',id:w.id})).status,200);assert.equal((await finance.earningsSummary(name)).availableMinor,90000);
 assert.throws(()=>db.exec("UPDATE seller_earnings_releases SET amount_minor=999999 WHERE store='parallel'"),/append-only/);
});

