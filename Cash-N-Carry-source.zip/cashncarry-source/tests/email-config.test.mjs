import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import ts from 'typescript';
import { sourceModule } from './load-route.mjs';
let saved, auditCalls, sends;
const db = new DatabaseSync(':memory:');
for (const f of readdirSync('drizzle').filter(f => f.endsWith('.sql')).sort()) db.exec(readFileSync('drizzle/' + f, 'utf8'));
class Query {
  constructor(sql, args=[]) { this.sql=sql; this.args=args; }
  bind(...args) { return new Query(this.sql,args); }
  async all() { return {results:db.prepare(this.sql).all(...this.args)}; }
  async first() { return db.prepare(this.sql).get(...this.args) || null; }
  async run() { auditCalls ||= []; auditCalls.push(this.args); return db.prepare(this.sql).run(...this.args); }
}
globalThis.emailTestEnv = { REVIBE_ADMIN_EMAIL:'admin@example.invalid', BETTER_AUTH_SECRET:'private-auth-fixture', SITE_URL:'https://shop.test', STREAM_CONFIG_KEY:randomBytes(32).toString('base64'), DB:{prepare:sql=>new Query(sql)}, BUCKET:{ get:async()=>saved?{json:async()=>JSON.parse(saved)}:null, put:async(key,value)=>{assert.equal(key,'private/email-configuration'); saved=value;} } };
globalThis.emailTestUser=null;
const {GET,POST}=await import(sourceModule('app/api/admin/email/route.ts','emailTestEnv','emailTestUser'));
const {getEmailConfig}=await import(sourceModule('app/email-config.ts','emailTestEnv'));
const apiKey='re_private_fixture_token_123456789';
const body={apiKey,from:'sender@example.invalid',requestId:crypto.randomUUID(),confirm:'SEND TEST AND ENABLE'};
const request=(data=body,origin='https://shop.test')=>new Request('https://shop.test/api/admin/email',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(data)});
const admin=()=>{ globalThis.emailTestUser={userId:'admin',email:'admin@example.invalid'}; };
const resetLimit=()=>db.exec('DELETE FROM rate_limits');
const realFetch=globalThis.fetch;
globalThis.fetch=async(url,options)=>{ sends ||= []; sends.push({url,options}); return Response.json({id:'provider-fixture-id'}); };

test('email setup requires administrator, same origin, consent and valid private credentials',async()=>{
  assert.equal((await GET()).status,403);
  assert.equal((await POST(request())).status,403);
  globalThis.emailTestUser={userId:'seller',email:'seller@example.invalid'};
  assert.equal((await POST(request())).status,403);
  admin();
  assert.equal((await POST(request(body,'https://evil.test'))).status,403);
  for(const invalid of [{...body,confirm:''},{...body,apiKey:'bad'},{...body,from:'bad\n@example.invalid'},{...body,requestId:'bad'},{...body,from:'onboarding@resend.dev'}]) assert.equal((await POST(request(invalid))).status,400);
  assert.equal(sends,undefined); assert.equal(saved,undefined);
});
test('provider rejection and unconfirmed responses cannot enable email accounts',async()=>{
  admin(); resetLimit();
  const previous=globalThis.fetch;
  for(const [status,result] of [[403,{message:'private provider detail'}],[200,{}]]) {
    globalThis.fetch=async()=>Response.json(result,{status});
    const response=await POST(request()); assert.equal(response.status,400);
    assert.doesNotMatch(JSON.stringify(await response.json()),/private provider detail/);
    assert.equal(await getEmailConfig(),null);
  }
  globalThis.fetch=previous;
});
test('accepted setup sends only to authenticated admin, encrypts key and returns redacted status and audit',async()=>{
  admin(); resetLimit();
  const response=await POST(request()); assert.equal(response.status,200);
  const result=await response.json(); assert.equal(result.configured,true); assert.match(result.message,/acceptance does not confirm inbox delivery/);
  assert.doesNotMatch(saved,new RegExp(apiKey));
  assert.doesNotMatch(JSON.stringify(auditCalls),new RegExp(apiKey));
  const call=sends.at(-1); assert.equal(call.url,'https://api.resend.com/emails');
  const message=JSON.parse(call.options.body); assert.deepEqual(message.to,['admin@example.invalid']); assert.equal(message.from,body.from);
  assert.doesNotMatch(message.text,new RegExp(apiKey));
  assert.equal(call.options.headers['Idempotency-Key'],'email-setup-'+body.requestId);
  const config=await getEmailConfig(); assert.equal(config.apiKey,apiKey); assert.equal(config.from,body.from);
  const status=await (await GET()).json(); assert.equal(status.configured,true); assert.equal(status.from,body.from); assert.doesNotMatch(JSON.stringify(status),new RegExp(apiKey));
});
test('retry identity remains stable and rate limit prevents repeated test sending',async()=>{
  admin();resetLimit();
  for(let i=0;i<5;i++)assert.equal((await POST(request())).status,200);
  const before=sends.length; assert.equal((await POST(request())).status,429);assert.equal(sends.length,before);
  assert.equal(sends.at(-1).options.headers['Idempotency-Key'],'email-setup-'+body.requestId);
});
test('server-managed email configuration takes precedence and encrypted tampering fails safely',async()=>{
  globalThis.emailTestEnv.RESEND_API_KEY='existing-private-key';globalThis.emailTestEnv.EMAIL_FROM='existing@example.invalid';
  assert.equal((await getEmailConfig()).apiKey,'existing-private-key');assert.equal((await POST(request())).status,409);
  assert.equal((await (await GET()).json()).environmentManaged,true);
  delete globalThis.emailTestEnv.RESEND_API_KEY;delete globalThis.emailTestEnv.EMAIL_FROM;
  const untouched=saved;const corrupt=JSON.parse(saved);corrupt.cipher[0]^=1;saved=JSON.stringify(corrupt);
  await assert.rejects(()=>getEmailConfig());assert.equal((await GET()).status,503);saved=untouched;
  const key=globalThis.emailTestEnv.STREAM_CONFIG_KEY;delete globalThis.emailTestEnv.STREAM_CONFIG_KEY;
  assert.equal((await POST(request())).status,503);globalThis.emailTestEnv.STREAM_CONFIG_KEY=key;
});
test('email auth readiness and reset/verification callbacks use encrypted configuration without simulating sessions',async()=>{
  let source=readFileSync('app/auth.ts','utf8').replace(/import[\s\S]*?from\s*["'][^"']+["'];/g,'');
  source=`import {renderEmail,emailTemplates} from ${JSON.stringify(sourceModule('app/email-templates.ts','emailTestEnv'))}; import {emailReplyTo} from ${JSON.stringify(sourceModule('app/email-reply-to.ts','emailTestEnv'))}; import {queueTemplate,flushEmails,emailEventId} from ${JSON.stringify(sourceModule('app/notifications.ts','emailTestEnv'))}; import {getEmailConfig} from ${JSON.stringify(sourceModule('app/email-config.ts','emailTestEnv'))}; const env=globalThis.emailTestEnv; const MIN_PASSWORD_LENGTH=12; const brand={name:'Cash N Carry',logo:'/brand/logo.svg',tagline:'Watch Live. Discover. Shop.'}; const authUser={},authSession={},authAccount={},authVerification={},authTwoFactor={};const twoFactor=()=>({id:"two-factor"}); const getDb=()=>({}); const drizzleAdapter=()=>({}); const chatGptAdminMfa=()=>({id:"cash-n-carry-chatgpt-admin-mfa"});const betterAuth=config=>config;`+source;
  const url='data:text/javascript;base64,'+Buffer.from(ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2023}}).outputText).toString('base64');
  const {authAvailable,getAuth,sendEmail}=await import(url);
  globalThis.testSendEmail=sendEmail;
  const stored=saved; saved=undefined;
  assert.equal(await authAvailable(),false); await assert.rejects(()=>getAuth(),/not available/);
  saved=stored; assert.equal(await authAvailable(),true);
  const config=await getAuth();
  assert.deepEqual(config.baseURL.allowedHosts,['shop.test','revibe-commerce.ogundiyatemidayo1.chatgpt.site']);
  assert.equal(config.baseURL.fallback,'https://shop.test');
  assert.equal(config.baseURL.protocol,'https');
  assert.deepEqual(config.trustedOrigins,['https://shop.test','https://revibe-commerce.ogundiyatemidayo1.chatgpt.site']);
  assert.equal(config.emailAndPassword.requireEmailVerification,true); assert.equal(config.emailAndPassword.revokeSessionsOnPasswordReset,true); assert.equal(config.advanced.useSecureCookies,true);
  for(const callback of [config.emailAndPassword.sendResetPassword,config.emailVerification.sendVerificationEmail]) {
    await callback({user:{email:'customer@example.invalid'},url:'https://shop.test/verification-link'});
    const call=sends.at(-1); const message=JSON.parse(call.options.body);
    assert.equal(call.options.headers.Authorization,'Bearer '+apiKey); assert.deepEqual(message.to,['customer@example.invalid']); assert.equal(message.from,body.from);
  }
  const oldGet=globalThis.emailTestEnv.BUCKET.get;globalThis.emailTestEnv.BUCKET.get=async()=>{throw Error('private storage failure')};
  assert.equal(await authAvailable(),false);globalThis.emailTestEnv.BUCKET.get=oldGet;
});

test.after(()=>{globalThis.fetch=realFetch;db.close();});

test('provider failures explain actionable cause without exposing provider content or saving',async()=>{
 admin();delete globalThis.emailTestEnv.RESEND_API_KEY;delete globalThis.emailTestEnv.EMAIL_FROM;
 const previous=globalThis.fetch;
 try {
  for(const [status,message,expected] of [[401,'private credential rejected',/API key/],[403,'The example.invalid domain is not verified',/domain is not verified/],[429,'private account detail',/rate limit/]]){
   resetLimit(); const before=saved;
   globalThis.fetch=async()=>Response.json({message},{status});
   const response=await POST(request());const result=await response.json();
   assert.equal(response.status,400);assert.match(result.error,expected);assert.doesNotMatch(result.error,/private credential|private account/);assert.equal(saved,before);
  }
 }finally{globalThis.fetch=previous;}
});
