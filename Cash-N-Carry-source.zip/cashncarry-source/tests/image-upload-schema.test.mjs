import { DatabaseSync } from "node:sqlite";
import assert from "node:assert/strict";
import { sourceModule } from "./load-route.mjs";

const db = new DatabaseSync(":memory:");
db.exec("CREATE TABLE upload_usage(user TEXT NOT NULL,day TEXT NOT NULL,bytes INTEGER NOT NULL DEFAULT 0,count INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user,day))");
const today = new Date().toISOString().slice(0, 10);
db.prepare("INSERT INTO upload_usage(user,day,bytes,count) VALUES('seller',?,?,?)").run(today, 1234, 2);
class Query {
  constructor(sql, args = []) { this.sql = sql; this.args = args; }
  bind(...args) { return new Query(this.sql, args); }
  async first() { return db.prepare(this.sql).get(...this.args) || null; }
  async all() { return { results: db.prepare(this.sql).all(...this.args) }; }
  async run() { return db.prepare(this.sql).run(...this.args); }
}
globalThis.testEnv = { DB: { prepare: (sql) => new Query(sql) } };
const { ensureImageUploadSchema } = await import(sourceModule("app/image-upload-schema.ts"));
await ensureImageUploadSchema();
await ensureImageUploadSchema();
const columns = new Set(db.prepare("PRAGMA table_info(upload_usage)").all().map((column) => column.name));
for (const name of ["image_count", "image_bytes", "image_reserved_count", "image_reserved_bytes"]) assert(columns.has(name));
const usage = db.prepare("SELECT image_count,image_bytes FROM upload_usage WHERE user='seller'").get();
assert.equal(usage.image_count, 2);
assert.equal(usage.image_bytes, 1234);
assert.equal(db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='media_upload_requests'").get()?.name, "media_upload_requests");
assert.equal(db.prepare("SELECT name FROM sqlite_master WHERE type='index' AND name='media_upload_requests_owner_hash'").get()?.name, "media_upload_requests_owner_hash");
console.log("PASS: additive upload schema upgrade is idempotent, creates the request ledger and preserves today's legacy usage.");
