import {onboardFixtureSellers} from "./seller-fixture.mjs";
import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {sourceModule} from './load-route.mjs';
const db=new DatabaseSync(':memory:');
for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+f,'utf8'));
let writes=0;
class Q {constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Q(this.sql,args);}async first(){if(!/^\s*SELECT/i.test(this.sql))writes++;return db.prepare(this.sql).get(...this.args)||null;}async all(){return{results:db.prepare(this.sql).all(...this.args)};}async run(){writes++;return{meta:db.prepare(this.sql).run(...this.args)};}}
globalThis.testEnv={DB:{prepare:sql=>new Q(sql)}};globalThis.testUser=null;
globalThis.testEnv.DB.batch=async statements=>{db.exec('BEGIN');try{const results=[];for(const statement of statements)results.push(await statement.run());db.exec('COMMIT');return results;}catch(error){db.exec('ROLLBACK');throw error;}};
const api=await import(sourceModule('app/api/commerce/route.ts'));
const {runMaintenance}=await import(sourceModule('app/maintenance-runner.ts'));
const {secureResponse}=await import(sourceModule('app/response-security.ts'));
const {canAdmin}=await import(sourceModule('app/admin-permissions.ts'));
test('commerce public and signed-in GET never mutate setup, activity or stale streams',async()=>{
 db.exec("INSERT INTO stores(id,owner,name,category,location,created) VALUES('s','seller','Shop','Tech','Lagos','now'); INSERT INTO streams(id,store,title,url,status,provider,heartbeat,created) VALUES('stale','s','Test','','live','native','2020-01-01','now');");
 onboardFixtureSellers(db);
 const settingsBefore=db.prepare('SELECT COUNT(*) n FROM platform_settings').get().n;
 const before=writes;let r=await api.GET(new Request('https://shop.test/api/commerce?stream=stale'));assert.equal(r.status,200);assert.equal((await r.json()).stream.status,'ended');
 globalThis.testUser={userId:'new','email':'new@example.invalid',displayName:'New'};
 r=await api.GET(new Request('https://shop.test/api/commerce'));assert.equal(r.status,200);assert.equal((await r.json()).streams.length,0);
 assert.equal(writes,before);assert.equal(db.prepare("SELECT status FROM streams WHERE id='stale'").get().status,'live');assert.equal(db.prepare('SELECT COUNT(*) n FROM profiles').get().n,0);assert.equal(db.prepare('SELECT COUNT(*) n FROM platform_settings').get().n,settingsBefore);
});
test('maintenance rejects overlapping jobs and safely recovers an expired lease',async()=>{
 db.prepare("INSERT INTO platform_settings(key,value,updated) VALUES('maintenance_job_lease','active',?)").run(new Date().toISOString());
 const skipped=await runMaintenance();assert.equal(skipped.skipped,true);assert.equal(db.prepare("SELECT status FROM streams WHERE id='stale'").get().status,'live');
 db.prepare("UPDATE platform_settings SET updated='2020-01-01' WHERE key='maintenance_job_lease'").run();
 const done=await runMaintenance();assert.equal(done.email.configured,false);assert.equal(db.prepare("SELECT status FROM streams WHERE id='stale'").get().status,'ended');assert.equal(db.prepare("SELECT COUNT(*) n FROM platform_settings WHERE key='maintenance_job_lease'").get().n,0);assert(db.prepare("SELECT value FROM platform_settings WHERE key='last_maintenance_run'").get());
});
test('all staff permission boundaries reject privilege escalation',()=>{
 for(const role of ['admin','support','finance','moderator',null]){assert.equal(canAdmin(role,'roles'),false);assert.equal(canAdmin(role,'settings'),false);}
 assert.equal(canAdmin('owner','roles'),true);assert.equal(canAdmin('finance','refunds'),true);assert.equal(canAdmin('finance','verification'),false);assert.equal(canAdmin('support','payments'),false);assert.equal(canAdmin('moderator','orders'),false);assert.equal(canAdmin('admin','refunds'),false);
});
test('existing audit records cannot be updated or deleted',()=>{
 db.exec("INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES('a','owner','test@example.invalid','test','fixture','test','{}','{}','now')");
 assert.throws(()=>db.exec("UPDATE admin_audit SET reason='changed' WHERE id='a'"),/append-only/);assert.throws(()=>db.exec("DELETE FROM admin_audit WHERE id='a'"),/append-only/);assert.equal(db.prepare("SELECT reason FROM admin_audit WHERE id='a'").get().reason,'test');
});
test('security headers protect private pages without disabling same-origin camera or provider checkout',()=>{
 const r=secureResponse(new Response('ok'),new Request('https://shop.test/admin'));
 assert.equal(r.headers.get('X-Content-Type-Options'),'nosniff');assert.equal(r.headers.get('Strict-Transport-Security'),'max-age=31536000');assert.match(r.headers.get('Content-Security-Policy'),/frame-ancestors 'self'/);assert.match(r.headers.get('Content-Security-Policy'),/checkout.flutterwave.com/);assert.match(r.headers.get('Permissions-Policy'),/camera=\(self\)/);assert.equal(r.headers.get('X-Robots-Tag'),'noindex, nofollow');
 assert.equal(secureResponse(new Response('ok'),new Request('https://shop.test/product/1')).headers.get('X-Robots-Tag'),null);
});

test('robots and sitemap publish eligible public URLs and omit private accounts', async()=>{
 const robots=await import(sourceModule('app/robots.txt/route.ts'));const map=await import(sourceModule('app/sitemap.xml/route.ts'));
 const r=robots.GET();assert.equal(r.status,200);const rules=await r.text();assert.match(rules,/Disallow: \/admin/);assert.match(rules,/Sitemap: https:\/\/cashncarryng.com\/sitemap.xml/);
 db.exec("INSERT INTO products(id,store,name,description,category,price,stock,image,created) VALUES('p','s','Item','Actual description','Tech',1000,1,'/api/media/example','now')");
 let response=await map.GET();assert.equal(response.status,200);let xml=await response.text();assert.match(xml,/<loc>https:\/\/cashncarryng.com\/product\/p<\/loc>/);assert.match(xml,/<loc>https:\/\/cashncarryng.com\/live-auctions<\/loc>/);assert.doesNotMatch(xml,/\/admin|\/account|\/order\//);
 db.exec("UPDATE stores SET suspended=1 WHERE id='s'");xml=await (await map.GET()).text();assert.doesNotMatch(xml,/\/product\/p|\/store\/s/);
});
