import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
import * as React from "react";
import { renderToStaticMarkup } from "react-dom/server";
const moduleUrl = (src) =>
  "data:text/javascript;base64," +
  Buffer.from(
    ts.transpileModule(src, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2023,
        jsx: ts.JsxEmit.React,
      },
    }).outputText,
  ).toString("base64");
globalThis.entryReact = React;
let form = fs
  .readFileSync("app/account/auth-form.tsx", "utf8")
  .replace(/import[\s\S]*?from\s*["'][^"']+["'];/g, "");
form =
  `const React=globalThis.entryReact;const {useEffect,useRef,useState}=React;const Link=({children,...props})=>React.createElement("a",props,children);const MIN_PASSWORD_LENGTH=12;const safeReturnPath=x=>x;const ArrowLeft=()=>null,Eye=()=>null,EyeOff=()=>null,BrandLogo=()=>null,Sessions=()=>null;` +
  form;
const { default: AuthForm } = await import(moduleUrl(form));
test("unavailable email integration hides forms and registration/recovery links", () => {
  for (const initialMode of ["sign-in", "sign-up", "reset", "password"]) {
    const html = renderToStaticMarkup(
      React.createElement(AuthForm, { available: false, initialMode }),
    );
    assert.doesNotMatch(
      html,
      /<form|type="password"|href="\/sign-up|href="\/forgot-password/,
    );
    assert.match(html, /Continue with ChatGPT/);
    assert.match(html, /Browse without an account/);
  }
});
test("configured email integration retains real sign-in and recovery form", () => {
  const html = renderToStaticMarkup(
    React.createElement(AuthForm, { available: true }),
  );
  assert.match(html, /<form/);
  assert.match(html, /name="email"/);
  assert.match(html, /name="password"/);
  assert.match(html, /Forgot password/);
});
const { policyDefinitions, policyBlockers, policyBlockerMatches, publicPolicyLinks } = await import(
  moduleUrl(
    fs.readFileSync("app/policy-drafts.ts", "utf8"),
  )
);
test("six source-document policies remain drafts with blockers and private routes", () => {
  assert.deepEqual(Object.keys(policyDefinitions), ["privacy", "terms", "delivery", "refunds", "seller-terms", "community-guidelines"]);
  assert.equal(publicPolicyLinks.length, 6);
  for (const [id, policy] of Object.entries(policyDefinitions)) {
    assert.equal(policy.path, `/${id === "seller-terms" ? "seller-terms" : id === "community-guidelines" ? "community-guidelines" : id}`);
    assert.match(policy.content, /^Effective date:/);
    assert.ok(policyBlockers(policy.content).length > 0, `${id} must require review before approval`);
    assert.doesNotMatch(policy.content, /\d+\s+\w+\s+(Street|Road|Avenue|Close|Crescent)/i);
  }
});
test("completed bracketed dates are not mistaken for unresolved placeholders", () => {
  assert.deepEqual(policyBlockers("Effective date: [10/10/2026]\n\n1. Resolved policy\nThis test fixture contains settled and verified policy text."), []);
  assert.ok(policyBlockers("Effective date: [DATE OF OWNER APPROVAL — NOT YET SET]\n\n1. Policy\nThis fixture contains unresolved terms.").length > 0);
  assert.ok(policyBlockers("Effective date: [10/10/3036]\n\n1. Policy\nThis fixture contains a date outside the accepted policy range.").some((reason) => reason.includes("Correct invalid bracketed dates")));
});
test("policy blocker report identifies the exact unresolved phrases", () => {
  const findings = policyBlockerMatches("Effective date: 10/10/2026\n[CONFIRM RECORDING PRACTICE]\nPROPOSED RETENTION PERIOD (NOT VERIFIED)");
  assert.ok(findings.some((finding) => finding.matches.includes("[CONFIRM RECORDING PRACTICE]")));
  assert.ok(findings.some((finding) => finding.matches.includes("PROPOSED")));
  assert.ok(findings.some((finding) => finding.matches.includes("NOT VERIFIED")));
});
const { broadcastLabel, scheduleText, broadcastSummary } = await import(
  moduleUrl(fs.readFileSync("app/broadcasts.ts", "utf8"))
);
test("schedules include timezone, past schedules await seller and summaries omit zero groups", () => {
  assert.match(scheduleText("2026-10-09T12:00:00Z"), /WAT, UTC\+1/);
  assert.equal(
    broadcastLabel({ status: "scheduled", scheduled: "2020-01-01T00:00:00Z" }),
    "AWAITING SELLER",
  );
  assert.equal(broadcastSummary([{ status: "live" }]), "1 live now");
  assert.equal(broadcastSummary([]), "");
  assert.equal(
    broadcastSummary([
      { status: "scheduled", scheduled: "2020-01-01T00:00:00Z" },
    ]),
    "1 awaiting seller",
  );
});

let pendingSource = fs
  .readFileSync("app/cart-resume.ts", "utf8")
  .replace(/import[^;]+;/, fs.readFileSync("app/auth-navigation.ts", "utf8"));
const { readCartIntent } = await import(
  moduleUrl(pendingSource)
);
test("temporary cart intent retains exact selection and discards expired or invalid drafts", () => {
  let value = JSON.stringify({
    id: crypto.randomUUID(),
    product: "p",
    variant: "Black",
    quantity: 2,
    created: Date.now(),
    returnTo: "/product/p",
  });
  const storage = { getItem: () => value, removeItem: () => (value = null) };
  assert.equal(readCartIntent(storage).variant, "Black");
  assert.equal(readCartIntent(storage).quantity, 2);
  assert.equal(readCartIntent(storage).returnTo, "/product/p");
  const p = JSON.parse(value);
  value = JSON.stringify({ ...p, created: Date.now() - 3600001 });
  assert.equal(readCartIntent(storage), null);
  assert.equal(value, null);
  value = JSON.stringify({ ...p, quantity: 100 });
  assert.equal(readCartIntent(storage), null);
  value = JSON.stringify({ ...p, returnTo: "https://evil.example" });
  assert.equal(readCartIntent(storage).returnTo, "/#market");
});

test("signup confirms passwords and recovery avoids unrelated account creation links", () => {
  const signup=renderToStaticMarkup(React.createElement(AuthForm,{available:true,initialMode:"sign-up"}));
  assert.match(signup,/name="confirmPassword"/);
  assert.match(signup,/name="terms"/);
  for(const initialMode of ["reset","password"]){
    const html=renderToStaticMarkup(React.createElement(AuthForm,{available:true,initialMode}));
    assert.match(html,/Back to sign in/);
    assert.doesNotMatch(html,/New to Cash N Carry/);
  }
  const login=renderToStaticMarkup(React.createElement(AuthForm,{available:true}));
  assert.doesNotMatch(login,/name="confirmPassword"/);
});
