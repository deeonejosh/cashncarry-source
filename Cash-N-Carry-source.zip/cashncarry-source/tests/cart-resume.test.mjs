import {onboardFixtureSellers} from "./seller-fixture.mjs";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import assert from "node:assert/strict";
const sqlite = new DatabaseSync(":memory:");
for (const f of readdirSync("drizzle")
  .filter((f) => f.endsWith(".sql"))
  .sort())
  sqlite.exec(readFileSync("drizzle/" + f, "utf8"));
class Query {
  constructor(sql, args = []) {
    this.sql = sql;
    this.args = args;
  }
  bind(...args) {
    return new Query(this.sql, args);
  }
  async all() {
    return { results: sqlite.prepare(this.sql).all(...this.args) };
  }
  async first() {
    return sqlite.prepare(this.sql).get(...this.args) || null;
  }
  async run() {
    return sqlite.prepare(this.sql).run(...this.args);
  }
}
globalThis.testEnv = {
  DB: {
    prepare: (s) => new Query(s),
    batch: async (stmts) => {
      sqlite.exec("BEGIN");
      try {
        const results = [];
        for (const s of stmts) results.push(await s.run());
        sqlite.exec("COMMIT");
        return results;
      } catch (e) {
        sqlite.exec("ROLLBACK");
        throw e;
      }
    },
  },
};
globalThis.testUser = null;
const { sourceModule } = await import("./load-route.mjs");
const api = await import(sourceModule("app/api/commerce/route.ts"));
const user = (id) =>
  (globalThis.testUser = id
    ? { userId: id, email: id + "@test.invalid", displayName: id, fullName: id }
    : null);
const post = async (b, expect = 200, origin = "https://revibe.test") => {
  const r = await api.POST(
    new Request("https://revibe.test/api/commerce", {
      method: "POST",
      headers: { origin, "Content-Type": "application/json" },
      body: JSON.stringify(b),
    }),
  );
  const d = await r.json();
  assert.equal(r.status, expect, JSON.stringify(d));
  return d;
};
const state = async () =>
  await (await api.GET(new Request("https://revibe.test/api/commerce"))).json();

user("seller");
await post({
  action: "store",
  name: "Resume Store",
  location: "Lagos",
  phone: "08012345678",
  category: "Tech",
});
onboardFixtureSellers(sqlite);
await post({
  action: "product",
  name: "Resume Product",
  description: "Resume test",
  category: "Tech",
  price: 1000,
  stock: 5,
  image: "https://example.com/p.jpg",
  variants: JSON.stringify([
    { name: "Black", price: 1200, stock: 5 },
    { name: "Sold out", price: 1000, stock: 0 },
  ]),
});
let data = await state();
const p = data.products[0];
const intent = {
  action: "cart_resume",
  request_id: crypto.randomUUID(),
  product: p.id,
  variant: "Black",
  quantity: 2,
};
user(null);
await post(intent, 401);
user("buyer");
await post(intent);
await post(intent);
data = await state();
assert.equal(data.cart[0].quantity, 2);
assert.equal(data.cart[0].variant, "Black");
assert.equal(data.cart[0].price, 1200);
// An uncertain response / retry after subsequent cart editing must not overwrite it.
await post({ action: "cart", product: p.id, variant: "Black", quantity: 3 });
await post(intent);
assert.equal((await state()).cart[0].quantity, 3);
await post({ ...intent, quantity: 1 }, 400);
await post({ ...intent, request_id: crypto.randomUUID(), quantity: 3 }, 400);
assert.equal((await state()).cart[0].quantity, 3);
await post(
  {
    ...intent,
    request_id: crypto.randomUUID(),
    variant: "Sold out",
    quantity: 1,
  },
  400,
);
await post(
  {
    ...intent,
    request_id: crypto.randomUUID(),
    variant: "Invalid",
    quantity: 1,
  },
  400,
);
// Two submissions can both read no receipt before serial atomic batches run.
let batchTail = Promise.resolve();
const serialBatch = globalThis.testEnv.DB.batch;
globalThis.testEnv.DB.batch = (stmts) => {
  const result = batchTail.then(() => serialBatch(stmts));
  batchTail = result.catch(() => {});
  return result;
};
const concurrent = { ...intent, request_id: crypto.randomUUID(), quantity: 1 };
await Promise.all([post(concurrent), post(concurrent)]);
assert.equal((await state()).cart[0].quantity, 4);
user("outsider");
await post(intent, 400);
assert.equal((await state()).cart.length, 0);
user("buyer");
sqlite
  .prepare("UPDATE products SET stock=0,variants='[]' WHERE id=?")
  .run(p.id);
await post(
  { ...intent, request_id: crypto.randomUUID(), variant: "", quantity: 1 },
  400,
);
console.log(
  "PASS: cart resumption preserves option/quantity, checks stock, enforces account isolation and prevents duplicate or concurrent replay.",
);
// Expired schedules leave public discovery but remain in seller history.
user("seller");
const sellerStore = (await state()).myStore.id;
sqlite
  .prepare(
    "INSERT INTO streams(id,store,title,url,status,provider,scheduled,created) VALUES('expired',?,'Expired schedule','','scheduled','native',?,?)",
  )
  .run(
    sellerStore,
    new Date(Date.now() - 2 * 86400000).toISOString(),
    new Date().toISOString(),
  );
const schedules = await state();
assert(!schedules.streams.some((s) => s.id === "expired"));
assert(schedules.myStreams.some((s) => s.id === "expired"));
console.log(
  "PASS: expired schedules excluded from discovery and retained in seller history.",
);

// Public identity contains email, not id: authentication must retrigger the pending-cart effect.
const cartUI=readFileSync('app/revibe.tsx','utf8');
assert.match(cartUI,/\[loading, data\.user\?\.email, resumeRetry\]/);
