import test from 'node:test';
import assert from 'node:assert/strict';
import ts from 'typescript';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
function fixture({user={id:'auth-1',email:'admin@test.invalid',emailVerified:true,twoFactorEnabled:true},factor={verified:true},role='owner',identity=true,origin='https://cashncarryng.com',suspended=0}={}) {
  const records=[],cookies=[];
  const ctx={context:{secret:'test-only',internalAdapter:{findUserByEmail:async()=>({user}),createVerificationValue:async x=>records.push(x)},adapter:{findOne:async()=>factor},createAuthCookie:(name,attributes)=>({name,attributes})},setSignedCookie:async(...x)=>cookies.push(x),json:x=>x};
  const sandbox={exports:{},crypto:{randomUUID:()=> 'random-challenge'},URL,Date,headers:async()=>new Headers({'origin':origin,...(identity?{'oai-authenticated-user-id':'site-1','oai-authenticated-user-email':'admin@test.invalid'}:{})}),getChatGPTUser:async()=>({userId:'site-1',email:'admin@test.invalid'}),assignedAdminRole:async()=>role,limit:async()=>{},env:{SITE_URL:'https://cashncarryng.com',DB:{prepare:()=>({bind:()=>({first:async()=>({suspended})})})}},createAuthEndpoint:(path,opts,handler)=>handler,APIError:{from:(status,data)=>Object.assign(new Error(data.message),{status})}};
  const src=readFileSync('app/chatgpt-mfa-challenge.ts','utf8').replace(/^import .*;\n/gm,'');
  vm.runInNewContext(ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,sandbox);
  return {ctx,records,cookies,endpoint:sandbox.exports.chatGptAdminMfa().endpoints.chatGptAdminChallenge};
}
test('ChatGPT admin receives only a signed, expiring pending challenge and attempt budget',async()=>{
  const f=fixture();await f.endpoint(f.ctx);assert.equal(f.records.length,2);assert.equal(f.records[0].value,'auth-1');assert.equal(f.records[1].value,'0');assert.equal(f.records[1].identifier,'2fa-attempts-'+f.records[0].identifier);assert.equal(f.cookies[0][0],'two_factor');assert.equal(f.cookies[0][3].maxAge,600);assert(f.records[0].expiresAt>Date.now());
});
test('bridge rejects missing trusted identity, missing admin role, suspension and foreign origin without issuing a challenge',async()=>{
  for(const options of [{identity:false},{role:null},{suspended:1},{origin:'https://evil.invalid'}]){const f=fixture(options);await assert.rejects(f.endpoint(f.ctx));assert.equal(f.records.length,0);assert.equal(f.cookies.length,0);}
});
test('bridge refuses absent or incomplete MFA and never creates accounts or sessions',async()=>{
  for(const options of [{user:null},{user:{id:'x',email:'admin@test.invalid',emailVerified:false,twoFactorEnabled:true}},{user:{id:'x',email:'admin@test.invalid',emailVerified:true,twoFactorEnabled:false}},{factor:null},{factor:{verified:false}}]){const f=fixture(options);await assert.rejects(f.endpoint(f.ctx),/authenticator/);assert.equal(f.records.length,0);assert.equal(f.cookies.length,0);}
});
