import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import * as React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
globalThis.noticeReact=React;
const src=fs.readFileSync('app/notification-panel.tsx','utf8').replace(/import[^;]+;/g,'');
const js=ts.transpileModule('const React=globalThis.noticeReact;const {useState}=React;const Bell=()=>null,CheckCheck=()=>null;'+src,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2023,jsx:ts.JsxEmit.React}}).outputText;
const {default:Panel}=await import('data:text/javascript;base64,'+Buffer.from(js).toString('base64'));
test('panel renders stored notices safely with unread status and filters',()=>{
 const html=renderToStaticMarkup(React.createElement(Panel,{items:[{id:'one',title:'<unsafe>',body:'Stored order update',created:'2026-10-10T10:00:00Z',read:0}],busy:false,markRead:async()=>{}}));
 assert.match(html,/&lt;unsafe&gt;/);assert.match(html,/Stored order update/);assert.match(html,/is-unread/);assert.match(html,/aria-pressed="true"/);assert.match(html,/Mark all read/);assert.match(html,/<time dateTime=/);
});
test('empty panel explains updates and disables unnecessary mark-read action',()=>{
 const html=renderToStaticMarkup(React.createElement(Panel,{items:[],busy:false,markRead:async()=>{}}));assert.match(html,/No notifications yet/);assert.match(html,/disabled=""/);
});
test('notification list has one homepage bell entry and no account/workspace copies',()=>{
 const home=fs.readFileSync('app/revibe.tsx','utf8');assert.match(home,/view === "Home" && <button[\s\S]*?setModal\(\{type: "notifications"\}\)/);
 assert.doesNotMatch(fs.readFileSync('app/account/hub.tsx','utf8'),/tab=Notifications/);
 assert.doesNotMatch(fs.readFileSync('app/workspace/page.tsx','utf8'),/d\.notifications\.map/);
 assert.match(home,/focusable\(\)\[0\]\?\.focus/);assert.match(home,/e.key === "Escape"/);
});
