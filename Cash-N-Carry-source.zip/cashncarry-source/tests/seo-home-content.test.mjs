import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import React from 'react';
import * as icons from 'lucide-react';
import {renderToStaticMarkup} from 'react-dom/server';
function module(file,globals={}){const exports={};const source=readFileSync(file,'utf8').replace(/import[\s\S]*?from\s*["'][^"']+["'];/g,'').replace(/import\s*["'][^"']+["'];/g,'');vm.runInNewContext(ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.React,target:ts.ScriptTarget.ES2023}}).outputText,{exports,React,URL,...icons,...globals});return exports;}
const {brand}=module('app/brand.ts');
test('homepage shopping guidance is server-rendered with accessible native disclosures',()=>{const Link=({href,children,...props})=>React.createElement('a',{href,...props},children);const {ShoppingGuide}=module('app/shopping-design.tsx',{Link});const html=renderToStaticMarkup(React.createElement(ShoppingGuide,{onShop:()=>{},onLive:()=>{}}));assert.equal((html.match(/<details>/g)||[]).length,3);assert.equal((html.match(/<summary>/g)||[]).length,3);assert.match(html,/not a guarantee of a particular product or transaction/);assert.match(html,/href="\/help"/);assert.match(html,/href="\/refunds"/);assert.doesNotMatch(html,/guaranteed delivery|guaranteed refunds|free delivery/i);});
test('organization and website identities agree without invented physical locations',()=>{const {default:Layout}=module('app/layout.tsx',{env:{SITE_URL:'https://cashncarryng.com'},brand,SkipLink:()=>React.createElement('a',{href:'#main-content'},'Skip to main content'),AnalyticsConsent:()=>null});const html=renderToStaticMarkup(React.createElement(Layout,React.createElement('main',{id:'main-content',tabIndex:-1})));const json=JSON.parse(html.match(/<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/)[1]);const org=json['@graph'].find(x=>x['@type']==='Organization'),site=json['@graph'].find(x=>x['@type']==='WebSite');assert.equal(site.publisher['@id'],org['@id']);assert.equal(org.contactPoint.url,'https://cashncarryng.com/help');assert.equal(org.name,brand.name);assert.equal(org.address,undefined);assert.equal(org.geo,undefined);assert.equal(org.sameAs,undefined);assert(html.indexOf('href="#main-content"')<html.indexOf('application/ld+json'));});
