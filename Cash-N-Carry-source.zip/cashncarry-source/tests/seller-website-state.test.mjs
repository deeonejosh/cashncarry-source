import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import ts from "typescript";
import * as React from "react";
import { renderToStaticMarkup } from "react-dom/server";

const source = readFileSync("app/seller/website/builder.tsx", "utf8")
  .replace(/^import .*;?\s*$/gm, "")
  .replace("export default function StoreBuilder", "function StoreBuilder");
const compiled = ts.transpileModule(
  `const React=globalThis.websiteTest.React; const {useEffect,useState}=globalThis.websiteTest; const SellerNavigation=()=>null; const ImageAsset=()=>null;\n${source}\nexport default StoreBuilder;`,
  { compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2023, jsx: ts.JsxEmit.React } },
).outputText;
const moduleUrl = "data:text/javascript;base64," + Buffer.from(compiled).toString("base64");
globalThis.websiteTest = { React, useEffect() {}, useState(value) { return [value, () => {}]; } };
const { default: StoreBuilder } = await import(moduleUrl);

test("suspended seller with an existing store sees management status, not store creation", () => {
  const html = renderToStaticMarkup(React.createElement(StoreBuilder, { hasStore: false, suspended: true }));
  assert.match(html, /<h1>Manage My Store<\/h1>/);
  assert.match(html, /existing Cash N Carry store is suspended/);
  assert.match(html, /View seller status/);
  assert.doesNotMatch(html, /Create Your Free Store/);
});
