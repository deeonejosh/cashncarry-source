import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { sourceModule } from "./load-route.mjs";
globalThis.testEnv = {
  FLW_MODE: "test",
  FLW_SECRET_KEY: "FLWSECK_TEST-fixture",
  FLW_WEBHOOK_HASH: "fixture",
  SITE_URL: "https://shop.test",
};
const payment = await import(sourceModule("app/payments.ts"));
assert.equal(payment.paymentsAvailable(), true);
globalThis.testEnv.FLW_MODE = "live";
assert.equal(payment.paymentsAvailable(), false);
globalThis.testEnv.FLW_SECRET_KEY = "FLWSECK-live-fixture";
assert.equal(payment.paymentsAvailable(), false);
globalThis.testEnv.FLW_LIVE_APPROVED = "true";
assert.equal(payment.paymentsAvailable(), false);
globalThis.testEnv.FLW_MERCHANT_ACCOUNT_ID = "123";
assert.equal(payment.paymentsAvailable(), true);
globalThis.testEnv.SITE_URL = "http://shop.test";
assert.equal(payment.paymentsAvailable(), false);
globalThis.testEnv.SITE_URL = "https://shop.test";
const originalFetch = globalThis.fetch;
let calls = 0;
globalThis.fetch = async () => {
  calls++;
  return Response.json({ status: "success", data: {} });
};
await assert.rejects(
  () => payment.flutterwave("transactions/1/verify", undefined, "test"),
  /not configured/,
);
assert.equal(calls, 0);
globalThis.testEnv.FLW_TEST_SECRET_KEY = "FLWSECK_TEST-historical";
await payment.flutterwave("transactions/1/verify", undefined, "test");
assert.equal(calls, 1);
const webhook = await import(sourceModule("app/api/payments/webhook/route.ts"));
const raw = JSON.stringify({ event: "irrelevant" });
const signature = createHmac("sha256", "fixture").update(raw).digest("base64");
const request = (body, headers) =>
  new Request("https://shop.test/api/payments/webhook", {
    method: "POST",
    headers,
    body,
  });
assert.equal((await webhook.POST(request(raw, {}))).status, 401);
assert.equal(
  (await webhook.POST(request(raw, { "flutterwave-signature": signature })))
    .status,
  200,
);
assert.equal(
  (
    await webhook.POST(
      request(raw + " ", { "flutterwave-signature": signature }),
    )
  ).status,
  401,
);
assert.equal(
  (
    await webhook.POST(
      request(raw, { "flutterwave-signature": "bad", "verif-hash": "fixture" }),
    )
  ).status,
  401,
);
assert.equal(
  (await webhook.POST(request(raw, { "verif-hash": "fixture" }))).status,
  200,
);
// Signed merchant events from another integration are acknowledged without
// contacting the provider, including UUID transaction IDs from v4.
let knownReference = false;
globalThis.testEnv.DB = {
  prepare: (sql) => ({ bind: () => ({ first: async () => sql.includes("seller_subscription_payments") ? null : knownReference ? { id: "shop-reference", mode: "test" } : null }) }),
};
const charge = JSON.stringify({ event: "charge.completed", data: {
  id: "external-uuid", tx_ref: "external-reference", status: "successful",
} });
const beforeUnrelated = calls;
assert.equal((await webhook.POST(request(charge, { "verif-hash": "fixture" }))).status, 200);
assert.equal(calls, beforeUnrelated);
assert.equal((await webhook.POST(request(charge, {}))).status, 401);
// An event for our reference must still reach verification and fail safely
// when its transaction ID is invalid; it cannot mark an order paid.
knownReference = true;
assert.equal((await webhook.POST(request(charge, { "verif-hash": "fixture" }))).status, 503);
const numericCharge = JSON.stringify({ event: "charge.completed", data: {
  id: 123, tx_ref: "shop-reference", status: "successful",
} });
globalThis.fetch = async () => { calls++; throw Error("Provider unavailable"); };
assert.equal((await webhook.POST(request(numericCharge, { "verif-hash": "fixture" }))).status, 503);
assert.equal(calls, beforeUnrelated + 1);
globalThis.fetch = originalFetch;
console.log(
  "Live readiness gates, historical credential isolation, HMAC tampering and v3 webhook authentication passed",
);
