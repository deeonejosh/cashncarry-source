import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "typescript";
const js = ts.transpileModule(
  fs.readFileSync("app/delivery-quote.ts", "utf8"),
  {
    compilerOptions: {
      module: ts.ModuleKind.ESNext,
      target: ts.ScriptTarget.ES2022,
    },
  },
).outputText;
const { deliveryQuote, deliveryFee } = await import(
  "data:text/javascript;base64," + Buffer.from(js).toString("base64")
);
for (const store of [
  null,
  {},
  { coverage: "[]", delivery_fee: 0 },
  { coverage: '["Lagos"]' },
  { coverage: "broken", delivery_fee: 0 },
  { coverage: '["Lagos"]', delivery_fee: -1 },
])
  assert.equal(deliveryQuote(store), undefined);
assert.equal(deliveryQuote({ coverage: '["Lagos"]', delivery_fee: 0 }), 0);
assert.equal(
  deliveryQuote({ coverage: '["Lagos"]', delivery_fee: 1500 }),
  1500,
);

assert.equal(deliveryFee({ coverage: "[]", delivery_fee: 100 }),100);
assert.equal(deliveryFee({delivery_fee:0}),0);
assert.equal(deliveryFee({}),undefined);
assert.equal(deliveryFee({delivery_fee:-1}),undefined);
