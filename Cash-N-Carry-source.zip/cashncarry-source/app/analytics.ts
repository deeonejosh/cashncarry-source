"use client";
import { ANALYTICS_CONSENT_KEY } from "./analytics-consent-key";
const VISITOR_KEY="cnc:analytics-visitor:v1";
export function trackAnalyticsEvent(event:string,store:string,details:{product?:string;stream?:string}={}){
 if(typeof window==="undefined"||!store)return;
 try{if(window.localStorage.getItem(ANALYTICS_CONSENT_KEY)!=="accepted")return;let visitor=window.localStorage.getItem(VISITOR_KEY);if(!visitor){visitor=crypto.randomUUID();window.localStorage.setItem(VISITOR_KEY,visitor);}void fetch("/api/seller-analytics",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({event,store,visitorId:visitor,...details}),keepalive:true}).catch(()=>{});}catch{/* Analytics never blocks shopping when storage is unavailable. */}
}
