import Link from "next/link";
import { ArrowLeft, Share2 } from "lucide-react";
import { brand } from "../brand";
import { CustomerHeader, CustomerNavigation } from "../customer-shell";

export const metadata = {
  title: "Social media — " + brand.name,
  description: "Find Cash N Carry's official social media pages.",
};

export default function SocialPage() {
  return <>
    <CustomerHeader />
    <main id="main-content" tabIndex={-1} className="customer-page social-coming-soon">
      <Link className="social-back-link" href="/?browse=1#home"><ArrowLeft size={17}/> Back to Cash N Carry</Link>
      <section className="social-coming-card" aria-labelledby="social-title">
        <span className="social-coming-icon" aria-hidden="true"><Share2 size={28}/></span>
        <p className="eyebrow">STAY CONNECTED</p>
        <h1 id="social-title">Our social pages are coming soon.</h1>
        <p>We’re getting Cash N Carry’s official social media pages ready. When they’re live, you’ll find the verified links here.</p>
        <Link className="primary" href="/?browse=1#home">Continue shopping</Link>
      </section>
    </main>
    <CustomerNavigation />
  </>;
}
