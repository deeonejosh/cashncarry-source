import {
  orderEmail,
  refundEmail,
  adminEmail,
  safelyEmail,
} from "./email-events";
import { paymentCheckoutUrl } from "./payment-checkout-url";
import { brand } from "./brand";
import { env } from "cloudflare:workers";
const q = (s: string, ...a: any[]) => env.DB!.prepare(s).bind(...a);
export function paymentMode(): "test" | "live" {
  return env.FLW_MODE === "live" ? "live" : "test";
}
function paymentKey(mode: string) {
  if (!["test", "live"].includes(mode)) return undefined;
  const key =
    mode === paymentMode()
      ? env.FLW_SECRET_KEY
      : mode === "test"
        ? env.FLW_TEST_SECRET_KEY
        : undefined;
  if (
    !key ||
    (mode === "test"
      ? !key.startsWith("FLWSECK_TEST")
      : !key.startsWith("FLWSECK-") || key.startsWith("FLWSECK_TEST"))
  )
    return undefined;
  return key;
}
export function paymentReadiness() {
  const mode = paymentMode();
  const blockers: string[] = [];
  if (env.FLW_MODE && !["test", "live"].includes(env.FLW_MODE))
    blockers.push("Invalid payment mode configuration");
  if (!paymentKey(mode))
    blockers.push("Matching server-side payment credentials are missing");
  if (!env.FLW_WEBHOOK_HASH) blockers.push("Webhook secret is missing");
  try {
    const url = new URL(env.SITE_URL || "");
    if (
      url.protocol !== "https:" ||
      url.username ||
      url.password ||
      url.pathname !== "/" ||
      url.search ||
      url.hash
    )
      throw Error();
  } catch {
    blockers.push("A valid HTTPS site origin is required");
  }
  if (mode === "live" && !/^\d+$/.test(env.FLW_MERCHANT_ACCOUNT_ID || ""))
    blockers.push("Verified live merchant account ID is missing");
  if (mode === "live" && env.FLW_LIVE_APPROVED !== "true")
    blockers.push(
      "Live NGN merchant approval and webhook configuration have not been confirmed",
    );
  return { mode, online: blockers.length === 0, blockers };
}
export function paymentsAvailable() {
  return paymentReadiness().online;
}
class TransactionNotFound extends Error {}
export async function flutterwave(
  path: string,
  body?: any,
  mode: string = paymentMode(),
  method: "GET" | "POST" | "PUT" | "DELETE" = body ? "POST" : "GET",
) {
  const key = paymentKey(mode);
  if (
    !key ||
    !env.SITE_URL ||
    !env.FLW_WEBHOOK_HASH ||
    (mode === "live" && (env.FLW_LIVE_APPROVED !== "true" || !/^\d+$/.test(env.FLW_MERCHANT_ACCOUNT_ID || "")))
  )
    throw Error("Payments are not configured for this transaction mode");
  let r: Response;
  let d: any;
  try {
    r = await fetch("https://api.flutterwave.com/v3/" + path, {
      signal: AbortSignal.timeout(15000),
      method,
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    d = await r.json();
  } catch {
    throw Error("Payment provider is unavailable. Your order remains pending.");
  }
  if (!r.ok || d.status !== "success") {
    // Do not expose provider bodies, checkout tokens or customer details in logs.
    const missing =
      r.status === 400 &&
      path.startsWith("transactions/verify_by_reference?") &&
      d.message === "No transaction was found for this id";
    console.warn("payment_provider_rejected", {
      operation: path.split("?")[0],
      status: r.status,
      reason: missing ? "transaction_not_found" : "request_rejected",
    });
    if (missing)
      throw new TransactionNotFound(
        "Flutterwave has not recorded a payment attempt yet. Your order is still pending. Continue payment from My orders, or contact support if you need to cancel.",
      );
    if (r.status >= 500 || r.status === 429)
      throw Error(
        "Payment provider is unavailable. Your order remains pending.",
      );
    throw Error(
      "Flutterwave could not confirm this request. Your order remains pending. Please contact support if this continues.",
    );
  }
  return d.data;
}
export async function initiatePayment(order: any, email: string) {
  const existing: any = await q(
    "SELECT * FROM payments WHERE order_id=?",
    order.id,
  ).first();
  if (existing && existing.status !== "pending")
    throw Error("Payment is already settled or requires reconciliation");
  if (existing && Date.parse(existing.expires) <= Date.now())
    throw Error(
      "This payment session has expired. Check your order status or contact support; stock is being reconciled.",
    );
  if (existing?.link) return existing.link;
  let pid = existing?.id || crypto.randomUUID();
  const now = new Date().toISOString();
  await q(
    "INSERT INTO payments(id,order_id,buyer,amount,currency,mode,status,expires,created,updated) VALUES(?,?,?,?,'NGN',?,'pending',?,?,?) ON CONFLICT(order_id) DO NOTHING",
    pid,
    order.id,
    order.buyer,
    order.total,
    paymentMode(),
    new Date(Date.now() + 30 * 60 * 1000).toISOString(),
    now,
    now,
  ).run();
  const persisted: any = await q(
    "SELECT * FROM payments WHERE order_id=?",
    order.id,
  ).first();
  pid = persisted.id;
  if (persisted.link) return persisted.link;
  const data = await flutterwave(
    "payments",
    {
      tx_ref: pid,
      amount: order.total,
      currency: "NGN",
      redirect_url: new URL("/payment-return", env.SITE_URL).href,
      customer: { email, name: order.name, phonenumber: order.phone },
      customizations: {
        title:
          brand.name + (persisted.mode === "test" ? " — TEST PAYMENT" : ""),
      },
      configuration: { session_duration: 30, max_retry_attempt: 3 },
    },
    persisted.mode,
  );
  const url = new URL(paymentCheckoutUrl(data.link, persisted.mode === "test"));
  await q(
    "UPDATE payments SET link=?,updated=? WHERE id=?",
    url.href,
    now,
    pid,
  ).run();
  return url.href;
}
export async function verifyPayment(
  transaction: string,
  reference?: string,
  event?: string,
  closeFailedCheckout = false,
) {
  if (!/^\d+$/.test(transaction)) throw Error("Invalid transaction");
  const expected: any = reference
    ? await q("SELECT mode FROM payments WHERE id=?", reference).first()
    : null;
  const mode = expected?.mode || paymentMode();
  const data = await flutterwave(
    "transactions/" + transaction + "/verify",
    undefined,
    mode,
  );
  const merchant = mode === "live" ? env.FLW_MERCHANT_ACCOUNT_ID : env.FLW_TEST_MERCHANT_ACCOUNT_ID;
  if (merchant && String(data.account_id) !== merchant) throw Error("Payment merchant does not match configuration");
  const p: any = await q(
    "SELECT * FROM payments WHERE id=?",
    data.tx_ref,
  ).first();
  if (
    !p ||
    p.mode !== mode ||
    String(data.id) !== transaction ||
    (reference && p.id !== reference) ||
    p.currency !== "NGN" ||
    data.currency !== "NGN" ||
    Number(data.amount) !== p.amount
  )
    throw Error("Payment details do not match the order");
  if (["paid", "refunded"].includes(p.status)) {
    if (p.status === "paid" && !p.order_id.startsWith("campaign_"))
      await safelyEmail(() => orderEmail(p.order_id, "paid"));
    return { status: p.status, order: p.order_id };
  }
  if (["failed", "cancelled"].includes(data.status)) {
    // An individual failed attempt does not close a retryable hosted checkout.
    if (!closeFailedCheckout) return { status: p.status, order: p.order_id };
    const stamp = new Date().toISOString();
    await env.DB!.batch([
      q(
        "UPDATE orders SET status='cancelled',payment_status=? WHERE id=? AND status='placed' AND payment_status='pending' AND EXISTS(SELECT 1 FROM payments WHERE id=? AND status='pending')",
        data.status,
        p.order_id,
        p.id,
      ),
      q(
        "UPDATE payments SET status=?,provider_id=?,updated=? WHERE id=? AND status='pending'",
        data.status,
        String(data.id),
        stamp,
        p.id,
      ),
    ]);
    const terminal: any = await q(
      "SELECT status FROM payments WHERE id=?",
      p.id,
    ).first();
    if (["failed", "cancelled"].includes(terminal.status)) {
      await safelyEmail(() => orderEmail(p.order_id, "cancelled"));
    }
    return { status: terminal.status, order: p.order_id };
  }
  if (data.status !== "successful")
    return { status: "pending", order: p.order_id };
  if (p.order_id.startsWith("campaign_")) {
    const campaign = p.order_id.slice(9);
    await env.DB!.batch([
      q(
        "INSERT INTO payment_events(id,payment,type,created) VALUES(?,?,'verified',?) ON CONFLICT(id) DO NOTHING",
        event || "verified-" + String(data.id),
        p.id,
        new Date().toISOString(),
      ),
      q(
        "UPDATE payments SET status='paid',provider_id=?,updated=? WHERE id=? AND status='pending'",
        String(data.id),
        new Date().toISOString(),
        p.id,
      ),
      q(
        "UPDATE campaigns SET payment_status='paid',status='active' WHERE id=? AND status='approved_draft'",
        campaign,
      ),
    ]);
    return { status: "paid", order: p.order_id };
  }
  const order: any = await q(
    "SELECT * FROM orders WHERE id=?",
    p.order_id,
  ).first();
  if (!order) throw Error("Order not found");
  if (order.status === "cancelled") {
    await q(
      "UPDATE payments SET status='review_required',provider_id=?,updated=? WHERE id=?",
      String(data.id),
      new Date().toISOString(),
      p.id,
    ).run();
    await safelyEmail(() =>
      adminEmail(
        `payment-review:${p.id}`,
        "A payment needs reconciliation against a cancelled order.",
      ),
    );
    return { status: "review_required", order: p.order_id };
  }
  const now = new Date().toISOString();
  await env.DB!.batch([
    q(
      "INSERT INTO payment_events(id,payment,type,created) VALUES(?,?,'verified',?) ON CONFLICT(id) DO NOTHING",
      event || "verified-" + String(data.id),
      p.id,
      now,
    ),
    q(
      "UPDATE payments SET status='paid',provider_id=?,updated=? WHERE id=? AND status='pending' AND EXISTS(SELECT 1 FROM orders WHERE id=? AND status!='cancelled' AND payment_status='pending')",
      String(data.id),
      now,
      p.id,
      p.order_id,
    ),
    q(
      "UPDATE orders SET payment_status='paid' WHERE id=? AND status!='cancelled' AND payment_status='pending' AND EXISTS(SELECT 1 FROM payments WHERE id=? AND status='paid')",
      p.order_id,
      p.id,
    ),
    q(
      "INSERT INTO notifications(id,user,title,body,created) SELECT ?,?,'Payment verified',?,? WHERE EXISTS(SELECT 1 FROM payments WHERE id=? AND status='paid') AND NOT EXISTS (SELECT 1 FROM notifications WHERE user=? AND body=?)",
      crypto.randomUUID(),
      p.buyer,
      "Order " + p.order_id + " has been paid.",
      now,
      p.id,
      p.buyer,
      "Order " + p.order_id + " has been paid.",
    ),
  ]);
  const settled: any = await q(
    "SELECT status FROM orders WHERE id=?",
    p.order_id,
  ).first();
  if (settled?.status === "cancelled") {
    await q(
      "UPDATE payments SET status='review_required',provider_id=?,updated=? WHERE id=? AND status!='refunded'",
      String(data.id),
      now,
      p.id,
    ).run();
    await safelyEmail(() =>
      adminEmail(
        `payment-review:${p.id}`,
        "A payment needs reconciliation against a cancelled order.",
      ),
    );
    return { status: "review_required", order: p.order_id };
  }
  const final: any = await q(
    "SELECT status FROM payments WHERE id=?",
    p.id,
  ).first();
  if (final.status === "paid")
    await safelyEmail(() => orderEmail(p.order_id, "paid"));
  return { status: final.status, order: p.order_id };
}
export function secretEqual(a: string, b: string) {
  const x = new TextEncoder().encode(a),
    y = new TextEncoder().encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++)
    diff |= (x[i] || 0) ^ (y[i] || 0);
  return diff === 0;
}
export async function cancelOnlineOrder(order: any) {
  const p: any = await q(
    "SELECT * FROM payments WHERE order_id=?",
    order.id,
  ).first();
  if (!p)
    throw Error(
      "Payment initiation is incomplete. Contact support to release this order.",
    );
  if (p.status === "paid") throw Error("Request a refund for a paid order");
  const lookup = () =>
    flutterwave(
      "transactions/verify_by_reference?tx_ref=" + encodeURIComponent(p.id),
      undefined,
      p.mode,
    );
  const closeCheckout = async () => {
    if (!p.link)
      throw Error(
        "Checkout link is unavailable. Contact support; stock remains reserved.",
      );
    const disabled = await flutterwave(
      "payments/link/disable",
      { link: p.link },
      p.mode,
    );
    if (disabled !== true)
      throw Error(
        "Flutterwave has not confirmed that checkout is closed. Your order remains pending. Please contact support.",
      );
  };
  let data: any;
  try {
    data = await lookup();
  } catch (error) {
    if (!(error instanceof TransactionNotFound)) throw error;
    // Allow expiry plus a settlement grace period before closing unused sessions.
    if (
      !Number.isFinite(Date.parse(p.expires)) ||
      Date.now() < Date.parse(p.expires) + 15 * 60 * 1000
    )
      throw Error(
        "No payment attempt is recorded. Cancellation becomes available 15 minutes after checkout expiry; stock remains reserved. You can still continue payment before expiry.",
      );
    await closeCheckout();
    try {
      data = await lookup();
    } catch (second) {
      if (!(second instanceof TransactionNotFound)) throw second;
      const stamp = new Date().toISOString();
      await env.DB!.batch([
        q(
          "UPDATE orders SET status='cancelled',payment_status='cancelled' WHERE id=? AND status='placed' AND payment_status='pending' AND EXISTS(SELECT 1 FROM payments WHERE id=? AND status='pending')",
          p.order_id,
          p.id,
        ),
        q(
          "UPDATE payments SET status='cancelled',updated=? WHERE id=? AND status='pending' AND EXISTS(SELECT 1 FROM orders WHERE id=? AND status='cancelled')",
          stamp,
          p.id,
          p.order_id,
        ),
      ]);
      const final: any = await q(
        "SELECT status FROM payments WHERE id=?",
        p.id,
      ).first();
      if (final.status !== "cancelled")
        throw Error(
          "Payment changed during cancellation. Check My orders or contact support.",
        );
      await safelyEmail(() => orderEmail(p.order_id, "cancelled"));
      return;
    }
  }
  if (
    !data.id ||
    data.tx_ref !== p.id ||
    data.currency !== "NGN" ||
    Number(data.amount) !== p.amount
  )
    throw Error(
      "Payment details do not match the reservation. Stock remains reserved.",
    );
  // Keep the checkout usable when there is no recorded or terminal attempt.
  // Disabling it before checking would strand an order that can still be paid.
  if (!["successful", "failed", "cancelled"].includes(data.status))
    throw Error(
      "Payment is still pending. Please wait and check My orders again. Stock remains reserved until the payment outcome is confirmed.",
    );
  if (["failed", "cancelled"].includes(data.status)) {
    await closeCheckout();
  }
  // Verify independently again: a pending transaction can settle during cancellation.
  const result = await verifyPayment(String(data.id), p.id, undefined, true);
  if (["paid", "review_required", "refunded"].includes(result.status))
    throw Error(
      "Payment was received or needs review. Contact support for a refund.",
    );
  if (!["failed", "cancelled"].includes(result.status))
    throw Error(
      "Payment is still pending. Stock remains reserved until reconciliation confirms no successful charge.",
    );
}
export async function processRefund(id: string) {
  const r: any = await q(
    "SELECT r.*,p.provider_id AS transaction,p.mode FROM refunds r JOIN payments p ON p.id=r.payment WHERE r.id=?",
    id,
  ).first();
  if (!r) throw Error("Refund not found");
  if (r.status !== "approved_for_processing")
    throw Error("Refund must be approved and not previously initiated");
  const claimed: any = await q(
    "UPDATE refunds SET status='initiating',updated=? WHERE id=? AND status='approved_for_processing' RETURNING id",
    new Date().toISOString(),
    id,
  ).first();
  if (!claimed) throw Error("Refund already claimed");
  try {
    const data = await flutterwave(
      "transactions/" + r.transaction + "/refund",
      { amount: r.amount, comments: r.reason },
      r.mode,
    );
    await q(
      "UPDATE refunds SET status='processing',provider_id=?,updated=? WHERE id=?",
      String(data.id),
      new Date().toISOString(),
      id,
    ).run();
    await safelyEmail(() => refundEmail(id));
    return { status: "processing" };
  } catch (e) {
    await q(
      "UPDATE refunds SET status='reconciliation_required',updated=? WHERE id=?",
      new Date().toISOString(),
      id,
    ).run();
    await safelyEmail(() => refundEmail(id));
    throw e;
  }
}
export async function reconcileRefund(id: string) {
  const r: any = await q(
    "SELECT r.*,p.mode FROM refunds r JOIN payments p ON p.id=r.payment WHERE r.id=?",
    id,
  ).first();
  if (!r?.provider_id)
    throw Error("Provider refund ID required for reconciliation");
  const data = await flutterwave(
    "refunds/" + encodeURIComponent(r.provider_id),
    undefined,
    r.mode,
  );
  if (
    String(data.id) !== r.provider_id ||
    Number(data.amount_refunded) !== r.amount
  )
    throw Error("Refund details do not match");
  if (data.status === "failed") {
    await q(
      "UPDATE refunds SET status='failed',updated=? WHERE id=? AND status!='completed'",
      new Date().toISOString(),
      id,
    ).run();
    await safelyEmail(() => refundEmail(id));
    return { status: "failed" };
  }
  if (!["completed", "completed-mpgs", "successful"].includes(data.status))
    return { status: data.status };
  await env.DB!.batch([
    q(
      "UPDATE refunds SET status='completed',updated=? WHERE id=?",
      new Date().toISOString(),
      id,
    ),
    q(
      "UPDATE payments SET status='refunded',updated=? WHERE id=? AND status='paid'",
      new Date().toISOString(),
      r.payment,
    ),
    q("UPDATE orders SET payment_status='refunded' WHERE id=?", r.order_id),
  ]);
  await safelyEmail(() => refundEmail(id));
  return { status: "completed" };
}

/** Bounded background maintenance. Never release stock from an expiry timestamp alone. */
export async function reconcileExpiredPayments() {
  if (!env.DB || !paymentsAvailable())
    return { checked: 0, released: 0, retained: 0 };
  const time = Date.now();
  const lease: any = await q(
    "INSERT INTO rate_limits(key,count,expires) VALUES('maintenance:payments',1,?) ON CONFLICT(key) DO UPDATE SET count=1,expires=excluded.expires WHERE rate_limits.expires<=? RETURNING key",
    time + 5 * 60 * 1000,
    time,
  ).first();
  if (!lease) return { checked: 0, released: 0, retained: 0 };
  const rows = (
    await q(
      "SELECT o.* FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.payment='flutterwave' AND o.status='placed' AND o.payment_status='pending' AND p.status='pending' AND p.expires<=? ORDER BY p.updated,p.expires LIMIT 3",
      new Date(time).toISOString(),
    ).all()
  ).results;
  let released = 0,
    retained = 0,
    settled = 0;
  for (const order of rows) {
    try {
      await cancelOnlineOrder(order);
      released++;
    } catch {
      const payment: any = await q(
        "SELECT status FROM payments WHERE order_id=?",
        order.id,
      ).first();
      if (payment?.status === "paid") settled++;
      else {
        retained++;
        await safelyEmail(() => orderEmail(String(order.id), "payment-issue"));
        // Rotate uncertain rows so they do not starve later reservations.
        await q(
          "UPDATE payments SET updated=? WHERE order_id=? AND status='pending'",
          new Date().toISOString(),
          order.id,
        ).run();
        console.warn("payment_reservation_reconciliation_retained", {
          order: order.id,
        });
      }
    }
  }
  return { checked: rows.length, released, retained, settled };
}
