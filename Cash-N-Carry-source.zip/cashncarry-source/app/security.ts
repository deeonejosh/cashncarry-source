import { env } from "cloudflare:workers";
export async function limit(key: string, max = 30, seconds = 60) {
  if (!env.DB) throw Error("Storage unavailable");
  const expiry = Math.floor(Date.now() / 1000) + seconds;
  const now = Math.floor(Date.now() / 1000);
  const r: any = await env.DB.prepare(
    "INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires<? THEN 1 ELSE count+1 END,expires=CASE WHEN expires<? THEN excluded.expires ELSE expires END RETURNING count",
  )
    .bind(key, expiry, now, now)
    .first();
  if (r.count > max) throw Error("Too many requests. Try again in a minute.");
}
