"use client";
import { CustomerHeader, CustomerNavigation } from "../customer-shell";
import Link from "next/link";
import { brand } from "../brand";
import { useEffect, useState } from "react";
export default function PaymentReturn() {
  const [message, setMessage] = useState("Verifying your payment securely…");
  const [attempt, setAttempt] = useState(0);
  const [liveReturn, setLiveReturn] = useState("");
  useEffect(() => {
    try {
      const id = sessionStorage.getItem("cnc-live-return");
      if (id && /^[a-zA-Z0-9_-]{1,100}$/.test(id))
        setLiveReturn("/?stream=" + encodeURIComponent(id));
    } catch {}
  }, []);
  const [busy, setBusy] = useState(true);
  const [retryable, setRetryable] = useState(false);
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const reference = params.get("tx_ref"),
      transaction = params.get("transaction_id");
    if (params.get("status") === "cancelled") {
      setMessage(
        "You closed the payment screen. This does not confirm order cancellation. Check My orders for the verified payment status or request cancellation.",
      );
      setBusy(false);
      setRetryable(false);
      return;
    }
    if (!reference || !transaction) {
      setMessage(
        "This payment return link is incomplete. Open My orders to check the payment status.",
      );
      setBusy(false);
      setRetryable(false);
      return;
    }
    const controller = new AbortController();
    let active = true;
    const timeout = setTimeout(() => controller.abort(), 15000);
    setBusy(true);
    setRetryable(false);
    setMessage("Verifying your payment securely…");
    fetch("/api/payments/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({ reference, transaction }),
    })
      .then(async (r) => {
        const d = (await r.json()) as { error?: string; status?: string; mode?: string };
        if (!active) return;
        if (!r.ok) {
          setMessage(
            d.error ||
              "Unable to verify your payment. Check My orders or retry.",
          );
          setRetryable(r.status !== 401 && r.status !== 404);
          return;
        }
        const messages: Record<string, string> = {
          paid: `Your ${d.mode === "live" ? "" : "sandbox "}payment is verified. View your order below.`,
          cancelled:
            "Your order cancellation is confirmed. View your order for details.",
          failed: "Payment failed. Review your order before trying again.",
          refunded:
            "The payment record shows a refund. View your order for details.",
          review_required:
            "This payment needs support review. Please do not pay again until its status is confirmed.",
        };
        setMessage(
          messages[d.status || ""] ||
            "Payment is pending. You can check again or view your order.",
        );
        setRetryable(d.status === "pending");
      })
      .catch(() => {
        if (active) {
          setMessage(
            "Unable to verify the payment right now. Retry or check My orders. Your order is only marked paid after server verification.",
          );
          setRetryable(true);
        }
      })
      .finally(() => {
        clearTimeout(timeout);
        if (active) setBusy(false);
      });
    return () => {
      active = false;
      clearTimeout(timeout);
      controller.abort();
    };
  }, [attempt]);
  return (
    <><CustomerHeader /><main id="main-content" tabIndex={-1} className="customer-page payment-result-page design-card">
      <h1>{brand.name} payment</h1>
      <p role="status" aria-live="polite" aria-busy={busy}>
        {message}
      </p>
      <div className="payment-actions">
        {liveReturn && (
          <a className="primary" href={liveReturn}>
            Back to broadcast
          </a>
        )}
        {retryable && (
          <button
            className="primary"
            disabled={busy}
            onClick={() => setAttempt((n) => n + 1)}
          >
            Retry verification
          </button>
        )}
        <Link className="secondary-button" href="/#orders">
          View my orders
        </Link>
      </div>
    </main><CustomerNavigation /></>
  );
}
