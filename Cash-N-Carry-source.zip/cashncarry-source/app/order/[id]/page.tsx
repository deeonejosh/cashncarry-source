import VerifiedSellerBadge from "../../verified-seller-badge";
import {
  CustomerHeader,
  CustomerNavigation,
  PageHeading,
} from "../../customer-shell";
import { brand } from "../../brand";
import Link from "next/link";
import { env } from "cloudflare:workers";
import { requireChatGPTUser } from "../../chatgpt-auth";
import { notFound } from "next/navigation";
export default async function Order({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params,
    u = await requireChatGPTUser("/order/" + id);
  const o: any = await env
    .DB!.prepare(
      "SELECT o.*,(SELECT mode FROM payments WHERE order_id=o.id) AS payment_mode,s.name AS seller,CASE WHEN s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles sp WHERE sp.id=s.owner AND sp.suspended=1) THEN s.verified ELSE 0 END AS verified,s.return_policy,s.delivery_days FROM orders o JOIN stores s ON s.id=o.store WHERE o.id=? AND (o.buyer=? OR s.owner=?)",
    )
    .bind(id, u.userId, u.userId)
    .first();
  if (!o) notFound();
  const items = (
    await env
      .DB!.prepare(
        "SELECT name,variant,price,quantity FROM order_items WHERE order_id=?",
      )
      .bind(id)
      .all<any>()
  ).results;
  return (
    <>
      <CustomerHeader active="Account" back="/?browse=1#orders" />
      <main
        id="main-content"
        tabIndex={-1}
        className="customer-page order-detail-page"
      >
        <Link href="/#orders">{brand.name} orders</Link>
        <PageHeading title="Order details" />
        <p>Order {o.id}</p>
        <p>
          {o.seller}<VerifiedSellerBadge verified={o.verified}/> · {o.status}
        </p>
        <p>
          Payment:{" "}
          {o.payment === "flutterwave"
            ? o.payment_mode === "live"
              ? "LIVE · "
              : "SANDBOX TEST · "
            : ""}
          {o.payment_status}
        </p>
        {items.map((i, n) => (
          <article key={n}>
            {i.name} {i.variant && "· " + i.variant}
            <p>
              {i.quantity} × ₦{i.price.toLocaleString()}
            </p>
          </article>
        ))}
        <p>
          Delivery fee: ₦{o.delivery_fee.toLocaleString()} · Total: ₦
          {o.total.toLocaleString()}
        </p>
        <p>
          Deliver to: {o.name} · {o.address}
        </p>
        <p>Estimated delivery: {o.delivery_days}</p>
        <p className="delivery-summary">
          Shipment: {o.tracking || "Seller has not added tracking yet."}
        </p>
        <p>Returns: {o.return_policy}</p>
        <a href={"/workspace?tab=Support&order=" + encodeURIComponent(id)}>Support, returns and refunds</a>
        {o.buyer === u.userId && (
          <p>
            <a href={"/api/orders/receipt?id=" + encodeURIComponent(id)}>
              Download order record
            </a>
          </p>
        )}
      </main>
      <CustomerNavigation active="Account" />
    </>
  );
}
