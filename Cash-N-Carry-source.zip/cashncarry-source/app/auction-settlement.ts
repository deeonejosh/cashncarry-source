import { env } from "cloudflare:workers";

const q = (sql: string, ...args: any[]) => env.DB!.prepare(sql).bind(...args);

/** Idempotently settles a time-expired auction into an explicitly unpaid order. */
export async function settleAuction(auctionId: string, at = new Date().toISOString()) {
  if (!env.DB) throw Error("Storage unavailable");
  const auction: any = await q("SELECT * FROM live_auctions WHERE id=?", auctionId).first();
  if (!auction) return { settled: false, reason: "not_found" };
  if (auction.status === "ended") return { settled: false, reason: "already_ended", orderId: auction.order_id || null };
  if (!["active", "scheduled"].includes(auction.status) || auction.ends_at > at)
    return { settled: false, reason: "not_due" };

  const bid: any = await q("SELECT b.*,p.name FROM auction_bids b JOIN profiles p ON p.id=b.bidder WHERE b.auction=? ORDER BY b.amount DESC,b.created ASC LIMIT 1", auctionId).first();
  const product: any = await q("SELECT name,stock FROM products WHERE id=?", auction.product).first();
  const winner = Boolean(bid && product?.stock > 0 && (!auction.reserve_price || bid.amount >= auction.reserve_price));
  const orderId = winner ? `auc-${auctionId}` : "";
  const seller: any = await q("SELECT owner FROM stores WHERE id=?", auction.store).first();
  const statements: any[] = [q("UPDATE live_auctions SET status='ended',winning_bid=?,order_id=?,updated=? WHERE id=? AND status IN ('active','scheduled') AND ends_at<=?", winner ? bid.id : "", orderId, at, auctionId, at)];
  if (winner) {
    statements.push(q("INSERT OR IGNORE INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,delivery_fee,delivery_state,created,seller_activation_required) VALUES(?,?,?,?,?,?,?,'placed','auction','pending',0,'',?,1)", orderId, bid.bidder, auction.store, bid.name, "", "", bid.amount, at));
    statements.push(q("INSERT INTO order_items(id,order_id,product,name,price,quantity,variant) SELECT ?,?,?,?,?,1,'' WHERE EXISTS(SELECT 1 FROM live_auctions WHERE id=? AND order_id=? AND winning_bid=?) AND NOT EXISTS(SELECT 1 FROM order_items WHERE order_id=? AND product=?)", crypto.randomUUID(), orderId, auction.product, product.name, bid.amount, auctionId, orderId, bid.id, orderId, auction.product));
    statements.push(q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)", `auction-win:${auctionId}`, bid.bidder, "You won a live auction", `Highest eligible bid: ₦${Number(bid.amount).toLocaleString("en-NG")}. The order is unpaid; payment collection is not enabled yet.`, at));
    if (seller?.owner) statements.push(q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)", `auction-ended:${auctionId}`, seller.owner, "Live auction ended", `Winning bid: ₦${Number(bid.amount).toLocaleString("en-NG")}. Its order is unpaid; payment collection is not enabled.`, at));
  } else if (seller?.owner) {
    statements.push(q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)", `auction-ended:${auctionId}`, seller.owner, "Live auction ended", "No eligible winning bid met the reserve or available stock requirement.", at));
  }
  await env.DB.batch(statements);
  const saved: any = await q("SELECT status,order_id FROM live_auctions WHERE id=?", auctionId).first();
  return { settled: saved?.status === "ended", orderId: saved?.order_id || null };
}

export async function settleExpiredAuctions(limit = 100) {
  if (!env.DB) throw Error("Storage unavailable");
  const stamp = new Date().toISOString();
  const due: any = await q("SELECT id FROM live_auctions WHERE status IN ('active','scheduled') AND ends_at<=? ORDER BY ends_at LIMIT ?", stamp, Math.max(1, Math.min(500, limit))).all();
  let settled = 0;
  for (const row of due.results as any[]) {
    const result = await settleAuction(row.id, stamp);
    if (result.settled) settled++;
  }
  return { due: due.results.length, settled };
}
