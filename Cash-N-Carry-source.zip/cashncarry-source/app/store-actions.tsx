"use client";
import { useEffect, useState } from "react";
import { Heart, Share2 } from "lucide-react";
import {trackAnalyticsEvent} from "./analytics";
export default function StoreActions({
  id,
  following = false,
  shareUrl,
}: {
  id: string;
  following?: boolean;
  shareUrl?: string;
}) {
  const [followed, setFollowed] = useState(following),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  useEffect(()=>{trackAnalyticsEvent("store_view",id);},[id]);
  const publicUrl = new URL(shareUrl || "/store/" + id, typeof window === "undefined" ? "https://cashncarryng.com" : window.location.origin).href;
  async function follow() {
    setBusy(true);
    try {
      const r = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "follow",
          store: id,
          follow: !followed,
        }),
        signal: AbortSignal.timeout(15000),
      });
      if (r.status === 401) {
        window.location.assign(
          "/sign-in?returnTo=" + encodeURIComponent("/store/" + id),
        );
        return;
      }
      const b: any = await r.json();
      if (!r.ok) throw Error(b.error || "Unable to update follow preference");
      setFollowed(!followed);
      if(!followed)trackAnalyticsEvent("follow",id);
      setMessage(
        !followed ? "You are following this seller." : "Seller unfollowed.",
      );
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Please retry.");
    } finally {
      setBusy(false);
    }
  }
  async function share() {
    try {
      if (navigator.share) await navigator.share({ url: publicUrl });
      else {
        await navigator.clipboard.writeText(publicUrl);
        setMessage("Store link copied.");
      }
    } catch {
      setMessage("You can copy the store link from your address bar.");
    }
  }
  return (
    <div className="store-follow-controls"><a className="primary" href={"/messages?store=" + encodeURIComponent(id)}>Chat with seller</a>
      <button
        className="primary"
        onClick={follow}
        aria-pressed={followed}
        disabled={busy}
      >
        <Heart size={18} />
        {busy ? "Saving…" : followed ? "Following" : "Follow seller"}
      </button>
      <button
        className="icon-control"
        onClick={share}
        aria-label="Share storefront"
      >
        <Share2 size={21} />
      </button>
      <a className="store-share-whatsapp" href={`https://wa.me/?text=${encodeURIComponent(publicUrl)}`} target="_blank" rel="noopener noreferrer">Share on WhatsApp</a>
      <a className="store-share-facebook" href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(publicUrl)}`} target="_blank" rel="noopener noreferrer">Share on Facebook</a>
      <p role="status">{message}</p>
    </div>
  );
}
