export function portraitCrop(width: number, height: number) {
  const ratio = 9 / 16;
  const w = Math.min(width, height * ratio),
    h = w / ratio;
  return { x: (width - w) / 2, y: (height - h) / 2, width: w, height: h };
}

/** Normalize the outgoing WHIP video as well as the local preview. Audio stays native. */
export function createPortraitPublisher(
  video: HTMLVideoElement,
  source: MediaStream,
) {
  const canvas = document.createElement("canvas");
  canvas.width = 720;
  canvas.height = 1280;
  if (!canvas.captureStream)
    throw Error(
      "Portrait broadcasting is unavailable in this browser. Try a supported mobile browser.",
    );
  const context = canvas.getContext("2d");
  if (!context)
    throw Error("Unable to prepare portrait video. Try another browser.");
  const output = canvas.captureStream(30);
  let frame = 0,
    stopped = false;
  const draw = () => {
    if (stopped) return;
    if (video.readyState >= 2 && video.videoWidth && video.videoHeight) {
      const crop = portraitCrop(video.videoWidth, video.videoHeight);
      context.drawImage(
        video,
        crop.x,
        crop.y,
        crop.width,
        crop.height,
        0,
        0,
        720,
        1280,
      );
    }
    frame = requestAnimationFrame(draw);
  };
  draw();
  return {
    stream: new MediaStream([
      ...output.getVideoTracks(),
      ...source.getAudioTracks(),
    ]),
    stop() {
      stopped = true;
      cancelAnimationFrame(frame);
      output.getTracks().forEach((t) => t.stop());
    },
  };
}
