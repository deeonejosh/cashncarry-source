import { ensureImageUploadSchema } from "./image-upload-schema";

export const DEFAULT_IMAGE_UPLOAD_POLICY = {
  dailyImages: 100,
  dailyBytes: 500 * 1024 * 1024,
  maxImageBytes: 10 * 1024 * 1024,
  maxImagesPerProduct: 10,
  uploadsPerMinute: 10,
} as const;

export type ImageUploadPolicy = { dailyImages: number; dailyBytes: number; maxImageBytes: number; maxImagesPerProduct: number; uploadsPerMinute: number };

function bounded(value: unknown, fallback: number, min: number, max: number) {
  const n = Number(value);
  return Number.isInteger(n) && n >= min && n <= max ? n : fallback;
}

export function normalizeImageUploadPolicy(input: unknown): ImageUploadPolicy {
  const value = input && typeof input === "object" ? input as Record<string, unknown> : {};
  return {
    dailyImages: bounded(value.dailyImages, DEFAULT_IMAGE_UPLOAD_POLICY.dailyImages, 1, 500),
    dailyBytes: bounded(value.dailyBytes, DEFAULT_IMAGE_UPLOAD_POLICY.dailyBytes, 10 * 1024 * 1024, 2 * 1024 * 1024 * 1024),
    maxImageBytes: bounded(value.maxImageBytes, DEFAULT_IMAGE_UPLOAD_POLICY.maxImageBytes, 1 * 1024 * 1024, 10 * 1024 * 1024),
    maxImagesPerProduct: bounded(value.maxImagesPerProduct, DEFAULT_IMAGE_UPLOAD_POLICY.maxImagesPerProduct, 1, 20),
    uploadsPerMinute: bounded(value.uploadsPerMinute, DEFAULT_IMAGE_UPLOAD_POLICY.uploadsPerMinute, 1, 60),
  };
}

export async function getImageUploadPolicy(db: any): Promise<ImageUploadPolicy> {
  try {
    await ensureImageUploadSchema(db);
    const row = await db.prepare("SELECT value FROM platform_settings WHERE key='image_upload_policy'").first();
    return normalizeImageUploadPolicy(row?.value ? JSON.parse(row.value) : {});
  } catch {
    return DEFAULT_IMAGE_UPLOAD_POLICY;
  }
}

export function utcDay(now = new Date()) {
  return now.toISOString().slice(0, 10);
}

export function nextUtcReset(now = new Date()) {
  const next = new Date(now);
  next.setUTCHours(24, 0, 0, 0);
  return next.toISOString();
}

