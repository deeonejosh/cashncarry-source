import { env } from "cloudflare:workers";
import { states } from "./commerce-extra";
const marker = "owner_setup_nigeria_20261010_v1";
/** One-time, owner-authorised data setup, separate from schema migrations. */
export async function applyOwnerBusinessSetup() {
  if (!env.DB) throw Error("Storage unavailable");
  if (await env.DB.prepare("SELECT key FROM platform_settings WHERE key=?").bind(marker).first()) return;
  const timestamp = new Date().toISOString();
  await env.DB.batch([
    env.DB.prepare("UPDATE stores SET coverage=? WHERE id=? AND NOT EXISTS (SELECT 1 FROM platform_settings WHERE key=?)").bind(JSON.stringify(states), "1a1edf07-38f9-4c3b-9a17-991e9d43f65b", marker),
    env.DB.prepare("INSERT OR IGNORE INTO platform_settings(key,value,updated) VALUES(?,?,?)").bind(marker, "Nationwide Gearpulse coverage configured; legal policy versions remain approval-gated", timestamp),
  ]);
}
