type Props = { verified: unknown; suspended?: unknown; variant?: "full" | "compact" | "icon" };
/** Presentation only: authority remains the existing admin-controlled store flag. */
export default function VerifiedSellerBadge({ verified, suspended, variant = "icon" }: Props) {
  if (!(verified === 1 || verified === true) || suspended === 1 || suspended === true) return null;
  return <span className={`verified-seller-badge verified-seller-badge--${variant}`} role="img" aria-label="Verified Seller" title="Verified Seller — seller verification approved by Cash N Carry. This does not guarantee a product or transaction.">
    <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="10.5" fill="#164B35" stroke="#D4A574" strokeWidth="1.5"/><path d="m7.2 12.2 3.1 3.1 6.7-7" fill="none" stroke="#FFF8EF" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
    {variant !== "icon" && <span className="verified-seller-badge__label" aria-hidden="true">{variant === "compact" ? "Verified" : "Verified Seller"}</span>}
  </span>;
}
