"use client";
import { useState, useEffect, useRef, type ImgHTMLAttributes } from "react";
export default function ImageAsset({
  src,
  alt = "",
  ...props
}: ImgHTMLAttributes<HTMLImageElement>) {
  const [failed, setFailed] = useState<string | null>(null);
  const image = useRef<HTMLImageElement>(null);
  useEffect(() => {
    // A failed SSR image can finish loading before React attaches onError.
    if (src && image.current?.complete && image.current.naturalWidth === 0)
      setFailed(String(src));
  }, [src]);
  const unavailable = !src || failed === String(src);
  return (
    <img
      loading="lazy"
      decoding="async"
      {...props}
      ref={image}
      className={[props.className, unavailable ? "image-unavailable" : ""]
        .filter(Boolean)
        .join(" ")}
      src={unavailable ? "/image-unavailable.svg" : src}
      alt={
        unavailable && alt !== ""
          ? `Photo unavailable${alt ? ": " + alt : ""}`
          : alt
      }
      onError={(event) => {
        setFailed(String(src || ""));
        props.onError?.(event);
      }}
    />
  );
}
