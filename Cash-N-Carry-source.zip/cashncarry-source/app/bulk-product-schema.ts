/* eslint-disable @typescript-eslint/no-explicit-any */
import { env } from "cloudflare:workers";

let ready: Promise<void> | null = null;

/** Keep local and existing D1 environments compatible while 0021 is rolled out. */
export async function ensureBulkProductSchema() {
  if (!env.DB) throw Error("Storage unavailable");
  if (!ready) {
    ready = (async () => {
      try {
        await env.DB!.prepare("SELECT sku FROM products LIMIT 0").run();
      } catch (error: any) {
        if (!/no such column:\s*sku/i.test(String(error?.message || error))) throw error;
        try {
          await env.DB!.prepare("ALTER TABLE products ADD COLUMN sku TEXT NOT NULL DEFAULT ''").run();
        } catch (alterError: any) {
          if (!/duplicate column name:\s*sku/i.test(String(alterError?.message || alterError))) throw alterError;
        }
      }
      await env.DB!.prepare("CREATE UNIQUE INDEX IF NOT EXISTS products_store_sku ON products(store,lower(sku)) WHERE sku!=''").run();
      await env.DB!.prepare(`CREATE TABLE IF NOT EXISTS seller_product_imports (
        id TEXT PRIMARY KEY,
        store TEXT NOT NULL REFERENCES stores(id),
        fingerprint TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'processing' CHECK(status IN ('processing','completed','partial')),
        total INTEGER NOT NULL DEFAULT 0,
        imported INTEGER NOT NULL DEFAULT 0,
        failed INTEGER NOT NULL DEFAULT 0,
        duplicates INTEGER NOT NULL DEFAULT 0,
        created TEXT NOT NULL,
        updated TEXT NOT NULL
      )`).run();
      await env.DB!.prepare("CREATE INDEX IF NOT EXISTS seller_product_imports_store_created ON seller_product_imports(store,created DESC)").run();
      await env.DB!.prepare(`CREATE TABLE IF NOT EXISTS seller_product_import_rows (
        import_id TEXT NOT NULL REFERENCES seller_product_imports(id),
        row_number INTEGER NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('imported','failed','duplicate')),
        sku TEXT NOT NULL DEFAULT '',
        product_name TEXT NOT NULL DEFAULT '',
        product_id TEXT NOT NULL DEFAULT '',
        source_key TEXT NOT NULL DEFAULT '',
        errors TEXT NOT NULL DEFAULT '[]',
        created TEXT NOT NULL,
        PRIMARY KEY(import_id,row_number)
      )`).run();
      try {
        await env.DB!.prepare("SELECT source_key FROM seller_product_import_rows LIMIT 0").run();
      } catch (error: any) {
        if (!/no such column:\s*source_key/i.test(String(error?.message || error))) throw error;
        await env.DB!.prepare("ALTER TABLE seller_product_import_rows ADD COLUMN source_key TEXT NOT NULL DEFAULT ''").run();
      }
      await env.DB!.prepare("CREATE UNIQUE INDEX IF NOT EXISTS seller_product_import_rows_source_key ON seller_product_import_rows(source_key) WHERE source_key!='' AND status='imported'").run();
    })().catch((error) => { ready = null; throw error; });
  }
  await ready;
}
