export const ANALYTICS_CONSENT_KEY = "cnc:analytics-consent:v1";
