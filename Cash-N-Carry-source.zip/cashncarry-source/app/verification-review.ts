import {env} from 'cloudflare:workers';
import {verificationEmail,safelyEmail} from './email-events';
const q=(sql:string,...args:any[])=>env.DB!.prepare(sql).bind(...args);
export async function reviewSellerVerification(id:string,status:string,reason:string,actor:{userId:string;email?:string}){
 if(!['approved','more_information','rejected'].includes(status))throw Error('Invalid review decision');
 const before:any=await q("SELECT * FROM verification_requests WHERE id=? AND status IN ('pending','more_information')",id).first();
 if(!before)throw Error('Application is no longer awaiting review');
 const latest:any=await q('SELECT id FROM verification_requests WHERE store=? ORDER BY created DESC,rowid DESC LIMIT 1',before.store).first();
 if(latest?.id!==id)throw Error('A newer application exists. Review the latest submission instead.');
 const safe={...before};delete safe.file_key;
 const now=new Date().toISOString();
 const result:any=await env.DB!.batch([
 q("UPDATE verification_requests SET status=?,note=?,updated=? WHERE id=? AND status IN ('pending','more_information') AND id=(SELECT id FROM verification_requests WHERE store=? ORDER BY created DESC,rowid DESC LIMIT 1)",status,reason,now,id,before.store),
 q('UPDATE stores SET verified=? WHERE id=? AND changes()=1',status==='approved'?1:0,before.store),
 q('INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) SELECT ?,?,?,?,?,?,?,?,? WHERE changes()=1',crypto.randomUUID(),actor.userId,actor.email||'','verification',id,reason,JSON.stringify(safe),JSON.stringify({...safe,status,outcome:'applied'}),now)
 ]);
 if(Number(result[0]?.meta?.changes??result[0]?.changes)!==1)throw Error('Application reviewed concurrently. Refresh before continuing.');
 await safelyEmail(()=>verificationEmail(id));
 return {ok:true};
}

/** Revoke the existing store flag while preserving prior application decisions. */
export async function revokeSellerVerification(store:string,reason:string,actor:{userId:string;email?:string}){
 if(reason.trim().length<5)throw Error('Record a reason of at least five characters');
 const before:any=await q('SELECT id,verified FROM stores WHERE id=? AND verified=1',store).first();
 if(!before)throw Error('Store is not currently verified');
 const now=new Date().toISOString();
 const result:any=await env.DB!.batch([
  q('UPDATE stores SET verified=0 WHERE id=? AND verified=1',store),
  q("INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) SELECT ?,?,?,?,?,?,?,?,? WHERE changes()=1",crypto.randomUUID(),actor.userId,actor.email||'','verification-revoked',store,reason.trim().slice(0,1000),JSON.stringify(before),JSON.stringify({id:store,verified:0}),now)
 ]);
 if(Number(result[0]?.meta?.changes??result[0]?.changes)!==1)throw Error('Verification changed concurrently; refresh and retry');
 return {ok:true};
}
