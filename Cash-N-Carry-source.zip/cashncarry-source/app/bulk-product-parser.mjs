import * as XLSX from "xlsx";
import {
  BULK_PRODUCT_HEADERS,
  BULK_PRODUCT_MAX_FILE_BYTES,
  BULK_PRODUCT_MAX_ROWS,
  normalizeBulkHeader,
  splitBulkImageUrls,
} from "./bulk-product-utils.mjs";

const supportedColumns = new Map([
  ["product name", "name"], ["description", "description"], ["category", "category"],
  ["price ngn", "price"], ["price", "price"], ["sku", "sku"],
  ["stock quantity", "stock"], ["stock", "stock"], ["main image url", "image"],
  ["additional image urls", "images"], ["product status", "status"],
]);

export function parseBulkProductWorkbook(buffer) {
  if (!(buffer instanceof ArrayBuffer) || buffer.byteLength < 4 || buffer.byteLength > BULK_PRODUCT_MAX_FILE_BYTES) {
    throw new Error("The Excel workbook must be smaller than 5 MB.");
  }
  const workbook = XLSX.read(buffer, { type: "array", cellDates: false, sheetRows: BULK_PRODUCT_MAX_ROWS + 2, dense: false });
  const sheetName = workbook.SheetNames.find((name) => name.toLocaleLowerCase() === "products") || workbook.SheetNames.find((name) => name.toLocaleLowerCase() !== "instructions");
  if (!sheetName) throw new Error("The workbook needs a Products worksheet.");
  const sheet = workbook.Sheets[sheetName];
  const range = sheet["!ref"] ? XLSX.utils.decode_range(sheet["!ref"]) : null;
  if (!range || range.e.r < range.s.r) throw new Error("The Products worksheet is empty.");
  if (range.e.r - range.s.r > BULK_PRODUCT_MAX_ROWS) throw new Error(`Upload no more than ${BULK_PRODUCT_MAX_ROWS} product rows at a time.`);
  for (let r = range.s.r; r <= range.e.r; r++) for (let c = range.s.c; c <= range.e.c; c++) {
    const cell = sheet[XLSX.utils.encode_cell({ r, c })];
    if (cell?.f) throw new Error("Remove spreadsheet formulas before uploading. Enter fixed values in product cells.");
  }
  const matrix = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "", raw: true, blankrows: true });
  const headerRow = matrix[0] || [];
  const headers = headerRow.map((value) => normalizeBulkHeader(value));
  const unknown = headerRow.map((value, index) => ({ value: String(value ?? "").trim(), key: headers[index] })).filter((item) => item.value && !supportedColumns.has(item.key));
  if (unknown.length) throw new Error(`Unsupported spreadsheet columns: ${unknown.map((item) => item.value).join(", ")}. Download the Cash N Carry template and move those values to supported fields before importing.`);
  const indexes = new Map();
  headers.forEach((key, index) => { const canonical = supportedColumns.get(key); if (canonical && !indexes.has(canonical)) indexes.set(canonical, index); });
  for (const required of ["name", "description", "category", "price", "stock"]) {
    if (!indexes.has(required)) {
      const display = BULK_PRODUCT_HEADERS.find((header) => supportedColumns.get(normalizeBulkHeader(header)) === required) || required;
      throw new Error(`Missing required column: ${display}.`);
    }
  }
  const rows = [];
  matrix.slice(1).forEach((values, index) => {
    if (!values.some((value) => String(value ?? "").trim())) return;
    const cell = (key) => indexes.has(key) ? values[indexes.get(key)] : "";
    rows.push({
      rowNumber: index + 2,
      name: String(cell("name") ?? "").trim(),
      description: String(cell("description") ?? "").trim(),
      category: String(cell("category") ?? "").trim(),
      price: cell("price"),
      sku: String(cell("sku") ?? "").trim(),
      stock: cell("stock"),
      image: String(cell("image") ?? "").trim(),
      images: splitBulkImageUrls(cell("images")),
      status: String(cell("status") ?? "").trim() || "Draft",
    });
  });
  if (!rows.length) throw new Error("Add at least one product row below the header.");
  if (rows.length > BULK_PRODUCT_MAX_ROWS) throw new Error(`Upload no more than ${BULK_PRODUCT_MAX_ROWS} product rows at a time.`);
  return rows;
}

export { XLSX };
