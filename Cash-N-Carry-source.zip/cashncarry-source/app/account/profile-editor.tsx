"use client";
import { useState } from "react";
export default function ProfileEditor({ user, onSaved }: { user: { name: string; email: string; username?: string }; onSaved: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [failed, setFailed] = useState(false);
  return <section className="profile-editor design-card" aria-labelledby="profile-edit-title">
    <h2 id="profile-edit-title">Your profile</h2>
    <p>Choose how your account is identified. Your email stays private.</p>
    <form onSubmit={async (event) => {
      event.preventDefault(); if (busy) return;
      const fields = new FormData(event.currentTarget);
      setBusy(true); setMessage(""); setFailed(false);
      try {
        const response = await fetch("/api/commerce", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "profile", name: fields.get("name"), username: fields.get("username") }), signal: AbortSignal.timeout(15000) });
        const body: any = await response.json();
        if (!response.ok) throw Error(body.error || "Unable to save your profile");
        setMessage("Profile saved.");
        await onSaved();
      } catch (error) { setFailed(true); setMessage(error instanceof Error ? error.message : "Unable to save. Please retry."); }
      finally { setBusy(false); }
    }}>
      <fieldset disabled={busy}>
        <label htmlFor="profile-name">Display name<input id="profile-name" name="name" autoComplete="name" required minLength={2} maxLength={100} defaultValue={user.name} /></label>
        <label htmlFor="profile-username">Username<span className="username-input"><span aria-hidden="true">@</span><input id="profile-username" name="username" autoComplete="off" autoCapitalize="none" spellCheck={false} required minLength={3} maxLength={24} pattern="[A-Za-z][A-Za-z0-9_]{2,23}" aria-describedby="username-help" defaultValue={user.username || ""} /></span></label>
        <p id="username-help">3–24 characters. Start with a letter; use letters, numbers or underscores. Usernames are unique and saved in lowercase.</p>
        <label>Email address<input type="email" readOnly value={user.email} /></label>
        <p className="profile-signin-note">Continue signing in with your email or existing sign-in method.</p>
        <button className="primary" type="submit">{busy ? "Saving…" : "Save profile"}</button>
      </fieldset>
    </form>
    {message && <p className={failed ? "profile-feedback is-error" : "profile-feedback"} role={failed ? "alert" : "status"}>{message}</p>}
  </section>;
}
