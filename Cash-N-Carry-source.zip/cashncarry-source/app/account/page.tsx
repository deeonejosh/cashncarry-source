import AuthForm from "./auth-form";
import AccountHub from "./hub";
import { authAvailable } from "../auth";
import { getChatGPTUser } from "../chatgpt-auth";
import { assignedAdminRole } from "../admin-access";
export const dynamic = "force-dynamic";
export default async function Account() {
  const user = await getChatGPTUser();
  return user ? (
    <AccountHub adminEntry={Boolean(await assignedAdminRole(user))} />
  ) : (
    <AuthForm available={await authAvailable()} legacy destination="/account" />
  );
}
