"use client";
import {useState} from "react";
export default function Sessions(){
const [sessions,setSessions]=useState<any[]>([]);const [busy,setBusy]=useState(false);const [message,setMessage]=useState("");
return <details className="entry-sessions"><summary>Manage email sessions</summary><p role="status">{message}</p>      <h2>Email session management</h2>
      <button
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setMessage("");
          try {
            const r = await fetch("/api/auth/list-sessions", {
              signal: AbortSignal.timeout(15000),
            });
            const d: any = await r.json();
            if (!r.ok) {
              setMessage(
                d.message || "Sign in with email to manage email sessions",
              );
              return;
            }
            const rows = Array.isArray(d) ? d : [];
            setSessions(rows);
            if (!rows.length)
              setMessage("No email sessions are available for this account.");
          } catch {
            setMessage(
              "Unable to load sessions. Check your connection and retry.",
            );
          } finally {
            setBusy(false);
          }
        }}
      >
        View sessions
      </button>
      {sessions.map((s: any) => (
        <article key={s.id}>
          <p>Session expires {new Date(s.expiresAt).toLocaleString()}</p>
          <button
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              setMessage("");
              try {
                const r = await fetch("/api/auth/revoke-session", {
                  signal: AbortSignal.timeout(15000),
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ token: s.token }),
                });
                if (r.ok) {
                  setSessions((v) => v.filter((x) => x.id !== s.id));
                  setMessage("Session revoked.");
                } else setMessage("Unable to revoke session");
              } catch {
                setMessage(
                  "Unable to revoke the session. Check your connection and retry.",
                );
              } finally {
                setBusy(false);
              }
            }}
          >
            Revoke session
          </button>
        </article>
      ))}
</details>;}
