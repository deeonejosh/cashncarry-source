import PolicyPage, { policyMetadata } from "../policy-page";
export const dynamic = "force-dynamic";
export const generateMetadata = () => policyMetadata("seller-terms");
export default function Page() { return PolicyPage({ policyId: "seller-terms" }); }
