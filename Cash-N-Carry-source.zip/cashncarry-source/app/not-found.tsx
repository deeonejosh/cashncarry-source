import { brand } from "./brand";
import Link from "next/link";
export default function NotFound() {
  return (
    <main id="main-content" tabIndex={-1}>
      <div className="empty">
        <h1>This page couldn’t be found.</h1>
        <p>Head back to {brand.name} to browse products and businesses.</p>
        <Link className="primary" href="/">
          Open {brand.name}
        </Link>
      </div>
    </main>
  );
}
