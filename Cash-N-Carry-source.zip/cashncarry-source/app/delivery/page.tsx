import PolicyPage, { policyMetadata } from "../policy-page";
export const dynamic = "force-dynamic";
export const generateMetadata = () => policyMetadata("delivery");
export default function Page() { return PolicyPage({ policyId: "delivery" }); }
