// Send complete ICE candidates: this client does not implement trickle PATCH.
export async function completeIceOffer(pc: RTCPeerConnection): Promise<string> {
  await pc.setLocalDescription(await pc.createOffer());
  if (pc.iceGatheringState !== "complete") {
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => { cleanup(); reject(Error("Network negotiation timed out. Check your connection and retry.")); }, 10000);
      const change = () => { if (pc.iceGatheringState === "complete") { cleanup(); resolve(); } };
      const cleanup = () => { clearTimeout(timer); pc.removeEventListener("icegatheringstatechange", change); };
      pc.addEventListener("icegatheringstatechange", change);
      change();
    });
  }
  if (pc.signalingState === "closed" || !pc.localDescription?.sdp) throw Error("Connection was closed. Retry the broadcast.");
  return pc.localDescription.sdp;
}
