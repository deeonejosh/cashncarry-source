import { eligibleSellerSQL } from "./seller-activation";
import { env } from "cloudflare:workers";
export async function catalog(params: URLSearchParams, user: string | null) {
  const text = (key: string, max = 100) =>
    (params.get(key) || "").trim().slice(0, max);
  const clauses = [
    "p.active=1",
    eligibleSellerSQL(),
    "s.suspended=0",
    "NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
  ];
  const args: any[] = [];
  const search = text("q", 200),
    category = text("category"),
    location = text("location");
  if (search) {
    clauses.push(
      "instr(lower(p.name||' '||s.name||' '||p.description),lower(?))>0",
    );
    args.push(search);
  }
  if (category && category !== "All") {
    clauses.push("p.category=?");
    args.push(category);
  }
  if (location) {
    clauses.push(
      params.get("mode") === "delivers"
        ? "EXISTS (SELECT 1 FROM json_each(s.coverage) WHERE instr(lower(value),lower(?))>0)"
        : "instr(lower(s.location||' '||s.state||' '||s.area),lower(?))>0",
    );
    args.push(location);
  }
  if (text("store")) {
    clauses.push("p.store=?");
    args.push(text("store"));
  }
  if (params.get("following") === "1") {
    clauses.push(
      "EXISTS (SELECT 1 FROM follows f WHERE f.store=p.store AND f.user=?)",
    );
    args.push(user || "");
  }
  if (params.has("lat") || params.has("lng")) {
    const lat = Number(params.get("lat")),
      lng = Number(params.get("lng")),
      radius = Number(params.get("radius") || 25);
    if (
      !params.has("lat") ||
      !params.has("lng") ||
      !Number.isFinite(lat) ||
      !Number.isFinite(lng) ||
      Math.abs(lat) > 90 ||
      Math.abs(lng) > 180 ||
      !Number.isFinite(radius) ||
      radius < 1 ||
      radius > 500
    )
      throw Error("Invalid distance filter");
    clauses.push(
      "s.latitude IS NOT NULL AND s.longitude IS NOT NULL AND sin(radians(s.latitude))*sin(radians(?))+cos(radians(s.latitude))*cos(radians(?))*cos(radians(s.longitude-?))>=cos(?/6371.0)",
    );
    args.push(lat, lat, lng, radius);
  }
  const from =
    " FROM products p JOIN stores s ON s.id=p.store WHERE " +
    clauses.join(" AND ");
  const total: any = await env
    .DB!.prepare("SELECT COUNT(*) AS total" + from)
    .bind(...args)
    .first();
  const requested = Number(params.get("page") || 1);
  if (!Number.isSafeInteger(requested) || requested < 1 || requested > 100000)
    throw Error("Invalid page");
  const page = Math.min(requested, Math.max(1, Math.ceil(total.total / 12)));
  const order: Record<string, string> = {
    low: "p.price ASC",
    high: "p.price DESC",
    name: "p.name COLLATE NOCASE ASC",
    newest: "p.created DESC",
  };
  const products = (
    await env
      .DB!.prepare(
        "SELECT p.*,s.name AS seller,s.location,s.state,s.area,s.coverage,s.verified,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy,s.latitude,s.longitude" +
          from +
          " ORDER BY " +
          (order[text("sort")] || order.newest) +
          ",p.id ASC LIMIT 12 OFFSET ?",
      )
      .bind(...args, (page - 1) * 12)
      .all()
  ).results;
  const featured = (
    await env
      .DB!.prepare(
        "SELECT p.*,s.name AS seller,s.location,s.state,s.area,s.coverage,s.verified,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy,s.latitude,s.longitude" +
          from +
          " AND p.featured=1 ORDER BY p.created DESC,p.id ASC LIMIT 6",
      )
      .bind(...args)
      .all()
  ).results;
  return {
    featured,
    products,
    total: total.total,
    page,
    pages: Math.max(1, Math.ceil(total.total / 12)),
  };
}
