export function listingReview(store: any, products: any[]): string[] {
  const warnings: string[] = [];
  if (!store) return warnings;
  if (/\bcaptital\b/i.test(store.location || ""))
    warnings.push(
      "Confirm your saved business location: “" +
        store.location +
        "”. The area spelling needs owner review; it has not been corrected automatically.",
    );
  for (const p of products)
    if (
      (p.description || "").trim().toLowerCase() ===
      (p.name || "").trim().toLowerCase()
    )
      warnings.push(
        "Review “" +
          p.name +
          "”: confirm the product identity, description, specifications and photographs before promoting it.",
      );
  return warnings;
}
