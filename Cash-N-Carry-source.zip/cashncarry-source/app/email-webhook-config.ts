import { env } from "cloudflare:workers";
const path = "private/email-webhook-configuration";
const aad = new TextEncoder().encode("cash-n-carry:email-webhook:v1");
async function key() {
  if (!env.STREAM_CONFIG_KEY)
    throw Error("Private encryption configuration unavailable");
  return crypto.subtle.importKey(
    "raw",
    Uint8Array.from(atob(env.STREAM_CONFIG_KEY), (c) => c.charCodeAt(0)),
    "AES-GCM",
    false,
    ["encrypt", "decrypt"],
  );
}
export async function emailWebhookSecret(): Promise<string | null> {
  if (env.RESEND_WEBHOOK_SECRET) return env.RESEND_WEBHOOK_SECRET;
  if (!env.BUCKET || !env.STREAM_CONFIG_KEY) return null;
  const saved = await env.BUCKET.get(path);
  if (!saved) return null;
  const data: any = await saved.json();
  return new TextDecoder().decode(
    await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: Uint8Array.from(data.iv), additionalData: aad },
      await key(),
      Uint8Array.from(data.cipher),
    ),
  );
}
export async function saveEmailWebhookSecret(secret: string) {
  if (env.RESEND_WEBHOOK_SECRET)
    throw Error("Webhook secret is managed through server configuration");
  if (!env.BUCKET) throw Error("Private storage unavailable");
  if (
    !/^whsec_[A-Za-z0-9+/=]{20,300}$/.test(secret) ||
    atob(secret.slice(6)).length < 16
  )
    throw Error("Enter the complete webhook signing secret from Resend");
  const iv = crypto.getRandomValues(new Uint8Array(12)),
    cipher = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv, additionalData: aad },
      await key(),
      new TextEncoder().encode(secret),
    );
  await env.BUCKET.put(
    path,
    JSON.stringify({
      iv: Array.from(iv),
      cipher: Array.from(new Uint8Array(cipher)),
    }),
  );
}
