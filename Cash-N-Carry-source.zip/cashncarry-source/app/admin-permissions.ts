export type AdminRole = "owner" | "admin" | "support" | "finance" | "moderator";
export type AdminPermission =
  | "overview"
  | "customers"
  | "sellers"
  | "verification"
  | "products"
  | "orders"
  | "payments"
  | "refunds"
  | "streams"
  | "support"
  | "reports"
  | "audit"
  | "settings"
  | "roles";
const permissions: Record<AdminRole, readonly AdminPermission[]> = {
  owner: [
    "overview",
    "customers",
    "sellers",
    "verification",
    "products",
    "orders",
    "payments",
    "refunds",
    "streams",
    "support",
    "reports",
    "audit",
    "settings",
    "roles",
  ],
  admin: [
    "overview",
    "customers",
    "sellers",
    "verification",
    "products",
    "orders",
    "streams",
    "support",
    "reports",
    "audit",
  ],
  support: ["overview", "orders", "support"],
  finance: ["overview", "orders", "payments", "refunds"],
  moderator: ["overview", "products", "streams", "reports"],
};
export function canAdmin(role: AdminRole | null, permission: AdminPermission) {
  return Boolean(role && permissions[role]?.includes(permission));
}
export function adminPermissions(role: AdminRole | null) {
  return role ? [...permissions[role]] : [];
}
