"use client";
import {
  Radio,
  ShoppingBag,
  Shirt,
  Sparkles,
  Armchair,
  Headphones,
  Utensils,
  Briefcase,
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  CircleHelp,
  Compass,
  MessageCircle,
  Share2,
  Store,
} from "lucide-react";
import Link from "next/link";
import BrandLogo from "./brand-logo";
import ImageAsset from "./image-asset";
export function ShoppingHero({
  onLive,
  onShop,
  liveCount = 0,
}: {
  onLive: () => void;
  onShop: () => void;
  liveCount?: number;
}) {
  return (
    <section className="shopping-hero">
      <div className="hero-copy">
        <p className="eyebrow"><span className="hero-live-dot" aria-hidden="true" /> CASH N CARRY MARKETPLACE</p>
        <h1>Good finds from Nigerian sellers.</h1>
        <p>Explore local storefronts, browse products and watch sellers demonstrate their finds.</p>
        <div className="hero-actions">
          <button className="primary" onClick={onShop}>
            <ShoppingBag size={19} aria-hidden="true" /> Browse products
          </button>
          <button className="secondary-button homepage-live-button" onClick={onLive} aria-label={liveCount > 0 ? `Watch live shopping: ${liveCount} sellers live now` : "Watch live shopping"}>
            <Radio size={19} aria-hidden="true" /> Watch live{liveCount > 0 ? ` · ${liveCount} live` : ""}
          </button>
        </div>
      </div>
      <div className="hero-photo">
        <ImageAsset
          src="/seller-hero-640.webp"
          srcSet="/seller-hero-640.webp 640w, /seller-hero.webp 1050w"
          sizes="(max-width: 767px) 100vw, (max-width: 1100px) 45vw, 550px"
          alt="Illustrative Nigerian seller demonstrating a leather handbag to a phone camera"
          width={1050}
          height={700}
          loading="eager"
          fetchPriority="high"
        />
        <div className="hero-photo-caption"><span>THE LIVE SHOPPING EXPERIENCE</span><strong>A closer look before you choose.</strong><small>Illustrative seller demonstration</small></div>
      </div>
    </section>
  );
}
const desktopChoices = [
  { label: "Fashion", stored: "Fashion", term: "", Icon: Shirt },
  { label: "Bags", stored: "Bags", term: "", Icon: ShoppingBag },
  { label: "Beauty", stored: "Beauty", term: "", Icon: Sparkles },
  { label: "Home", stored: "Home", term: "", Icon: Armchair },
  { label: "Electronics", stored: "Tech", term: "", Icon: Headphones },
];
const mobileChoices = [
  { label: "Fashion", stored: "Fashion", term: "", Icon: Shirt },
  { label: "Beauty", stored: "Beauty", term: "", Icon: Sparkles },
  { label: "Food", stored: "Food", term: "", Icon: Utensils },
  { label: "Tech", stored: "Tech", term: "", Icon: Headphones },
  { label: "Home", stored: "Home", term: "", Icon: Armchair },
  { label: "Services", stored: "Services", term: "", Icon: Briefcase },
];
export function ShopCategories({
  products,
  onSelect,
  mobileVariant = false,
}: {
  products: { category: string; name: string; image: string }[];
  onSelect: (label: string, stored: string, term: string) => void;
  mobileVariant?: boolean;
}) {
  const choices = mobileVariant ? mobileChoices : desktopChoices;
  return (
    <section className="shop-categories">
      <div className="section-heading">
        <h2>Shop by category</h2>
      </div>
      <div className="shopping-category-grid">
        {choices.map(({ label, stored, term, Icon }) => {
          const p = products.find(
            (p) =>
              p.category === stored &&
              (!term || p.name.toLowerCase().includes(term)),
          );
          return (
            <button key={label} onClick={() => onSelect(label, stored, term)}>
              <span className="category-visual">
                {p && <ImageAsset src={p.image} alt={`${label}: ${p.name}`} loading="lazy" />}
                <Icon className="category-fallback-icon" size={34} strokeWidth={1.5} aria-hidden="true" />
              </span>
              <strong>{label}</strong>
            </button>
          );
        })}
      </div>
    </section>
  );
}
export function ShoppingGuide({ onShop, onLive }: { onShop: () => void; onLive: () => void }) {
  return <section className="shopping-guide" aria-labelledby="shopping-guide-title">
    <div className="shopping-guide-cta">
      <div className="shopping-guide-copy">
        <p className="shopping-guide-eyebrow">MADE FOR THE WAY NIGERIA SHOPS</p>
        <h2 id="shopping-guide-title">Meet your next Nigerian favourite.</h2>
        <p>Find independent sellers, see products in action and shop with the details you need before checkout.</p>
        <div className="shopping-guide-actions">
          <button type="button" className="shopping-guide-primary" onClick={onShop}><ShoppingBag size={18} aria-hidden="true" /> Explore the shop <ArrowRight size={17} aria-hidden="true" /></button>
          <button type="button" className="shopping-guide-secondary" onClick={onLive}><Radio size={17} aria-hidden="true" /> Watch live</button>
        </div>
      </div>
      <div className="shopping-guide-steps" aria-label="How Cash N Carry shopping works">
        <article><span><Compass size={19} aria-hidden="true" /></span><div><strong>Discover</strong><p>Browse products and seller storefronts.</p></div></article>
        <article><span><MessageCircle size={19} aria-hidden="true" /></span><div><strong>See it up close</strong><p>Watch a live demo and ask questions.</p></div></article>
        <article><span><ShoppingBag size={19} aria-hidden="true" /></span><div><strong>Choose with confidence</strong><p>Review options, delivery and total at checkout.</p></div></article>
      </div>
    </div>
    <div className="shopping-guide-lower">
      <div className="shopping-guide-note">
        <span className="shopping-guide-note-icon"><BadgeCheck size={18} aria-hidden="true" /></span>
        <div><h3>Know who you’re buying from</h3><p>Seller pages show their products and available details. A Verified Seller badge means their verification was approved; it is not a guarantee of a particular product or transaction.</p></div>
      </div>
      <section className="shopping-faq" aria-labelledby="shopping-faq-title">
        <h3 id="shopping-faq-title"><CircleHelp size={19} aria-hidden="true" /> Quick answers</h3>
        <details><summary>How do delivery fees work?</summary><p>Delivery coverage and fees vary by seller and destination. Enter your delivery address and review the shipping charge in the checkout summary before placing an order.</p></details>
        <details><summary>Can I ask a seller about an item?</summary><p>Yes. Use the product or live comments for questions, or sign in and message the seller for a private product enquiry.</p></details>
        <details><summary>Where can I get help with an order?</summary><p>Check your order details and contact the seller about the item. For platform guidance, visit <Link href="/help">Help &amp; contact</Link>. Review the <Link href="/delivery">delivery</Link> and <Link href="/refunds">returns policies</Link> before ordering.</p></details>
      </section>
    </div>
  </section>;
}

export function HomeFooter({ onShop, onLive }: { onShop: () => void; onLive: () => void }) {
  return <footer className="home-footer">
    <div className="home-footer-main">
      <div className="home-footer-brand">
        <BrandLogo tagline />
        <p>Discover Nigerian sellers through products, videos and live shopping.</p>
        <Link href="/social" className="home-footer-social"><Share2 size={17} aria-hidden="true" /><span>Social channels</span><ArrowUpRight size={15} aria-hidden="true" /></Link>
      </div>
      <nav className="home-footer-column" aria-label="Shop links"><h2>Shop</h2><button type="button" onClick={onShop}>Browse products</button><button type="button" onClick={onLive}>Watch live</button><a href="/help">How shopping works</a></nav>
      <nav className="home-footer-column" aria-label="Seller links"><h2>For sellers</h2><a href="/start-selling"><Store size={15} aria-hidden="true" /> Start selling</a><a href="/seller">Seller Centre</a><a href="/seller-terms">Seller terms</a></nav>
      <nav className="home-footer-column" aria-label="Support links"><h2>Help &amp; policies</h2><a href="/help">Help &amp; contact</a><a href="/delivery">Delivery</a><a href="/refunds">Returns &amp; refunds</a><a href="/privacy">Privacy</a><a href="/terms">Terms</a><a href="/community-guidelines">Community guidelines</a></nav>
    </div>
    <div className="home-footer-bottom"><span>© {new Date().getFullYear()} Cash N Carry</span><span>Shop local. Shop with care.</span></div>
  </footer>;
}
