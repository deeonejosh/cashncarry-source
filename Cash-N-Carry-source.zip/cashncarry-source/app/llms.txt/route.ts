export function GET(){return new Response(`# Cash N Carry

Cash N Carry is a Nigerian marketplace for product discovery and livestream shopping. Prices are displayed in Nigerian naira. Independent sellers manage their listings and fulfil orders.

## Public information
- [Homepage](https://cashncarryng.com/)
- [Help](https://cashncarryng.com/help)
- [Terms](https://cashncarryng.com/terms)
- [Delivery](https://cashncarryng.com/delivery)
- [Returns and refunds](https://cashncarryng.com/refunds)
- [Privacy](https://cashncarryng.com/privacy)
- [Public sitemap](https://cashncarryng.com/sitemap.xml)

Product stock, prices and live availability change. Check current product pages before purchasing.
`,{headers:{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"public,max-age=3600"}});}
