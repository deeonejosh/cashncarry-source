import VerifiedSellerBadge from "../../verified-seller-badge";
import { sellerActivation, eligibleSellerSQL } from "../../seller-activation";
import { ensureCompetitiveSchema } from "../../competitive-schema";
import { CustomerHeader, CustomerNavigation } from "../../customer-shell";
import StoreActions from "../../store-actions";
import StoreProductActions from "../../store-product-actions";
import { getChatGPTUser } from "../../chatgpt-auth";
import ImageAsset from "../../image-asset";
import { brand } from "../../brand";
import { broadcastLabel } from "../../broadcasts";
import { env } from "cloudflare:workers";
import { notFound } from "next/navigation";
import { Search } from "lucide-react";
const scheduleCutoff = () => new Date(Date.now() - 86400000).toISOString();
export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const paramId = (await params).id;
  const s: any = await env.DB?.prepare(
    "SELECT COALESCE(NULLIF(f.display_name,''),s.name) AS name,COALESCE(NULLIF(f.description,''),s.description) AS description,f.slug,f.banner FROM stores s LEFT JOIN storefronts f ON f.store=s.id WHERE (s.id=? OR (f.slug=? AND f.published=1)) AND s.suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
  ).bind(paramId, paramId.toLowerCase()).first();
  const title = `${s?.name || "Store unavailable"} | ${brand.name}`;
  const canonical = "/store/" + (s?.slug || paramId);
  return {
    title,
    alternates: { canonical },
    description: s?.description,
    openGraph: { url: canonical, title, siteName: brand.name, description: s?.description, images: s?.banner ? [s.banner] : undefined },
  };
}
export default async function Store({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ q?: string; category?: string }>;
}) {
  await ensureCompetitiveSchema();
  const { id } = await params;
  const filters = await searchParams;
  const term = String(filters.q || "").trim().slice(0, 100);
  const category = String(filters.category || "").trim().slice(0, 60);
  const s: any = await env.DB?.prepare(
    "SELECT s.id,s.owner,COALESCE(NULLIF(CASE WHEN f.published=1 THEN f.display_name END,''),s.name) AS name,COALESCE(NULLIF(CASE WHEN f.published=1 THEN f.description END,''),s.description) AS description,COALESCE(NULLIF(CASE WHEN f.published=1 THEN f.category END,''),s.category) AS category,s.location,s.verified,CASE WHEN f.published=1 THEN f.slug END AS slug,CASE WHEN f.published=1 THEN f.logo END AS logo,CASE WHEN f.published=1 THEN f.banner END AS banner,CASE WHEN f.published=1 THEN f.template END AS template,CASE WHEN f.published=1 THEN f.accent END AS accent,CASE WHEN f.published=1 THEN f.featured_products END AS featured_products,EXISTS(SELECT 1 FROM founding_enrollments fe JOIN founding_program fp ON fp.id=1 WHERE fe.store=s.id AND fe.status='active' AND fp.enabled=1 AND fe.starts_at<=strftime('%Y-%m-%dT%H:%M:%fZ','now') AND fe.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now')) AS founding_seller FROM stores s LEFT JOIN storefronts f ON f.store=s.id WHERE (s.id=? OR (f.slug=? AND f.published=1)) AND s.suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
  )
    .bind(id, id.toLowerCase())
    .first();
  if (!s) notFound();
  const allProducts = (
    await env
      .DB!.prepare(
        "SELECT id,name,description,category,image,price,video,stock,variants FROM products WHERE store=? AND active=1 AND store IN (SELECT s.id FROM stores s WHERE " + eligibleSellerSQL() + ")",
      )
      .bind(s.id)
      .all<any>()
  ).results;
  const categories = [...new Set(allProducts.map((p: any) => p.category).filter(Boolean))].sort();
  const products = allProducts.filter((p: any) =>
    (!category || p.category === category) &&
    (!term || `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(term.toLowerCase())),
  );
  const [reviews, reviewSummary] = await Promise.all([
    env.DB!.prepare(
      "SELECT r.name,r.rating,r.comment,r.created,p.name AS product FROM reviews r JOIN products p ON p.id=r.product JOIN orders o ON o.id=r.order_id WHERE p.store=? AND o.status='delivered' ORDER BY r.created DESC LIMIT 20",
    ).bind(s.id).all<any>(),
    env.DB!.prepare(
      "SELECT COUNT(*) AS count,COALESCE(AVG(r.rating),0) AS average FROM reviews r JOIN products p ON p.id=r.product JOIN orders o ON o.id=r.order_id WHERE p.store=? AND o.status='delivered'",
    ).bind(s.id).first<any>(),
  ]);
  const ratingCount = Number(reviewSummary?.count || 0);
  const rating = Number(reviewSummary?.average || 0);
  const streams = (
    await env
      .DB!.prepare(
        "SELECT id,title,scheduled,status,provider,replay,url FROM streams WHERE store=? AND store IN (SELECT s.id FROM stores s WHERE " + eligibleSellerSQL() + ") AND (status IN ('live','scheduled','external') OR (status='ended' AND replay!='')) AND NOT (provider='native' AND status='live' AND COALESCE(julianday(heartbeat),0)<julianday('now','-90 seconds')) AND NOT (status='scheduled' AND (scheduled='' OR scheduled<?)) ORDER BY created DESC LIMIT 30",
      )
      .bind(s.id, scheduleCutoff())
      .all<any>()
  ).results;
  const videos = (await env.DB!.prepare("SELECT v.id,v.media,v.thumbnail,v.caption,v.created FROM videos v JOIN stores st ON st.id=v.store WHERE v.store=? AND v.status='approved' AND v.published=1 AND " + eligibleSellerSQL("st") + " AND NOT EXISTS(SELECT 1 FROM media_blocks mb WHERE mb.key=substr(v.media,instr(v.media,'/api/media/')+11)) ORDER BY v.created DESC LIMIT 30").bind(s.id).all<any>()).results;
  const featuredIds: string[] = JSON.parse(s.featured_products || "[]");
  const featured = featuredIds.length ? allProducts.filter((p: any) => featuredIds.includes(p.id)) : products.slice(0, 4);
  const activation = await sellerActivation(s.id);
  const user = await getChatGPTUser();
  const following = user
    ? Boolean(
        await env
          .DB!.prepare("SELECT id FROM follows WHERE user=? AND store=?")
          .bind(user.userId, s.id)
          .first(),
      )
    : false;
  const storeQuery = new URLSearchParams();
  if (term) storeQuery.set("q", term);
  if (category) storeQuery.set("category", category);
  const storeReturnTo = `/store/${encodeURIComponent(s.slug || s.id)}${storeQuery.size ? `?${storeQuery.toString()}` : ""}#store-products`;
  const productLink = (productId: string) => `/product/${encodeURIComponent(productId)}?returnTo=${encodeURIComponent(storeReturnTo)}`;
  return (
    <>
      <CustomerHeader active="Shop" />
      <main
        id="main-content"
        tabIndex={-1}
        className={`customer-page storefront-page template-${s.template || "market"}`}
        style={{ "--store-accent": s.accent || "#164B35" } as React.CSSProperties}
      >
        <section className="storefront-heading design-card">
          {s.banner && <div className="storefront-banner" style={{ backgroundImage: `linear-gradient(90deg,rgba(22,75,53,.84),rgba(22,75,53,.08)),url("${s.banner.replaceAll('"', '%22')}")` }} />}
          {s.logo ? <ImageAsset src={s.logo} alt={s.name + " logo"} width="72" height="72" /> : <span className="store-avatar" aria-hidden="true">{s.name.slice(0, 1)}</span>}
          <h1 className="seller-identity"><span className="seller-name-text">{s.name}</span><VerifiedSellerBadge verified={s.verified} variant="full"/></h1>
          <p>{s.description}</p>
          <p>
            {s.location}
            {s.verified ? " · Business verification approved" : ""}
            {s.founding_seller ? " · Founding Seller" : ""}
          </p>
          <StoreActions id={s.id} following={following} shareUrl={"/store/" + (s.slug || s.id)} />
        </section>
        <nav className="storefront-tabs" aria-label="Storefront sections">
          {featured.length > 0 && <a href="#store-featured">Featured</a>}
          <a href="#store-products">Products</a>
          {ratingCount > 0 && <a href="#store-reviews">Reviews</a>}
          {(products.some((p) => p.video) || videos.length > 0) && <a href="#store-videos">Videos</a>}
          {streams.length > 0 && <a href="#store-broadcasts">Broadcasts</a>}
        </nav>
        {featured.length > 0 && <><h2 id="store-featured">Featured products</h2><div className="storefront-product-grid">{featured.map((p: any) => <article className="storefront-product design-card" key={p.id}><ImageAsset src={p.image} alt={p.name} width="160" height="160"/><a href={productLink(p.id)}>{p.name} · ₦{p.price.toLocaleString()}</a></article>)}</div></>}
        <h2 id="store-products">Products</h2>
        <form method="get" className="storefront-filter" role="search" aria-label="Search this store">
          <label>Search products<input name="q" type="search" defaultValue={term} placeholder="Search this store" /></label>
          <label>Category<select name="category" defaultValue={category}><option value="">All categories</option>{categories.map((value: string) => <option key={value} value={value}>{value}</option>)}</select></label>
          <button type="submit"><Search size={17} /> Filter products</button>
          {(term || category) && <a href={`/store/${id}#store-products`}>Clear filters</a>}
        </form>
        <div className="storefront-product-grid">
          {products.length ? (
            products.map((p) => (
              <article className="storefront-product design-card" key={p.id}>
                <ImageAsset
                  src={p.image}
                  alt={p.name}
                  width="160"
                  height="160"
                />
                <a href={productLink(p.id)}>
                  {p.name} · ₦{p.price.toLocaleString()}
                </a>
                <StoreProductActions
                  product={p}
                  storeId={s.id}
                  signedIn={!!user}
                />
              </article>
            ))
          ) : (
            <p>{activation.canSell ? "No products listed yet." : "This store is not accepting new orders right now. You can still contact the seller about an existing order."}</p>
          )}
        </div>
        {ratingCount > 0 && <section id="store-reviews" className="storefront-reviews">
          <h2>Customer reviews</h2>
          <p><strong>{rating.toFixed(1)} / 5</strong> average from {ratingCount} delivered-order {ratingCount === 1 ? "review" : "reviews"}</p>
          <p>Star ratings and written comments are submitted separately by verified buyers.</p>
          {reviews.results.map((review: any, index: number) => <article className="design-card" key={`${review.created}-${index}`}>
            <h3>Verified buyer · {review.rating}/5</h3><p>Purchased: {review.product}</p><p>{review.comment}</p><small>{new Date(review.created).toLocaleDateString("en-NG")}</small>
          </article>)}
        </section>}
        {(products.some((p) => p.video) || videos.length > 0) && <><h2 id="store-videos">Product videos</h2>
        <div className="storefront-product-grid">
          {videos.length ? videos.map((v: any) => <article className="design-card" key={v.id}><video src={v.media} poster={v.thumbnail || undefined} controls playsInline preload="none" aria-label={v.caption || "Seller product video"}/><p>{v.caption}</p><a href={`/for-you?v=${encodeURIComponent(v.id)}`}>Open in For You</a></article>) : products.filter((p) => p.video).length ? (
            products
              .filter((p) => p.video)
              .map((p) => (
                <article className="design-card" key={p.id}>
                  <h3>{p.name}</h3>
                  <video
                    src={p.video}
                    controls
                    playsInline
                    preload="none"
                    aria-label={p.name + " video"}
                  />
                  <a href={productLink(p.id)}>View product</a>
                </article>
              ))
          ) : (
            <p>No product videos yet.</p>
          )}
        </div>
        </>}
        {streams.length > 0 && <><h2 id="store-broadcasts">Broadcasts</h2>
        <div className="storefront-broadcast-grid">
          {streams.length ? (
            streams.map((x: any) => (
              <article key={x.id}>
                <h3>{x.title}</h3>
                <p>
                  {broadcastLabel(x)}
                  {x.status === "scheduled" && x.scheduled
                    ? " · " +
                      new Date(x.scheduled).toLocaleString("en-NG", {
                        timeZone: "Africa/Lagos",
                      }) +
                      " WAT"
                    : ""}
                </p>
                {x.status === "ended" && !x.replay ? (
                  <p>Session ended. No replay is available.</p>
                ) : x.provider === "tiktok" && x.status === "external" ? (
                  <a href={x.url} target="_blank" rel="noopener noreferrer">
                    Watch on TikTok
                  </a>
                ) : (
                  <a href={"/?stream=" + encodeURIComponent(x.id)}>
                    {x.status === "ended"
                      ? "Watch replay"
                      : x.status === "scheduled"
                        ? "View scheduled broadcast"
                        : "Watch live"}
                  </a>
                )}
              </article>
            ))
          ) : (
            <p>No broadcasts scheduled.</p>
          )}
        </div></>}
      </main>
      <CustomerNavigation active="Shop" />
    </>
  );
}
