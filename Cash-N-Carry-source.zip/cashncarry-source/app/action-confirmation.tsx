"use client";
import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
export default function ActionConfirmation({ title, description, busy, error, onCancel, onConfirm }: { title: string; description: string; busy: boolean; error?: string; onCancel: () => void; onConfirm: (reason: string) => Promise<void> }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [reason, setReason] = useState("");
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const element = dialog.current;
    if (element && !element.open) element.showModal();
    return () => { element?.close(); previous?.focus({ preventScroll: true }); };
  }, []);
  return <dialog ref={dialog} className="action-dialog" aria-labelledby="confirmation-title" aria-describedby="confirmation-description" onCancel={e => { e.preventDefault(); if (!busy) onCancel(); }}>
    <header><h2 id="confirmation-title">{title}</h2><button type="button" className="icon-control" disabled={busy} aria-label="Close confirmation" onClick={onCancel}><X size={20} /></button></header>
    <p id="confirmation-description">{description}</p>
    {error && <p className="finance-alert" role="alert">{error}</p>}
    <form onSubmit={e => { e.preventDefault(); if (!busy && reason.trim().length >= 5) void onConfirm(reason.trim()); }}>
      <label htmlFor="confirmation-reason">Reason for this decision<textarea id="confirmation-reason" autoFocus minLength={5} maxLength={500} required value={reason} disabled={busy} onChange={e => setReason(e.target.value)} aria-describedby="confirmation-reason-help" /></label>
      <small id="confirmation-reason-help">This reason will be recorded in the admin audit trail.</small>
      <footer><button type="button" className="secondary-button" disabled={busy} onClick={onCancel}>Cancel</button><button className="primary" disabled={busy || reason.trim().length < 5}>{busy ? "Saving…" : "Confirm decision"}</button></footer>
    </form>
  </dialog>;
}
