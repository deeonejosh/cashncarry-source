"use client";
import { useEffect, useRef, useState } from "react";
import BrandLogo from "../brand-logo";
import { safeReturnPath, mfaSignInPath } from "../auth-navigation";
export default function MfaForm() {
  const [enroll, setEnroll] = useState(false),
    [backup, setBackup] = useState(false),
    [uri, setUri] = useState(""),
    [codes, setCodes] = useState<string[]>([]),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const destination = useRef("/account");
  const [returnTo,setReturnTo]=useState("/account");
  const [chatgpt,setChatgpt]=useState(false),[challengeReady,setChallengeReady]=useState(false);
  useEffect(() => {
    const p = new URLSearchParams(location.search);
    setEnroll(p.get("enroll") === "1");
    destination.current = safeReturnPath(p.get("returnTo") || "/account");
    setReturnTo(destination.current);
    setChatgpt(p.get("chatgpt")==="1");
  }, []);
  async function startChallenge() {
    if(busy)return;
    setBusy(true);setError("");setChallengeReady(false);
    try {
      const r=await fetch("/api/auth/admin/chatgpt-challenge",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}",signal:AbortSignal.timeout(15000)});
      const d:any=await r.json().catch(()=>null);
      if(!r.ok || !d?.status)throw Error(d?.message || "Unable to start admin verification. Try again.");
      setChallengeReady(true);
    }catch(e){setError(e instanceof Error?e.message:"Unable to start verification");}
    finally{setBusy(false);}
  }
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;
    const f = new FormData(e.currentTarget);
    setBusy(true);
    setError("");
    try {
      const setup = enroll && !uri;
      const response = await fetch(
        "/api/auth/two-factor/" +
          (setup ? "enable" : backup ? "verify-backup-code" : "verify-totp"),
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(
            setup
              ? { password: f.get("password"), method: "totp" }
              : { code: f.get("code"), trustDevice: false },
          ),
          signal: AbortSignal.timeout(15000),
        },
      );
      const data: any = await response.json().catch(() => null);
      if (!response.ok || !data)
        throw Error(
          /two.?factor cookie/i.test(data?.message || "") ? (chatgpt ? "Your verification session expired. Reload this page and choose Continue to authenticator to request a fresh challenge." : "Your verification session has expired or is missing. Sign in with your Cash N Carry email and password, then use a current authenticator code.") : data?.message ||
            "Unable to verify. Sign in with your email account and retry.",
        );
      if (setup) {
        if (!data.totpURI) throw Error("Authenticator setup was not confirmed");
        setUri(data.totpURI);
        setCodes(data.backupCodes || []);
      } else {
        window.location.assign(destination.current);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Verification failed");
    } finally {
      setBusy(false);
    }
  }
  const secret = uri ? new URL(uri).searchParams.get("secret") : "";
  return (
    <main id="main-content" tabIndex={-1} className="entry-shell">
      <section className="entry-panel">
        <BrandLogo tagline />
        <h1>
          {enroll ? "Secure your admin account" : "Two-step verification"}
        </h1>
        <p>
          {chatgpt ? "Your ChatGPT identity is signed in. Verify your existing Cash N Carry authenticator to unlock admin access." : "Admin access requires a verified email account and an authenticator code. ChatGPT sign-in alone does not unlock the Admin Console."}
        </p>
        {enroll && !uri ? (
          <p>
            Sign in with your Cash N Carry email account, then enter its
            password to set up an authenticator app.
          </p>
        ) : null}
        {uri ? (
          <>
            <p>
              Add an account in your authenticator app using this setup key.
              Keep it private.
            </p>
            <code style={{ overflowWrap: "anywhere" }}>{secret}</code>
            <p>Issuer: Cash N Carry. Time based, 6 digits, 30-second period.</p>
            <details>
              <summary>Save recovery codes securely</summary>
              <p>
                Each code can be used once if you lose your authenticator. Store
                them outside this device.
              </p>
              <pre>{codes.join("\n")}</pre>
            </details>
          </>
        ) : null}
        {chatgpt && !challengeReady ? <button className="entry-primary" onClick={startChallenge} disabled={busy}>{busy?"Preparing verification…":"Continue to authenticator"}</button> : <form onSubmit={submit}>
          {enroll && !uri ? (
            <label>
              Account password
              <input
                name="password"
                type="password"
                autoComplete="current-password"
                required
              />
            </label>
          ) : (
            <label>
              {backup ? "Recovery code" : "Authenticator code"}
              <input
                name="code"
                autoComplete="one-time-code"
                inputMode={backup ? "text" : "numeric"}
                pattern={backup ? undefined : "[0-9]{6}"}
                required
              />
            </label>
          )}
          <button className="entry-primary" disabled={busy}>
            {busy
              ? "Checking…"
              : enroll && !uri
                ? "Set up authenticator"
                : "Verify and continue"}
          </button>
        </form>}
        {error ? (
          <p role="alert" className="notice">
            {error}
          </p>
        ) : null}
        {!enroll && (!chatgpt || challengeReady) ? (
          <button
            className="entry-secondary"
            onClick={() => setBackup(!backup)}
          >
            {backup ? "Use authenticator" : "Use a recovery code"}
          </button>
        ) : null}
        <a
          className="entry-secondary"
          href={mfaSignInPath(returnTo,enroll)}
        >
          Sign in with email
        </a>
        <a href="/account">Return to Account</a>
      </section>
    </main>
  );
}
