import MfaForm from "./form";
export const metadata = {
  title: "Account security | Cash N Carry",
  robots: { index: false, follow: false },
};
export default function Page() {
  return <MfaForm />;
}
