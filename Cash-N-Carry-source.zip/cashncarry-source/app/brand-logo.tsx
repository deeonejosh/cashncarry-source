import { brand } from "./brand";
import Link from "next/link";

export default function BrandLogo({ tagline = false, compact = false }: { tagline?: boolean; compact?: boolean }) {
  return (
    <Link href="/" className={`brand-logo${compact ? " brand-logo--compact" : ""}`} aria-label="Cash N Carry home">
      <picture>
        {compact && <source media="(max-width: 374px)" srcSet={brand.symbol} />}
        <source type="image/webp" srcSet="/brand/cash-n-carry-logo.webp" />
        <img src={brand.logo} width={brand.logoWidth} height={brand.logoHeight} alt="Cash N Carry" decoding="async" />
      </picture>
      {tagline && <span className="brand-logo-tagline">{brand.tagline}</span>}
    </Link>
  );
}
