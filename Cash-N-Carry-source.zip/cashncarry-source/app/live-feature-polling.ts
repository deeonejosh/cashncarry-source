/** One request at a time; pause hidden viewers and abort work on studio exit. */
export function startLiveFeaturePolling(url: string, receive: (data: any) => void) {
  let stopped = false;
  let controller: AbortController | null = null;
  const refresh = async () => {
    if (stopped || controller || document.visibilityState === "hidden") return;
    const request = new AbortController();
    controller = request;
    const timeout = setTimeout(() => request.abort(), 10000);
    try {
      const response = await fetch(url, { cache: "no-store", signal: request.signal });
      if (!response.ok) return; // Preserve last known offers after transient failure.
      const data = await response.json();
      if (!stopped && !request.signal.aborted) receive(data);
    } catch { /* A later tick retries; commerce remains independently available. */ }
    finally { clearTimeout(timeout); if (controller === request) controller = null; }
  };
  const visibility = () => {
    if (document.visibilityState === "hidden") controller?.abort();
    else void refresh();
  };
  void refresh();
  const interval = setInterval(refresh, 5000);
  document.addEventListener("visibilitychange", visibility);
  return () => {
    stopped = true;
    clearInterval(interval);
    controller?.abort();
    document.removeEventListener("visibilitychange", visibility);
  };
}
