import SkipLink from "./skip-link";
import AnalyticsConsent from "./analytics-consent";
import { brand } from "./brand";
import { env } from "cloudflare:workers";
import type { Metadata } from "next";
import "./globals.css";
import "./design-system.css";
import "./premium.css";
import "./dashboard-redesign.css";
import "./shop-redesign.css";

const publicSiteUrl = env.SITE_URL || "https://cashncarryng.com";

export const metadata: Metadata = {
  metadataBase: new URL(publicSiteUrl),
  alternates: { canonical: "/" },
  title: `${brand.name} — Live Shopping & Online Marketplace Nigeria`,
  description: brand.description,
  manifest: "/api/manifest",
  applicationName: brand.name,
  appleWebApp: { title: brand.name },
  openGraph: {
    title: `${brand.name} — Live Shopping & Online Marketplace Nigeria`,
    siteName: brand.name,
    description: brand.description,
    type: "website",
    url: "/",
    images: [
      {
        url: "/seller-hero.webp",
        width: 1050,
        height: 700,
        alt: "A Nigerian seller presenting a handbag in her shop",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: `${brand.name} — Live Shopping & Online Marketplace Nigeria`,
    description: brand.description,
    images: ["/seller-hero.webp"],
  },
  icons: {
    icon: [{ url: "/brand/favicon-32.png", sizes: "32x32", type: "image/png" }, { url: "/favicon.ico", sizes: "48x48" }],
    shortcut: "/brand/favicon-32.png",
    apple: "/brand/apple-touch-icon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head><link rel="sitemap" type="application/xml" href="/sitemap.xml" /></head>
      <body className="antialiased">
        <SkipLink />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@graph": [
                {"@type":"Organization","@id":new URL("/#organization",publicSiteUrl).href,name:brand.name,url:publicSiteUrl,description:brand.description,logo:new URL(brand.logo,publicSiteUrl).href,areaServed:{"@type":"Country",name:"Nigeria"},contactPoint:{"@type":"ContactPoint",contactType:"customer support",url:new URL("/help",publicSiteUrl).href,availableLanguage:"English"}},
                {"@type":"WebSite","@id":new URL("/#website",publicSiteUrl).href,name:brand.name,description:brand.description,url:publicSiteUrl,inLanguage:"en",publisher:{"@id":new URL("/#organization",publicSiteUrl).href}}
              ],
            }).replace(/</g, "\\u003c"),
          }}
        />
        <AnalyticsConsent />
        {children}
      </body>
    </html>
  );
}
