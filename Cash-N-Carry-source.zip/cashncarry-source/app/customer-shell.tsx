"use client";
import { useEffect, useState } from "react";
import {
  Home,
  Radio,
  ShoppingBag,
  UserRound,
  ShoppingCart,
  ArrowLeft,
  Search,
  MessageSquare,
} from "lucide-react";
import Link from "next/link";
import BrandLogo from "./brand-logo";
const links = [
  ["Home", "/?browse=1#home", Home],
  ["Shop", "/?browse=1#market", ShoppingBag],
  ["Live", "/live", Radio],
  ["Bag", "/?browse=1&open=cart", ShoppingCart],
  ["Account", "/account", UserRound],
] as const;
export function CustomerHeader({
  active = "",
  back = "/?browse=1#market",
}: {
  active?: string;
  back?: string;
}) {
  return (
    <header className="customer-header">
      <a href={back} className="icon-control" aria-label="Back to shopping">
        <ArrowLeft size={22} />
      </a>
      <BrandLogo />
      <Link className="customer-search-link" href="/?browse=1#market"><Search size={18} aria-hidden="true" /><span>Search products and sellers</span></Link>
      <nav aria-label="Customer navigation">
        {[...links.filter(([label]) => label !== "Bag").slice(0, 3), ["For You", "/for-you", Home] as const, links[4]].map(([label, href]) => (
          <a
            key={label}
            href={href}
            aria-current={active === label ? "page" : undefined}
          >
            {label}
          </a>
        ))}
      </nav>
      <Link href="/messages" className="icon-control" aria-label="Buyer and seller messages"><MessageSquare size={22} /></Link>
      <Link
        href="/?browse=1&open=cart"
        className="icon-control customer-cart"
        aria-label="Open bag"
      >
        <ShoppingCart size={23} />
      </Link>
    </header>
  );
}
export function CustomerNavigation({ active = "" }: { active?: string }) {
  const [bagCount, setBagCount] = useState(0);
  useEffect(() => {
    let alive = true;
    const loadBagCount = async () => {
      try {
        const response = await fetch("/api/commerce", { cache: "no-store" });
        const data = await response.json() as { cart?: Array<{ quantity?: number }> };
        if (alive && response.ok) setBagCount((data.cart || []).reduce((sum: number, item: any) => sum + Number(item.quantity || 0), 0));
      } catch { /* Navigation remains usable if the count cannot load. */ }
    };
    void loadBagCount();
    window.addEventListener("focus", loadBagCount);
    return () => { alive = false; window.removeEventListener("focus", loadBagCount); };
  }, []);
  return (
    <nav className="customer-bottom-nav" aria-label="Customer navigation">
      {links.map(([label, href, Icon]) => (
        <a
          key={label}
          href={href}
          aria-current={active === label ? "page" : undefined}
          aria-label={label === "Bag" && bagCount ? `Bag, ${bagCount} items` : label}
        >
          <Icon size={22} aria-hidden="true" />
          <span>{label}</span>
          {label === "Bag" && bagCount > 0 && <b className="customer-bag-count">{bagCount}</b>}
        </a>
      ))}
    </nav>
  );
}
export function PageHeading({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="design-page-heading">
      <div>
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {children}
    </div>
  );
}
