import { safeReturnPath } from "./auth-navigation";
export const CART_RESUME_KEY = "cash-n-carry:pending-cart:v1";
export type CartIntent = {
  id: string;
  product: string;
  variant: string;
  quantity: number;
  intent?: "cart" | "buy-now";
  created: number;
  returnTo: string;
};
export function readCartIntent(
  storage: Pick<Storage, "getItem" | "removeItem">,
): CartIntent | null {
  try {
    const p = JSON.parse(storage.getItem(CART_RESUME_KEY) || "null");
    if (!p) return null;
    if (
      !/^[a-f0-9-]{36}$/.test(p.id) ||
      typeof p.product !== "string" ||
      !p.product ||
      typeof p.variant !== "string" ||
      !Number.isInteger(p.quantity) ||
      p.quantity < 1 ||
      p.quantity > 99 ||
      typeof p.created !== "number" ||
      Date.now() - p.created > 3600000 ||
      p.created > Date.now() + 60000
    ) {
      storage.removeItem(CART_RESUME_KEY);
      return null;
    }
    return {
      ...p,
      intent: p.intent === "buy-now" ? "buy-now" : "cart",
      returnTo: safeReturnPath(p.returnTo),
    };
  } catch {
    return null;
  }
}
export function preserveCartForSignIn(
  product: string,
  variant: string,
  quantity: number,
  returnTo: string,
  actionIntent: "cart" | "buy-now" = "cart",
) {
  try {
    const intent: CartIntent = {
      id: crypto.randomUUID(),
      product,
      variant,
      quantity,
      intent: actionIntent,
      created: Date.now(),
      returnTo: safeReturnPath(returnTo),
    };
    sessionStorage.setItem(CART_RESUME_KEY, JSON.stringify(intent));
    const destination =
      "/?browse=1&resumeCart=" + encodeURIComponent(intent.id) + "#market";
    window.location.assign(
      "/sign-in?returnTo=" + encodeURIComponent(destination),
    );
  } catch {
    throw Error(
      "Your browser could not preserve this selection. Allow session storage and retry.",
    );
  }
}
