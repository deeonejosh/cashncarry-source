"use client";
import { useEffect, useState } from "react";
import { scheduleText } from "./broadcasts";
export default function ScheduleInfo({ scheduled }: { scheduled?: string }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const timer = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(timer);
  }, []);
  const time = Date.parse(scheduled || "");
  const minutes = now === null ? null : Math.ceil((time - now) / 60000);
  return (
    <div className="schedule-info">
      <p>{scheduleText(scheduled)}</p>
      {minutes !== null && Number.isFinite(minutes) && (
        <p role="status">
          {minutes <= 0
            ? "The scheduled time has passed. The seller has not started this broadcast."
            : minutes <= 60
              ? `Starts in about ${minutes} ${minutes === 1 ? "minute" : "minutes"}.`
              : "Waiting for the seller to start."}
        </p>
      )}
    </div>
  );
}
