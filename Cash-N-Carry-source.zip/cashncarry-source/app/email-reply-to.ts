import { env } from "cloudflare:workers";
import { publicSupportEmail, supportEmail } from "./public-support";
export async function emailReplyTo(): Promise<string | null> {
  const row = await env.DB?.prepare(
    "SELECT value FROM platform_settings WHERE key='email_reply_to'",
  ).first<{ value: string }>();
  return supportEmail(row?.value) || (await publicSupportEmail());
}
