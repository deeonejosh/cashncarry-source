export function parseBulkProductWorkbook(buffer: ArrayBuffer): Array<{
  rowNumber: number;
  name: string;
  description: string;
  category: string;
  price: string | number;
  sku: string;
  stock: string | number;
  image: string;
  images: string[];
  status: string;
}>;
