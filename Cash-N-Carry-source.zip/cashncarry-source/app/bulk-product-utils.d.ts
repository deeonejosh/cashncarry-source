export const BULK_PRODUCT_HEADERS: string[];
export const BULK_PRODUCT_MAX_ROWS: number;
export const BULK_PRODUCT_MAX_FILE_BYTES: number;
export function normalizeBulkHeader(value: unknown): string;
export function isSafeBulkImageUrl(value: unknown, origin?: string): string;
export function splitBulkImageUrls(value: unknown): string[];
export function bulkDuplicateKey(row: Record<string, unknown>): string;
