"use client";
import VerifiedSellerBadge from "./verified-seller-badge";
import { liveProductSelection } from "./live-product-selection";
import { startLiveFeaturePolling } from "./live-feature-polling";
import { useEffect, useRef, useState } from "react";
import {
  Heart,
  ShoppingBag,
  ShoppingCart,
  Share2,
  Flag,
  X,
  Send,
  MoreHorizontal,
  Maximize,
  ChevronDown,
  ChevronUp,
  Zap,
} from "lucide-react";
import { LiveAction, LiveSheet } from "./live-overlay";
import { broadcastLabel } from "./broadcasts";
import { deliveryQuote, deliveryFee } from "./delivery-quote";
import WebRTCVideo from "./webrtc-video";
import ScheduleInfo from "./schedule-info";
import LiveVideo from "./live-video";
import ImageAsset from "./image-asset";
const initialClock = Date.now();
const trackAnalyticsEvent=(event:string,store:string,details:{product?:string;stream?:string}={})=>{if(typeof window==="undefined"||!store)return;try{if(window.localStorage.getItem("cnc:analytics-consent:v1")!=="accepted")return;let visitor=window.localStorage.getItem("cnc:analytics-visitor:v1");if(!visitor){visitor=crypto.randomUUID();window.localStorage.setItem("cnc:analytics-visitor:v1",visitor);}void fetch("/api/seller-analytics",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({event,store,visitorId:visitor,...details}),keepalive:true}).catch(()=>{});}catch{/* Analytics must not block livestream shopping. */}};
const money = (n: number) =>
  new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(n);
export default function LiveShopping({
  initial,
  data,
  act,
  busy,
  onClose,
}: any) {
  const [stream, setStream] = useState(initial),
    [products, setProducts] = useState<any[]>([]),
    [chats, setChats] = useState<any[]>([]);
  const [viewers, setViewers] = useState<number | null>(null),
    [offline, setOffline] = useState(false),
    [sheet, setSheet] = useState("");
  const [selected, setSelected] = useState(""),
    [options, setOptions] = useState<Record<string, string>>({}),
    [quantities, setQuantities] = useState<Record<string, number>>({});
  const [message, setMessage] = useState(""),
    [feedback, setFeedback] = useState(""),
    [liked, setLiked] = useState(false),
    [checkoutKey, setCheckoutKey] = useState("");
  const [replayPlaying, setReplayPlaying] = useState(false);
  const [fullscreenAvailable, setFullscreenAvailable] = useState(false);
  const [likes, setLikes] = useState<number | null>(null);
  const [reacting, setReacting] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [directPurchase, setDirectPurchase] = useState<any>(null);
  const [deals, setDeals] = useState<any[]>([]);
  const [clock, setClock] = useState(initialClock);
  const [auctions, setAuctions] = useState<any[]>([]);
  const [auctionBusy, setAuctionBusy] = useState("");
  const [auctionFeedback, setAuctionFeedback] = useState("");
  const [pinCollapsed, setPinCollapsed] = useState(false);
  const viewportRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const stage = viewportRef.current;
    const header = stage?.querySelector<HTMLElement>(".live-top");
    const dock = stage?.querySelector<HTMLElement>(".live-lower");
    const fit = () => {
      if (header) stage?.style.setProperty("--live-header-height", `${Math.ceil(header.getBoundingClientRect().height)}px`);
      if (dock) stage?.style.setProperty("--live-dock-height", `${Math.ceil(dock.getBoundingClientRect().height) + 8}px`);
    };
    fit();
    const observer = typeof ResizeObserver !== "undefined" ? new ResizeObserver(fit) : null;
    if (header) observer?.observe(header);
    if (dock) observer?.observe(dock);
    return () => observer?.disconnect();
  }, [sheet, pinCollapsed, products.length]);
  useEffect(() => {
    setFullscreenAvailable(Boolean(document.fullscreenEnabled));
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const viewport = window.visualViewport;
    const resize = () => {
      if (viewportRef.current)
        viewportRef.current.dataset.compact = String(
          (viewport?.height || window.innerHeight) < 520,
        );
      viewportRef.current?.style.setProperty(
        "--visible-viewport",
        `${Math.round(viewport?.height || window.innerHeight)}px`,
      );
      viewportRef.current?.style.setProperty(
        "--visible-viewport-top",
        `${viewport?.offsetTop || 0}px`,
      );
    };
    resize();
    viewport?.addEventListener("resize", resize);
    viewport?.addEventListener("scroll", resize);
    window.addEventListener("resize", resize);
    return () => {
      document.body.style.overflow = previousOverflow;
      viewport?.removeEventListener("resize", resize);
      viewport?.removeEventListener("scroll", resize);
      window.removeEventListener("resize", resize);
    };
  }, []);
  useEffect(() => {
    const before = location.pathname + location.search + location.hash;
    const url = new URL(location.href);
    url.searchParams.set("stream", initial.id);
    history.replaceState(
      history.state,
      "",
      url.pathname + url.search + url.hash,
    );
    return () => {
      if (new URL(location.href).searchParams.get("stream") === initial.id)
        history.replaceState(history.state, "", before);
    };
  }, [initial.id]);
  useEffect(()=>{trackAnalyticsEvent("livestream_view",initial.store,{stream:initial.id});},[initial.id,initial.store]);
  useEffect(() => startLiveFeaturePolling(
    "/api/live-deals?stream=" + encodeURIComponent(initial.id),
    (data) => setDeals(data.deals || []),
  ), [initial.id]);
  useEffect(()=>{const timer=setInterval(()=>setClock(Date.now()),1000);return()=>clearInterval(timer);},[]);
  useEffect(() => startLiveFeaturePolling(
    "/api/live-auctions?stream=" + encodeURIComponent(initial.id),
    (data) => setAuctions(data.auctions || []),
  ), [initial.id]);
  const dealFor=(productId:string)=>(Array.isArray(deals)?deals:[]).find(d=>d.product===productId&&new Date(d.starts_at).getTime()<=clock&&new Date(d.ends_at).getTime()>clock&&Number(d.sold_quantity)<Number(d.max_quantity));
  const countdown=(value:string)=>{const seconds=Math.max(0,Math.ceil((new Date(value).getTime()-clock)/1000));const hours=Math.floor(seconds/3600),minutes=Math.floor((seconds%3600)/60),rest=seconds%60;return hours?`${hours.toString().padStart(2,"0")}:${minutes.toString().padStart(2,"0")}:${rest.toString().padStart(2,"0")}`:`${minutes.toString().padStart(2,"0")}:${rest.toString().padStart(2,"0")}`;};
  const streamAuctions=(Array.isArray(auctions)?auctions:[]).filter(a=>["active","scheduled"].includes(a.status)).sort((a,b)=>{const aActive=a.status==="active",bActive=b.status==="active";if(aActive!==bActive)return aActive?-1:1;return Date.parse(aActive?a.ends_at:a.starts_at)-Date.parse(bActive?b.ends_at:b.starts_at);});
  const featuredAuction=streamAuctions[0];
  const soonestDeal=[...deals].sort((a,b)=>Date.parse(a.ends_at)-Date.parse(b.ends_at))[0];
  async function submitAuctionBid(e:React.FormEvent<HTMLFormElement>,auction:{id:string}){e.preventDefault();setAuctionBusy(auction.id);setAuctionFeedback("");try{const values=Object.fromEntries(new FormData(e.currentTarget));if(values.terms!=="on")throw Error("Confirm the auction terms before bidding.");const response=await fetch("/api/live-auctions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"bid",auction:auction.id,amount:Number(values.amount),requestId:crypto.randomUUID()})});const result: {error?:string}=await response.json();if(!response.ok)throw Error(result.error||"Bid could not be recorded.");const refreshed=await fetch("/api/live-auctions?stream="+encodeURIComponent(stream.id),{cache:"no-store"});const current: {error?:string;auctions?:Array<Record<string,unknown>>}=await refreshed.json();if(!refreshed.ok)throw Error(current.error||"Auction details could not refresh.");setAuctions(current.auctions||[]);setAuctionFeedback("Your bid was recorded.");}catch(error:unknown){setAuctionFeedback(error instanceof Error?error.message:"Bid could not be recorded. Please retry.");}finally{setAuctionBusy("");}}

  useEffect(() => {
    let alive = true;
    let refreshing = false;
    const refresh = async () => {
      if (refreshing) return;
      refreshing = true;
      try {
        const r = await fetch(
          "/api/commerce?stream=" + encodeURIComponent(initial.id),
          { signal: AbortSignal.timeout(10000) },
        );
        if (r.status === 404) {
          if(alive){setStream((previous:any)=>({...previous,status:"unavailable",verified:0,url:"",replay:"",product:""}));setProducts([]);setOffline(false);setFeedback("This broadcast is no longer available.");}
          return;
        }
        if (!r.ok) throw Error();
        const d = (await r.json()) as any;
        if (alive) {
          setStream(d.stream);
          setProducts(d.products || []);
          setChats((d.chats || []).reverse());
          setViewers(d.viewers);
          setLikes(d.likes);
          setLiked(Boolean(d.liked));
          setOffline(false);
        }
      } catch {
        if (alive) setOffline(true);
      } finally {
        refreshing = false;
      }
    };
    refresh();
    const timer = setInterval(refresh, 3500);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [initial.id]);
  useEffect(() => {
    if (stream.status !== "live") return;
    const ping = () => {
      if (document.visibilityState === "visible")
        fetch("/api/live-presence", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: initial.id }),
        }).catch(() => {});
    };
    ping();
    const timer = setInterval(ping, 15000);
    const leave = () =>
      fetch("/api/live-presence", {
        method: "POST",
        keepalive: true,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: initial.id, leave: true }),
      }).catch(() => {});
    const visibility = () =>
      document.visibilityState === "hidden" ? leave() : ping();
    document.addEventListener("visibilitychange", visibility);
    window.addEventListener("pagehide", leave);
    return () => {
      clearInterval(timer);
      leave();
      document.removeEventListener("visibilitychange", visibility);
      window.removeEventListener("pagehide", leave);
    };
  }, [initial.id, stream.status]);
  const pinned = products.find((p) => p.id === stream.product),
    p = products.find((p) => p.id === selected) || pinned || products[0];
  const selection = liveProductSelection(p, options[p?.id] || "", quantities[p?.id] || 1);
  const { variants, variant, stock } = selection;
  const price = variant?.price ?? (dealFor(p?.id||"")?.promo_price ?? p?.price);
  const pinnedSelection = liveProductSelection(pinned, options[pinned?.id] || "", quantities[pinned?.id] || 1);
  const cartTotal = data.cart.reduce(
      (sum: number, c: any) => sum + (dealFor(c.id)?.promo_price??c.price) * c.quantity,
      0,
    ),
    delivery = deliveryQuote(
      data.stores.find((s: any) => s.id === data.cart[0]?.store),
    );
  const savedDeliveryFee = deliveryFee(data.stores.find((s: any) => s.id === data.cart[0]?.store));
  const directVariant = directPurchase
    ? JSON.parse(directPurchase.product.variants || "[]").find((v: any) => v.name === directPurchase.variant)
    : null;
  const checkoutProductTotal = directPurchase
    ? (directVariant?.price ?? directPurchase.deal?.promo_price ?? directPurchase.product.price) * directPurchase.quantity
    : cartTotal;
  const checkoutDelivery = directPurchase
    ? deliveryQuote(directPurchase.product)
    : delivery;
  const checkoutDeliveryFee = directPurchase
    ? deliveryFee(directPurchase.product)
    : savedDeliveryFee;
  async function addProduct(target = p) {
    if (!target) return;
    if (offline) {setFeedback("Connection interrupted. Reconnect before purchasing this product.");return;}
    const choice = liveProductSelection(target, options[target.id] || "", quantities[target.id] || 1);
    if (choice.error) { setSelected(target.id); setSheet("product"); setFeedback(choice.error); return; }
    setDirectPurchase(null);
    const existing = data.cart.find(
      (c: any) => c.id === target.id && c.variant === (options[target.id] || ""),
    );
    const ok = await act(
      {
        action: "cart",
        product: target.id,
        variant: options[target.id] || "",
        quantity: (existing?.quantity || 0) + (quantities[target.id] || 1),
      },
      "Added to cart",
    );
    if(ok)trackAnalyticsEvent("add_to_cart",target.store,{product:target.id,stream:stream.id});
    setFeedback(
      ok
        ? "Added to cart. Continue watching or checkout."
        : "Unable to add this product. Check the current price, option and stock, then retry.",
    );
  }
  function buyNowProduct(target = p) {
    if (!target) return;
    if (offline) {setFeedback("Connection interrupted. Reconnect before purchasing this product.");return;}
    const selectedVariant = options[target.id] || "";
    const quantity = quantities[target.id] || 1;
    const choice = liveProductSelection(target, selectedVariant, quantity);
    if (choice.error) { setSelected(target.id); setSheet("product"); setFeedback(choice.error); return; }
    const deal=dealFor(target.id);if(deal&&quantity>Number(deal.max_quantity)-Number(deal.sold_quantity)){setFeedback("Only the remaining promotional quantity is available at this price.");return;}
    setDirectPurchase({ product: target, variant: selectedVariant, quantity, deal });
    setCheckoutKey(crypto.randomUUID());
    trackAnalyticsEvent("buy_now",target.store,{product:target.id,stream:stream.id});trackAnalyticsEvent("checkout_start",target.store,{product:target.id,stream:stream.id});
    setSheet("checkout");
  }
  async function share() {
    const url = location.origin + "/?stream=" + encodeURIComponent(stream.id);
    try {
      if (navigator.share) await navigator.share({ title: stream.title, url });
      else {
        await navigator.clipboard.writeText(url);
        setFeedback("Broadcast link copied");
      }
    } catch {
      setFeedback("Sharing was cancelled or unavailable.");
    }
  }
  const cartQuantity = data.cart.reduce(
    (n: number, c: any) => n + c.quantity,
    0,
  );
  async function reactToStream() {
    if (reacting) return;
    setReacting(true);
    try {
      if (
        await act(
          { action: "stream-like", stream: stream.id, liked: !liked },
          "",
        )
      ) {
        const r = await fetch(
          "/api/commerce?stream=" + encodeURIComponent(stream.id),
          { signal: AbortSignal.timeout(10000) },
        );
        if (!r.ok) throw Error();
        const fresh: any = await r.json();
        setLikes(fresh.likes);
        setLiked(Boolean(fresh.liked));
      } else
        setFeedback(
          "Sign in to react, or retry if the broadcast is unavailable.",
        );
    } catch {
      setFeedback("Reaction count could not refresh. Retrying…");
    } finally {
      setReacting(false);
    }
  }
  function openCart() {
    setDirectPurchase(null);
    setCheckoutKey(crypto.randomUUID());
    setSheet("checkout");
  }
  return (
    <div className="live-shopping" ref={viewportRef}>
      <div className="live-stage" inert={Boolean(sheet)}>
        {stream.status === "unavailable" ? <div className="live-state"><h2>Broadcast unavailable</h2><p>The seller or stream is no longer available.</p><button onClick={onClose}>Browse live streams</button></div> : stream.status === "ended" ? (
          replayPlaying && stream.replay ? (
            <LiveVideo url={stream.replay} />
          ) : (
            <div className="live-state live-ended">
              <h2>This broadcast has ended</h2>
              <button onClick={onClose}>Browse live streams</button>
              <a
                className="secondary-button"
                href={"/store/" + encodeURIComponent(stream.store)}
              >
                Visit seller’s store
              </a>
              {stream.replay && (
                <button onClick={() => setReplayPlaying(true)}>
                  Watch replay
                </button>
              )}
            </div>
          )
        ) : stream.status === "scheduled" ? (
          <div className="live-state">
            <h2>Waiting for the seller</h2>
            <ScheduleInfo scheduled={stream.scheduled} />
            <button onClick={onClose}>Browse live streams</button>
          </div>
        ) : stream.provider === "tiktok" ? (
          <a
            className="live-state"
            href={stream.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            Watch on TikTok
          </a>
        ) : stream.provider === "native" ? (
          <WebRTCVideo url={stream.url} />
        ) : (
          <LiveVideo url={stream.url} />
        )}
        <div className="live-top">
          <div className="live-seller">
            <span className="seller-initial" aria-hidden="true">
              {stream.seller?.slice(0, 1)}
            </span>
            <div>
              <strong>
                <span className="seller-name-text">{stream.seller}</span><VerifiedSellerBadge verified={stream.verified} variant="compact"/>
              </strong>
              <small>{stream.title}</small>
            </div>
            <button
              className="live-follow"
              disabled={busy}
              onClick={() =>
                act(
                  {
                    action: "follow",
                    store: stream.store,
                    follow: !data.follows.some(
                      (f: any) => f.store === stream.store,
                    ),
                  },
                  "Follow preference updated",
                )
              }
            >
              {data.follows.some((f: any) => f.store === stream.store)
                ? "Following"
                : "Follow"}
            </button>
          </div>
          <button aria-label="Close broadcast" onClick={onClose}>
            <X />
          </button>
        </div>
        <div className="live-top-meta">
          <span className="live-status">
            {stream.status === "live" && stream.provider === "native"
              ? "LIVE"
              : ["live", "external"].includes(stream.status)
                ? "EXTERNAL STREAM"
                : stream.status === "ended" && stream.replay
                  ? "REPLAY"
                  : broadcastLabel(stream)}
          </span>
          {stream.status === "live" && viewers !== null && (
            <span className="live-viewer-count" title="Current viewers on this broadcast">
              <span aria-hidden="true" className="live-viewer-dot" />
              {viewers.toLocaleString()} {viewers === 1 ? "viewer" : "viewers"} watching
            </span>
          )}
          {soonestDeal && <button type="button" className="live-deal-pulse" aria-label={`Flash deal${deals.length===1?"":"s"} available. Soonest offer ends in ${countdown(soonestDeal.ends_at)}. Browse deals.`} onClick={()=>setSheet("products")}><Zap size={14} aria-hidden="true"/> FLASH DEAL{deals.length===1?"":"S"} · {countdown(soonestDeal.ends_at)}</button>}
        </div>
        <div className="live-viewer-tools" aria-label="Viewer actions">
          <LiveAction
            label={likes === null ? "Like" : String(likes)}
            icon={<Heart fill={liked ? "currentColor" : "none"} />}
            aria-label={
              (liked ? "Unlike broadcast" : "Like broadcast") +
              (likes === null ? "" : `, ${likes} likes`)
            }
            aria-pressed={liked}
            disabled={
              busy || reacting || !["live", "external"].includes(stream.status)
            }
            title={
              ["live", "external"].includes(stream.status)
                ? "Sign in to save your reaction"
                : "Reactions are available during a broadcast"
            }
            onClick={reactToStream}
          />
          <LiveAction
            label="Share"
            icon={<Share2 />}
            aria-label="Share broadcast"
            onClick={share}
          />
          {products.length > 0 && (
            <LiveAction
              label="Products"
              icon={<ShoppingBag />}
              count={products.length}
              aria-label={`Browse ${products.length} featured ${products.length === 1 ? "product" : "products"}`}
              onClick={() => setSheet("products")}
            />
          )}
          <LiveAction
            label="More"
            icon={<MoreHorizontal />}
            aria-label="More broadcast options"
            aria-haspopup="dialog"
            onClick={() => setSheet("more")}
          />
        </div>
        <div className="live-lower" inert={Boolean(sheet)}>
          {!sheet&&featuredAuction&&<button type="button" className="live-auction-callout" aria-label={`${featuredAuction.status==="active"?"Live auction":"Upcoming auction"} for ${featuredAuction.product_name}. ${featuredAuction.status==="active"?"Ends in":"Starts in"} ${countdown(featuredAuction.status==="active"?featuredAuction.ends_at:featuredAuction.starts_at)}. Open auction details.`} onClick={()=>{setAuctionFeedback("");setSheet("auction");}}><span><small>{featuredAuction.status==="active"?"LIVE AUCTION":"UPCOMING AUCTION"} · {featuredAuction.status==="active"?"ENDS":"STARTS"} IN {countdown(featuredAuction.status==="active"?featuredAuction.ends_at:featuredAuction.starts_at)}</small><strong>{featuredAuction.product_name}</strong><span>{featuredAuction.highest_bid?money(featuredAuction.highest_bid):money(featuredAuction.start_price)} · {featuredAuction.bid_count} bids</span></span><b>{featuredAuction.status==="active"?"View & bid":"View auction"}</b></button>}
          {!sheet && (
            <div className="live-chat">
              <div className="live-messages" aria-live="polite">
                {chats.slice(-3).map((c) => (
                  <p key={c.id}>
                    <strong>{c.name}</strong> {c.message}
                  </p>
                ))}
              </div>
              {offline && <p role="status">Chat disconnected. Retrying…</p>}
            </div>
          )}
          {pinned && !sheet && <div className={"live-pin-shell" + (pinCollapsed ? " is-collapsed" : "")}>
            <button type="button" className="live-pin-toggle" aria-label={pinCollapsed ? "Expand pinned product" : "Collapse pinned product"} aria-expanded={!pinCollapsed} aria-controls={pinCollapsed ? undefined : "live-pinned-product"} onClick={() => setPinCollapsed(v => !v)}>
              <ShoppingBag size={16} aria-hidden="true" /> {pinCollapsed ? <><ImageAsset src={pinned.image} alt=""/><span className="pin-collapsed-name">{pinned.name}</span><b>{money(pinnedSelection.variant?.price ?? dealFor(pinned.id)?.promo_price ?? pinned.price)}</b></> : "Pinned Product"}{pinCollapsed ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
          {!pinCollapsed && (
            <div id="live-pinned-product" className="live-premium-product">
              <button className="live-premium-product-info" aria-label={`View ${pinned.name} details`} onClick={() => {trackAnalyticsEvent("product_click",pinned.store,{product:pinned.id,stream:stream.id});setSelected(pinned.id);setSheet("product");}}>
                <ImageAsset src={pinned.image} alt={pinned.name} />
                <span><strong>{pinned.name}</strong><span className="live-premium-price">{money(pinnedSelection.variant?.price ?? dealFor(pinned.id)?.promo_price ?? pinned.price)}{dealFor(pinned.id) && <s>{money(pinned.price)}</s>}</span>
                <small>{pinnedSelection.needsOption ? "Choose an option below" : pinnedSelection.stock ? `${pinnedSelection.stock} available` : "Sold out"}{deliveryFee(pinned) !== undefined ? ` · Delivery ${money(deliveryFee(pinned)!)}` : ""}</small>
                {dealFor(pinned.id) && <small className="live-pin-deal">Flash deal · {countdown(dealFor(pinned.id).ends_at)} left · {Math.max(0,dealFor(pinned.id).max_quantity-dealFor(pinned.id).sold_quantity)} remaining</small>}</span>
              </button>
              {pinnedSelection.variants.length > 0 && <label className="live-pinned-option">Choose an option<select aria-label={`Option for ${pinned.name}`} value={options[pinned.id] || ""} onChange={e=>{setOptions({...options,[pinned.id]:e.target.value});setQuantities({...quantities,[pinned.id]:1});setFeedback("");}}><option value="">Select an available option</option>{pinnedSelection.variants.map(v=><option key={v.name} value={v.name} disabled={!v.stock}>{v.name} · {money(v.price ?? pinned.price)} · {v.stock ? `${v.stock} available` : "Sold out"}</option>)}</select></label>}
              <div className="live-premium-purchase">
                <button className="primary" disabled={busy || offline || Boolean(pinnedSelection.error)} onClick={() => buyNowProduct(pinned)}>Buy Now</button>
                <button className="secondary-button" disabled={busy || offline || Boolean(pinnedSelection.error)} onClick={() => {void addProduct(pinned);}}>Add to Cart</button>
              </div>
            </div>
          )}
          </div>}

          {!sheet && ["live", "external"].includes(stream.status) && (
            <div className="live-composer">
              {" "}
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (
                    await act(
                      { action: "chat", stream: stream.id, message },
                      "",
                    )
                  )
                    setMessage("");
                  else setFeedback("Message could not be sent. Please retry.");
                }}
              >
                <input
                  aria-label="Ask the seller a question"
                  placeholder="Ask the seller…"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  maxLength={400}
                  required
                  disabled={!["live", "external"].includes(stream.status)}
                />
                <button aria-label="Send question" disabled={busy}>
                  <Send size={19} />
                </button>
              </form>
              <button
                className="live-cart-button"
                aria-label={`Open cart, ${cartQuantity} ${cartQuantity === 1 ? "item" : "items"}`}
                onClick={openCart}
                title={
                  cartQuantity ? "View cart and checkout" : "Your cart is empty"
                }
              >
                <ShoppingCart />
                {cartQuantity > 0 && (
                  <span className="live-action-count">{cartQuantity}</span>
                )}
              </button>
            </div>
          )}
          {!["live", "external"].includes(stream.status) &&
            cartQuantity > 0 && (
              <button
                className="live-cart-button live-ended-cart"
                onClick={openCart}
              >
                <ShoppingCart />
                Cart · {cartQuantity}
              </button>
            )}
        </div>
      </div>

      {feedback && (
        <div className="live-feedback" role="status">
          {feedback}
          <button aria-label="Dismiss message" onClick={() => setFeedback("")}>
            <X size={18} />
          </button>
        </div>
      )}
      {sheet && (
        <LiveSheet
          title={
            sheet === "checkout"
              ? "Your cart"
              : sheet === "products"
                ? "Shop this broadcast"
                : sheet === "more"
                  ? "Broadcast options"
                  : sheet === "comments" ? "Live comments" : sheet === "auction" ? "Live auction" : "Product details"
          }
          onClose={() => setSheet("")}
        >
          {feedback && (
            <p role="status" className="live-sheet-notice">
              {feedback}
            </p>
          )}
          {sheet === "more" ? (
            <div className="live-option-list">
              <button onClick={()=>setSheet("comments")}>View all comments</button>
              {fullscreenAvailable && (
                <button
                  onClick={() =>
                    viewportRef.current
                      ?.requestFullscreen()
                      .then(() => setSheet(""))
                      .catch(() =>
                        setFeedback(
                          "Fullscreen is unavailable. Continue watching here.",
                        ),
                      )
                  }
                >
                  <Maximize />
                  Enter fullscreen
                </button>
              )}
              <a href={"/store/" + encodeURIComponent(stream.store)}>
                Visit seller’s store
              </a>
              {!products.length && <p>No featured products are available.</p>}
              {!["live", "external"].includes(stream.status) && (
                <p>Reactions and comments are available during a broadcast.</p>
              )}
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (
                    await act(
                      {
                        action: "report",
                        target_type: "stream",
                        target: stream.id,
                        reason: reportReason,
                        details: "Broadcast report: " + reportReason,
                      },
                      "Report submitted",
                    )
                  ) {
                    setReportReason("");
                    setSheet("");
                  }
                }}
              >
                <label>
                  Report this broadcast
                  <textarea
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    placeholder="Tell us what happened"
                    minLength={5}
                    maxLength={1000}
                    required
                  />
                </label>
                <button disabled={busy}>
                  <Flag />
                  Submit report
                </button>
              </form>
            </div>
          ) : sheet === "comments" ? <div className="live-comments-panel">{chats.length ? chats.map(c=><p key={c.id}><strong>{c.name}</strong> {c.message}</p>) : <p>No comments yet.</p>}</div> : sheet === "auction" ? (
            <div className="live-auction-list">
              {auctionFeedback&&<p className="live-sheet-notice" role="status">{auctionFeedback}</p>}
              {streamAuctions.length?streamAuctions.map((auction:any)=>{const active=auction.status==="active",current=Number(auction.highest_bid||0),minimum=current?current+Number(auction.increment):Number(auction.start_price);return <article className="live-auction-card" key={auction.id}>
                <div className="live-auction-card-heading"><span className={active?"is-live":"is-upcoming"}>{active?"LIVE NOW":"UP NEXT"}</span><span>{active?"Ends in":"Starts in"} <strong>{countdown(active?auction.ends_at:auction.starts_at)}</strong></span></div>
                <h3>{auction.product_name}</h3>
                <dl><div><dt>Current bid</dt><dd>{current?money(current):"No bids"}</dd></div><div><dt>Next bid</dt><dd>{money(minimum)}</dd></div><div><dt>Bids</dt><dd>{auction.bid_count}</dd></div></dl>
                {active&&auction.canBid?<form className="live-auction-bid-form" onSubmit={e=>void submitAuctionBid(e,auction)}><label>Your bid (₦)<input name="amount" type="number" min={minimum} step={Number(auction.increment)} defaultValue={minimum} required/></label><label className="live-auction-terms"><input name="terms" type="checkbox" required/> A winning bid creates an unpaid order. Payment collection is not enabled; you will not be charged.</label><button className="primary" disabled={auctionBusy===auction.id}>{auctionBusy===auction.id?"Submitting…":"Place bid"}</button></form>:active?<p className="live-auction-signin">Sign in as a buyer to bid. Sellers cannot bid on their own auctions. <a href={`/sign-in?returnTo=${encodeURIComponent(`/?browse=1&stream=${stream.id}#live`)}`}>Sign in</a></p>:<p className="live-auction-upcoming-note">Bidding opens when the countdown reaches zero while this broadcast is live.</p>}
              </article>;}) : <p>No auctions are running in this broadcast.</p>}
            </div>
          ) : sheet === "products" ? (
            <div className="live-product-list">
              {products.length ? (
                products.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setSelected(item.id);
                      setSheet("product");
                    }}
                  >
                    <ImageAsset src={item.image} alt={item.name} />
                    <span>
                      <strong>{item.name}</strong>
                      {dealFor(item.id)?<><s>{money(item.price)}</s><b>{money(dealFor(item.id).promo_price)}</b><small>{Math.round((1-dealFor(item.id).promo_price/item.price)*100)}% off · ends in {countdown(dealFor(item.id).ends_at)} · {Math.max(0,Number(dealFor(item.id).max_quantity)-Number(dealFor(item.id).sold_quantity))} remaining</small></>:<b>{money(item.price)}</b>}
                      <small>{item.stock ? "View options" : "Sold out"}</small>
                    </span>
                  </button>
                ))
              ) : (
                <p>The seller has not featured any products yet.</p>
              )}
            </div>
          ) : sheet === "product" && p ? (
            <div className="live-product-detail">
              <ImageAsset src={p.image} alt={p.name} />
              <h3>{p.name}</h3>
              {dealFor(p.id)&&!variant?<><del>{money(p.price)}</del><strong>{money(price)} · {Math.round((1-price/p.price)*100)}% off</strong><p className="live-deal-timer">Flash deal ends in {countdown(dealFor(p.id).ends_at)} · {Math.max(0,dealFor(p.id).max_quantity-dealFor(p.id).sold_quantity)} remaining</p></>:<strong>{money(price)}</strong>}
              <p>{p.description}</p>
              {variants.length > 0 && (
                <label>
                  Variant
                  <select
                    value={options[p.id] || ""}
                    onChange={(e) => {
                      setOptions({ ...options, [p.id]: e.target.value });
                      if (e.target.value && (feedback === "Choose an available product option first." || feedback === `Choose an available option for ${p.name}.` || feedback.startsWith("This option or product is sold out."))) setFeedback("");
                    }}
                  >
                    <option value="">Choose variant</option>
                    {variants.map((v: any) => (
                      <option key={v.name} value={v.name} disabled={!v.stock}>
                        {v.name} · {money(v.price)}
                        {!v.stock ? " · Sold out" : ""}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              <label>
                Quantity
                <input
                  type="number"
                  min="1"
                  max={Math.min(stock || 1, 99)}
                  value={quantities[p.id] || 1}
                  onChange={(e) =>
                    setQuantities({
                      ...quantities,
                      [p.id]: Math.max(
                        1,
                        Math.min(stock || 1, 99, Number(e.target.value) || 1),
                      ),
                    })
                  }
                />
              </label>
              <p>
                {variants.length && !variant
                  ? "Choose an option"
                  : stock
                    ? `${stock} available`
                    : "Sold out"}
              </p>
              <details>
                <summary>Delivery and seller details</summary>
                <p>{p.location}</p>
                <p>
                  Coverage:{" "}
                  {JSON.parse(p.coverage || "[]").join(", ") ||
                    "Confirm with seller"}
                </p>
                <p>
                  Delivery:{" "}
                  {deliveryFee(p) === undefined
                    ? "Fee confirmed at checkout"
                    : money(deliveryFee(p)!) + " per order"}{" "}
                  · {p.delivery_days}
                </p>
                <p>{p.return_policy}</p>
              </details>
              <button
                className="primary"
                disabled={busy || offline || Boolean(selection.error)}
                onClick={() => buyNowProduct()}
              >
                Buy Now
              </button>
              <button
                className="secondary-button"
                disabled={busy || offline || Boolean(selection.error)}
                onClick={() => addProduct()}
              >
                Add to Cart
              </button>
              <button
                onClick={() => {
                  setDirectPurchase(null);
                  setCheckoutKey(crypto.randomUUID());
                  setSheet("checkout");
                }}
              >
                View cart and checkout
              </button>
              <button onClick={() => setSheet("products")}>
                All featured products
              </button>
            </div>
          ) : sheet === "checkout" ? (
            <div>
              {directPurchase ? (
                <p>{directPurchase.product.name}{directPurchase.variant ? ` · ${directPurchase.variant}` : ""} · {directPurchase.quantity} × {money(directVariant?.price ?? directPurchase.deal?.promo_price ?? directPurchase.product.price)}</p>
              ) : data.cart.map((c: any) => (
                <p key={c.id}>
                  {c.name} {c.variant} · {c.quantity} × {money(dealFor(c.id)?.promo_price??c.price)} {dealFor(c.id)&&<small><s>{money(c.price)}</s> live deal</small>}
                </p>
              ))}
              <p>
                Products {money(checkoutProductTotal)} ·{" "}
                {checkoutDeliveryFee === undefined ? "Delivery fee not set" : `Delivery ${money(checkoutDeliveryFee)} · Total ${money(checkoutProductTotal + checkoutDeliveryFee)}`}
                {checkoutDelivery === undefined && <span> · Seller delivery coverage is required before payment.</span>}
              </p>
              {directPurchase || data.cart.length ? (
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const body = Object.fromEntries(
                      new FormData(e.currentTarget),
                    );
                    if (body.payment === "flutterwave") {
                      try {
                        sessionStorage.setItem("cnc-live-return", stream.id);
                      } catch {}
                    }
                    const ok = await act(
                      {
                        action: "checkout",
                        ...body,
                        key: checkoutKey,
                        ...(directPurchase
                          ? {
                              product: directPurchase.product.id,
                              variant: directPurchase.variant,
                              quantity: directPurchase.quantity,
                              ...(directPurchase.deal?{dealId:directPurchase.deal.id,stream:stream.id}:{}),
                            }
                          : {deals:Object.fromEntries(data.cart.map((c:any)=>[c.id,dealFor(c.id)?.id]).filter((entry:any)=>Boolean(entry[1]))),stream:stream.id}),
                      },
                      "Order placed",
                    );
                    setFeedback(
                      ok
                        ? "Order placed. Check My orders for payment status."
                        : "Checkout failed. Check your cart, price, stock and delivery details, then retry.",
                    );
                    if (ok) {
                      setSheet("");
                      setDirectPurchase(null);
                    }
                  }}
                >
                  <label>
                    Delivery name
                    <input name="name" required />
                  </label>
                  <label>
                    Phone
                    <input name="phone" type="tel" required />
                  </label>
                  <label>
                    Address
                    <input name="address" required />
                  </label>
                  <label>
                    Delivery state
                    <input name="delivery_state" required />
                  </label>
                  <label>
                    Payment
                    <select name="payment" disabled={!data.payments?.online}>
                      {!data.payments?.online && <option value="">Debit card payment unavailable</option>}
                      {data.payments?.online && (
                        <option value="flutterwave">
                          Debit card payment
                          {data.payments?.mode === "live" ? "" : " sandbox"}
                        </option>
                      )}
                    </select>
                  </label>
                  <p>
                    {data.payments?.mode === "live"
                      ? "Online payment"
                      : "Sandbox payment"}{" "}
                    opens secure checkout powered by Flutterwave. Use Back to broadcast on the payment
                    result page to return.
                  </p>
                  <button
                    className="primary"
                    disabled={busy || checkoutDelivery === undefined || !data.payments?.online}
                  >
                    Place order
                  </button>
                </form>
              ) : (
                <p>Your cart is empty.</p>
              )}
            </div>
          ) : null}
        </LiveSheet>
      )}
    </div>
  );
}
