/** Turn seller-entered product copy into a concise search snippet. */
export function productSeoDescription(name: string, description: string): string {
  const clean = `${name}: ${description}`
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;|&#34;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
  if (clean.length <= 155) return clean;
  const clipped = clean.slice(0, 152);
  const boundary = clipped.lastIndexOf(" ");
  return `${clipped.slice(0, boundary > 100 ? boundary : 152).trimEnd()}…`;
}

export function absoluteProductImage(image: string | null | undefined, origin: string): string | undefined {
  const source = image?.trim();
  if (!source) return undefined;
  try {
    const url = new URL(source, origin);
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : undefined;
  } catch {
    return undefined;
  }
}
