import { requireSellerActive } from "../../seller-activation";
import { limit } from "../../security";
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { getStreamConfig } from "../../stream-config";
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403 });
  const u = await getChatGPTUser();
  if (!u) return Response.json({ error: "Sign in" }, { status: 401 });
  try {
    const b: any = await req.json();
    if (!b || typeof b.id !== "string" || !b.id || b.id.length > 100 || !["prepare", "resume", "connected", "end", "replay"].includes(b.action))
      throw Error("Invalid broadcast request");
    await limit("stream-control:" + u.userId, 90);
    const s: any = await env
      .DB!.prepare(
        "SELECT l.*,s.suspended FROM streams l JOIN stores s ON s.id=l.store WHERE l.id=? AND s.owner=? AND s.suspended=0",
      )
      .bind(b.id, u.userId)
      .first();
    const p: any = await env
      .DB!.prepare("SELECT suspended FROM profiles WHERE id=?")
      .bind(u.userId)
      .first();
    if (!s || p?.suspended) throw Error("Active seller access required");
    if (b.action === "end") {
      // Closing a browser peer is insufficient: revoke this session's publisher
      // input before confirming the end. Recorded videos and our history remain.
      if (s.provider === "native" && s.provider_id) {
        const config = await getStreamConfig();
        if (!config) throw Error("Cannot confirm the broadcast has stopped: streaming configuration is unavailable. Retry End Live.");
        const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${config.accountId}/stream/live_inputs/${encodeURIComponent(s.provider_id)}`, {
          method: "DELETE", headers: { Authorization: `Bearer ${config.token}` }, signal: AbortSignal.timeout(10000),
        });
        const result: any = await response.json().catch(() => null);
        const alreadyRemoved = response.status === 404 && result?.errors?.some((error: any) => error.code === 1000);
        if (!(response.ok && result?.success === true) && !alreadyRemoved)
          throw Error("The streaming provider did not confirm the broadcast has stopped. Retry End Live.");
      }
      await env.DB!.prepare("UPDATE streams SET status='ended',publish_url='' WHERE id=? AND store=?").bind(s.id, s.store).run();
      return Response.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
    }
    await requireSellerActive(s.store);
    const config = await getStreamConfig();
    if (!config)
      throw Error(
        "Native broadcasting is not configured. You can schedule a session or add a TikTok link.",
      );
    if (b.action === "prepare" || b.action === "resume") {
      const leaseKey = "stream-prepare:" + s.id;
      const now = Math.floor(Date.now() / 1000);
      const lease = await env.DB!.prepare("INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET expires=excluded.expires WHERE expires<=? RETURNING key").bind(leaseKey, now + 45, now).first();
      if (!lease) return Response.json({ error: "Broadcast preparation is already in progress. Wait and retry." }, { status: 409 });
      let createdInput = "";
      try {
        // Re-read after claiming the lease; a previous request may have prepared it.
        const latest: any = await env.DB!.prepare("SELECT l.* FROM streams l JOIN stores s ON s.id=l.store WHERE l.id=? AND s.owner=? AND s.suspended=0").bind(s.id, u.userId).first();
        if (!latest || !(b.action === "resume" ? ["scheduled","live"] : ["scheduled"]).includes(latest.status) || latest.provider !== "native")
          throw Error("This native session is no longer available for connection");
        if (await env.DB!.prepare("SELECT id FROM streams WHERE store=? AND id!=? AND status='live' AND provider='native' AND heartbeat>?").bind(latest.store, latest.id, new Date(Date.now()-90000).toISOString()).first())
          return Response.json({ error: "End your current broadcast before starting another." }, { status: 409 });
        if (latest.provider_id && latest.publish_url)
          return Response.json({ publish: latest.publish_url, play: latest.url }, { headers: { "Cache-Control": "no-store" } });
        const r = await fetch(`https://api.cloudflare.com/client/v4/accounts/${config.accountId}/stream/live_inputs`, {
          signal: AbortSignal.timeout(15000), method: "POST",
          headers: { Authorization: `Bearer ${config.token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ meta: { name: latest.title }, recording: { mode: "automatic" } }),
        });
        const result: any = await r.json();
        if (!r.ok || !result.success || !result.result?.uid || !result.result?.webRTC?.url || !result.result?.webRTCPlayback?.url)
          throw Error("Stream provider could not prepare the broadcast");
        createdInput = result.result.uid;
        const updated: any = await env.DB!.prepare("UPDATE streams SET provider_id=?,publish_url=?,url=? WHERE id=? AND status='scheduled' AND EXISTS(SELECT 1 FROM stores s WHERE s.id=streams.store AND s.owner=? AND s.suspended=0) AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.id=? AND p.suspended=1)").bind(createdInput, result.result.webRTC.url, result.result.webRTCPlayback.url, latest.id, u.userId, u.userId).run();
        if (Number(updated.meta?.changes ?? updated.changes) !== 1)
          throw Error("Broadcast changed during preparation. Refresh before retrying.");
        createdInput = ""; // Persisted inputs belong to the session, not this request.
        return Response.json({ publish: result.result.webRTC.url, play: result.result.webRTCPlayback.url }, { headers: { "Cache-Control": "no-store" } });
      } finally {
        if (createdInput)
          await fetch(`https://api.cloudflare.com/client/v4/accounts/${config.accountId}/stream/live_inputs/${encodeURIComponent(createdInput)}`, { method: "DELETE", headers: { Authorization: `Bearer ${config.token}` }, signal: AbortSignal.timeout(5000) }).catch(() => {});
        await env.DB!.prepare("DELETE FROM rate_limits WHERE key=?").bind(leaseKey).run();
      }
    }
    if (b.action === "connected") {
      if (s.provider !== "native" || !["scheduled", "live"].includes(s.status))
        return Response.json(
          { error: "This broadcast is no longer available for connection." },
          { status: 409, headers: { "Cache-Control": "no-store" } },
        );
      if (!s.publish_url) throw Error("Prepare a broadcast first");
      if (!s.provider_id) throw Error("Prepare a broadcast first");
      const provider = await fetch(
        `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/stream/live_inputs/${s.provider_id}`,
        {
          headers: { Authorization: `Bearer ${config.token}` },
          signal: AbortSignal.timeout(10000),
        },
      );
      const state: any = await provider.json();
      const providerStatus =
        typeof state.result?.status === "string"
          ? state.result.status
          : state.result?.status?.current?.state;
      const confirmed =
        provider.ok &&
        state.success &&
        ["connected", "reconnected"].includes(providerStatus);
      if (!confirmed)
        return Response.json(
          {
            error:
              "The provider has not confirmed broadcasting yet. Keep this screen open while we retry.",
          },
          { status: 409 },
        );

      const updated = await env
        .DB!.prepare(
          "UPDATE streams SET status='live',heartbeat=? WHERE id=? AND status IN ('scheduled','live') AND provider='native' AND publish_url!='' AND EXISTS(SELECT 1 FROM stores s WHERE s.id=streams.store AND s.owner=? AND s.suspended=0) AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.id=? AND p.suspended=1) AND NOT EXISTS(SELECT 1 FROM streams other WHERE other.store=streams.store AND other.id!=streams.id AND other.provider='native' AND other.status='live' AND other.heartbeat>?)",
        )
        .bind(new Date().toISOString(), s.id, u.userId, u.userId, new Date(Date.now()-90000).toISOString())
        .run();
      if (Number(updated.meta?.changes ?? (updated as any).changes) !== 1)
        return Response.json(
          {
            error:
              "The broadcast changed while connecting. Refresh before retrying.",
          },
          { status: 409, headers: { "Cache-Control": "no-store" } },
        );
      return Response.json(
        { ok: true },
        { headers: { "Cache-Control": "no-store" } },
      );
    }
    if (b.action === "replay") {
      return Response.json(
        {
          error:
            "Shoppable replay publication is not available yet. Provider recordings are not automatically published as replays.",
        },
        { status: 409 },
      );
    }
    throw Error("Unknown action");
  } catch (e: any) {
    const limited = e.message?.startsWith("Too many requests");
    return Response.json({ error: e.message?.includes("D1_ERROR") ? "Broadcast service unavailable. Refresh and retry." : e.message }, { status: limited ? 429 : 400, headers: { "Cache-Control": "no-store", ...(limited ? { "Retry-After": "60" } : {}) } });
  }
}
