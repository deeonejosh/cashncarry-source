import { verificationEmail, safelyEmail } from "../../email-events";
import { limit } from "../../security";
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { isAdmin } from "../../admin-access";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const u = await getChatGPTUser();
  if (!u) return new Response("Sign in required", { status: 401 });
  try {
    const id = new URL(req.url).searchParams.get("document");
    if (!id) return new Response("Document required", { status: 400 });
    const row: any = await env
      .DB!.prepare("SELECT * FROM verification_requests WHERE id=?")
      .bind(id)
      .first();
    if (!row || (!await isAdmin(u, "verification") && row.owner !== u.userId))
      return new Response("Access denied", { status: 403 });
    const obj = await env.BUCKET!.get(row.file_key);
    if (!obj) return new Response("Document not found", { status: 404 });
    return new Response(obj.body, {
      headers: {
        "Content-Type": row.file_type,
        "Cache-Control": "private,no-store",
        "Content-Disposition":
          'attachment; filename="verification-document' +
          (row.file_type === "application/pdf"
            ? ".pdf"
            : row.file_type === "image/png"
              ? ".png"
              : ".jpg") +
          '"',
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    return new Response("Document unavailable", { status: 503 });
  }
}
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403 });
  const u = await getChatGPTUser();
  if (!u) return Response.json({ error: "Sign in required" }, { status: 401 });
  try {
    if (!env.DB || !env.BUCKET) throw Error("Storage unavailable");
    const profile: any = await env.DB.prepare(
      "SELECT suspended FROM profiles WHERE id=?",
    )
      .bind(u.userId)
      .first();
    if (profile?.suspended) throw Error("Your account is suspended.");
    const store: any = await env.DB.prepare(
      "SELECT * FROM stores WHERE owner=?",
    )
      .bind(u.userId)
      .first();
    if (!store || store.suspended)
      throw Error("An active storefront is required");
    if (
      await env.DB.prepare(
        "SELECT id FROM verification_requests WHERE store=? AND status='pending'",
      )
        .bind(store.id)
        .first()
    )
      throw Error("Your application is already pending review.");
    if (Number(req.headers.get("content-length") || 0) > 9 * 1024 * 1024)
      throw Error("Maximum document size is 8 MB");
    await limit("verification-upload:" + u.userId, 5, 3600);
    const f = await req.formData();
    const legal = String(f.get("legal_name") || "")
      .trim()
      .slice(0, 150);
    const sellerType = String(f.get("seller_type") || "individual");
    const contactEmail = String(f.get("contact_email") || u.email).trim().slice(0,200);
    const contactPhone = String(f.get("contact_phone") || store.phone || "").trim().slice(0,30);
    if (!["individual", "registered_business"].includes(sellerType) || !contactEmail.includes("@") || contactPhone.replace(/\D/g, "").length < 8) throw Error("Provide seller type and valid contact details");
    if (sellerType === "registered_business" && !String(f.get("registration") || "").trim()) throw Error("Registered businesses must provide their registration reference");
    const document = f.get("document");
    if (
      !legal ||
      !(document instanceof File) ||
      !["application/pdf", "image/jpeg", "image/png"].includes(document.type) ||
      document.size === 0 ||
      document.size > 8 * 1024 * 1024
    )
      throw Error(
        "Provide your legal name and a PDF, JPG or PNG document up to 8 MB.",
      );
    const bytes = new Uint8Array(await document.slice(0, 8).arrayBuffer());
    const valid =
      document.type === "application/pdf"
        ? String.fromCharCode(...bytes.slice(0, 5)) === "%PDF-"
        : document.type === "image/jpeg"
          ? bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255
          : bytes[0] === 137 &&
            String.fromCharCode(...bytes.slice(1, 4)) === "PNG";
    if (!valid) throw Error("The document does not match its file type");
    const id = crypto.randomUUID(),
      key = "verification/" + id,
      stamp = new Date().toISOString();
    await env.BUCKET.put(key, await document.arrayBuffer(), {
      httpMetadata: { contentType: document.type },
    });
    try {
      await env.DB.prepare(
        "INSERT INTO verification_requests(id,store,owner,legal_name,registration,file_key,file_type,status,note,created,updated,seller_type,contact_email,contact_phone) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      )
        .bind(
          id,
          store.id,
          u.userId,
          legal,
          String(f.get("registration") || "")
            .trim()
            .slice(0, 100),
          key,
          document.type,
          "pending",
          "",
          stamp,
          stamp,
          sellerType,
          contactEmail,
          contactPhone,
        )
        .run();
    } catch (e) {
      await env.BUCKET.delete(key);
      throw e;
    }
    await safelyEmail(()=>verificationEmail(id));
    return Response.json(
      { ok: true },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e: any) {
    return Response.json(
      {
        error: e.message?.includes("D1_ERROR")
          ? "Unable to submit. Refresh and retry."
          : e.message || "Unable to submit",
      },
      { status: e.message?.startsWith("Too many requests") ? 429 : 400 },
    );
  }
}
