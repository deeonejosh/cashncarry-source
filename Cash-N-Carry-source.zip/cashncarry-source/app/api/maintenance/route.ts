import { runMaintenance } from "../../maintenance-runner";
import { env } from "cloudflare:workers";
import { secretEqual } from "../../payments";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store" };
async function authorised(req: Request) {
  const credential = req.headers
      .get("authorization")
      ?.match(/^Bearer ([^\s]{1,1000})$/)?.[1],
    expected = env.MAINTENANCE_TOKEN_SHA256;
  if (!credential || !expected || !/^[a-f0-9]{64}$/.test(expected))
    return false;
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(credential),
  );
  return secretEqual(
    Array.from(new Uint8Array(digest), (b) =>
      b.toString(16).padStart(2, "0"),
    ).join(""),
    expected,
  );
}
/** Read-only credential/status check for the unattended runner; never sends emails. */
export async function GET(req: Request) {
  if (!(await authorised(req)))
    return Response.json({ error: "Unauthorised" }, { status: 401, headers });
  if (!env.DB)
    return Response.json(
      { error: "Storage unavailable" },
      { status: 503, headers },
    );
  const last = await env.DB.prepare(
    "SELECT value,updated FROM platform_settings WHERE key='last_maintenance_run'",
  ).first();
  return Response.json({ authorised: true, last }, { headers });
}
export async function POST(req: Request) {
  if (!(await authorised(req)))
    return Response.json({ error: "Unauthorised" }, { status: 401, headers });
  if (!env.DB)
    return Response.json(
      { error: "Storage unavailable" },
      { status: 503, headers },
    );
  try {
    return Response.json(await runMaintenance(), { headers });
  } catch {
    return Response.json(
      { error: "Maintenance failed; retry later" },
      { status: 503, headers },
    );
  }
}
