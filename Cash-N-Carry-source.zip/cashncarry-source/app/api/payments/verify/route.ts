import { limit } from "../../../security";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { env } from "cloudflare:workers";
import { verifyPayment } from "../../../payments";
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403 });
  const u = await getChatGPTUser();
  if (!u) return Response.json({ error: "Sign in" }, { status: 401 });
  try {
    await limit("payment-verification:" + u.userId, 15);
    const b: any = await req.json();
    if (
      typeof b.reference !== "string" ||
      !b.reference ||
      b.reference.length > 100 ||
      !/^\d{1,20}$/.test(String(b.transaction))
    )
      return Response.json(
        { error: "Invalid payment reference or transaction" },
        { status: 400 },
      );
    const p: any = await env
      .DB!.prepare("SELECT id,mode FROM payments WHERE id=? AND buyer=?")
      .bind(b.reference, u.userId)
      .first();
    if (!p)
      return Response.json({ error: "Payment not found" }, { status: 404 });
    return Response.json({...await verifyPayment(String(b.transaction), p.id), mode: p.mode});
  } catch (e: any) {
    const limited = e.message === "Too many requests. Try again in a minute.";
    return Response.json(
      { error: e.message },
      {
        status: limited ? 429 : 400,
        headers: limited ? { "Retry-After": "60" } : {},
      },
    );
  }
}
