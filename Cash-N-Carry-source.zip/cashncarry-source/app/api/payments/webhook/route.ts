import { verifySellerSubscription, reconcileSellerRenewal, recordProviderSubscriptionCancellation } from "../../../seller-finance";
import { env } from "cloudflare:workers";
import { secretEqual, verifyPayment } from "../../../payments";
export async function POST(req: Request) {
  const raw = await req.text();
  if (raw.length > 65536)
    return Response.json({ error: "Request too large" }, { status: 413 });
  const hash = env.FLW_WEBHOOK_HASH;
  const signature = req.headers.get("flutterwave-signature");
  let valid = false;
  if (hash && signature) {
    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(hash),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"],
    );
    const bytes = new Uint8Array(
      await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw)),
    );
    const expected = btoa(String.fromCharCode(...bytes));
    valid = secretEqual(signature, expected);
  } else if (hash) {
    // Flutterwave v3 Standard documents verif-hash; v4 uses a raw-body HMAC.
    valid = secretEqual(req.headers.get("verif-hash") || "", hash);
  }
  if (!valid)
    return Response.json({ error: "Invalid webhook" }, { status: 401 });
  try {
    const b: any = JSON.parse(raw);
    if(b.event==='subscription.cancelled'){
      await recordProviderSubscriptionCancellation(b.data);
      return Response.json({ok:true});
    }
    if (
      b.event === "charge.completed" &&
      ["successful", "failed", "cancelled"].includes(b.data?.status)
    ) {
      if (
        typeof b.data?.tx_ref !== "string" ||
        !b.data.tx_ref ||
        b.data.tx_ref.length > 100
      )
        return Response.json({ error: "Invalid reference" }, { status: 400 });
      if (await verifySellerSubscription(String(b.data.id), b.data.tx_ref)) return Response.json({ok:true});
      // A merchant account can emit payments from other integrations. Only
      // verify references created by this shop; acknowledge unrelated events
      // without changing an order or repeatedly rejecting their delivery.
      if (!env.DB) throw new Error("Payment database unavailable");
      const payment = await env.DB.prepare(
        "SELECT id FROM payments WHERE id=?",
      ).bind(b.data.tx_ref).first();
      if (!payment) {
        if (await reconcileSellerRenewal(String(b.data.id), b.data.tx_ref,b.data)) return Response.json({ok:true});
        return Response.json({ ok: true });
      }
      await verifyPayment(
        String(b.data.id),
        b.data.tx_ref,
        "charge-" + b.data.id,
      );
    }
    return Response.json({ ok: true });
  } catch {
    console.error("payment_webhook_failed");
    return Response.json({ error: "Verification failed" }, { status: 503 });
  }
}
