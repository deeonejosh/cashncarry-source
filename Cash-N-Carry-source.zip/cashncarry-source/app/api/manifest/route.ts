import { brand } from "../../brand";
export function GET() {
  return Response.json(
    {
      id: "/",
      name: brand.name,
      short_name: brand.name,
      description: brand.tagline,
      start_url: "/",
      scope: "/",
      display: "standalone",
      lang: "en-NG",
      background_color: "#FFF8EF",
      theme_color: "#164B35",
      icons: [
        { src: "/brand/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
        { src: "/brand/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
        { src: "/brand/icon-maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
      ],
    },
    {
      headers: {
        "Content-Type": "application/manifest+json",
        "Cache-Control": "public, max-age=300",
      },
    },
  );
}
