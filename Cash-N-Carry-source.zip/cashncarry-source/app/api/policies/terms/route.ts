import { env } from "cloudflare:workers";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const current = await env.DB?.prepare(
      "SELECT version,published_at,effective_date FROM policy_versions WHERE policy_id='terms' AND status='published' ORDER BY version DESC LIMIT 1",
    ).first<{version:number;published_at:string|null;effective_date:string|null}>();
    if (!current) return Response.json({ error: "Terms are not currently published" }, { status: 503, headers: { "Cache-Control": "no-store" } });
    return Response.json(current, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Terms version is temporarily unavailable" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
