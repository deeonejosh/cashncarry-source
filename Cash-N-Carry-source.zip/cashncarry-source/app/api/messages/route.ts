import { env } from "cloudflare:workers";
import { limit } from "../../security";
import { messageContext, messageThread, messageJson as json, validMessageFile } from "../../seller-messaging";
import {messageFileType} from "../../message-file-type";
export const dynamic="force-dynamic";
export async function GET(req:Request){
 try{
  const c=await messageContext();if(!c)return json({error:"Sign in to message a seller"},401);
  const url=new URL(req.url),store=url.searchParams.get("store"),selectedBuyer=url.searchParams.get("buyer"),buyer=selectedBuyer||c.user.userId;
  if(store){
   const own=await c.db.prepare("SELECT id,name FROM stores WHERE id=? AND owner=? AND suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles WHERE id=stores.owner AND suspended=1)").bind(store,c.user.userId).first<{id:string;name:string}>();
   if(own&&!selectedBuyer){
    const conversations=(await c.db.prepare("SELECT m.store,m.buyer,s.name,COALESCE('@'||NULLIF(p.username,''),'Buyer') AS counterpart,MAX(m.created) AS updated FROM seller_messages m JOIN stores s ON s.id=m.store LEFT JOIN profiles p ON p.id=m.buyer WHERE m.store=? AND s.owner=? GROUP BY m.store,m.buyer ORDER BY updated DESC LIMIT 100").bind(store,c.user.userId).all()).results;
    return json({conversations,name:own.name,user:c.user.userId,selectBuyer:true,isSeller:true});
   }
   const seller=await messageThread(c,store,buyer);if(!seller)return json({error:"Conversation unavailable. Select a buyer from your inbox."},403);
   const messages=(await c.db.prepare("SELECT m.id,m.sender,m.body,m.created,CASE WHEN m.sender=s.owner THEN s.name ELSE COALESCE('@'||NULLIF(p.username,''),'Buyer') END AS sender_name,f.name AS file_name,f.type AS file_type,f.size AS file_size FROM (SELECT * FROM seller_messages WHERE store=? AND buyer=? ORDER BY created DESC,id DESC LIMIT 200) m JOIN stores s ON s.id=m.store LEFT JOIN profiles p ON p.id=m.sender LEFT JOIN seller_message_files f ON f.message=m.id ORDER BY m.created,m.id").bind(store,buyer).all()).results;
   const profile=await c.db.prepare("SELECT username FROM profiles WHERE id=?").bind(buyer).first<{username:string}>();
   const buyerName=profile?.username?"@"+profile.username:"Buyer";
   return json({store:seller.id,name:seller.name,buyer,buyerName,peerName:seller.owner===c.user.userId?buyerName:seller.name,messages,verified:seller.verified,user:c.user.userId,isSeller:seller.owner===c.user.userId});
  }
  const conversations=(await c.db.prepare("SELECT m.store,m.buyer,s.name,CASE WHEN s.owner=? THEN COALESCE('@'||NULLIF(p.username,''),'Buyer') ELSE s.name END AS counterpart,MAX(m.created) AS updated FROM seller_messages m JOIN stores s ON s.id=m.store LEFT JOIN profiles p ON p.id=m.buyer WHERE (m.buyer=? OR s.owner=?) AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles WHERE id=s.owner AND suspended=1) GROUP BY m.store,m.buyer ORDER BY updated DESC LIMIT 100").bind(c.user.userId,c.user.userId,c.user.userId).all()).results;
  return json({conversations,user:c.user.userId});
 }catch{return json({error:"Unable to load messages. Please retry."},503);}
}
export async function POST(req:Request){
 let key:string|null=null;
 try{
  if(req.headers.get("Origin")!==new URL(req.url).origin)return json({error:"Request not allowed"},403);
  const c=await messageContext();if(!c)return json({error:"Sign in to send messages"},401);
  if(Number(req.headers.get("content-length")||0)>11*1024*1024)return json({error:"Attachments must be 10 MB or smaller"},413);
  await limit("seller-message:"+c.user.userId,30,60);
  let b:Record<string,unknown>,file:File|null=null;
  if(req.headers.get("content-type")?.startsWith("multipart/form-data")){
   const form=await req.formData();b={store:form.get("store"),buyer:form.get("buyer"),body:form.get("body"),id:form.get("id")};
   const candidate=form.get("file");if(candidate && typeof candidate!=="string")file=candidate;
  }else b=await req.json();
  const store=String(b.store||""),buyer=String(b.buyer||c.user.userId),body=String(b.body||"").trim(),id=String(b.id||crypto.randomUUID());
  if((!body&&!file)||body.length>2000)return json({error:"Write a message or attach a file. Messages can be up to 2,000 characters."},400);
  if(!await messageThread(c,store,buyer))return json({error:"Conversation unavailable. Select a buyer from your inbox."},403);
  const existing=await c.db.prepare("SELECT store,buyer,sender,EXISTS(SELECT 1 FROM seller_message_files f WHERE f.message=seller_messages.id) AS fileSaved FROM seller_messages WHERE id=?").bind(id).first<{store:string;buyer:string;sender:string;fileSaved:number}>();
  if(existing)return existing.store===store&&existing.buyer===buyer&&existing.sender===c.user.userId?json({ok:true,id,attachmentSaved:Boolean(existing.fileSaved)}):json({error:"Message reference already used. Reload and retry."},409);
  const created=new Date().toISOString();
  if(file){
   if(!await validMessageFile(file))return json({error:"Choose a valid JPG, PNG, WebP, PDF or TXT file up to 10 MB."},400);
   if(!env.BUCKET)return json({error:"Attachment storage temporarily unavailable"},503);
   await limit("seller-chat-upload:"+c.user.userId,10,60);
   key="private/chat/"+crypto.randomUUID();
   await env.BUCKET.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:messageFileType(file)},customMetadata:{owner:c.user.userId}});
   const name=file.name.replace(/[\x00-\x1f\x7f/\\]/g,"_").slice(0,160)||"Attachment";
   await c.db.batch([
    c.db.prepare("INSERT INTO seller_messages(id,store,buyer,sender,body,created) VALUES(?,?,?,?,?,?)").bind(id,store,buyer,c.user.userId,body,created),
    c.db.prepare("INSERT INTO seller_message_files(message,key,name,type,size) VALUES(?,?,?,?,?)").bind(id,key,name,messageFileType(file),file.size),
   ]);
   key=null;
  }else await c.db.prepare("INSERT INTO seller_messages(id,store,buyer,sender,body,created) VALUES(?,?,?,?,?,?)").bind(id,store,buyer,c.user.userId,body,created).run();
  return json({ok:true,id,attachmentSaved:Boolean(file)});
 }catch(e){
  console.error("seller_message_send_failed",{attachment:Boolean(key),cause:e instanceof Error?e.name:"Unknown"});
  if(key)await env.BUCKET?.delete(key).catch(()=>{});
  if(e instanceof Error&&e.message.startsWith("Too many requests"))return json({error:"Too many messages or uploads. Wait a minute and retry."},429);
  return json({error:"Message could not be sent. Please retry."},503);
 }
}
