import { env } from "cloudflare:workers";
import { messageContext,messageThread } from "../../../../seller-messaging";
export async function GET(req:Request,{params}:{params:Promise<{id:string}>}){
 const missing=()=>new Response("Attachment unavailable",{status:404,headers:{"Cache-Control":"no-store"}});
 try{
  const c=await messageContext();if(!c)return missing();
  const {id}=await params;
  const file=await c.db.prepare("SELECT m.store,m.buyer,f.key,f.name,f.type FROM seller_message_files f JOIN seller_messages m ON m.id=f.message WHERE m.id=?").bind(id).first<{store:string;buyer:string;key:string;name:string;type:string}>();
  if(!file||!await messageThread(c,file.store,file.buyer))return missing();
  const obj=await env.BUCKET?.get(file.key);if(!obj)return missing();
  const image=file.type.startsWith("image/")&&!new URL(req.url).searchParams.has("download");
  return new Response(obj.body,{headers:{"Content-Type":file.type,"Content-Disposition":`${image?"inline":"attachment"}; filename*=UTF-8''${encodeURIComponent(file.name)}`,"Cache-Control":"private,no-store","X-Content-Type-Options":"nosniff","Content-Security-Policy":"sandbox; default-src 'none'"}});
 }catch{return new Response("Attachment temporarily unavailable",{status:503,headers:{"Cache-Control":"no-store"}});}
}
