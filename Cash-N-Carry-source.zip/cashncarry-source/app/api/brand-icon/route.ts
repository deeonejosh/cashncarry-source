import { brand } from "../../brand";
/** Compatibility endpoint for previously installed app icons. */
export function GET(req: Request) {
  return Response.redirect(new URL(brand.symbol, req.url), 302);
}
