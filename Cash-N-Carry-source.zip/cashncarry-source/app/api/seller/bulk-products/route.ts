/* eslint-disable @typescript-eslint/no-explicit-any */
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { requireSellerActive, sellerActivation } from "../../../seller-activation";
import { ensureBulkProductSchema } from "../../../bulk-product-schema";
import { limit } from "../../../security";
import { getImageUploadPolicy } from "../../../media-upload-policy";
import {
  BULK_PRODUCT_MAX_ROWS,
  bulkDuplicateKey,
  isSafeBulkImageUrl,
  splitBulkImageUrls,
} from "../../../bulk-product-utils.mjs";

export const dynamic = "force-dynamic";
const json = (body: unknown, status = 200) =>
  Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
const q = (sql: string, ...args: unknown[]) => env.DB!.prepare(sql).bind(...args);
const stamp = () => new Date().toISOString();
const text = (value: unknown, max: number) => String(value ?? "").trim().slice(0, max);
const money = (value: unknown) => {
  if (typeof value === "boolean" || value === null || value === undefined || String(value).trim() === "") return NaN;
  const normalized = String(value).replace(/[₦,\s]/g, "");
  const amount = Number(normalized);
  return Number.isSafeInteger(amount) ? amount : NaN;
};
const csvSafeText = (value: unknown) => String(value ?? "").slice(0, 10000);

type NormalizedRow = {
  rowNumber: number;
  name: string;
  description: string;
  category: string;
  price: number;
  sku: string;
  stock: number;
  image: string;
  images: string[];
  active: number;
  sourceKey: string;
  errors: string[];
  status: "imported" | "failed" | "duplicate" | "ready";
};

async function readJson(req: Request) {
  const length = Number(req.headers.get("content-length") || 0);
  if (length > 8 * 1024 * 1024) throw Error("This import is too large. Upload no more than 500 products at a time.");
  const raw = await req.text();
  if (new TextEncoder().encode(raw).byteLength > 8 * 1024 * 1024) throw Error("This import is too large. Upload no more than 500 products at a time.");
  const body = JSON.parse(raw);
  if (!body || typeof body !== "object" || Array.isArray(body)) throw Error("Invalid bulk upload request.");
  if (!Array.isArray(body.rows) || body.rows.length < 1 || body.rows.length > BULK_PRODUCT_MAX_ROWS) throw Error(`Upload between 1 and ${BULK_PRODUCT_MAX_ROWS} product rows.`);
  return body;
}

async function validateRows(input: unknown[], store: string, origin: string): Promise<NormalizedRow[]> {
  const imagePolicy = await getImageUploadPolicy(env.DB);
  const categories = (await q("SELECT name FROM categories WHERE active=1 ORDER BY name").all<{ name: string }>()).results;
  const categoryByKey = new Map(categories.map(({ name }) => [name.trim().toLocaleLowerCase(), name]));
  const usedRowNumbers = new Set<number>();
  const rawRows = input.map((raw: any, index) => {
    let rowNumber = Number.isSafeInteger(Number(raw?.rowNumber)) && Number(raw.rowNumber) >= 2 ? Number(raw.rowNumber) : index + 2;
    if (usedRowNumbers.has(rowNumber)) {
      rowNumber = index + 2;
      while (usedRowNumbers.has(rowNumber)) rowNumber++;
    }
    usedRowNumbers.add(rowNumber);
    return {
      rowNumber,
      name: text(raw?.name, 100),
      description: text(raw?.description, 2000),
      categoryInput: text(raw?.category, 100),
      price: money(raw?.price),
      sku: text(raw?.sku, 80),
      stockInput: raw?.stock,
      image: text(raw?.image, 1500),
      images: Array.isArray(raw?.images) ? raw.images.map((x: unknown) => text(x, 1500)).filter(Boolean).slice(0, 9) : splitBulkImageUrls(raw?.additionalImages),
      statusInput: text(raw?.status, 20).toLocaleLowerCase() || "draft",
    };
  });
  const categoryNames = new Set(categories.map((c) => c.name.toLocaleLowerCase()));
  const categoryAliases = new Map<string, string>();
  // The shop uses "Electronics" as its customer-facing label for stored Tech.
  if (categoryNames.has("tech")) categoryAliases.set("electronics", categoryByKey.get("tech")!);
  const skuValues = rawRows.map((r) => r.sku).filter(Boolean);
  const existingSkuSet = new Set<string>();
  for (let offset = 0; offset < skuValues.length; offset += 80) {
    const part = skuValues.slice(offset, offset + 80);
    if (!part.length) continue;
    const placeholders = part.map(() => "?").join(",");
    const existing = await q(`SELECT sku FROM products WHERE store=? AND lower(sku) IN (${placeholders})`, store, ...part.map((x) => x.toLocaleLowerCase())).all<{ sku: string }>();
    for (const item of existing.results) existingSkuSet.add(item.sku.toLocaleLowerCase());
  }
  const seen = new Set<string>();
  const output: NormalizedRow[] = [];
  for (const row of rawRows) {
    const errors: string[] = [];
    if (!row.name) errors.push("Product Name is required.");
    if (!row.description) errors.push("Description is required by the product form.");
    const categoryKey = row.categoryInput.toLocaleLowerCase();
    const acceptedCategory = categoryByKey.get(categoryKey) || categoryAliases.get(categoryKey);
    if (!row.categoryInput || !acceptedCategory) errors.push("Choose an active Cash N Carry category.");
    if (!Number.isSafeInteger(row.price) || row.price < 100) errors.push("Price must be a whole NGN amount of at least ₦100, matching the existing product form.");
    const stock = Number(row.stockInput);
    if (typeof row.stockInput === "boolean" || row.stockInput === null || row.stockInput === undefined || String(row.stockInput).trim() === "" || !Number.isSafeInteger(stock) || stock < 0 || stock > 100000) errors.push("Stock Quantity must be a whole number from 0 to 100,000.");
    if (row.sku && !/^[A-Za-z0-9][A-Za-z0-9._/-]{0,79}$/.test(row.sku)) errors.push("SKU may contain letters, numbers, dots, underscores, slashes and hyphens.");
    if (row.images.length + (row.image ? 1 : 0) > imagePolicy.maxImagesPerProduct) errors.push(`Use no more than ${imagePolicy.maxImagesPerProduct} images per product. Separate image URLs with |.`);
    const mainImageProblem = isSafeBulkImageUrl(row.image, origin);
    if (mainImageProblem) errors.push(`Main Image URL: ${mainImageProblem}`);
    for (const [index, image] of row.images.entries()) {
      const imageProblem = isSafeBulkImageUrl(image, origin);
      if (imageProblem) errors.push(`Additional Image URL ${index + 1}: ${imageProblem}`);
    }
    if (!["draft", "publish", "published"].includes(row.statusInput)) errors.push("Product Status must be Draft or Publish.");
    if (row.sku && existingSkuSet.has(row.sku.toLocaleLowerCase())) errors.push("This SKU is already used by one of your products.");
    const canonicalCategory = acceptedCategory || row.categoryInput;
    const normalized: NormalizedRow = { rowNumber: row.rowNumber, name: row.name, description: row.description, category: canonicalCategory, price: row.price, sku: row.sku, stock: Number.isSafeInteger(stock) ? stock : 0, image: row.image, images: row.images, active: ["publish", "published"].includes(row.statusInput) ? 1 : 0, sourceKey: "", errors, status: "ready" };
    const duplicateKey = bulkDuplicateKey(normalized);
    if (seen.has(duplicateKey)) errors.push(row.sku ? "Duplicate SKU appears more than once in this spreadsheet." : "Duplicate product row appears more than once in this spreadsheet.");
    else seen.add(duplicateKey);
    if (row.sku && existingSkuSet.has(row.sku.toLocaleLowerCase()) && !errors.some((e) => e.includes("already used"))) errors.push("This SKU is already used by one of your products.");
    if (errors.some((e) => e.includes("Duplicate") || e.includes("already used"))) normalized.status = "duplicate";
    else if (errors.length) normalized.status = "failed";
    output.push(normalized);
  }
  for (const row of output) {
    // Image edits should not turn a re-upload of the same seller product into a new item.
    const source = JSON.stringify({ store, name: row.name.toLocaleLowerCase(), description: row.description, category: row.category.toLocaleLowerCase(), price: row.price, sku: row.sku.toLocaleLowerCase(), stock: row.stock, active: row.active });
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(source));
    row.sourceKey = Array.from(new Uint8Array(digest), (x) => x.toString(16).padStart(2, "0")).join("");
  }
  const sourceKeys = output.map((row) => row.sourceKey);
  const previouslyImported = new Set<string>();
  for (let offset = 0; offset < sourceKeys.length; offset += 80) {
    const part = sourceKeys.slice(offset, offset + 80);
    if (!part.length) continue;
    const existing = await q(`SELECT r.source_key FROM seller_product_import_rows r JOIN seller_product_imports i ON i.id=r.import_id WHERE i.store=? AND r.status='imported' AND r.source_key IN (${part.map(() => "?").join(",")})`, store, ...part).all<{ source_key: string }>();
    for (const item of existing.results) previouslyImported.add(item.source_key);
  }
  for (const row of output) {
    if (previouslyImported.has(row.sourceKey) && !row.errors.some((message) => message.includes("already imported"))) {
      row.errors.push("This exact product row was already imported by an earlier upload.");
      row.status = "duplicate";
    }
  }
  // Do not fetch remote URLs. For first-party uploads, confirm the object belongs
  // to this seller before accepting it into a product row.
  for (const row of output) {
    for (const url of [row.image, ...row.images]) {
      if (!url.startsWith("/api/media/")) continue;
      const key = url.slice("/api/media/".length);
      const blocked = await q("SELECT key FROM media_blocks WHERE key=?", key).first();
      if (blocked) row.errors.push("An uploaded image has been removed from public listings.");
      const object = await env.BUCKET?.head(key);
      if (!object || object.customMetadata?.owner !== (await q("SELECT owner FROM stores WHERE id=?", store).first<{ owner: string }>())?.owner) row.errors.push("Use only uploaded images belonging to your seller account.");
      if (row.errors.length && row.status === "ready") row.status = "failed";
    }
  }
  return output;
}

function importHash(rows: NormalizedRow[]) {
  const normalized = rows.map(({ rowNumber, name, description, category, price, sku, stock, image, images, active }) => ({ rowNumber, name, description, category, price, sku, stock, image, images, active }));
  return crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(normalized))).then((value) => Array.from(new Uint8Array(value), (x) => x.toString(16).padStart(2, "0")).join(""));
}

async function loadExistingImport(id: string, store: string) {
  const record = await q("SELECT * FROM seller_product_imports WHERE id=? AND store=?", id, store).first<any>();
  const rows = await q("SELECT row_number AS rowNumber,status,sku,product_name AS name,product_id AS productId,errors FROM seller_product_import_rows WHERE import_id=? ORDER BY row_number", id).all<any>();
  return { record, rows: rows.results.map((r: any) => ({ ...r, errors: JSON.parse(r.errors || "[]") })) };
}

async function saveRow(importId: string, row: NormalizedRow, status: "failed" | "duplicate", errors = row.errors) {
  await q("INSERT OR IGNORE INTO seller_product_import_rows(import_id,row_number,status,sku,product_name,product_id,source_key,errors,created) VALUES(?,?,?,?,?,?,?,?,?)", importId, row.rowNumber, status, row.sku, row.name, "", row.sourceKey, JSON.stringify(errors), stamp()).run();
}

export async function GET(req: Request) {
  try {
    await ensureBulkProductSchema();
    const user = await getChatGPTUser();
    if (!user) return json({ error: "Sign in to use bulk upload." }, 401);
    const store = await q("SELECT id,suspended FROM stores WHERE owner=?", user.userId).first<any>();
    if (!store) return json({ error: "Create your seller storefront first." }, 404);
    const url = new URL(req.url);
    const importId = url.searchParams.get("import") || "";
    if (importId) {
      const data = await loadExistingImport(importId, store.id);
      if (!data.record) return json({ error: "Import not found." }, 404);
      return json({ import: data.record, rows: data.rows });
    }
    const [categories, history, access] = await Promise.all([
      q("SELECT name FROM categories WHERE active=1 ORDER BY name").all<{ name: string }>(),
      q("SELECT id,status,total,imported,failed,duplicates,created,updated FROM seller_product_imports WHERE store=? ORDER BY created DESC LIMIT 25", store.id).all(),
      sellerActivation(store.id),
    ]);
    return json({ categories: categories.results.map((x) => x.name), history: history.results, canSell: access.canSell, activation: access });
  } catch {
    return json({ error: "Unable to load product import history." }, 503);
  }
}

export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin) return json({ error: "Invalid request origin." }, 403);
  try {
    await ensureBulkProductSchema();
    const user = await getChatGPTUser();
    if (!user) return json({ error: "Sign in to continue." }, 401);
    const body = await readJson(req);
    await limit("bulk-products:" + user.userId, 12, 60);
    const store = await q("SELECT * FROM stores WHERE owner=?", user.userId).first<any>();
    if (!store) return json({ error: "Create your seller storefront first." }, 404);
    if (store.suspended) return json({ error: "Selling is suspended for this store." }, 403);
    const rows = await validateRows(body.rows, store.id, new URL(req.url).origin);
      if (body.action === "preview") {
      const access = await sellerActivation(store.id);
      const valid = rows.filter((r) => r.status === "ready").length;
      return json({ rows: rows.map((row) => ({ ...row, imagePreviewAllowed: row.image.startsWith("/api/media/") && !row.errors.some((message) => message.includes("uploaded image")), statusCode: row.status, status: row.active ? "Publish" : "Draft" })), total: rows.length, valid, invalid: rows.filter((r) => r.status === "failed").length, duplicates: rows.filter((r) => r.status === "duplicate").length, canImport: access.canSell, accessMessage: access.canSell ? "" : "Seller verification and active selling access are required to import products." });
    }
    if (body.action !== "import") return json({ error: "Choose preview or import." }, 400);
    await requireSellerActive(store.id);
    let importId = text(body.importId, 80);
    if (!/^[a-f0-9-]{36}$/i.test(importId)) return json({ error: "Start a new import preview before importing." }, 400);
    const fingerprint = await importHash(rows);
    const ts = stamp();
    const prior = await q("SELECT id,status FROM seller_product_imports WHERE store=? AND fingerprint=? ORDER BY created DESC LIMIT 1", store.id, fingerprint).first<{ id: string; status: string }>();
    if (prior && prior.id !== importId) {
      if (prior.status !== "processing") {
        const priorData = await loadExistingImport(prior.id, store.id);
        return json({ import: priorData.record, rows: priorData.rows, duplicateImport: true });
      }
      // Resume an interrupted in-flight import with its original idempotency key.
      importId = prior.id;
    }
    await q("INSERT OR IGNORE INTO seller_product_imports(id,store,fingerprint,status,total,imported,failed,duplicates,created,updated) VALUES(?,?,?,'processing',?,0,0,0,?,?)", importId, store.id, fingerprint, rows.length, ts, ts).run();
    const state = await loadExistingImport(importId, store.id);
    if (!state.record) return json({ error: "Could not start this import." }, 503);
    if (state.record.fingerprint !== fingerprint) return json({ error: "This import ID is already associated with a different spreadsheet. Start a new preview." }, 409);
    if (state.record.status !== "processing") return json({ import: state.record, rows: state.rows, resumed: true });

    const encoder = new TextEncoder();
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        const send = (event: unknown) => controller.enqueue(encoder.encode(JSON.stringify(event) + "\n"));
        void (async () => {
          try {
            const previousRows = await q("SELECT row_number,status FROM seller_product_import_rows WHERE import_id=?", importId).all<any>();
            const handled = new Map<number, string>(previousRows.results.map((r: any) => [Number(r.row_number), r.status]));
            for (const row of rows) {
              if (handled.has(row.rowNumber)) continue;
              if (row.status === "failed") { await saveRow(importId, row, "failed"); handled.set(row.rowNumber, "failed"); }
              else if (row.status === "duplicate") { await saveRow(importId, row, "duplicate"); handled.set(row.rowNumber, "duplicate"); }
            }
            const pending = rows.filter((r) => r.status === "ready" && !handled.has(r.rowNumber));
            let completed = handled.size;
            send({ type: "progress", completed, total: rows.length });
            for (let offset = 0; offset < pending.length; offset += 25) {
              const batchRows = pending.slice(offset, offset + 25);
              const statements = batchRows.flatMap((row) => {
                const productId = crypto.randomUUID();
                return [
                  q("INSERT INTO products(id,store,name,sku,description,category,price,stock,image,video,active,images,variants,created) VALUES(?,?,?,?,?,?,?,?,?,'',?,?,?,?)", productId, store.id, row.name, row.sku, row.description, row.category, row.price, row.stock, row.image, row.active, JSON.stringify(row.images), "[]", ts),
                  q("INSERT INTO seller_product_import_rows(import_id,row_number,status,sku,product_name,product_id,source_key,errors,created) VALUES(?,?, 'imported',?,?,?,?, '[]',?)", importId, row.rowNumber, row.sku, row.name, productId, row.sourceKey, ts),
                ];
              });
              try {
                await env.DB!.batch(statements as any);
                completed += batchRows.length;
              } catch {
                // A unique SKU race or a single row constraint should not lose
                // the rest of this batch. Retry each pair atomically and record
                // the exact row result for later reconciliation.
                for (const row of batchRows) {
                  const productId = crypto.randomUUID();
                  try {
                    await env.DB!.batch([
                      q("INSERT INTO products(id,store,name,sku,description,category,price,stock,image,video,active,images,variants,created) VALUES(?,?,?,?,?,?,?,?,?,'',?,?,?,?)", productId, store.id, row.name, row.sku, row.description, row.category, row.price, row.stock, row.image, row.active, JSON.stringify(row.images), "[]", ts),
                      q("INSERT INTO seller_product_import_rows(import_id,row_number,status,sku,product_name,product_id,source_key,errors,created) VALUES(?,?, 'imported',?,?,?,?, '[]',?)", importId, row.rowNumber, row.sku, row.name, productId, row.sourceKey, ts),
                    ] as any);
                  } catch (error: any) {
                    const duplicate = /unique constraint failed: products\.store, products\.sku|unique constraint failed: index ['"]?(?:products_store_sku|seller_product_import_rows_source_key)/i.test(String(error?.message || error));
                    await saveRow(importId, row, duplicate ? "duplicate" : "failed", [duplicate ? "This SKU is already used by one of your products." : "This product could not be saved. Review the row and retry."]);
                  }
                  completed++;
                }
              }
              send({ type: "progress", completed, total: rows.length });
            }
            const result = await loadExistingImport(importId, store.id);
            const imported = result.rows.filter((r: any) => r.status === "imported").length;
            const failed = result.rows.filter((r: any) => r.status === "failed").length;
            const duplicates = result.rows.filter((r: any) => r.status === "duplicate").length;
            const status = failed || duplicates ? "partial" : "completed";
            await q("UPDATE seller_product_imports SET status=?,total=?,imported=?,failed=?,duplicates=?,updated=? WHERE id=? AND store=?", status, rows.length, imported, failed, duplicates, stamp(), importId, store.id).run();
            const final = await loadExistingImport(importId, store.id);
            send({ type: "complete", import: final.record, rows: final.rows });
          } catch {
            send({ type: "error", error: "The import was interrupted. Retry this same import to reconcile completed rows without creating duplicates." });
          } finally {
            controller.close();
          }
        })();
      },
    });
    return new Response(stream, { headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
  } catch (error: any) {
    if (error?.message?.startsWith("Too many requests")) return json({ error: error.message }, 429);
    if (error?.message?.includes("verification") || error?.message?.includes("subscription") || error?.message?.includes("selling access") || error?.message?.includes("active selling")) return json({ error: error.message }, 403);
    if (error?.message === "Unexpected end of JSON input" || error instanceof SyntaxError) return json({ error: "The import request could not be read. Please retry." }, 400);
    const message = csvSafeText(error?.message || "");
    const safeMessage = /^(?:Invalid bulk upload request|Upload between \d+ and \d+ product rows|This import is too large|Choose preview or import|The import request could not be read|Start a new import preview|This import ID is already associated|Too many requests|Complete seller verification|An active seller subscription|Selling is suspended|Create your seller storefront)/i.test(message);
    return json({ error: safeMessage ? message : "Unable to process this import. Please retry or contact support if the issue continues." }, safeMessage ? 400 : 503);
  }
}
