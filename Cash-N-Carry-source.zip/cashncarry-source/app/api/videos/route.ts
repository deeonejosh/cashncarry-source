import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { eligibleSellerSQL, requireSellerActive } from "../../seller-activation";
import { limit } from "../../security";
import { isAdmin } from "../../admin-access";
import { ensureVideoStorefrontSchema } from "../../video-storefront-schema";

export const dynamic = "force-dynamic";
const json = (data: any, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
const db = () => { if (!env.DB) throw Error("Storage unavailable"); return env.DB; };
const q = (sql: string, ...args: any[]) => db().prepare(sql).bind(...args);
const all = async (sql: string, ...args: any[]) => (await q(sql, ...args).all<any>()).results;
const now = () => new Date().toISOString();
const mediaKey = (url: string) => /^\/api\/media\/([a-zA-Z0-9_-]+)$/.exec(url)?.[1] || "";

async function videoRows(where: string, args: any[], userId: string | null, limitRows: number) {
  const rows = await all(
    `SELECT v.id,v.store,v.owner,v.media,v.thumbnail,v.caption,v.hashtags,v.status,v.published,v.created,s.name AS seller,s.verified AS verified,f.slug AS store_slug,(SELECT COUNT(*) FROM videos sv WHERE sv.store=s.id AND sv.status='approved') AS seller_video_count,(SELECT COUNT(*) FROM video_likes vl WHERE vl.video=v.id) AS likes,(SELECT COUNT(*) FROM video_comments vc WHERE vc.video=v.id AND vc.hidden=0) AS comments,(SELECT COUNT(DISTINCT ve.visitor) FROM video_events ve WHERE ve.video=v.id AND ve.kind='view') AS views,${userId ? `EXISTS(SELECT 1 FROM video_likes ul WHERE ul.video=v.id AND ul.user=?)` : "0"} AS liked,${userId ? `EXISTS(SELECT 1 FROM video_saves us WHERE us.video=v.id AND us.user=?)` : "0"} AS saved,${userId ? `EXISTS(SELECT 1 FROM follows fo WHERE fo.user=? AND fo.store=s.id)` : "0"} AS following FROM videos v JOIN stores s ON s.id=v.store LEFT JOIN storefronts f ON f.store=s.id WHERE ${where} ORDER BY v.created DESC LIMIT ?`,
    ...(userId ? [userId, userId, userId] : []), ...args, limitRows,
  );
  if (!rows.length) return [];
  const ids = rows.map((r: any) => r.id);
  const tagged = await all(`SELECT vp.video,p.id,p.name,p.price,p.stock,p.image,p.active,p.variants FROM video_products vp JOIN products p ON p.id=vp.product WHERE vp.video IN (${ids.map(() => "?").join(",")}) ORDER BY p.featured DESC,p.created DESC`, ...ids);
  const products = new Map<string, any[]>();
  for (const p of tagged) products.set(p.video, [...(products.get(p.video) || []), p]);
  return rows.map((v: any) => ({ ...v, products: (products.get(v.id) || []).filter((p) => p.active) }));
}

export async function GET(req: Request) {
  try {
    await ensureVideoStorefrontSchema();
    const url = new URL(req.url), user = await getChatGPTUser();
    const mine = url.searchParams.get("mine") === "1";
    if (mine) {
      if (!user) return json({ error: "Sign in required" }, 401);
      const store: any = await q("SELECT id FROM stores WHERE owner=?", user.userId).first();
      if (!store) return json({ videos: [] });
      const videos = await videoRows("v.store=? AND v.owner=?", [store.id, user.userId], user.userId, 100);
      const stats = await all("SELECT video,kind,CASE WHEN kind='view' THEN COUNT(DISTINCT visitor) ELSE COUNT(*) END AS count FROM video_events WHERE video IN (SELECT id FROM videos WHERE store=?) GROUP BY video,kind", store.id);
      const counts = new Map<string, any>();
      for (const x of stats) counts.set(x.video, { ...(counts.get(x.video) || {}), [x.kind]: x.count });
      return json({ videos: videos.map((v: any) => ({ ...v, analytics: counts.get(v.id) || {} })) });
    }
    if (url.searchParams.get("moderation") === "1") {
      if (!await isAdmin(user, "products")) return json({ error: "Administrator access required" }, user ? 403 : 401);
      const videos = await videoRows("v.status IN ('pending','rejected','removed')", [], user?.userId || null, 200);
      return json({ videos });
    }
    const id = url.searchParams.get("id") || "";
    const storeParam = url.searchParams.get("store") || "";
    const product = url.searchParams.get("product") || "";
    const following = url.searchParams.get("following") === "1";
    const limitRows = Math.min(30, Math.max(1, Number(url.searchParams.get("limit") || 12) || 12));
    const conditions = ["v.status='approved'", "v.published=1", "s.suspended=0", `(${eligibleSellerSQL("s")})`, "NOT EXISTS(SELECT 1 FROM profiles pr WHERE pr.id=s.owner AND pr.suspended=1)", "NOT EXISTS(SELECT 1 FROM media_blocks mb WHERE mb.key=substr(v.media,instr(v.media,'/api/media/')+11))", "EXISTS(SELECT 1 FROM video_products vp JOIN products p ON p.id=vp.product WHERE vp.video=v.id AND p.active=1)"];
    const args: any[] = [];
    if (id) { conditions.push("v.id=?"); args.push(id.slice(0, 100)); }
    if (storeParam) { conditions.push("(s.id=? OR f.slug=?)"); args.push(storeParam.slice(0, 100), storeParam.toLowerCase().slice(0, 60)); }
    if (product) { conditions.push("EXISTS(SELECT 1 FROM video_products pv WHERE pv.video=v.id AND pv.product=?)"); args.push(product.slice(0, 100)); }
    if (following) {
      if (!user) return json({ error: "Sign in to see videos from sellers you follow" }, 401);
      conditions.push("EXISTS(SELECT 1 FROM follows fo WHERE fo.user=? AND fo.store=s.id)"); args.push(user.userId);
    }
    let videos = await videoRows(conditions.join(" AND "), args, user?.userId || null, Math.min(90, limitRows * 3));
    const time = Date.now();
    videos = videos.map((v: any) => {
      const ageHours = Math.max(0, (time - new Date(v.created).getTime()) / 3600000);
      const freshness = Math.exp(-ageHours / 120);
      const availability = v.products.some((p: any) => p.stock > 0) ? 0.4 : 0;
      const sellerDiscovery = Number(v.seller_video_count) <= 3 ? 0.7 : 0;
      const quality = v.verified ? 0.45 : 0;
      const engagement = Math.log1p(Number(v.likes)) * 0.35 + Math.log1p(Number(v.views)) * 0.18;
      return { ...v, _rank: freshness * 1.5 + availability + sellerDiscovery + quality + engagement };
    }).sort((a: any, b: any) => b._rank - a._rank).slice(0, limitRows).map((v: any) => { const { _rank } = v; void _rank; return v; });
    // Comment threads are public only when the requested video itself passed
    // every public-feed eligibility check above. This keeps drafts and
    // moderation-held videos from leaking their comment text by ID.
    const comments = id && videos.some((video: any) => video.id === id)
      ? await all("SELECT c.id,c.video,c.parent,c.body,c.created,COALESCE(p.username,'Shopper') AS username FROM video_comments c LEFT JOIN profiles p ON p.id=c.user WHERE c.video=? AND c.hidden=0 ORDER BY c.created ASC LIMIT 100", id)
      : [];
    return json({ videos, comments });
  } catch {
    return json({ error: "Unable to load videos. Please retry." }, 503);
  }
}

export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin) return json({ error: "Invalid request origin" }, 403);
  try {
    await ensureVideoStorefrontSchema();
    const body: any = await req.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) throw Error("Invalid request");
    const action = String(body.action || "");
    if (action === "event") {
      const kinds = ["view", "product_click", "store_visit", "add_to_cart"];
      const kind = String(body.kind || "");
      const visitor = String(body.visitor || "").slice(0, 80);
      if (!kinds.includes(kind) || !/^[a-zA-Z0-9_-]{16,80}$/.test(visitor)) throw Error("Invalid video event");
      const video: any = await q("SELECT id FROM videos WHERE id=? AND status='approved' AND published=1", String(body.video || "").slice(0, 100)).first();
      if (!video) return json({ error: "Video unavailable" }, 404);
      await limit("video-event:" + visitor, 90);
      const day = now().slice(0, 10);
      await q("INSERT OR IGNORE INTO video_events(id,video,visitor,kind,day,created) VALUES(?,?,?,?,?,?)", crypto.randomUUID(), video.id, visitor, kind, day, now()).run();
      return json({ ok: true });
    }
    const user = await getChatGPTUser();
    if (!user) return json({ error: "Sign in to continue" }, 401);
    await limit("video-action:" + user.userId, 45);
    const profile: any = await q("SELECT suspended FROM profiles WHERE id=?", user.userId).first();
    if (profile?.suspended) throw Error("Your account is suspended.");
    const videoId = String(body.id || body.video || "").slice(0, 100);
    const at = now();
    if (["create", "update"].includes(action)) {
      const store: any = await q("SELECT id,suspended FROM stores WHERE owner=?", user.userId).first();
      if (!store) throw Error("Create your seller account in Seller Centre first.");
      if (store.suspended) throw Error("Your store is suspended.");
      const prior: any = action === "update" ? await q("SELECT * FROM videos WHERE id=? AND store=? AND owner=?", videoId, store.id, user.userId).first() : null;
      if (action === "update" && !prior) throw Error("Video not found.");
      if (prior?.status === "removed") throw Error("Removed videos cannot be edited.");
      const media = String(body.media || prior?.media || "").slice(0, 200);
      const key = mediaKey(media);
      if (!key || !env.BUCKET) throw Error("Upload a video file to Cash N Carry first.");
      const object = await env.BUCKET.head(key);
      if (!object || object.customMetadata?.owner !== user.userId || !String(object.httpMetadata?.contentType || "").startsWith("video/")) throw Error("Use a video uploaded by your seller account.");
      if (await q("SELECT key FROM media_blocks WHERE key=?", key).first()) throw Error("This video was removed by moderation.");
      const thumbnail = String(body.thumbnail ?? prior?.thumbnail ?? "").slice(0, 200);
      if (thumbnail && !mediaKey(thumbnail)) throw Error("Upload a thumbnail image through Cash N Carry.");
      if (thumbnail) {
        const thumb = await env.BUCKET.head(mediaKey(thumbnail));
        if (!thumb || thumb.customMetadata?.owner !== user.userId || !String(thumb.httpMetadata?.contentType || "").startsWith("image/")) throw Error("Use an image uploaded by your seller account.");
      }
      const oldTags = prior ? await all("SELECT product FROM video_products WHERE video=?", videoId) : [];
      const products = Array.isArray(body.products) ? [...new Set(body.products.map((x: any) => String(x).slice(0, 100)))].slice(0, 5) : oldTags.map((x: any) => x.product);
      if (!products.length) throw Error("Tag at least one product from your catalogue.");
      const allowed: any = await q(`SELECT COUNT(*) AS count FROM products WHERE store=? AND active=1 AND id IN (${products.map(() => "?").join(",")})`, store.id, ...products).first();
      if (Number(allowed?.count) !== products.length) throw Error("Only published products from your store can be tagged.");
      const caption = String(body.caption || "").trim().slice(0, 500);
      const hashtags = Array.isArray(body.hashtags) ? body.hashtags.map((x: any) => String(x).replace(/^#/, "").replace(/[^\p{L}\p{N}_]/gu, "").slice(0, 30)).filter(Boolean).slice(0, 10) : [];
      const publish = body.publish === true;
      if (publish) await requireSellerActive(store.id);
      let id = videoId;
      if (action === "create") {
        id = crypto.randomUUID();
        const status = publish ? "pending" : "draft";
        await q("INSERT INTO videos(id,store,owner,media,thumbnail,caption,hashtags,status,published,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)", id, store.id, user.userId, media, thumbnail, caption, JSON.stringify(hashtags), status, 0, at, at).run();
      } else {
        await q("UPDATE videos SET media=?,thumbnail=?,caption=?,hashtags=?,status=?,published=0,updated=?,moderation_note='' WHERE id=? AND owner=?", media, thumbnail, caption, JSON.stringify(hashtags), publish ? "pending" : "draft", at, id, user.userId).run();
        await q("DELETE FROM video_products WHERE video=?", id).run();
      }
      for (const product of products) await q("INSERT INTO video_products(video,product) VALUES(?,?)", id, product).run();
      return json({ ok: true, id, status: publish ? "pending" : "draft" });
    }
    if (action === "submit") {
      const owned: any = await q("SELECT id,store,status FROM videos WHERE id=? AND owner=?", videoId, user.userId).first();
      if (!owned) throw Error("Video not found.");
      if (["removed", "approved", "pending"].includes(owned.status)) throw Error("This video cannot be submitted in its current state.");
      await requireSellerActive(owned.store);
      if (!await q("SELECT 1 FROM video_products vp JOIN products p ON p.id=vp.product WHERE vp.video=? AND p.active=1 LIMIT 1", videoId).first()) throw Error("Add a published product tag before submitting.");
      await q("UPDATE videos SET status='pending',published=0,updated=?,moderation_note='' WHERE id=? AND owner=?", at, videoId, user.userId).run();
      return json({ ok: true, status: "pending" });
    }
    const owned: any = await q("SELECT v.id,v.store,v.owner,v.status FROM videos v WHERE v.id=?", videoId).first();
    if (!owned) throw Error("Video not found.");
    if (action === "delete") {
      if (owned.owner !== user.userId) return json({ error: "Video access denied" }, 403);
      await q("UPDATE videos SET status='removed',published=0,updated=? WHERE id=?", at, videoId).run();
      return json({ ok: true });
    }
    const publicVideo: any = await q("SELECT id FROM videos WHERE id=? AND status='approved' AND published=1", videoId).first();
    if (!publicVideo) return json({ error: "Video unavailable" }, 404);
    if (action === "like" || action === "save") {
      const table = action === "like" ? "video_likes" : "video_saves";
      if (body.enabled) await q(`INSERT OR IGNORE INTO ${table}(video,user,created) VALUES(?,?,?)`, videoId, user.userId, at).run();
      else await q(`DELETE FROM ${table} WHERE video=? AND user=?`, videoId, user.userId).run();
      return json({ ok: true, enabled: Boolean(body.enabled) });
    }
    if (action === "comment") {
      const text = String(body.body || "").trim().slice(0, 500);
      if (!text) throw Error("Write a comment first.");
      const parent = String(body.parent || "").slice(0, 100);
      if (parent && !await q("SELECT id FROM video_comments WHERE id=? AND video=? AND hidden=0", parent, videoId).first()) throw Error("Comment reply target not found.");
      const id = crypto.randomUUID();
      await q("INSERT INTO video_comments(id,video,user,parent,body,created) VALUES(?,?,?,?,?,?)", id, videoId, user.userId, parent, text, at).run();
      return json({ ok: true, id });
    }
    if (action === "report") {
      const reason = String(body.reason || "other").slice(0, 80);
      await q("INSERT INTO reports(id,reporter,target_type,target,reason,details,status,created,updated) VALUES(?,?,?,?,?,?, 'open',?,?)", crypto.randomUUID(), user.userId, "video", videoId, reason, String(body.details || "").trim().slice(0, 500), at, at).run();
      return json({ ok: true });
    }
    throw Error("Unsupported video action.");
  } catch (error: any) {
    const status = error?.message === "Sign in to continue" ? 401 : 400;
    return json({ error: error?.message || "Unable to complete the video action." }, status);
  }
}
