import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { ensureCompetitiveSchema } from "../../competitive-schema";
import { requireSellerActive } from "../../seller-activation";
import { sellerActivation } from "../../seller-activation";
import { isAdmin } from "../../admin-access";
import { settleAuction, settleExpiredAuctions } from "../../auction-settlement";

const q=(sql:string,...args:any[])=>env.DB!.prepare(sql).bind(...args);
const json=(b:any,s=200)=>Response.json(b,{status:s,headers:{"Cache-Control":"no-store"}});
const now=()=>new Date().toISOString();
const changed=(r:any)=>Number(r?.meta?.changes??r?.changes??0);

export async function GET(req:Request){
 try{
  await ensureCompetitiveSchema(); const stamp=now();
  await settleExpiredAuctions();
  const u=await getChatGPTUser(),stream=new URL(req.url).searchParams.get("stream")||"";
  if(stream){const live=await q("SELECT id FROM streams WHERE id=? AND status IN ('live','external')",stream).first();if(!live)return json({auctions:[]});await q("UPDATE live_auctions SET status='active',updated=? WHERE stream=? AND status='scheduled' AND starts_at<=? AND ends_at>?",stamp,stream,stamp,stamp).run();}
  const owner=u&&!stream?(await q("SELECT id FROM stores WHERE owner=?",u.userId).first<any>())?.id:"";
  if(!stream&&!owner)return json({auctions:[]});
  const rows=await q("SELECT a.*,p.name AS product_name,p.image,p.price AS listed_price,p.stock,s.name AS seller,CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles owner_profile WHERE owner_profile.id=s.owner AND owner_profile.suspended=1) THEN 1 ELSE 0 END AS verified,(SELECT MAX(amount) FROM auction_bids WHERE auction=a.id) AS highest_bid,(SELECT COUNT(*) FROM auction_bids WHERE auction=a.id) AS bid_count FROM live_auctions a JOIN products p ON p.id=a.product JOIN stores s ON s.id=a.store WHERE ((?<>'' AND a.stream=? AND a.status IN ('scheduled','active')) OR (?='' AND a.store=?)) AND s.suspended=0 AND p.active=1 ORDER BY a.starts_at ASC LIMIT 100",stream,stream,stream,owner).all();
  const auctions:any[]=[]; for(const a of rows.results as any[]){const mine=u?await q("SELECT id FROM stores WHERE owner=? AND id=?",u!.userId,a.store).first():null;const bids=(await q("SELECT b.amount,b.created,COALESCE('@'||NULLIF(p.username,''),'Shopper') AS bidder_name FROM auction_bids b LEFT JOIN profiles p ON p.id=b.bidder WHERE b.auction=? ORDER BY b.amount DESC,b.created ASC LIMIT 20",a.id).all()).results;const sellerState=await sellerActivation(a.store);auctions.push({...a,canBid:!mine&&Boolean(u)&&sellerState.canSell,bids});}
  return json({auctions});
 }catch(e:any){return json({error:e.message||"Unable to load auctions"},503);}
}

export async function POST(req:Request){
 if(req.headers.get("origin")!==new URL(req.url).origin)return json({error:"Invalid origin"},403);
 try{
  await ensureCompetitiveSchema();const b:any=await req.json(),action=String(b.action||""),stamp=now();const u=await getChatGPTUser();if(!u&&action!=="settle")return json({error:"Sign in to continue"},401);
  if(action==="create"){
   const store:any=await q("SELECT id FROM stores WHERE owner=? AND suspended=0",u!.userId).first();if(!store)throw Error("Active seller store required");await requireSellerActive(store.id);
   const product=String(b.product||""),stream=String(b.stream||""),startPrice=Number(b.startPrice),increment=Number(b.increment),reserve=b.reservePrice===""||b.reservePrice==null?null:Number(b.reservePrice),start=new Date(b.startsAt),end=new Date(b.endsAt);
   if(!Number.isSafeInteger(startPrice)||startPrice<1||!Number.isSafeInteger(increment)||increment<1||(reserve!==null&&(!Number.isSafeInteger(reserve)||reserve<startPrice))||!Number.isFinite(start.getTime())||!Number.isFinite(end.getTime())||start<new Date()||end<=start||end.getTime()-start.getTime()>24*60*60*1000)throw Error("Enter valid auction prices and a future window of up to 24 hours.");
   const p:any=await q("SELECT id,stock,active,variants FROM products WHERE id=? AND store=?",product,store.id).first();if(!p||!p.active||p.stock<1||JSON.parse(p.variants||"[]").length)throw Error("Choose an available product without variants.");
   const l:any=await q("SELECT id,status FROM streams WHERE id=? AND store=?",stream,store.id).first();if(!l||!["live","scheduled"].includes(l.status))throw Error("Choose your live or scheduled livestream.");
   const id=crypto.randomUUID();await q("INSERT INTO live_auctions(id,store,product,stream,start_price,increment,reserve_price,starts_at,ends_at,status,created,updated) VALUES(?,?,?,?,?,?,?,?,?,'scheduled',?,?)",id,store.id,product,stream,startPrice,increment,reserve,start.toISOString(),end.toISOString(),stamp,stamp).run();return json({ok:true,id});
  }
  if(action==="bid"){
   const auction=String(b.auction||""),amount=Number(b.amount),requestId=String(b.requestId||"");if(!Number.isSafeInteger(amount)||amount<1||!/^[a-f0-9-]{36}$/i.test(requestId))throw Error("Invalid bid request");
   const a:any=await q("SELECT a.*,s.owner,s.suspended AS store_suspended,p.active AS product_active,p.stock,st.status AS stream_status FROM live_auctions a JOIN stores s ON s.id=a.store JOIN products p ON p.id=a.product JOIN streams st ON st.id=a.stream WHERE a.id=?",auction).first();if(!a||!["live","external"].includes(a.stream_status))throw Error("This auction is only available while its livestream is live.");await q("UPDATE live_auctions SET status='active',updated=? WHERE id=? AND status='scheduled' AND starts_at<=? AND ends_at>?",stamp,auction,stamp,stamp).run();const current:any=await q("SELECT status FROM live_auctions WHERE id=?",auction).first();if(!current||current.status!=="active"||a.starts_at>stamp||a.ends_at<=stamp||a.store_suspended||!a.product_active||a.stock<1)throw Error("This auction is not accepting bids.");if(a.owner===u!.userId)throw Error("Sellers cannot bid on their own auctions.");if(!(await q("SELECT id FROM profiles WHERE id=? AND suspended=0",a.owner).first())||!(await q("SELECT id FROM profiles WHERE id=? AND suspended=0",u!.userId).first())||!((await q("SELECT verified FROM stores WHERE id=?",a.store).first<any>())?.verified))throw Error("Seller is not eligible to run this auction.");await requireSellerActive(a.store);
   const prior:any=await q("SELECT id,amount FROM auction_bids WHERE request_id=?",requestId).first();if(prior)return json({ok:true,bid:prior,duplicate:true});
   const minimum:any=await q("SELECT COALESCE(MAX(amount)+?,?) AS value FROM auction_bids WHERE auction=?",a.increment,a.start_price,auction).first();if(amount<Number(minimum.value))throw Error(`Next bid must be at least ₦${Number(minimum.value).toLocaleString("en-NG")}.`);
   const bidId=crypto.randomUUID();const r:any=await q("INSERT INTO auction_bids(id,auction,bidder,amount,request_id,created) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM live_auctions a JOIN streams st ON st.id=a.stream WHERE a.id=? AND a.status='active' AND st.status IN ('live','external') AND a.starts_at<=? AND a.ends_at>? AND ? >= COALESCE((SELECT MAX(b.amount)+a.increment FROM auction_bids b WHERE b.auction=a.id),a.start_price))",bidId,auction,u!.userId,amount,requestId,stamp,auction,stamp,stamp,amount).run();if(changed(r)!==1){const current:any=await q("SELECT COALESCE(MAX(amount)+?,?) AS value FROM auction_bids WHERE auction=?",a.increment,a.start_price,auction).first();throw Error(`Bid changed during submission. Next bid is ₦${Number(current.value).toLocaleString("en-NG")}.`);}
   const seller:any=await q("SELECT owner FROM stores WHERE id=?",a.store).first();await q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)",`auction-bid:${bidId}`,seller.owner,"New auction bid",`A buyer placed a bid of ₦${amount.toLocaleString("en-NG")}.`,stamp).run();return json({ok:true,bid:{id:bidId,amount,created:stamp}});
  }
  if(action==="end"){
   const store:any=await q("SELECT id FROM stores WHERE owner=?",u!.userId).first();if(!store)throw Error("Seller store not found.");const a:any=await q("SELECT id,status FROM live_auctions WHERE id=? AND store=?",String(b.auction||""),store.id).first();if(!a||!["active","scheduled"].includes(a.status))throw Error("Auction is not open for ending.");await q("UPDATE live_auctions SET ends_at=?,updated=? WHERE id=? AND store=? AND status IN ('active','scheduled')",stamp,stamp,a.id,store.id).run();const result=await settleAuction(a.id,stamp);return json({ok:true,orderId:result.orderId||null});
  }
  if(action==="settle"){
   const result=await settleAuction(String(b.auction||""),stamp);if(result.reason==="not_found")throw Error("Auction not found");if(result.reason==="not_due")throw Error("Auction has not ended.");return json({ok:true,orderId:result.orderId||null,reserveMet:Boolean(result.orderId)});
  }
  if(action==="moderate"){if(!(await isAdmin(u,"streams")))return json({error:"Administrator access required"},403);const r:any=await q("UPDATE live_auctions SET status='suspended',updated=? WHERE id=? AND status IN ('scheduled','active')",stamp,String(b.auction||"")).run();if(!changed(r))throw Error("Auction not found or already closed");return json({ok:true});}
  throw Error("Unknown auction action");
 }catch(e:any){return json({error:e.message||"Unable to process auction"},400);}
}
