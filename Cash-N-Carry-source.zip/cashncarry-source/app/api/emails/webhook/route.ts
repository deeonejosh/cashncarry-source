import { emailWebhookSecret } from "../../../email-webhook-config";
import { env } from "cloudflare:workers";
import { verifyEmailWebhook } from "../../../email-webhook";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  let secret: string | null;
  try {
    secret = await emailWebhookSecret();
  } catch {
    return Response.json(
      { error: "Email webhook configuration unavailable" },
      { status: 503 },
    );
  }
  if (!secret)
    return Response.json(
      { error: "Email webhook not configured" },
      { status: 503 },
    );
  if (Number(req.headers.get("Content-Length") || 0) > 65536)
    return new Response(null, { status: 413 });
  let verified;
  try {
    const raw = await req.text();
    if (raw.length > 65536) return new Response(null, { status: 413 });
    verified = await verifyEmailWebhook(raw, req.headers, secret);
  } catch {
    return Response.json({ error: "Invalid webhook" }, { status: 401 });
  }
  const { id, event } = verified;
  const statuses: Record<string, string> = {
    "email.sent": "accepted",
    "email.delivered": "delivered",
    "email.delivery_delayed": "delayed",
    "email.bounced": "bounced",
    "email.complained": "complained",
    "email.failed": "failed",
    "email.suppressed": "suppressed",
  };
  const status = statuses[event.type],
    providerId = event.data?.email_id;
  if (!status || typeof providerId !== "string")
    return Response.json({ ok: true, ignored: true });
  try {
    const stamp = new Date().toISOString();
    const rows = (
      await env
        .DB!.prepare("SELECT recipient FROM email_outbox WHERE provider_id=?")
        .bind(providerId)
        .all<{ recipient: string }>()
    ).results;
    const statements = [
      env
        .DB!.prepare(
          "INSERT INTO email_webhook_events(id,provider_id,type,created) VALUES(?,?,?,?) ON CONFLICT(id) DO NOTHING",
        )
        .bind(id, providerId, event.type, stamp),
      env
        .DB!.prepare(
          "UPDATE email_outbox SET delivery_status=?,updated=? WHERE provider_id=? AND (delivery_status NOT IN ('bounced','complained','suppressed') OR ? IN ('bounced','complained','suppressed')) AND (delivery_status!='delivered' OR ? IN ('bounced','complained','suppressed')) AND (delivery_status!='complained' OR ?='complained')",
        )
        .bind(status, stamp, providerId, status, status, status),
    ];
    if (["bounced", "complained", "suppressed"].includes(status)) {
      // The signed event can also refer to a direct authentication email.
      const recipients = [
        ...rows.map((r) => r.recipient),
        ...(Array.isArray(event.data?.to) ? event.data.to : []),
      ];
      for (const recipient of new Set(
        recipients
          .filter((v: unknown) => typeof v === "string" && v.length <= 254)
          .map((v: string) => v.toLowerCase()),
      ))
        statements.push(
          env
            .DB!.prepare(
              "INSERT INTO email_suppressions(recipient,reason,created) VALUES(?,?,?) ON CONFLICT(recipient) DO NOTHING",
            )
            .bind(recipient, status, stamp),
        );
    }
    await env.DB!.batch(statements);
    return Response.json({ ok: true });
  } catch {
    console.error("email_webhook_storage_failed");
    return Response.json(
      { error: "Email event storage unavailable" },
      { status: 503 },
    );
  }
}
