import {bankDetails} from '../../bank-details';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {limit} from '../../security';
import {flutterwave,paymentMode} from '../../payments';
import {sellerActivation} from '../../seller-activation';
import {sellerFinanceSettings,earningsSummary,checkoutSellerSubscription,verifySellerSubscription,cancelSellerAutoRenewal,reactivateSellerAutoRenewal,requestWithdrawal,SELLER_TERMS_VERSION} from '../../seller-finance';
const q=(s:string,...a:any[])=>env.DB!.prepare(s).bind(...a);
const json=(d:any,status=200)=>Response.json(d,{status,headers:{'Cache-Control':'private, no-store'}});
async function context(){const u=await getChatGPTUser();if(!u)throw Error('Sign in required');const p:any=await q('SELECT suspended FROM profiles WHERE id=?',u.userId).first();const store:any=await q('SELECT * FROM stores WHERE owner=?',u.userId).first();if(!store)throw Error('Create your storefront first');return {u,store,suspended:Boolean(p?.suspended||store.suspended)};}
export async function GET(req:Request){try{
 const {u,store}=await context(),mode=paymentMode();
 if(new URL(req.url).searchParams.get('banks')==='1') {
  if(mode!=='test')throw Error('Live bank onboarding is not enabled.');
  const r:any=await flutterwave('banks/NG',undefined,'test');if(!Array.isArray(r))throw Error('The provider returned an invalid bank list. Retry loading.');const banks=r.filter((b:any)=>b&&typeof b.name==='string'&&/^\d{2,9}$/.test(String(b.code))).map((b:any)=>({id:b.id,name:b.name,code:String(b.code)})).sort((a:any,b:any)=>a.name.localeCompare(b.name));if(!banks.length)throw Error('The provider returned no Nigerian banks. Retry loading.');return json({banks});
 }
 const [activation,settings,earnings,payments,banks,withdrawals,releases,adjustments,verification]=await Promise.all([
  sellerActivation(store.id),sellerFinanceSettings(),earningsSummary(store.id),
  q('SELECT id,amount_minor,status,mode,period_start,period_end,created,provider_id,provider_plan,recurring,terms_version FROM seller_subscription_payments WHERE store=? ORDER BY created DESC,rowid DESC LIMIT 100',store.id).all(),
  q('SELECT id,bank_name,account_name,substr(account_number,-4) AS last4,status,mode,note FROM seller_banks WHERE store=? ORDER BY created DESC',store.id).all(),
  q('SELECT id,amount_minor,fee_minor,status,reference,provider_id,note,created,mode FROM seller_withdrawals WHERE store=? ORDER BY created DESC,rowid DESC LIMIT 100',store.id).all(),
  q('SELECT id,payment,mode,amount_minor,settlement_reference,created FROM seller_earnings_releases WHERE store=? ORDER BY created DESC,rowid DESC LIMIT 100',store.id).all(),
  q('SELECT id,mode,amount_minor,reference,reason,created FROM seller_adjustments WHERE store=? ORDER BY created DESC,rowid DESC LIMIT 100',store.id).all(),
  q('SELECT id,status,note,seller_type,legal_name,registration,appeal,created FROM verification_requests WHERE owner=? ORDER BY created DESC,rowid DESC LIMIT 1',u.userId).first(),
 ]);
 return json({store:{id:store.id,name:store.name},activation,settings,earnings:settings.fundFlow==='direct_settlement'?{...earnings,availableMinor:0}:earnings,payments:payments.results,banks:banks.results,withdrawals:withdrawals.results,releases:releases.results,adjustments:adjustments.results,verification,termsVersion:SELLER_TERMS_VERSION});
}catch(e:any){return json({error:e.message},e.message==='Sign in required'?401:400);}}
export async function POST(req:Request){if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Invalid origin'},403);
 try{const {u,store,suspended}=await context(),b:any=await req.json();await limit('seller-finance:'+u.userId,20);
 if(suspended&&!['appeal','withdrawal-cancel'].includes(b.action))throw Error('Your selling access is suspended. Contact support to appeal.');
 const mode=paymentMode();
 if(b.action==='subscription-checkout')return json(await checkoutSellerSubscription(store,u,b));
 if(b.action==='subscription-verify'){
  if(!await q('SELECT id FROM seller_subscription_payments WHERE id=? AND owner=?',b.reference,u.userId).first())throw Error('Subscription payment not found');
  return json(await verifySellerSubscription(String(b.transaction),String(b.reference)));
 }
 if(b.action==='subscription-cancel'){
  const result=await cancelSellerAutoRenewal(store.id,mode);
  return json({...result,message:'Flutterwave confirmed renewal cancellation. Your paid selling access continues until the paid-through date.'});
 }
 if(b.action==='subscription-reactivate')return json(await reactivateSellerAutoRenewal(store.id,mode,b.autoRenewConsent===true,b.termsVersion));
 if(b.action==='bank-save'){
  if(mode!=='test')throw Error('Live bank onboarding is disabled pending payout approval.');
  const {accountNumber,bankCode,accountName}=bankDetails(b);
  if(await q("SELECT id FROM seller_withdrawals WHERE store=? AND status IN ('requested','under_review','processing')",store.id).first())throw Error('Wait for pending withdrawals before changing bank details.');
  const banks:any=await flutterwave('banks/NG',undefined,'test');const bank=Array.isArray(banks)?banks.find((x:any)=>String(x.code)===bankCode):null;if(!bank)throw Error('Bank list could not confirm your selection. Reload the banks and retry.');
  const existing:any=await q('SELECT id,status FROM seller_banks WHERE store=? AND mode=? AND bank_code=? AND account_number=?',store.id,mode,bankCode,accountNumber).first();
  if(existing)return json({ok:true,id:existing.id,status:existing.status,message:'These bank details are already saved. Check their verification status below.'});
  const id=crypto.randomUUID(),now=new Date().toISOString();try{await q('INSERT INTO seller_banks(id,store,mode,bank_code,bank_name,account_number,account_name,status,note,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)',id,store.id,mode,bankCode,bank.name,accountNumber,accountName,'pending_resolution','Account holder name supplied by seller. Provider verification has not completed.',now,now).run();}catch(e){const saved:any=await q('SELECT id,status FROM seller_banks WHERE store=? AND mode=? AND bank_code=? AND account_number=?',store.id,mode,bankCode,accountNumber).first();if(saved)return json({ok:true,id:saved.id,status:saved.status,message:'These bank details are already saved. Check their status below.'});throw e;}
  return json({ok:true,id,status:'pending_resolution',message:'Bank details saved — not verified. Sandbox cannot verify real accounts. This account is unavailable for payouts until provider verification and ownership review are complete.'});
 }
 if(b.action==='bank-resolve'){
  if(mode!=='test')throw Error('Live bank onboarding is disabled pending payout approval.');
  if(b.id){const saved:any=await q('SELECT * FROM seller_banks WHERE id=? AND store=? AND mode=?',b.id,store.id,mode).first();if(!saved)throw Error('Bank account not found');if(saved.status!=='pending_resolution')return json({ok:true,message:'This account has already been resolved or reviewed.'});b.accountNumber=saved.account_number;b.bankCode=saved.bank_code;}
  b.accountNumber=String(b.accountNumber||'').replace(/\s/g,'');b.bankCode=String(b.bankCode||'').trim();
  if(!/^\d{10}$/.test(b.accountNumber||'')||!/^\d{2,9}$/.test(b.bankCode||''))throw Error('Choose a Nigerian bank and enter its 10-digit account number.');
  if((await q("SELECT id FROM seller_withdrawals WHERE store=? AND status IN ('requested','under_review','processing')",store.id).first()))throw Error('Wait for pending withdrawals before changing bank details.');
  const banks:any=await flutterwave('banks/NG',undefined,'test'),bank=banks?.find((x:any)=>String(x.code)===b.bankCode);
  if(!bank)throw Error('Bank not found');
  let r:any;try{r=await flutterwave('accounts/resolve',{account_number:b.accountNumber,account_bank:b.bankCode},'test');}catch{throw Error('Sandbox verification could not complete. Real bank accounts cannot be verified in sandbox. Saved details remain unverified; use a Flutterwave test account only for sandbox testing.');}
  if(String(r?.account_number||'')!==b.accountNumber||typeof r?.account_name!=='string'||!r.account_name.trim())throw Error('Provider account details did not match. Saved details remain unverified. Sandbox supports test accounts only.');
  if(b.id){await q("UPDATE seller_banks SET account_name=?,status='resolved',note='',updated=? WHERE id=? AND store=? AND mode=? AND status='pending_resolution'",r.account_name.trim(),new Date().toISOString(),b.id,store.id,mode).run();return json({ok:true,accountName:r.account_name,message:'Sandbox account resolved. A human reviewer must match ownership. This is not real-account verification.'});}
  const saved:any=await q('SELECT id,status FROM seller_banks WHERE store=? AND mode=? AND bank_code=? AND account_number=?',store.id,mode,b.bankCode,b.accountNumber).first();
  if(saved){if(saved.status==='pending_resolution')await q("UPDATE seller_banks SET status='resolved',account_name=?,note='',updated=? WHERE id=? AND status='pending_resolution'",r.account_name,new Date().toISOString(),saved.id).run();return json({ok:true,id:saved.id,message:'Bank account already saved. Check its ownership review status.'});}
  const id=crypto.randomUUID(),now=new Date().toISOString();
  try{await q('INSERT INTO seller_banks(id,store,mode,bank_code,bank_name,account_number,account_name,created,updated) VALUES(?,?,?,?,?,?,?,?,?)',id,store.id,mode,b.bankCode,bank.name,b.accountNumber,r.account_name,now,now).run();}catch(e){const existing:any=await q('SELECT id FROM seller_banks WHERE store=? AND mode=? AND bank_code=? AND account_number=?',store.id,mode,b.bankCode,b.accountNumber).first();if(existing)return json({ok:true,id:existing.id,message:'Bank account already saved.'});throw e;}
  return json({ok:true,accountName:r.account_name,message:'Account resolved. A human reviewer must match it to your verification evidence.'});
 }
 if(b.action==='withdrawal-request')return json(await requestWithdrawal(store,b));
 if(b.action==='withdrawal-cancel'){
  const result:any=await q("UPDATE seller_withdrawals SET status='cancelled',updated=? WHERE id=? AND store=? AND status='requested'",new Date().toISOString(),b.id,store.id).run();
  if(Number(result.meta?.changes??result.changes)!==1)throw Error('Only requested withdrawals can be cancelled.');return json({ok:true});
 }
 if(b.action==='appeal'){
  const note=String(b.note||'').trim();if(note.length<10||note.length>1500)throw Error('Provide an appeal between 10 and 1,500 characters');
  const latest:any=await q('SELECT id FROM verification_requests WHERE store=? ORDER BY created DESC,rowid DESC LIMIT 1',store.id).first();if(!latest)throw Error('Submit verification before appealing.');
  await q('UPDATE verification_requests SET appeal=?,updated=? WHERE id=?',note,new Date().toISOString(),latest.id).run();return json({ok:true});
 }
 throw Error('Unknown finance action');
 }catch(e:any){return json({error:e.message?.includes('D1_')?'Unable to complete the request. Check your balance and retry.':e.message},e.message==='Sign in required'?401:400);}}
