import { recordMfaSession, mfaResponseHeaders, type MfaSession } from "../../../mfa-proof";
import { MIN_PASSWORD_LENGTH, safeReturnPath } from "../../../auth-navigation";
import { limit } from "../../../security";
import { getAuth, authAvailable } from "../../../auth";
import { env } from "cloudflare:workers";
export const dynamic = "force-dynamic";
async function handleRequest(req: Request) {
  let acceptedTermsVersion: number | null = null;
  if (
    req.method === "POST" &&
    new URL(req.url).pathname.endsWith("/sign-up/email")
  ) {
    let body: any;
    try {
      body = await req.json();
    } catch {
      return Response.json(
        { message: "Invalid registration request." },
        { status: 400 },
      );
    }
    if (!body || typeof body !== "object" || Array.isArray(body))
      return Response.json({ message: "Invalid registration request." }, { status: 400 });
    if (body.termsAccepted !== true)
      return Response.json(
        { message: "Accept the Terms to create an account." },
        { status: 400 },
      );
    if (!Number.isSafeInteger(body.termsVersion) || body.termsVersion < 1)
      return Response.json({ message: "Reload the current Terms before creating an account." }, { status: 409 });
    const currentTerms = await env.DB?.prepare(
      "SELECT version FROM policy_versions WHERE policy_id='terms' AND status='published' ORDER BY version DESC LIMIT 1",
    ).first<{version:number}>();
    if (!currentTerms || Number(currentTerms.version) !== body.termsVersion)
      return Response.json({ message: "The Terms have changed or are not published. Reload before creating an account." }, { status: 409 });
    acceptedTermsVersion = Number(currentTerms.version);
    if (
      typeof body.name !== "string" ||
      !body.name.trim() ||
      body.name.length > 100 ||
      typeof body.email !== "string" ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email) ||
      typeof body.password !== "string" ||
      body.password.length < MIN_PASSWORD_LENGTH
    )
      return Response.json(
        {
          message:
            "Check your name, email and password (at least 12 characters).",
        },
        { status: 400 },
      );
    req = replaceJsonBody(req, {
      name: body.name.trim(),
      email: body.email.trim(),
      password: body.password,
      callbackURL: verificationCallback(body.callbackURL),
    });
  }
  if (
    req.method === "POST" &&
    new URL(req.url).pathname.endsWith("/send-verification-email")
  ) {
    let body: any;
    try {
      body = await req.json();
    } catch {
      return Response.json(
        { message: "Invalid verification request." },
        { status: 400 },
      );
    }
    if (
      !body || typeof body !== "object" || Array.isArray(body) ||
      typeof body.email !== "string" ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email.trim())
    )
      return Response.json(
        { message: "Enter a valid email address." },
        { status: 400 },
      );
    req = replaceJsonBody(req, {
      email: body.email.trim(),
      callbackURL: verificationCallback(body.callbackURL),
    });
  }
  const available = await authAvailable();
  // ChatGPT-only installations have no usable email session to terminate.
  if (
    !available &&
    req.method === "POST" &&
    new URL(req.url).pathname.endsWith("/sign-out")
  )
    return Response.json(
      { success: true },
      { headers: { "Cache-Control": "no-store" } },
    );
  if (!available)
    return Response.json(
      {
        message: "Email accounts are not configured yet. Use ChatGPT sign-in.",
      },
      { status: 503 },
    );
  try {
    if (req.method === "POST") {
      const bytes = await crypto.subtle.digest(
        "SHA-256",
        new TextEncoder().encode(
          req.headers.get("cf-connecting-ip") || "unknown",
        ),
      );
      const key = Array.from(new Uint8Array(bytes), (n) =>
        n.toString(16).padStart(2, "0"),
      ).join("");
      await limit("auth:" + key, 20);
    }
    const auth = await getAuth();
    const response = await auth.handler(req);
    if (req.method === "POST" && new URL(req.url).pathname.endsWith("/sign-up/email") && response.ok) {
      const result = await response.clone().json().catch(() => null) as {user?:{id?:string}} | null;
      if (!result?.user?.id || !acceptedTermsVersion) return Response.json({ message: "Account registration could not be confirmed." }, { status: 503, headers: { "Cache-Control": "no-store" } });
      await env.DB!.prepare("INSERT OR IGNORE INTO policy_acceptances(id,user_id,policy_id,version,accepted_at) VALUES(?,?,'terms',?,?)")
        .bind(crypto.randomUUID(), result.user.id, acceptedTermsVersion, new Date().toISOString()).run();
    }
    if (req.method === "POST" && response.ok && /\/two-factor\/verify-(totp|backup-code)$/.test(new URL(req.url).pathname)) {
      const session = await auth.api.getSession({headers:mfaResponseHeaders(req,response)});
      if (!session) throw Error("MFA session was not confirmed");
      await recordMfaSession(session as MfaSession);
    }
    return response;
  } catch (error) {
    const throttled =
      error instanceof Error && error.message.startsWith("Too many requests");
    return Response.json(
      {
        message: throttled
          ? "Too many requests. Try again in a minute."
          : "Authentication is temporarily unavailable. Please retry.",
      },
      {
        status: throttled ? 429 : 503,
        headers: {
          "Cache-Control": "no-store",
          ...(throttled ? { "Retry-After": "60" } : {}),
        },
      },
    );
  }
}
// A consumed request cannot be used as the Request constructor input in Workers.
function replaceJsonBody(req: Request, body: Record<string, unknown>): Request {
  const headers = new Headers(req.headers);
  headers.delete("Content-Length");
  headers.set("Content-Type", "application/json");
  return new Request(req.url, {
    method: req.method,
    headers,
    body: JSON.stringify(body),
  });
}
async function handler(req: Request) {
  try {
    return await handleRequest(req);
  } catch {
    return Response.json(
      { message: "Authentication is temporarily unavailable. Please retry." },
      { status: 503, headers: { "Cache-Control": "no-store" } },
    );
  }
}
export const GET = handler;
export const POST = handler;

function verificationCallback(value: unknown): string {
  if (
    typeof value !== "string" ||
    !value.startsWith("/") ||
    value.startsWith("//") ||
    /[\\\x00-\x1f\x7f]/.test(value)
  )
    return "/sign-in?verified=1";
  const u = new URL(value, "https://internal.invalid");
  if (u.origin !== "https://internal.invalid" || u.pathname !== "/sign-in")
    return "/sign-in?verified=1";
  return (
    "/sign-in?verified=1&returnTo=" +
    encodeURIComponent(safeReturnPath(u.searchParams.get("returnTo")))
  );
}
