import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { ensureCompetitiveSchema } from "../../competitive-schema";
export async function POST(req: Request) {
  const headers: Record<string, string> = { "Cache-Control": "no-store" };
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403, headers });
  try {
    await ensureCompetitiveSchema();
    const body = (await req.json()) as any;
    if (typeof body.id !== "string" || body.id.length > 100) throw Error();
    const stream = await env
      .DB!.prepare(
        "SELECT l.id FROM streams l JOIN stores s ON s.id=l.store WHERE l.id=? AND l.status='live' AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.id=s.owner AND p.suspended=1)",
      )
      .bind(body.id)
      .first();
    if (!stream) return Response.json({ viewers: 0 }, { headers });
    const supplied = req.headers
      .get("cookie")
      ?.match(/(?:^|;\s*)cnc_viewer=([a-f0-9-]{36})(?:;|$)/)?.[1];
    const session = supplied || crypto.randomUUID();
    if (!supplied)
      headers["Set-Cookie"] =
        `cnc_viewer=${session}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=86400`;
    await env
      .DB!.prepare("DELETE FROM live_viewers WHERE seen<?")
      .bind(new Date(Date.now() - 120000).toISOString())
      .run();
    if (body.leave)
      await env
        .DB!.prepare("DELETE FROM live_viewers WHERE stream=? AND session=?")
        .bind(body.id, session)
        .run();
    else
      await env
        .DB!.prepare(
          "INSERT INTO live_viewers(stream,session,seen) VALUES(?,?,?) ON CONFLICT(stream,session) DO UPDATE SET seen=excluded.seen",
        )
        .bind(body.id, session, new Date().toISOString())
        .run();
    const count: any = await env
      .DB!.prepare(
        "SELECT COUNT(*) AS count FROM live_viewers WHERE stream=? AND seen>?",
      )
      .bind(body.id, new Date(Date.now() - 45000).toISOString())
      .first();
    const sampledAt=new Date().toISOString();
    await env.DB!.prepare("INSERT INTO livestream_peak_metrics(stream,day,peak_viewers,sampled_at) VALUES(?,?,?,?) ON CONFLICT(stream,day) DO UPDATE SET peak_viewers=MAX(livestream_peak_metrics.peak_viewers,excluded.peak_viewers),sampled_at=excluded.sampled_at").bind(body.id,sampledAt.slice(0,10),Number(count.count||0),sampledAt).run();
    const user=await getChatGPTUser();
    const profile=user?await env.DB!.prepare("SELECT username FROM profiles WHERE id=?").bind(user.userId).first<{username:string}>():null;
    return Response.json({ viewers: count.count, username:profile?.username?"@"+profile.username:"Guest" }, { headers });
  } catch {
    return Response.json(
      { error: "Viewer presence unavailable" },
      { status: 400, headers },
    );
  }
}
