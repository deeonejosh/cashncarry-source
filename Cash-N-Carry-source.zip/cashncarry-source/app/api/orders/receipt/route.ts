import { brand } from "../../../brand";
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
export async function GET(req: Request) {
  const u = await getChatGPTUser();
  if (!u) return Response.json({ error: "Sign in" }, { status: 401 });
  const id = new URL(req.url).searchParams.get("id");
  const o: any = await env
    .DB!.prepare("SELECT o.*,(SELECT mode FROM payments WHERE order_id=o.id) AS payment_mode FROM orders o WHERE id=? AND buyer=?")
    .bind(id, u.userId)
    .first();
  if (!o) return Response.json({ error: "Order not found" }, { status: 404 });
  const items = (
    await env
      .DB!.prepare(
        "SELECT name,variant,price,quantity FROM order_items WHERE order_id=?",
      )
      .bind(id)
      .all<any>()
  ).results;
  const text = [
    brand.name + " — Order record",
    o.payment === "flutterwave" ? (o.payment_mode === "live" ? "LIVE PAYMENT" : "SANDBOX TEST PAYMENT") : "CASH ON DELIVERY",
    `Order: ${o.id}`,
    `Created: ${o.created}`,
    `Payment: ${o.payment_status}`,
    `Fulfilment: ${o.status}`,
    ...items.map(
      (i) =>
        `${i.name}${i.variant ? " (" + i.variant + ")" : ""}: ${i.quantity} × NGN ${i.price}`,
    ),
    `Delivery: NGN ${o.delivery_fee}`,
    `Total: NGN ${o.total}`,
    o.payment_status === "paid"
      ? (o.payment_mode === "live" ? "Provider-verified live payment." : "Provider-verified sandbox payment. Not a real-money receipt.")
      : "This order record does not confirm collection of cash.",
  ].join("\n");
  return new Response(text, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Content-Disposition": `attachment; filename="${brand.filePrefix}-order.txt"`,
      "Cache-Control": "no-store",
    },
  });
}
