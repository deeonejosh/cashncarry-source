import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { limit } from "../../security";
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403 });
  try {
    const b: any = await req.json();
    if (!["click", "impression"].includes(b.kind)) throw Error("Invalid event");
    const u = await getChatGPTUser();
    const bytes = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(
        (u?.userId || req.headers.get("cf-connecting-ip") || "anonymous") +
          new Date().toISOString().slice(0, 10),
      ),
    );
    const visitor = Array.from(new Uint8Array(bytes), (x) =>
      x.toString(16).padStart(2, "0"),
    ).join("");
    await limit("ads:" + visitor, 100);
    const c = await env
      .DB!.prepare(
        "SELECT id FROM campaigns WHERE id=? AND status='active' AND payment_status='paid' AND starts<=? AND ends>?",
      )
      .bind(b.campaign, new Date().toISOString(), new Date().toISOString())
      .first();
    if (!c) throw Error("Campaign inactive");
    const field = b.kind === "click" ? "clicks" : "impressions",
      id = crypto.randomUUID();
    await env.DB!.batch([
      env
        .DB!.prepare(
          "INSERT INTO campaign_events(id,campaign,visitor,kind,day,created) VALUES(?,?,?,?,?,?) ON CONFLICT(campaign,visitor,kind,day) DO NOTHING",
        )
        .bind(
          id,
          b.campaign,
          visitor,
          b.kind,
          new Date().toISOString().slice(0, 10),
          new Date().toISOString(),
        ),
      env
        .DB!.prepare(
          `UPDATE campaigns SET ${field}=${field}+1 WHERE id=? AND EXISTS(SELECT 1 FROM campaign_events WHERE id=?)`,
        )
        .bind(b.campaign, id),
    ]);
    return Response.json({ ok: true });
  } catch (e: any) {
    return Response.json({ error: e.message }, { status: 400 });
  }
}
