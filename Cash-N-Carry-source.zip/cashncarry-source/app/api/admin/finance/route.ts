import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
import { POST as settingsPost } from "../settings/route";
export async function GET() {
  if (!(await isAdmin(await getChatGPTUser(), "payments")))
    return Response.json(
      { error: "Finance access and MFA required" },
      { status: 403 },
    );
  const [payments, refunds] = await Promise.all([
    env
      .DB!.prepare(
        "SELECT id,order_id,amount,currency,mode,status,provider_id,created,updated FROM payments ORDER BY created DESC LIMIT 300",
      )
      .all(),
    env
      .DB!.prepare(
        "SELECT id,order_id,payment,amount,status,reason,provider_id,created,updated FROM refunds ORDER BY created DESC LIMIT 300",
      )
      .all(),
  ]);
  return Response.json(
    { payments: payments.results, refunds: refunds.results },
    { headers: { "Cache-Control": "no-store" } },
  );
}
export async function POST(req: Request) {
  const body: any = await req
    .clone()
    .json()
    .catch(() => null);
  if (
    !body ||
    ![
      "refund-review",
      "refund-process",
      "refund-reconcile",
      "reconcile-payments",
    ].includes(body.action)
  )
    return Response.json({ error: "Invalid finance action" }, { status: 400 });
  if (body.action === "refund-process" && body.confirm !== true)
    return Response.json(
      { error: "Confirm provider refund execution" },
      { status: 400 },
    );
  return settingsPost(req);
}
