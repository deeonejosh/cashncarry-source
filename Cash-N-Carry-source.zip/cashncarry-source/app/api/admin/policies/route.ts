import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin, isOwnerIdentity } from "../../../admin-access";
import { policyDefinitions, policyBlockers, type PolicyId } from "../../../policy-drafts";

export const dynamic = "force-dynamic";
const db = () => env.DB!;
const ids = Object.keys(policyDefinitions) as PolicyId[];
type PolicyVersionRecord = {
  id: string; policy_id: string; version: number; title: string; content: string; status: string;
  created_by: string; created_by_email: string; created_at: string; submitted_at: string | null;
  approved_by: string | null; approved_by_email: string | null; approved_at: string | null;
  published_by: string | null; published_by_email: string | null; published_at: string | null;
  effective_date: string | null; reason: string;
};
type PolicyActionBody = {
  action?: unknown; policyId?: unknown; reason?: unknown; confirm?: unknown; versionId?: unknown;
  content?: unknown; effectiveDate?: unknown; checklist?: Record<string, unknown>;
};

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

async function seedInitialDrafts(user: { userId: string; email: string }) {
  const stamp = new Date().toISOString();
  for (const policyId of ids) {
    const definition = policyDefinitions[policyId];
    await db().prepare(`INSERT OR IGNORE INTO policy_versions
      (id,policy_id,version,title,content,status,created_by,created_by_email,created_at,reason)
      VALUES(?,?,1,?,?,'draft',?,?,?,'Initial source-document draft; awaiting legal, operational and owner review')`)
      .bind(crypto.randomUUID(), policyId, definition.title, definition.content, user.userId, user.email, stamp).run();
  }
}

export async function GET() {
  const user = await getChatGPTUser();
  if (!user || !(await isAdmin(user, "settings"))) return json({ error: "Admin permission and completed MFA required" }, 403);
  await seedInitialDrafts(user);
  const [history, audit] = await Promise.all([
    db().prepare("SELECT * FROM policy_versions ORDER BY policy_id,version DESC").all<PolicyVersionRecord>(),
    db().prepare("SELECT id,actor,email,action,target,reason,before_json,after_json,created FROM admin_audit WHERE action LIKE 'policy-%' ORDER BY created DESC LIMIT 200").all(),
  ]);
  const records = history.results || [];
  const policies = ids.map((policyId) => ({
    id: policyId,
    ...policyDefinitions[policyId],
    versions: records.filter((row) => row.policy_id === policyId),
  }));
  return json({ policies, audit: audit.results || [], canEdit: true, isOwner: isOwnerIdentity(user) });
}

export async function POST(request: Request) {
  if (request.headers.get("origin") !== new URL(request.url).origin) return json({ error: "Invalid origin" }, 403);
  const user = await getChatGPTUser();
  if (!user || !(await isAdmin(user, "settings"))) return json({ error: "Admin permission and completed MFA required" }, 403);
  let body: PolicyActionBody;
  try { body = await request.json() as PolicyActionBody; } catch { return json({ error: "Invalid request" }, 400); }
  const action = String(body.action || "");
  const policyId = String(body.policyId || "") as PolicyId;
  if (!ids.includes(policyId)) return json({ error: "Unknown policy" }, 400);
  const definition = policyDefinitions[policyId];
  const reason = String(body.reason || "").trim().slice(0, 1000);
  if (reason.length < 5) return json({ error: "Enter a reason of at least 5 characters" }, 400);
  const stamp = new Date().toISOString();
  const audit = async (target: string, before: unknown, after: unknown) => db().prepare(
    "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
  ).bind(crypto.randomUUID(), user.userId, user.email, `policy-${action}`, target, reason, JSON.stringify(before), JSON.stringify(after), stamp).run();

  try {
    if (action === "submit-review") {
      if (body.confirm !== true) return json({ error: "Confirm submission of this exact version for review" }, 400);
      const versionId = String(body.versionId || "");
      const version = await db().prepare("SELECT * FROM policy_versions WHERE id=? AND policy_id=?").bind(versionId, policyId).first<PolicyVersionRecord>();
      const latest = await db().prepare("SELECT MAX(version) AS version FROM policy_versions WHERE policy_id=?").bind(policyId).first<{version:number}>();
      if (!version || version.status !== "draft" || version.version !== Number(latest?.version)) return json({ error: "Only the current draft version can be submitted for review" }, 409);
      const blockers = policyBlockers(String(version.content));
      if (blockers.length) return json({ error: "Resolve this version’s approval blockers before submitting it for review", blockers }, 409);
      await db().prepare("UPDATE policy_versions SET status='pending_review',submitted_at=? WHERE id=? AND status='draft'").bind(stamp, versionId).run();
      await audit(`${policyId}:v${version.version}`, { status: "draft" }, { status: "pending_review", submittedAt: stamp });
      return json({ ok: true, version: version.version, status: "pending_review" });
    }

    if (action === "save-draft") {
      const content = String(body.content || "");
      if (content.trim().length < 100 || content.length > 30000) return json({ error: "Policy text must be between 100 and 30,000 characters" }, 400);
      const row = await db().prepare("SELECT COALESCE(MAX(version),0) AS version FROM policy_versions WHERE policy_id=?").bind(policyId).first<{version:number}>();
      const version = Number(row?.version || 0) + 1;
      const id = crypto.randomUUID();
      const status = "draft";
      await db().prepare(`INSERT INTO policy_versions
        (id,policy_id,version,title,content,status,created_by,created_by_email,created_at,reason)
        VALUES(?,?,?,?,?,?,?,?,?,?)`)
        .bind(id, policyId, version, definition.title, content, status, user.userId, user.email, stamp, reason).run();
      await audit(`${policyId}:v${version}`, null, { version, status, title: definition.title });
      return json({ ok: true, id, version, status });
    }

    if (!["approve", "publish"].includes(action)) return json({ error: "Unsupported policy action" }, 400);
    if (!isOwnerIdentity(user) || body.confirm !== true) return json({ error: "Owner identity, completed MFA and explicit confirmation required" }, 403);
    const versionId = String(body.versionId || "");
    const version = await db().prepare("SELECT * FROM policy_versions WHERE id=? AND policy_id=?").bind(versionId, policyId).first<PolicyVersionRecord>();
    if (!version) return json({ error: "Policy version not found" }, 404);
    const latest = await db().prepare("SELECT MAX(version) AS version FROM policy_versions WHERE policy_id=?").bind(policyId).first<{version:number}>();
    if (version.version !== Number(latest?.version)) return json({ error: "Only the current version can be approved or published" }, 409);
    const blockers = policyBlockers(String(version.content));
    if (blockers.length) return json({ error: "This version still has unresolved approval blockers", blockers }, 409);

    if (action === "approve") {
      if (version.status !== "pending_review") return json({ error: "Only a version pending review can be approved" }, 409);
      const approved = await env.DB!.batch([
        db().prepare("UPDATE policy_versions SET status='approved',approved_by=?,approved_by_email=?,approved_at=? WHERE id=? AND status='pending_review'")
          .bind(user.userId, user.email, stamp, versionId),
        db().prepare("INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) SELECT ?,?,?,?,?,?,?,?,? WHERE changes()=1")
          .bind(crypto.randomUUID(), user.userId, user.email, "policy-approve", `${policyId}:v${version.version}`, reason, JSON.stringify({status: version.status}), JSON.stringify({status: "approved", approvedBy: user.email, approvedAt: stamp}), stamp),
      ]);
      if (Number(approved[0]?.meta?.changes ?? (approved[0] as { changes?: number })?.changes) !== 1) return json({ error: "This version changed while approval was being recorded. Refresh and review again." }, 409);
      const legacyId = policyId === "seller-terms" ? "sellers" : policyId === "community-guidelines" ? "community" : policyId === "refunds" ? "returns" : policyId;
      await db().prepare("UPDATE policies SET title=?,content=?,reviewed=1,updated=? WHERE id=?")
        .bind(version.title, version.content, stamp, legacyId).run();
      return json({ ok: true, status: "approved", version: version.version });
    }

    if (version.status !== "approved") return json({ error: "Only an approved version can be published" }, 409);
    const checklist = body.checklist || {};
    const required = ["legalReview", "operationalReview", "supportMailbox", "privacyInventory", "addressReview"];
    const missing = required.filter((key) => checklist[key] !== true);
    if (missing.length) return json({ error: "Complete every publication readiness check", blockers: missing });
    const effectiveDate = String(body.effectiveDate || "");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(effectiveDate)) return json({ error: "Choose a valid effective date" }, 400);
    const published = await env.DB!.batch([
      db().prepare("UPDATE policy_versions SET status='published',published_by=?,published_by_email=?,published_at=?,effective_date=? WHERE id=? AND status='approved'")
        .bind(user.userId, user.email, stamp, effectiveDate, versionId),
      db().prepare("INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) SELECT ?,?,?,?,?,?,?,?,? WHERE changes()=1")
        .bind(crypto.randomUUID(), user.userId, user.email, "policy-publish", `${policyId}:v${version.version}`, reason, JSON.stringify({status: version.status}), JSON.stringify({status: "published", publishedBy: user.email, publishedAt: stamp, effectiveDate, checklist}), stamp),
    ]);
    if (Number(published[0]?.meta?.changes ?? (published[0] as { changes?: number })?.changes) !== 1) return json({ error: "This version changed while publication was being recorded. Refresh and review again." }, 409);
    return json({ ok: true, status: "published", version: version.version, effectiveDate });
  } catch (error) {
    console.error("Policy management action failed", error);
    return json({ error: "Policy action could not be completed" }, 500);
  }
}
