import {
  emailWebhookSecret,
  saveEmailWebhookSecret,
} from "../../../email-webhook-config";
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
import { getEmailConfig } from "../../../email-config";
import { emailReplyTo } from "../../../email-reply-to";
import {
  emailTemplates,
  renderEmail,
  sampleEmail,
  type TemplateId,
} from "../../../email-templates";
import { queueTemplate, flushEmails } from "../../../notifications";
import { supportEmail } from "../../../public-support";
import { limit } from "../../../security";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "private,no-store" };
export async function GET(req: Request) {
  if (!await isAdmin(await getChatGPTUser(), "settings"))
    return Response.json(
      { error: "Admin access required" },
      { status: 403, headers },
    );
  try {
    const config = await getEmailConfig(),
      replyTo = await emailReplyTo();
    const id = new URL(req.url).searchParams.get("template") || "verification";
    const selected = emailTemplates.find((t) => t.id === id);
    if (!selected)
      return Response.json(
        { error: "Unknown template" },
        { status: 400, headers },
      );
    const logs = (
      await env
        .DB!.prepare(
          "SELECT id,template,status,delivery_status,attempts,last_error,updated,retry_at FROM email_outbox ORDER BY created DESC LIMIT 50",
        )
        .all()
    ).results;
    return Response.json(
      {
        templates: emailTemplates.map((t) => ({
          ...t,
          enabled: t.connected && Boolean(config),
        })),
        selected: id,
        preview: renderEmail(id as TemplateId, sampleEmail(id as TemplateId)),
        configuration: {
          configured: Boolean(config),
          from: config?.from || null,
          replyTo,
          replyToStatus: replyTo
            ? "Owner-confirmed monitored contact; mailbox delivery not independently tested"
            : "Not configured — replies must not be advertised as support",
          senderDomainStatus:
            "API acceptance is recorded by setup; current domain verification must be checked separately",
          webhookConfigured: Boolean(await emailWebhookSecret()),
          webhookSetupAvailable: Boolean(
            env.BUCKET && env.STREAM_CONFIG_KEY && !env.RESEND_WEBHOOK_SECRET,
          ),
          webhookUrl: "https://cashncarryng.com/api/emails/webhook",
        },
        logs,
      },
      { headers },
    );
  } catch {
    return Response.json(
      { error: "Unable to load templates or email status" },
      { status: 503, headers },
    );
  }
}
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403, headers });
  const user = await getChatGPTUser();
  if (!await isAdmin(user, "settings"))
    return Response.json(
      { error: "Admin access required" },
      { status: 403, headers },
    );
  if (Number(req.headers.get("Content-Length") || 0) > 4096)
    return Response.json(
      { error: "Request too large" },
      { status: 413, headers },
    );
  try {
    const body: any = await req.json();
    await limit("email-templates:" + user!.userId, 5, 60);
    if (body.action === "webhook-secret") {
      await saveEmailWebhookSecret(String(body.secret || "").trim());
      await env
        .DB!.prepare(
          "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
        )
        .bind(
          crypto.randomUUID(),
          user!.userId,
          user!.email,
          "email-webhook-configuration",
          "resend",
          "Administrator configured signed delivery feedback",
          "{}",
          '{"configured":true}',
          new Date().toISOString(),
        )
        .run();
      return Response.json(
        {
          message:
            "Signing secret encrypted and saved. Configure the webhook URL and events in Resend; saving does not create a provider webhook.",
        },
        { headers },
      );
    }
    if (body.action === "reply-to") {
      const recipient = supportEmail(body.recipient);
      if (!recipient || body.confirmed !== true)
        throw Error(
          "Provide an address and confirm it receives replies and is monitored",
        );
      const stamp = new Date().toISOString();
      await env.DB!.batch([
        env
          .DB!.prepare(
            "INSERT INTO platform_settings(key,value,updated) VALUES('email_reply_to',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated",
          )
          .bind(recipient, stamp),
        env
          .DB!.prepare(
            "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
          )
          .bind(
            crypto.randomUUID(),
            user!.userId,
            user!.email,
            "email-reply-to",
            "email",
            "Owner confirmed mailbox receives replies and is monitored",
            "{}",
            JSON.stringify({ recipient }),
            stamp,
          ),
      ]);
      return Response.json(
        { message: "Reply-To saved based on your mailbox confirmation" },
        { headers },
      );
    }
    const config = await getEmailConfig();
    if (!config) throw Error("Configure the secure email sender first");
    if (body.action === "check-domain") {
      const r = await fetch("https://api.resend.com/domains", {
        headers: { Authorization: `Bearer ${config.apiKey}` },
        signal: AbortSignal.timeout(10000),
      });
      if (!r.ok)
        return Response.json(
          {
            message:
              r.status === 403 || r.status === 401
                ? "The sending key cannot inspect domains. Check verification in Resend; do not broaden key permissions just for this check."
                : "Domain status could not be retrieved; check Resend",
          },
          { headers },
        );
      const result: any = await r.json();
      const sender = config.from.match(/@([^>\s]+)/)?.[1]?.toLowerCase();
      const domain = result.data?.find(
        (d: any) => d.name?.toLowerCase() === sender,
      );
      return Response.json(
        {
          message: domain
            ? `Sender domain ${domain.name}: ${domain.status}. Receiving capability: ${domain.capabilities?.receiving || "not reported"}. Domain receiving does not prove this mailbox is monitored.`
            : "Configured sender domain was not returned. Check the domain in Resend.",
          domain: domain
            ? {
                name: domain.name,
                status: domain.status,
                receiving: domain.capabilities?.receiving,
              }
            : null,
        },
        { headers },
      );
    }
    if (body.action !== "test") throw Error("Unknown email action");
    const recipient = supportEmail(body.recipient),
      template = emailTemplates.find((t) => t.id === body.template);
    if (
      !recipient ||
      !template ||
      body.confirmed !== true ||
      !/^[a-f0-9-]{36}$/.test(body.requestId || "")
    )
      throw Error(
        "Choose a template and controlled test recipient, then confirm test sending",
      );
    const id = await queueTemplate(
      recipient,
      `test:${user!.userId}:${body.requestId}:${template.id}`,
      template.id,
      { ...sampleEmail(template.id), sample: true },
    );
    await env
      .DB!.prepare(
        "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING",
      )
      .bind(
        "test-" + id,
        user!.userId,
        user!.email,
        "email-template-test",
        template.id,
        "Administrator explicitly selected and confirmed a controlled test recipient",
        "{}",
        JSON.stringify({ recipient, outbox: id }),
        new Date().toISOString(),
      )
      .run();
    await flushEmails(id); // Test only this message; never flush customer messages from the test action.
    const status: any = await env
      .DB!.prepare(
        "SELECT status,delivery_status,last_error,retry_at FROM email_outbox WHERE id=?",
      )
      .bind(id)
      .first();
    return Response.json(
      {
        id,
        ...status,
        message:
          status?.status === "sent"
            ? "Resend accepted the sample email. Inbox delivery is not confirmed."
            : "Test queued but provider acceptance is not confirmed. Check the sending status before retrying.",
      },
      { headers },
    );
  } catch (error) {
    const message =
      error instanceof Error && !error.message.includes("D1_ERROR")
        ? error.message
        : "Email action could not be completed";
    return Response.json({ error: message }, { status: 400, headers });
  }
}
