import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
import { limit } from "../../../security";
const json = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
export async function GET() {
  if (!(await isAdmin(await getChatGPTUser(), "roles")))
    return json({ error: "Owner access and MFA required" }, 403);
  const rows = (
    await env
      .DB!.prepare(
        "SELECT key,value,updated FROM platform_settings WHERE key LIKE 'admin_role:%' ORDER BY updated DESC",
      )
      .all()
  ).results;
  return json({
    assignments: rows.map((r: any) => ({
      userId: r.key.slice(11),
      ...JSON.parse(r.value),
      updated: r.updated,
    })),
  });
}
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return json({ error: "Invalid origin" }, 403);
  const user = await getChatGPTUser();
  if (!(await isAdmin(user, "roles")))
    return json({ error: "Owner access and MFA required" }, 403);
  try {
    await limit("admin-access:" + user!.userId, 10);
    const b: any = await req.json(),
      target = String(b.userId || "").slice(0, 150),
      reason = String(b.reason || "")
        .trim()
        .slice(0, 1000);
    if (
      !target ||
      reason.length < 5 ||
      b.confirm !== true ||
      !["admin", "support", "finance", "moderator", "revoke"].includes(b.role)
    )
      throw Error("Choose an existing account, role, reason and confirmation");
    const profile: any = await env
      .DB!.prepare("SELECT id,email,suspended FROM profiles WHERE id=?")
      .bind(target)
      .first();
    if (
      !profile ||
      profile.suspended ||
      profile.email?.toLowerCase() === env.REVIBE_ADMIN_EMAIL?.toLowerCase()
    )
      throw Error("Cannot change this account's access");
    const emailAccount: any = await env
      .DB!.prepare(
        "SELECT id,email_verified FROM auth_user WHERE lower(email)=lower(?)",
      )
      .bind(profile.email)
      .first();
    if (b.role !== "revoke" && !emailAccount?.email_verified)
      throw Error(
        "A verified email account is required; the recipient must enrol MFA before access",
      );
    const key = "admin_role:" + target,
      stamp = new Date().toISOString(),
      before: any = await env
        .DB!.prepare("SELECT value FROM platform_settings WHERE key=?")
        .bind(key)
        .first();
    const after =
      b.role === "revoke"
        ? null
        : { role: b.role, email: profile.email.toLowerCase() };
    await env.DB!.batch([
      after
        ? env
            .DB!.prepare(
              "INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated",
            )
            .bind(key, JSON.stringify(after), stamp)
        : env
            .DB!.prepare("DELETE FROM platform_settings WHERE key=?")
            .bind(key),
      env
        .DB!.prepare(
          "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
        )
        .bind(
          crypto.randomUUID(),
          user!.userId,
          user!.email,
          "admin-role",
          target,
          reason,
          before?.value || "null",
          JSON.stringify(after),
          stamp,
        ),
    ]);
    return json({ ok: true });
  } catch (e) {
    return json(
      { error: e instanceof Error ? e.message : "Unable to change access" },
      400,
    );
  }
}
