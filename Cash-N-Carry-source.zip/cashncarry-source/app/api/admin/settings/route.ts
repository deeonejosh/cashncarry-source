import { applyOwnerBusinessSetup } from "../../../business-setup";
import { runMaintenance } from "../../../maintenance-runner";
import { refundEmail, safelyEmail } from "../../../email-events";
import { supportEmail } from "../../../public-support";
import { androidLinkConfiguration } from "../../../android-links";
import {
  processRefund,
  reconcileRefund,
  reconcileExpiredPayments,
} from "../../../payments";
import { flushEmails } from "../../../notifications";
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
import { getImageUploadPolicy, normalizeImageUploadPolicy, utcDay } from "../../../media-upload-policy";
export const dynamic = "force-dynamic";
const q = (s: string, ...a: any[]) => env.DB!.prepare(s).bind(...a);
export async function GET() {
  const u = await getChatGPTUser();
  if (!await isAdmin(u, "settings"))
    return Response.json({ error: "Admin access required" }, { status: 403 });
  const tables = [
    "platform_settings",
    "categories",
    "payments",
    "refunds",
    "email_outbox",
  ];
  const result: any = {};
  for (const t of tables)
    result[t] = (
      await q(
        t === "email_outbox"
          ? "SELECT id,status,attempts,updated,retry_at FROM email_outbox ORDER BY created DESC LIMIT 100"
          : `SELECT * FROM ${t} LIMIT 300`,
      ).all()
    ).results;
  result.imageUploadPolicy = await getImageUploadPolicy(env.DB);
  const today = utcDay();
  result.imageUploadMetrics = await q(
    "SELECT COALESCE(SUM(image_count),0) AS successfulImagesToday,COALESCE(SUM(image_bytes),0) AS uploadedBytesToday,COALESCE(SUM(image_reserved_count),0) AS reservedImages,COALESCE(SUM(image_reserved_bytes),0) AS reservedBytes FROM upload_usage WHERE day=?",
  ).bind(today).first();
  result.imageUploadMetrics.allTimeUploadedBytes = Number((await q("SELECT COALESCE(SUM(image_bytes),0) AS bytes FROM upload_usage").first())?.bytes || 0);
  result.imageUploadMetrics.failed = Number((await q("SELECT COUNT(*) AS n FROM media_upload_requests WHERE status='failed' AND day=?").bind(today).first())?.n || 0);
  result.imageUploadMetrics.quotaRejected = Number((await q("SELECT COUNT(*) AS n FROM media_upload_requests WHERE status='rejected' AND day=?").bind(today).first())?.n || 0);
  result.imageUploadMetrics.accountsApproachingLimit = Number((await q("SELECT COUNT(*) AS n FROM upload_usage WHERE day=? AND (image_count>=? OR image_bytes>=?)").bind(today, Math.ceil(result.imageUploadPolicy.dailyImages * 0.8), Math.floor(result.imageUploadPolicy.dailyBytes * 0.8)).first())?.n || 0);
  const attempts = Number(result.imageUploadMetrics.failed) + Number(result.imageUploadMetrics.quotaRejected) + Number(result.imageUploadMetrics.successfulImagesToday);
  result.imageUploadMetrics.successRateToday = attempts ? Math.round(Number(result.imageUploadMetrics.successfulImagesToday) / attempts * 100) : null;
  return Response.json(result, { headers: { "Cache-Control": "no-store" } });
}
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403 });
  const u = await getChatGPTUser();
  try {
    const b: any = await req.json();
    const financeAction = ["refund-review", "refund-process", "refund-reconcile", "reconcile-payments"].includes(b.action);
    if (!await isAdmin(u, "settings") && !(financeAction && await isAdmin(u, "refunds")))
      return Response.json({error:"Admin permission and MFA required"},{status:403});
    const
      id = String(b.id || "").slice(0, 100),
      reason = String(b.reason || "")
        .trim()
        .slice(0, 1000),
      stamp = new Date().toISOString();
    if (b.action === "refund-process" && b.confirm !== true) throw Error("Confirm provider refund execution");
    if (!id || reason.length < 5) throw Error("Target and reason required");
    if (["run-maintenance", "owner-business-setup"].includes(b.action)) {
      if (!await isAdmin(u,"settings") || b.confirm !== true) return Response.json({error:"Owner confirmation required"},{status:403});
      const result = b.action === "run-maintenance" ? await runMaintenance() : await applyOwnerBusinessSetup();
      await q("INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)", crypto.randomUUID(),u!.userId,u!.email,b.action,id,reason,"{}",JSON.stringify(result || {ok:true}),stamp).run();
      return Response.json({ok:true,...result});
    }
    let stmt: any, before: any, after: any;
    if (
      [
        "refund-process",
        "refund-reconcile",
        "flush-emails",
        "reconcile-payments",
      ].includes(b.action)
    ) {
      const result =
        b.action === "refund-process"
          ? await processRefund(id)
          : b.action === "refund-reconcile"
            ? await reconcileRefund(id)
            : b.action === "reconcile-payments"
              ? await reconcileExpiredPayments()
              : { sent: await flushEmails() };
      await q(
        "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
        crypto.randomUUID(),
        u!.userId,
        u!.email,
        b.action,
        id,
        reason,
        "{}",
        JSON.stringify(result),
        stamp,
      ).run();
      return Response.json({ ok: true, ...result });
    }
    if (b.action === "android-app-links") {
      if (id !== "android_app_links" || b.confirmed !== true) throw Error("Confirm the package and certificate belong to your Android app");
      const config = androidLinkConfiguration(b);
      before = await q("SELECT * FROM platform_settings WHERE key=?", id).first();
      after = { key: id, value: JSON.stringify(config) };
      stmt = q("INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated", id, after.value, stamp);
    } else if (b.action === "public-support") {
      const email = supportEmail(b.value);
      if (id !== "public_support_email" || !email || b.confirmed !== true)
        throw Error("Provide a valid public support email and confirm it is monitored and approved for publication");
      before = await q("SELECT * FROM platform_settings WHERE key=?", id).first();
      after = { key: id, value: email };
      stmt = q("INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated", id, email, stamp);
    } else if (b.action === "seller-approval") {
      if (
        id !== "seller_approval_required" ||
        !["0", "1"].includes(String(b.value))
      )
        throw Error("Invalid seller approval setting");
      before = await q(
        "SELECT * FROM platform_settings WHERE key=?",
        id,
      ).first();
      after = { key: id, value: String(b.value) };
      stmt = q(
        "INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated",
        id,
        after.value,
        stamp,
      );
    } else if (b.action === "image-upload-policy") {
      if (id !== "image_upload_policy") throw Error("Invalid image upload policy target");
      const policy = normalizeImageUploadPolicy({
        dailyImages: Number(b.dailyImages),
        dailyBytes: Math.round(Number(b.dailyMegabytes) * 1024 * 1024),
        maxImageBytes: Math.round(Number(b.maxImageMegabytes) * 1024 * 1024),
        maxImagesPerProduct: Number(b.maxImagesPerProduct),
        uploadsPerMinute: Number(b.uploadsPerMinute),
      });
      if (
        !Number.isInteger(Number(b.dailyImages)) || Number(b.dailyImages) !== policy.dailyImages ||
        !Number.isFinite(Number(b.dailyMegabytes)) || Number(b.dailyMegabytes) * 1024 * 1024 !== policy.dailyBytes ||
        !Number.isFinite(Number(b.maxImageMegabytes)) || Number(b.maxImageMegabytes) * 1024 * 1024 !== policy.maxImageBytes ||
        !Number.isInteger(Number(b.maxImagesPerProduct)) || Number(b.maxImagesPerProduct) !== policy.maxImagesPerProduct ||
        !Number.isInteger(Number(b.uploadsPerMinute)) || Number(b.uploadsPerMinute) !== policy.uploadsPerMinute
      ) throw Error("Image limits are outside the supported ranges. Check the values and retry.");
      before = await q("SELECT * FROM platform_settings WHERE key=?", id).first();
      after = { key: id, value: JSON.stringify(policy) };
      stmt = q("INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated", id, after.value, stamp);
    } else if (b.action === "category") {
      const name = String(b.name || "")
        .trim()
        .slice(0, 40);
      if (!name) throw Error("Category name required");
      before = await q("SELECT * FROM categories WHERE id=?", id).first();
      after = { id, name, active: b.active ? 1 : 0 };
      stmt = q(
        "INSERT INTO categories(id,name,active) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,active=excluded.active",
        id,
        name,
        after.active,
      );
    } else if (b.action === "featured") {
      before = await q(
        "SELECT id,featured FROM products WHERE id=?",
        id,
      ).first();
      if (!before) throw Error("Product not found");
      after = { ...before, featured: b.featured ? 1 : 0 };
      stmt = q("UPDATE products SET featured=? WHERE id=?", after.featured, id);
    } else if (b.action === "commission") {
      const rate = Number(b.value);
      if (
        id !== "commission_percent" ||
        !Number.isFinite(rate) ||
        rate < 0 ||
        rate > 30
      )
        throw Error("Commission must be 0 to 30 percent");
      before = await q(
        "SELECT * FROM platform_settings WHERE key=?",
        id,
      ).first();
      after = { key: id, value: String(rate) };
      stmt = q(
        "INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated",
        id,
        String(rate),
        stamp,
      );
    } else if (b.action === "refund-review") {
      before = await q("SELECT * FROM refunds WHERE id=?", id).first();
      if (
        !before ||
        !["approved_for_processing", "rejected"].includes(b.status)
      )
        throw Error("Invalid refund review");
      if (
        !["requested", "approved_for_processing"].includes(before.status) ||
        before.status === b.status
      )
        return Response.json(
          {
            error:
              "This refund has already progressed or been reviewed. Refresh before taking another action.",
          },
          { status: 409 },
        );
      after = { ...before, status: b.status, updated: stamp };
      const applied: any = await env.DB!.batch([
        q(
          "UPDATE refunds SET status=?,updated=? WHERE id=? AND status=? AND status IN ('requested','approved_for_processing')",
          b.status,
          stamp,
          id,
          before.status,
        ),
        q(
          "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) SELECT ?,?,?,?,?,?,?,?,? WHERE changes()=1",
          crypto.randomUUID(),
          u!.userId,
          u!.email,
          b.action,
          id,
          reason,
          JSON.stringify(before),
          JSON.stringify({ ...after, outcome: "applied" }),
          stamp,
        ),
      ]);
      if (Number(applied[0]?.meta?.changes ?? applied[0]?.changes) !== 1)
        return Response.json(
          {
            error:
              "The refund changed while you were reviewing it. Refresh and retry.",
          },
          { status: 409 },
        );
      await safelyEmail(()=>refundEmail(id,reason));
      return Response.json({ ok: true, status: b.status });
    } else throw Error("Invalid action");
    await env.DB!.batch([
      stmt,
      q(
        "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
        crypto.randomUUID(),
        u!.userId,
        u!.email,
        b.action,
        id,
        reason,
        JSON.stringify(before),
        JSON.stringify(after),
        stamp,
      ),
    ]);
    return Response.json({ ok: true });
  } catch (e: any) {
    return Response.json({ error: e.message }, { status: 400 });
  }
}
