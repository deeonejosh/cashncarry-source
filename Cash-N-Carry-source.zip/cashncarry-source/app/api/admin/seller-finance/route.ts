import {reviewSellerVerification} from '../../../verification-review';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../../chatgpt-auth';
import {isAdmin} from '../../../admin-access';
import {minor,sellerFinanceSettings,earningsSummary,reconcileSellerTransfer,sellerFinanceNotice} from '../../../seller-finance';
import {flutterwave,paymentMode} from '../../../payments';
const q=(s:string,...a:any[])=>env.DB!.prepare(s).bind(...a);
const json=(d:any,status=200)=>Response.json(d,{status,headers:{'Cache-Control':'private,no-store'}});
export async function GET(){const u=await getChatGPTUser();const finance=await isAdmin(u,'payments'),verification=await isAdmin(u,'verification');if(!finance&&!verification)return json({error:'Admin permission and MFA required'},403);
 try{const stores:any=await q('SELECT s.id,s.name,CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles vp WHERE vp.id=s.owner AND vp.suspended=1) THEN 1 ELSE 0 END AS verified,s.suspended FROM stores s').all();
 const [subs,subscriptionPayments,banks,withdrawals,requests,releaseCandidates,releases,adjustments,audit]=await Promise.all([
 finance?q('SELECT ss.*,s.name,CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles vp WHERE vp.id=s.owner AND vp.suspended=1) THEN 1 ELSE 0 END AS verified FROM seller_subscriptions ss JOIN stores s ON s.id=ss.store ORDER BY ss.updated DESC LIMIT 300').all():{results:[]},
 finance?q('SELECT p.id,p.store,p.owner,p.mode,p.amount_minor,p.status,p.provider_id,p.provider_plan,p.recurring,p.created,p.period_start,p.period_end,s.name AS seller,CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles vp WHERE vp.id=s.owner AND vp.suspended=1) THEN 1 ELSE 0 END AS verified FROM seller_subscription_payments p JOIN stores s ON s.id=p.store ORDER BY p.created DESC LIMIT 500').all():{results:[]},
 q('SELECT b.id,b.store,b.mode,b.bank_name,b.account_name,substr(b.account_number,-4) AS last4,b.status,b.note,s.name AS seller,CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles vp WHERE vp.id=s.owner AND vp.suspended=1) THEN 1 ELSE 0 END AS verified FROM seller_banks b JOIN stores s ON s.id=b.store ORDER BY b.created DESC LIMIT 300').all(),
 finance?q('SELECT w.*,s.name AS seller,CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles vp WHERE vp.id=s.owner AND vp.suspended=1) THEN 1 ELSE 0 END AS verified,b.bank_name,b.account_name,substr(b.account_number,-4) AS last4 FROM seller_withdrawals w JOIN stores s ON s.id=w.store JOIN seller_banks b ON b.id=w.bank ORDER BY w.created DESC LIMIT 300').all():{results:[]},
 verification?q('SELECT v.id,v.store,v.legal_name,v.registration,v.seller_type,v.contact_email,v.contact_phone,v.status,v.note,v.appeal,v.created,s.name AS seller,CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles vp WHERE vp.id=s.owner AND vp.suspended=1) THEN 1 ELSE 0 END AS verified FROM verification_requests v JOIN stores s ON s.id=v.store ORDER BY v.created DESC,v.rowid DESC LIMIT 300').all():{results:[]},
 finance?q("SELECT p.id,p.amount,p.mode,p.provider_id,o.id AS order_id,o.store,o.status,o.created,s.name AS seller,CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles vp WHERE vp.id=s.owner AND vp.suspended=1) THEN 1 ELSE 0 END AS verified FROM payments p JOIN orders o ON o.id=p.order_id JOIN stores s ON s.id=o.store WHERE p.status='paid' AND NOT EXISTS(SELECT 1 FROM seller_earnings_releases r WHERE r.payment=p.id) ORDER BY p.created DESC LIMIT 300").all():{results:[]},
 finance?q('SELECT * FROM seller_earnings_releases ORDER BY created DESC LIMIT 300').all():{results:[]},
 finance?q('SELECT * FROM seller_adjustments ORDER BY created DESC LIMIT 300').all():{results:[]},
 q("SELECT id,action,target,reason,created FROM admin_audit WHERE action LIKE 'seller-%' ORDER BY created DESC LIMIT 100").all(),
 ]);
 const earnings=finance?await Promise.all(stores.results.map(async(s:any)=>({...s,...await earningsSummary(s.id)}))):[];
 const subscriptions=finance?await Promise.all(subs.results.map(async(s:any)=>{
  const [payment,billing,next]:any[]=await Promise.all([
   q("SELECT amount_minor FROM seller_subscription_payments WHERE store=? AND mode=? AND status='paid' ORDER BY period_end DESC,created DESC LIMIT 1",s.store,s.mode).first(),
   q('SELECT value FROM platform_settings WHERE key=?',`seller_subscription_billing_${s.mode}_${s.store}`).first(),
   q('SELECT value FROM platform_settings WHERE key=?',`seller_subscription_next_${s.mode}_${s.store}`).first(),
  ]);
  return {...s,amount_minor:Number(payment?.amount_minor||0),auto_renew:Boolean(s.provider_plan&&s.provider_subscription&&!s.cancel_at_end),next_renewal:next?.value||'',billing_status:billing?.value||(s.provider_subscription?'active':s.provider_plan?'provider_confirmation_pending':'manual')};
 })):[];
 return json({settings:await sellerFinanceSettings(),mode:paymentMode(),canFinance:finance,canVerification:verification,canSettings:await isAdmin(u,'settings'),subscriptions,subscriptionPayments:subscriptionPayments.results,banks:banks.results,withdrawals:withdrawals.results,verification:requests.results,releaseCandidates:releaseCandidates.results,releases:releases.results,adjustments:adjustments.results,audit:audit.results,earnings});
 }catch{return json({error:'Seller finance records unavailable'},503);}}
export async function POST(req:Request){if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Invalid origin'},403);
 const u=await getChatGPTUser();try{
 const b:any=await req.json(),reason=String(b.reason||'').trim().slice(0,1000),now=new Date().toISOString();
 if(reason.length<5)throw Error('Record a reason for this financial or verification action.');
 const permission=['verification-review','bank-review'].includes(b.action)?'verification':b.action==='settings'?'settings':'payments';
 if(!await isAdmin(u,permission))return json({error:'Authorised admin permission and MFA required'},403);
 const audit=(after:any)=>q('INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)',crypto.randomUUID(),u!.userId,u!.email,'seller-'+b.action,String(b.id||'settings'),reason,'{}',JSON.stringify(after),now);
 if(b.action==='settings'){
  const price=minor(b.priceMinor),fee=minor(b.feeMinor),days=minor(b.releaseDays);if(price<10000||price>100000000||days>90)throw Error('Invalid monthly price or release period');
  if(!['unconfirmed','sandbox_platform','direct_settlement'].includes(b.fundFlow))throw Error('Invalid fund-flow model');
  const currentSettings=await sellerFinanceSettings();
  if(currentSettings.fundFlow!==b.fundFlow&&await q("SELECT id FROM seller_withdrawals WHERE status IN ('requested','under_review','processing')").first())throw Error('Resolve pending withdrawals before changing fund flow.');
  const values={seller_monthly_minor:String(price),seller_price_confirmed:b.confirmPrice===true?'1':'0',seller_withdrawal_fee_minor:String(fee),seller_release_days:String(days),seller_fund_flow:b.fundFlow};
  await env.DB!.batch([...Object.entries(values).map(([k,v])=>q('INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated',k,v,now)),audit({...values,liveBilling:false,liveWithdrawals:false})]);return json({ok:true});
 }
 if(b.action==='verification-review')return json(await reviewSellerVerification(b.id,b.status,reason,u!));
 if(b.action==='bank-review'){
  if(!['verified','rejected'].includes(b.status))throw Error('Invalid bank decision');
  const result:any=await env.DB!.batch([q("UPDATE seller_banks SET status=?,note=?,updated=? WHERE id=? AND status='resolved'",b.status,reason,now,b.id),audit({status:b.status})]);if(Number(result[0]?.meta?.changes??result[0]?.changes)!==1)throw Error('Bank already reviewed');return json({ok:true});
 }
 if(b.action==='release'){
  if(b.confirm!==true)throw Error('Confirm settlement evidence and fund-release review');
  const p:any=await q("SELECT p.*,o.store,o.status AS order_status,o.payment_status,o.created AS order_created,o.delivered_at FROM payments p JOIN orders o ON o.id=p.order_id WHERE p.id=?",b.id).first();
  const settings=await sellerFinanceSettings();
  if(!p||p.mode!=='test'||paymentMode()!=='test'||settings.fundFlow!=='sandbox_platform')throw Error('Only simulated sandbox settlement releases are enabled. Direct settlements are not platform balances.');
  if(p.status!=='paid'||p.payment_status!=='paid'||p.order_status!=='delivered')throw Error('A verified paid and delivered order is required');
  // Conservative hold measured from payment update AND latest order fulfilment audit.
  const latest:any=await q("SELECT MAX(created) AS stamp FROM admin_audit WHERE target=? AND action IN ('order','seller-order')",p.order_id).first();
  if(!p.delivered_at)throw Error('Delivery timestamp evidence is required before release.');
  const since=[p.updated,p.delivered_at,latest?.stamp||''].sort().at(-1)!;
  if(Date.parse(since)>Date.now()-settings.releaseDays*86400000)throw Error('The configured release holding period has not elapsed.');
  if(await q("SELECT id FROM refunds WHERE payment=? AND status NOT IN ('rejected','failed')",p.id).first()||await q("SELECT id FROM reports WHERE target=? AND status IN ('open','in_review')",p.order_id).first())throw Error('Resolve refunds and disputes before releasing earnings');
  const amount=minor(b.amountMinor);if(!amount||amount>Math.round(p.amount*100))throw Error('Release must not exceed the verified buyer payment');
  const ref=String(b.settlementReference||'').trim();if(ref.length<5||ref.length>150)throw Error('Add a settlement reference');
  await env.DB!.batch([q('INSERT INTO seller_earnings_releases(id,store,payment,mode,amount_minor,settlement_reference,evidence,actor,created) VALUES(?,?,?,?,?,?,?,?,?)',crypto.randomUUID(),p.store,p.id,p.mode,amount,ref,reason,u!.userId,now),audit({amountMinor:amount,mode:'test',settlementReference:ref})]);return json({ok:true});
 }
 if(b.action==='adjustment'){
  if(paymentMode()!=='test')throw Error('Live accounting adjustments require an approved operational process');
  const amount=minor(b.amountMinor);if(!amount)throw Error('Enter a debit amount');
  if(!await q('SELECT id FROM stores WHERE id=?',b.id).first())throw Error('Seller not found');
  await env.DB!.batch([q('INSERT INTO seller_adjustments(id,store,mode,amount_minor,reference,reason,actor,created) VALUES(?,?,?,?,?,?,?,?)',crypto.randomUUID(),b.id,'test',-amount,String(b.reference||crypto.randomUUID()),reason,u!.userId,now),audit({amountMinor:-amount,mode:'test'})]);return json({ok:true});
 }
 const w:any=await q('SELECT * FROM seller_withdrawals WHERE id=?',b.id).first();if(!w||w.mode!=='test'||paymentMode()!=='test')throw Error('Only sandbox payout requests may be processed');
 if(b.action==='withdrawal-review'){
  if(!['under_review','cancelled'].includes(b.status)||!['requested','under_review'].includes(w.status))throw Error('Invalid withdrawal review');
  await env.DB!.batch([q('UPDATE seller_withdrawals SET status=?,note=?,updated=? WHERE id=? AND status=?',b.status,reason,now,w.id,w.status),audit({status:b.status})]);return json({ok:true});
 }
 if(b.action==='withdrawal-reconcile'){const result=await reconcileSellerTransfer(w.id);await audit(result).run();if(result.status==='paid'||result.status==='failed'){const title=result.status==='paid'?'Withdrawal completed':'Withdrawal failed',template=result.status==='paid'?'seller-withdrawal-paid':'seller-withdrawal-failed';await sellerFinanceNotice(w.store,template,`withdrawal-${result.status}:${w.id}`,title,`Flutterwave confirmed your withdrawal status as ${result.status}. Review the payment reference and amount in Seller Centre.`,[['Amount',`NGN ${(w.amount_minor/100).toFixed(2)}`],['Status',result.status],['Reference',w.reference]],'/seller/finance?tab=Withdrawals').catch(()=>{});}return json(result);}
 if(b.action==='withdrawal-process'){
  if(b.confirm!==true||w.status!=='under_review')throw Error('Review and explicitly approve this sandbox transfer first');
  const settings=await sellerFinanceSettings(),bank:any=await q("SELECT * FROM seller_banks WHERE id=? AND status='verified'",w.bank).first();
  const s:any=await q('SELECT s.verified,s.suspended,COALESCE(p.suspended,0) AS account_suspended FROM stores s LEFT JOIN profiles p ON p.id=s.owner WHERE s.id=?',w.store).first();
  const balance=await earningsSummary(w.store,'test');
  if(settings.fundFlow!=='sandbox_platform'||!bank||!s?.verified||s.suspended||s.account_suspended||balance.deficitMinor>0)throw Error('Bank, seller or available-funds review prevents payout');
  const claim:any=await q("UPDATE seller_withdrawals SET status='processing',updated=? WHERE id=? AND status='under_review'",now,w.id).run();if(Number(claim.meta?.changes??claim.changes)!==1)throw Error('Withdrawal already processing');
  // Do not reset after a timeout: the provider may have accepted the transfer.
  await audit({status:'processing',reference:w.reference}).run();
  const r:any=await flutterwave('transfers',{account_bank:bank.bank_code,account_number:bank.account_number,amount:w.amount_minor/100,currency:'NGN',debit_currency:'NGN',reference:w.reference,narration:'Cash N Carry sandbox seller payout'},'test');
  if(!r?.id||r.reference!==w.reference)throw Error('Provider response requires manual reconciliation; do not resubmit.');
  await q("UPDATE seller_withdrawals SET provider_id=?,updated=? WHERE id=? AND status='processing'",String(r.id),now,w.id).run();return json({ok:true,status:'processing'});
 }
 throw Error('Unknown seller administration action');
 }catch(e:any){return json({error:e.message?.includes('D1_')?'Record changed or financial constraint prevented this action. Refresh and review.':e.message},e.message?.includes('concurrently')?409:400);}}
