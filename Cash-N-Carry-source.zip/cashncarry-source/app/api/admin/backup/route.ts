import { brand } from "../../../brand";
import { env } from "cloudflare:workers";
import { ensureVideoStorefrontSchema } from "../../../video-storefront-schema";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
const tables = [
  "auth_user",
  "policy_acceptances",
  "auth_account",
  "auth_two_factor",
  "auth_session",
  "auth_verification",
  "profiles",
  "stores",
  "storefronts",
  "videos",
  "video_products",
  "video_likes",
  "video_saves",
  "video_comments",
  "video_events",
  "video_moderation_history",
  "products",
  "carts",
  "orders",
  "order_items",
  "streams",
  "chats",
  "live_blocks",
  "live_viewers",
  "reviews",
  "follows",
  "campaigns",
  "campaign_events",
  "addresses",
  "favourites",
  "preferences",
  "notifications",
  "payments",
  "payment_events",
  "refunds",
  "reports",
  "verification_requests",
  "admin_audit",
  "platform_settings",
  "categories",
  "policies",
  "policy_versions",
  "email_outbox",
  "email_suppressions",
  "email_webhook_events",
  "upload_usage",
  "media_upload_requests",
  "media_blocks",
  "seller_subscriptions",
  "seller_subscription_payments",
  "seller_banks",
  "seller_earnings_releases",
  "seller_adjustments",
  "seller_withdrawals",
];
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403 });
  const u = await getChatGPTUser();
  if (!await isAdmin(u, "settings"))
    return Response.json({ error: "Admin access required" }, { status: 403 });
  try {
    const b: any = await req.json();
    if (b.confirm !== "EXPORT PRIVATE BACKUP")
      return Response.json(
        { error: "Backup contains private data; confirm encrypted storage" },
        { status: 400 },
      );
    await ensureVideoStorefrontSchema();
    const data: any = {
      format: "revibe-backup-v1",
      created: new Date().toISOString(),
      media: "R2 objects must be backed up separately",
      tables: {},
    };
    // D1 batch executes the reads in one transaction, avoiding mixed snapshots
    // when orders/inventory change while an export is in progress.
    const snapshot = await env.DB!.batch(
      tables.map((t) => env.DB!.prepare(`SELECT * FROM ${t}`)),
    );
    tables.forEach((table, index) => {
      data.tables[table] = snapshot[index].results;
    });
    await env
      .DB!.prepare(
        "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
      )
      .bind(
        crypto.randomUUID(),
        u!.userId,
        u!.email,
        "backup_export",
        "database",
        "Administrator requested private database export",
        "{}",
        '{"outcome":"exported"}',
        data.created,
      )
      .run();
    return new Response(JSON.stringify(data), {
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="${brand.filePrefix}-private-backup.json"`,
        "Cache-Control": "no-store",
      },
    });
  } catch {
    console.error("backup_failed");
    return Response.json({ error: "Unable to export backup" }, { status: 503 });
  }
}
