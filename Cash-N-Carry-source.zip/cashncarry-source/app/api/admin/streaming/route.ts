import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
import { getStreamConfig, saveStreamConfig } from "../../../stream-config";
export const dynamic = "force-dynamic";
const headers = {"Cache-Control": "no-store"};
export async function GET() {
  if (!await isAdmin(await getChatGPTUser(), "settings")) return Response.json({error: "Admin access required"}, {status: 403, headers});
  try {
    const config = await getStreamConfig();
    return Response.json({configured: Boolean(config), accountId: config?.accountId || env.STREAM_ACCOUNT_ID || ""}, {headers});
  } catch { return Response.json({error: "Unable to load streaming configuration"}, {status: 503, headers}); }
}
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin) return Response.json({error: "Invalid origin"}, {status: 403, headers});
  const user = await getChatGPTUser();
  if (!await isAdmin(user, "settings")) return Response.json({error: "Admin access required"}, {status: 403, headers});
  if (Number(req.headers.get("content-length") || 0) > 8192) return Response.json({error: "Request too large"}, {status: 413, headers});
  try {
    const raw = await req.text();
    if (raw.length > 8192) return Response.json({error: "Request too large"}, {status: 413, headers});
    const body = JSON.parse(raw);
    const accountId = String(body.accountId || "").trim();
    const token = String(body.token || "").trim();
    if (!/^[a-f0-9]{32}$/i.test(accountId) || token.length < 20 || token.length > 512 || /\s/.test(token)) return Response.json({error: "Enter a valid Account ID and API token"}, {status: 400, headers});
    const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${accountId}/stream/live_inputs?per_page=1`, {headers: {Authorization: `Bearer ${token}`}, signal: AbortSignal.timeout(15000)});
    const result: any = await response.json();
    if (!response.ok || !result.success) {
      const codes = (Array.isArray(result.errors) ? result.errors : []).map((e: any) => Number(e.code)).filter(Number.isFinite).slice(0, 5);
      console.warn("stream_configuration_rejected", {status: response.status, codes});
      const help = response.status === 401 || response.status === 403 || codes.includes(10000) || codes.includes(9109)
        ? "Cloudflare rejected this token. Copy the token value and check Account → Stream → Edit permission for the same account."
        : "Cloudflare could not access Stream for this account. Check the Account ID, active Stream subscription and token permissions.";
      return Response.json({error: help + (codes.length ? ` Error code: ${codes.join(", ")}.` : "")}, {status: 400, headers});
    }
    await saveStreamConfig(accountId, token);
    await env.DB!.prepare("INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)").bind(crypto.randomUUID(), user!.userId, user!.email, "stream-configuration", "cloudflare-stream", "Administrator updated streaming credentials", "{}", JSON.stringify({accountId, configured: true}), new Date().toISOString()).run();
    return Response.json({ok: true, configured: true}, {headers});
  } catch { return Response.json({error: "Unable to verify or save streaming configuration. Please retry."}, {status: 503, headers}); }
}
