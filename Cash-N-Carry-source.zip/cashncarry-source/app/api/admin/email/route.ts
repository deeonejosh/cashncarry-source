import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
import { getEmailConfig, saveEmailConfig } from "../../../email-config";
import { supportEmail } from "../../../public-support";
import { limit } from "../../../security";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store" };
export async function GET() {
  if (!await isAdmin(await getChatGPTUser(), "settings"))
    return Response.json(
      { error: "Admin access required" },
      { status: 403, headers },
    );
  try {
    const config = await getEmailConfig();
    return Response.json(
      {
        configured: Boolean(config),
        from: config?.from || "",
        acceptedAt: config?.acceptedAt || null,
        environmentManaged: Boolean(env.RESEND_API_KEY && env.EMAIL_FROM),
        setupAvailable: Boolean(
          env.STREAM_CONFIG_KEY &&
          env.BUCKET &&
          env.DB &&
          env.BETTER_AUTH_SECRET &&
          env.SITE_URL,
        ),
      },
      { headers },
    );
  } catch {
    return Response.json(
      {
        error:
          "Unable to load email configuration. Existing ChatGPT sign-in remains available.",
      },
      { status: 503, headers },
    );
  }
}
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403, headers });
  const user = await getChatGPTUser();
  if (!await isAdmin(user, "settings"))
    return Response.json(
      { error: "Admin access required" },
      { status: 403, headers },
    );
  if (Number(req.headers.get("content-length") || 0) > 4096)
    return Response.json(
      { error: "Request too large" },
      { status: 413, headers },
    );
  try {
    if (env.RESEND_API_KEY && env.EMAIL_FROM)
      return Response.json(
        {
          error:
            "Email is managed through server secrets. Update those settings to replace the sender or key.",
        },
        { status: 409, headers },
      );
    if (
      !env.STREAM_CONFIG_KEY ||
      !env.BUCKET ||
      !env.DB ||
      !env.BETTER_AUTH_SECRET ||
      !env.SITE_URL
    )
      return Response.json(
        {
          error:
            "Secure email setup is unavailable until private storage and authentication server settings are configured.",
        },
        { status: 503, headers },
      );
    const raw = await req.text();
    if (raw.length > 4096)
      return Response.json(
        { error: "Request too large" },
        { status: 413, headers },
      );
    const body = JSON.parse(raw);
    const apiKey = String(body.apiKey || "").trim(),
      from = supportEmail(body.from),
      recipient = supportEmail(user!.email);
    const requestId = String(body.requestId || "");
    if (
      body.confirm !== "SEND TEST AND ENABLE" ||
      !/^re_[A-Za-z0-9_-]{10,200}$/.test(apiKey) ||
      !from ||
      !recipient ||
      !/^[a-f0-9-]{36}$/i.test(requestId)
    )
      return Response.json(
        {
          error:
            "Enter a Resend API key and sender email, then confirm the test email.",
        },
        { status: 400, headers },
      );
    const domain = from.split("@")[1].toLowerCase();
    if (domain === "resend.dev" || domain.endsWith(".resend.dev"))
      return Response.json(
        {
          error:
            "Use your own verified sender domain. Resend's demo sender cannot enable customer email accounts.",
        },
        { status: 400, headers },
      );
    await limit("email-setup:" + user!.userId, 5);
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      signal: AbortSignal.timeout(15000),
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "Idempotency-Key": "email-setup-" + requestId,
      },
      body: JSON.stringify({
        from,
        to: [recipient],
        subject: "Cash N Carry email setup test",
        text: "You requested this email from Cash N Carry's administrator settings. The provider accepted the sender configuration. Check that you received it before relying on registration and password recovery. No password or API key is included.",
      }),
    });
    const result: any = await response.json().catch(() => null);
    if (!response.ok || typeof result?.id !== "string" || !result.id) {
      const providerMessage = String(result?.message || "").toLowerCase();
      const reason =
        response.status === 401
          ? "Resend rejected the API key. Create or copy a valid sending key."
          : /domain.*verif|verif.*domain/.test(providerMessage)
            ? "The sender domain is not verified in Resend. Complete domain verification or choose an already verified sender."
            : /testing|own email|test.*recipient/.test(providerMessage)
              ? "Resend restricted this sender to test recipients. Use your own verified domain for customer email accounts."
              : response.status === 403
                ? "Resend denied sending permission. Check the key's domain permission and the verified sender address."
                : response.status === 429
                  ? "Resend has reached a sending or rate limit. Check your account limits before trying again."
                  : "Resend did not confirm acceptance. Check the sender address, account limits and key permission.";
      return Response.json(
        { error: reason + " Existing configuration was preserved." },
        { status: 400, headers },
      );
    }
    const acceptedAt = new Date().toISOString();
    await saveEmailConfig({ apiKey, from, acceptedAt });
    await env.DB.prepare(
      "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
    )
      .bind(
        crypto.randomUUID(),
        user!.userId,
        user!.email,
        "email-configuration",
        "resend",
        "Administrator requested a setup test and enabled email accounts",
        "{}",
        JSON.stringify({ from, configured: true, acceptedAt }),
        acceptedAt,
      )
      .run();
    return Response.json(
      {
        ok: true,
        configured: true,
        from,
        acceptedAt,
        message:
          "Resend accepted the test and encrypted settings were saved. Email accounts are enabled. Check your inbox and spam folder; acceptance does not confirm inbox delivery.",
      },
      { headers },
    );
  } catch (error) {
    const throttled =
      error instanceof Error && error.message.startsWith("Too many requests");
    return Response.json(
      {
        error: throttled
          ? "Too many setup attempts. Wait a minute before retrying."
          : "Unable to confirm email setup. Refresh the configuration status before retrying; the provider may already have accepted the test.",
      },
      {
        status: throttled ? 429 : 503,
        headers: { ...headers, ...(throttled ? { "Retry-After": "60" } : {}) },
      },
    );
  }
}
