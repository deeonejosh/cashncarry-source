import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
import { eligibleSellerSQL } from "../../../seller-activation";
import { ensureVideoStorefrontSchema } from "../../../video-storefront-schema";
export async function GET(
  req: Request,
  { params }: { params: Promise<{ key: string }> },
) {
  try {
    await ensureVideoStorefrontSchema();
    if (!env.BUCKET)
      return new Response("Storage unavailable", { status: 503 });
    const { key } = await params;
    if (key.startsWith("verification/") || key.startsWith("private/"))
      return new Response("Not found", { status: 404 });
    const hidden = () =>
      new Response("Not found", {
        status: 404,
        headers: { "Cache-Control": "no-store" },
      });
    if (!env.DB)
      return new Response("Storage unavailable", {
        status: 503,
        headers: { "Cache-Control": "no-store" },
      });
    const range = req.headers.get("range");
    const meta = await env.BUCKET.head(key);
    if (!meta) return hidden();
    const path = "/api/media/" + key;
    const absolute = new URL(path, req.url).href;
    const references =
      "(p.image IN (?,?) OR p.video IN (?,?) OR EXISTS(SELECT 1 FROM json_each(p.images) WHERE value IN (?,?)))";
    const args = [path, absolute, path, absolute, path, absolute];
    const blocked = await env.DB.prepare(
      "SELECT key FROM media_blocks WHERE key=?",
    )
      .bind(key)
      .first();
    if (blocked && !await isAdmin(await getChatGPTUser(), "products")) return hidden();
    const publicListing = await env.DB.prepare(
      "SELECT p.id FROM products p JOIN stores s ON s.id=p.store WHERE " +
        references +
        " AND (? IS NULL OR s.owner=?) AND p.active=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1) LIMIT 1",
    )
      .bind(
        ...args,
        meta.customMetadata?.owner || null,
        meta.customMetadata?.owner || null,
      )
      .first();
    const publicVideo = await env.DB.prepare(
      "SELECT v.id FROM videos v JOIN stores s ON s.id=v.store WHERE v.media IN (?,?) AND v.status='approved' AND v.published=1 AND s.suspended=0 AND " + eligibleSellerSQL("s") + " AND NOT EXISTS(SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1) LIMIT 1",
    ).bind(path, absolute).first();
    if (!publicListing && !publicVideo) {
      const user = await getChatGPTUser();
      if (!await isAdmin(user, "products")) {
        const linked = await env.DB.prepare(
          "SELECT p.id FROM products p WHERE " + references + " LIMIT 1",
        )
          .bind(...args)
          .first();
        const owner = meta.customMetadata?.owner;
        const activeOwner =
          user && owner === user.userId
            ? await env.DB.prepare(
                "SELECT s.id FROM stores s WHERE s.owner=? AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1) LIMIT 1",
              )
                .bind(user.userId)
                .first()
            : null;
        if (linked || !activeOwner) return hidden();
      }
    }
    if (req.headers.get("if-none-match") === meta.httpEtag && !range)
      return new Response(null, {
        status: 304,
        headers: { ETag: meta.httpEtag, "Cache-Control": "no-store" },
      });
    let offset = 0,
      length = meta.size;
    if (range) {
      const m = /^bytes=(\d*)-(\d*)$/.exec(range);
      if (!m || (!m[1] && !m[2]))
        return new Response(null, {
          status: 416,
          headers: { "Content-Range": `bytes */${meta.size}` },
        });
      if (!m[1]) {
        length = Math.min(Number(m[2]), meta.size);
        offset = meta.size - length;
      } else {
        offset = Number(m[1]);
        const end = m[2]
          ? Math.min(Number(m[2]), meta.size - 1)
          : meta.size - 1;
        length = end - offset + 1;
      }
      if (
        offset >= meta.size ||
        length <= 0 ||
        !Number.isSafeInteger(offset) ||
        !Number.isSafeInteger(length)
      )
        return new Response(null, {
          status: 416,
          headers: { "Content-Range": `bytes */${meta.size}` },
        });
    }
    const obj = await env.BUCKET.get(
      key,
      range ? { range: { offset, length } } : undefined,
    );
    if (!obj) return new Response("Not found", { status: 404 });
    const h = new Headers();
    obj.writeHttpMetadata(h);
    h.set("Cache-Control", "private,no-store,max-age=0");
    h.set("ETag", obj.httpEtag);
    h.set("Accept-Ranges", "bytes");
    h.set("Content-Length", String(length));
    h.set("X-Content-Type-Options", "nosniff");
    if (range)
      h.set(
        "Content-Range",
        `bytes ${offset}-${offset + length - 1}/${meta.size}`,
      );
    return new Response(obj.body, { status: range ? 206 : 200, headers: h });
  } catch (e) {
    console.error("Media read failed", e);
    return new Response("Media temporarily unavailable", { status: 503 });
  }
}
