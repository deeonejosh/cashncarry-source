import { limit } from "../../security";
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { getImageUploadPolicy, nextUtcReset, utcDay } from "../../media-upload-policy";
import { imageDimensions, imageDimensionsProblem } from "../../image-validation";
export const dynamic = "force-dynamic";

const imageTypes = ["image/jpeg", "image/png", "image/webp"];
const videoTypes = ["video/mp4", "video/webm", "video/quicktime"];
const MiB = 1024 * 1024;
const q = (sql: string, ...args: any[]) => env.DB!.prepare(sql).bind(...args);
const changed = (result: any) => Number(result?.meta?.changes ?? result?.changes ?? 0);

async function seller(userId: string) {
  const profile: any = await q("SELECT suspended FROM profiles WHERE id=?", userId).first();
  if (profile?.suspended) return { error: "Account suspended", status: 403 };
  const store = await q("SELECT id FROM stores WHERE owner=? AND suspended=0", userId).first();
  if (!store) return { error: "Create your storefront before uploading media.", status: 403 };
  return { store };
}

async function releaseStaleReservations(userId: string) {
  const cutoff = new Date(Date.now() - 30 * 60 * 1000).toISOString();
  const stale: any[] = (await q(
    "SELECT id,day,bytes,media_key FROM media_upload_requests WHERE user=? AND status='reserved' AND created<? ORDER BY created LIMIT 50",
    userId, cutoff,
  ).all()).results || [];
  for (const item of stale) {
    await env.DB!.batch([
      q("UPDATE upload_usage SET image_reserved_count=max(0,image_reserved_count-1),image_reserved_bytes=max(0,image_reserved_bytes-?) WHERE user=? AND day=? AND EXISTS(SELECT 1 FROM media_upload_requests WHERE id=? AND status='reserved')", item.bytes, userId, item.day, item.id),
      q("UPDATE media_upload_requests SET status='stale',updated=? WHERE id=? AND status='reserved'", new Date().toISOString(), item.id),
    ]);
    // A process can stop after the object write but before quota commit. Remove that orphan safely.
    try { await env.BUCKET?.delete(item.media_key); } catch { /* storage cleanup can be retried operationally */ }
  }
}

async function imageQuota(userId: string, day: string) {
  const policy = await getImageUploadPolicy(env.DB);
  const usage: any = await q(
    "SELECT image_count,image_bytes,image_reserved_count,image_reserved_bytes FROM upload_usage WHERE user=? AND day=?",
    userId, day,
  ).first();
  return {
    policy,
    usedCount: Number(usage?.image_count || 0),
    usedBytes: Number(usage?.image_bytes || 0),
    reservedCount: Number(usage?.image_reserved_count || 0),
    reservedBytes: Number(usage?.image_reserved_bytes || 0),
    resetsAt: nextUtcReset(),
  };
}

async function uploadImage(file: File, userId: string, day: string, requestId: string) {
  const { policy } = await imageQuota(userId, day);
  if (file.size > policy.maxImageBytes)
    return Response.json({ error: `Choose an image up to ${Math.round(policy.maxImageBytes / MiB)} MB.`, maxImageBytes: policy.maxImageBytes }, { status: 413 });

  const payload = await file.arrayBuffer();
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", payload));
  const contentHash = Array.from(digest, (byte) => byte.toString(16).padStart(2, "0")).join("");

  await releaseStaleReservations(userId);
  const existing: any = await q("SELECT user,status,media_key,content_hash FROM media_upload_requests WHERE id=?", requestId).first();
  if (existing) {
    if (existing.user !== userId) return Response.json({ error: "Upload request reference is invalid." }, { status: 409 });
    if (existing.status === "completed") {
      if (existing.content_hash !== contentHash) return Response.json({ error: "This request reference was already used for a different image." }, { status: 409 });
      const metadata: any = await env.BUCKET!.head(existing.media_key);
      if (metadata?.customMetadata?.owner === userId)
        return Response.json({ url: "/api/media/" + existing.media_key, reused: true, quota: await imageQuota(userId, day) }, { headers: { "Cache-Control": "no-store" } });
      return Response.json({ error: "The previous upload is no longer available. Retry with a new upload." }, { status: 409 });
    }
    if (existing.status === "reserved") return Response.json({ error: "This upload is still processing. Wait a moment before retrying." }, { status: 409 });
  }

  const duplicate: any = await q("SELECT media_key FROM media_upload_requests WHERE user=? AND content_hash=? AND status='completed' LIMIT 1", userId, contentHash).first();
  if (duplicate) {
    if (await q("SELECT key FROM media_blocks WHERE key=?", duplicate.media_key).first())
      return Response.json({ error: "This photo is unavailable. Choose a different image." }, { status: 403 });
    const metadata: any = await env.BUCKET!.head(duplicate.media_key);
    if (metadata?.customMetadata?.owner === userId)
      return Response.json({ url: "/api/media/" + duplicate.media_key, reused: true, quota: await imageQuota(userId, day) }, { headers: { "Cache-Control": "no-store" } });
    await q("UPDATE media_upload_requests SET status='stale',updated=? WHERE user=? AND content_hash=? AND status='completed'", new Date().toISOString(), userId, contentHash).run();
  }

  const key = crypto.randomUUID();
  const stamp = new Date().toISOString();
  const requestCreated = existing
    ? await q("UPDATE media_upload_requests SET day=?,bytes=?,content_hash=?,media_key=?,status='reserved',created=?,updated=? WHERE id=? AND user=? AND status IN ('failed','stale','rejected') RETURNING id", day, file.size, contentHash, key, stamp, stamp, requestId, userId).first()
    : await q("INSERT INTO media_upload_requests(id,user,day,bytes,content_hash,media_key,status,created,updated) VALUES(?,?,?,?,?,?,'reserved',?,?) ON CONFLICT(id) DO NOTHING RETURNING id", requestId, userId, day, file.size, contentHash, key, stamp, stamp).first();
  if (!requestCreated) return Response.json({ error: "This upload request is already being processed. Wait a moment, then retry if the image has not appeared." }, { status: 409 });
  await q("INSERT INTO upload_usage(user,day,bytes,count,image_count,image_bytes,image_reserved_count,image_reserved_bytes) VALUES(?,?,0,0,0,0,0,0) ON CONFLICT(user,day) DO NOTHING", userId, day).run();
  const reserved = await q(
    "UPDATE upload_usage SET image_reserved_count=image_reserved_count+1,image_reserved_bytes=image_reserved_bytes+? WHERE user=? AND day=? AND image_count+image_reserved_count<? AND image_bytes+image_reserved_bytes+?<=? RETURNING user",
    file.size, userId, day, policy.dailyImages, file.size, policy.dailyBytes,
  ).first();
  if (!reserved) {
    await q("UPDATE media_upload_requests SET status='rejected',updated=? WHERE id=? AND status='reserved'", new Date().toISOString(), requestId).run();
    const current = await imageQuota(userId, day);
    return Response.json({ error: `Today's image upload allowance has been reached (${current.usedCount}/${policy.dailyImages} files or ${Math.ceil(current.usedBytes / MiB)}/${Math.round(policy.dailyBytes / MiB)} MB). It resets at midnight UTC. You can continue without an image or retry after the reset.`, quota: current }, { status: 429, headers: { "Retry-After": String(Math.max(1, Math.ceil((Date.parse(current.resetsAt) - Date.now()) / 1000))) } });
  }

  try {
    await env.BUCKET!.put(key, payload, { httpMetadata: { contentType: file.type }, customMetadata: { owner: userId, sha256: contentHash } });
    const results: any[] = await env.DB!.batch([
      q("UPDATE upload_usage SET image_reserved_count=max(0,image_reserved_count-1),image_reserved_bytes=max(0,image_reserved_bytes-?),image_count=image_count+1,image_bytes=image_bytes+? WHERE user=? AND day=? AND EXISTS(SELECT 1 FROM media_upload_requests WHERE id=? AND status='reserved')", file.size, file.size, userId, day, requestId),
      q("UPDATE media_upload_requests SET status='completed',updated=? WHERE id=? AND status='reserved'", new Date().toISOString(), requestId),
    ]);
    if (changed(results[0]) !== 1 || changed(results[1]) !== 1) {
      try { await env.BUCKET!.delete(key); } catch { /* orphan cleanup is best effort */ }
      return Response.json({ error: "The upload timed out before it could be confirmed. Please select the image again to retry." }, { status: 503 });
    }
    return Response.json({ url: "/api/media/" + key, quota: await imageQuota(userId, day) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    let state: any = null;
    try { state = await q("SELECT status FROM media_upload_requests WHERE id=?", requestId).first(); } catch { /* retain the object if database outcome is uncertain */ }
    if (state?.status === "completed")
      return Response.json({ url: "/api/media/" + key, quota: await imageQuota(userId, day) }, { headers: { "Cache-Control": "no-store" } });
    if (state?.status === "reserved") {
      try {
        await env.DB!.batch([
          q("UPDATE upload_usage SET image_reserved_count=max(0,image_reserved_count-1),image_reserved_bytes=max(0,image_reserved_bytes-?) WHERE user=? AND day=? AND EXISTS(SELECT 1 FROM media_upload_requests WHERE id=? AND status='reserved')", file.size, userId, day, requestId),
          q("UPDATE media_upload_requests SET status='failed',updated=? WHERE id=? AND status='reserved'", new Date().toISOString(), requestId),
        ]);
        try { await env.BUCKET!.delete(key); } catch { /* orphan cleanup is best effort */ }
      } catch { /* a later stale-reservation pass will reconcile uncertain writes */ }
    }
    throw error;
  }
}

export async function GET() {
  const u = await getChatGPTUser();
  if (!u) return Response.json({ error: "Sign in to view image upload allowance." }, { status: 401 });
  try {
    if (!env.DB || !env.BUCKET) throw Error("Storage unavailable");
    const access: any = await seller(u.userId);
    if (access.error) return Response.json({ error: access.error }, { status: access.status });
    const day = utcDay();
    await releaseStaleReservations(u.userId);
    const quota = await imageQuota(u.userId, day);
    return Response.json({ ...quota, remainingCount: Math.max(0, quota.policy.dailyImages - quota.usedCount - quota.reservedCount), remainingBytes: Math.max(0, quota.policy.dailyBytes - quota.usedBytes - quota.reservedBytes) }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Image upload allowance is temporarily unavailable." }, { status: 503 });
  }
}

export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return Response.json({ error: "Invalid origin" }, { status: 403 });
  const u = await getChatGPTUser();
  if (!u) return Response.json({ error: "Sign in to upload" }, { status: 401 });
  if (Number(req.headers.get("content-length") || 0) > 41 * MiB)
    return Response.json({ error: "File is too large. Maximum upload is 40 MB." }, { status: 413 });
  try {
    if (!env.BUCKET || !env.DB) throw Error("Storage unavailable");
    const access: any = await seller(u.userId);
    if (access.error) return Response.json({ error: access.error }, { status: access.status });
    const uploadPolicy = await getImageUploadPolicy(env.DB);
    await limit("upload:" + u.userId, uploadPolicy.uploadsPerMinute, 60);
    const f = (await req.formData()).get("file");
    if (!(f instanceof File) || ![...imageTypes, ...videoTypes].includes(f.type) || f.size === 0 || f.size > 40 * MiB)
      return Response.json({ error: "Use JPG, PNG, WebP, MP4 or WebM. Videos may be up to 40 MB; image limits are shown in your upload allowance." }, { status: 400 });
    const b = new Uint8Array(await f.slice(0, 16).arrayBuffer());
    const ascii = (offset: number, len: number) => String.fromCharCode(...b.slice(offset, offset + len));
    const valid = f.type === "image/jpeg" ? b[0] === 255 && b[1] === 216 && b[2] === 255
      : f.type === "image/png" ? b[0] === 137 && ascii(1, 3) === "PNG"
      : f.type === "image/webp" ? ascii(0, 4) === "RIFF" && ascii(8, 4) === "WEBP"
      : f.type === "video/mp4" || f.type === "video/quicktime" ? ascii(4, 4) === "ftyp"
      : b[0] === 26 && b[1] === 69 && b[2] === 223 && b[3] === 163;
    if (!valid) return Response.json({ error: "The file does not match its media type. Choose a valid photo or video." }, { status: 400 });

    if (imageTypes.includes(f.type)) {
      const imageHeader = new Uint8Array(await f.slice(0, Math.min(f.size, MiB)).arrayBuffer());
      const dimensionsProblem = imageDimensionsProblem(imageDimensions(f.type, imageHeader));
      if (dimensionsProblem) return Response.json({ error: dimensionsProblem }, { status: 400 });
      const requestId = req.headers.get("Idempotency-Key") || crypto.randomUUID();
      if (!/^[a-zA-Z0-9-]{16,80}$/.test(requestId)) return Response.json({ error: "Invalid upload request reference." }, { status: 400 });
      return await uploadImage(f, u.userId, utcDay(), requestId);
    }

    // Existing video allowance remains unchanged; image-specific policy does not consume it.
    const day = utcDay();
    const reservation = await q("INSERT INTO upload_usage(user,day,bytes,count) VALUES(?,?,?,1) ON CONFLICT(user,day) DO UPDATE SET bytes=bytes+excluded.bytes,count=count+1 WHERE bytes+excluded.bytes<=209715200 AND count<20 RETURNING user", u.userId, day, f.size).first();
    if (!reservation) return Response.json({ error: "Daily video allowance reached (20 files or 200 MB). It resets at midnight UTC." }, { status: 429 });
    const key = crypto.randomUUID();
    try {
      await env.BUCKET.put(key, await f.arrayBuffer(), { httpMetadata: { contentType: f.type }, customMetadata: { owner: u.userId } });
    } catch (error) {
      await q("UPDATE upload_usage SET bytes=max(0,bytes-?),count=max(0,count-1) WHERE user=? AND day=?", f.size, u.userId, day).run();
      throw error;
    }
    return Response.json({ url: "/api/media/" + key }, { headers: { "Cache-Control": "no-store" } });
  } catch (e: any) {
    if (e.message?.startsWith("Too many requests")) return Response.json({ error: e.message }, { status: 429, headers: { "Retry-After": "60" } });
    console.error("media_upload_failed", { message: "Storage or upload service unavailable" });
    return Response.json({ error: "Upload failed and no image was saved. Please retry; the daily image quota was released." }, { status: 503 });
  }
}
