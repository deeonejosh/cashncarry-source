import { env } from "cloudflare:workers";
import { getChatGPTUser } from "./chatgpt-auth";
import {messageFileType} from "./message-file-type";
export async function messageContext() {
  const user = await getChatGPTUser();
  if (!user) return null;
  if (!env.DB) throw Error("Messaging temporarily unavailable");
  await env.DB.prepare("CREATE TABLE IF NOT EXISTS seller_messages (id TEXT PRIMARY KEY, store TEXT NOT NULL, buyer TEXT NOT NULL, sender TEXT NOT NULL, body TEXT NOT NULL, created TEXT NOT NULL)").run();
  await env.DB.prepare("CREATE INDEX IF NOT EXISTS seller_messages_thread ON seller_messages(store,buyer,created)").run();
  await env.DB.prepare("CREATE TABLE IF NOT EXISTS seller_message_files (message TEXT PRIMARY KEY, key TEXT NOT NULL UNIQUE, name TEXT NOT NULL, type TEXT NOT NULL, size INTEGER NOT NULL)").run();
  return {user, db:env.DB};
}
export async function messageThread(c:NonNullable<Awaited<ReturnType<typeof messageContext>>>,store:string,buyer:string){
  const seller=await c.db.prepare("SELECT id,owner,name,verified FROM stores WHERE id=? AND suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles WHERE id=stores.owner AND suspended=1)").bind(store).first<{id:string;owner:string;name:string;verified:number}>();
  if(!seller || (c.user.userId!==buyer && c.user.userId!==seller.owner) || buyer===seller.owner)return null;
  const blocked=await c.db.prepare("SELECT suspended FROM profiles WHERE id IN (?,?) AND suspended=1 LIMIT 1").bind(c.user.userId,buyer).first();
  return blocked?null:seller;
}
export const messageJson=(data:unknown,status=200)=>Response.json(data,{status,headers:{"Cache-Control":"no-store"}});

export async function validMessageFile(file:File){
  if(!messageFileType(file)||!file.size||file.size>10*1024*1024)return false;
  const bytes=new Uint8Array(await file.slice(0,4096).arrayBuffer());
  const text=(start:number,length:number)=>String.fromCharCode(...bytes.slice(start,start+length));
  switch(messageFileType(file)){
    case "image/jpeg":return bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
    case "image/png":return bytes[0]===137&&text(1,7)==="PNG\r\n\x1a\n";
    case "image/webp":return text(0,4)==="RIFF"&&text(8,4)==="WEBP";
    case "application/pdf":return text(0,5)==="%PDF-";
    default:return !bytes.includes(0);
  }
}
