"use client";
import { useEffect, useId, useRef, useState } from "react";
import { productPhotoProblem } from "./product-photo-validation";
import { optimizeProductImage } from "./optimize-product-image";
type Quota = { policy: { dailyImages: number; dailyBytes: number; maxImageBytes: number }; usedCount: number; usedBytes: number; remainingCount: number; remainingBytes: number; resetsAt: string };
export default function ProductPhoto({ initial = "", name, value, onChange, onBusy, disabled = false, showQuota = false }: {
  initial?: string; name?: string; value?: string; onChange?: (url: string) => void;
  onBusy: (busy: boolean) => void; disabled?: boolean; showQuota?: boolean;
}) {
  const [saved, setSaved] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [retryAvailable, setRetryAvailable] = useState(false);
  const [quota, setQuota] = useState<Quota | null>(null);
  const [quotaError, setQuotaError] = useState("");
  const [progress, setProgress] = useState(0);
  const [optimizing, setOptimizing] = useState(false);
  const picker = useRef<HTMLInputElement>(null);
  const camera = useRef<HTMLInputElement>(null);
  const active = useRef(false);
  const request = useRef<XMLHttpRequest | null>(null);
  const retryFile = useRef<File | null>(null);
  const retryRequest = useRef<{ signature: string; id: string } | null>(null);
  const validation = useRef<HTMLInputElement>(null);
  const choose = useRef<HTMLButtonElement>(null);
  const id = useId();
  const url = value ?? saved;
  const problem = productPhotoProblem(url, loaded, busy);
  async function refreshQuota() {
    try {
      const response = await fetch("/api/media", { cache: "no-store" });
      const result = await response.json() as Quota & { error?: string };
      if (!response.ok) throw Error(result.error || "Allowance unavailable");
      setQuota(result); setQuotaError("");
    } catch (error) { setQuotaError(error instanceof Error ? error.message : "Upload allowance unavailable."); }
  }
  useEffect(() => { if (showQuota) void refreshQuota(); }, [showQuota]);
  useEffect(() => { validation.current?.setCustomValidity(problem); }, [problem]);
  const change = (next: string) => { setSaved(next); onChange?.(next); setLoaded(false); setError(""); setUploadSuccess(false); };
  async function upload(file?: File, alreadyPrepared = false) {
    if (!file || active.current || disabled) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setError("Choose a JPG, PNG or WebP photo. Export HEIC photos as JPG first."); return;
    }
    const maxBytes = quota?.policy.maxImageBytes || 10 * 1024 * 1024;
    if (!file.size || file.size > maxBytes) { setError(`Choose a photo up to ${Math.round(maxBytes / (1024 * 1024))} MB.`); return; }
    active.current = true; setBusy(true); onBusy(true); setError("");
    setRetryAvailable(false);
    setProgress(0); setOptimizing(!alreadyPrepared);
    try {
      const prepared = alreadyPrepared ? file : await optimizeProductImage(file);
      setOptimizing(false);
      retryFile.current = prepared;
      const signature = `${prepared.name}:${prepared.size}:${prepared.lastModified}:${prepared.type}`;
      if (!retryRequest.current || retryRequest.current.signature !== signature) retryRequest.current = { signature, id: crypto.randomUUID() };
      const requestId = retryRequest.current.id;
      const body = new FormData(); body.append("file", prepared);
      const data = await new Promise<{ url?: string; error?: string; quota?: Quota }>((resolve, reject) => {
        const xhr = new XMLHttpRequest(); request.current = xhr; xhr.open("POST", "/api/media"); xhr.timeout = 60000; xhr.setRequestHeader("Idempotency-Key", requestId);
        xhr.upload.onprogress = (event) => { if (event.lengthComputable) setProgress(Math.round(event.loaded / event.total * 100)); };
        xhr.onerror = () => reject(Error("Upload interrupted. Check your connection and retry."));
        xhr.ontimeout = () => reject(Error("Upload timed out. Retry when your connection is stable."));
        xhr.onabort = () => reject(Error("Upload cancelled. No image was attached to the product."));
        xhr.onload = () => { try { const response = JSON.parse(xhr.responseText); if (xhr.status >= 200 && xhr.status < 300) resolve(response); else reject(Error(response.error || "Photo upload failed. Try again.")); } catch { reject(Error("Upload failed. Please retry.")); } };
        xhr.send(body);
      });
      if (typeof data.url !== "string") throw Error(data.error || "Photo upload failed. Try again.");
      change(data.url); setUploadSuccess(true);
      retryRequest.current = null;
      retryFile.current = null;
      setRetryAvailable(false);
      if (data.quota) setQuota(data.quota); else if (showQuota) void refreshQuota();
    } catch (e) { setRetryAvailable(Boolean(retryFile.current)); setError(e instanceof Error ? e.message : "Upload interrupted. Check your connection and try again."); }
    finally { request.current = null; active.current = false; setBusy(false); setOptimizing(false); onBusy(false); if (picker.current) picker.current.value = ""; if (camera.current) camera.current.value = ""; }
  }
  return <div className="product-photo-upload">
    <input ref={validation} className="photo-validation-proxy" aria-label="Product photo validation" tabIndex={-1} value={url} onChange={() => {}} onInvalid={e => { e.preventDefault(); setError(problem); choose.current?.focus(); }} />
    {name && <input type="hidden" name={name} value={url} />}
    <input ref={picker} id={id} type="file" accept="image/jpeg,image/png,image/webp" hidden disabled={disabled || busy} onChange={e => void upload(e.target.files?.[0])} />
    <input ref={camera} type="file" accept="image/jpeg,image/png,image/webp" capture="environment" hidden disabled={disabled || busy} onChange={e => void upload(e.target.files?.[0])} />
    <button ref={choose} type="button" className="secondary-button" disabled={disabled || busy || (showQuota && !!quota && (quota.remainingCount <= 0 || quota.remainingBytes <= 0))} onClick={() => picker.current?.click()}>{busy ? optimizing ? "Optimising photo…" : `Uploading photo… ${progress}%` : url ? "Replace photo from device" : "Choose photo from device"}</button>
    <button type="button" className="secondary-button" disabled={disabled || busy || (showQuota && !!quota && (quota.remainingCount <= 0 || quota.remainingBytes <= 0))} onClick={() => camera.current?.click()}>Take photo</button>
    {busy && <>{optimizing ? <p role="status">Preparing a smaller product image…</p> : <><progress max="100" value={progress} aria-label="Photo upload progress"/><button type="button" className="secondary-button" onClick={() => request.current?.abort()}>Cancel upload</button></>}</>}
    {!!error && !busy && retryAvailable && <button type="button" className="secondary-button" disabled={disabled} onClick={() => void upload(retryFile.current || undefined, true)}>Retry photo upload</button>}
    <p>Choose a photo from your phone gallery or computer. JPG, PNG or WebP, up to {Math.round((quota?.policy.maxImageBytes || 10 * 1024 * 1024) / (1024 * 1024))} MB.</p>
    {showQuota && quota && <p className="product-photo-quota" aria-live="polite">Images uploaded today: {quota.usedCount} of {quota.policy.dailyImages}<br/>Image data uploaded today: {Math.ceil(quota.usedBytes / (1024 * 1024))} MB of {Math.round(quota.policy.dailyBytes / (1024 * 1024))} MB<br/>Allowance resets {new Date(quota.resetsAt).toLocaleString(undefined, { timeZone: "UTC" })} UTC.</p>}
    {showQuota && quotaError && <p role="status">{quotaError}</p>}
{showQuota && quota && quota.remainingCount <= 0 && <p className="product-photo-error" role="status">Today&apos;s image upload allowance has been reached. You can continue without an image, use an existing uploaded image where permitted, or upload again after the allowance resets.</p>}
    {url && <img key={url} className="product-photo-preview" src={url} alt="Product photo preview" onLoad={() => setLoaded(true)} onError={() => { setLoaded(false); setError("This photo cannot load. Choose a photo from your device to replace it."); }} />}
    {url && <button type="button" className="secondary-button" disabled={disabled || busy} onClick={() => change("")}>Remove photo</button>}
    <p role="status">{busy ? "Uploading. Please wait before saving." : uploadSuccess ? "Photo uploaded successfully. Save the product to attach it." : loaded && !url.startsWith("/api/media/") ? "Photo preview ready. Save the product to attach this image link." : ""}</p>
    {error && <p role="alert" className="product-photo-error">{error}</p>}
    <details><summary>Use an image link instead</summary><label className="field">Direct image URL<input type="url" value={url.startsWith("/api/media/") ? "" : url} disabled={disabled || busy} placeholder="https://example.com/photo.jpg" onChange={e => change(e.target.value)} /></label><p>Use a public image file link. Google search and share links do not display as photos.</p></details>
  </div>;
}
