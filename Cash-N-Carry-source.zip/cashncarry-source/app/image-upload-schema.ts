import { env } from "cloudflare:workers";

let ready: Promise<void> | null = null;

/** Additive runtime migration for Sites D1 deployments, which publish Worker code separately from SQL files. */
export async function ensureImageUploadSchema(db: any = env.DB) {
  if (!db) throw Error("Storage unavailable");
  if (!ready) {
    ready = (async () => {
      const columns = await db.prepare("PRAGMA table_info(upload_usage)").all();
      const names = new Set((columns.results || []).map((column: any) => String(column.name)));
      const additions = [
        ["image_count", "INTEGER NOT NULL DEFAULT 0"],
        ["image_bytes", "INTEGER NOT NULL DEFAULT 0"],
        ["image_reserved_count", "INTEGER NOT NULL DEFAULT 0"],
        ["image_reserved_bytes", "INTEGER NOT NULL DEFAULT 0"],
      ] as const;
      let addedUsageColumns = false;
      for (const [name, declaration] of additions) {
        if (names.has(name)) continue;
        try {
          await db.prepare(`ALTER TABLE upload_usage ADD COLUMN ${name} ${declaration}`).run();
          addedUsageColumns = true;
        } catch (error: any) {
          // Another isolate may have completed the same additive migration.
          if (!/duplicate column name/i.test(String(error?.message || error))) throw error;
        }
      }
      if (addedUsageColumns) {
        // Carry forward the legacy mixed-media quota for today so deployment does not reset
        // a seller's already-used allowance in the middle of the UTC day.
        const today = new Date().toISOString().slice(0, 10);
        await db.prepare("UPDATE upload_usage SET image_count=max(image_count,count),image_bytes=max(image_bytes,bytes) WHERE day=?").bind(today).run();
      }
      await db.prepare(`CREATE TABLE IF NOT EXISTS media_upload_requests (
        id TEXT PRIMARY KEY,
        user TEXT NOT NULL,
        day TEXT NOT NULL,
        bytes INTEGER NOT NULL,
        content_hash TEXT NOT NULL DEFAULT '',
        media_key TEXT NOT NULL UNIQUE,
        status TEXT NOT NULL CHECK(status IN ('reserved','completed','failed','stale','rejected')),
        created TEXT NOT NULL,
        updated TEXT NOT NULL
      )`).run();
      await db.prepare("CREATE INDEX IF NOT EXISTS media_upload_requests_cleanup ON media_upload_requests(status,created)").run();
      await db.prepare("CREATE UNIQUE INDEX IF NOT EXISTS media_upload_requests_owner_hash ON media_upload_requests(user,content_hash) WHERE content_hash!='' AND status='completed'").run();
    })().catch((error) => { ready = null; throw error; });
  }
  await ready;
}
