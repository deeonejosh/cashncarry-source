"use client";
import VerifiedSellerBadge from "./verified-seller-badge";
import { lazy, Suspense, useState, useEffect, useCallback, useRef } from "react";
import {
  CART_RESUME_KEY,
  readCartIntent,
  preserveCartForSignIn,
} from "./cart-resume";
import { shoppingReturnPath } from "./auth-navigation";
import { listingReview } from "./listing-review";
import { clientId } from "./client-id";
import ImageAsset from "./image-asset";
import ReturnGuidance from "./return-guidance";
import { trackAnalyticsEvent } from "./analytics";
import {
  ShoppingGuide,
  HomeFooter,
  ShoppingHero,
  ShopCategories,
} from "./shopping-design";
import BrandLogo from "./brand-logo";
import { brand } from "./brand";
import { deliveryQuote, deliveryFee } from "./delivery-quote";
import { broadcastLabel, broadcastSummary } from "./broadcasts";
import ScheduleInfo from "./schedule-info";
import { VideoDiscovery, VideoFeed } from "./video-feed";
import Link from "next/link";
import {
  Home,
  Bell,
  Plus,
  Radio,
  ShoppingBag,
  Search,
  ShoppingCart,
  Package,
  Store,
  ChartColumn,
  ChevronRight,
  X,
  MapPin,
  Heart,
  Check,
  LoaderCircle,
  Truck,
  ArrowUpRight,
  SlidersHorizontal,
  Shirt,
  Sparkles,
  Utensils,
  Headphones,
  Armchair,
  Briefcase,
  Play,
  Users,
  AlertCircle,
  MessageSquare,
  FileCheck2,
} from "lucide-react";

// Keep seller tools and modal-only workflows out of the initial discovery bundle.
// These chunks load when a seller opens their workspace or a buyer opens a dialog.
const SellerNavigation = lazy(() => import("./seller/navigation"));
const SellerActivationCard = lazy(() =>
  import("./seller/activation-card").then((module) => ({ default: module.SellerActivationCard })),
);
const NotificationPanel = lazy(() => import("./notification-panel"));
const ProductOptions = lazy(() => import("./product-options"));
const ProductPhoto = lazy(() => import("./product-photo"));
const LiveShopping = lazy(() => import("./live-shopping"));
const money = (n: number) =>
  new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(n || 0);
const defaultCategories = [
  "All",
  "Fashion",
  "Beauty",
  "Food",
  "Tech",
  "Home",
  "Services",
];
const icons = [
  ShoppingBag,
  Shirt,
  Sparkles,
  Utensils,
  Headphones,
  Armchair,
  Briefcase,
];
const initialNow=Date.now();
const initial: any = {
  products: [],
  stores: [],
  streams: [],
  cart: [],
  orders: [],
  sellerOrders: [],
  reviews: [],
  follows: [],
  campaigns: [],
};
const Field = ({
  label,
  name,
  type = "text",
  value = "",
  required = true,
  ...p
}: any) => (
  <label className="field">
    {label}
    <input
      name={name}
      type={type}
      defaultValue={value}
      required={required}
      {...p}
    />
  </label>
);
const Empty = ({
  title,
  text,
  action,
  label,
  icon: Icon = ShoppingBag,
  headingLevel = 3,
}: any) => {
  const Heading = headingLevel === 2 ? "h2" : "h3";
  return (
    <div className="empty">
      <span className="empty-icon">
        <Icon size={30} />
      </span>
      <Heading>{title}</Heading>
      <p>{text}</p>
      {action && (
        <button className="primary" onClick={action}>
          {label}
        </button>
      )}
    </div>
  );
};

const Button = ({ children, busy, disabled, ...p }: any) => (
  <button disabled={busy || disabled} {...p}>
    {children}
  </button>
);
export default function ReVibe({initialData,initialCatalogue}: {initialData?:any;initialCatalogue?:any} = {}) {
  const [data, setData] = useState<any>(initialData || initial),
    [view, setView] = useState("Home"),
    [category, setCategory] = useState("All"),
    [tab, setTab] = useState("For You"),
    [query, setQuery] = useState(""),
    [location, setLocation] = useState(""),
    [locationMode, setLocationMode] = useState("delivers"),
    [deviceLocation, setDeviceLocation] = useState<{
      lat: number;
      lng: number;
    } | null>(null),
    [radius, setRadius] = useState(25),
    [sort, setSort] = useState("newest"),
    [page, setPage] = useState(1),
    [variant, setVariant] = useState(""),
    [uploadProgress, setUploadProgress] = useState<number | null>(null),
    [modal, setModal] = useState<any>(null),
    [busy, setBusy] = useState(false),
    [loading, setLoading] = useState(!initialData),
    [error, setError] = useState(""),
    [toast, setToast] = useState(""),
    [toastKind, setToastKind] = useState("success"),
    [checkoutError, setCheckoutError] = useState(""),
    [sellerTab, setSellerTab] = useState("Overview");
  const categories: string[] = data.categories?.length
    ? ["All", ...data.categories.map((c: any) => c.name)]
    : defaultCategories;
  const [catalogue, setCatalogue] = useState<any>(initialCatalogue || {
    products: [],
    total: 0,
    page: 1,
    pages: 1,
  });
  const [catalogueLoading, setCatalogueLoading] = useState(!initialCatalogue);
  const [catalogueError, setCatalogueError] = useState("");
  const [catalogueVersion, setCatalogueVersion] = useState(0);
  const [sharedProductLoading, setSharedProductLoading] = useState(false);
  const [sharedProductError, setSharedProductError] = useState("");
  const [sharedProductRetry, setSharedProductRetry] = useState(0);
  const [filterDraft, setFilterDraft] = useState({
    location: "",
    mode: "delivers",
    category: "All",
    sort: "newest",
    radius: 25,
    deviceLocation: null as { lat: number; lng: number } | null,
  });
  const openFilters = () => {
    setFilterDraft({
      location,
      mode: locationMode,
      category,
      sort,
      radius,
      deviceLocation,
    });
    setModal({ type: "filters" });
  };
  useEffect(() => {
    setVariant("");
  }, [modal?.p?.id, modal?.stream?.product]);
  const operation = useRef(false);
  const trackedAds = useRef(new Set<string>());
  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/commerce", {
        signal: AbortSignal.timeout(15000),
      });
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      setData(d);
      setCatalogueVersion((v) => v + 1);
      setModal((m: any) =>
        m?.type === "product" && d.products.find((p: any) => p.id === m.p.id)
          ? { ...m, p: d.products.find((p: any) => p.id === m.p.id) }
          : m,
      );
      setError("");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    // The server already supplies this request’s current account and marketplace.
    if (!initialData) load();
  }, [load, initialData]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 4500);
    return () => clearTimeout(t);
  }, [toast]);
  useEffect(() => {
    if (!modal) return;
    const previous = document.activeElement as HTMLElement;
    const dialog = document.querySelector("[role=dialog]") as HTMLElement;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusable = () =>
      (
        Array.from(
          (dialog?.querySelector(".live-sheet") || dialog)?.querySelectorAll(
            "button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),summary",
          ) || [],
        ) as HTMLElement[]
      ).filter(
        (element) =>
          element.getClientRects().length > 0 &&
          getComputedStyle(element).visibility !== "hidden",
      );
    focusable()[0]?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") setModal(null);
      if (e.key === "Tab") {
        const els = focusable();
        const first = els[0],
          last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.body.style.overflow = oldOverflow;
      document.removeEventListener("keydown", key);
      previous?.focus();
    };
  }, [modal?.type]);
  const signed = (intent?: string) => {
    if (data.user) return true;
    window.location.assign(
      "/sign-in?returnTo=" +
        encodeURIComponent(
          shoppingReturnPath(
            window.location.pathname +
              window.location.search +
              window.location.hash,
            intent,
          ),
        ),
    );
    return false;
  };
  const act = async (b: any, success = "Saved") => {
    if (b.action === "checkout") setCheckoutError("");
    if (operation.current) return false;
    if (!data.user && b.action === "cart" && b.quantity > 0) {
      try {
        preserveCartForSignIn(
          b.product,
          b.variant || "",
          b.quantity,
          window.location.pathname +
            window.location.search +
            window.location.hash,
        );
      } catch (error: any) {
        setToast(error.message);
      }
      return false;
    }
    if (!signed()) return false;
    operation.current = true;
    setBusy(true);
    try {
      const r = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(b),
        signal: AbortSignal.timeout(b.action === "checkout" ? 45000 : 25000),
      });
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      if (d.paymentLink) {
        window.location.assign(d.paymentLink);
        return true;
      }
      await load();
      if (success) {
        setToastKind("success");
        setToast(success);
      }
      return true;
    } catch (e: any) {
      if (b.action === "checkout") setCheckoutError(e.message);
      setToastKind("error");
      setToast(e.message);
      return false;
    } finally {
      operation.current = false;
      setBusy(false);
    }
  };
  const resumingCart = useRef(false);
  const [resumeError, setResumeError] = useState("");
  const [resumeRetry, setResumeRetry] = useState(0);
  const [resumeReturnTo, setResumeReturnTo] = useState("");
  useEffect(() => {
    const key = new URLSearchParams(window.location.search).get("resumeCart");
    if (!key || loading || !data.user || resumingCart.current) return;
    let intent;
    try {
      intent = readCartIntent(sessionStorage);
    } catch {
      return;
    }
    if (!intent || intent.id !== key) return;
    resumingCart.current = true;
    setResumeError("");
    if (intent.intent === "buy-now") {
      fetch("/api/commerce?product=" + encodeURIComponent(intent.product), {
        signal: AbortSignal.timeout(15000),
      })
        .then(async (r) => {
          const result: any = await r.json();
          if (!r.ok) throw Error(result.error || "This product is unavailable.");
          setResumeReturnTo(intent.returnTo);
          setModal({
            type: "checkout",
            key: clientId(),
            directPurchase: { product: result.product, variant: intent.variant, quantity: intent.quantity },
          });
          sessionStorage.removeItem(CART_RESUME_KEY);
          const url = new URL(window.location.href);
          url.searchParams.delete("resumeCart");
          window.history.replaceState(window.history.state, "", url.pathname + url.search + url.hash);
        })
        .catch((e) => {
          setResumeError(e instanceof Error ? e.message : "Your saved purchase could not be opened.");
          resumingCart.current = false;
        });
      return;
    }
    act(
      {
        action: "cart_resume",
        request_id: intent.id,
        product: intent.product,
        variant: intent.variant,
        quantity: intent.quantity,
      },
      "Your selection was added to the cart after sign-in.",
    ).then((ok) => {
      if (ok) {
        setResumeReturnTo(intent.returnTo);
        sessionStorage.removeItem(CART_RESUME_KEY);
        const url = new URL(window.location.href);
        url.searchParams.delete("resumeCart");
        window.history.replaceState(
          window.history.state,
          "",
          url.pathname + url.search + url.hash,
        );
        setModal({ type: "cart" });
      } else {
        setResumeError(
          "Your saved selection could not be added. Review its option and stock or retry.",
        );
        resumingCart.current = false;
      }
    });
  }, [loading, data.user?.email, resumeRetry]);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get("buyNow");
    if (!productId || loading || error || !data.user) return;
    const controller = new AbortController();
    setSharedProductLoading(true);
    setSharedProductError("");
    fetch("/api/commerce?product=" + encodeURIComponent(productId), {
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]),
    })
      .then(async (r) => {
        const result: any = await r.json();
        if (!r.ok) throw Error(result.error || "This product is unavailable.");
        const quantity = Number(params.get("quantity") || 1);
        if (!Number.isInteger(quantity) || quantity < 1 || quantity > 99)
          throw Error("Choose a valid quantity before checkout.");
        if (!controller.signal.aborted)
          setModal({
            type: "checkout",
            key: clientId(),
            directPurchase: { product: result.product, variant: params.get("variant") || "", quantity },
          });
        params.delete("buyNow");
        params.delete("variant");
        params.delete("quantity");
        window.history.replaceState(window.history.state, "", window.location.pathname + (params.size ? "?" + params.toString() : "") + window.location.hash);
      })
      .catch((e) => {
        if (!controller.signal.aborted) setSharedProductError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setSharedProductLoading(false);
      });
    return () => controller.abort();
  }, [loading, error, data.user?.email, sharedProductRetry]);
  const add = async (p: any) => {
    if (
      JSON.parse(p.variants || "[]").length &&
      !JSON.parse(p.variants).some((v: any) => v.name === variant)
    ) {
      setModal({ type: "product", p });
      setToastKind("error");
      setToast("Choose a product option before adding it");
      return false;
    }
    const option = JSON.parse(p.variants || "[]").length ? variant : "";
    const existing = data.cart.find((c: any) => c.id === p.id);
    const ok=await act(
      {
        action: "cart",
        product: p.id,
        quantity: (existing?.variant === option ? existing.quantity : 0) + 1,
        variant: option,
      },
      "Added to your cart",
    );
    if(ok)trackAnalyticsEvent("add_to_cart",p.store,{product:p.id});
    return ok;
  };
  const buyNow = (p: any, selectedVariant = "", quantity = 1) => {
    const variants: any[] = JSON.parse(p.variants || "[]");
    const selected = variants.find((v) => v.name === selectedVariant);
    const stock = variants.length ? selected?.stock || 0 : p.stock;
    if ((variants.length && !selected) || !stock) {
      setToastKind("error");
      setToast(variants.length ? "Choose an available product option first." : "This item is sold out.");
      return;
    }
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > Math.min(stock, 99)) {
      setToastKind("error");
      setToast("Choose a valid quantity for the available stock.");
      return;
    }
    if (!data.user) {
      preserveCartForSignIn(p.id, selectedVariant, quantity, "/product/" + p.id, "buy-now");
      return;
    }
    trackAnalyticsEvent("buy_now",p.store,{product:p.id});
    trackAnalyticsEvent("checkout_start",p.store,{product:p.id});
    const store = data.stores.find((s: any) => s.id === p.store);
    const product = {
      ...p,
      delivery_fee: p.delivery_fee ?? store?.delivery_fee,
      coverage: p.coverage ?? store?.coverage,
    };
    setModal({
      type: "checkout",
      key: clientId(),
      directPurchase: { product, variant: selectedVariant, quantity },
    });
  };
  const form = async (e: any, action: string, extra: any = {}) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const b: any = Object.fromEntries(formData);
    if (action === "schedule") {
      b.featured = formData.getAll("featured");
      b.product = b.featured[0] || "";
    }
    for (const key of ["scheduled", "starts", "ends"])
      if (b[key]) b[key] = new Date(b[key]).toISOString();
    if (
      await act(
        { action, ...b, ...extra },
        action === "checkout"
          ? "Order created. Complete debit card payment in secure checkout. Check My orders for payment status."
          : "Saved successfully",
      )
    ) {
      setModal(null);
      if (action === "checkout") setView("Orders");
      if (action === "schedule")
        window.location.assign("/workspace?tab=Broadcasts");
    }
  };
  const upload = async (e: any) => {
    const file = e.target.files?.[0];
    if (!file || operation.current) return;
    const input = e.target
      .closest("form")
      ?.querySelector(`[name="${e.target.dataset.field}"]`) as HTMLInputElement;
    operation.current = true;
    setBusy(true);
    try {
      const f = new FormData();
      f.append("file", file);
      setUploadProgress(0);
      const d: any = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "/api/media");
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable)
            setUploadProgress(Math.round((e.loaded / e.total) * 100));
        };
        xhr.onerror = () =>
          reject(Error("Upload interrupted. Check your connection and retry."));
        xhr.onload = () => {
          try {
            const data = JSON.parse(xhr.responseText);
            if (xhr.status >= 200 && xhr.status < 300) resolve(data);
            else reject(Error(data.error || "Upload failed"));
          } catch {
            reject(Error("Upload failed. Please retry."));
          }
        };
        xhr.send(f);
      });
      if (input?.isConnected) input.value = d.url;
      setToastKind("success");
      setToast("Upload ready for playback. Save the product to publish it.");
    } catch (e: any) {
      setToastKind("error");
      setToast(e.message);
    } finally {
      setUploadProgress(null);
      operation.current = false;
      setBusy(false);
    }
  };
  const shoppingContext = () => ({
    view,
    query,
    category,
    location,
    locationMode,
    sort,
    page,
    tab,
    radius,
    deviceLocation,
  });
  const viewUrl = (v: string, search = "") =>
    "#" + v.toLowerCase() + (search ? "?q=" + encodeURIComponent(search) : "");
  const nav = (v: string) => {
    window.history.replaceState({ shopping: shoppingContext() }, "");
    const nextTab = v === "Home" && tab === "LIVE" ? "For You" : tab;
    const next = {
      ...shoppingContext(),
      view: v,
      query: "",
      category: "All",
      page: 1,
      tab: nextTab,
    };
    window.history.pushState({ shopping: next }, "", viewUrl(v));
    setView(v);
    setTab(nextTab);
    setQuery("");
    setCategory("All");
    setPage(1);
  };
  useEffect(() => {
    const restore = () => {
      const [path, search = ""] = window.location.hash.slice(1).split("?");
      const v =
        ["Home", "Explore", "Live", "Market", "Seller", "Orders"].find(
          (v) => v.toLowerCase() === path.toLowerCase(),
        ) || "Home";
      const saved = window.history.state?.shopping;
      setView(v);
      const section = new URLSearchParams(window.location.search).get("sellerTab");
      if (section && ["Overview", "Store", "Products", "Orders", "Content", "Ads"].includes(section)) setSellerTab(section);
      setQuery(saved?.query ?? new URLSearchParams(search).get("q") ?? "");
      if (saved) {
        setCategory(saved.category);
        setLocation(saved.location);
        setLocationMode(saved.locationMode);
        setSort(saved.sort);
        setPage(saved.page);
        setTab(saved.tab);
        setRadius(saved.radius);
        setDeviceLocation(saved.deviceLocation);
      }
      setModal(null);
    };
    restore();
    window.addEventListener("popstate", restore);
    window.addEventListener("hashchange", restore);
    return () => {
      window.removeEventListener("popstate", restore);
      window.removeEventListener("hashchange", restore);
    };
  }, []);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("startSelling") !== "1" || loading || error) return;
    if (!data.user) {
      const returnTo = window.location.pathname + window.location.search + window.location.hash;
      window.location.assign("/sign-in?returnTo=" + encodeURIComponent(returnTo));
      return;
    }
    setView("Seller");
    if (!data.myStore) setModal({ type: "storeForm" });
    params.delete("startSelling");
    window.history.replaceState(window.history.state, "", window.location.pathname + (params.size ? "?" + params.toString() : "") + window.location.hash);
  }, [loading, error, data.user?.email, data.myStore?.id]);
  useEffect(() => {
    if (loading || !data.user) return;
    const url = new URL(window.location.href);
    if (url.searchParams.get("open") !== "cart") return;
    setModal({ type: "cart" });
    url.searchParams.delete("open");
    window.history.replaceState(
      window.history.state,
      "",
      url.pathname + url.search + url.hash,
    );
  }, [loading, data.user]);
  const historyReady = useRef(false);
  useEffect(() => {
    if (!historyReady.current) {
      historyReady.current = true;
      return;
    }
    window.history.replaceState(
      {
        shopping: {
          view,
          query,
          category,
          location,
          locationMode,
          sort,
          page,
          tab,
          radius,
          deviceLocation,
        },
      },
      "",
      viewUrl(view, query),
    );
  }, [
    view,
    query,
    category,
    location,
    locationMode,
    sort,
    page,
    tab,
    radius,
    deviceLocation,
  ]);
  const matchesLocation = (value: string) =>
    !location.trim() ||
    String(value || "")
      .toLowerCase()
      .includes(location.trim().toLowerCase());
  const withinDistance = (s: any) => {
    if (!deviceLocation) return true;
    if (s?.latitude == null || s?.longitude == null) return false;
    const rad = (n: number) => (n * Math.PI) / 180,
      lat = Number(s.latitude),
      lng = Number(s.longitude),
      a =
        Math.sin(rad(lat - deviceLocation.lat) / 2) ** 2 +
        Math.cos(rad(deviceLocation.lat)) *
          Math.cos(rad(lat)) *
          Math.sin(rad(lng - deviceLocation.lng) / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) <= radius;
  };
  const matchesStore = (s: any) =>
    withinDistance(s) &&
    (locationMode === "delivers"
      ? matchesLocation(JSON.parse(s?.coverage || "[]").join(" "))
      : matchesLocation(s?.location));
  const stores = data.stores.filter(
    (s: any) =>
      matchesStore(s) &&
      (category === "All" || s.category === category) &&
      `${s.name} ${s.category} ${s.location}`
        .toLowerCase()
        .includes(query.trim().toLowerCase()),
  );
  const liveStreams = data.streams.filter((s: any) => {
    const store = data.stores.find((t: any) => t.id === s.store);
    return (
      (s.status !== "ended" || Boolean(s.replay)) &&
      !(
        s.status === "scheduled" &&
        s.scheduled &&
        Date.parse(s.scheduled) < initialNow - 86400000
      ) &&
      (tab !== "Following" ||
        data.follows.some((f: any) => f.store === s.store)) &&
      matchesStore(store) &&
      (category === "All" || store?.category === category) &&
      `${s.title} ${s.seller}`
        .toLowerCase()
        .includes(query.trim().toLowerCase())
    );
  });
  // The mobile Home feed is a separate discovery surface from Shop. Its Live
  // tab must not inherit search, category, location, or delivery filters that
  // are hidden while the full-screen feed is open.
  const homeFeedLiveStreams = data.streams.filter((s: any) =>
    ["live", "external"].includes(s.status),
  );
  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({
      q: query,
      category,
      location,
      mode: locationMode,
      sort,
      page: String(page),
      following: tab === "Following" && view === "Home" ? "1" : "0",
    });
    if (deviceLocation) {
      params.set("lat", String(deviceLocation.lat));
      params.set("lng", String(deviceLocation.lng));
      params.set("radius", String(radius));
    }
    setCatalogueLoading(true);
    setCatalogueError("");
    fetch("/api/catalog?" + params, {
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]),
    })
      .then(async (r) => {
        const result: any = await r.json();
        if (!r.ok) throw Error(result.error);
        if (!controller.signal.aborted) {
          setCatalogue(result);
          setModal((m: any) =>
            m?.type === "product"
              ? {
                  ...m,
                  p:
                    [...result.products, ...(result.featured || [])].find(
                      (p: any) => p.id === m.p.id,
                    ) || m.p,
                }
              : m,
          );
          if (result.page !== page) setPage(result.page);
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) setCatalogueError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setCatalogueLoading(false);
      });
    return () => controller.abort();
  }, [
    query,
    category,
    location,
    locationMode,
    sort,
    page,
    tab,
    view,
    deviceLocation,
    radius,
    catalogueVersion,
  ]);
  const products = catalogue.products;
  // The homepage is a discovery surface, not a second full catalogue. Fewer
  // initial product cards mean fewer large image downloads, especially on
  // mobile connections; Shop still retains the complete paginated catalogue.
  const homeProducts = view === "Home" ? products.slice(0, 4) : products;
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pid = params.has("stream") ? null : params.get("product");
    if (!pid || loading || error) return;
    const controller = new AbortController();
    setSharedProductLoading(true);
    setSharedProductError("");
    fetch("/api/commerce?product=" + encodeURIComponent(pid), {
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]),
    })
      .then(async (r) => {
        const result: any = await r.json();
        if (!r.ok) throw Error(result.error || "Unable to open this product");
        if (!controller.signal.aborted)
          setModal({ type: "product", p: result.product });
      })
      .catch((e) => {
        if (!controller.signal.aborted) setSharedProductError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setSharedProductLoading(false);
      });
    return () => controller.abort();
  }, [loading, error, sharedProductRetry]);
  useEffect(() => {
    const stream = new URLSearchParams(window.location.search).get("stream");
    if (!stream || loading || error) return;
    const controller = new AbortController();
    setSharedProductLoading(true);
    setSharedProductError("");
    fetch("/api/commerce?stream=" + encodeURIComponent(stream), {
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]),
    })
      .then(async (response) => {
        const result: any = await response.json();
        if (!response.ok)
          throw Error(result.error || "Unable to open this broadcast");
        if (!controller.signal.aborted) {
          setModal({ type: "live", stream: result.stream });
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) setSharedProductError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setSharedProductLoading(false);
      });
    return () => controller.abort();
  }, [loading, error, sharedProductRetry]);
  useEffect(
    () => setPage(1),
    [
      query,
      category,
      location,
      locationMode,
      radius,
      deviceLocation,
      tab,
      view,
    ],
  );
  useEffect(() => {
    for (const c of (data.sponsored || []).filter(
      (c: any) => c.placement === (view === "Market" ? "market" : "discovery"),
    )) {
      if (!trackedAds.current.has(c.id)) {
        trackedAds.current.add(c.id);
        fetch("/api/ads-events", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ campaign: c.id, kind: "impression" }),
        }).catch(() => {});
      }
    }
  }, [data.sponsored, view]);
  const mine = data.myProducts || [];
  const cartTotal = data.cart.reduce(
    (s: number, c: any) => s + c.price * c.quantity,
    0,
  );
  const cartStores = [...new Set(data.cart.map((p: any) => p.store))];
  const cartShipping =
    cartStores.length === 1
      ? deliveryQuote(data.stores.find((s: any) => s.id === cartStores[0]))
      : undefined;
  const cartFee = cartStores.length === 1 ? deliveryFee(data.stores.find((s: any) => s.id === cartStores[0])) : undefined;
  const directCheckout = modal?.type === "checkout" ? modal.directPurchase : null;
  const directVariants: any[] = directCheckout
    ? JSON.parse(directCheckout.product.variants || "[]")
    : [];
  const directOption = directVariants.find((v) => v.name === directCheckout?.variant);
  const checkoutProductTotal = directCheckout
    ? (directOption?.price ?? directCheckout.product.price) * directCheckout.quantity
    : cartTotal;
  const checkoutDelivery = directCheckout
    ? deliveryQuote(directCheckout.product)
    : cartShipping;
  const checkoutDeliveryFee = directCheckout
    ? deliveryFee(directCheckout.product)
    : cartFee;
  const sales = data.sellerOrders
    .filter(
      (o: any) =>
        o.status === "delivered" &&
        (o.payment !== "flutterwave" ||
          (o.payment_mode === "live" && o.payment_status === "paid")),
    )
    .reduce((s: number, o: any) => s + o.total, 0);

  const requestDeviceLocation = () => {
    if (!navigator.geolocation) {
      setToast(
        "Device location is unavailable. Enter your state or area manually.",
      );
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setDeviceLocation({
          lat: p.coords.latitude,
          lng: p.coords.longitude,
        });
        setLocationMode("located");
        setPage(1);
        setToast(
          "Showing sellers with public business coordinates within the selected distance.",
        );
      },
      () =>
        setToast(
          "Location access was denied or unavailable. Enter your state or area manually.",
        ),
    );
  };
  const renderProduct = (p: any, large = false) => {
    const variants: any[] = JSON.parse(p.variants || "[]");
    const available = variants.length
      ? variants.some((option) => option.stock > 0)
      : p.stock > 0;
    return (
    <article key={p.id} className={"product " + (large ? "featured" : "")}>
      <button
        className="product-image"
        onClick={() => {trackAnalyticsEvent("product_view",p.store,{product:p.id});setModal({ type: "product", p });}}
      >
        <ImageAsset src={p.image} alt={p.name} loading="lazy" />
        {p.video && (
          <span className="video-tag">
            <Play size={13} fill="currentColor" /> Product video
          </span>
        )}
        <span className="category-tag">{p.category}</span>
      </button>
      <button
        className="product-save"
        aria-label={
          (data.favourites?.some((f: any) => f.product === p.id)
            ? "Unsave "
            : "Save ") + p.name
        }
        aria-pressed={!!data.favourites?.some((f: any) => f.product === p.id)}
        disabled={busy}
        onClick={() =>
          signed() &&
          act(
            {
              action: "favourite",
              product: p.id,
              saved: !data.favourites?.some((f: any) => f.product === p.id),
            },
            "Saved products updated",
          )
        }
      >
        <Heart size={18} />
      </button>
      <div className="product-info">
        <button
          className="seller-link"
          onClick={() =>
            setModal({
              type: "store",
              store: data.stores.find((s: any) => s.id === p.store),
            })
          }
        >
          {p.seller}<VerifiedSellerBadge verified={p.verified}/> <ChevronRight size={13} />
        </button>
        <button
          className="product-name"
        onClick={() => {trackAnalyticsEvent("product_click",p.store,{product:p.id});setModal({ type: "product", p });}}
        >
          {p.name}
        </button>
        <div className="product-bottom">
          <strong>{money(p.price)}</strong>
        </div>
        <div className="product-card-actions">
          <button
            className="product-card-buy"
            disabled={busy || !available}
            onClick={() => {
              if (variants.length) {
                setModal({ type: "product", p });
                return;
              }
              buyNow(p);
            }}
          >
            Buy now
          </button>
          <button
            className="product-card-add"
            disabled={busy || !available}
            aria-label={"Add " + p.name + " to cart"}
            onClick={() => add(p)}
          >
            <Plus size={16} /> Add to cart
          </button>
        </div>
        <span className="secondary">
          {p.active === 0
            ? "No longer listed"
            : available
              ? "Seller: " + p.location
              : "Sold out"}
        </span>
        <small className="delivery-note">
          {(() => {
            const store = data.stores.find((t: any) => t.id === p.store);
            const coverage = JSON.parse(store?.coverage || "[]");
            return coverage.length
              ? coverage.length === 37 ? "Nationwide delivery · 36 states + FCT" : "Delivers to " + coverage.slice(0, 2).join(", ") + (coverage.length > 2 ? ` +${coverage.length - 2} states` : "")
              : "Confirm delivery coverage with seller";
          })()}
        </small>
      </div>
    </article>
    );
  };
  const orderList = (orders: any[], seller = false) =>
    orders.length ? (
      <div className="orders-list">
        {orders.map((o) => (
          <article className="order" key={o.id}>
            <div className="order-top">
              <div>
                <small>
                  ORDER {o.id.slice(0, 8).toUpperCase()}
                  {o.payment === "flutterwave" &&
                    (o.payment_mode === "live"
                      ? " · LIVE PAYMENT"
                      : " · SANDBOX TEST")}
                </small>
                <h3>{seller ? o.name : o.seller}</h3>
              </div>
              <span className={"status " + o.status}>{o.status}</span>
              <a href={"/order/" + o.id}>Order details</a>
            </div>
            {o.items?.map((i: any) => (
              <div className="order-line" key={i.id}>
                <span>
                  {i.quantity} × {i.name}
                </span>
                <strong>{money(i.price * i.quantity)}</strong>
                {!seller &&
                  o.payment === "flutterwave" &&
                  o.payment_status === "pending" && (
                    <button
                      onClick={() => act({ action: "retry-payment", id: o.id })}
                    >
                      Continue {o.payment_mode === "live" ? "" : "sandbox "}
                      payment
                    </button>
                  )}
                {!seller && o.payment_status === "paid" && (
                  <a href={"/workspace?tab=Support&order=" + encodeURIComponent(o.id)}>Request refund through support</a>
                )}
                {!seller && (
                  <a
                    href={"/api/orders/receipt?id=" + encodeURIComponent(o.id)}
                  >
                    Download order record
                  </a>
                )}
                {o.tracking && <p>Shipment: {o.tracking}</p>}
                {!seller && o.status === "delivered" && (
                  <button
                    onClick={() =>
                      setModal({ type: "review", item: i, order: o })
                    }
                  >
                    Review
                  </button>
                )}
              </div>
            ))}
            <div className="order-footer">
              <span>
                {new Date(o.created).toLocaleDateString("en-GB")} · {o.payment === "flutterwave" ? "Debit card" : "Cash on delivery"}
              </span>
              <strong>{money(o.total)}</strong>
            </div>
            <details>
              <summary>Delivery details</summary>
              <p>
                {o.name} · {o.phone}
                <br />
                {o.address}
              </p>
            </details>
            {!seller && o.status === "placed" && (
              <div className="order-actions">
                <Button
                  busy={busy}
                  className="secondary-button"
                  onClick={() => setModal({ type: "cancelOrder", order: o })}
                >
                  Cancel order
                </Button>
              </div>
            )}
            {seller &&
              ["placed", "confirmed", "shipped"].includes(o.status) && (
                <div className="order-actions">
                  {o.payment === "flutterwave" && o.payment_status !== "paid" && <p role="status">Awaiting verified payment. The customer must complete payment before you can confirm or fulfil this order. Pending payment does not mean it failed; ask the customer to check My orders before retrying.</p>}
                  {o.status !== "shipped" && o.payment !== "flutterwave" && (
                    <Button
                      busy={busy}
                      className="secondary-button"
                      onClick={() =>
                        act(
                          { action: "status", id: o.id, status: "cancelled" },
                          "Order cancelled; stock restored",
                        )
                      }
                    >
                      Cancel order
                    </Button>
                  )}
                  <Button
                    busy={busy}
                    disabled={o.payment === "flutterwave" && o.payment_status !== "paid"}
                    className="primary"
                    onClick={() =>
                      act(
                        {
                          action: "status",
                          id: o.id,
                          status: (
                            {
                              placed: "confirmed",
                              confirmed: "shipped",
                              shipped: "delivered",
                            } as any
                          )[o.status],
                        },
                        "Order updated",
                      )
                    }
                  >
                    {
                      (
                        {
                          placed: "Confirm order",
                          confirmed: "Mark shipped",
                          shipped: "Mark delivered",
                        } as any
                      )[o.status]
                    }
                  </Button>
                </div>
              )}
          </article>
        ))}
      </div>
    ) : (
      <Empty
        icon={Package}
        title="No orders yet"
        text={
          seller
            ? "Your customer orders will appear here."
            : "Your purchases and delivery updates will appear here."
        }
        action={() => nav("Market")}
        label="Browse the market"
      />
    );
  return (
    <div className="app">
      <div className="workspace">
        <header className={`topbar shopping-header${view === "Market" ? " mobile-shop-header" : view === "Home" ? " mobile-home-header" : ""}`}>
          <BrandLogo tagline compact />
          <button className="delivery-location" onClick={openFilters}>
            <MapPin size={18} />
            <span>
              <small>
                {locationMode === "delivers"
                  ? "Delivery to"
                  : "Seller location"}
              </small>
              <strong>{location || "Choose location"}</strong>
            </span>
          </button>
          <div className="search">
            <Search size={19} />
            <input
              aria-label="Search products and businesses"
              placeholder="Search products and sellers"
              value={query}
              onChange={(e) => {
                const nextQuery = e.target.value;
                const mobile = window.matchMedia("(max-width: 767px)").matches;
                const nextView = mobile && view === "Home"
                  ? "Market"
                  : ["Home", "Explore", "Market"].includes(view)
                  ? view
                  : "Market";
                if (nextView !== view) {
                  window.history.replaceState(
                    { shopping: shoppingContext() },
                    "",
                  );
                  window.history.pushState(
                    {
                      shopping: {
                        ...shoppingContext(),
                        view: nextView,
                        query: nextQuery,
                        page: 1,
                      },
                    },
                    "",
                    viewUrl(nextView, nextQuery),
                  );
                } else {
                  window.history.replaceState(
                    {
                      shopping: {
                        ...shoppingContext(),
                        query: nextQuery,
                        page: 1,
                      },
                    },
                    "",
                    viewUrl(nextView, nextQuery),
                  );
                }
                setQuery(nextQuery);
                setView(nextView);
                setPage(1);
              }}
            />
            <kbd>⌕</kbd>
          </div>
          <nav className="shopping-links" aria-label="Main navigation">
            <button
              aria-current={view === "Home" ? "page" : undefined}
              onClick={() => nav("Home")}
            >
              Home
            </button>
            <button
              className="nav-live-button"
              aria-current={view === "Live" ? "page" : undefined}
              onClick={() => nav("Live")}
            >
              <Radio size={18} aria-hidden="true" /> Live
            </button>
            <button
              aria-current={view === "Market" ? "page" : undefined}
              onClick={() => nav("Market")}
            >
              Shop
            </button>
          </nav>
          {view === "Home" && <button
            className="notification-button"
            onClick={() => signed("notifications") && setModal({type: "notifications"})}
            aria-label={"Notifications" + (data.notifications?.filter((n: any) => !n.read).length ? ", " + data.notifications.filter((n: any) => !n.read).length + " unread" : "")}
            aria-haspopup="dialog"
            aria-expanded={modal?.type === "notifications"}
          >
            <Bell size={21} aria-hidden="true" />
            {data.notifications?.some((n: any) => !n.read) && <span className="notification-badge">{Math.min(99,data.notifications.filter((n: any) => !n.read).length)}</span>}
          </button>}
          <button
            className="cart-button"
            onClick={() => signed("cart") && setModal({ type: "cart" })}
            aria-label="Shopping cart"
          >
            <ShoppingCart size={22} />
            {data.cart.length > 0 && (
              <b>
                {data.cart.reduce((s: number, p: any) => s + p.quantity, 0)}
              </b>
            )}
          </button>
          <button
            className="profile-button"
            aria-label="My account"
            onClick={() => window.location.assign("/account")}
          >
            <span className="avatar">
              {data.user ? (
                data.user.name[0].toUpperCase()
              ) : (
                <Users size={17} />
              )}
            </span>
          </button>
        </header>
        <main id="main-content" tabIndex={-1} className={view === "Home" ? "mobile-discovery-home storefront-home" : undefined}>
          {view === "Home" && <section className="mobile-home-feed desktop-home-feed" aria-label="Video and live discovery"><VideoFeed liveStreams={homeFeedLiveStreams} products={[...data.products, ...(data.pinnedProducts || []), ...catalogue.products, ...(catalogue.featured || [])]} myStoreId={data.myStore?.id} onOpenLive={(stream) => setModal({ type: "live", stream })}/></section>}
          {view === "Seller" &&
            data.myStore &&
            listingReview(data.myStore, data.myProducts || []).length > 0 && (
              <section className="notice" aria-label="Seller details to review">
                <h2>Details needing your review</h2>
                <ul>
                  {listingReview(data.myStore, data.myProducts || []).map(
                    (w) => (
                      <li key={w}>{w}</li>
                    ),
                  )}
                </ul>
                <a href="/workspace?tab=Account">Manage seller account</a>
              </section>
            )}
          {resumeError && (
            <div className="error-banner" role="alert">
              {resumeError}{" "}
              <button onClick={() => setResumeRetry((v) => v + 1)}>
                Retry saved selection
              </button>
            </div>
          )}
          {sharedProductLoading && <p role="status">Opening selected item…</p>}
          {sharedProductError && (
            <div role="alert" className="error-banner">
              {sharedProductError}{" "}
              <button onClick={() => setSharedProductRetry((v) => v + 1)}>
                Retry selected item
              </button>
            </div>
          )}
          {error ? (
            <div className="error-banner">
              {error} <button onClick={load}>Retry</button>
            </div>
          ) : null}
          {error && !data.products.length && !data.user ? (
            <Empty
              title={brand.name + " is temporarily unavailable"}
              text="Your connection or the service may be unavailable. Please try again."
              action={load}
              label="Retry"
            />
          ) : loading ? (
            <div className="loading">
              <LoaderCircle className="spin" /> Opening {brand.name}…
            </div>
          ) : view === "Seller" ? (
            <>
              <div className="page-heading seller-dashboard-heading">
                <div>
                  <p className="eyebrow">YOUR BUSINESS WORKSPACE</p>
                  <h1>Welcome back{data.myStore?.name ? `, ${data.myStore.name}` : ""}</h1>
                  <p>Your store, orders and next steps at a glance.</p>
                  {data.myStore && <div className="seller-dashboard-identity"><span>{data.myStore.suspended ? "Store needs attention" : "Store is active"}</span><span className="seller-dashboard-status-dot" aria-hidden="true"/><VerifiedSellerBadge verified={data.myStore.verified} suspended={data.myStore.suspended} /></div>}
                </div>
                {data.myStore ? (
                  <div className="seller-dashboard-actions">
                  <a className="seller-view-store" href={`/store/${data.myStore.id}`}><Store size={17}/> View storefront</a>
                  <button
                    className="primary"
                    onClick={() => setModal({ type: "productForm" })}
                  >
                    <Plus size={18} />
                    Add a product
                  </button>
                  </div>
                ) : <button className="primary" onClick={() => setModal({ type: "storeForm" })}>Create your store</button>}
              </div>
              <details className="seller-policy-disclosure"><summary>Seller policies &amp; guidance</summary><nav className="seller-policy-links" aria-label="Seller policies">
                <a href="/seller-terms" target="_blank" rel="noopener noreferrer">Seller Terms</a>
                <a href="/community-guidelines" target="_blank" rel="noopener noreferrer">Community Guidelines</a>
                <a href="/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a>
              </nav></details>
              {!data.myStore ? (
                <div className="seller-workspace-layout">
                  <Suspense fallback={<div className="seller-workspace-nav-loading" aria-hidden="true" />}><SellerNavigation active="Dashboard"/></Suspense>
                  <section className="seller-workspace-content" aria-label="Seller dashboard">
                <section className="onboarding panel">
                  <div>
                    <span className="pill">START SELLING</span>
                    <h2>
                      Give your business
                      <br />a home on {brand.name}.
                    </h2>
                    <p>
                      List your products, share demonstrations and manage orders
                      in one place.
                    </p>
                    <p className="policy-link-list"><a href="/seller-terms">Seller Terms</a><a href="/community-guidelines">Community Guidelines</a></p>
                    <ul>
                      <li>
                        <Check size={18} />A dedicated storefront
                      </li>
                      <li>
                        <Check size={18} />
                        Products, videos and inventory
                      </li>
                      <li>
                        <Check size={18} />
                        Live shopping and customer chat
                      </li>
                    </ul>
                    <button
                      className="primary"
                      onClick={() => setModal({ type: "storeForm" })}
                    >
                      Create my store
                    </button>
                  </div>
                  <Store size={100} strokeWidth={1} />
                </section>
                <section className="seller-my-website-card" aria-labelledby="seller-my-website-title">
                  <div className="seller-my-website-copy">
                    <span className="seller-my-website-icon" aria-hidden="true"><Store size={22}/></span>
                    <div><p className="eyebrow">YOUR ONLINE STOREFRONT</p><h2 id="seller-my-website-title">My Website</h2><p>Create your free storefront and start building a shareable home for your business.</p><Link className="seller-my-website-action" href="/seller/website">Create Your Free Store<ArrowUpRight size={16}/></Link></div>
                  </div>
                  <div className="seller-my-website-note"><Check size={16}/><span>Free basic storefront. Selling still follows existing verification and subscription rules.</span></div>
                </section>
                  </section>
                </div>
              ) : (
                <>
<div className="seller-workspace-layout"><Suspense fallback={<div className="seller-workspace-nav-loading" aria-hidden="true" />}><SellerNavigation active={sellerTab==='Overview'?'Dashboard':sellerTab==='Store'?'Storefront':sellerTab}/></Suspense>

                    <section
                      className="seller-workspace-content"
                      aria-label={sellerTab}
                    >
                      {["Overview", "Analytics"].includes(sellerTab) ? (
                        <>
                          <Suspense fallback={<div className="panel seller-activation-loading" aria-hidden="true" />}><SellerActivationCard /></Suspense>
                          <div className="stats">
                            {[
                              ["Delivered order value", money(sales), ChartColumn],
                              ["Pending orders", data.sellerOrders.filter((o: any) => !["delivered", "cancelled"].includes(o.status)).length, Package],
                              ["Listed products", mine.length, ShoppingBag],
                              ["Live now", data.streams.filter((s: any) => s.store === data.myStore.id && ["live", "external"].includes(s.status)).length, Radio],
                            ].map(([l, n, I]: any) => (
                              <div className="stat panel" key={l}>
                                <span>{l}<I size={19} /></span>
                                <strong>{n}</strong>
                                <small>{l === "Delivered order value" ? "Gross value of delivered orders" : "From your store activity"}</small>
                              </div>
                            ))}
                          </div>
                          <section className="seller-my-website-card" aria-labelledby="seller-my-website-title">
                            <div className="seller-my-website-copy">
                              <span className="seller-my-website-icon" aria-hidden="true"><Store size={22}/></span>
                              <div>
                                <p className="eyebrow">YOUR ONLINE STOREFRONT</p>
                                <h2 id="seller-my-website-title">My Website</h2>
                                <p>{data.myStore ? "Manage your storefront and share your Cash N Carry store link with customers." : "Create a free storefront for your business and share it with customers."}</p>
                                <Link className="seller-my-website-action" href="/seller/website">{data.myStore ? "Manage My Store" : "Create Your Free Store"}<ArrowUpRight size={16}/></Link>
                              </div>
                            </div>
                            <div className="seller-my-website-note"><Check size={16}/><span>Free basic storefront. Your existing product catalogue connects automatically.</span></div>
                          </section>
                          <section className="panel seller-next-steps" aria-label="Store setup and quick actions">
                            <div className="seller-section-heading"><div><p className="eyebrow">YOUR NEXT STEPS</p><h2>Daily tasks</h2></div><a href="/workspace?tab=Account">View all</a></div>
                            <div className="seller-task-grid">
                              <Link className="seller-task-card" href="/?browse=1&sellerTab=Orders#seller"><span className="seller-task-icon"><Package size={19}/></span><strong>Manage orders</strong><small>Process new orders</small></Link>
                              <a className="seller-task-card" href="/messages"><span className="seller-task-icon is-blue"><MessageSquare size={19}/></span><strong>Buyer messages</strong><small>Reply to customers</small></a>
                              <a className="seller-task-card" href="/workspace?tab=Broadcasts&studio=1"><span className="seller-task-icon is-indigo"><Radio size={19}/></span><strong>Open Live Studio</strong><small>Go live now</small></a>
                              <a className="seller-task-card" href="/workspace?tab=Delivery"><span className="seller-task-icon is-ochre"><Truck size={19}/></span><strong>Manage shipping</strong><small>{deliveryQuote(data.myStore) === undefined ? "Add delivery settings" : "Update delivery settings"}</small></a>
                              <a className="seller-task-card" href="/seller/finance?tab=Activation"><span className="seller-task-icon is-terracotta"><FileCheck2 size={19}/></span><strong>Verification</strong><small>{data.myVerification?.status || "Review seller status"}</small></a>
                            </div>
                          </section>
                          <section className="panel">
                            <div className="section-heading">
                              <h2>Recent orders</h2>
                              <button onClick={() => setSellerTab("Orders")}>
                                View all
                              </button>
                            </div>
                            {orderList(data.sellerOrders.slice(0, 4), true)}
                          </section>
                          <p className="dashboard-footnote">Sales figures reflect delivered orders. Settlement records are available in Payments &amp; refunds.</p>
                        </>
                      ) : sellerTab === "Products" ||
                        sellerTab === "Content" ? (
                        <>
                          <div className="section-heading">
                            <h2>
                              {sellerTab === "Content"
                                ? "Product videos"
                                : "Your products"}
                            </h2>
                            {sellerTab === "Products" && <Link className="secondary-button" href="/seller/bulk-upload">Bulk upload</Link>}

                          </div>
                          {sellerTab === "Content" &&
                          !mine.some((p: any) => p.video) ? (
                            <Empty
                              title="No product videos yet"
                              text="Edit a product to upload a video and link it to your listing."
                              action={() => setSellerTab("Products")}
                              label="Manage products"
                            />
                          ) : mine.length ? (
                            <div className="inventory">
                              {mine
                                .filter(
                                  (p: any) =>
                                    sellerTab !== "Content" || p.video,
                                )
                                .map((p: any) => (
                                  <div className="inventory-row" key={p.id}>
                                    <ImageAsset src={p.image} alt={p.name} />
                                    <div>
                                      <strong>{p.name}</strong>
                                      <small>
                                        {p.category} · {p.stock} in stock
                                      </small>
                                    </div>
                                    <strong>{money(p.price)}</strong>
                                    <button
                                      onClick={() =>
                                        setModal({ type: "productForm", p })
                                      }
                                    >
                                      Edit
                                    </button>
                                    <button
                                      className="danger-link"
                                      onClick={() =>
                                        setModal({ type: "archive", p })
                                      }
                                    >
                                      Archive
                                    </button>
                                  </div>
                                ))}
                            </div>
                          ) : (
                            <Empty
                              title="Your first product starts here"
                              text="Upload a photo, set a price and add stock. Customers can then place real orders."
                              action={() => setModal({ type: "productForm" })}
                              label="List a product"
                            />
                          )}
                        </>
                      ) : sellerTab === "Orders" ? (
                        orderList(data.sellerOrders, true)
                      ) : sellerTab === "Ads" ? (
                        <>
                          <div className="section-heading">
                            <h2>Ad campaigns</h2>
                            <button
                              className="primary"
                              onClick={() => setModal({ type: "campaign" })}
                            >
                              Create draft
                            </button>
                          </div>
                          <div className="notice">
                            Save your campaign plan here. Paid delivery and ad
                            billing are not active; drafts do not run or spend
                            money.
                          </div>
                          {data.campaigns.map((c: any) => (
                            <div className="panel campaign" key={c.id}>
                              <div>
                                <h3>{c.title}</h3>
                                <p>
                                  {c.goal} · {c.location} · {c.days} days
                                </p>
                              </div>
                              <strong>
                                {money(c.budget)}/day · {c.placement} ·{" "}
                                {c.payment_status}
                              </strong>
                              <span className="status">Draft</span>
                            </div>
                          ))}
                        </>
                      ) : (
                        <section className="panel store-settings">
                          <span className="eyebrow">YOUR STOREFRONT</span>
                          <h2 className="seller-identity"><span className="seller-name-text">{data.myStore.name}</span><VerifiedSellerBadge verified={data.myStore.verified} variant="full"/></h2>
                          <p>{data.myStore.description}</p>
                          <p>
                            <MapPin size={17} />
                            {data.myStore.location} · {data.myStore.category}
                          </p>
                          <p>{data.myStore.phone}</p>
                          <button
                            className="primary"
                            onClick={() =>
                              setModal({
                                type: "storeForm",
                                store: data.myStore,
                              })
                            }
                          >
                            Edit store
                          </button>
                          <button
                            className="secondary-button"
                            onClick={() =>
                              setModal({ type: "store", store: data.myStore })
                            }
                          >
                            View storefront
                          </button>
                          <p>
                            Shipping fee:{" "}
                            {deliveryFee(data.myStore) === undefined
                              ? "Not set"
                              : money(deliveryFee(data.myStore)!)}{" "}
                            per order
                          </p>
                          <a
                            className="secondary-button"
                            href="/workspace?tab=Delivery"
                          >
                            Set shipping fee
                          </a>
                          <div className="notice">
                            Verification:{" "}
                            {data.myVerification?.status || "Not submitted"}.{" "}
                            <a href="/workspace">
                              Submit documents and manage delivery, broadcasts
                              and support
                            </a>
                          </div>
                        </section>
                      )}
                    </section>
                  </div>
                </>
              )}
            </>
          ) : view === "Orders" ? (
            <>
              <div className="page-heading">
                <div>
                  <p className="eyebrow">YOUR PURCHASES</p>
                  <h1>My orders</h1>
                  <p>Follow every purchase from confirmation to delivery.</p>
                </div>
              </div>
              {orderList(data.orders)}
            </>
          ) : (
            <>
              {view === "Home" ? (
                <ShoppingHero
                  liveCount={data.streams.filter((stream: any) => stream.status === "live").length}
                  onLive={() => nav("Live")}
                  onShop={() => nav("Market")}
                />
              ) : (
                <>
                  {" "}
                  <div className={`page-heading${view === "Market" ? " marketplace-page-heading" : ""}`}>
                    <div>
                      <p className="eyebrow">
                        {view === "Live"
                          ? "REAL-TIME DISCOVERY"
                          : view === "Market"
                            ? "THE " + brand.name + " MARKET"
                            : "MADE FOR YOUR NEXT DISCOVERY"}
                      </p>
                      <h1>
                        {view === "Live"
                          ? "Meet your next find. Live."
                          : view === "Market"
                            ? "Shop the marketplace."
                            : view === "Explore"
                              ? "Find your kind of business."
                              : "Discover something good."}
                      </h1>
                      <p>
                        {view === "Live"
                          ? "Watch product demonstrations, ask sellers questions and shop while they’re live."
                          : view === "Market"
                            ? "Products and businesses, all in one place."
                            : "Fresh products, local businesses and a closer way to shop."}
                      </p>
                    </div>
                  </div>
                  {view === "Live" && <section className="buyer-live-intro" aria-label="Watch live shopping">
                    <div className="buyer-live-pulse" aria-hidden="true"><Radio size={22}/></div>
                    <div><p className="eyebrow">LIVE SHOPPING</p><h2>Watch sellers show you the details.</h2><p>Join an active broadcast, browse upcoming sessions or catch a replay. You can watch and shop with a buyer account.</p></div>
                    <div className="buyer-live-actions"><button className="secondary-button" onClick={() => nav("Market")}>Shop products</button><a href="/start-selling">Have a business? Start selling</a></div>
                  </section>}
                  {view === "Market" && <section className="marketplace-welcome-banner" aria-label="Marketplace introduction">
                    <div className="marketplace-banner-copy"><p className="eyebrow">DISCOVER THE MARKETPLACE</p><h2>Good finds, from businesses across Nigeria.</h2><p>Browse products, compare options and shop directly from local sellers.</p></div>
                    <div className="marketplace-banner-actions"><button className="marketplace-live-link" onClick={() => nav("Live")}><Radio size={17}/> Watch live</button><button className="marketplace-sellers-link" onClick={() => nav("Explore")}><Store size={17}/> Explore sellers <ChevronRight size={16}/></button></div>
                    <div className="marketplace-banner-meta"><span><ShoppingBag size={16}/>{catalogue.total} products</span><span><Radio size={16}/>{data.streams.filter((stream: any) => stream.status === "live").length} live now</span></div>
                  </section>}
                </>
              )}
          {view === "Home" && !loading && !error && (
            <ShopCategories
              products={products}
              onSelect={(label, stored, term) => {
                nav("Market");
                setCategory(stored);
                setQuery(term);
              }}
            />
          )}
          {view === "Market" && (
            <>
              <section className="mobile-shop-intro" aria-label="Shop introduction">
                <h1>Find something good.</h1>
                <p>Shop from trusted sellers near you.</p>
              </section>
              <div className="mobile-shop-categories">
                <ShopCategories
                  products={[...data.products, ...products]}
                  mobileVariant
                  onSelect={(_label, stored, term) => {
                    setCategory(stored);
                    setQuery(term);
                    setPage(1);
                  }}
                />
              </div>
              <section className="mobile-popular-sellers" aria-label="Popular sellers near you">
                <div className="section-heading">
                  <div><h2>Popular near you</h2><p>Shops the community loves</p></div>
                  <button type="button" onClick={() => nav("Explore")}>See all <ChevronRight size={15}/></button>
                </div>
                {stores.length ? (
                  <div className="mobile-seller-list">
                    {stores.slice(0, 8).map((store: any) => (
                      <a className="mobile-seller" key={store.id} href={`/store/${store.slug || store.id}`}>
                        <span className="mobile-seller-avatar">{(store.name || "S").slice(0, 1).toUpperCase()}</span>
                        <strong>{store.name}</strong>
                        <small>{store.category || store.location || "Seller"}</small>
                      </a>
                    ))}
                  </div>
                ) : (
                  <p className="mobile-sellers-empty">Local seller storefronts will appear here as they join Cash N Carry.</p>
                )}
              </section>
            </>
          )}

              {view === "Home" && (
                <div className="feed-tabs">
                  {["For You", "Following"].map((t) => (
                    <button
                      className={tab === t ? "selected" : ""}
                      key={t}
                      onClick={() => {
                        setTab(t);
                        if (t === "LIVE") nav("Live");
                      }}
                    >
                      {t === "LIVE" && <Radio size={15} />} {t}
                    </button>
                  ))}
                </div>
              )}
              {view === "Live" && (
                <div className="feed-tabs" aria-label="Broadcast discovery">
                  <button
                    className={tab !== "Following" ? "selected" : ""}
                    onClick={() => setTab("For You")}
                  >
                    All broadcasts
                  </button>
                  <button
                    className={tab === "Following" ? "selected" : ""}
                    onClick={() => setTab("Following")}
                  >
                    Following
                  </button>
                </div>
              )}
              <div className={`browse-toolbar${view === "Market" ? " marketplace-browse-toolbar" : ""}`}>
                <button className="secondary-button" onClick={openFilters}>
                  <SlidersHorizontal size={17} /> Filters
                  {category !== "All" || location ? " · active" : ""}
                </button>
                <span>
                  {location
                    ? (locationMode === "delivers"
                        ? "Delivers to "
                        : "Sellers in ") + location
                    : "Discover across Nigeria"}
                </span>
                <button onClick={() => nav("Explore")}>Discover sellers</button>
              </div>
              <div className={`category-bar${view === "Home" ? " home-category-strip" : ""}${view === "Market" ? " marketplace-category-bar" : ""}`}>
                {categories.map((c, i) => {
                  const I = icons[i] || ShoppingBag;
                  return (
                    <button
                      key={c}
                      className={category === c ? "selected" : ""}
                      onClick={() => setCategory(c)}
                    >
                      <I size={17} />
                      {c}
                    </button>
                  );
                })}
              </div>
              {view === "Explore" ? (
                <>
                  <div className="section-heading">
                    <h2>Browse by interest</h2>
                    <span>Find your next favourite</span>
                  </div>
                  <div className="category-grid">
                    {categories.slice(1).map((c, i) => {
                      const I = icons[i + 1] || ShoppingBag;
                      return (
                        <button
                          key={c}
                          onClick={() => {
                            setView("Market");
                            setCategory(c);
                          }}
                          className={"category-tile cat-" + i}
                        >
                          <I size={38} />
                          <strong>{c}</strong>
                          <span>
                            Explore {c.toLowerCase()} <ChevronRight size={16} />
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  <div className="section-heading">
                    <h2>Business storefronts</h2>
                    <span>{stores.length} stores</span>
                  </div>
                  {stores.length ? (
                    <div className="stores-grid">
                      {stores.map((s: any) => (
                        <button
                          className="store-card panel"
                          key={s.id}
                          onClick={() => setModal({ type: "store", store: s })}
                        >
                          <span className="store-avatar">{s.name[0]}</span>
                          <h3 className="seller-identity"><span className="seller-name-text">{s.name}</span><VerifiedSellerBadge verified={s.verified}/></h3>
                          <p>
                            {s.category} · {s.location}
                          </p>
                          <span>
                            Visit store <ChevronRight size={15} />
                          </span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <Empty
                      icon={Store}
                      title={
                        location || query || category !== "All"
                          ? "No matching businesses"
                          : "Room for your business"
                      }
                      text={
                        location || query || category !== "All"
                          ? "Try another location or clear your filters."
                          : "Be one of the first businesses on " +
                            brand.name +
                            "."
                      }
                      action={() =>
                        location || query || category !== "All"
                          ? (setLocation(""), setQuery(""), setCategory("All"))
                          : signed("seller") && nav("Seller")
                      }
                      label={
                        location || query || category !== "All"
                          ? "Clear filters"
                          : "Open a store"
                      }
                    />
                  )}
                </>
              ) : (
                <>
                  {view !== "Market" &&
                    ((view === "Home"
                      ? liveStreams.filter((s: any) =>
                          ["live", "external"].includes(s.status),
                        )
                      : liveStreams
                    ).length > 0 ? (
                      <section>
                        <div className="section-heading">
                          <h2>
                            <span className="red-dot" />
                            {view === "Home" ? "Live now" : "Watch broadcasts"}
                          </h2>
                          <span>{broadcastSummary(liveStreams)}</span>
                        </div>
                        <div className="live-grid">
                          {(view === "Home"
                            ? liveStreams.filter((s: any) =>
                                ["live", "external"].includes(s.status),
                              )
                            : liveStreams
                          ).map((s: any) => {
                            const p = [
                              ...data.products,
                              ...(data.pinnedProducts || []),
                              ...catalogue.products,
                              ...(catalogue.featured || []),
                              ...(data.myProducts || []),
                            ].find((p: any) => p.id === s.product);
                            return (
                              <button
                                className="live-card"
                                key={s.id}
                                onClick={() =>
                                  setModal({ type: "live", stream: s })
                                }
                              >
                                {p ? (
                                  <ImageAsset src={p.image} alt={p.name} />
                                ) : (
                                  <div className="live-placeholder">
                                    <Radio size={50} />
                                  </div>
                                )}
                                <span className="live-badge">
                                  {broadcastLabel(s)}
                                </span>
                                <span className="play-circle">
                                  <Play fill="currentColor" size={21} />
                                </span>
                                <div>
                                  <small>{s.seller}<VerifiedSellerBadge verified={s.verified}/></small>
                                  <h3>{s.title}</h3>
                                  {s.status === "scheduled" && (
                                    <ScheduleInfo scheduled={s.scheduled} />
                                  )}
                                  <span>
                                    {s.status === "scheduled"
                                      ? "Scheduled broadcast"
                                      : s.status === "ended"
                                        ? s.replay
                                          ? "Watch replay"
                                          : "Session ended"
                                        : s.provider === "tiktok"
                                          ? "Watch on TikTok"
                                          : p
                                            ? money(p.price)
                                            : "Join the conversation"}
                                  </span>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </section>
                    ) : view === "Live" ? (
                      <Empty
                        icon={Radio}
                        headingLevel={2}
                        title="No broadcasts available"
                        text="There are no live streams, scheduled sessions or replays matching your filters."
                        action={() => nav("Market")}
                        label="Browse products"
                      />
                    ) : (
                      <section className="live-empty">
                        <div className="section-heading">
                          <h2>Live now</h2>
                        </div>
                        <div className="live-empty-body">
                          <Radio size={28} />
                          <div>
                            <h3>No sellers are live right now</h3>
                            <p>
                              Browse scheduled sessions and replays, or explore
                              products while you wait.
                            </p>
                          </div>
                          <button
                            className="secondary-button"
                            onClick={() => nav("Live")}
                          >
                            Browse broadcasts
                          </button>
                        </div>
                      </section>
                    ))}
                  {view !== "Live" && (
                    <>
                      <div className="section-heading">
                        <h2>
                          {view === "Market" ? (
                            <>
                              <span className="desktop-market-products-heading">All products</span>
                              <span className="mobile-market-products-heading">{query || category !== "All" ? "Search results" : "Picked for you"}</span>
                            </>
                          ) : tab === "Following" && view === "Home"
                            ? "From stores you follow"
                            : "Discover local favourites"}
                        </h2>
                        <span>
                          {catalogue.total}{" "}
                          {catalogue.total === 1 ? "product" : "products"}{" "}
                          <SlidersHorizontal size={15} />
                        </span>
                      </div>
                      {catalogueLoading && !catalogue.products.length ? (
                        <div className="product-grid catalogue-skeleton" role="status" aria-label="Loading products">{Array.from({length:4},(_,i)=><div className="product-skeleton" key={i}/>)}</div>
                      ) : catalogueError ? (
                        <div role="alert">
                          <p>{catalogueError}</p>
                          <button
                            onClick={() => setCatalogueVersion((v) => v + 1)}
                          >
                            Retry products
                          </button>
                        </div>
                      ) : products.length ? (
                        <div className={`product-grid${view === "Home" ? " home-product-grid" : ""}`}>
                          {homeProducts.map((p: any) => renderProduct(p))}
                        </div>
                      ) : (
                        <Empty
                          title={
                            query || location || category !== "All"
                              ? "No matching products"
                              : tab === "Following"
                                ? "Your favourite stores, right here"
                              : view === "Market" ? "No products available yet" : "No products to show yet"
                          }
                          text={
                            query || location || category !== "All"
                              ? "Try a different location, search or category."
                              : tab === "Following"
                                ? "Explore businesses and follow a store to see its products."
                              : view === "Market" ? "New products from Nigerian sellers will appear here as they become available. Check back soon." : "Browse businesses and explore products from sellers across Nigeria."
                          }
                          action={() =>
                            query || location || category !== "All"
                              ? (setQuery(""),
                                setCategory("All"),
                                setLocation(""))
                              : tab === "Following"
                                ? nav("Explore")
                                : nav("Explore")
                          }
                          label={
                            query || location || category !== "All"
                              ? "Clear filters"
                              : "Explore stores"
                          }
                        />
                      )}
                      {view === "Home" && products.length > homeProducts.length && (
                        <div className="home-product-more">
                          <button className="secondary-button" onClick={() => nav("Market")}>
                            Browse all products
                          </button>
                        </div>
                      )}
                    </>
                  )}
                </>
              )}
            </>
          )}
          {view === "Home" &&
            !catalogueLoading &&
            !catalogueError &&
            catalogue.featured?.length > 0 && (
              <section className="home-featured-products">
                <h2>Featured products</h2>
                <div className="product-grid">
                  {catalogue.featured.slice(0, 2).map((p: any) => renderProduct(p))}
                </div>
              </section>
            )}
          {view === "Home" && !catalogueLoading && !catalogueError && (() => {
            const shoppableVideos = (catalogue.products || []).filter((p: any) => p.video && p.video_status !== "removed").slice(0, 4);
            if (!shoppableVideos.length) return null;
            return <section className="shoppable-video-shelf" aria-labelledby="shoppable-videos-title">
              <div className="section-heading"><div><p className="eyebrow">Watch · discover · shop</p><h2 id="shoppable-videos-title">Shop through product videos</h2></div><button onClick={() => nav("Market")}>Browse products <ChevronRight size={16} /></button></div>
              <div className="shoppable-video-grid">{shoppableVideos.map((p: any) => {
                const variants: any[] = JSON.parse(p.variants || "[]");
                const available = variants.length ? variants.some((v) => v.stock > 0) : p.stock > 0;
                return <article key={p.id} className="shoppable-video-card">
                  <a className="shoppable-video-player" href={`/product/${p.id}`} aria-label={`View ${p.name}`}>
                    <video src={p.video} controls playsInline preload="none" aria-label={`${p.name} product video`} />
                  </a>
                  <div className="shoppable-video-copy"><a href={`/product/${p.id}`}><strong>{p.name}</strong></a><span>{money(p.price)} · {p.seller}<VerifiedSellerBadge verified={p.verified}/></span></div>
                  <div className="product-card-actions"><button className="product-card-buy" disabled={busy || !available} onClick={() => variants.length ? setModal({ type: "product", p }) : buyNow(p)}>Buy now</button><button className="product-card-add" disabled={busy || !available} onClick={() => add(p)}><Plus size={16} /> Add to cart</button></div>
                </article>;
              })}</div>
            </section>;
          })()}
          {view === "Home" && !loading && stores.length > 0 && (
            <section className="home-sellers" aria-label="Discover sellers">
              <div className="section-heading"><h2>Meet the sellers</h2><button onClick={() => nav("Explore")}>View all sellers <ChevronRight size={16} /></button></div>
              <div className="home-seller-list">{stores.slice(0, 4).map((store: any) => <a key={store.id} className="home-seller-card" href={"/store/" + store.id}><span className="store-avatar">{store.name[0]}</span><div><h3>{store.name}<VerifiedSellerBadge verified={store.verified}/></h3><p>{store.category} · {store.location}</p></div><ChevronRight size={18} aria-hidden="true" /></a>)}</div>
            </section>
          )}
          {view === "Market" && (
            <section className="shop-discovery-sections" aria-label="Seller storefront discovery">
              <div className="section-heading">
                <div><p className="eyebrow">Find your next favourite</p><h2>Seller storefronts</h2></div>
                <button onClick={() => nav("Explore")}>Explore all sellers <ChevronRight size={16} /></button>
              </div>
              {stores.length ? (
                <div className="home-seller-list">
                  {stores.slice(0, 6).map((store: any) => (
                    <a key={store.id} className="home-seller-card" href={`/store/${store.slug || store.id}`}>
                      <span className="store-avatar">{store.name?.[0] || "S"}</span>
                      <div><h3>{store.name}<VerifiedSellerBadge verified={store.verified} /></h3><p>{store.category} · {store.location}</p></div>
                      <ChevronRight size={18} aria-hidden="true" />
                    </a>
                  ))}
                </div>
              ) : <p>Seller storefronts will appear here as sellers join Cash N Carry.</p>}
            </section>
          )}
          {data.sponsored?.length > 0 && (
            <section>
              <h2>Sponsored</h2>
              <div className="product-grid">
                {data.sponsored
                  .filter(
                    (c: any) =>
                      c.placement ===
                      (view === "Market" ? "market" : "discovery"),
                  )
                  .map((c: any) => (
                    <a
                      key={c.id}
                      href={"/product/" + c.product}
                      onClick={() =>
                        fetch("/api/ads-events", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({
                            campaign: c.id,
                            kind: "click",
                          }),
                          keepalive: true,
                        }).catch(() => {})
                      }
                    >
                      <ImageAsset src={c.image} alt={c.name} width="160" />
                      <small>Sponsored</small>
                      <h3>{c.name}</h3>
                      <p>
                        {money(c.price)} · {c.seller}<VerifiedSellerBadge verified={c.verified}/>
                      </p>
                    </a>
                  ))}
              </div>
            </section>
          )}
          {["Home", "Market"].includes(view) && (
            <>
              <div className="market-controls">
                <label>
                  Sort products{" "}
                  <select
                    value={sort}
                    onChange={(e) => {
                      setSort(e.target.value);
                      setPage(1);
                    }}
                  >
                    <option value="newest">Newest</option>
                    <option value="low">Price: low to high</option>
                    <option value="high">Price: high to low</option>
                    <option value="name">Name</option>
                  </select>
                </label>
                {catalogue.pages > 1 && (
                  <>
                    <button
                      disabled={catalogueLoading || page <= 1}
                      onClick={() => setPage((p) => p - 1)}
                    >
                      Previous
                    </button>
                    <span>
                      Page {page} of {catalogue.pages}
                    </span>
                    <button
                      disabled={catalogueLoading || page >= catalogue.pages}
                      onClick={() => setPage((p) => p + 1)}
                    >
                      Next
                    </button>
                  </>
                )}
              </div>
            </>
          )}
          {view === "Home" && <VideoDiscovery />}
          {view === "Home" && <ShoppingGuide onShop={() => nav("Market")} onLive={() => nav("Live")} />}
          {view === "Home" ? <HomeFooter onShop={() => nav("Market")} onLive={() => nav("Live")} /> : <footer><BrandLogo tagline /><span><a href="/help">Help &amp; contact</a> · <a href="/privacy">Privacy</a> · <a href="/terms">Terms</a> · <a href="/delivery">Delivery</a> · <a href="/refunds">Returns and refunds</a> · <a href="/seller-terms">Seller Terms</a> · <a href="/community-guidelines">Community Guidelines</a></span></footer>}
        </main>
      </div>
      <nav className="mobile-nav" aria-label="Customer navigation">
        {[
          [Home, "Home"],
          [ShoppingBag, "Shop"],
          [Radio, "Live"],
          [ShoppingCart, "Bag"],
          [Users, "Account"],
        ].map(([I, l]: any) => (
          <button
            className={
              view === (l === "Shop" ? "Market" : l) || (l === "Bag" && modal?.type === "cart") ||
              (l === "Account" && modal?.type === "account")
                ? "active"
                : ""
            }
            key={l}
            aria-current={view === (l === "Shop" ? "Market" : l) ? "page" : (l === "Bag" && modal?.type === "cart") ? "page" : undefined}
            aria-label={l === "Bag" && data.cart.length > 0 ? `Bag, ${data.cart.reduce((sum: number, item: any) => sum + item.quantity, 0)} items` : l}
            onClick={() =>
              l === "Account"
                ? window.location.assign("/account")
                : l === "Live" && data.myStore && data.sellerAccess?.canSell
                  ? window.location.assign("/workspace?tab=Broadcasts&studio=1")
                : l === "Bag"
                  ? signed("cart") && setModal({ type: "cart" })
                : nav(l === "Shop" ? "Market" : l)
            }
          >
            <I size={22} aria-hidden="true" />
            <span>{l}</span>
            {l === "Bag" && data.cart.length > 0 && <b className="mobile-cart-count">{data.cart.reduce((sum: number, item: any) => sum + item.quantity, 0)}</b>}
          </button>
        ))}
      </nav>
      {toast && (
        <div
          className={"toast " + toastKind}
          role={toastKind === "error" ? "alert" : "status"}
        >
          {toastKind === "error" ? (
            <AlertCircle size={18} />
          ) : (
            <Check size={18} />
          )}
          {toast}
        </div>
      )}
      {modal && (
        <div
          className="modal-backdrop"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setModal(null);
          }}
        >
          <section
            className={
              "modal modal--" +
              modal.type +
              " " +
              (modal.type === "live"
                ? "live-modal"
                : modal.type === "filters"
                  ? "filter-sheet"
                  : "")
            }
            role="dialog"
            aria-modal="true"
            aria-label={modal.type}
          >
            <button
              className="modal-close"
              aria-label="Close dialog"
              onClick={() => setModal(null)}
            >
              <X size={22} />
            </button>
            {modal.type === "notifications" ? (
              <Suspense fallback={<p className="muted" role="status">Loading notifications…</p>}><NotificationPanel items={data.notifications || []} busy={busy} markRead={() => act({action:"read-notifications"}, "Notifications marked as read")} /></Suspense>
            ) : modal.type === "filters" ? (
              <>
                <p className="eyebrow">FIND YOUR NEXT DISCOVERY</p>
                <h2>Search &amp; filters</h2>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setLocation(filterDraft.location.trim());
                    setLocationMode(filterDraft.mode);
                    setCategory(filterDraft.category);
                    setSort(filterDraft.sort);
                    setRadius(filterDraft.radius);
                    setDeviceLocation(filterDraft.deviceLocation);
                    setPage(1);
                    setModal(null);
                  }}
                >
                  <label className="field">
                    Match location
                    <select
                      value={filterDraft.mode}
                      onChange={(e) =>
                        setFilterDraft({ ...filterDraft, mode: e.target.value })
                      }
                    >
                      <option value="located">Seller located here</option>
                      <option value="delivers">Delivers here</option>
                    </select>
                  </label>
                  <label className="field">
                    Nigerian state, city or area
                    <input
                      value={filterDraft.location}
                      placeholder="Try Lagos or Lekki"
                      onChange={(e) =>
                        setFilterDraft({
                          ...filterDraft,
                          location: e.target.value,
                        })
                      }
                      list="filter-locations"
                    />
                  </label>
                  <datalist id="filter-locations">
                    {Array.from(
                      new Set(data.stores.map((s: any) => s.location)),
                    ).map((l: any) => (
                      <option key={l} value={l} />
                    ))}
                  </datalist>
                  <label className="field">
                    Category
                    <select
                      value={filterDraft.category}
                      onChange={(e) =>
                        setFilterDraft({
                          ...filterDraft,
                          category: e.target.value,
                        })
                      }
                    >
                      {categories.map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    Sort products
                    <select
                      value={filterDraft.sort}
                      onChange={(e) =>
                        setFilterDraft({ ...filterDraft, sort: e.target.value })
                      }
                    >
                      <option value="newest">Newest</option>
                      <option value="low">Price: low to high</option>
                      <option value="high">Price: high to low</option>
                      <option value="name">Name</option>
                    </select>
                  </label>
                  <button
                    type="button"
                    className="secondary-button"
                    onClick={() => {
                      requestDeviceLocation();
                      setModal(null);
                    }}
                  >
                    Use device location
                  </button>
                  <p className="secondary">
                    Optional. Distance results include only sellers with
                    reliable public business coordinates.
                  </p>
                  {filterDraft.deviceLocation && (
                    <label className="field">
                      Distance
                      <select
                        value={filterDraft.radius}
                        onChange={(e) =>
                          setFilterDraft({
                            ...filterDraft,
                            radius: Number(e.target.value),
                          })
                        }
                      >
                        {[5, 10, 25, 50, 100].map((n) => (
                          <option key={n} value={n}>
                            {n} km
                          </option>
                        ))}
                      </select>
                    </label>
                  )}
                  <div className="filter-actions">
                    <button
                      type="button"
                      className="secondary-button"
                      onClick={() => {
                        setFilterDraft({
                          location: "",
                          mode: "delivers",
                          category: "All",
                          sort: "newest",
                          radius: 25,
                          deviceLocation: null,
                        });
                      }}
                    >
                      Clear
                    </button>
                    <button type="submit" className="primary">
                      Apply filters
                    </button>
                  </div>
                </form>
              </>
            ) : modal.type === "cancelOrder" ? (
              <>
                <h2>Cancel this order?</h2>
                <p>
                  {modal.order.payment === "flutterwave"
                    ? "We’ll verify your debit card payment before cancelling. If the payment outcome is not confirmed, your order stays pending and stock remains reserved. A paid order requires a refund."
                    : "You can cancel before the seller confirms it. Reserved stock will be returned to the store."}
                </p>
                <Button
                  busy={busy}
                  className="primary full"
                  onClick={async () => {
                    if (
                      await act(
                        { action: "cancel", id: modal.order.id },
                        "Order cancelled",
                      )
                    )
                      setModal(null);
                  }}
                >
                  Cancel order
                </Button>
                <button
                  className="secondary-button full"
                  onClick={() => setModal(null)}
                >
                  Keep order
                </button>
              </>
            ) : modal.type === "storeForm" ? (
              <>
                <h2>{modal.store ? "Edit your store" : "Open your store"}</h2>
                <p>Make it easy for customers to get to know your business.</p>
                <form onSubmit={(e) => form(e, "store")}>
                  <Field
                    label="Business name"
                    name="name"
                    value={modal.store?.name}
                  />
                  <label className="field">
                    About your business
                    <textarea
                      name="description"
                      defaultValue={modal.store?.description}
                      maxLength={1000}
                    />
                  </label>
                  <div className="form-row">
                    <label className="field">
                      Category
                      <select
                        name="category"
                        defaultValue={modal.store?.category || "Fashion"}
                      >
                        {categories.slice(1).map((c) => (
                          <option key={c}>{c}</option>
                        ))}
                      </select>
                    </label>
                    <Field
                      label="City / location"
                      name="location"
                      value={modal.store?.location}
                      placeholder="Lekki, Lagos, Nigeria"
                    />
                  </div>
                  <Field
                    label="Customer contact phone"
                    name="phone"
                    type="tel"
                    value={modal.store?.phone}
                  />
                  <Button
                    busy={busy}
                    className="primary full"
                  >
                    {busy ? "Saving…" : "Save storefront"}
                  </Button>
                </form>
              </>
            ) : modal.type === "productForm" ? (
              <>
                <h2>{modal.p ? "Edit product" : "List a product"}</h2>
                {uploadProgress !== null && (
                  <p role="status">
                    {uploadProgress < 100
                      ? "Uploading: " + uploadProgress + "%"
                      : "Validating and storing media…"}
                  </p>
                )}
                <form
                  onSubmit={(e) =>
                    form(e, "product", modal.p ? { id: modal.p.id } : {})
                  }
                >
                  <Field
                    label="Product name"
                    name="name"
                    value={modal.p?.name}
                  />
                  <Field label="SKU (optional)" name="sku" value={modal.p?.sku} />
                  <label className="field">
                    Description
                    <textarea
                      name="description"
                      required
                      defaultValue={modal.p?.description}
                    />
                  </label>
                  <div className="form-row">
                    <Field
                      label="Price (₦)"
                      name="price"
                      type="number"
                      min="100"
                      value={modal.p?.price}
                    />
                    <Field
                      label="Available stock"
                      name="stock"
                      type="number"
                      min="0"
                      max="100000"
                      value={modal.p?.stock ?? 1}
                    />
                  </div>
                  <label className="field">
                    Category
                    <select
                      name="category"
                      defaultValue={modal.p?.category || "Fashion"}
                    >
                      {categories.slice(1).map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                  </label>
                  <p className="muted">Your store can list products across different categories.</p>
                  <fieldset className="product-options">
                    <legend>Product photo</legend>
                    <Suspense fallback={<p className="muted" role="status">Loading product tools…</p>}>
                      <ProductPhoto
                        initial={modal.p?.image || ""}
                        name="image"
                        showQuota
                        disabled={busy}
                        onBusy={(value) => {
                          operation.current = value;
                          setBusy(value);
                        }}
                      />
                    </Suspense>
                  </fieldset>
                  <Suspense fallback={<p className="muted" role="status">Loading product options…</p>}>
                    <ProductOptions
                      product={modal.p}
                      disabled={busy}
                      onBusy={(value) => {
                        operation.current = value;
                        setBusy(value);
                      }}
                    />
                  </Suspense>
                  <Field
                    label="Product video URL (optional)"
                    name="video"
                    required={false}
                    value={modal.p?.video}
                  />
                  <label className="upload-label">
                    Upload product video · up to 40 MB
                    <input
                      type="file"
                      accept="video/mp4,video/webm"
                      data-field="video"
                      onChange={upload}
                    />
                  </label>
                  <p className="muted">
                    Video uploads have a separate daily allowance of 20 files or 200 MB per seller. Up to 10 upload attempts per minute.
                  </p>
                  <Button
                    busy={busy}
                    className="primary full"
                  >
                    {busy ? "Saving…" : "Save product"}
                  </Button>
                </form>
              </>
            ) : modal.type === "product" ? (
              <>
                <ImageAsset
                  className="detail-image"
                  src={modal.p.image}
                  alt={modal.p.name}
                />
                <p className="eyebrow">
                  {modal.p.seller}<VerifiedSellerBadge verified={modal.p.verified}/> · {modal.p.category}
                </p>
                <h2>{modal.p.name}</h2>
                {Array.from(new Set<string>(JSON.parse(modal.p.images || "[]"))).filter((url) => url !== modal.p.image).map((url: string) => (
                  <ImageAsset
                    key={url}
                    src={url}
                    alt={modal.p.name}
                    className="detail-image"
                  />
                ))}
                {JSON.parse(modal.p.variants || "[]").length > 0 && (
                  <label className="field">
                    Variant
                    <select
                      value={variant}
                      onChange={(e) => setVariant(e.target.value)}
                    >
                      <option value="">Choose variant</option>
                      {JSON.parse(modal.p.variants).map((v: any) => (
                        <option key={v.name} value={v.name} disabled={!v.stock}>
                          {v.name} · {money(v.price)} · {v.stock} available
                        </option>
                      ))}
                    </select>
                  </label>
                )}
                <strong className="detail-price">
                  {money(
                    JSON.parse(modal.p.variants || "[]").find(
                      (v: any) => v.name === variant,
                    )?.price || modal.p.price,
                  )}
                </strong>
                <p>{modal.p.description}</p>
                <a href={"/product/" + modal.p.id}>Shareable product page</a>
                <p>
                  Delivery: {modal.p.delivery_days || "Confirm with seller"} ·{" "}
                  {deliveryFee(modal.p) === undefined
                    ? "Delivery fee confirmed at checkout"
                    : money(deliveryFee(modal.p)!)}
                </p>
                <details className="product-coverage">
                  <summary>Delivery coverage</summary>
                  <p>Delivers to:{" "}
                  {JSON.parse(
                    data.stores.find((s: any) => s.id === modal.p.store)
                      ?.coverage || "[]",
                  ).join(", ") || "Confirm coverage with seller"}</p>
                </details>
                <ReturnGuidance sellerTerms={modal.p.return_policy} />
                <button
                  className="secondary-button"
                  onClick={() =>
                    act(
                      {
                        action: "favourite",
                        product: modal.p.id,
                        saved: !data.favourites?.some(
                          (f: any) => f.product === modal.p.id,
                        ),
                      },
                      "Saved products updated",
                    )
                  }
                >
                  {data.favourites?.some((f: any) => f.product === modal.p.id)
                    ? "Remove from favourites"
                    : "Save product"}
                </button>
                <p className="secondary">
                  {modal.p.stock
                    ? `${modal.p.stock} available`
                    : "Out of stock"}{" "}
                  · Seller location: {modal.p.location}
                </p>
                {modal.p.video && (
                  <video
                    className="product-video"
                    controls
                    playsInline
                    src={modal.p.video}
                    preload="none"
                  />
                )}
                <div className="product-purchase-actions">
                <Button
                  busy={busy}
                  disabled={
                    busy ||
                    !modal.p.stock ||
                    (JSON.parse(modal.p.variants || "[]").length > 0 &&
                      !JSON.parse(modal.p.variants || "[]").some(
                        (v: any) => v.name === variant && v.stock > 0,
                      ))
                  }
                  className="primary"
                  onClick={() => buyNow(modal.p, variant, 1)}
                >
                  Buy now
                </Button>
                <Button
                  busy={busy}
                  disabled={
                    busy ||
                    !modal.p.stock ||
                    (JSON.parse(modal.p.variants || "[]").length > 0 &&
                      !JSON.parse(modal.p.variants || "[]").some(
                        (v: any) => v.name === variant && v.stock > 0,
                      ))
                  }
                  className="secondary-button"
                  onClick={() => add(modal.p)}
                >
                  <ShoppingCart size={18} />
                  {modal.p.stock ? "Add to cart" : "Sold out"}
                </Button>
                </div>
                <div className="section-heading">
                  <h3>Customer reviews</h3>
                </div>
                {data.reviews
                  .filter((r: any) => r.product === modal.p.id)
                  .map((r: any) => (
                    <div className="review" key={r.id}>
                      <strong>
                        {r.name} · {"★".repeat(r.rating)}
                      </strong>
                      <p>{r.comment}</p>
                      <small>Verified purchase</small>
                    </div>
                  ))}
                {!data.reviews.some((r: any) => r.product === modal.p.id) && (
                  <p className="secondary">
                    No reviews yet. Reviews are available after delivery.
                  </p>
                )}
              </>
            ) : modal.type === "store" ? (
              <>
                <span className="store-avatar">{modal.store.name[0]}</span>
                <h2 className="seller-identity"><span className="seller-name-text">{modal.store.name}</span><VerifiedSellerBadge verified={modal.store.verified} variant="full"/></h2>
                <p>{modal.store.description}</p>
                <p>
                  <MapPin size={16} /> {modal.store.location} ·{" "}
                  {modal.store.category}
                </p>
                <div className="store-actions">
                  <Button
                    busy={busy}
                    className="secondary-button"
                    onClick={() =>
                      act(
                        {
                          action: "follow",
                          store: modal.store.id,
                          follow: !data.follows.some(
                            (f: any) => f.store === modal.store.id,
                          ),
                        },
                        "Follow preference updated",
                      )
                    }
                  >
                    <Heart size={17} />
                    {data.follows.some((f: any) => f.store === modal.store.id)
                      ? "Following"
                      : "Follow store"}
                  </Button>
                  <a
                    className="secondary-button"
                    href={"/messages?store=" + encodeURIComponent(modal.store.id)}
                  >
                    Chat with seller
                  </a>
                </div>
                <div className="product-grid mini">
                  <a
                    className="secondary-button"
                    href={"/store/" + modal.store.id}
                  >
                    View all products in this storefront
                  </a>
                </div>
              </>
            ) : modal.type === "cart" ? (
              <>
                {resumeReturnTo && (
                  <p>
                    <a href={resumeReturnTo}>
                      Return to your selected product or broadcast
                    </a>
                  </p>
                )}
                <header className="cart-dialog-heading">
                  <p className="eyebrow">YOUR BAG</p>
                  <h2>Your shopping bag <span>{data.cart.reduce((sum: number, item: any) => sum + item.quantity, 0)}</span></h2>
                  <p>Review your picks before heading to checkout.</p>
                </header>
                {data.cart.length ? (
                  <>
                    <div className="cart-items">
                      {data.cart.map((p: any) => (
                        <div className="cart-row" key={p.id}>
                          <ImageAsset src={p.image} alt={p.name} />
                          <div>
                            <strong>{p.name}</strong>
                            <small>{p.seller}<VerifiedSellerBadge verified={p.verified}/></small>
                            <span>{money(p.price)}</span>
                          </div>
                          <button
                            className="cart-remove"
                            disabled={busy}
                            onClick={() =>
                              act(
                                { action: "cart", product: p.id, quantity: 0 },
                                "Item removed",
                              )
                            }
                            aria-label={"Remove " + p.name + " from cart"}
                          >
                            <X size={16} />
                          </button>
                          <div className="quantity">
                            <Button
                              busy={busy}
                              onClick={() =>
                                act(
                                  {
                                    action: "cart",
                                    product: p.id,
                                    variant: p.variant,
                                    quantity: p.quantity - 1,
                                  },
                                  "Cart updated",
                                )
                              }
                              aria-label={"Decrease quantity of " + p.name}
                            >
                              −
                            </Button>
                            <span>{p.quantity}</span>
                            <Button
                              busy={busy}
                              onClick={() =>
                                act(
                                  {
                                    action: "cart",
                                    product: p.id,
                                    variant: p.variant,
                                    quantity: p.quantity + 1,
                                  },
                                  "Cart updated",
                                )
                              }
                              aria-label={"Increase quantity of " + p.name}
                            >
                              +
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="cart-order-summary">
                    <div className="cart-total">
                      <span>Subtotal</span>
                      <strong>{money(cartTotal)}</strong>
                    </div>
                    <div className="cart-total">
                      <span>Shipping</span>
                      <strong>
                        {cartFee == null ? "Fee not set" : money(cartFee)}
                      </strong>
                    </div>
                    {cartShipping != null && (
                      <div className="cart-total cart-grand-total">
                        <span>Estimated total</span>
                        <strong>{money(cartTotal + cartShipping)}</strong>
                      </div>
                    )}
                    </div>
                    <p className="secondary">
                      Single-seller checkout. Delivery fees are calculated from
                      the seller’s saved settings. Online payments, when
                      available, run in{" "}
                      {data.payments?.mode === "live" ? "live" : "sandbox"}{" "}
                      mode.
                    </p>
                    <Button
                      busy={busy}
                      className="primary full"
                      onClick={() =>
                        setModal({ type: "checkout", key: clientId() })
                      }
                    >
                      Continue to checkout
                    </Button>
                  </>
                ) : (
                  <Empty
                    title="Your bag is empty"
                    text="Find something you love in the marketplace."
                    action={() => {
                      setModal(null);
                      nav("Market");
                    }}
                    label="Browse products"
                  />
                )}
              </>
            ) : modal.type === "checkout" ? (
              <>
                <p className="eyebrow">SINGLE-SELLER CHECKOUT</p>
                <h2>Where should it go?</h2>
                <form onSubmit={(e) => form(e, "checkout", {
                  key: modal.key,
                  ...(directCheckout
                    ? { product: directCheckout.product.id, variant: directCheckout.variant, quantity: directCheckout.quantity }
                    : {}),
                })}>
                  <Field
                    label="Recipient name"
                    name="name"
                    value={data.user?.name.split("@")[0]}
                  />
                  <Field label="Phone number" name="phone" type="tel" />
                  <label className="field">
                    Delivery state
                    <select name="delivery_state" required>
                      <option value="">Choose state</option>
                      {[
                        "Abia",
                        "Adamawa",
                        "Akwa Ibom",
                        "Anambra",
                        "Bauchi",
                        "Bayelsa",
                        "Benue",
                        "Borno",
                        "Cross River",
                        "Delta",
                        "Ebonyi",
                        "Edo",
                        "Ekiti",
                        "Enugu",
                        "FCT",
                        "Gombe",
                        "Imo",
                        "Jigawa",
                        "Kaduna",
                        "Kano",
                        "Katsina",
                        "Kebbi",
                        "Kogi",
                        "Kwara",
                        "Lagos",
                        "Nasarawa",
                        "Niger",
                        "Ogun",
                        "Ondo",
                        "Osun",
                        "Oyo",
                        "Plateau",
                        "Rivers",
                        "Sokoto",
                        "Taraba",
                        "Yobe",
                        "Zamfara",
                      ].map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    Payment
                    <select name="payment" disabled={!data.payments?.online}>
                      {!data.payments?.online && <option value="">Debit card payment unavailable</option>}
                      {data.payments.online && (
                        <option value="flutterwave">
                          Debit card payment
                          {data.payments?.mode === "live"
                            ? ""
                            : " · SANDBOX TEST"}
                        </option>
                      )}
                    </select>
                  </label>
                  <label className="field">
                    Full delivery address
                    <textarea
                      name="address"
                      required
                      placeholder="Street, area, city, state and postcode"
                    />
                  </label>
                  {directCheckout && (
                    <div className="cart-total">
                      <span>{directCheckout.product.name}{directCheckout.variant ? ` · ${directCheckout.variant}` : ""} · Qty {directCheckout.quantity}</span>
                      <strong>{money(checkoutProductTotal)}</strong>
                    </div>
                  )}
                  <div className="cart-total">
                    <span>Product total</span>
                    <strong>{money(checkoutProductTotal)}</strong>
                  </div>
                  <div className="cart-total">
                    <span>Total including delivery</span>
                    <strong>
                      {checkoutDeliveryFee === undefined ? "Delivery fee not set" : money(checkoutProductTotal + checkoutDeliveryFee)}
                    </strong>
                  </div>
                  <div className="notice">
                    Checkout supports one seller at a time. Delivery fee:{" "}
                    {checkoutDeliveryFee === undefined ? "Fee not set" : money(checkoutDeliveryFee)}
                    . {checkoutDelivery === undefined && "The seller must set delivery coverage before payment. "}Delivery coverage is checked by the server. Sandbox
                    payments do not charge real money.
                  </div>
                  <nav className="checkout-policy-links" aria-label="Checkout policies">
                    <span>By placing an order, you agree to the <a href="/terms" target="_blank" rel="noopener noreferrer">Terms</a>. See also <a href="/privacy" target="_blank" rel="noopener noreferrer">Privacy</a>, <a href="/delivery" target="_blank" rel="noopener noreferrer">Delivery</a> and <a href="/refunds" target="_blank" rel="noopener noreferrer">Returns and refunds</a>.</span>
                  </nav>
                  {checkoutError && (
                    <div className="error-banner" role="alert">
                      {checkoutError}
                    </div>
                  )}
                  <Button
                    busy={busy}
                    disabled={checkoutDelivery === undefined || !data.payments?.online}
                    className="primary full"
                  >
                    {busy
                      ? "Placing order…"
                      : "Place order · " +
                        (checkoutDelivery === undefined
                          ? "Seller must set delivery coverage"
                          : money(checkoutProductTotal + checkoutDelivery))}
                  </Button>
                </form>
              </>
            ) : modal.type === "live" ? (
              <Suspense fallback={<p className="muted" role="status">Connecting to livestream…</p>}>
                <LiveShopping
                  initial={modal.stream}
                  data={data}
                  act={act}
                  busy={busy}
                  onClose={() => setModal(null)}
                />
              </Suspense>
            ) : modal.type === "campaign" ? (
              <>
                <h2>Submit a promotion for review</h2>
                <p>
                  Discovery placement: ₦1,000/day. Marketplace placement:
                  ₦2,000/day. Content is labelled Sponsored and runs only after
                  approval, payment and the scheduled start.
                </p>
                <form onSubmit={(e) => form(e, "campaign")}>
                  <Field label="Campaign name" name="title" />
                  <label className="field">
                    Promoted product
                    <select name="product" required>
                      <option value="">Choose product</option>
                      {mine.map((p: any) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    Placement
                    <select name="placement">
                      <option value="discovery">Discovery · ₦1,000/day</option>
                      <option value="market">Marketplace · ₦2,000/day</option>
                    </select>
                  </label>
                  <Field label="Starts" name="starts" type="datetime-local" />
                  <Field label="Ends" name="ends" type="datetime-local" />
                  <label className="field">
                    Goal
                    <select name="goal">
                      {[
                        "More sales",
                        "Website visits",
                        "WhatsApp enquiries",
                        "Followers",
                        "Live viewers",
                      ].map((g) => (
                        <option key={g}>{g}</option>
                      ))}
                    </select>
                  </label>
                  <Field
                    label="Target location"
                    name="location"
                    placeholder="Lagos"
                  />
                  <div className="form-row">
                    <Field
                      label="Daily budget (₦)"
                      name="budget"
                      type="number"
                      min="1000"
                    />
                    <Field
                      label="Duration (days)"
                      name="days"
                      type="number"
                      min="1"
                      max="90"
                      value="7"
                    />
                  </div>
                  <div className="notice">
                    Draft only. Your campaign will not run and no payment will
                    be taken.
                  </div>
                  <Button busy={busy} className="primary full">
                    Save draft
                  </Button>
                </form>
              </>
            ) : modal.type === "archive" ? (
              <>
                <h2>Archive {modal.p.name}?</h2>
                <p>
                  This removes the product from discovery and the market.
                  Existing orders remain available.
                </p>
                <Button
                  busy={busy}
                  className="primary"
                  onClick={async () => {
                    if (
                      await act(
                        { action: "archive", id: modal.p.id },
                        "Product archived",
                      )
                    )
                      setModal(null);
                  }}
                >
                  Archive product
                </Button>
              </>
            ) : modal.type === "review" ? (
              <>
                <h2>Review {modal.item.name}</h2>
                <form
                  onSubmit={(e) =>
                    form(e, "review", {
                      product: modal.item.product,
                      order: modal.order.id,
                    })
                  }
                >
                  <label className="field">
                    Rating
                    <select name="rating">
                      {[5, 4, 3, 2, 1].map((n) => (
                        <option key={n} value={n}>
                          {n} stars
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    Your experience
                    <textarea name="comment" required maxLength={1000} />
                  </label>
                  <Button busy={busy} className="primary full">
                    Publish review
                  </Button>
                </form>
              </>
            ) : null}
          </section>
        </div>
      )}
    </div>
  );
}
