import { notFound, redirect } from "next/navigation";
const aliases: Record<string, string> = {
  privacy: "/privacy",
  terms: "/terms",
  delivery: "/delivery",
  returns: "/refunds",
  refunds: "/refunds",
  sellers: "/seller-terms",
  "seller-terms": "/seller-terms",
  community: "/community-guidelines",
  "community-guidelines": "/community-guidelines",
};
export default async function LegacyPolicy({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const destination = aliases[id];
  if (!destination) notFound();
  redirect(destination);
}
