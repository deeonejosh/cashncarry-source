/** Only exact checkout hosts returned by Flutterwave's authenticated API are trusted. */
export function paymentCheckoutUrl(value: unknown, sandbox: boolean): string {
  if (typeof value !== "string") throw Error("Invalid payment checkout URL");
  let url: URL;
  try { url = new URL(value); } catch { throw Error("Invalid payment checkout URL"); }
  const trusted = url.hostname === "checkout.flutterwave.com" ||
    (sandbox && url.hostname === "checkout-v2.dev-flutterwave.com");
  if (url.protocol !== "https:" || !trusted || url.username || url.password || url.port)
    throw Error("Invalid payment checkout URL");
  return url.href;
}
