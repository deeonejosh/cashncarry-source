import { env } from 'cloudflare:workers';
import { flutterwave, paymentMode, paymentReadiness } from './payments';
import { paymentCheckoutUrl } from './payment-checkout-url';
import { sellerActivation } from './seller-activation';
import { queueUserTemplate,flushEmails } from './notifications';
import { getEmailConfig } from './email-config';
export const SELLER_TERMS_VERSION='seller-subscription-recurring-test-2026-10-12';
const q=(sql:string,...args:any[])=>env.DB!.prepare(sql).bind(...args);
const stamp=()=>new Date().toISOString();
const metadataKey=(kind:string,mode:string,store:string)=>`seller_subscription_${kind}_${mode}_${store}`;
async function setSubscriptionMetadata(kind:string,mode:string,store:string,value:string){await q('INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated',metadataKey(kind,mode,store),value,stamp()).run();}
export async function sellerFinanceNotice(store:string,template:any,event:string,title:string,body:string,details:[string,string][],actionUrl='/seller/finance?tab=Subscription') {
 const owner:any=await q('SELECT owner FROM stores WHERE id=?',store).first();if(!owner?.owner)return;
 const now=stamp();
 await q('INSERT INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING','seller-finance:'+event,owner.owner,title,body.slice(0,1200),now).run();
 await queueUserTemplate(owner.owner,event,template,{actionUrl,details});
 if(await getEmailConfig())await flushEmails().catch(()=>{});
}
async function subscriptionNotice(store:string,template:any,event:string,details:[string,string][]) {
 const titles:Record<string,string>={'seller-subscription-activated':'Seller subscription active','seller-subscription-renewed':'Seller subscription renewed','seller-subscription-cancelled':'Automatic renewal cancelled','seller-subscription-payment-failed':'Seller renewal payment failed'};
 const body=details.map(([k,v])=>`${k}: ${v}`).join(' · ');
 await sellerFinanceNotice(store,template,event,titles[template]||'Seller subscription update',body,details);
}
export const minor=(value:any)=>{const n=Number(value);if(!Number.isSafeInteger(n)||n<0||n>10000000000)throw Error('Invalid amount');return n;};
export async function sellerFinanceSettings() {
 const rows:any=await q("SELECT key,value FROM platform_settings WHERE key LIKE 'seller_%'").all();
 const s=Object.fromEntries(rows.results.map((r:any)=>[r.key,r.value]));
 return {priceMinor:Number(s.seller_monthly_minor||200000),priceConfirmed:s.seller_price_confirmed==='1',feeMinor:Number(s.seller_withdrawal_fee_minor||0),releaseDays:Number(s.seller_release_days||7),fundFlow:s.seller_fund_flow||'unconfirmed',liveBilling:false,liveWithdrawals:false,automaticRenewal:true};
}
async function paymentPlan(mode:string,priceMinor:number) {
 const key=`seller_payment_plan_${mode}_${priceMinor}`;
 const saved:any=await q('SELECT value FROM platform_settings WHERE key=?',key).first();if(saved?.value)return String(saved.value);
 const lockKey='seller-plan:'+key,now=Math.floor(Date.now()/1000);
 const lock:any=await q('INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET expires=excluded.expires WHERE expires<=? RETURNING key',lockKey,now+90,now).first();
 if(!lock){for(let i=0;i<8;i++){await new Promise(r=>setTimeout(r,250));const p:any=await q('SELECT value FROM platform_settings WHERE key=?',key).first();if(p?.value)return String(p.value);}throw Error('Monthly plan setup is in progress. Retry this checkout shortly.');}
 try {
  const again:any=await q('SELECT value FROM platform_settings WHERE key=?',key).first();if(again?.value)return String(again.value);
  const name=`Cash N Carry Seller ${priceMinor/100} NGN monthly ${mode}`;
  // Recover a provider-side create whose response was lost before creating another plan.
  try{const plans:any=await flutterwave('payment-plans',undefined,mode);const found=Array.isArray(plans)?plans.find((p:any)=>p.name===name&&Number(p.amount)===priceMinor/100&&String(p.interval).toLowerCase()==='monthly'&&p.status==='active'):null;if(found?.id){await q('INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated',key,String(found.id),stamp()).run();return String(found.id);}}catch{}
  const p:any=await flutterwave('payment-plans',{name,amount:priceMinor/100,currency:'NGN',interval:'monthly'},mode);
  if(!p?.id||Number(p.amount)!==priceMinor/100||String(p.currency||'NGN')!=='NGN'||String(p.interval).toLowerCase()!=='monthly')throw Error('Flutterwave did not confirm the requested monthly plan.');
  await q('INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated',key,String(p.id),stamp()).run();return String(p.id);
 } finally {await q('DELETE FROM rate_limits WHERE key=?',lockKey).run();}
}
export function calendarMonthAfter(start:string) {
 const d=new Date(start), day=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+1);
 const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,last));return d.toISOString();
}
export async function checkoutSellerSubscription(store:any,user:any,body:any) {
 const mode=paymentMode(),config=await sellerFinanceSettings();
 if(mode!=='test')throw Error('Live seller billing is disabled pending owner pricing, merchant and legal approval.');
 if(!paymentReadiness().online)throw Error('Sandbox payment service is not configured.');
 if(body.acceptTerms!==true||body.termsVersion!==SELLER_TERMS_VERSION||body.autoRenewConsent!==true)throw Error('Accept the terms and monthly automatic-renewal authorisation before continuing.');
 if(!/^[a-f0-9-]{36}$/.test(body.id||''))throw Error('Invalid checkout request');
 const previous:any=await q('SELECT * FROM seller_subscription_payments WHERE id=?',body.id).first();
 if(previous&&(previous.owner!==user.userId||previous.store!==store.id||previous.mode!==mode))throw Error('Checkout request does not belong to this seller');
 if(previous?.status==='paid')return {paid:true};
 if(previous?.link)return {link:previous.link,mode};
 if(previous&&previous.amount_minor!==config.priceMinor)throw Error('Plan price changed. Start a new checkout.');
 const leaseKey=`seller-checkout-store:${store.id}:${mode}`,epoch=Math.floor(Date.now()/1000);
 const lease=await q('INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET expires=excluded.expires WHERE expires<=? RETURNING key',leaseKey,epoch+60,epoch).first();
 if(!lease)throw Error('A seller subscription checkout is already being prepared. Wait and retry.');
 try {
  const active:any=await q('SELECT status,paid_until FROM seller_subscriptions WHERE store=? AND mode=?',store.id,mode).first();
  if(active?.status==='active'&&active.paid_until>stamp())throw Error('Your seller access is already paid through '+active.paid_until+'. Manage automatic renewal from this page instead of starting another charge.');
  const existing:any=await q("SELECT link FROM seller_subscription_payments WHERE store=? AND mode=? AND id!=? AND status IN ('pending','failed') AND link!='' ORDER BY created DESC,rowid DESC LIMIT 1",store.id,mode,body.id).first();
  if(existing?.link)return {link:existing.link,mode,reused:true};
  const plan=await paymentPlan(mode,config.priceMinor),consentedAt=stamp();
  await q("INSERT OR IGNORE INTO seller_subscription_payments(id,store,owner,mode,amount_minor,provider_plan,recurring,customer_email,terms_version,created,updated) VALUES(?,?,?,?,?,?,1,?,?,?,?)",body.id,store.id,user.userId,mode,config.priceMinor,plan,user.email,SELLER_TERMS_VERSION,consentedAt,consentedAt).run();
  const latest:any=await q('SELECT link,status FROM seller_subscription_payments WHERE id=?',body.id).first();
  if(latest?.status==='paid')return {paid:true};
  if(latest?.link)return {link:latest.link,mode};
  const result:any=await flutterwave('payments',{tx_ref:body.id,amount:config.priceMinor/100,currency:'NGN',payment_plan:Number(plan),redirect_url:env.SITE_URL+'/seller/billing-return',customer:{email:user.email,name:store.name},customizations:{title:'Cash N Carry Seller — sandbox monthly subscription'}},mode);
  const link=paymentCheckoutUrl(result?.link,mode==='test');
  await q("UPDATE seller_subscription_payments SET link=?,updated=? WHERE id=? AND status IN ('pending','failed')",link,stamp(),body.id).run();
  return {link,mode};
 }finally{await q('DELETE FROM rate_limits WHERE key=?',leaseKey).run();}
}
export async function verifySellerSubscription(transaction:string,reference:string) {
 const p:any=await q('SELECT * FROM seller_subscription_payments WHERE id=?',reference).first();
 if(!p)return null;
 if(!/^\d{1,20}$/.test(transaction))throw Error('Invalid subscription transaction');
 const r:any=await flutterwave('transactions/'+transaction+'/verify',undefined,p.mode),d=r;
 const merchant=p.mode==='live'?env.FLW_MERCHANT_ACCOUNT_ID:env.FLW_TEST_MERCHANT_ACCOUNT_ID;
 if(!d||String(d.id)!==transaction||d.tx_ref!==p.id||d.currency!=='NGN'||Math.round(Number(d.amount)*100)!==p.amount_minor||Number(d.amount)!==p.amount_minor/100||(merchant&&String(d.account_id)!==merchant))throw Error('Subscription payment verification mismatch');
 if(p.status==='paid'){if(p.provider_id!==transaction)throw Error('Different payment for an already paid checkout');return {status:'paid',periodEnd:p.period_end,mode:p.mode};}
 if(d.status!=='successful') {
  // Failed attempts can be retried on the same hosted link; do not grant access.
  if(d.status==='failed'){
   const now=stamp();await env.DB!.batch([
    q("UPDATE seller_subscription_payments SET status='failed',updated=? WHERE id=? AND status!='paid'",now,p.id),
    q("UPDATE seller_subscriptions SET status=CASE WHEN paid_until>? THEN 'active' ELSE 'payment_failed' END,updated=? WHERE store=? AND mode=? AND provider_plan!='' AND cancel_at_end=0",now,now,p.store,p.mode),
   ]);
   await setSubscriptionMetadata('billing',p.mode,p.store,'payment_failed');
   await subscriptionNotice(p.store,'seller-subscription-payment-failed','subscription-payment-failed:'+transaction,[['Payment reference',p.id],['Current paid-through date',(await q('SELECT paid_until FROM seller_subscriptions WHERE store=? AND mode=?',p.store,p.mode).first() as any)?.paid_until||'None'],['Payment mode',p.mode.toUpperCase()]]).catch(()=>{});
  }
  return {status:d.status==='failed'?'failed':'pending',mode:p.mode};
 }
 const key='seller-renewal:'+p.store+':'+p.mode,now=Math.floor(Date.now()/1000);
 const lock=await q('INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET expires=excluded.expires WHERE expires<=? RETURNING key',key,now+60,now).first();
 if(!lock)throw Error('Subscription renewal is being reconciled. Retry shortly.');
 try {
  let providerSubscription='',nextRenewal='';
  if(p.recurring&&p.provider_plan){try{const subs:any=await flutterwave('subscriptions?transaction_id='+encodeURIComponent(transaction),undefined,p.mode),list=Array.isArray(subs)?subs:[];const match=list.find((s:any)=>String(s.plan)===String(p.provider_plan)&&String(s.customer?.customer_email||s.customer?.email||'').toLowerCase()===String(p.customer_email).toLowerCase()&&s.status==='active');if(match?.id){providerSubscription=String(match.id);nextRenewal=String(match.next_due||match.next_due_date||'');}}catch{}}
  const current:any=await q('SELECT paid_until,provider_subscription,provider_plan,cancel_at_end FROM seller_subscriptions WHERE store=? AND mode=?',p.store,p.mode).first();
  if(!providerSubscription&&p.recurring&&current?.provider_subscription&&current.provider_plan===p.provider_plan&&!current.cancel_at_end)providerSubscription=String(current.provider_subscription);
  if(providerSubscription&&!nextRenewal){const savedNext:any=await q('SELECT value FROM platform_settings WHERE key=?',metadataKey('next',p.mode,p.store)).first();nextRenewal=String(savedNext?.value||'');}
  const start=current?.paid_until>stamp()?current.paid_until:stamp(),end=calendarMonthAfter(start);
  const results:any=await env.DB!.batch([
   q("UPDATE seller_subscription_payments SET status='paid',provider_id=?,period_start=?,period_end=?,updated=? WHERE id=? AND status!='paid'",transaction,start,end,stamp(),p.id),
   q("INSERT INTO seller_subscriptions(store,mode,status,paid_until,cancel_at_end,provider_subscription,provider_plan,customer_email,updated) SELECT ?,?,'active',?,0,?,?,?,? WHERE changes()=1 ON CONFLICT(store,mode) DO UPDATE SET status='active',paid_until=excluded.paid_until,cancel_at_end=0,provider_subscription=CASE WHEN excluded.provider_subscription!='' THEN excluded.provider_subscription ELSE seller_subscriptions.provider_subscription END,provider_plan=excluded.provider_plan,customer_email=excluded.customer_email,updated=excluded.updated",p.store,p.mode,end,providerSubscription,p.provider_plan,p.customer_email,stamp()),
  ]);
  if(Number(results[0]?.meta?.changes??results[0]?.changes)!==1){const latest:any=await q('SELECT period_end FROM seller_subscription_payments WHERE id=?',p.id).first();return {status:'paid',periodEnd:latest.period_end,mode:p.mode};}
  await setSubscriptionMetadata('billing',p.mode,p.store,providerSubscription?'active':'provider_confirmation_pending');
  if(providerSubscription&&nextRenewal)await setSubscriptionMetadata('next',p.mode,p.store,nextRenewal);else if(!providerSubscription)await setSubscriptionMetadata('next',p.mode,p.store,'');
  await subscriptionNotice(p.store,current?.paid_until?'seller-subscription-renewed':'seller-subscription-activated','subscription-paid:'+transaction,[['Monthly price',`NGN ${(p.amount_minor/100).toFixed(2)}`],['Paid through',end],['Payment reference',p.id],['Automatic renewal',providerSubscription?'Confirmed by Flutterwave':'Not yet confirmed'],['Mode',p.mode.toUpperCase()]]).catch(()=>{});
  return {status:'paid',periodEnd:end,mode:p.mode,automaticRenewal:Boolean(providerSubscription),nextRenewal:providerSubscription?nextRenewal:''};
 } finally {await q('DELETE FROM rate_limits WHERE key=?',key).run();}
}
export async function reconcileSellerRenewal(transaction:string,reference:string,hint:any={}) {
 if(typeof reference!=='string'||!reference||reference.length>100)return null;
 const existing:any=await q('SELECT * FROM seller_subscription_payments WHERE id=?',reference).first();
 if(existing)return verifySellerSubscription(transaction,reference);
 const mode=paymentMode(),hintEmail=String(hint.customer?.email||hint.customer?.customer_email||'').trim().toLowerCase(),hintPlan=String(hint.payment_plan??hint.plan?.id??hint.plan_id??hint.payment_plan_id??'');
 // Identify a plausible recurring subscriber before contacting Flutterwave.
 // Unrelated merchant webhook events are acknowledged without external calls.
 if(!hintEmail)return null;
 let candidates:any=hintPlan?await q("SELECT * FROM seller_subscriptions WHERE mode=? AND provider_plan=? AND lower(customer_email)=? AND provider_subscription!='' AND cancel_at_end=0 AND status='active'",mode,hintPlan,hintEmail).all():{results:[]};
 if(!candidates.results.length)candidates=await q("SELECT * FROM seller_subscriptions WHERE mode=? AND lower(customer_email)=? AND provider_subscription!='' AND cancel_at_end=0 AND status='active'",mode,hintEmail).all();
 if(candidates.results.length!==1)return null;
 const sub=candidates.results[0];
 if(!/^\d{1,20}$/.test(transaction))throw Error('Invalid recurring charge reference');
 const d:any=await flutterwave('transactions/'+transaction+'/verify');
 if(!d||String(d.id)!==transaction||d.tx_ref!==reference||d.currency!=='NGN'||!['successful','failed'].includes(String(d.status)))throw Error('Recurring transaction verification mismatch');
 const merchant=mode==='live'?env.FLW_MERCHANT_ACCOUNT_ID:env.FLW_TEST_MERCHANT_ACCOUNT_ID;
 if(merchant&&String(d.account_id)!==merchant)throw Error('Recurring charge merchant mismatch');
 const planValue=d.payment_plan??d.plan?.id??d.plan_id??d.payment_plan_id??'';
 const email=String(d.customer?.email||d.customer?.customer_email||'').trim().toLowerCase();
 const amountMinor=Math.round(Number(d.amount)*100);
 const latestPayment:any=await q("SELECT amount_minor FROM seller_subscription_payments WHERE store=? AND mode=? AND status='paid' ORDER BY period_end DESC,created DESC LIMIT 1",sub.store,mode).first();
 if(email!==hintEmail||amountMinor<=0||amountMinor!==Number(latestPayment?.amount_minor))throw Error('Recurring charge does not match the seller\'s authorised subscription');
 const configured:any=await q('SELECT value FROM platform_settings WHERE key=?',`seller_payment_plan_${mode}_${amountMinor}`).first();
 if(!configured||String(configured.value)!==String(sub.provider_plan))throw Error('Recurring amount does not match the seller\'s subscribed plan');
 if(sub.provider_plan&&planValue&&String(planValue)!==String(sub.provider_plan))throw Error('Recurring payment plan does not match the seller subscription');
 const plan=String(sub.provider_plan||planValue);if(!plan)throw Error('Recurring payment has no confirmed plan reference');
 const now=stamp();
 await q("INSERT OR IGNORE INTO seller_subscription_payments(id,store,owner,mode,amount_minor,status,provider_plan,recurring,customer_email,terms_version,created,updated) VALUES(?,?,?,?,?,'pending',?,1,?,?,?,?)",reference,sub.store,(await q('SELECT owner FROM stores WHERE id=?',sub.store).first() as any)?.owner,mode,amountMinor,plan,email,SELLER_TERMS_VERSION,now,now).run();
 return verifySellerSubscription(transaction,reference);
}
export async function recordProviderSubscriptionCancellation(data:any) {
 const plan=String(data?.plan?.id||data?.plan||''),email=String(data?.customer?.customer_email||data?.customer?.email||'').trim().toLowerCase();
 if(!plan||!email)return false;
 const matches:any=await q("SELECT store,mode,paid_until,provider_subscription FROM seller_subscriptions WHERE provider_plan=? AND lower(customer_email)=? AND provider_subscription!='' AND cancel_at_end=0 AND status='active'",plan,email).all();
 if(matches.results.length!==1)return false;
 const sub=matches.results[0],now=stamp();
 await q("UPDATE seller_subscriptions SET cancel_at_end=1,status=CASE WHEN paid_until>? THEN 'active' ELSE 'expired' END,updated=? WHERE store=? AND mode=? AND provider_subscription=?",now,now,sub.store,sub.mode,sub.provider_subscription).run();
 await setSubscriptionMetadata('billing',sub.mode,sub.store,'cancelled');await setSubscriptionMetadata('next',sub.mode,sub.store,'');
 await subscriptionNotice(sub.store,'seller-subscription-cancelled','provider-cancel-notice:'+sub.provider_subscription+':'+now,[['Paid access until',sub.paid_until],['Automatic renewal','Cancelled by Flutterwave'],['Mode',sub.mode.toUpperCase()]]).catch(()=>{});
 return true;
}
export async function cancelSellerAutoRenewal(store:string,mode:string) {
 const sub:any=await q('SELECT * FROM seller_subscriptions WHERE store=? AND mode=?',store,mode).first();
 if(!sub?.provider_plan||!sub.provider_subscription||sub.cancel_at_end)throw Error('There is no confirmed active recurring subscription to cancel.');
 if(sub.cancel_at_end)return {ok:true,paidUntil:sub.paid_until};
 let providerSubscription=String(sub.provider_subscription||'');
 if(!providerSubscription){const list:any=await flutterwave('subscriptions?email='+encodeURIComponent(sub.customer_email)+'&plan='+encodeURIComponent(sub.provider_plan)+'&status=active',undefined,mode);const matches=Array.isArray(list)?list.filter((x:any)=>String(x.plan)===String(sub.provider_plan)&&String(x.customer?.customer_email||x.customer?.email||'').toLowerCase()===String(sub.customer_email).toLowerCase()&&x.status==='active'):[];if(matches.length!==1)throw Error('Flutterwave could not uniquely confirm the subscription to cancel. No local cancellation was recorded; retry or contact support.');providerSubscription=String(matches[0].id);}
 const confirmed:any=await flutterwave('subscriptions/'+encodeURIComponent(providerSubscription)+'/cancel',undefined,mode,'PUT');
 if(confirmed?.id&&String(confirmed.id)!==providerSubscription)throw Error('Flutterwave cancellation response did not match this subscription.');
 if(confirmed?.status&&String(confirmed.status).toLowerCase()==='active')throw Error('Flutterwave still reports this subscription as active. No local cancellation was recorded.');
 const now=stamp();await q('UPDATE seller_subscriptions SET provider_subscription=?,cancel_at_end=1,updated=? WHERE store=? AND mode=? AND provider_plan=? AND cancel_at_end=0',providerSubscription,now,store,mode,sub.provider_plan).run();
 await setSubscriptionMetadata('billing',mode,store,'cancelled');await setSubscriptionMetadata('next',mode,store,'');await subscriptionNotice(store,'seller-subscription-cancelled','subscription-cancelled:'+providerSubscription,[['Paid access until',sub.paid_until],['Automatic renewal','Cancelled with Flutterwave'],['Mode',mode.toUpperCase()]]).catch(()=>{});return {ok:true,paidUntil:sub.paid_until};
}
export async function reactivateSellerAutoRenewal(store:string,mode:string,accepted:boolean,termsVersion:string) {
 if(!accepted||termsVersion!==SELLER_TERMS_VERSION)throw Error('Fresh monthly renewal authorisation is required.');
 const sub:any=await q('SELECT * FROM seller_subscriptions WHERE store=? AND mode=?',store,mode).first();
 if(!sub?.provider_subscription||sub.mode!=='test')throw Error('Start a new subscription checkout to authorise recurring payments again.');
 if(sub.paid_until<=stamp())throw Error('Your paid period has ended. Start a new checkout to restore access and authorise recurring billing.');
 const result:any=await flutterwave('subscriptions/'+encodeURIComponent(sub.provider_subscription)+'/activate',undefined,mode,'PUT');
 if(!result?.id||String(result.id)!==String(sub.provider_subscription)||String(result.status).toLowerCase()!=='active')throw Error('Flutterwave did not confirm reactivation.');
 const now=stamp();await q("UPDATE seller_subscriptions SET status=CASE WHEN paid_until>? THEN 'active' ELSE status END,cancel_at_end=0,updated=? WHERE store=? AND mode=? AND provider_subscription=?",now,now,store,mode,sub.provider_subscription).run();
 await setSubscriptionMetadata('billing',mode,store,'active');await setSubscriptionMetadata('next',mode,store,String(result.next_due||''));await subscriptionNotice(store,'seller-subscription-activated','subscription-reactivated:'+sub.provider_subscription,[['Paid access until',sub.paid_until],['Automatic renewal','Reactivated with Flutterwave'],['Mode',mode.toUpperCase()]]).catch(()=>{});return {ok:true,message:'Automatic renewal was reactivated by Flutterwave.'};
}
export async function earningsSummary(store:string,mode=paymentMode()) {
 const released:any=await q('SELECT COALESCE(SUM(amount_minor),0) AS n FROM seller_released_credits WHERE store=? AND mode=?',store,mode).first();
 const adjustment:any=await q('SELECT COALESCE(SUM(amount_minor),0) AS n FROM seller_adjustments WHERE store=? AND mode=?',store,mode).first();
 const w:any=await q("SELECT COALESCE(SUM(CASE WHEN status NOT IN ('failed','cancelled') THEN amount_minor+fee_minor ELSE 0 END),0) AS committed,COALESCE(SUM(CASE WHEN status='paid' THEN amount_minor ELSE 0 END),0) AS withdrawn,COALESCE(SUM(CASE WHEN status IN ('requested','under_review','processing') THEN amount_minor+fee_minor ELSE 0 END),0) AS reserved FROM seller_withdrawals WHERE store=? AND mode=?",store,mode).first();
 const sales:any=await q("SELECT COALESCE(SUM(CAST(ROUND(p.amount*100) AS INTEGER)),0) AS total FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.store=? AND p.mode=? AND p.status IN ('paid','refunded')",store,mode).first();
 const refunds:any=await q("SELECT COALESCE(SUM(CAST(ROUND(r.amount*100) AS INTEGER)),0) AS total FROM refunds r JOIN payments p ON p.id=r.payment JOIN orders o ON o.id=p.order_id WHERE o.store=? AND p.mode=? AND r.status='completed'",store,mode).first();
 const net=Number(sales.total)-Number(refunds.total),balance=Number(released.n)+Number(adjustment.n)-Number(w.committed);
 return {totalSalesMinor:Number(sales.total),pendingMinor:Math.max(0,net-Number(released.n)),availableMinor:Math.max(0,balance),deficitMinor:Math.max(0,-balance),reservedMinor:Number(w.reserved),withdrawnMinor:Number(w.withdrawn),refundsMinor:Number(refunds.total),adjustmentsMinor:Number(adjustment.n),releasedMinor:Number(released.n),mode};
}
export async function requestWithdrawal(store:any,body:any) {
 const state=await sellerActivation(store.id),mode=paymentMode();
 if(state.verification!=='verified')throw Error('Seller verification is required for withdrawals.');
 if(mode!=='test')throw Error('Live withdrawals are disabled until the marketplace payout model is approved.');
 const config=await sellerFinanceSettings();
 if(config.fundFlow!=='sandbox_platform')throw Error('Withdrawal requests are unavailable until a sandbox fund-flow model is configured.');
 const amount=minor(body.amountMinor);if(amount<10000)throw Error('Sandbox minimum withdrawal is ₦100.');
 if(!/^[a-f0-9-]{36}$/.test(body.id||''))throw Error('Invalid withdrawal request');
 const existing:any=await q('SELECT * FROM seller_withdrawals WHERE id=?',body.id).first();
 if(existing){if(existing.store!==store.id||existing.mode!==mode||existing.amount_minor!==amount||existing.bank!==body.bank)throw Error('Withdrawal request changed');return {id:existing.id,status:existing.status};}
 const bank:any=await q("SELECT * FROM seller_banks WHERE id=? AND store=? AND mode=? AND status='verified'",body.bank,store.id,mode).first();
 if(!bank)throw Error('Choose a bank account resolved by the provider and approved during verification.');
 await q("INSERT INTO seller_withdrawals(id,store,mode,bank,amount_minor,fee_minor,reference,created,updated) VALUES(?,?,?,?,?,?,?,?,?)",body.id,store.id,mode,bank.id,amount,config.feeMinor,'cnc-payout-'+body.id,stamp(),stamp()).run();
 await sellerFinanceNotice(store.id,'seller-withdrawal-requested','withdrawal-requested:'+body.id,'Withdrawal request received',`Your withdrawal request for ${amount/100} NGN is recorded. Funds are reserved during review; this is not confirmation of payment.`,[['Amount',`NGN ${(amount/100).toFixed(2)}`],['Status','Requested'],['Reference',`cnc-payout-${body.id}`]],'/seller/finance?tab=Withdrawals').catch(()=>{});
 return {id:body.id,status:'requested'};
}
export async function reconcileSellerTransfer(id:string) {
 const w:any=await q('SELECT * FROM seller_withdrawals WHERE id=?',id).first();
 if(!w||w.mode!=='test'||w.status!=='processing')throw Error('Only processing sandbox withdrawals can be reconciled.');
 const r:any=await flutterwave(w.provider_id?'transfers/'+encodeURIComponent(w.provider_id):'transfers?reference='+encodeURIComponent(w.reference),undefined,'test');
 const d=Array.isArray(r)?r.find((t:any)=>t.reference===w.reference):r;
 if(!d)throw Error('No provider transfer found; funds remain reserved. Do not resubmit.');
 const bank:any=await q('SELECT * FROM seller_banks WHERE id=?',w.bank).first();
 if(d.reference!==w.reference||d.currency!=='NGN'||Math.round(Number(d.amount)*100)!==w.amount_minor||String(d.account_number)!==bank.account_number||String(d.bank_code||d.account_bank)!==bank.bank_code)throw Error('Provider transfer reconciliation mismatch');
 const status=String(d.status).toUpperCase()==='SUCCESSFUL'?'paid':String(d.status).toUpperCase()==='FAILED'?'failed':'processing';
 await q("UPDATE seller_withdrawals SET status=?,provider_id=?,updated=? WHERE id=? AND status='processing'",status,String(d.id),stamp(),id).run();
 return {status};
}
