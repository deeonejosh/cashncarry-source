import { brand } from "../brand";
export const metadata = {
  title: "Welcome — " + brand.name,
  robots: { index: false, follow: true },
};
import { Welcome } from "../welcome";
export default function Page() { return <Welcome />; }
