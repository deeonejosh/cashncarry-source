export const androidPackage = "site.chatgpt.ogundiyatemidayo1.cashncarry";
export function androidLinkConfiguration(value: unknown) {
  const data = value as { packageName?: unknown; fingerprints?: unknown } | null;
  if (!data || typeof data.packageName !== "string" || !/^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*){2,}$/.test(data.packageName)) throw Error("Enter a valid Android package name");
  const fingerprints = Array.isArray(data.fingerprints) ? data.fingerprints : typeof data.fingerprints === "string" ? data.fingerprints.split(/[\n,]+/) : [];
  const unique = [...new Set(fingerprints.map((value: unknown) => String(value).trim().toUpperCase()).filter(Boolean))];
  if (!unique.length || unique.length > 10 || unique.some(value => !/^(?:[A-F0-9]{2}:){31}[A-F0-9]{2}$/.test(value))) throw Error("Provide the SHA-256 signing certificate fingerprint from Play Console, one per line");
  return { packageName: data.packageName, fingerprints: unique };
}
