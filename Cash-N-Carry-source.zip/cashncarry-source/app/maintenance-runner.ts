import { env } from "cloudflare:workers";
import { getEmailConfig } from "./email-config";
import { reconcileExpiredPayments } from "./payments";
import { flushEmails, queueUserTemplate } from "./notifications";
import { sellerMoney } from "./seller-money";
import { settleExpiredAuctions } from "./auction-settlement";
import { ensureCompetitiveSchema } from "./competitive-schema";
/** Single authenticated/worker job lease; ownership token prevents a stale runner unlocking its successor. */
export async function runMaintenance() {
  if (!env.DB) throw Error("Storage unavailable");
  const timestamp = new Date().toISOString(),
    owner = crypto.randomUUID();
  const lease = await env.DB.prepare(
    "INSERT INTO platform_settings(key,value,updated) VALUES('maintenance_job_lease',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated WHERE platform_settings.updated<? RETURNING key",
  )
    .bind(owner, timestamp, new Date(Date.now() - 10 * 60 * 1000).toISOString())
    .first();
  if (!lease)
    return { skipped: true, reason: "Another maintenance job is running" };
  try {
    const stale = await env.DB.prepare(
      "UPDATE streams SET status='ended' WHERE provider='native' AND status='live' AND heartbeat<?",
    )
      .bind(new Date(Date.now() - 90000).toISOString())
      .run();
    await env.DB.prepare("DELETE FROM platform_settings WHERE key LIKE 'admin_mfa_session:%' AND CASE WHEN json_valid(value) THEN json_extract(value,'$.expiresAt') ELSE 0 END<?").bind(Date.now()).run();
    const payment = await reconcileExpiredPayments();
    await ensureCompetitiveSchema();
    const auctions = await settleExpiredAuctions();
    const reminderCutoff=new Date(Date.now()+3*86400000).toISOString();
    const candidates:any=await env.DB.prepare("SELECT ss.store,ss.mode,ss.paid_until,ss.provider_subscription,ss.provider_plan,ss.customer_email,s.owner FROM seller_subscriptions ss JOIN stores s ON s.id=ss.store WHERE ss.status='active' AND ss.cancel_at_end=0 AND ss.provider_subscription!='' AND ss.provider_plan!=''").all();
    let reminderCount=0;
    for(const sub of candidates.results){
      const [next,plan]:any[]=await Promise.all([
        env.DB.prepare('SELECT value FROM platform_settings WHERE key=?').bind(`seller_subscription_next_${sub.mode}_${sub.store}`).first(),
        env.DB.prepare("SELECT amount_minor FROM seller_subscription_payments WHERE store=? AND mode=? AND status='paid' ORDER BY period_end DESC,created DESC LIMIT 1").bind(sub.store,sub.mode).first(),
      ]);
      if(!next?.value||next.value<=timestamp||next.value>reminderCutoff)continue;
      const id=`seller-subscription:renewal-reminder:${sub.store}:${next.value}`;
      const inserted=await env.DB.prepare("INSERT INTO notifications(id,user,title,body,created) VALUES(?,?,'Upcoming seller subscription renewal',?,?) ON CONFLICT(id) DO NOTHING RETURNING id").bind(id,sub.owner,`Cash N Carry Seller is scheduled to renew through Flutterwave on ${next.value}. Monthly price: ${sellerMoney(plan?.amount_minor||0)}. Cancel automatic renewal in Seller Centre if you do not want the next charge.`,timestamp).first();
      if(inserted){reminderCount++;await queueUserTemplate(sub.owner,`subscription-reminder:${sub.store}:${next.value}`,'seller-subscription-expiring',{actionUrl:'/seller/finance?tab=Subscription',details:[['Next renewal',next.value],['Monthly price',sellerMoney(plan?.amount_minor||0)],['Billing','Flutterwave recurring plan'],['Mode',String(sub.mode).toUpperCase()]]});}
    }
    const expired:any=await env.DB.prepare("SELECT ss.store,ss.mode,ss.paid_until,s.owner FROM seller_subscriptions ss JOIN stores s ON s.id=ss.store WHERE ss.status='active' AND ss.paid_until!='' AND ss.paid_until<=?").bind(timestamp).all();
    for(const sub of expired.results){const id=`seller-subscription:expired:${sub.store}:${sub.paid_until}`;const inserted=await env.DB.prepare("INSERT INTO notifications(id,user,title,body,created) VALUES(?,?,'Seller subscription expired',?,?) ON CONFLICT(id) DO NOTHING RETURNING id").bind(id,sub.owner,`Paid seller access ended on ${sub.paid_until}. New sales and livestream selling are paused; existing order fulfilment and eligible earnings remain accessible. Renew to restore selling access.`,timestamp).first();if(inserted){const plan:any=await env.DB.prepare("SELECT amount_minor FROM seller_subscription_payments WHERE store=? AND mode=? AND status='paid' ORDER BY period_end DESC,created DESC LIMIT 1").bind(sub.store,sub.mode).first();await queueUserTemplate(sub.owner,`subscription-expired:${sub.store}:${sub.paid_until}`,'seller-subscription-expired',{actionUrl:'/seller/finance?tab=Subscription',details:[['Paid through',sub.paid_until],['Monthly price',sellerMoney(plan?.amount_minor||0)],['Mode',String(sub.mode).toUpperCase()]]});}await env.DB.prepare("UPDATE seller_subscriptions SET status='expired',updated=? WHERE store=? AND mode=? AND status='active' AND paid_until<=?").bind(timestamp,sub.store,sub.mode,timestamp).run();await env.DB.prepare('INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated').bind(`seller_subscription_billing_${sub.mode}_${sub.store}`,sub.cancel_at_end?'cancelled_expired':'expired',timestamp).run();}
    const foundingExpired:any=await env.DB.prepare("UPDATE founding_enrollments SET status='expired',updated=? WHERE status='active' AND ends_at<=? RETURNING store,ends_at").bind(timestamp,timestamp).all();
    for(const enrollment of foundingExpired.results){const seller:any=await env.DB.prepare("SELECT owner FROM stores WHERE id=?").bind(enrollment.store).first();if(!seller)continue;await env.DB.prepare("INSERT INTO notifications(id,user,title,body,created) VALUES(?,?,'Founding Seller access ended',?,?) ON CONFLICT(id) DO NOTHING").bind(`founding-expired:${enrollment.store}:${enrollment.ends_at}`,seller.owner,`Your complimentary Founding Seller access ended on ${enrollment.ends_at}. New product publishing and livestream selling are paused until you have an eligible subscription. Existing orders and earnings records remain available. No charge has been made.`,timestamp).run();}
    const emailConfigured = Boolean(await getEmailConfig());
    const sent = emailConfigured ? await flushEmails() : 0;
    const result = {
      completedAt: new Date().toISOString(),
      payment,
      subscriptions:{renewalReminders:reminderCount,expired:expired.results.length},
      foundingSeller:{expired:foundingExpired.results.length},
      auctions,
      email: { configured: emailConfigured, sent },
      streams: { ended: stale.meta?.changes || 0 },
    };
    await env.DB.prepare(
      "INSERT INTO platform_settings(key,value,updated) VALUES('last_maintenance_run',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated",
    )
      .bind(JSON.stringify(result), result.completedAt)
      .run();
    console.info("maintenance_completed", {
      paymentChecked: payment.checked,
      emailsAccepted: sent,
      staleStreams: result.streams.ended,
    });
    return result;
  } catch (error) {
    const failedAt = new Date().toISOString();
    await env.DB.prepare(
      "INSERT INTO platform_settings(key,value,updated) VALUES('last_maintenance_failure',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated",
    )
      .bind(
        JSON.stringify({
          failedAt,
          message: "Maintenance failed; review server logs and retry",
        }),
        failedAt,
      )
      .run();
    console.error("maintenance_run_failed", error);
    throw Error("Maintenance failed; retry later");
  } finally {
    await env.DB.prepare(
      "DELETE FROM platform_settings WHERE key='maintenance_job_lease' AND value=?",
    )
      .bind(owner)
      .run();
  }
}
