import { createAuthEndpoint, APIError } from "better-auth/api";
import { headers } from "next/headers";
import { getChatGPTUser } from "./chatgpt-auth";
import { assignedAdminRole } from "./admin-access";
import { limit } from "./security";
import { env } from "cloudflare:workers";

/** Reuse Better Auth's pending challenge; never issue a pre-MFA session. */
export async function createChatGptMfaChallenge(ctx: any, identity: {userId:string;email:string}) {
  const found = await ctx.context.internalAdapter.findUserByEmail(identity.email.toLowerCase());
  const user = found?.user;
  if (!user?.emailVerified || !user.twoFactorEnabled || user.email.toLowerCase() !== identity.email.toLowerCase())
    throw APIError.from("BAD_REQUEST", {code:"ADMIN_AUTHENTICATOR_NOT_ENROLLED",message:"This admin identity has no enrolled Cash N Carry authenticator. Account security setup is required; ChatGPT sign-in has not granted admin access."});
  const factor = await ctx.context.adapter.findOne({model:"twoFactor",where:[{field:"userId",value:user.id}]});
  if (!factor || factor.verified === false)
    throw APIError.from("BAD_REQUEST", {code:"ADMIN_AUTHENTICATOR_NOT_ENROLLED",message:"Your Cash N Carry authenticator setup is incomplete. Admin access remains locked."});
  const maxAge=600, identifier="2fa-"+crypto.randomUUID();
  const expiresAt=new Date(Date.now()+maxAge*1000);
  await ctx.context.internalAdapter.createVerificationValue({identifier,value:user.id,expiresAt});
  await ctx.context.internalAdapter.createVerificationValue({identifier:"2fa-attempts-"+identifier,value:"0",expiresAt});
  const cookie=ctx.context.createAuthCookie("two_factor",{maxAge});
  await ctx.setSignedCookie(cookie.name,identifier,ctx.context.secret,cookie.attributes);
  return ctx.json({status:true});
}

export function chatGptAdminMfa() {
  return {id:"cash-n-carry-chatgpt-admin-mfa",endpoints:{chatGptAdminChallenge:createAuthEndpoint("/admin/chatgpt-challenge",{method:"POST"},async ctx=>{
    const h=await headers();
    const origin=h.get("origin");
    if (!origin || ![new URL(env.SITE_URL!).origin,"https://revibe-commerce.ogundiyatemidayo1.chatgpt.site"].includes(origin))
      throw APIError.from("FORBIDDEN",{code:"ADMIN_MFA_ACCESS_DENIED",message:"Open admin verification from Cash N Carry."});
    // Only Dispatch's authenticated identity can start this bridge.
    if (!h.get("oai-authenticated-user-id") || !h.get("oai-authenticated-user-email"))
      throw APIError.from("UNAUTHORIZED",{code:"ADMIN_MFA_ACCESS_DENIED",message:"Sign in with ChatGPT before requesting admin verification."});
    const user=await getChatGPTUser();
    if (!user || !await assignedAdminRole(user))
      throw APIError.from("FORBIDDEN",{code:"ADMIN_MFA_ACCESS_DENIED",message:"Administrator access required."});
    const profile=await env.DB!.prepare("SELECT suspended FROM profiles WHERE id=?").bind(user.userId).first<{suspended:number}>();
    if(profile?.suspended)throw APIError.from("FORBIDDEN",{code:"ADMIN_MFA_ACCESS_DENIED",message:"Administrator access is restricted."});
    await limit("chatgpt-admin-mfa:"+user.userId,5,600);
    return createChatGptMfaChallenge(ctx,user);
  })}};
}
