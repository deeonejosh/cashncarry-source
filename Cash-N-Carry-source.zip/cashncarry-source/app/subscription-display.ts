export function subscriptionDisplay(activation:{subscription:string;paidUntil?:string;cancelAtEnd?:boolean},now=Date.now()) {
 const expiry=activation.paidUntil?Date.parse(activation.paidUntil):NaN;
 const expired=Number.isFinite(expiry)&&expiry<=now;
 const days=Number.isFinite(expiry)?Math.max(0,Math.ceil((expiry-now)/86400000)):null;
 const active=activation.subscription==='active'&&Number.isFinite(expiry)&&!expired;
 const state=active?(days!==null&&days<=7?'expiring':'active'):expired||activation.subscription==='expired'?'expired':'inactive';
 return {state,days,label:state==='expiring'?'Expiring soon':state==='active'?'Active':state==='expired'?'Expired':'Not active',
 action:state==='expired'?'Resubscribe':active?'Renew subscription':'Activate subscription',
 expiry: Number.isFinite(expiry)?new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Lagos',day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:true}).format(new Date(expiry))+' WAT':'No paid subscription yet',
 guidance:state==='expired'?'Your paid period has ended. Resubscribe to restore selling once verification is approved.':active?`${expiry-now<86400000?'Less than 1 day':days===1?'1 day':days+' days'} remaining. Renewing adds a month to your current paid period.`:'Activate a monthly subscription after reviewing the plan. Selling also requires verification.',
 };
}
