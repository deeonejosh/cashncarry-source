"use client";
import VerifiedSellerBadge from "../verified-seller-badge";
import { useCallback, useEffect, useRef, useState } from "react";
import { Copy, ExternalLink, Link2, MousePointer2, ShoppingBag, Sparkles } from "lucide-react";
import { CustomerHeader, CustomerNavigation, PageHeading } from "../customer-shell";
import Link from "next/link";
type Partnership = { id: string; product_name: string; store_name: string; verified?:number; status: string; clicks: number; attributed_orders: number; estimated_commission: number; commission_bps: number };
type Commission = { id: string; product_name: string; amount: number; status: string; order_status: string };
type CreatorData = { profile: { display_name: string; status: string; note?: string } | null; creatorPartnerships: Partnership[]; commissions: Commission[] };
const money = (value: number) => new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(value);
export default function CreatorPanel() {
  const [data, setData] = useState<CreatorData | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const load = useCallback(async (signal?: AbortSignal) => {
    const response = await fetch("/api/affiliate", { cache: "no-store", signal: signal || AbortSignal.timeout(15000) });
    const result = await response.json() as CreatorData & { error?: string };
    if (!response.ok) throw Error(result.error || "Unable to load your creator dashboard.");
    setData(result); setError("");
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal).catch(e => { if (!controller.signal.aborted) setError(e instanceof Error ? e.message : "Unable to load creator data."); });
    return () => controller.abort();
  }, [load]);
  async function save(body: Record<string, unknown>) {
    if (lock.current) return;
    lock.current = true; setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch("/api/affiliate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000) });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw Error(result.error || "Your change could not be saved.");
      setNotice("Saved successfully."); await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Please try again."); }
    finally { lock.current = false; setBusy(false); }
  }
  const partnerships = data?.creatorPartnerships || [];
  const clicks = partnerships.reduce((total, p) => total + Number(p.clicks || 0), 0);
  const orders = partnerships.reduce((total, p) => total + Number(p.attributed_orders || 0), 0);
  const estimated = partnerships.reduce((total, p) => total + Number(p.estimated_commission || 0), 0);
  return <><CustomerHeader active="Account" /><main id="main-content" tabIndex={-1} className="customer-page creator-page">
    <PageHeading title="Creator Centre" description="Your partnerships, promotional links and real referral activity."><a className="secondary-button" href="/account">Account settings</a></PageHeading>
    {error && <div className="design-alert" role="alert"><p>{error}</p><button disabled={busy} onClick={() => void load().catch(e => setError(e.message))}>Retry</button></div>}
    {notice && <p className="finance-success" role="status">{notice}</p>}
    {!data && !error && <div className="design-card" role="status" aria-busy="true">Loading your creator dashboard…</div>}
    {data && <>
      <section className="design-card creator-profile"><div><p className="eyebrow">YOUR CREATOR PROFILE</p><h2>{data.profile?.display_name || "Share what you love"}</h2><p>{data.profile ? "Build partnerships with Nigerian sellers." : "Apply to promote products through the affiliate programme."}</p></div><span className="creator-status">{data.profile?.status || "Not registered"}</span></section>
      {data.profile?.note && <p className="design-alert">Review update: {data.profile.note}</p>}
      {(!data.profile || data.profile.status === "rejected") && <section className="design-card" style={{ marginTop: 24 }}><h2>Apply as a creator</h2><form className="competitive-form" onSubmit={e => { e.preventDefault(); const f = new FormData(e.currentTarget); void save({ action: "applyCreator", displayName: f.get("displayName"), socialLinks: f.get("social") ? [f.get("social")] : [], categories: String(f.get("categories") || "").split(",").map(s => s.trim()).filter(Boolean) }); }}><label>Public creator name<input name="displayName" minLength={2} maxLength={80} required defaultValue={data.profile?.display_name} /></label><label>Social profile link<input name="social" type="url" placeholder="https://" /></label><label>Content categories<input name="categories" placeholder="Fashion, beauty" /><small>Separate categories with commas.</small></label><button disabled={busy}>{busy ? "Submitting…" : "Submit application"}</button></form></section>}
      {data.profile?.status === "pending" && <p className="design-alert" role="status">Your application is being reviewed. Approved partnerships will appear here after acceptance.</p>}
      <section className="creator-kpis" aria-label="Referral activity"><article className="design-card"><span><MousePointer2 size={18} /> Referral clicks</span><strong>{clicks}</strong><small>Recorded unique clicks across your links</small></article><article className="design-card"><span><ShoppingBag size={18} /> Attributed orders</span><strong>{orders}</strong><small>Attributed orders may still be unpaid or pending</small></article><article className="design-card"><span><Sparkles size={18} /> Estimated commissions</span><strong>{money(estimated)}</strong><small>Estimates only · payouts are disabled</small></article></section>
      <PageHeading title="Seller partnerships" description="Accept invitations, share approved links and track each product." />
      {partnerships.length ? <div className="creator-partnerships">{partnerships.map(p => <article className="design-card" key={p.id}><span className="creator-status">{p.status}</span><h2>{p.product_name}</h2><p>{p.store_name}<VerifiedSellerBadge verified={p.verified}/> · {(p.commission_bps / 100).toFixed(1)}% proposed commission</p><p>{p.clicks} clicks · {p.attributed_orders} orders · {money(Number(p.estimated_commission || 0))} estimated</p>
        {p.status === "pending" && data.profile?.status === "approved" && <div className="creator-partnership-actions"><button className="primary" disabled={busy} onClick={() => void save({ action: "creatorPartnershipResponse", id: p.id, status: "approved" })}>Accept partnership</button><button className="secondary-button" disabled={busy} onClick={() => void save({ action: "creatorPartnershipResponse", id: p.id, status: "rejected" })}>Decline</button></div>}
        {p.status === "approved" && data.profile?.status === "approved" && <><label className="creator-link-field"><span><Link2 size={16} /> Your affiliate link</span><input readOnly value={`https://cashncarryng.com/affiliate/go?ref=${encodeURIComponent(p.id)}`} onFocus={e => e.currentTarget.select()} /></label><div className="creator-partnership-actions"><button className="secondary-button" onClick={async () => { try { await navigator.clipboard.writeText(`https://cashncarryng.com/affiliate/go?ref=${encodeURIComponent(p.id)}`); setNotice("Affiliate link copied."); } catch { setError("Copy is unavailable. Select and copy the link above."); } }}><Copy size={16} />Copy link</button><a className="secondary-button" href={`/affiliate/go?ref=${encodeURIComponent(p.id)}`}><ExternalLink size={16} />View product</a></div></>}
      </article>)}</div> : <section className="design-card chat-empty"><Link2 size={32} /><h3>No partnerships yet</h3><p>Seller invitations and their approval status will appear here.</p><Link className="secondary-button" href="/?browse=1#market">Discover products</Link></section>}
      <section className="design-card"><h2>Commission history</h2><p className="dashboard-footnote">These are recorded estimates. This dashboard cannot request or initiate payouts.</p>{data.commissions.length ? <div className="table-wrap"><table><caption className="sr-only">Recorded commission estimates</caption><thead><tr><th scope="col">Product</th><th scope="col">Estimate</th><th scope="col">Status</th><th scope="col">Order</th></tr></thead><tbody>{data.commissions.map(c => <tr key={c.id}><td>{c.product_name}</td><td>{money(c.amount)}</td><td>{c.status}</td><td>{c.order_status}</td></tr>)}</tbody></table></div> : <p>No commission records yet.</p>}</section>
    </>}
  </main><CustomerNavigation active="Account" /></>;
}
