import { redirect } from "next/navigation";
import { getChatGPTUser } from "../chatgpt-auth";
import CreatorPanel from "./panel";
export const dynamic = "force-dynamic";
export const metadata = { title: "Creator Centre — Cash N Carry", robots: { index: false, follow: false } };
export default async function CreatorPage() {
  if (!(await getChatGPTUser())) redirect("/sign-in?returnTo=%2Fcreator");
  return <CreatorPanel />;
}
