type Broadcast = {
  status: string;
  replay?: string;
  provider?: string;
  scheduled?: string;
};
export function broadcastCounts(streams: Broadcast[]) {
  return {
    live: streams.filter((s) => s.status === "live" && s.provider !== "tiktok")
      .length,
    scheduled: streams.filter((s) => s.status === "scheduled").length,
    replays: streams.filter((s) => s.status === "ended" && Boolean(s.replay))
      .length,
    ended: streams.filter((s) => s.status === "ended" && !s.replay).length,
    external: streams.filter(
      (s) =>
        s.status === "external" ||
        (s.status === "live" && s.provider === "tiktok"),
    ).length,
  };
}
export function broadcastLabel(stream: Broadcast) {
  if (stream.status === "scheduled")
    return stream.scheduled && Date.parse(stream.scheduled) < Date.now()
      ? "AWAITING SELLER"
      : "SCHEDULED";
  if (stream.status === "ended") return stream.replay ? "REPLAY" : "ENDED";
  if (stream.status === "external" || stream.provider === "tiktok")
    return "TIKTOK LINK";
  return stream.status === "live" ? "LIVE" : stream.status.toUpperCase();
}

export function scheduleText(scheduled?: string) {
  const time = Date.parse(scheduled || "");
  return Number.isFinite(time)
    ? new Intl.DateTimeFormat("en-NG", {
        dateStyle: "medium",
        timeStyle: "short",
        timeZone: "Africa/Lagos",
      }).format(time) + " (WAT, UTC+1)"
    : "Start time not provided";
}
export function broadcastSummary(streams: Broadcast[]) {
  const c = broadcastCounts(streams);
  const awaiting = streams.filter(
    (s) =>
      s.status === "scheduled" &&
      s.scheduled &&
      Date.parse(s.scheduled) < Date.now(),
  ).length;
  return [
    [c.live, "live now"],
    [c.scheduled - awaiting, "scheduled"],
    [awaiting, "awaiting seller"],
    [c.replays, c.replays === 1 ? "replay" : "replays"],
    [c.external, c.external === 1 ? "TikTok link" : "TikTok links"],
  ]
    .filter(([n]) => Number(n) > 0)
    .map(([n, label]) => `${n} ${label}`)
    .join(" · ");
}
