"use client";
import {useEffect} from "react";
import {trackAnalyticsEvent} from "./analytics";
export default function AnalyticsTracker({event,store,product="",stream=""}:{event:string;store:string;product?:string;stream?:string}){useEffect(()=>{trackAnalyticsEvent(event,store,{product:product||undefined,stream:stream||undefined});},[event,store,product,stream]);return null;}
