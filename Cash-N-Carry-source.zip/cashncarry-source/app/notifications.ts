import { env } from "cloudflare:workers";
import { sendEmail } from "./auth";
import { getEmailConfig } from "./email-config";
import {
  renderEmail,
  type TemplateId,
  type EmailData,
} from "./email-templates";
export async function flushEmails(onlyId?: string) {
  if (!(await getEmailConfig()))
    throw Error("Transactional email is not configured");
  const now = new Date().toISOString();
  await env
    .DB!.prepare(
      "UPDATE email_outbox SET status='expired',lease_token=NULL,last_error='Security link expired; request a fresh link' WHERE status IN ('pending','sending') AND template IN ('verification','password-reset') AND created<?",
    )
    .bind(new Date(Date.now() - 3600000).toISOString())
    .run();
  const stale = new Date(Date.now() - 10 * 60 * 1000).toISOString();
  const safeWindow = new Date(Date.now() - 23 * 60 * 60 * 1000).toISOString();
  // Never resend an uncertain delivery beyond the provider's idempotency window.
  await env
    .DB!.prepare(
      "UPDATE email_outbox SET status='reconciliation_required',lease_token=NULL WHERE status IN ('sending','pending') AND attempts>0 AND coalesce(first_attempt,created)<?",
    )
    .bind(safeWindow)
    .run();
  await env
    .DB!.prepare(
      "UPDATE email_outbox SET status='pending',lease_token=NULL,retry_at=? WHERE status='sending' AND updated<?",
    )
    .bind(now, stale)
    .run();
  await env
    .DB!.prepare(
      "UPDATE email_outbox SET status='failed' WHERE status='pending' AND attempts>=5",
    )
    .run();
  const rows = (
    await env
      .DB!.prepare(
        "SELECT * FROM email_outbox WHERE status='pending' AND attempts<5 AND (retry_at IS NULL OR retry_at<=?) AND (? IS NULL OR id=?) ORDER BY created LIMIT 20",
      )
      .bind(now, onlyId || null, onlyId || null)
      .all<any>()
  ).results;
  let sent = 0;
  for (const row of rows) {
    if (
      await env
        .DB!.prepare("SELECT reason FROM email_suppressions WHERE recipient=?")
        .bind(row.recipient.toLowerCase())
        .first()
    ) {
      await env
        .DB!.prepare(
          "UPDATE email_outbox SET status='suppressed',delivery_status='suppressed',last_error='Recipient bounced or complained',updated=? WHERE id=? AND status='pending'",
        )
        .bind(now, row.id)
        .run();
      continue;
    }
    const token = crypto.randomUUID();
    const claimed = await env
      .DB!.prepare(
        "UPDATE email_outbox SET status='sending',attempts=attempts+1,first_attempt=coalesce(first_attempt,?),updated=?,lease_token=? WHERE id=? AND status='pending' RETURNING id",
      )
      .bind(now, now, token, row.id)
      .first();
    if (!claimed) continue;
    try {
      const providerId = await sendEmail(
        row.recipient,
        row.subject,
        row.body,
        "outbox-" + row.id,
      );
      await env
        .DB!.prepare(
          "UPDATE email_outbox SET status='sent',provider_id=?,delivery_status=CASE WHEN delivery_status IN ('delivered','bounced','complained','suppressed') THEN delivery_status ELSE coalesce((SELECT CASE type WHEN 'email.delivered' THEN 'delivered' WHEN 'email.bounced' THEN 'bounced' WHEN 'email.complained' THEN 'complained' WHEN 'email.suppressed' THEN 'suppressed' WHEN 'email.delivery_delayed' THEN 'delayed' WHEN 'email.failed' THEN 'failed' ELSE 'accepted' END FROM email_webhook_events WHERE provider_id=? ORDER BY CASE type WHEN 'email.complained' THEN 6 WHEN 'email.bounced' THEN 5 WHEN 'email.suppressed' THEN 4 WHEN 'email.delivered' THEN 3 ELSE 1 END DESC,created DESC LIMIT 1),'accepted') END,last_error='',updated=?,lease_token=NULL WHERE id=? AND lease_token=?",
        )
        .bind(
          providerId || null,
          providerId || null,
          new Date().toISOString(),
          row.id,
          token,
        )
        .run();
      sent++;
    } catch (error) {
      console.error("email_delivery_failed", { id: row.id });
      const retry = new Date(
        Date.now() + Math.min(60 * 60 * 1000, 60000 * 2 ** row.attempts),
      ).toISOString();
      await env
        .DB!.prepare(
          "UPDATE email_outbox SET status=?,last_error=?,updated=?,retry_at=?,lease_token=NULL WHERE id=? AND lease_token=?",
        )
        .bind(
          row.attempts + 1 >= 5 ? "failed" : "pending",
          error instanceof Error && /rate limited/.test(error.message)
            ? "Provider rate limit; automatic retry scheduled"
            : "Provider acceptance could not be confirmed; check configuration or retry status",
          new Date().toISOString(),
          retry,
          row.id,
          token,
        )
        .run();
    }
  }
  return sent;
}

/** Event identity is durable; provider idempotency also protects uncertain retries. */
export async function emailEventId(value: string) {
  const hash = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value),
  );
  return Array.from(new Uint8Array(hash), (b) =>
    b.toString(16).padStart(2, "0"),
  ).join("");
}
export async function queueTemplate(
  recipient: string,
  event: string,
  template: TemplateId,
  data: EmailData,
) {
  const id =
    "event-" + (await emailEventId(event + ":" + recipient.toLowerCase()));
  const stamp = new Date().toISOString();
  const rendered = renderEmail(template, data);
  if (data.sample) rendered.subject = "[SAMPLE TEST] " + rendered.subject;
  else if (
    data.details?.some(
      ([key, value]) => key === "Environment" && value.startsWith("TEST"),
    )
  )
    rendered.subject = "[TEST] " + rendered.subject;
  await env
    .DB!.prepare(
      "INSERT INTO email_outbox(id,recipient,subject,body,template,status,created,updated) VALUES(?,?,?,?,?,'pending',?,?) ON CONFLICT(id) DO NOTHING",
    )
    .bind(
      id,
      recipient,
      rendered.subject,
      JSON.stringify({ emailTemplateVersion: 1, template, data }),
      template,
      stamp,
      stamp,
    )
    .run();
  return id;
}
export async function queueUserTemplate(
  user: string,
  event: string,
  template: TemplateId,
  data: EmailData,
  preference?: "order_updates" | "live_alerts",
) {
  if (preference) {
    const p: any = await env
      .DB!.prepare("SELECT * FROM preferences WHERE user=?")
      .bind(user)
      .first();
    if (p && p[preference] === 0) return;
  }
  const profile: any = await env
    .DB!.prepare("SELECT email,name FROM profiles WHERE id=?")
    .bind(user)
    .first();
  if (profile?.email)
    await queueTemplate(profile.email, event, template, {
      ...data,
      name: profile.name || data.name,
    });
}
