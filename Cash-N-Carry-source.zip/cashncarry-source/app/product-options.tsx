"use client";
import { useEffect, useState } from "react";
import ProductPhoto from "./product-photo";
export default function ProductOptions({ product, disabled, onBusy }: { product: any; disabled: boolean; onBusy: (busy: boolean) => void }) {
  const [maxImages, setMaxImages] = useState(10);
  const [variants, setVariants] = useState<any[]>(
      JSON.parse(product?.variants || "[]"),
    ),
    [images, setImages] = useState<string[]>(
      JSON.parse(product?.images || "[]"),
    );
  useEffect(() => {
    let active = true;
    fetch("/api/media", { cache: "no-store" }).then(r => r.ok ? r.json() : null).then((data: any) => {
      if (active && Number.isInteger(data?.policy?.maxImagesPerProduct)) setMaxImages(data.policy.maxImagesPerProduct);
    }).catch(() => {});
    return () => { active = false; };
  }, []);
  function change(i: number, key: string, value: string) {
    setVariants((v) =>
      v.map((x, n) =>
        n === i ? { ...x, [key]: key === "name" ? value : Number(value) } : x,
      ),
    );
  }
  return (
    <>
      <fieldset className="product-options">
        <legend>Variants</legend>
        <p>
          Optional sizes, colours or options. Each option has its own price and
          stock.
        </p>
        <input type="hidden" name="variants" value={JSON.stringify(variants)} />
        {variants.map((v, i) => (
          <div className="variant-row" key={i}>
            <label>
              Option
              <input
                value={v.name}
                onChange={(e) => change(i, "name", e.target.value)}
                required
                maxLength={100}
              />
            </label>
            <label>
              Price (₦)
              <input
                type="number"
                min={100}
                value={v.price}
                onChange={(e) => change(i, "price", e.target.value)}
                required
              />
            </label>
            <label>
              Stock
              <input
                type="number"
                min={0}
                max={100000}
                value={v.stock}
                onChange={(e) => change(i, "stock", e.target.value)}
                required
              />
            </label>
            <button
              type="button"
              aria-label={"Remove option " + v.name}
              onClick={() => setVariants((v) => v.filter((_, n) => n !== i))}
            >
              Remove
            </button>
          </div>
        ))}
        <button
          type="button"
          className="secondary-button"
          disabled={variants.length >= 40}
          onClick={() =>
            setVariants((v) => [
              ...v,
              { name: "", price: product?.price || 100, stock: 0 },
            ])
          }
        >
          Add variant
        </button>
      </fieldset>
      <fieldset className="product-options">
        <legend>Additional photos</legend>
        <input type="hidden" name="images" value={JSON.stringify(images.filter(Boolean))} />
        {images.map((url, i) => (
          <div className="variant-row" key={i}>
            <ProductPhoto value={url} disabled={disabled} onBusy={onBusy} onChange={next => setImages(v => v.map((x, n) => n === i ? next : x))} />
            <button type="button" disabled={disabled || i === 0} aria-label={`Move photo ${i + 1} earlier`} onClick={() => setImages(v => v.map((x, n) => n === i ? v[i - 1] : n === i - 1 ? v[i] : x))}>Move earlier</button>
            <button type="button" disabled={disabled || i === images.length - 1} aria-label={`Move photo ${i + 1} later`} onClick={() => setImages(v => v.map((x, n) => n === i ? v[i + 1] : n === i + 1 ? v[i] : x))}>Move later</button>
            <button
              type="button"
              disabled={disabled}
              aria-label={"Remove photo " + (i + 1)}
              onClick={() => setImages((v) => v.filter((_, n) => n !== i))}
            >
              Remove
            </button>
          </div>
        ))}
        <button
          type="button"
          className="secondary-button"
          disabled={disabled || images.length >= Math.max(0, maxImages - 1)}
          onClick={() => setImages((v) => [...v, ""])}
        >
          Add another photo ({Math.max(0, maxImages - 1 - images.length)} remaining)
        </button>
      </fieldset>
    </>
  );
}
