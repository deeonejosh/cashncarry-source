import { sessionHasMfa, type MfaSession } from "./mfa-proof";
import { env } from "cloudflare:workers";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { authAvailable, getAuth } from "./auth";
import type { ChatGPTUser } from "./chatgpt-auth";
import {
  canAdmin,
  type AdminRole,
  type AdminPermission,
} from "./admin-permissions";
export function isOwnerIdentity(user: ChatGPTUser | null): boolean {
  const email = env.REVIBE_ADMIN_EMAIL?.trim().toLowerCase();
  return Boolean(email && user && user.email.trim().toLowerCase() === email);
}
export async function assignedAdminRole(
  user: ChatGPTUser | null,
): Promise<AdminRole | null> {
  if (!user || !env.DB) return null;
  if (isOwnerIdentity(user)) return "owner";
  const row = await env.DB.prepare(
    "SELECT value FROM platform_settings WHERE key=?",
  )
    .bind("admin_role:" + user.userId)
    .first<{ value: string }>();
  try {
    const data = JSON.parse(row?.value || "null");
    return data?.email === user.email.toLowerCase() &&
      ["admin", "support", "finance", "moderator"].includes(data.role)
      ? data.role
      : null;
  } catch {
    return null;
  }
}
/** Email identity alone is insufficient: require verified Better Auth MFA session. */
export async function adminRole(
  user: ChatGPTUser | null,
): Promise<AdminRole | null> {
  const role = await assignedAdminRole(user);
  if (!role || !user || !(await authAvailable())) return null;
  const session = await (
    await getAuth()
  ).api.getSession({ headers: await headers() });
  if (
    !session?.user.emailVerified ||
    session.user.email.toLowerCase() !== user.email.toLowerCase() ||
    !(session.user as { twoFactorEnabled?: boolean }).twoFactorEnabled
  )
    return null;
  if (!(await sessionHasMfa(session as MfaSession))) return null;
  const suspended = await env
    .DB!.prepare("SELECT suspended FROM profiles WHERE id=?")
    .bind(user.userId)
    .first<{ suspended: number }>();
  return suspended?.suspended ? null : role;
}
export async function isAdmin(
  user: ChatGPTUser | null,
  permission: AdminPermission = "overview",
): Promise<boolean> {
  return canAdmin(await adminRole(user), permission);
}
export async function requireAdminMfa(user: ChatGPTUser, returnTo: string) {
  if (!(await assignedAdminRole(user)) || await adminRole(user)) return;
  const suspended = await env.DB!.prepare("SELECT suspended FROM profiles WHERE id=?")
    .bind(user.userId).first<{suspended:number}>();
  if (suspended?.suspended) return;
  if (!(await authAvailable())) redirect("/sign-in?returnTo=" + encodeURIComponent(returnTo));
  const session = await (await getAuth()).api.getSession({headers:await headers()});
  if (!session?.user.emailVerified || session.user.email.toLowerCase() !== user.email.toLowerCase())
  {
    const h=await headers();
    if (h.get("oai-authenticated-user-id") === user.userId && h.get("oai-authenticated-user-email")?.toLowerCase() === user.email.toLowerCase())
      redirect("/two-factor?chatgpt=1&returnTo="+encodeURIComponent(returnTo));
    redirect("/sign-in?returnTo=" + encodeURIComponent(returnTo));
  }
  const enrolled = Boolean((session.user as {twoFactorEnabled?:boolean}).twoFactorEnabled);
  redirect("/two-factor?enroll=" + (enrolled ? "0" : "1") + "&returnTo=" + encodeURIComponent(returnTo));
}
