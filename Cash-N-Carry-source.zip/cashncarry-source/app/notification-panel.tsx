"use client";
import { useState } from "react";
import { Bell, CheckCheck } from "lucide-react";
type Notice = {id: string; title: string; body: string; created: string; read: number | boolean};
export default function NotificationPanel({items, busy, markRead}: {items: Notice[]; busy: boolean; markRead: () => Promise<unknown>}) {
  const [unreadOnly, setUnreadOnly] = useState(false);
  const unread = items.filter(n => !n.read).length;
  const shown = unreadOnly ? items.filter(n => !n.read) : items;
  return <div className="notification-panel">
    <p className="eyebrow">CASH N CARRY</p>
    <h2>Notifications</h2>
    <p className="notification-intro">Your orders, stores and account updates, in one place.</p>
    <div className="notification-toolbar">
      <div className="notification-filters" role="group" aria-label="Filter notifications">
        <button type="button" aria-pressed={!unreadOnly} onClick={() => setUnreadOnly(false)}>All</button>
        <button type="button" aria-pressed={unreadOnly} onClick={() => setUnreadOnly(true)}>Unread <span>{unread}</span></button>
      </div>
      <button type="button" className="notification-read" disabled={busy || !unread} onClick={() => markRead()}><CheckCheck size={17} aria-hidden="true" />Mark all read</button>
    </div>
    <div className="notification-list" aria-live="polite" aria-busy={busy}>
      {shown.length ? shown.map(n => {
        const date = new Date(n.created);
        return <article key={n.id} className={"notification-card" + (!n.read ? " is-unread" : "")}>
          <div className="notification-symbol" aria-hidden="true"><Bell size={19} /></div>
          <div><h3>{n.title}</h3><p>{n.body}</p><div className="notification-meta"><span>{n.read ? "Read" : "New"}</span>{!Number.isNaN(date.getTime()) && <time dateTime={date.toISOString()}>{date.toLocaleString(undefined,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}</time>}</div></div>
        </article>;
      }) : <div className="notification-empty"><Bell size={32} aria-hidden="true" /><h3>{unreadOnly ? "You’re all caught up" : "No notifications yet"}</h3><p>{unreadOnly ? "There are no unread updates." : "Your order, store and account updates will appear here."}</p></div>}
    </div>
  </div>;
}
