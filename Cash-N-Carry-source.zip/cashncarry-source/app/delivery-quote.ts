/** A stored fee is displayable even while delivery coverage is incomplete. */
export function deliveryFee(store: { delivery_fee?: number } | null | undefined): number | undefined {
  const fee = store?.delivery_fee;
  return typeof fee === "number" && Number.isSafeInteger(fee) && fee >= 0 ? fee : undefined;
}
/** Empty coverage is the existing 'confirm with seller' state, not free delivery. */
export function deliveryQuote(
  store: { coverage?: string; delivery_fee?: number } | null | undefined,
): number | undefined {
  try {
    const coverage = JSON.parse(store?.coverage || "[]");
    const fee = store?.delivery_fee;
    return Array.isArray(coverage) &&
      coverage.length > 0 &&
      typeof fee === "number" &&
      Number.isSafeInteger(fee) &&
      fee >= 0
      ? fee
      : undefined;
  } catch {
    return undefined;
  }
}
