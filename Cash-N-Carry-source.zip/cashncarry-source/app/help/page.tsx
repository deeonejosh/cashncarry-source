import { CustomerHeader, CustomerNavigation } from "../customer-shell";
import Link from "next/link";
export const metadata = { title: "Help & contact — Cash N Carry", alternates: { canonical: "/help" } };
export const dynamic = "force-dynamic";
export default function Help() {
  const email = "support@cashncarryng.com";
  return (
    <>
      <CustomerHeader />
      <main
        id="main-content"
        tabIndex={-1}
        className="customer-page policy-page help-page"
      >
        <h1>Help & contact</h1>
        <p>
          You can read this help without signing in. Private order enquiries
          require your account.
        </p>
        <section className="support-contact design-card">
          <h2>Contact platform support</h2>
          {email ? (
            <a href={"mailto:" + encodeURIComponent(email)}>{email}</a>
          ) : (
            <p className="notice">
              A verified public support contact has not yet been published.
              Account holders can submit a private support case below.
            </p>
          )}
          <p className="notice">
            Support response coverage is being confirmed. Do not include passwords,
            verification codes or payment credentials in an email.
          </p>
          <a className="secondary-button" href="/workspace?tab=Support">
            Open an account support case
          </a>
        </section>
        <details className="help-topic">
          <summary>Sign-in problems</summary>
          <p>
            Use <a href="/sign-in">the sign-in page</a> to see available
            methods. Email registration and password recovery appear only when
            email accounts are enabled. If ChatGPT sign-in fails, retry from a
            current browser and check whether cookies are allowed.
          </p>
        </details>
        <details className="help-topic">
          <summary>Delivery questions</summary>
          <p>
            Check the seller’s delivery coverage and fee before checkout. Seller
            location is not delivery coverage. An unknown fee is not free
            delivery. Checkout is blocked until the seller saves coverage and a
            fee matching your delivery state.
          </p>
          <a href="/delivery">Delivery policy</a>
        </details>
        <details className="help-topic">
          <summary>Order and payment problems</summary>
          <p>
            Sign in and open <Link href="/?browse=1#orders">My orders</Link> to check
            your order and payment status. Closing the debit card payment page does not prove
            cancellation. If you have paid but your order remains pending,
            retain your transaction reference and open a private support case.
            Do not pay repeatedly to resolve an uncertain payment.
          </p>
        </details>
        <details className="help-topic">
          <summary>Returns and refunds</summary>
          <p>
            Read the seller’s return terms and{" "}
            <a href="/refunds">the returns policy</a>. Use your order
            to request a return or support review. An approved request is not
            confirmation that a provider refund has completed. Return periods
            and refund timelines require owner confirmation.
          </p>
        </details>
        <section className="help-topic" aria-labelledby="policy-links-heading">
          <h2 id="policy-links-heading">Policies</h2>
          <nav className="policy-link-list" aria-label="Cash N Carry policies">
            <a href="/privacy">Privacy Policy</a>
            <a href="/terms">Terms and Conditions</a>
            <a href="/delivery">Delivery and Shipping</a>
            <a href="/refunds">Returns, Cancellations and Refunds</a>
            <a href="/seller-terms">Seller Terms</a>
            <a href="/community-guidelines">Community Guidelines</a>
          </nav>
        </section>
        <details className="help-topic">
          <summary>Livestream problems</summary>
          <p>
            Allow camera and microphone access when hosting. Keep the broadcast
            screen open. Viewers can use Retry playback after a connection
            failure. A camera preview is not proof that other viewers receive
            your picture or sound.
          </p>
        </details>
      </main>
      <CustomerNavigation />
    </>
  );
}
