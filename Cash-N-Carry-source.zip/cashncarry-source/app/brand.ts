/** Public platform branding. Integration identifiers and the existing domain stay unchanged. */
export const brand = Object.freeze({
  name: "Cash N Carry",
  tagline: "Watch Live. Discover. Shop.",
  logo: "/brand/cash-n-carry-logo.png",
  symbol: "/brand/cash-n-carry-symbol.png",
  logoWidth: 1175,
  logoHeight: 300,
  accent: "#B94D32",
  iconBackground: "#164B35",
  filePrefix: "cash-n-carry",
  description:
    "Shop Nigerian sellers on Cash N Carry. Watch live product demonstrations, ask questions, discover local businesses and buy products online in naira.",
});

/** Historical platform wording in editable policies must never leak publicly. */
export function platformWording(text: string): string {
  return text.replace(/revibe/gi, brand.name);
}
