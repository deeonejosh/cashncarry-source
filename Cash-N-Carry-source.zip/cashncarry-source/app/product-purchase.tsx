"use client";
import { preserveCartForSignIn } from "./cart-resume";
import { useState } from "react";
import Link from "next/link";
import { ShoppingBag, Heart } from "lucide-react";
import { trackAnalyticsEvent } from "./analytics";
export default function ProductPurchase({
  product,
  initiallySaved = false,
  signedIn = false,
}: {
  product: any;
  initiallySaved?: boolean;
  signedIn?: boolean;
}) {
  const variants: any[] = JSON.parse(product.variants || "[]");
  const [variant, setVariant] = useState(
      variants.find((v) => v.stock > 0)?.name || variants[0]?.name || "",
    ),
    [quantity, setQuantity] = useState(1),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(""),
    [saved, setSaved] = useState(initiallySaved),
    [added, setAdded] = useState(false);
  const choice = variants.find((v) => v.name === variant),
    stock = choice?.stock ?? product.stock,
    price = choice?.price ?? product.price;
  async function request(action: string) {
    if (busy) return;
    if (action === "buy-now") {
      if (!signedIn) {
        preserveCartForSignIn(
          product.id,
          variant,
          quantity,
          "/product/" + product.id,
          "buy-now",
        );
        return;
      }
      const params = new URLSearchParams({
        buyNow: product.id,
        variant,
        quantity: String(quantity),
      });
      trackAnalyticsEvent("buy_now",product.store,{product:product.id});
      trackAnalyticsEvent("checkout_start",product.store,{product:product.id});
      window.location.assign("/?" + params.toString());
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      const r = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          action === "cart"
            ? { action, product: product.id, variant, quantity }
            : {
                action: "favourite",
                product: product.id,
                saved: saved !== true,
              },
        ),
        signal: AbortSignal.timeout(15000),
      });
      const b: any = await r.json();
      if (r.status === 401) {
        if (action === "cart") {
          preserveCartForSignIn(
            product.id,
            variant,
            quantity,
            "/product/" + product.id,
          );
          return;
        }
        window.location.assign(
          "/sign-in?returnTo=" + encodeURIComponent("/product/" + product.id),
        );
        return;
      }
      if (!r.ok) throw Error(b.error || "Unable to save this item");
      if (action === "cart") {
        setAdded(true);
        trackAnalyticsEvent("add_to_cart",product.store,{product:product.id});
        setMessage("Added to your cart.");
      } else {
        setSaved(saved !== true);
        setMessage(saved ? "Removed from saved items." : "Item saved.");
      }
    } catch (e) {
      setMessage(
        e instanceof Error
          ? e.message
          : "Please check your connection and retry.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="product-purchase">
      <div className="purchase-price">
        <strong>₦{Number(price).toLocaleString("en-NG")}</strong>
        <span className={stock > 0 ? "stock-available" : "stock-unavailable"}>
          {stock > 0 ? "In stock" : "Out of stock"}
        </span>
      </div>
      {variants.length > 0 && (
        <label>
          Choose an option
          <select
            value={variant}
            onChange={(e) => {
              setVariant(e.target.value);
              setQuantity(1);
              setAdded(false);
            }}
          >
            {variants.map((v) => (
              <option key={v.name} value={v.name} disabled={!v.stock}>
                {v.name} · ₦{Number(v.price).toLocaleString("en-NG")}
                {!v.stock ? " — sold out" : ""}
              </option>
            ))}
          </select>
        </label>
      )}
      <label>
        Quantity
        <input
          type="number"
          min={1}
          max={Math.max(1, Math.min(stock, 99))}
          value={quantity}
          disabled={!stock || busy}
          onChange={(e) => setQuantity(Number(e.target.value))}
        />
      </label>
      <p role="status" aria-live="polite">
        {message}
      </p>
      <div className="purchase-actions">
        <button
          className="primary"
          disabled={
            busy ||
            stock < 1 ||
            !Number.isInteger(quantity) ||
            quantity < 1 ||
            quantity > Math.min(stock, 99)
          }
          onClick={() => request("buy-now")}
        >
          {busy ? "Please wait…" : "Buy now"}
        </button>
        <button
          className="secondary-button"
          disabled={
            busy ||
            stock < 1 ||
            !Number.isInteger(quantity) ||
            quantity < 1 ||
            quantity > Math.min(stock, 99)
          }
          onClick={() => request("cart")}
        >
          <ShoppingBag size={20} />
          {busy ? "Please wait…" : "Add to cart"}
        </button>
        <Link className="secondary-button" href="/?open=cart">
          {added ? "View cart" : "Open cart"}
        </Link>
        <button
          className="icon-control"
          aria-label={saved ? "Remove from saved items" : "Save product"}
          aria-pressed={saved}
          disabled={busy}
          onClick={() => request("favourite")}
        >
          <Heart size={21} />
        </button>
      </div>
    </div>
  );
}
