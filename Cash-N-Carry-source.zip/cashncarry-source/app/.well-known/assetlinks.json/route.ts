import { env } from "cloudflare:workers";
import { androidLinkConfiguration } from "../../android-links";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const row = await env.DB?.prepare("SELECT value FROM platform_settings WHERE key='android_app_links'").first<{ value: string }>();
    let statements: any[] = [];
    if (row) {
      const config = androidLinkConfiguration(JSON.parse(row.value));
      statements = [{ relation: ["delegate_permission/common.handle_all_urls"], target: { namespace: "android_app", package_name: config.packageName, sha256_cert_fingerprints: config.fingerprints } }];
    }
    return Response.json(statements, { headers: { "Cache-Control": "public, max-age=300" } });
  } catch { return Response.json({ error: "Android app verification temporarily unavailable" }, { status: 503, headers: { "Cache-Control": "no-store" } }); }
}
