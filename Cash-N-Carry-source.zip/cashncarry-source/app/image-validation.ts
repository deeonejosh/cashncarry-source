export type ImageDimensions = { width: number; height: number };

export function imageDimensions(type: string, input: Uint8Array): ImageDimensions | null {
  const view = new DataView(input.buffer, input.byteOffset, input.byteLength);
  if (type === "image/png" && input.length >= 24) {
    return { width: view.getUint32(16), height: view.getUint32(20) };
  }
  if (type === "image/jpeg" && input[0] === 0xff && input[1] === 0xd8) {
    let offset = 2;
    const sof = new Set([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf]);
    while (offset + 8 < input.length) {
      if (input[offset] !== 0xff) { offset++; continue; }
      while (input[offset] === 0xff) offset++;
      const marker = input[offset++];
      if (marker === 0xd9 || marker === 0xda) break;
      if ([0x01,0xd0,0xd1,0xd2,0xd3,0xd4,0xd5,0xd6,0xd7].includes(marker)) continue;
      if (offset + 2 > input.length) break;
      const length = view.getUint16(offset);
      if (length < 2) break;
      if (sof.has(marker) && offset + 7 <= input.length)
        return { height: view.getUint16(offset + 3), width: view.getUint16(offset + 5) };
      offset += length;
    }
  }
  if (type === "image/webp" && input.length >= 30 && String.fromCharCode(...input.slice(0,4)) === "RIFF" && String.fromCharCode(...input.slice(8,12)) === "WEBP") {
    const chunk = String.fromCharCode(...input.slice(12,16));
    if (chunk === "VP8X") return { width: 1 + input[24] + (input[25] << 8) + (input[26] << 16), height: 1 + input[27] + (input[28] << 8) + (input[29] << 16) };
    if (chunk === "VP8 " && input[23] === 0x9d && input[24] === 0x01 && input[25] === 0x2a)
      return { width: view.getUint16(26, true) & 0x3fff, height: view.getUint16(28, true) & 0x3fff };
    if (chunk === "VP8L" && input[20] === 0x2f) {
      const width = 1 + input[21] + ((input[22] & 0x3f) << 8);
      const height = 1 + (input[22] >> 6) + (input[23] << 2) + ((input[24] & 0x0f) << 10);
      return { width, height };
    }
  }
  return null;
}

export function imageDimensionsProblem(dimensions: ImageDimensions | null): string {
  if (!dimensions || !Number.isSafeInteger(dimensions.width) || !Number.isSafeInteger(dimensions.height) || dimensions.width < 1 || dimensions.height < 1)
    return "The image dimensions could not be verified. Choose a valid JPEG, PNG or WebP image.";
  if (dimensions.width > 10000 || dimensions.height > 10000 || dimensions.width * dimensions.height > 40_000_000)
    return "This image is too large in pixel dimensions. Choose an image under 40 megapixels.";
  return "";
}
