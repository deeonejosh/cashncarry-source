export function bankDetails(input:Record<string,unknown>){
 const bankCode=String(input.bankCode||'').trim();
 const accountNumber=String(input.accountNumber||'').replace(/[\s-]/g,'');
 const accountName=String(input.accountName||'').trim();
 if(!/^\d{2,9}$/.test(bankCode))throw Error('Select your bank before saving.');
 if(accountName.length<2||accountName.length>150)throw Error('Enter the account holder name (2–150 characters).');
 if(!/^\d{10}$/.test(accountNumber))throw Error('Enter a valid 10-digit account number. Spaces and hyphens are allowed.');
 return {bankCode,accountNumber,accountName};
}
