"use client";
import { useEffect, useRef, useState } from "react";
export default function LiveVideo({ url }: { url: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let h: any;
    let alive = true;
    const v = ref.current;
    setError(false);
    if (!v) return;
    if (
      url.split("?")[0].endsWith(".m3u8") &&
      !v.canPlayType("application/vnd.apple.mpegurl")
    ) {
      import("hls.js")
        .then(({ default: Hls }) => {
          if (!alive) return;
          if (Hls.isSupported()) {
            h = new Hls();
            h.loadSource(url);
            h.attachMedia(v);
            h.on(Hls.Events.ERROR, (_: any, d: any) => {
              if (d.fatal) setError(true);
            });
          } else setError(true);
        })
        .catch(() => {
          if (alive) setError(true);
        });
    } else {
      v.src = url;
      v.load();
    }
    return () => {
      alive = false;
      h?.destroy();
      v.pause();
      v.removeAttribute("src");
      v.load();
    };
  }, [url, attempt]);
  return (
    <>
      <video
        ref={ref}
        controls
        autoPlay
        playsInline
        onError={() => setError(true)}
      />
      {error && (
        <div className="stream-error">
          This video could not be loaded. Retry playback or contact the seller
          if the problem continues.
          <br />
          <button
            className="secondary-button"
            onClick={() => setAttempt((n) => n + 1)}
          >
            Retry video
          </button>
        </div>
      )}
    </>
  );
}
