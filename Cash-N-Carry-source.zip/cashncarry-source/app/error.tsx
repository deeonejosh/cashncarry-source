"use client";
import { brand } from "./brand";
import Link from "next/link";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main id="main-content" tabIndex={-1}>
      <div className="empty">
        <h1>Something interrupted {brand.name}.</h1>
        <p>Please retry. Your saved orders and store data are retained.</p>
        <button className="primary" onClick={reset}>
          Try again
        </button>
        <Link className="secondary-button" href="/">
          Return home
        </Link>
      </div>
    </main>
  );
}
