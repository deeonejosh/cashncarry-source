"use client";
import { useState } from "react";
import ImageAsset from "./image-asset";
export default function ProductGallery({
  name,
  images,
  video,
}: {
  name: string;
  images: string[];
  video?: string;
}) {
  const [selected, setSelected] = useState(images[0]);
  return (
    <section className="public-product-gallery" aria-label="Product photos">
      <ImageAsset
        src={selected}
        alt={name}
        className="public-product-image"
        loading="eager"
        fetchPriority="high"
      />
      <div className="public-product-thumbnails">
        {images.length > 1 &&
          images.map((image, i) => (
            <button
              key={image}
              aria-label={"View photo " + (i + 1)}
              aria-pressed={selected === image}
              onClick={() => setSelected(image)}
            >
              <ImageAsset src={image} alt="" width={80} height={80} />
            </button>
          ))}
      </div>
      {video && (
        <video
          src={video}
          controls
          playsInline
          preload="none"
          aria-label={name + " product video"}
        />
      )}
    </section>
  );
}
