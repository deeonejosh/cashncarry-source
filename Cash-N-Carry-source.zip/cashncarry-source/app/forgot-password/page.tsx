import { brand } from "../brand";
export const metadata = { title: "Reset your password — " + brand.name };
import AuthForm from "../account/auth-form";
import { authAvailable } from "../auth";
export const dynamic = "force-dynamic";
export default async function Page() { return <AuthForm initialMode="reset" available={await authAvailable()} />; }
