export const BULK_PRODUCT_HEADERS = [
  "Product Name",
  "Description",
  "Category",
  "Price (NGN)",
  "SKU",
  "Stock Quantity",
  "Main Image URL",
  "Additional Image URLs",
  "Product Status",
];

export const BULK_PRODUCT_MAX_ROWS = 500;
export const BULK_PRODUCT_MAX_FILE_BYTES = 5 * 1024 * 1024;

export function normalizeBulkHeader(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[₦]/g, "ngn")
    .replace(/[()]/g, "")
    .replace(/[\s_-]+/g, " ");
}

export function isSafeBulkImageUrl(value, origin = "https://cashncarryng.com") {
  const raw = String(value ?? "").trim();
  if (!raw) return ""; // Optional image; supplied URLs remain strictly validated.
  if (raw.startsWith("/api/media/")) {
    return /^\/api\/media\/[A-Za-z0-9_-]{1,160}$/.test(raw)
      ? ""
      : "Use a valid Cash N Carry uploaded-image link.";
  }
  let url;
  try {
    url = new URL(raw, origin);
  } catch {
    return "Use a valid HTTPS image URL.";
  }
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (
    url.protocol !== "https:" ||
    url.username ||
    url.password ||
    !host.includes(".") ||
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    host.endsWith(".test")
  ) return "Use a public HTTPS image URL without credentials.";
  // Reject address literals entirely. This avoids local, private and link-local
  // destinations without making a server-side request or trusting DNS results.
  if (/^[0-9.]+$/.test(host) || host.includes(":"))
    return "Use a public hostname, not an IP address, for product images.";
  if (/^(?:www\.|images\.)?google\.[a-z.]+$/.test(host) || host === "share.google" || host === "drive.google.com")
    return "Use a direct public image URL, not a search or sharing page.";
  return "";
}

export function splitBulkImageUrls(value) {
  return String(value ?? "")
    .split(/[|\n;]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

export function bulkDuplicateKey(row) {
  const sku = String(row?.sku ?? "").trim().toLocaleLowerCase();
  if (sku) return `sku:${sku}`;
  return [row?.name, row?.category, row?.price]
    .map((part) => String(part ?? "").trim().toLocaleLowerCase())
    .join("\u001f");
}
