import PolicyPage, { policyMetadata } from "../policy-page";
export const dynamic = "force-dynamic";
export const generateMetadata = () => policyMetadata("community-guidelines");
export default function Page() { return PolicyPage({ policyId: "community-guidelines" }); }
