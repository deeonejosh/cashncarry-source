import { env } from "cloudflare:workers";

export function supportEmail(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const email = value.trim();
  return email.length <= 254 && /^[A-Za-z0-9.!#$%&'*+\/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(email) ? email : null;
}

export async function publicSupportEmail() {
  const configured = supportEmail(env.SUPPORT_EMAIL);
  if (configured) return configured;
  try {
    const record = await env.DB?.prepare("SELECT value FROM platform_settings WHERE key='public_support_email'").first<{ value: string }>();
    return supportEmail(record?.value);
  } catch { return null; }
}
