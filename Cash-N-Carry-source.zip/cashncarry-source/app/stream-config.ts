import { env } from "cloudflare:workers";
const objectKey = "private/stream-configuration";
async function encryptionKey() {
  if (!env.STREAM_CONFIG_KEY) throw Error("Streaming configuration storage is unavailable");
  const bytes = Uint8Array.from(atob(env.STREAM_CONFIG_KEY), c => c.charCodeAt(0));
  return crypto.subtle.importKey("raw", bytes, "AES-GCM", false, ["encrypt", "decrypt"]);
}
export async function getStreamConfig(): Promise<{accountId: string; token: string} | null> {
  if (env.BUCKET && env.STREAM_CONFIG_KEY) {
    const saved = await env.BUCKET.get(objectKey);
    if (saved) {
      const data: any = await saved.json();
      const clear = await crypto.subtle.decrypt({name: "AES-GCM", iv: Uint8Array.from(data.iv)}, await encryptionKey(), Uint8Array.from(data.cipher));
      return JSON.parse(new TextDecoder().decode(clear));
    }
  }
  return env.STREAM_ACCOUNT_ID && env.STREAM_API_TOKEN ? {accountId: env.STREAM_ACCOUNT_ID, token: env.STREAM_API_TOKEN} : null;
}
export async function saveStreamConfig(accountId: string, token: string) {
  if (!env.BUCKET) throw Error("Streaming configuration storage is unavailable");
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({name: "AES-GCM", iv}, await encryptionKey(), new TextEncoder().encode(JSON.stringify({accountId, token})));
  await env.BUCKET.put(objectKey, JSON.stringify({iv: Array.from(iv), cipher: Array.from(new Uint8Array(cipher))}));
}
