export const messageFileTypes=["image/jpeg","image/png","image/webp","application/pdf","text/plain"];
export function messageFileType(file:{type:string;name:string}){
 if(messageFileTypes.includes(file.type))return file.type;
 // Android document providers can return an empty or generic MIME type.
 if(file.type && !["application/octet-stream","binary/octet-stream"].includes(file.type))return "";
 const extension=file.name.toLowerCase().split('.').at(-1)||"";
 const types:Record<string,string>={jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",webp:"image/webp",pdf:"application/pdf",txt:"text/plain"};
 return types[extension]||"";
}
