/** Worker-level policy covers HTML, API, errors and static application responses. */
export function secureResponse(response: Response, request: Request) {
  const headers = new Headers(response.headers);
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  headers.set("X-Frame-Options", "SAMEORIGIN");
  headers.set(
    "Permissions-Policy",
    "camera=(self), microphone=(self), geolocation=(self), fullscreen=(self), payment=(self)",
  );
  if (new URL(request.url).protocol === "https:")
    headers.set("Strict-Transport-Security", "max-age=31536000");
  // React/Vinext emits inline hydration scripts and styles. Keep those working;
  // narrow provider origins, block object embeds and foreign framing/base URLs.
  headers.set(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      "base-uri 'self'",
      "object-src 'none'",
      "frame-ancestors 'self'",
      "script-src 'self' 'unsafe-inline' https://checkout.flutterwave.com",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob: https:",
      "worker-src 'self' blob:",
      "font-src 'self' data:",
      "media-src 'self' blob: https:",
      "connect-src 'self' https: wss:",
      "frame-src 'self' https://*.flutterwave.com https://*.flutterwave.cloud https://*.cloudflarestream.com https://*.videodelivery.net https://www.tiktok.com",
      "form-action 'self' https://*.flutterwave.com https://*.flutterwave.cloud",
      "upgrade-insecure-requests",
    ].join("; "),
  );
  const path = new URL(request.url).pathname;
  if (
    /^\/(admin|account|seller|workspace|order|sign-in|sign-up|forgot-password|two-factor|payment-return|api)(\/|$)/.test(
      path,
    )
  )
    headers.set("X-Robots-Tag", "noindex, nofollow");
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}
