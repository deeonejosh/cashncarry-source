import Entry from "./welcome";
import { GET as commerce } from "./api/commerce/route";
import { catalog } from "./catalog";
export const dynamic = "force-dynamic";
export default async function Page() {
 const [response, catalogue] = await Promise.all([commerce(new Request("https://cashncarryng.com/api/commerce")), catalog(new URLSearchParams(),null).catch(()=>null)]);
 const data=response.ok ? await response.json() : null;
 return <Entry initialData={data} initialCatalogue={catalogue}/>;
}
