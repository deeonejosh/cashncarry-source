/** Verify Resend's Svix signature over the exact raw body, with replay tolerance. */
export async function verifyEmailWebhook(
  raw: string,
  headers: Headers,
  secret: string,
  now = Date.now(),
) {
  const id = headers.get("svix-id") || "",
    timestamp = headers.get("svix-timestamp") || "",
    signatures = headers.get("svix-signature") || "";
  if (
    !id ||
    id.length > 200 ||
    !/^\d+$/.test(timestamp) ||
    Math.abs(now / 1000 - Number(timestamp)) > 300 ||
    !secret.startsWith("whsec_")
  )
    throw Error("Invalid webhook signature");
  const bytes = Uint8Array.from(atob(secret.slice(6)), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "raw",
    bytes,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["verify"],
  );
  const content = new TextEncoder().encode(`${id}.${timestamp}.${raw}`);
  let valid = false;
  for (const signature of signatures.split(" ")) {
    if (!signature.startsWith("v1,")) continue;
    try {
      if (
        await crypto.subtle.verify(
          "HMAC",
          key,
          Uint8Array.from(atob(signature.slice(3)), (c) => c.charCodeAt(0)),
          content,
        )
      )
        valid = true;
    } catch {}
  }
  if (!valid) throw Error("Invalid webhook signature");
  return { id, event: JSON.parse(raw) };
}
