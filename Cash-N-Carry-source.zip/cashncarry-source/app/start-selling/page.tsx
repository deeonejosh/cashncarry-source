import { brand } from "../brand";
import StartSelling from "./start-selling";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Start selling — " + brand.name,
  description: "Set up your Cash N Carry storefront and follow the steps to start selling.",
};

export default function Page() {
  return <StartSelling />;
}
