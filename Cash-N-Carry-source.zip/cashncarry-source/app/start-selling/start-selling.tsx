"use client";

import { ArrowRight, BadgeCheck, CircleDollarSign, ClipboardCheck, Radio, Store, Video } from "lucide-react";
import { CustomerHeader, CustomerNavigation } from "../customer-shell";

const setupHref = "/?browse=1&startSelling=1#seller";

export default function StartSelling() {
  return <>
    <CustomerHeader />
    <main id="main-content" tabIndex={-1} className="customer-page start-selling-page">
      <section className="start-selling-hero">
        <div className="start-selling-hero-copy">
          <p className="eyebrow">FOR NIGERIAN BUSINESSES</p>
          <h1>Bring your business online. Make it easier to shop from you.</h1>
          <p>Set up a storefront, show customers what you sell, and manage orders and conversations from one place.</p>
          <a className="primary start-selling-cta" href={setupHref}>Start your seller setup <ArrowRight size={18} /></a>
          <small>Creating a basic storefront is free. Seller verification and an active subscription are required for selling features.</small>
        </div>
        <div className="start-selling-hero-art" aria-hidden="true">
          <span className="start-selling-art-store"><Store size={32}/></span>
          <span className="start-selling-art-video"><Video size={24}/></span>
          <span className="start-selling-art-live"><Radio size={25}/><b>LIVE</b></span>
          <div className="start-selling-art-card"><i/><i/><i/><span/></div>
        </div>
      </section>

      <section className="start-selling-benefits" aria-label="Seller tools">
        <article><span><Store size={20}/></span><h2>Your own storefront</h2><p>Share one store link with your customers and organise your business in one place.</p></article>
        <article><span><Video size={20}/></span><h2>Product videos</h2><p>Show how products look and work, then connect approved videos to your catalogue.</p></article>
        <article><span><Radio size={20}/></span><h2>Live shopping</h2><p>When your seller access is active, demonstrate products and answer questions live.</p></article>
      </section>

      <section className="start-selling-steps" aria-labelledby="start-selling-steps-title">
        <div className="start-selling-section-heading"><p className="eyebrow">YOUR SETUP</p><h2 id="start-selling-steps-title">A clear path from account to first sale</h2><p>Complete each step in order. Selling tools unlock when your store meets the platform requirements.</p></div>
        <ol className="start-selling-step-list">
          <li><span className="start-selling-step-icon"><ClipboardCheck size={20}/></span><div><strong>Create or sign in to your account</strong><p>Your buyer account can also manage your seller storefront.</p></div><span className="start-selling-step-number">01</span></li>
          <li><span className="start-selling-step-icon"><Store size={20}/></span><div><strong>Create your free storefront</strong><p>Add your business name, category, location and customer contact details.</p></div><span className="start-selling-step-number">02</span></li>
          <li><span className="start-selling-step-icon"><BadgeCheck size={20}/></span><div><strong>Submit seller verification</strong><p>Provide the required identity or business details for review.</p></div><span className="start-selling-step-number">03</span></li>
          <li><span className="start-selling-step-icon"><CircleDollarSign size={20}/></span><div><strong>Activate selling access</strong><p>Choose an available subscription or qualifying offer. Review current terms before payment.</p></div><span className="start-selling-step-number">04</span></li>
        </ol>
        <div className="start-selling-bottom-cta"><div><h2>Ready to set up your store?</h2><p>You can save your storefront details before completing seller activation.</p></div><a className="primary" href={setupHref}>Continue to setup <ArrowRight size={18}/></a></div>
        <p className="start-selling-policy-note">Seller verification, subscription and selling eligibility rules apply. <a href="/seller-terms">Read Seller Terms</a>.</p>
      </section>
    </main>
    <CustomerNavigation />
  </>;
}
