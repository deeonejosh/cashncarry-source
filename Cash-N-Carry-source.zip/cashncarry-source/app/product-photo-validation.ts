export function productPhotoProblem(url: string, loaded: boolean, uploading: boolean): string {
  if (uploading) return "Wait for the photo upload to finish before saving.";
  if (!url.trim()) return ""; // Product images are optional; supplied images still require validation.
  if (!url.startsWith("/api/media/")) {
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "https:" || parsed.username || parsed.password)
        return "Use a public HTTPS image link or upload a photo.";
      if (/^(?:www\.|images\.)?google\.[a-z.]+$/.test(parsed.hostname) || parsed.hostname === "share.google" || parsed.hostname === "drive.google.com")
        return "Google search and sharing pages are not image files. Upload the photo from your device.";
    } catch { return "Use a valid image link or upload a photo."; }
  }
  return loaded ? "" : "This photo has not loaded. Upload a working photo before saving.";
}
