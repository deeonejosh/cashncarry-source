import { brand } from "../brand";
export const metadata = { title: "Sign in — " + brand.name };
import AuthForm from "../account/auth-form";
import { authAvailable } from "../auth";
export const dynamic = "force-dynamic";
export default async function Page() { return <AuthForm initialMode="sign-in" available={await authAvailable()} />; }
