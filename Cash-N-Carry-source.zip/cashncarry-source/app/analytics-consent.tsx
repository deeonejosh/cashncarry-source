"use client";
import {useEffect,useState} from "react";
import { ANALYTICS_CONSENT_KEY } from "./analytics-consent-key";
export { ANALYTICS_CONSENT_KEY } from "./analytics-consent-key";
export default function AnalyticsConsent(){const [choice,setChoice]=useState("");useEffect(()=>{setChoice(localStorage.getItem(ANALYTICS_CONSENT_KEY)||"");},[]);function save(value:string){localStorage.setItem(ANALYTICS_CONSENT_KEY,value);setChoice(value);}if(choice)return null;return <aside className="analytics-consent" aria-label="Optional analytics choice"><p>Cash N Carry can use first-party analytics to understand product discovery and livestream engagement. Optional analytics are off until you choose.</p><div><button onClick={()=>save("accepted")}>Allow analytics</button><button className="secondary-button" onClick={()=>save("rejected")}>Reject optional analytics</button><a href="/privacy">Privacy details</a></div></aside>;}
