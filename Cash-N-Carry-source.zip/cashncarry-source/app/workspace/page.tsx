"use client";
import VerifiedSellerBadge from "../verified-seller-badge";
import { createPortraitPublisher } from "../portrait-publisher";
import Link from "next/link";
import { completeIceOffer } from "../webrtc-offer";
import { safeReturnPath, workspaceTab } from "../auth-navigation";
import SellerNavigation from "../seller/navigation";
import BrandLogo from "../brand-logo";
import ProfileEditor from "../account/profile-editor";
import { broadcastLabel } from "../broadcasts";
import ImageAsset from "../image-asset";
import { brand } from "../brand";
import { useEffect, useRef, useState } from "react";
import {
  Mic,
  MicOff,
  SwitchCamera,
  X,
  Send,
  ShoppingBag,
  MoreHorizontal,
  Maximize,
  ArrowLeft,
  Radio,
  ShieldCheck,
  Video,
  VideoOff,
  Zap,
  Settings,
  Pin,
  Share2,
  BarChart3,
} from "lucide-react";
import { LiveAction, LiveSheet, ElapsedBroadcast } from "../live-overlay";
const states = [
  "Abia",
  "Adamawa",
  "Akwa Ibom",
  "Anambra",
  "Bauchi",
  "Bayelsa",
  "Benue",
  "Borno",
  "Cross River",
  "Delta",
  "Ebonyi",
  "Edo",
  "Ekiti",
  "Enugu",
  "FCT",
  "Gombe",
  "Imo",
  "Jigawa",
  "Kaduna",
  "Kano",
  "Katsina",
  "Kebbi",
  "Kogi",
  "Kwara",
  "Lagos",
  "Nasarawa",
  "Niger",
  "Ogun",
  "Ondo",
  "Osun",
  "Oyo",
  "Plateau",
  "Rivers",
  "Sokoto",
  "Taraba",
  "Yobe",
  "Zamfara",
];
export default function Workspace() {
  const [d, setD] = useState<any>(null),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [tab, setTab] = useState("Account"),
    [active, setActive] = useState(""),
    [starting, setStarting] = useState(false),
    [previewId, setPreviewId] = useState(""),
    [connectionLabel, setConnectionLabel] = useState("Not broadcasting"),
    [muted, setMuted] = useState(false),
    [hostChat, setHostChat] = useState<any[]>([]),
    [hostViewers, setHostViewers] = useState<number | null>(null),
    [hostMessage, setHostMessage] = useState(""),
    [hostSheet, setHostSheet] = useState(""),
    [broadcastStartedAt, setBroadcastStartedAt] = useState<number | null>(null),
    [fullscreenAvailable, setFullscreenAvailable] = useState(false),
    [returnPath, setReturnPath] = useState("/workspace");
  const supportOrder = (new URL(returnPath, "https://cashncarryng.com").searchParams.get("order") || "").slice(0, 150);
  useEffect(() => {
    setReturnPath(
      safeReturnPath(window.location.pathname + window.location.search),
    );
  }, []);
  const pc = useRef<RTCPeerConnection | null>(null),
    camera = useRef<MediaStream | null>(null),
    portrait = useRef<ReturnType<typeof createPortraitPublisher> | null>(null),
    confirmationPending = useRef(false),
    previewPending = useRef(false),
    switchPending = useRef(false),
    cameraFacing = useRef("user"),
    session = useRef(""),
    broadcast = useRef(""),
    generation = useRef(0),
    preview = useRef<HTMLVideoElement>(null),
    setupPending = useRef(false);
  const [studioTitle,setStudioTitle]=useState("");
  const [studioProduct,setStudioProduct]=useState("");
  const [cameraEnabled,setCameraEnabled]=useState(true);
  const [torchEnabled,setTorchEnabled]=useState(false);
  const [torchSupported,setTorchSupported]=useState(false);
  const [pinCollapsed,setPinCollapsed]=useState(false);
  const [hostLikes,setHostLikes]=useState<number|null>(null);
  const [hostLiveDeals,setHostLiveDeals]=useState<any[]>([]);
  const [hostLiveAuctions,setHostLiveAuctions]=useState<any[]>([]);
  const [liveClock,setLiveClock]=useState(Date.now());
  const [endSummary,setEndSummary]=useState<{seconds:number|null;viewers:number|null;likes:number|null}|null>(null);
  const studioEntered=useRef(false);
  const studioStartLock=useRef(false);
  const endingLock=useRef(false);
  const pinLock=useRef(false);
  const [pinCandidate,setPinCandidate]=useState("");
  const cameraOnlyId="camera-preview";
  useEffect(()=>{
    if(!d || studioEntered.current || new URLSearchParams(location.search).get("studio")!=="1")return;
    studioEntered.current=true;
    if(d.myStore && d.sellerAccess?.canSell){setTab("Broadcasts");void previewCamera(cameraOnlyId);}
    else if(d.myStore)setMessage(d.sellerAccess?.verification==="suspended"?"Selling is suspended. Review your seller status before broadcasting.":d.sellerAccess?.verification!=="verified"?"Complete seller verification before going live.":"Active selling access is required before going live.");
    else window.location.assign("/?browse=1#live");
  },[d]);
  async function startStudio(){
    if(studioStartLock.current)return;
    if(!camera.current?.getVideoTracks().some(t=>t.readyState==="live"&&t.enabled)||!camera.current?.getAudioTracks().some(t=>t.readyState==="live")){setMessage("Enable your camera and allow microphone access before going live.");return;}
    if(!d.services?.stream){setMessage("Broadcasting is not configured yet. Your camera remains in private preview.");return;}
    studioStartLock.current=true;
    const run=generation.current;
    try{
      const result=await request({action:"preview-session",title:studioTitle.trim()||`${d.myStore.name} · Live shopping`,featured:studioProduct?[studioProduct]:[],product:studioProduct});
      if(result?.streamId){if(run!==generation.current){await request({action:"end",id:result.streamId},"/api/streams");return;}setPreviewId(result.streamId);await start(result.streamId);}
    }finally{studioStartLock.current=false;}
  }
  async function toggleTorch(){
    const track=camera.current?.getVideoTracks()[0];if(!track)return;
    try{await track.applyConstraints({advanced:[{torch:!torchEnabled} as MediaTrackConstraintSet]});setTorchEnabled(v=>!v);}catch{setMessage("Flashlight is unavailable on this camera.");}
  }
  const reconnectTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const connectionDeadline=useRef<ReturnType<typeof setTimeout>|null>(null);
  const reconnectLock=useRef(false);
  const reconnectAttempts=useRef(0);
  const [retryBroadcast,setRetryBroadcast]=useState("");
  function detachTransport(){
    if(reconnectTimer.current){clearTimeout(reconnectTimer.current);reconnectTimer.current=null;}
    if(connectionDeadline.current){clearTimeout(connectionDeadline.current);connectionDeadline.current=null;}
    const endpoint=session.current;session.current="";
    if(pc.current)pc.current.onconnectionstatechange=null;
    pc.current?.close();pc.current=null;
    portrait.current?.stop();portrait.current=null;
    confirmationPending.current=false;
    return endpoint;
  }
  async function recoverBroadcast(id:string){
    if(reconnectLock.current || broadcast.current!==id)return;
    reconnectLock.current=true;
    const guard=++generation.current;
    const endpoint=detachTransport();
    setActive("");setPreviewId(id);setStarting(true);setConnectionLabel("Reconnecting…");
    setMessage("Network interrupted. Restoring this broadcast; keep the studio open.");
    try{
      if(endpoint)await fetch(endpoint,{method:"DELETE",signal:AbortSignal.timeout(5000)}).catch(()=>{});
      if(guard!==generation.current)return;
      broadcast.current="";
      await start(id,true);
    }finally{reconnectLock.current=false;}
  }
  function offerBroadcastRetry(id:string,reason:string){
    generation.current++;
    releaseMedia();
    broadcast.current=id;
    setActive("");setPreviewId(id);setStarting(false);setRetryBroadcast(id);
    setConnectionLabel("Connection lost — not live");setMessage(reason);
  }
  async function load() {
    const r = await fetch("/api/commerce", {
      signal: AbortSignal.timeout(15000),
    });
    const b: any = await r.json();
    if (!r.ok) throw Error(b.error);
    setD(b);
  }
  useEffect(() => {
    load().catch((e) => setMessage(e.message));
    const leave = () => {
      const id = broadcast.current;
      generation.current++;
      releaseMedia();
      if (id)
        fetch("/api/streams", {
          method: "POST",
          keepalive: true,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "end", id }),
        }).catch(() => {});
    };
    const warnBeforeLeaving = (e: BeforeUnloadEvent) => {
      if (!broadcast.current) return;
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", warnBeforeLeaving);
    window.addEventListener("pagehide", leave);
    const requested = new URLSearchParams(window.location.search).get("tab");
    setTab(workspaceTab(requested));
    return () => {
      window.removeEventListener("pagehide", leave);
      window.removeEventListener("beforeunload", warnBeforeLeaving);
      const id = broadcast.current;
      generation.current++;
      releaseMedia();
      if (id)
        fetch("/api/streams", {
          method: "POST",
          keepalive: true,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "end", id }),
        }).catch(() => {});
    };
  }, []);
  async function request(body: any, path = "/api/commerce") {
    setBusy(true);
    try {
      const r = await fetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(body.action === "end" ? 45000 : 25000),
      });
      const b: any = await r.json();
      if (!r.ok) throw Error(b.error || "The action could not be completed. Please try again.");
      if (body.action !== "connected") {
        try {
          await load();
          setMessage("Saved successfully");
        } catch {
          setMessage(
            "Saved successfully, but the screen could not refresh. Reload to see the latest data.",
          );
        }
      }
      return b;
    } catch (e: any) {
      setMessage(e.message);
      return null;
    } finally {
      setBusy(false);
    }
  }
  async function form(e: React.FormEvent<HTMLFormElement>, action: string) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const body: any = Object.fromEntries(fd);
    if (action === "delivery-settings") body.coverage = fd.getAll("coverage");
    if (action === "schedule" || action === "preview-session") {
      body.featured = fd.getAll("featured");
      body.product = body.featured[0] || "";
    }
    if (body.scheduled) body.scheduled = new Date(body.scheduled).toISOString();
    if (setupPending.current) return;
    setupPending.current = true;
    try {
      const result = await request({ action, ...body });
      if (action === "preview-session" && result?.streamId)
        await previewCamera(result.streamId);
    } finally {
      setupPending.current = false;
    }
  }
  function releaseMedia() {
    const endpoint = detachTransport();
    if (endpoint)
      fetch(endpoint, {
        method: "DELETE",
        signal: AbortSignal.timeout(5000),
      }).catch(() => {});
    if (pc.current) pc.current.onconnectionstatechange = null;
    pc.current?.close();
    pc.current = null;
    portrait.current?.stop();
    portrait.current = null;
    camera.current?.getTracks().forEach((track) => track.stop());
    camera.current = null;
    if (preview.current) preview.current.srcObject = null;
    broadcast.current = "";
    confirmationPending.current = false;
  }
  async function stop(id = broadcast.current) {
    if (endingLock.current) return;
    endingLock.current = true;
    try {
    setRetryBroadcast("");
    reconnectAttempts.current=0;
    if(id)setEndSummary({seconds:broadcastStartedAt?Math.max(0,Math.floor((Date.now()-broadcastStartedAt)/1000)):null,viewers:hostViewers,likes:hostLikes});
    generation.current++;
    releaseMedia();
    setActive("");
    setPreviewId("");
    setStarting(false);
    setConnectionLabel(id ? "Confirming broadcast ended…" : "Preview closed");
    setHostSheet("");
    setBroadcastStartedAt(null);
    if (id) {
      let ended = null;
      for (let attempt = 0; attempt < 3 && !ended; attempt++) {
        ended = await request({ action: "end", id }, "/api/streams");
      }
      setConnectionLabel(
        ended ? "Ended" : "End not confirmed — camera stopped",
      );
      if (!ended) {
        setRetryBroadcast(id);
        setMessage(
          "Camera and microphone stopped. The server could not confirm ending; viewers may see LIVE until the connection expires. Use End session to retry safely.",
        );
      }
    }
    } finally { endingLock.current = false; }
  }
  async function previewCamera(id: string) {
    if ((broadcast.current && broadcast.current!==retryBroadcast) || starting || previewPending.current) return;
    previewPending.current = true;
    setEndSummary(null);
    setBusy(true);
    setPreviewId(id);
    const run = ++generation.current;
    try {
      releaseMedia();
      if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) throw Error("Use HTTPS in a browser that supports camera access.");
      const media = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
          width: { ideal: 720 },
          height: { ideal: 1280 },
          aspectRatio: { ideal: 9 / 16 },
        },
        audio: true,
      });
      if (run !== generation.current) {
        media.getTracks().forEach((t) => t.stop());
        return;
      }
      camera.current = media;
      cameraFacing.current =
        media.getVideoTracks()[0]?.getSettings().facingMode || "user";
      if (preview.current) preview.current.srcObject = media;
      setPreviewId(id);
      setMuted(false);
      setCameraEnabled(true);
      setTorchEnabled(false);
      setTorchSupported(Boolean((media.getVideoTracks()[0]?.getCapabilities?.() as MediaTrackCapabilities & {torch?:boolean})?.torch));
      setConnectionLabel("Camera preview — not live");
      const settings = media.getVideoTracks()[0]?.getSettings();
      setMessage(
        `Camera ${settings?.width || "?"} × ${settings?.height || "?"}. Broadcast video is centred and cropped to portrait. Check your picture before going live.`,
      );
    } catch (e: any) {
      if (run !== generation.current) return;
      if(id!==cameraOnlyId)setPreviewId("");
      setConnectionLabel(e.name === "NotAllowedError" ? "Camera permission required" : e.name === "NotFoundError" ? "Camera or microphone unavailable" : e.message?.startsWith("Use HTTPS") ? "Secure camera access unavailable" : "Camera preview unavailable");
      setMessage(
        e.name === "NotAllowedError"
          ? "Allow camera and microphone access to preview your broadcast."
          : e.message?.startsWith("Use HTTPS") ? e.message : e.name === "NotFoundError" ? "No camera or microphone was found. Connect a device and retry." : "Camera preview unavailable. Check your device and retry.",
      );
    } finally {
      previewPending.current = false;
      setBusy(false);
    }
  }
  async function switchCamera() {
    const old = camera.current?.getVideoTracks()[0];
    if (!old || switchPending.current) return;
    switchPending.current = true;
    const run = generation.current;
    const original = camera.current;
    const previousFacing = old.getSettings().facingMode || cameraFacing.current;
    const facing = previousFacing === "environment" ? "user" : "environment";
    const previousDevice = old.getSettings().deviceId;
    // Mobile devices often cannot open both cameras at once. Keep audio running.
    old.stop();
    setMessage("Switching camera…");
    const attach = async (media: MediaStream) => {
      if (run !== generation.current || camera.current !== original) {
        media.getTracks().forEach((t) => t.stop());
        return false;
      }
      const track = media.getVideoTracks()[0];
      const sender = pc.current
        ?.getSenders()
        .find((s) => s.track?.kind === "video");
      try {
        if (sender && !portrait.current) await sender.replaceTrack(track);
      } catch (e) {
        media.getTracks().forEach((t) => t.stop());
        throw e;
      }
      if (run !== generation.current || camera.current !== original) {
        media.getTracks().forEach((t) => t.stop());
        return false;
      }
      original!.removeTrack(old);
      original!.addTrack(track);
      track.enabled=cameraEnabled;
      setTorchEnabled(false);
      setTorchSupported(Boolean((track.getCapabilities?.() as MediaTrackCapabilities & {torch?:boolean})?.torch));
      if (preview.current) {
        preview.current.srcObject = original;
        preview.current.play().catch(() => {});
      }
      return true;
    };
    try {
      const media = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { exact: facing },
          width: { ideal: 720 },
          height: { ideal: 1280 },
          aspectRatio: { ideal: 9 / 16 },
        },
        audio: false,
      });
      if (await attach(media)) {
        cameraFacing.current = facing;
        setMessage(
          facing === "environment"
            ? "Back camera selected."
            : "Front camera selected.",
        );
      }
    } catch {
      if (run !== generation.current || camera.current !== original) return;
      try {
        const restored = await navigator.mediaDevices.getUserMedia({
          video: {
            ...(previousDevice
              ? { deviceId: { exact: previousDevice } }
              : { facingMode: { ideal: previousFacing } }),
            width: { ideal: 720 },
            height: { ideal: 1280 },
            aspectRatio: { ideal: 9 / 16 },
          },
          audio: false,
        });
        if (await attach(restored))
          setMessage(
            "Requested camera unavailable. Your previous camera has been restored.",
          );
      } catch {
        if (run === generation.current) {
          await stop();
          setMessage(
            "Camera switch failed and the previous camera could not restart. Broadcast stopped. Preview your camera and retry.",
          );
        }
      }
    } finally {
      switchPending.current = false;
    }
  }
  useEffect(() => {
    if (!active) return;
    let alive = true;
    let refreshing = false;
    const refresh = async () => {
      if (refreshing) return;
      refreshing = true;
      try {
        const r = await fetch("/api/commerce?stream=" + active, {
          signal: AbortSignal.timeout(10000),
        });
        if (!r.ok) throw Error();
        const body = (await r.json()) as any;
        if (alive && broadcast.current === active) {
          if (body.stream?.status === "ended") {
            generation.current++;
            releaseMedia();
            setActive("");
            setPreviewId("");
            setStarting(false);
            setConnectionLabel("Ended");
            setMessage(
              "This broadcast has ended. Camera and microphone stopped.",
            );
            return;
          }
          if (body.stream && (body.stream.verified === 0 || body.stream.verified === 1)) setD((previous:any) => previous?.myStore ? {...previous,myStore:{...previous.myStore,verified:body.stream.verified}} : previous);
          setHostChat((body.chats || []).reverse());
          setHostViewers(body.viewers);
          if(typeof body.likes === "number")setHostLikes(body.likes);
        }
      } catch {
        if (alive) setMessage("Chat disconnected. Retrying…");
      } finally {
        refreshing = false;
      }
    };
    refresh();
    const timer = setInterval(refresh, 3500);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [active]);
  useEffect(()=>{
    if(!active)return;
    let alive=true,refreshing=false;
    const refresh=async()=>{
      if(refreshing)return;refreshing=true;
      try{
        const [dealResponse,auctionResponse]=await Promise.all([
          fetch(`/api/live-deals?stream=${encodeURIComponent(active)}`,{cache:"no-store",signal:AbortSignal.timeout(10000)}),
          fetch(`/api/live-auctions?stream=${encodeURIComponent(active)}`,{cache:"no-store",signal:AbortSignal.timeout(10000)}),
        ]);
        if(!dealResponse.ok||!auctionResponse.ok)throw Error();
        const [dealData,auctionData]=await Promise.all([dealResponse.json(),auctionResponse.json()]) as any[];
        if(alive&&broadcast.current===active){setHostLiveDeals(dealData.deals||[]);setHostLiveAuctions(auctionData.auctions||[]);}
      }catch{if(alive){setHostLiveDeals([]);setHostLiveAuctions([]);}}
      finally{refreshing=false;}
    };
    void refresh();const timer=setInterval(refresh,5000);
    return()=>{alive=false;clearInterval(timer);};
  },[active]);
  useEffect(()=>{const timer=setInterval(()=>setLiveClock(Date.now()),1000);return()=>clearInterval(timer);},[]);
  async function start(id: string, resuming=false) {
    setRetryBroadcast("");
    if(!resuming)reconnectAttempts.current=0;
    if (switchPending.current) {
      setMessage("Wait for the camera switch before going live.");
      return;
    }
    if (broadcast.current && !(resuming && broadcast.current===id && !pc.current)) {
      setMessage("End the current broadcast before starting another.");
      return;
    }
    broadcast.current = id;
    const run = ++generation.current;
    setStarting(true);
    setConnectionLabel("Connecting…");
    setMessage("Requesting camera and microphone…");
    try {
      const b = await request({ action: resuming?"resume":"prepare", id }, "/api/streams");
      if (run !== generation.current) return;
      if (!b) {
        offerBroadcastRetry(id,"Connection preparation failed. Check your network, then retry this broadcast.");
        return;
      }
      const media =
        camera.current ||
        (await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "user",
            width: { ideal: 720 },
            height: { ideal: 1280 },
            aspectRatio: { ideal: 9 / 16 },
          },
          audio: true,
        }));
      if (run !== generation.current) {
        media.getTracks().forEach((t) => t.stop());
        return;
      }
      camera.current = media;
      media.getAudioTracks().forEach(t=>t.enabled=!muted);
      cameraFacing.current =
        media.getVideoTracks()[0]?.getSettings().facingMode || "user";
      if (preview.current) preview.current.srcObject = media;
      setMessage("Connecting broadcast…");
      const connection = new RTCPeerConnection();
      pc.current = connection;
      connectionDeadline.current=setTimeout(() => {
        connectionDeadline.current=null;
        if (
          run === generation.current &&
          !["connected", "closed"].includes(connection.connectionState)
        ) {
          offerBroadcastRetry(id,"Connection timed out. Check your network, then retry this broadcast.");
        }
      }, 30000);
      if (!preview.current)
        throw Error(
          "Camera preview is unavailable. Preview your camera and retry.",
        );
      await preview.current.play();
      if (run !== generation.current) return;
      portrait.current = createPortraitPublisher(preview.current, media);
      const published = portrait.current.stream;
      published.getTracks().forEach((t) =>
        connection.addTransceiver(t, {
          direction: "sendonly",
          streams: [published],
        }),
      );
      connection.onconnectionstatechange = async () => {
        if (run !== generation.current) return;
        if (connection.connectionState === "connected") {
          if(connectionDeadline.current){clearTimeout(connectionDeadline.current);connectionDeadline.current=null;}
          if(reconnectTimer.current){clearTimeout(reconnectTimer.current);reconnectTimer.current=null;}
          reconnectAttempts.current=0;
          if (confirmationPending.current) return;
          confirmationPending.current = true;
          let confirmed = null;
          for (
            let attempt = 0;
            attempt < 15 && run === generation.current;
            attempt++
          ) {
            confirmed = await request(
              { action: "connected", id },
              "/api/streams",
            );
            if (confirmed) break;
            await new Promise((resolve) => setTimeout(resolve, 1000));
          }
          if (run !== generation.current) return;
          if (connection.connectionState !== "connected") {
            confirmationPending.current = false;
            return;
          }
          if (!confirmed) {
            offerBroadcastRetry(id,"The provider could not confirm this connection. Retry when your network is stable.");
            return;
          }
          setPreviewId("");
          setActive(id);
          setBroadcastStartedAt((previous) => previous ?? Date.now());
          setStarting(false);
          confirmationPending.current = false;
          setMessage("Broadcast connected");
          setConnectionLabel("LIVE — provider confirmed");
        }
        if (["disconnected","failed"].includes(connection.connectionState)) {
          setConnectionLabel("Reconnecting…");
          setMessage("Network interrupted. Waiting for the connection to recover…");
          if(reconnectTimer.current)return;
          reconnectTimer.current=setTimeout(()=>{
            reconnectTimer.current=null;
            if(run!==generation.current||connection.connectionState==="connected"||connection.connectionState==="closed")return;
            if(reconnectAttempts.current>=2){offerBroadcastRetry(id,"Automatic recovery could not restore the connection. Check your network and retry this broadcast.");return;}
            reconnectAttempts.current++;
            void recoverBroadcast(id);
          },connection.connectionState==="failed"?1000:15000);
        }
      };
      const offer = await completeIceOffer(connection);
      const r = await fetch(b.publish, {
        method: "POST",
        signal: AbortSignal.timeout(15000),
        headers: { "Content-Type": "application/sdp" },
        body: offer,
      });
      if (!r.ok) throw Error("Provider rejected the connection");
      const loc = r.headers.get("location");
      const endpoint = loc ? new URL(loc, b.publish).href : "";
      if (run !== generation.current) {
        if (endpoint)
          fetch(endpoint, {
            method: "DELETE",
            signal: AbortSignal.timeout(5000),
          }).catch(() => {});
        return;
      }
      session.current = endpoint;
      await connection.setRemoteDescription({
        type: "answer",
        sdp: await r.text(),
      });
    } catch (e: any) {
      if (run !== generation.current) return;
      offerBroadcastRetry(id,e.name==="NotAllowedError"?"Camera permission was denied. Allow camera and microphone access and retry.":e.message||"Connection unavailable. Check your network and retry.");
    }
  }
  useEffect(() => {
    if (!active) return;
    const timer = setInterval(async () => {
      const id = broadcast.current;
      if (!id || pc.current?.connectionState!=="connected") return;
      const run=generation.current;
      const confirmed = await request(
        { action: "connected", id },
        "/api/streams",
      );
      if(run!==generation.current || pc.current?.connectionState!=="connected")return;
      if (confirmed && broadcast.current === id)
        setConnectionLabel("LIVE — provider confirmed");
      if (!confirmed && broadcast.current === id) {
        setConnectionLabel("Connection check unavailable — retrying…");
      }
    }, 20000);
    return () => clearInterval(timer);
  }, [active]);
  useEffect(() => {
    if (preview.current && camera.current && preview.current.srcObject !== camera.current) {
      preview.current.srcObject = camera.current;
      preview.current.play().catch(() => {});
    }
  });
  useEffect(() => {
    const media = camera.current;
    if (!media) return;
    let handled = false;
    const interrupted = () => {
      if (handled || camera.current !== media) return;
      handled = true;
      void stop().then(() => setMessage("Camera or microphone access was interrupted. Media stopped; reopen your camera to continue."));
    };
    const tracks = media.getTracks();
    tracks.forEach(track => track.addEventListener("ended", interrupted));
    return () => tracks.forEach(track => track.removeEventListener("ended", interrupted));
  });
  const hostId = active || previewId || (starting ? broadcast.current : "");
  const hostStream = d?.myStreams?.find((s: any) => s.id === hostId);
  let hostFeatured:string[]=[];try{hostFeatured=JSON.parse(hostStream?.featured||"[]");}catch{}
  const hostSelectedProduct=hostId===cameraOnlyId?studioProduct:(hostStream?.product||"");
  const selectableHostProducts=[...(d?.myProducts||[]),...(hostId===cameraOnlyId?[]:(d?.affiliateProducts||[]))];
  const hostPinned = selectableHostProducts.find(
    (p: any) => p.id === hostSelectedProduct,
  );
  async function changePinnedProduct(productId: string) {
    if (pinLock.current) return;
    if (productId && !selectableHostProducts.some((p:any)=>p.id===productId && p.active && p.stock>0)) {setMessage("Choose an available, in-stock product.");return;}
    if (hostId===cameraOnlyId) {setStudioProduct(productId);setMessage(productId?"Product ready for your livestream.":"Product unpinned.");return;}
    pinLock.current=true;
    const previousProduct=hostSelectedProduct;
    setD((previous:any)=>({...previous,myStreams:previous.myStreams.map((item:any)=>item.id===hostId?{...item,product:productId}:item)}));
    try {
      const result=await request({action:"pin",id:hostId,product:productId,previousProduct});
      if (!result) setD((previous:any)=>({...previous,myStreams:previous.myStreams.map((item:any)=>item.id===hostId?{...item,product:previousProduct}:item)}));
      else setMessage(productId?"Product pinned. Viewer updates are syncing.":"Product unpinned. Viewer updates are syncing.");
    } finally {pinLock.current=false;}
  }
  const hostOpen = Boolean(hostId || starting);
  useEffect(() => {
    if (!hostOpen) return;
    setFullscreenAvailable(Boolean(document.fullscreenEnabled));
    const stage = document.querySelector<HTMLElement>(".host-live-stage");
    const dock = stage?.querySelector<HTMLElement>(".host-live-lower");
    const fit = () => {
      if (dock) stage?.style.setProperty("--host-dock-height", `${dock.getBoundingClientRect().height + 8}px`);
      if (stage)
        stage.dataset.compact = String(
          (window.visualViewport?.height || window.innerHeight) < 520,
        );
      stage?.style.setProperty(
        "--host-viewport",
        `${window.visualViewport?.height || window.innerHeight}px`,
      );
      stage?.style.setProperty(
        "--host-viewport-top",
        `${window.visualViewport?.offsetTop || 0}px`,
      );
    };
    fit();
    const dockObserver = typeof ResizeObserver !== "undefined" ? new ResizeObserver(fit) : null;
    if (dock) dockObserver?.observe(dock);
    window.visualViewport?.addEventListener("resize", fit);
    window.visualViewport?.addEventListener("scroll", fit);
    window.addEventListener("resize", fit);
    const previousOverflow = document.body.style.overflow;
    const previousFocus = document.activeElement as HTMLElement | null;
    document.body.style.overflow = "hidden";
    const rotate = () => {
      fit();
      const track = camera.current?.getVideoTracks()[0];
      track
        ?.applyConstraints({
          width: { ideal: 720 },
          height: { ideal: 1280 },
          aspectRatio: { ideal: 9 / 16 },
        })
        .catch(() => {});
    };
    window.addEventListener("orientationchange", rotate);
    stage?.querySelector<HTMLElement>("button")?.focus({ preventScroll: true });
    return () => {
      dockObserver?.disconnect();
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus({ preventScroll: true });
      window.removeEventListener("orientationchange", rotate);
      window.visualViewport?.removeEventListener("resize", fit);
      window.visualViewport?.removeEventListener("scroll", fit);
      window.removeEventListener("resize", fit);
    };
  }, [hostOpen]);
  const field = (
    name: string,
    label: string,
    type = "text",
    value: any = "",
    required = true,
  ) => (
    <label>
      {label}
      <input name={name} type={type} defaultValue={value} required={required} />
    </label>
  );
  const stateSelect = (name = "state", value = "") => (
    <label>
      State
      <select name={name} defaultValue={value} required>
        <option value="">Choose state</option>
        {states.map((x) => (
          <option key={x}>{x}</option>
        ))}
      </select>
    </label>
  );
  const studioMode = new URLSearchParams(returnPath.split("?")[1] || "").get("studio") === "1";
  const formatLiveCountdown=(end:string)=>{const parsed=Date.parse(end);if(!Number.isFinite(parsed))return "--:--";const total=Math.max(0,Math.floor((parsed-liveClock)/1000));return `${String(Math.floor(total/3600)).padStart(2,"0")}:${String(Math.floor(total%3600/60)).padStart(2,"0")}:${String(total%60).padStart(2,"0")}`;};
  const studioDeal=hostLiveDeals[0]||null;
  const studioAuction=hostLiveAuctions.find(item=>item.status==="active")||hostLiveAuctions.find(item=>item.status==="scheduled")||null;
  return (
    <main
      id="main-content"
      tabIndex={-1}
      className={
        "workspace-page workspace-dashboard" +
        (hostOpen ? " host-immersive" : "") + (studioMode ? " studio-page" : "")
      }
    >
      {studioMode && !hostOpen && <>
        <header className="studio-entry-header"><Link className="icon-control" href="/seller" aria-label="Back to Seller Centre"><ArrowLeft size={22}/></Link><BrandLogo/><Link href="/?browse=1#live" className="secondary-button">Explore Lives</Link></header>
        <section className="studio-entry-card">
          <span className="studio-entry-icon"><Video size={30}/></span><p className="eyebrow">CASH N CARRY · LIVE STUDIO</p>
          <h1>{connectionLabel==="Ended"?"Your live has ended":"Your shop. On camera."}</h1>
          <p className="studio-entry-description">{connectionLabel==="Ended"?"Your camera and microphone are stopped. Review your session or prepare your next live.":"Show your products, answer questions and bring your store to life."}</p>
          {!d ? <div role="status" className="studio-entry-notice">{message || "Loading your studio…"}{message&&<button className="secondary-button" onClick={()=>load().catch(e=>setMessage(e.message))}>Retry loading</button>}</div> : !d.user ? <Link className="primary" href={"/sign-in?returnTo="+encodeURIComponent(returnPath)}>Sign in to your studio</Link> : !d.sellerAccess?.canSell ? <div className="studio-access-state"><ShieldCheck size={24}/><h2>{d.sellerAccess?.verification==="suspended"?"Selling access is suspended":d.sellerAccess?.verification!=="verified"?"Verify your store to go live":"Activate your selling access"}</h2><p>{d.sellerAccess?.verification==="suspended"?"Review your seller status and the next steps in Seller Centre.":"Complete the required steps, then return here to open your camera."}</p><Link className="primary" href={d.sellerAccess?.verification!=="verified"?"/seller/finance?tab=Activation":"/seller/finance?tab=Subscription"}>Review seller access</Link></div> : <>
            {endSummary&&connectionLabel==="Ended"&&<dl className="studio-summary"><div><dt>Observed duration</dt><dd>{endSummary.seconds===null?"Not recorded":`${Math.floor(endSummary.seconds/60)}m ${endSummary.seconds%60}s`}</dd></div><div><dt>Last observed viewers</dt><dd>{endSummary.viewers??"Not recorded"}</dd></div><div><dt>Last recorded likes</dt><dd>{endSummary.likes??"Not recorded"}</dd></div></dl>}
            <div className="studio-entry-actions"><button className="primary" disabled={busy} onClick={()=>{setTab("Broadcasts");void previewCamera(cameraOnlyId);}}><Video size={20}/>{connectionLabel==="Ended"?"Prepare another live":"Open camera"}</button><Link className="secondary-button" href="/workspace?tab=Broadcasts">Scheduled Lives</Link></div>
            {connectionLabel==="Ended"&&<Link className="studio-text-link" href="/seller/competitive?tab=Analytics">View recorded analytics</Link>}
            <p className="studio-privacy-note"><ShieldCheck size={16}/>Private preview. Broadcasting starts only when you tap Go Live.</p>
            {message&&connectionLabel!=="Ended"&&<p className="studio-entry-notice" role="status">{message}</p>}
          </>}
        </section>
      </>}
      <BrandLogo tagline />
      <header className="workspace-heading">
        <h1>
          {["Delivery", "Verification", "Broadcasts", "Preview", "Sales"].includes(tab)
            ? "Seller Centre"
            : "My account"}
        </h1>
        <a className="secondary-button" href="/seller">
          Seller Centre
        </a>
        <a className="secondary-button" href="/account">
          My account
        </a>
      </header>
      <p role="status">{message}</p>
      {!d ? (
        message ? (
          <div role="alert">
            <p>Your workspace could not load.</p>
            <button onClick={() => load().catch((e) => setMessage(e.message))}>
              Retry
            </button>
          </div>
        ) : (
          <p role="status">Loading…</p>
        )
      ) : !d.user ? (
        <>
          <p>Sign in to access your account.</p>
          <a href={"/sign-in?returnTo=" + encodeURIComponent(returnPath)}>
            Sign in or register
          </a>
        </>
      ) : (
        <>
          {["Delivery", "Verification", "Broadcasts", "Preview", "Sales"].includes(tab) &&
            !hostOpen && (
<SellerNavigation active={tab==='Broadcasts'?'Livestreams':tab}/>
            )}
          <div className="workspace-tabs">
            {[
              "Account",
              "Saved products",
              "Addresses",
              "Notification preferences",
              "Delivery",
              "Verification",
              "Broadcasts",
              "Support",
              "Sales",
            ]
              .filter((t) =>
                ["Delivery", "Verification", "Broadcasts", "Preview", "Sales"].includes(
                  tab,
                )
                  ? [
                      "Delivery",
                      "Verification",
                      "Broadcasts",
                      "Sales",
                    ].includes(t)
                  : ![
                      "Delivery",
                      "Verification",
                      "Broadcasts",
                      "Sales",
                    ].includes(t),
              )
              .map((t) => (
                <button
                  key={t}
                  aria-pressed={tab === t}
                  onClick={() => {
                    if (hostOpen && t !== "Broadcasts") {
                      if (
                        (active || starting) &&
                        !confirm("End the broadcast and leave this screen?")
                      )
                        return;
                      void stop();
                    }
                    setTab(t);
                    const url = new URL(window.location.href);
                    url.searchParams.set("tab", t);
                    window.history.replaceState(
                      null,
                      "",
                      url.pathname + url.search,
                    );
                  }}
                >
                  {({ Delivery: "Shipping", Broadcasts: "Broadcast studio", Sales: "Payments & refunds", Account: "Profile settings" } as Record<string, string>)[t] || t}
                </button>
              ))}
            {d.user.admin && <a href="/admin">Admin back office</a>}
          </div>
          <section className="workspace-content" aria-label={tab}>
            {tab === "Account" ? (
              <>
                <ProfileEditor user={d.user} onSaved={load} />
                <a href="/forgot-password">Reset your email password</a>
                <p>
                  Account access is protected. Seller tools are available after
                  creating a storefront in Seller Centre.
                </p>
              </>
            ) : tab === "Saved products" ? (
              <>
                <h2>Saved products</h2>
                {d.favourites.length ? (
                  d.favourites.map((f: any) => {
                    const p = d.products.find((p: any) => p.id === f.product);
                    return (
                      <article key={f.product}>
                        {p ? (
                          <>
                            <ImageAsset
                              src={p.image}
                              width="100"
                              alt={p.name}
                            />
                            <a href={"/product/" + p.id}>{p.name}</a>
                          </>
                        ) : (
                          <p>Product unavailable</p>
                        )}
                        <button
                          onClick={() =>
                            request({
                              action: "favourite",
                              product: f.product,
                              saved: false,
                            })
                          }
                        >
                          Remove
                        </button>
                      </article>
                    );
                  })
                ) : (
                  <p>No saved products yet.</p>
                )}
              </>
            ) : tab === "Addresses" ? (
              <>
                <h2>Private delivery addresses</h2>
                {d.addresses.map((a: any) => (
                  <article key={a.id}>
                    <p>
                      {a.name} · {a.line}, {a.area}, {a.state}
                    </p>
                    <button
                      onClick={() =>
                        request({ action: "address", id: a.id, remove: true })
                      }
                    >
                      Delete
                    </button>
                  </article>
                ))}
                <form onSubmit={(e) => form(e, "address")}>
                  {field("name", "Recipient")}
                  {field("phone", "Phone", "tel")}
                  {field("line", "Street address")}
                  {stateSelect()}
                  {field("area", "City or area")}
                  <button disabled={busy}>Save address</button>
                </form>
              </>
            ) : tab === "Notification preferences" ? (
              <>
                <h2>Notification preferences</h2>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const f = new FormData(e.currentTarget);
                    request({
                      action: "preferences",
                      order_updates: f.has("order_updates"),
                      live_alerts: f.has("live_alerts"),
                      marketing: f.has("marketing"),
                    });
                  }}
                >
                  {[
                    ["order_updates", "Order updates"],
                    ["live_alerts", "Followed seller live alerts"],
                    ["marketing", "Marketing emails"],
                  ].map(([v, l]) => (
                    <label key={v}>
                      <input
                        type="checkbox"
                        name={v}
                        defaultChecked={Boolean(
                          d.preferences?.[v] ?? v !== "marketing",
                        )}
                      />
                      {l}
                    </label>
                  ))}
                  <button disabled={busy}>Save preferences</button>
                </form>
              </>
            ) : !d.myStore &&
              ["Delivery", "Verification", "Broadcasts", "Preview", "Sales"].includes(
                tab,
              ) ? (
              <p>
                Create a storefront in <a href="/seller">Seller Centre</a>{" "}
                first.
              </p>
            ) : tab === "Delivery" ? (
              <>
                <h2>Set up shipping</h2>
                <p>Set your price, confirm the states you serve, then save. You can update these settings anytime.</p>
                <div className="shipping-price-card"><span>Current shipping fee per order</span><strong>₦{Number(d.myStore.delivery_fee).toLocaleString("en-NG")}</strong><p>Charged once per order. Changes apply to new orders.</p></div>
                <p>
                  Publish only your business city or area, not a private
                  residential street address. Save at least one delivery state
                  and a fee before customers can order. Empty coverage blocks
                  delivery checkout; it does not offer an arranged-delivery
                  option.
                </p>
                <div className="design-alert">
                  <strong>Delivery coverage</strong>
                  <p>
                    One fixed shipping fee per order applies across your
                    selected states. Destination-specific rates and collection
                    checkout are not currently supported.
                  </p>
                </div>
                {!JSON.parse(d.myStore.coverage || "[]").length && (
                  <p className="notice" role="status">
                    Delivery checkout is currently unavailable for your store.
                    Your ₦{Number(d.myStore.delivery_fee).toLocaleString("en-NG")} shipping fee is saved. Select the delivery states you actually serve below, then save shipping settings to enable checkout.
                  </p>
                )}
                <form className="shipping-setup-form" onSubmit={(e) => form(e, "delivery-settings")}>
                  <h3>1. Shipping price</h3>
                  <label>Shipping fee per order (₦)<input name="delivery_fee" type="number" min="0" max="100000000" step="1" required defaultValue={d.myStore.delivery_fee ?? 100} /></label>
                  <p>The starting fee is ₦100. Enter another amount anytime, or 0 for free shipping.</p>
                  <h3>2. Business location</h3>
                  {stateSelect("state", d.myStore.state)}
                  {field(
                    "area",
                    "Business city or area",
                    "text",
                    d.myStore.area,
                  )}
                  <p>
                    Optional coordinates must describe a public business
                    location. Leave blank for a home business.
                  </p>
                  {field(
                    "latitude",
                    "Public business latitude",
                    "text",
                    d.myStore.latitude ?? "",
                    false,
                  )}
                  {field(
                    "longitude",
                    "Public business longitude",
                    "text",
                    d.myStore.longitude ?? "",
                    false,
                  )}
                  <fieldset>
                    <legend>3. Delivery coverage</legend>
                    <p>
                      Select only states where you can fulfil orders for the
                      fixed fee below. Your business state is not selected
                      automatically.
                    </p>
                    <div className="delivery-state-options">
                      {states.map((state) => (
                        <label key={state}>
                          <input
                            type="checkbox"
                            name="coverage"
                            value={state}
                            defaultChecked={JSON.parse(
                              d.myStore.coverage || "[]",
                            ).includes(state)}
                          />
                          {state}
                        </label>
                      ))}
                    </div>
                  </fieldset>
                  <h3>4. Delivery time & returns</h3>
                  {field(
                    "delivery_days",
                    "Estimated delivery time",
                    "text",
                    d.myStore.delivery_days,
                  )}
                  <label>
                    Returns information
                    <textarea
                      name="return_policy"
                      required
                      defaultValue={d.myStore.return_policy}
                    />
                  </label>
                  <p>
                    This fixed shipping fee is added once to each order. Enter 0
                    for free shipping.
                  </p>
                  <button disabled={busy}>Save shipping settings</button>
                </form>
              </>
            ) : tab === "Verification" ? (
              <>
                <h2>Seller verification</h2>
                <p>Status: {d.myVerification?.status || "Not submitted"}</p>
                <p>{d.myVerification?.note}</p>
                <p>
                  Evidence is accessible only to you and authorised admins.
                  Verification is manual.
                </p>
<p>Complete individual or registered-business verification, review document requests and submit appeals from the verification centre.</p><Link className="primary" href="/seller/finance?tab=Activation">Open verification centre</Link>
              </>
            ) : tab === "Broadcasts" || tab === "Preview" ? (
              <>
                {new URLSearchParams(returnPath.split("?")[1]||"").get("studio")==="1" && !d.sellerAccess?.canSell && <section className="design-card" role="status"><h2>Prepare your seller access</h2><p>{d.sellerAccess?.verification==="suspended"?"Selling is suspended. Review the status and next steps in your verification centre.":d.sellerAccess?.verification!=="verified"?"Verification is required to broadcast.":"Your selling access is inactive or expired."}</p><Link className="primary" href={d.sellerAccess?.verification!=="verified"?"/seller/finance?tab=Activation":"/seller/finance?tab=Subscription"}> {d.sellerAccess?.verification!=="verified"?"Complete verification":"Manage selling access"}</Link><Link className="secondary-button" href="/?browse=1#live">Explore Lives</Link></section>}
                <h2>{tab === "Preview" ? "Preview your livestream" : "Broadcasts"}</h2>
                <p role="status">{connectionLabel}</p>
                {connectionLabel === "Ended" && (
                  <div className="design-card">
                    <h3>This broadcast has ended</h3>
                    <p>Your camera and microphone are stopped.</p>
                    {endSummary&&<dl className="studio-summary"><div><dt>Observed stream duration</dt><dd>{endSummary.seconds===null?"Not recorded":`${Math.floor(endSummary.seconds/60)}m ${endSummary.seconds%60}s`}</dd></div><div><dt>Last observed viewers</dt><dd>{endSummary.viewers??"Not recorded"}</dd></div><div><dt>Last recorded likes</dt><dd>{endSummary.likes??"Not recorded"}</dd></div></dl>}
                    <Link className="primary" href="/seller/competitive?tab=Analytics">View recorded analytics</Link>
                    <Link href="/?browse=1#live">Browse live streams</Link>
                    {" · "}
                    <a href={"/store/" + encodeURIComponent(d.myStore.id)}>
                      Visit your store
                    </a>
                    <p>
                      Use Go live now below to prepare another private preview.
                    </p>
                  </div>
                )}
                <p>
                  Shoppable replays are not available yet. Provider recordings are not automatically published.
                </p>
                <p>
                  {d.services.stream
                    ? "Native broadcast provider configured."
                    : "Native broadcasting requires provider credentials. Scheduling and TikTok links are available."}
                </p>
                {hostOpen && (
                  <section
                    className="host-live-stage"
                    data-studio-state={active ? (connectionLabel.startsWith("LIVE")?"live":"reconnecting") : starting?"connecting":"preview"}
                    role="dialog"
                    aria-modal="true"
                    aria-label="Seller broadcast"
                    onKeyDown={(e) => {
                      if (e.key === "Tab") {
                        const controls = Array.from(
                          e.currentTarget.querySelectorAll<HTMLElement>(
                            "button:not(:disabled), input:not(:disabled), select:not(:disabled), summary, a[href]",
                          ),
                        ).filter((el) => el.getClientRects().length > 0);
                        const first = controls[0],
                          last = controls.at(-1);
                        if (e.shiftKey && document.activeElement === first) {
                          e.preventDefault();
                          last?.focus();
                        } else if (
                          !e.shiftKey &&
                          document.activeElement === last
                        ) {
                          e.preventDefault();
                          first?.focus();
                        }
                      }
                      if (e.key === "Escape") {
                        e.preventDefault();
                        if (hostSheet) setHostSheet("");
                        else if (active || starting) setHostSheet("leave");
                        else stop();
                      }
                    }}
                  >
                    <div className="host-video-frame">
                      {!camera.current&&<div className="studio-camera-empty"><span><VideoOff size={34}/></span><h2>{busy?"Opening your camera…":"Your camera is private"}</h2><p>{busy?"Allow camera and microphone access when your browser asks.":"Allow camera access to see your preview. Your broadcast has not started."}</p></div>}
                      <video
                        ref={preview}
                        autoPlay
                        muted
                        playsInline
                        className="host-preview"
                        data-facing={cameraFacing.current}
                        aria-label="Your camera preview"
                      />
                    </div>
                    <div className="host-live-top" inert={Boolean(hostSheet)}>
                      <div className="host-seller-identity">
                        <div className="host-seller-avatar" aria-hidden="true">
                          {d.myStore?.name?.slice(0, 1).toUpperCase()}
                        </div>
                        <div>
                          <strong className="seller-identity"><span className="seller-name-text">{d.myStore?.name}</span><VerifiedSellerBadge verified={d.myStore?.verified} suspended={d.myStore?.suspended} variant="compact"/></strong>
                          <span title={hostStream?.title}>
                            {hostStream?.title}
                          </span>
                        </div>
                      </div>
                      <button
                        aria-label={active || starting ? "End livestream" : "Close broadcast"}
                        onClick={() =>
                          active || starting ? setHostSheet("leave") : stop()
                        }
                      >
                        <X />
                      </button>
                    </div>
                    <div
                      className="host-live-status"
                      inert={Boolean(hostSheet)}
                    >
                      <span className="live-status">
                        {active && connectionLabel.startsWith("LIVE")
                          ? "LIVE"
                          : active
                            ? "CHECKING"
                            : starting
                              ? "CONNECTING"
                              : "PREVIEW"}
                      </span>
                      {active && hostLikes!==null && <span>{hostLikes} likes</span>}
                      {active && hostViewers !== null && (
                        <span className="host-viewer-count" title="Current viewers on this broadcast">
                          <span aria-hidden="true" className="live-viewer-dot" />
                          {hostViewers.toLocaleString()} {hostViewers === 1 ? "viewer" : "viewers"} watching
                        </span>
                      )}
                    </div>
                    <div
                      className="host-connection-meta"
                      inert={Boolean(hostSheet)}
                    >
                      <span role="status">{connectionLabel}</span>
                      {active && (
                        <ElapsedBroadcast startedAt={broadcastStartedAt} />
                      )}
                    </div>
                    <div
                      className="host-live-tools"
                      aria-label="Host actions"
                      inert={Boolean(hostSheet)}
                    >
                      <LiveAction
                        label={muted ? "Muted" : "Mic"}
                        icon={muted ? <MicOff /> : <Mic />}
                        aria-label={
                          muted ? "Unmute microphone" : "Mute microphone"
                        }
                        aria-pressed={muted}
                        disabled={!camera.current?.getAudioTracks().length}
                        title={
                          !camera.current?.getAudioTracks().length
                            ? "Allow microphone access to use this control"
                            : muted
                              ? "Microphone is muted"
                              : "Microphone is on"
                        }
                        onClick={() => {
                          const next = !muted;
                          camera.current
                            ?.getAudioTracks()
                            .forEach((t) => (t.enabled = !next));
                          setMuted(next);
                        }}
                      />
                      <LiveAction
                        label="Flip"
                        icon={<SwitchCamera />}
                        aria-label="Switch camera"
                        disabled={
                          starting || !camera.current?.getVideoTracks().length
                        }
                        title={
                          starting
                            ? "Wait for the broadcast to connect"
                            : "Switch between front and back cameras, where supported"
                        }
                        onClick={switchCamera}
                      />
                      <LiveAction label={cameraEnabled?"Camera":"Off"} icon={cameraEnabled?<Video/>:<VideoOff/>} aria-label={cameraEnabled?"Turn camera off":"Turn camera on"} aria-pressed={cameraEnabled} disabled={!camera.current?.getVideoTracks().length} onClick={()=>{const next=!cameraEnabled;camera.current?.getVideoTracks().forEach(t=>t.enabled=next);setCameraEnabled(next);}}/>
                      {torchSupported&&<LiveAction label="Flash" icon={<Zap/>} aria-label="Toggle camera flashlight" aria-pressed={torchEnabled} onClick={toggleTorch}/>}
                      <LiveAction
                        label="Products"
                        icon={<ShoppingBag />}
                        aria-label="Manage broadcast products"
                        aria-haspopup="dialog"
                        onClick={() => setHostSheet("products")}
                      />
                      <LiveAction label="Pin" icon={<Pin/>} aria-label="Select a product to pin" onClick={()=>setHostSheet("products")}/>
                      <LiveAction label="Deals" icon={<Zap/>} aria-label="Manage live deals" onClick={()=>window.open("/seller/competitive?tab=Live%20Deals","_blank","noopener,noreferrer")}/>

                      <LiveAction
                        label="More"
                        icon={<MoreHorizontal />}
                        aria-label="More host options"
                        aria-haspopup="dialog"
                        onClick={() => setHostSheet("more")}
                      />
                    </div>
                    <div className="host-live-lower" inert={Boolean(hostSheet)}>
                      {!active&&!starting&&camera.current&&<section className="studio-preflight" aria-label="Livestream setup">
                        <div className="studio-preview-note"><span className="studio-ready-dot"/>Private preview · only you can see this</div>
                        <label className="studio-title-field">Stream title
                          <input aria-label="Livestream title" value={studioTitle} onChange={e=>setStudioTitle(e.target.value.slice(0,100))} maxLength={100} placeholder={`${d.myStore?.name || "Your store"} · Live shopping`} />
                        </label>
                        <label className="studio-title-field">Feature a product
                          <select aria-label="Featured product for livestream" value={studioProduct} onChange={e=>setStudioProduct(e.target.value)}>
                            <option value="">Choose later or pin during the live</option>
                            {selectableHostProducts.filter((product:any)=>product.active&&product.stock>0).map((product:any)=><option key={product.id} value={product.id}>{product.name}</option>)}
                          </select>
                        </label>
                        <div className="studio-preflight-checks" aria-label="Device checks">
                          <span><span className="studio-ready-dot"/>Camera {camera.current?.getVideoTracks().some(t=>t.readyState==="live"&&t.enabled)?"ready":camera.current?.getVideoTracks().some(t=>t.readyState==="live")?"turn on":"check access"}</span>
                          <span><span className="studio-ready-dot"/>Microphone {camera.current?.getAudioTracks().some(t=>t.readyState==="live")?(muted?"ready · muted":"ready"):"check access"}</span>
                          <span><span className="studio-ready-dot"/>{d.services?.stream?"Provider configured":"Stream setup needed"}</span>
                        </div>
                      </section>}
                      <p className="host-live-feedback" role="status">
                        {message}
                      </p>
                      {message.startsWith("Chat disconnected") && (
                        <p role="status" className="host-chat-notice">
                          {message}
                        </p>
                      )}
                      <div className="host-live-chat" aria-live="polite">
                        {hostChat.slice(-3).map((c: any) => (
                          <div key={c.id}>
                            <strong>{c.name}</strong>
                            <span>{c.message}</span>
                          </div>
                        ))}
                      </div>
                      {hostPinned && <section className={"studio-pin-shell seller-premium-pin"+(pinCollapsed?" is-collapsed":"")} aria-label="Pinned product">
                        <button className="seller-pin-heading studio-pin-toggle" aria-label={pinCollapsed?"Expand pinned product":"Collapse pinned product"} aria-expanded={!pinCollapsed} onClick={()=>setPinCollapsed(v=>!v)}>
                          <Pin size={16}/>{pinCollapsed?<><ImageAsset src={hostPinned.image} alt=""/><span className="pin-collapsed-name">{hostPinned.name}</span><b>{new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(hostPinned.price)}</b></>:<span>Pinned Product</span>}<span aria-hidden="true">{pinCollapsed?"⌄":"⌃"}</span>
                        </button>
                        {!pinCollapsed && <div className="host-live-pin"><ImageAsset src={hostPinned.image} alt={hostPinned.name}/><span><strong title={hostPinned.name}>{hostPinned.name}</strong><b>{new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(hostPinned.price)}</b><small>{hostPinned.stock>0?`In stock: ${hostPinned.stock}`:"Sold out"}</small><a href="/?browse=1&sellerTab=Products#seller" target="_blank" rel="noopener noreferrer">Manage product ↗</a></span><button className="seller-unpin" disabled={busy || pinLock.current} onClick={()=>changePinnedProduct("")}><Pin size={16}/>Unpin</button></div>}
                      </section>}
                      {active&&<section className="studio-live-promos" aria-label="Livestream promotions">
                        <article className="studio-live-promo deal-promo">
                          <div><strong>Flash deal</strong><b>{studioDeal?formatLiveCountdown(studioDeal.ends_at):"—"}</b><small>{studioDeal?`${studioDeal.name} · ${Number(studioDeal.sold_quantity||0)} of ${Number(studioDeal.max_quantity||0)} claimed`:"No flash deal running"}</small></div>
                          <a href="/seller/competitive?tab=Live%20Deals" target="_blank" rel="noopener noreferrer" aria-label="Manage livestream flash deals">{studioDeal?"Manage":"Set up"}</a>
                        </article>
                        <article className="studio-live-promo auction-promo">
                          <div><strong>Auction</strong><b>{studioAuction?formatLiveCountdown(studioAuction.status==="active"?studioAuction.ends_at:studioAuction.starts_at):"—"}</b><small>{studioAuction?`${studioAuction.product_name} · ${studioAuction.status==="active"?`${studioAuction.bid_count||0} bids`:"Starts soon"}`:"No auction running"}</small></div>
                          <a href="/seller/competitive?tab=Auctions" target="_blank" rel="noopener noreferrer" aria-label="Manage livestream auctions">{studioAuction?"Manage":"Set up"}</a>
                        </article>
                      </section>}
                      {selectableHostProducts.some((product:any)=>product.active) && <div className="seller-product-selection"><nav className="seller-live-product-strip" aria-label="Products available to pin">{selectableHostProducts.filter((product:any)=>product.active).slice(0,10).map((product:any)=><button key={product.id} disabled={busy || !product.stock} aria-label={`Select ${product.name}`} aria-pressed={pinCandidate===product.id} data-pinned={hostSelectedProduct===product.id} onClick={()=>setPinCandidate(product.id)}><ImageAsset src={product.image} alt=""/><span>{product.name}{hostSelectedProduct===product.id?" · Pinned":""}</span></button>)}</nav><button className="seller-pin-selected" disabled={busy || !pinCandidate || pinCandidate===hostSelectedProduct} onClick={()=>changePinnedProduct(pinCandidate)}><Pin size={16}/>Pin selected product</button></div>}
                      {active && (
                        <form
                          className="host-live-reply"
                          onSubmit={async (e) => {
                            e.preventDefault();
                            if (
                              await request({
                                action: "chat",
                                stream: active,
                                message: hostMessage,
                              })
                            )
                              setHostMessage("");
                          }}
                        >
                          <input
                            aria-label="Reply to viewers"
                            placeholder="Reply to viewers…"
                            value={hostMessage}
                            onChange={(e) => setHostMessage(e.target.value)}
                            required
                            maxLength={400}
                          />
                          <button aria-label="Send reply" disabled={busy}>
                            <Send />
                          </button>
                        </form>
                      )}
                      <div className="host-live-actions">
                        {!active && !starting ? (
                          <>
                            {(busy || !camera.current || !cameraEnabled) && (
                              <p className="host-start-reason" role="status">
                                {busy
                                  ? "Please wait for the current camera or connection action to finish."
                                  : !cameraEnabled ? "Turn your camera on to go live." : message || "Allow camera and microphone access to open your preview."}
                              </p>
                            )}
                            <button
                              className="primary"
                              disabled={busy || (!retryBroadcast && (!camera.current || !cameraEnabled))}
                              onClick={() => retryBroadcast ? start(retryBroadcast,true) : previewId===cameraOnlyId ? startStudio() : start(previewId)}
                            >
                              <Radio size={20} aria-hidden="true"/>{retryBroadcast?"Retry broadcast":"Go Live"}
                            </button>
                            {!camera.current && <button onClick={()=>previewCamera(previewId||cameraOnlyId)}>Retry camera permission</button>}
                            <button onClick={() => retryBroadcast ? stop(retryBroadcast) : stop()}>
                              {retryBroadcast?"End session":"Cancel preview"}
                            </button>
                          </>
                        ) : null}
                      </div>
                    </div>
                    {hostSheet && (
                      <LiveSheet
                        title={
                          hostSheet === "products"
                            ? "Manage products"
                            : hostSheet === "moderation"
                              ? "Moderate comments"
                              : hostSheet === "leave"
                                ? "End livestream?"
                                : hostSheet === "settings" ? "Camera & live settings" : hostSheet === "stats" ? "Live statistics" : "Studio tools"
                        }
                        onClose={() => setHostSheet("")}
                      >
                        {hostSheet !== "more" && message && (
                          <p role="status" className="live-sheet-notice">
                            {message}
                          </p>
                        )}
                        {hostSheet === "stats" ? <dl className="seller-live-stats"><div><dt>Current viewers</dt><dd>{hostViewers===null?"Unavailable":hostViewers}</dd></div><div><dt>Likes</dt><dd>{hostLikes===null?"Unavailable":hostLikes}</dd></div><div><dt>Featured products</dt><dd>{hostFeatured.length}</dd></div></dl> : hostSheet === "products" ? (
                          <div className="live-option-list">
                            <p>
                              Pin your products or products covered by an approved creator partnership. Viewers can choose an option before adding it to their cart.
                            </p>
                            {selectableHostProducts.some((p: any) => p.active) ? (
                              <label>
                                Pinned product
                                <select
                                  value={pinCandidate}
                                  disabled={busy}
                                  onChange={(e) => setPinCandidate(e.target.value)}
                                >
                                  <option value="">Choose a product to pin</option>
                                  {selectableHostProducts
                                    .filter((p: any) => p.active)
                                    .map((p: any) => (
                                      <option key={p.id} value={p.id} disabled={!p.stock}>
                                        {d.myProducts?.some((mine:any)=>mine.id===p.id)?"":`${p.seller} · `}{p.name}
                                        {!p.stock ? " · Out of stock" : ""}
                                      </option>
                                    ))}
                                </select>
                                <button disabled={busy || !pinCandidate || pinCandidate===hostSelectedProduct} onClick={()=>changePinnedProduct(pinCandidate)}>Pin selected product</button>
                              </label>
                            ) : (
                              <p>
                                No available products. Add products in your
                                seller dashboard after closing the preview or
                                ending the broadcast.
                              </p>
                            )}
                          </div>
                        ) : hostSheet === "settings" ? <div className="live-option-list"><label>Optional livestream title<input value={studioTitle} maxLength={160} onChange={e=>setStudioTitle(e.target.value)} disabled={Boolean(active||starting)} placeholder="Showcase your products…"/></label><p>Front camera opens by default. Use Flip to change cameras. Permission settings are managed in your browser.</p><p>Camera: {camera.current?.getVideoTracks()[0]?.readyState||"unavailable"} · Microphone: {camera.current?.getAudioTracks()[0]?.readyState||"unavailable"}</p></div> : hostSheet === "moderation" ? (
                          <div className="live-moderation-list">
                            {hostChat.length ? (
                              hostChat.slice(-30).map((c: any) => (
                                <article key={c.id}>
                                  <p>
                                    <strong>{c.name}</strong> {c.message}
                                  </p>
                                  <div>
                                    <button
                                      disabled={busy}
                                      onClick={async () => {
                                        if (
                                          await request({
                                            action: "moderate-chat",
                                            id: c.id,
                                          })
                                        )
                                          setHostChat((previous) =>
                                            previous.filter(
                                              (item) => item.id !== c.id,
                                            ),
                                          );
                                      }}
                                    >
                                      Hide message
                                    </button>
                                    <button
                                      disabled={busy}
                                      onClick={async () => {
                                        if (
                                          confirm(
                                            "Mute this viewer for this broadcast?",
                                          )
                                        ) {
                                          if (
                                            await request({
                                              action: "moderate-chat",
                                              id: c.id,
                                              block: true,
                                            })
                                          )
                                            setHostChat((previous) =>
                                              previous.filter(
                                                (item) => item.id !== c.id,
                                              ),
                                            );
                                        }
                                      }}
                                    >
                                      Mute viewer
                                    </button>
                                  </div>
                                </article>
                              ))
                            ) : (
                              <p>No comments to moderate yet.</p>
                            )}
                          </div>
                        ) : hostSheet === "leave" ? (
                          <div className="live-option-list">
                            <p>Your livestream will stop and viewers will be disconnected.</p>
                            <button className="secondary-button" onClick={() => setHostSheet("")}>Cancel</button>
                            <button className="host-end" disabled={busy || endingLock.current} onClick={() => stop()}>End Live</button>
                          </div>
                        ) : (
                          <div className="live-option-list">
                            {!active && !starting && <Link href="/?browse=1#live" onClick={()=>releaseMedia()}>Explore Lives</Link>}
                            <button onClick={()=>setHostSheet("settings")}><Settings size={18}/>Camera settings and optional title</button>
                            <button onClick={()=>setHostSheet("stats")}><BarChart3 size={18}/>Live stats</button>
                            <a href="/seller/competitive?tab=Analytics" target="_blank" rel="noopener noreferrer">Recorded analytics</a>
                            <button onClick={async()=>{const url=new URL("/",window.location.origin);url.searchParams.set("stream",active);try{if(navigator.share)await navigator.share({title:hostStream?.title||"Cash N Carry live",url:url.href});else{await navigator.clipboard.writeText(url.href);setMessage("Broadcast link copied.");}}catch(e){if((e as Error).name!=="AbortError")setMessage("Unable to share. Please try again.");}}} disabled={!active}><Share2 size={18}/>Share broadcast</button>
                            <a href="/seller/competitive?tab=Bundles" target="_blank" rel="noopener noreferrer">Product bundles — opens seller tools</a>
                            <a href="/seller/competitive?tab=Auctions" target="_blank" rel="noopener noreferrer">Auctions — opens seller tools</a>
                            <button onClick={() => setHostSheet("moderation")}>
                              Moderate comments
                            </button>
                            {fullscreenAvailable && (
                              <button
                                onClick={(e) => {
                                  const stage = e.currentTarget.closest(
                                    ".host-live-stage",
                                  ) as HTMLElement;
                                  stage
                                    .requestFullscreen()
                                    .then(() => setHostSheet(""))
                                    .catch(() =>
                                      setMessage(
                                        "Fullscreen is unavailable. Continue broadcasting here.",
                                      ),
                                    );
                                }}
                              >
                                <Maximize />
                                Enter fullscreen
                              </button>
                            )}
                            <p role="status">{message || connectionLabel}</p>

                          </div>
                        )}
                      </LiveSheet>
                    )}
                  </section>
                )}
                {tab !== "Preview" && d.myStreams.map((s: any) => (
                  <article key={s.id}>
                    <strong>{s.title}</strong>
                    <p>
                      {s.status === "scheduled" && !s.scheduled
                        ? "Private setup"
                        : broadcastLabel(s)}{" "}
                      ·{" "}
                      {s.scheduled &&
                        new Date(s.scheduled).toLocaleString("en-NG", {
                          timeZone: "Africa/Lagos",
                          timeZoneName: "short",
                        })}
                    </p>
                    {s.status === "scheduled" && (
                      <button
                        disabled={
                          busy ||
                          starting ||
                          Boolean(active) ||
                          !d.services.stream
                        }
                        onClick={() => previewCamera(s.id)}
                      >
                        Preview camera &amp; microphone
                      </button>
                    )}
                    {["scheduled", "live", "external"].includes(s.status) && (
                      <button
                        onClick={() =>
                          s.provider === "native"
                            ? confirm("End this session?")
                              ? broadcast.current === s.id
                                ? stop(s.id)
                                : request(
                                    { action: "end", id: s.id },
                                    "/api/streams",
                                  )
                              : undefined
                            : confirm("End this external session?")
                              ? request({ action: "endstream", id: s.id })
                              : undefined
                        }
                      >
                        End session
                      </button>
                    )}
                    <label>
                      Pin product
                      <select
                        value={s.product}
                        onChange={(e) =>
                          request({
                            action: "pin",
                            id: s.id,
                            product: e.target.value,
                          })
                        }
                      >
                        <option value="">Choose product</option>
                        {(d.myProducts || d.products)
                          .filter((p: any) => p.store === d.myStore.id)
                          .map((p: any) => (
                            <option value={p.id} key={p.id}>
                              {p.name}
                            </option>
                          ))}
                      </select>
                    </label>
                  </article>
                ))}
                <h3>Go live now</h3>
                <p>
                  Set up a private camera preview. You publish only after
                  pressing Go Live.
                </p>
                <form className="live-preview-form design-card" onSubmit={(e) => form(e, "preview-session")}>
                  {field("title", "Stream title")}
                  <fieldset>
                    <legend>Featured products</legend>
                    {(d.myProducts || [])
                      .filter((p: any) => p.active)
                      .map((p: any) => (
                        <label key={p.id}>
                          <input type="checkbox" name="featured" value={p.id} />
                          {p.name}
                        </label>
                      ))}
                  </fieldset>
                  <button
                    disabled={
                      busy || starting || Boolean(active) || !d.services?.stream
                    }
                  >
                    Preview camera
                  </button>
                  {!d.services?.stream && (
                    <p role="status">
                      Streaming needs configuration by the owner before you can
                      broadcast.
                    </p>
                  )}
                </form>
                {tab !== "Preview" && <>
                <h3>Schedule a native broadcast</h3>
                <form onSubmit={(e) => form(e, "schedule")}>
                  {field("title", "Title")}
                  {field("scheduled", "Date and time", "datetime-local")}
                  <fieldset>
                    <legend>Featured products</legend>
                    {(d.myProducts || []).map((p: any) => (
                      <label key={p.id}>
                        <input type="checkbox" name="featured" value={p.id} />
                        {p.name}
                      </label>
                    ))}
                  </fieldset>
                  <button disabled={busy}>Schedule</button>
                </form>
                <h3>TikTok LIVE link</h3>
                <p>
                  Viewers open TikTok. Sharing a link does not embed TikTok LIVE
                  on {brand.name}.
                </p>
                <form onSubmit={(e) => form(e, "tiktok")}>
                  {field("title", "Title")}
                  {field("url", "TikTok LIVE URL", "url")}
                  <button disabled={busy}>Share Watch on TikTok link</button>
                </form></>}
              </>
            ) : tab === "Sales" ? (
              <>
                <h2>Orders and shipment updates</h2>
                {d.sellerOrders.map((o: any) => (
                  <form key={o.id} onSubmit={(e) => form(e, "tracking")}>
                    <strong>
                      {o.id} · {o.status}
                    </strong>
                    <p>Payment: {o.payment_status || o.payment}{o.payment === "flutterwave" && o.payment_mode !== "live" ? " · Sandbox test" : ""}</p>
                    {o.payment === "flutterwave" && o.payment_status !== "paid" && <p role="status">Awaiting verified payment. Ask the customer to check My orders and complete payment before confirming. Do not ask them to pay again if the result is uncertain.</p>}
                    {["placed", "confirmed", "shipped"].includes(o.status) && <button type="button" disabled={busy || (o.payment === "flutterwave" && o.payment_status !== "paid")} onClick={() => request({action: "status", id: o.id, status: ({placed: "confirmed", confirmed: "shipped", shipped: "delivered"} as Record<string,string>)[o.status]})}>{({placed: "Confirm order", confirmed: "Mark shipped", shipped: "Mark delivered"} as Record<string,string>)[o.status]}</button>}
                    <a href={"/order/" + o.id}>View order details</a>
                    <input type="hidden" name="id" value={o.id} />
                    {field(
                      "tracking",
                      "Carrier / tracking reference",
                      "text",
                      o.tracking,
                      false,
                    )}
                    <button disabled={busy}>Save shipment details</button>
                  </form>
                ))}
                <h2>Verified payment records</h2>
                <p>
                  These records are payments to orders, not seller payouts.
                  Payout settlement is not configured.
                </p>
                {d.financials.length ? (
                  d.financials.map((p: any) => (
                    <article key={p.id}>
                      {p.mode.toUpperCase()} · ₦{p.amount.toLocaleString()} ·{" "}
                      {p.status}
                      <p>Order {p.order_id}</p>
                    </article>
                  ))
                ) : (
                  <p>No online payments recorded.</p>
                )}
              </>
            ) : (
              <>
                <h2>Support and reports</h2><a href="/messages" className="secondary-button">Buyer & seller messages</a>
                <p>Track an issue, request a refund review or contact the team about an order.</p>
                <div className="support-form-grid">
                <form className="support-card" onSubmit={(e) => form(e, "refund-request")}>
                  <span className="support-kicker">PAYMENTS &amp; RETURNS</span><h3>Request a refund review</h3>
                  <p>Approval does not mean money has been refunded. We will show the provider-confirmed status.</p>
                  {field("id", "Paid order ID", "text", supportOrder)}
                  <label>Reason (at least 10 characters)<input name="reason" required minLength={10} maxLength={1000} /></label>
                  <button disabled={busy}>Request refund review</button>
                </form>
                <form className="support-card" onSubmit={(e) => form(e, "report")}>
                  <span className="support-kicker">ORDER &amp; MARKETPLACE HELP</span><h3>Open a support case</h3><p>Choose what happened and provide the item or order reference.</p>
                  <label>
                    Type
                    <select name="target_type" defaultValue={supportOrder ? "order" : "product"}>
                      {["product", "store", "stream", "order", "return"].map(
                        (t) => (
                          <option key={t}>{t}</option>
                        ),
                      )}
                    </select>
                  </label>
                  {field("target", "Item or order ID", "text", supportOrder)}
                  {field("reason", "Reason")}
                  <label>
                    Describe the problem
                    <textarea name="details" minLength={10} required />
                  </label>
                  <button disabled={busy}>Submit case</button>
                </form>
                </div><h3>Your cases</h3>
                {!d.myReports.length && <p className="support-empty">No cases yet. Your requests and responses will appear here.</p>}
                {d.myReports.map((r: any) => (
                  <article className="support-case" key={r.id}>
                    <strong>{r.reason}</strong>
                    <p>
                      {r.status} · {r.resolution || "Awaiting review"}
                    </p>
                  </article>
                ))}
              </>
            )}
          </section>
        </>
      )}
    </main>
  );
}
