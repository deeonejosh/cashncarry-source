"use client";
export default function SkipLink() {
  return (
    <a
      className="skip-link"
      href="#main-content"
      onClick={(event) => {
        const main = document.getElementById("main-content");
        if (main) {
          event.preventDefault();
          main.focus();
          main.scrollIntoView({ block: "start" });
        }
      }}
    >
      Skip to main content
    </a>
  );
}
