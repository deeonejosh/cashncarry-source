import { env } from "cloudflare:workers";
export type MfaSession = {
  session: { id: string; expiresAt: Date | string };
  user: {
    id: string;
    email: string;
    emailVerified: boolean;
    twoFactorEnabled?: boolean;
  };
};
/** An enabled account alone cannot authenticate an older pre-enrolment session. */
export async function recordMfaSession(session: MfaSession) {
  if (!env.DB || !session.user.emailVerified || !session.user.twoFactorEnabled)
    throw Error("Verified MFA session required");
  const expiresAt = Math.min(
    new Date(session.session.expiresAt).getTime(),
    Date.now() + 8 * 60 * 60 * 1000,
  );
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now())
    throw Error("Session expired");
  await env.DB.prepare(
    "INSERT INTO platform_settings(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated",
  )
    .bind(
      "admin_mfa_session:" + session.session.id,
      JSON.stringify({
        userId: session.user.id,
        email: session.user.email.toLowerCase(),
        expiresAt,
      }),
      new Date().toISOString(),
    )
    .run();
}
export async function sessionHasMfa(session: MfaSession) {
  if (!env.DB || !session.user.emailVerified || !session.user.twoFactorEnabled)
    return false;
  const row = await env.DB.prepare(
    "SELECT value FROM platform_settings WHERE key=?",
  )
    .bind("admin_mfa_session:" + session.session.id)
    .first<{ value: string }>();
  try {
    const proof = JSON.parse(row?.value || "null");
    return Boolean(
      proof &&
      proof.userId === session.user.id &&
      proof.email === session.user.email.toLowerCase() &&
      Number.isFinite(proof.expiresAt) &&
      proof.expiresAt > Date.now(),
    );
  } catch {
    return false;
  }
}
/** Merge provider-set session cookies after enrolment/challenge without exposing their values. */
export function mfaResponseHeaders(request: Request, response: Response) {
  const jar = new Map<string, string>();
  for (const part of (request.headers.get("cookie") || "").split(/;\s*/)) {
    const i = part.indexOf("=");
    if (i > 0) jar.set(part.slice(0, i), part.slice(i + 1));
  }
  const cookies =
    response.headers.getSetCookie?.() ||
    (response.headers.get("set-cookie") || "").split(/,(?=\s*[^;,=\s]+=)/);
  for (const cookie of cookies) {
    const part = cookie.split(";")[0].trim(),
      i = part.indexOf("=");
    if (i > 0) jar.set(part.slice(0, i), part.slice(i + 1));
  }
  const headers = new Headers(request.headers);
  headers.set("cookie", [...jar].map(([k, v]) => k + "=" + v).join("; "));
  return headers;
}

