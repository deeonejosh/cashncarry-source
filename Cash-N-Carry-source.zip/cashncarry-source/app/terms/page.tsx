import PolicyPage, { policyMetadata } from "../policy-page";
export const dynamic = "force-dynamic";
export const generateMetadata = () => policyMetadata("terms");
export default function Page() { return PolicyPage({ policyId: "terms" }); }
