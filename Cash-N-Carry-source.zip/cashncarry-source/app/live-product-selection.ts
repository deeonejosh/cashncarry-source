/** Client-side guidance only. Checkout must still recalculate from server records. */
type LiveOption = { name: string; stock: number; price?: number };
type LiveProduct = { name?: string; stock?: number; price?: number; variants?: string } | null | undefined;
export function liveProductSelection(product: LiveProduct, option = "", quantity = 1) {
  let variants: LiveOption[] = [];
  try {
    const parsed = JSON.parse(product?.variants || "[]");
    if (!Array.isArray(parsed) || !parsed.every(v => v && typeof v.name === "string" && Number.isFinite(v.stock) && v.stock >= 0)) throw new Error("Invalid options");
    variants = parsed;
  } catch { /* Treat malformed option data as unavailable, never as a base-price fallback. */
    return { variants, variant: undefined, stock: 0, price: product?.price, needsOption: false, error: "Product options are unavailable. Reopen the product and try again." };
  }
  const variant = variants.find(v => v.name === option);
  const stock = Math.max(0, Number(variants.length ? variant?.stock || 0 : product?.stock || 0));
  const needsOption = variants.length > 0 && !variant;
  const error = !product ? "Product unavailable. Choose another product."
    : needsOption ? `Choose an available option for ${product.name}.`
    : !stock ? "This option or product is sold out. Choose another available option or product."
    : !Number.isSafeInteger(quantity) || quantity < 1 || quantity > Math.min(stock, 99) ? `Choose a quantity from 1 to ${Math.min(stock, 99)}.`
    : "";
  return { variants, variant, stock, price: variant?.price ?? product?.price, needsOption, error };
}
