"use client";
import {useEffect,useState} from 'react';
import {subscriptionDisplay} from '../subscription-display';
import {sellerMoney} from '../seller-money';
export function SubscriptionSummary({activation,priceMinor,onRenew,compact=false}:{activation:any;priceMinor:number;onRenew?:()=>void;compact?:boolean}){
 const [now,setNow]=useState(Date.now);
 useEffect(()=>{const timer=window.setInterval(()=>setNow(Date.now()),60000);return()=>window.clearInterval(timer);},[]);
 const display=subscriptionDisplay(activation,now);
 return <section className={'subscription-summary subscription-'+display.state+(compact?' subscription-compact':'')} aria-label="Your seller subscription">
 <div className="subscription-summary-header"><div><p className="eyebrow">CASH N CARRY SELLER</p><h2>Your subscription</h2></div><span className={'subscription-badge status-'+display.state}>{display.label}</span></div>
 <div className="subscription-summary-facts"><div><span>Access expires</span><strong>{activation.paidUntil?<time dateTime={activation.paidUntil}>{display.expiry}</time>:display.expiry}</strong></div><div><span>Monthly plan</span><strong>{sellerMoney(priceMinor)} <small>/ month</small></strong></div></div>
 <p className="subscription-summary-guidance">{display.guidance}</p>
 <p className="subscription-summary-note">{activation.mode==='test'?'Sandbox access · ':''}{activation.autoRenewal?'Automatic monthly renewal confirmed by Flutterwave':activation.billingStatus==='payment_failed'?'Renewal payment failed · review payment status':activation.billingStatus==='provider_confirmation_pending'?'Recurring plan attached; checking provider subscription status':activation.cancelAtEnd?'Automatic renewal cancelled · paid access remains until expiry':'Automatic renewal is not confirmed'}{activation.cancelAtEnd?' · Renewal cancellation recorded':''}</p>
 {onRenew?<button className="subscription-main-action" onClick={onRenew}>{display.action}</button>:compact?<div className="subscription-summary-actions"><a className="subscription-main-action" href="/seller/finance?tab=Subscription">{display.action}</a><a href="/seller/finance?tab=History">Payment history</a></div>:null}
 </section>;
}
