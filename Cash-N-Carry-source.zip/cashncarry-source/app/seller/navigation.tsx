"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Activity,
  BadgeDollarSign,
  Boxes,
  ChevronDown,
  CircleUserRound,
  ClipboardList,
  FileCheck2,
  FileSpreadsheet,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Package,
  Radio,
  Settings,
  ShoppingBag,
  Store,
  Truck,
  Video,
  Wallet,
  X,
} from "lucide-react";

const groups = [
  ["Overview", [["Dashboard", "/?browse=1&sellerTab=Overview#seller", LayoutDashboard]]],
  ["Selling", [
    ["Products", "/?browse=1&sellerTab=Products#seller", ShoppingBag],
    ["Bulk Product Upload", "/seller/bulk-upload", FileSpreadsheet],
    ["Orders", "/?browse=1&sellerTab=Orders#seller", Package],
    ["Storefront", "/?browse=1&sellerTab=Store#seller", Store],
    ["My Website", "/seller/website", Store],
    ["Shipping", "/workspace?tab=Delivery", Truck],
    ["Product Videos", "/seller/videos", Video],
    ["Bundles", "/seller/competitive?tab=Bundles", Boxes],
  ]],
  ["Livestream", [
    ["Livestream Studio", "/workspace?tab=Broadcasts&studio=1", Radio],
    ["Scheduled Lives", "/workspace?tab=Broadcasts", ClipboardList],
    ["Live Deals", "/seller/competitive?tab=Live%20Deals", BadgeDollarSign],
    ["Auctions", "/seller/competitive?tab=Auctions", Activity],
  ]],
  ["Growth", [
    ["Analytics", "/seller/competitive?tab=Analytics", Activity],
    ["Affiliates", "/seller/competitive?tab=Affiliates", CircleUserRound],
    ["Founding Seller", "/seller/competitive?tab=Founding%20Seller", Store],
  ]],
  ["Customers", [["Customer Messages", "/messages", MessageSquare]]],
  ["Finances", [
    ["Earnings", "/seller/finance?tab=Earnings", Wallet],
    ["Withdraw funds", "/seller/finance?tab=Withdrawals", BadgeDollarSign],
    ["Transactions", "/seller/finance?tab=History", ClipboardList],
  ]],
  ["Account", [
    ["Verification", "/seller/finance?tab=Activation", FileCheck2],
    ["Subscription", "/seller/finance?tab=Subscription", BadgeDollarSign],
    ["Bank accounts", "/seller/finance?tab=Bank%20account", Wallet],
    ["Settings", "/workspace?tab=Account", Settings],
  ]],
] as const;

export default function SellerNavigation({ active = "" }: { active?: string }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!open) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", closeOnEscape);
    return () => document.removeEventListener("keydown", closeOnEscape);
  }, [open]);

  const navContents = (mobile = false) => (
    <nav className="seller-full-menu" aria-label={mobile ? "Seller Centre navigation" : "All Seller Centre tools"}>
      {groups.map(([group, items]) => (
        <section key={group}>
          <h2>{group}</h2>
          {items.map(([label, href, Icon]) => (
            <Link
              key={label}
              href={href}
              aria-current={active === label ? "page" : undefined}
              onClick={() => mobile && setOpen(false)}
            >
              <Icon size={17} aria-hidden="true" />
              <span>{label}</span>
            </Link>
          ))}
        </section>
      ))}
    </nav>
  );

  return (
    <>
      <aside className="seller-sidebar" aria-label="Seller Centre tools">
        <p className="seller-sidebar-label">SELLER CENTRE</p>
        {navContents()}
        <Link className="seller-sidebar-market" href="/?browse=1">Return to marketplace</Link>
      </aside>
      <div className="seller-mobile-drawer-wrap">
        <button
          type="button"
          className="seller-menu-trigger"
          aria-expanded={open}
          aria-controls="seller-mobile-drawer"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
          <span>{open ? "Close menu" : "Seller tools"}</span>
          <ChevronDown size={17} aria-hidden="true" />
        </button>
        {open && <button className="seller-drawer-scrim" aria-label="Close seller menu" onClick={() => setOpen(false)} />}
        <div id="seller-mobile-drawer" className={`seller-mobile-drawer${open ? " is-open" : ""}`} hidden={!open}>
          <div className="seller-mobile-drawer-heading">
            <strong>Seller Centre</strong>
            <button type="button" aria-label="Close seller menu" onClick={() => setOpen(false)}><X size={19} /></button>
          </div>
          {navContents(true)}
        </div>
      </div>
    </>
  );
}
