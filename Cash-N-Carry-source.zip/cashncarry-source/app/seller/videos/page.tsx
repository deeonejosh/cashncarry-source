import { requireChatGPTUser } from "../../chatgpt-auth";
import SellerVideos from "./manager";
export const dynamic = "force-dynamic";
export const metadata = { title: "Product Videos | Seller Centre | Cash N Carry", robots: { index: false, follow: false } };
export default async function SellerVideosPage() {
  await requireChatGPTUser("/seller/videos");
  return <main id="main-content" className="seller-tool-page"><SellerVideos/></main>;
}
