"use client";
import {useEffect,useState} from 'react';
import {ArrowUpRight, CircleDollarSign, Clock3, ShieldCheck, Wallet} from 'lucide-react';
import {sellerMoney} from '../seller-money';
import {SubscriptionSummary} from './subscription-summary';
export function SellerActivationCard(){
 const [data,setData]=useState<any>(null),[error,setError]=useState('');
 useEffect(()=>{let mounted=true;fetch('/api/seller-finance').then(async r=>{const d:any=await r.json();if(!r.ok)throw Error(d.error);if(mounted)setData(d);}).catch(()=>{if(mounted)setError('Unable to load your current subscription. Open subscription settings to retry.');});return()=>{mounted=false;};},[]);
 return <section className="seller-activation-card" aria-label="Selling access">
 {data?<>
   <SubscriptionSummary activation={data.activation} priceMinor={data.activation.monthlyPriceMinor||data.settings.priceMinor} compact/>
   <div className="seller-verification-strip">
     <span className="seller-verification-icon"><ShieldCheck size={20}/></span>
     <div><strong>Verification</strong><p><span className="seller-status-word">{data.activation.verification.replaceAll('_',' ')}</span> · {data.activation.canSell?'Selling enabled':'Selling paused until verification and subscription are complete'}</p></div>
     <a href="/seller/finance?tab=Activation">Review verification <ArrowUpRight size={16}/></a>
   </div>
   <div className="finance-stats" aria-label="Seller earnings summary">
     <section className="panel earnings-card earnings-available"><div className="earnings-card-heading"><span><Wallet size={20}/></span><small>Available</small></div><strong>{sellerMoney(data.earnings.availableMinor)}</strong><a href="/seller/finance?tab=Withdrawals">Withdrawal options <ArrowUpRight size={15}/></a></section>
     <section className="panel earnings-card"><div className="earnings-card-heading"><span className="is-blue"><Clock3 size={20}/></span><small>Pending / held</small></div><strong>{sellerMoney(data.earnings.pendingMinor)}</strong><p>Recorded from eligible orders</p></section>
     <section className="panel earnings-card"><div className="earnings-card-heading"><span className="is-ochre"><CircleDollarSign size={20}/></span><small>Reserved</small></div><strong>{sellerMoney(data.earnings.reservedMinor)}</strong><p>Reserved for withdrawal requests</p></section>
   </div>
   <details className="seller-activation-details"><summary>Your selling setup</summary><ol className="seller-activation-steps" aria-label="Seller activation steps"><li>1. Register ✓</li><li>2. Verify identity {data.activation.verification==='verified'?'✓':'— action needed'}</li><li>3. Subscribe {data.activation.subscription==='active'?'✓':'— action needed'}</li><li>4. Start selling {data.activation.canSell?'✓':'— locked'}</li></ol></details>
 </>:<div className="panel"><h2>Your seller subscription</h2><p role={error?'alert':'status'}>{error||'Loading subscription status…'}</p><a href="/seller/finance?tab=Subscription">Subscription settings</a></div>}
 </section>;
}
