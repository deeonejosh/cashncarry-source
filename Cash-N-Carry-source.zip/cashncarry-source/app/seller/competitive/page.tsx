import {redirect} from "next/navigation";
import {getChatGPTUser} from "../../chatgpt-auth";
import SellerCompetitivePanel from "../competitive-panel";
export const dynamic="force-dynamic";
export const metadata={title:"Seller growth tools — Cash N Carry",robots:{index:false,follow:false}};
export default async function Page(){if(!await getChatGPTUser())redirect("/sign-in?returnTo=%2Fseller%2Fcompetitive");return <SellerCompetitivePanel/>;}
