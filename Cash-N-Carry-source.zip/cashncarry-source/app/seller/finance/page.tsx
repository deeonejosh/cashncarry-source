import {redirect} from 'next/navigation';
import {getChatGPTUser} from '../../chatgpt-auth';
import SellerFinancePanel from './panel';
export const dynamic='force-dynamic';
export const metadata={title:'Seller subscription & earnings — Cash N Carry',robots:{index:false,follow:false}};
export default async function Page(){if(!await getChatGPTUser())redirect('/sign-in?returnTo=%2Fseller%2Ffinance');return <SellerFinancePanel/>;}
