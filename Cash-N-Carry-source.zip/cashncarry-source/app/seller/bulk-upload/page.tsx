import { redirect } from "next/navigation";
import { getChatGPTUser } from "../../chatgpt-auth";
import SellerNavigation from "../navigation";
import BulkProductUpload from "./upload";
import "./bulk-upload.css";

export const dynamic = "force-dynamic";
export const metadata = { title: "Bulk product upload — Cash N Carry", robots: { index: false, follow: false } };

export default async function Page() {
  if (!await getChatGPTUser()) redirect("/sign-in?returnTo=%2Fseller%2Fbulk-upload");
  return <main className="seller-bulk-page"><div className="seller-bulk-shell"><SellerNavigation active="Bulk Upload"/><BulkProductUpload/></div></main>;
}
