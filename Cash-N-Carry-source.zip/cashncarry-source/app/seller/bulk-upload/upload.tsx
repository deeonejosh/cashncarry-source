"use client";
/* eslint-disable @typescript-eslint/no-explicit-any */

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import ImageAsset from "../../image-asset";
import { optimizeProductImage } from "../../optimize-product-image";
import { Download, FileSpreadsheet, History, LoaderCircle, RefreshCw, Upload, AlertTriangle, CheckCircle2, CircleHelp, ArrowLeft, ExternalLink } from "lucide-react";
import {
  BULK_PRODUCT_MAX_FILE_BYTES,
  splitBulkImageUrls,
} from "../../bulk-product-utils.mjs";

type ProductRow = { rowNumber: number; name: string; description: string; category: string; price: number | string; sku: string; stock: number | string; image: string; images: string[]; status: string; errors?: string[]; statusCode?: string; imagePreviewAllowed?: boolean };
type Preview = { rows: ProductRow[]; total: number; valid: number; invalid: number; duplicates: number; canImport: boolean; accessMessage?: string };
type HistoryRow = { id: string; status: string; total: number; imported: number; failed: number; duplicates: number; created: string; updated: string };
type ImageQuota = { policy: { dailyImages: number; dailyBytes: number; maxImageBytes: number }; usedCount: number; usedBytes: number; reservedCount?: number; reservedBytes?: number; remainingCount: number; remainingBytes: number; resetsAt: string };
const uuid = () => crypto.randomUUID();
const label = (status: string) => status === "imported" ? "Imported" : status === "failed" ? "Needs correction" : status === "duplicate" ? "Skipped duplicate" : "Ready";

export default function BulkProductUpload() {
  const [categories, setCategories] = useState<string[]>([]);
  const [canSell, setCanSell] = useState(false);
  const [accessMessage, setAccessMessage] = useState("");
  const [history, setHistory] = useState<HistoryRow[]>([]);
  const [fileName, setFileName] = useState("");
  const [rows, setRows] = useState<ProductRow[]>([]);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [result, setResult] = useState<any>(null);
  const [importId, setImportId] = useState("");
  const [importValidOnly, setImportValidOnly] = useState(true);
  const [confirm, setConfirm] = useState(false);
  const [imageQuota, setImageQuota] = useState<ImageQuota | null>(null);
  const [imageUploads, setImageUploads] = useState<Record<number, { busy: boolean; error: string; progress: number; phase?: "optimizing" | "uploading" }>>({});
  const fileRef = useRef<HTMLInputElement>(null);
  const imageRetryRequests = useRef<Record<number, { signature: string; id: string }>>({});

  const load = async () => {
    const response = await fetch("/api/seller/bulk-products", { cache: "no-store" });
    const body: any = await response.json();
    if (!response.ok) throw Error(body.error || "Could not load bulk upload.");
    setCategories(body.categories || []);
    setCanSell(Boolean(body.canSell));
    setAccessMessage(body.activation?.message || "Seller verification and an active subscription are required before importing products.");
    setHistory(body.history || []);
    try { const quotaResponse = await fetch("/api/media", { cache: "no-store" }); const quotaBody: any = await quotaResponse.json(); if (quotaResponse.ok) setImageQuota(quotaBody); } catch { /* Image-free product imports remain available if quota details cannot load. */ }
  };

  useEffect(() => {
    let active = true;
    fetch("/api/seller/bulk-products", { cache: "no-store" })
      .then(async (response) => {
        const body: any = await response.json();
        if (!response.ok) throw Error(body.error || "Could not load bulk upload.");
        if (active) {
          setCategories(body.categories || []);
          setCanSell(Boolean(body.canSell));
          setAccessMessage(body.activation?.message || "Seller verification and an active subscription are required before importing products.");
          setHistory(body.history || []);
          const quotaResponse = await fetch("/api/media", { cache: "no-store" });
          const quotaBody: any = await quotaResponse.json();
          if (quotaResponse.ok) setImageQuota(quotaBody);
        }
      })
      .catch((loadError) => { if (active) setError(loadError.message || "Could not load bulk upload."); });
    return () => { active = false; };
  }, []);

  const downloadTemplate = async () => {
    const { createBulkProductTemplate } = await import("../../bulk-product-template.mjs");
    const file = new Blob([createBulkProductTemplate()], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    const url = URL.createObjectURL(file);
    const link = document.createElement("a");
    link.href = url;
    link.download = "cash-n-carry-product-template.xlsx";
    link.click();
    URL.revokeObjectURL(url);
  };

  const reset = () => {
    setRows([]); setPreview(null); setResult(null); setError(""); setProgress(0); setFileName(""); setImportId(""); setConfirm(false);
    if (fileRef.current) fileRef.current.value = "";
  };

  const parseFile = async (file?: File) => {
    if (!file) return;
    setError(""); setResult(null); setPreview(null);
    const ext = file.name.split(".").pop()?.toLocaleLowerCase();
    if (ext !== "xlsx") { setError("Choose an Excel .xlsx file. Save CSV files as .xlsx before uploading."); return; }
    if (file.size <= 0 || file.size > BULK_PRODUCT_MAX_FILE_BYTES) { setError("The workbook must be smaller than 5 MB."); return; }
    setBusy(true); setFileName(file.name);
    try {
      const { parseBulkProductWorkbook } = await import("../../bulk-product-parser.mjs");
      const parsed = parseBulkProductWorkbook(await file.arrayBuffer()) as ProductRow[];
      setRows(parsed);
      setImportId(uuid());
    } catch (e: any) {
      setError(e?.message || "This workbook could not be read. Download the template and try again.");
      setRows([]);
    } finally { setBusy(false); }
  };

  const validate = async () => {
    if (!rows.length) return;
    setBusy(true); setError(""); setResult(null); setProgress(0);
    try {
      const response = await fetch("/api/seller/bulk-products", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "preview", rows }), cache: "no-store" });
      const body: any = await response.json();
      if (!response.ok) throw Error(body.error || "Unable to validate these products.");
      setPreview(body); setRows(body.rows); setCanSell(Boolean(body.canImport)); setAccessMessage(body.accessMessage || "");
    } catch (e: any) { setError(e.message || "Unable to validate these products."); }
    finally { setBusy(false); }
  };

  const revalidate = async () => {
    const response = await fetch("/api/seller/bulk-products", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "preview", rows }), cache: "no-store" });
    const body: any = await response.json();
    if (!response.ok) throw Error(body.error || "Unable to validate these products.");
    setRows(body.rows); setPreview(body); setCanSell(Boolean(body.canImport)); setAccessMessage(body.accessMessage || "");
  };

  const edit = (rowNumber: number, key: keyof ProductRow, value: unknown) => {
    setRows((current) => current.map((row) => row.rowNumber === rowNumber ? { ...row, [key]: key === "images" ? splitBulkImageUrls(value) : value, ...(key === "image" ? { imagePreviewAllowed: false } : {}) } : row));
    setPreview((current) => current ? { ...current, rows: current.rows.map((row) => row.rowNumber === rowNumber ? { ...row, [key]: value } : row) } : current);
  };

  const uploadProductImage = async (rowNumber: number, file?: File) => {
    if (!file) return;
    const maxImageBytes = imageQuota?.policy.maxImageBytes || 10 * 1024 * 1024;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || !file.size || file.size > maxImageBytes) {
      setImageUploads((current) => ({ ...current, [rowNumber]: { busy: false, error: `Choose a JPG, PNG or WebP photo up to ${Math.round(maxImageBytes / (1024 * 1024))} MB.`, progress: 0 } }));
      return;
    }
    setImageUploads((current) => ({ ...current, [rowNumber]: { busy: true, error: "", progress: 0, phase: "optimizing" } }));
    try {
      const prepared = await optimizeProductImage(file);
      setImageUploads((current) => ({ ...current, [rowNumber]: { busy: true, error: "", progress: 0, phase: "uploading" } }));
      const signature = `${prepared.name}:${prepared.size}:${prepared.lastModified}:${prepared.type}`;
      if (!imageRetryRequests.current[rowNumber] || imageRetryRequests.current[rowNumber].signature !== signature) imageRetryRequests.current[rowNumber] = { signature, id: crypto.randomUUID() };
      const requestId = imageRetryRequests.current[rowNumber].id;
      const form = new FormData(); form.append("file", prepared);
      const uploaded = await new Promise<{ url: string; quota?: ImageQuota }>((resolve, reject) => {
        const request = new XMLHttpRequest();
        request.open("POST", "/api/media"); request.timeout = 60000; request.setRequestHeader("Idempotency-Key", requestId);
        request.upload.onprogress = (event) => {
          if (event.lengthComputable) setImageUploads((current) => ({ ...current, [rowNumber]: { busy: true, error: "", phase: "uploading", progress: Math.round(event.loaded / event.total * 100) } }));
        };
        request.onload = () => {
          let body: any = {};
          try { body = JSON.parse(request.responseText); } catch { /* handled as an upload failure below */ }
          if (request.status >= 200 && request.status < 300 && typeof body.url === "string") resolve({ url: body.url, quota: body.quota });
          else reject(Error(body.error || "Photo upload failed. Try again."));
        };
        request.onerror = () => reject(Error("Photo upload failed. Check your connection and retry."));
        request.ontimeout = () => reject(Error("Photo upload timed out. Retry when your connection is stable."));
        request.onabort = () => reject(Error("Photo upload was interrupted. Retry the upload."));
        request.send(form);
      });
      setRows((current) => current.map((row) => row.rowNumber === rowNumber ? { ...row, image: uploaded.url, imagePreviewAllowed: true } : row));
      setPreview((current) => current ? { ...current, rows: current.rows.map((row) => row.rowNumber === rowNumber ? { ...row, image: uploaded.url, imagePreviewAllowed: true } : row) } : current);
      if (uploaded.quota) setImageQuota({ ...uploaded.quota, remainingCount: Math.max(0, uploaded.quota.policy.dailyImages - uploaded.quota.usedCount - (uploaded.quota.reservedCount || 0)), remainingBytes: Math.max(0, uploaded.quota.policy.dailyBytes - uploaded.quota.usedBytes - (uploaded.quota.reservedBytes || 0)) });
      delete imageRetryRequests.current[rowNumber];
      setImageUploads((current) => ({ ...current, [rowNumber]: { busy: false, error: "", progress: 100 } }));
    } catch (uploadError: any) {
      setImageUploads((current) => ({ ...current, [rowNumber]: { busy: false, error: uploadError.message || "Photo upload failed. Try again.", progress: 0 } }));
    }
  };

  const importProducts = async () => {
    if (!preview || !canSell) return;
    const candidates = rows;
    const productCount = rows.filter((row) => !row.errors?.length && !["failed", "duplicate"].includes(row.statusCode || "")).length;
    if (!productCount) { setError("There are no valid products to import."); return; }
    const selected = candidates.map((row) => ({ ...row, rowNumber: row.rowNumber }));
    setConfirm(false); setBusy(true); setError(""); setProgress(0); setResult(null);
    try {
      const response = await fetch("/api/seller/bulk-products", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "import", importId, rows: selected }), cache: "no-store" });
      if (!response.ok) { const body: any = await response.json(); throw Error(body.error || "Import could not start."); }
      const contentType = response.headers.get("content-type") || "";
      if (!contentType.includes("application/x-ndjson") || !response.body) {
        const body: any = await response.json(); setResult(body); setProgress(100); await load(); return;
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let complete: any = null;
      while (true) {
        const { value, done } = await reader.read();
        buffer += decoder.decode(value || new Uint8Array(), { stream: !done });
        const lines = buffer.split("\n"); buffer = lines.pop() || "";
        for (const line of lines) if (line.trim()) {
          const event = JSON.parse(line);
          if (event.type === "progress") setProgress(event.total ? Math.round(event.completed / event.total * 100) : 100);
          if (event.type === "complete") complete = event;
          if (event.type === "error") throw Error(event.error);
        }
        if (done) break;
      }
      if (complete) { setResult(complete); setProgress(100); setPreview(null); await load(); }
      else throw Error("The import connection ended before the result arrived. Retry the same import to reconcile completed rows.");
    } catch (e: any) { setError(e.message || "Import interrupted. Retry the same import to reconcile completed rows."); }
    finally { setBusy(false); }
  };

  const showHistory = async (id: string) => {
    try { const response = await fetch(`/api/seller/bulk-products?import=${encodeURIComponent(id)}`, { cache: "no-store" }); const body: any = await response.json(); if (!response.ok) throw Error(body.error); setResult({ import: body.import, rows: body.rows }); setPreview(null); setRows([]); }
    catch (e: any) { setError(e.message); }
  };

  const downloadErrorReport = (source = result?.rows || rows) => {
    const entries = source.map((row: any) => ({
      "Spreadsheet row": row.rowNumber,
      "Product name": row.name || "",
      SKU: row.sku || "",
      Status: label(row.statusCode || row.status || "failed"),
      Errors: Array.isArray(row.errors) ? row.errors.join("; ") : row.errors || "",
    })).filter((row: any) => row.Errors || row.Status !== "Imported");
    if (!entries.length) return;
    const csvRows: unknown[][] = [Object.keys(entries[0]), ...entries.map((item: any) => Object.values(item))];
    const csv = csvRows.map((cells: unknown[]) => cells.map((value: unknown) => {
      const cell = String(value ?? "");
      const safe = /^[=+\-@\t\r]/.test(cell) ? `'${cell}` : cell;
      return `"${safe.replace(/"/g, '""')}"`;
    }).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a"); link.href = url; link.download = "cash-n-carry-import-results.csv"; link.click(); URL.revokeObjectURL(url);
  };

  return <section className="bulk-upload-content">
    <header className="bulk-upload-header"><Link href="/?browse=1&sellerTab=Products#seller" className="bulk-back-link"><ArrowLeft size={17}/> Products</Link><p className="eyebrow">SELLER CENTRE · PRODUCT TOOLS</p><h1>Bulk product upload</h1><p>Add many products using one Excel workbook. We check every row before anything is saved.</p></header>
    {error && <div className="bulk-alert is-error" role="alert"><AlertTriangle size={19}/><span>{error}</span></div>}
    {!canSell && <div className="bulk-alert is-info" role="status"><CircleHelp size={19}/><span>{accessMessage || "Complete seller verification and keep selling access active before importing products."} <a href="/seller/finance?tab=Activation">Review seller status</a></span></div>}

    {!result && <div className="bulk-upload-grid">
      <section className="bulk-card bulk-start-card">
        <div className="bulk-card-heading"><span className="bulk-icon"><FileSpreadsheet size={20}/></span><div><h2>1. Get the template</h2><p>Start with the Cash N Carry columns so every field maps to a real product setting.</p></div></div>
        <button type="button" className="bulk-template-button" onClick={() => downloadTemplate().catch((e) => setError(e.message))}><Download size={18}/> Download Excel template</button>
        <details className="bulk-field-guide"><summary>What the spreadsheet supports</summary><ul><li>Product name, description and active Cash N Carry category</li><li>Price in whole NGN, optional unique SKU, and stock count</li><li>Images are optional. Upload product photos from your device in the preview or after import.</li><li>Draft or Publish; blank status defaults to Draft</li><li>Variants, sale prices and per-product shipping are not supported by the current product form</li></ul></details>
      </section>
      <section className="bulk-card bulk-upload-card">
        <div className="bulk-card-heading"><span className="bulk-icon"><Upload size={20}/></span><div><h2>2. Upload your workbook</h2><p>Excel .xlsx only · Up to 5 MB · Maximum 500 product rows.</p></div></div>
        <input ref={fileRef} className="bulk-file-input" type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={(event) => parseFile(event.currentTarget.files?.[0])} aria-label="Choose an Excel workbook" />
        <button type="button" className="bulk-dropzone" onClick={() => fileRef.current?.click()} disabled={busy}>
          {busy && !preview ? <LoaderCircle className="bulk-spin" size={26}/> : <FileSpreadsheet size={27}/>}<strong>{fileName || "Choose an .xlsx file"}</strong><span>{fileName ? "Choose a different workbook" : "Tap to browse files on your device"}</span>
        </button>
        {rows.length > 0 && !preview && <div className="bulk-file-ready"><CheckCircle2 size={17}/><span>{rows.length} product rows read from {fileName}</span><button type="button" onClick={validate} disabled={busy}>{busy ? "Checking…" : "Validate products"}</button></div>}
      </section>
    </div>}

    {preview && !result && <section className="bulk-card bulk-preview-card">
      <div className="bulk-preview-heading"><div><p className="eyebrow">3. REVIEW BEFORE IMPORT</p><h2>Product preview</h2><p>Correct fields in the preview, then select Revalidate. Nothing is saved until you confirm Import.</p></div><button type="button" className="bulk-secondary" onClick={() => revalidate().catch((e) => setError(e.message))} disabled={busy}><RefreshCw size={16}/> Revalidate</button></div>
      {imageQuota && <p className="bulk-upload-quota" role="status">Images uploaded today: {imageQuota.usedCount} of {imageQuota.policy.dailyImages} · {Math.ceil(imageQuota.usedBytes / (1024 * 1024))} MB of {Math.round(imageQuota.policy.dailyBytes / (1024 * 1024))} MB. Up to {Math.round(imageQuota.policy.maxImageBytes / (1024 * 1024))} MB each. Missing images are allowed; you can continue without one. Resets at midnight UTC.</p>}
      <div className="bulk-summary-grid"><div><strong>{preview.total}</strong><span>Total rows</span></div><div className="is-good"><strong>{preview.valid}</strong><span>Valid products</span></div><div className="is-bad"><strong>{preview.invalid}</strong><span>Rows to correct</span></div><div className="is-warn"><strong>{preview.duplicates}</strong><span>Duplicates skipped</span></div></div>
      <div className="bulk-import-choice"><label><input type="radio" checked={importValidOnly} onChange={() => setImportValidOnly(true)}/> Import valid rows only; skip rows with errors</label><label><input type="radio" checked={!importValidOnly} onChange={() => setImportValidOnly(false)} disabled={preview.invalid > 0 || preview.duplicates > 0}/> Import only after every row is valid</label></div>
      {!preview.canImport && <div className="bulk-alert is-info"><AlertTriangle size={18}/><span>{preview.accessMessage}</span></div>}
      <div className="bulk-mobile-cards">{rows.map((row) => <article className="bulk-product-card" key={row.rowNumber}>
        <div className="bulk-product-card-heading"><strong>Row {row.rowNumber} · {row.name || "Unnamed product"}</strong><span className={`bulk-row-status ${row.statusCode || "ready"}`}>{label(row.statusCode || (row.errors?.length ? "failed" : "ready"))}</span></div>
        <ImageAsset className="bulk-product-card-image" src={row.imagePreviewAllowed ? row.image : row.image || "/image-unavailable.svg"} alt={row.image ? `${row.name} preview` : "No product image added"} loading="lazy" referrerPolicy="no-referrer"/>
        <p className="bulk-no-image-note">{imageUploads[row.rowNumber]?.progress === 100 && !imageUploads[row.rowNumber]?.error ? "Photo uploaded successfully. Confirm import to attach it to this product." : row.image ? "Product photo selected" : "No image added — you can upload one now or after publishing."}</p>
        <label>Product name<input value={row.name} maxLength={100} onChange={(e) => edit(row.rowNumber,"name",e.target.value)}/></label>
        <label>SKU<input maxLength={80} value={row.sku} onChange={(e) => edit(row.rowNumber,"sku",e.target.value)}/></label>
        <label>Category<select value={row.category} onChange={(e) => edit(row.rowNumber,"category",e.target.value)}><option value="">Choose…</option>{categories.map((category) => <option key={category}>{category}</option>)}</select></label>
        <div className="bulk-product-card-fields"><label>Price (NGN)<input type="number" min="100" step="1" value={row.price} onChange={(e) => edit(row.rowNumber,"price",e.target.value)}/></label><label>Stock<input type="number" min="0" max="100000" step="1" value={row.stock} onChange={(e) => edit(row.rowNumber,"stock",e.target.value)}/></label></div>
        <label>Product status<select value={row.status || "Draft"} onChange={(e) => edit(row.rowNumber,"status",e.target.value)}><option>Draft</option><option>Publish</option></select></label>
        <label className="bulk-mobile-file-label">{imageUploads[row.rowNumber]?.busy ? `Uploading photo… ${imageUploads[row.rowNumber].progress}%` : row.image ? "Replace image from device" : "Upload image from device"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={imageUploads[row.rowNumber]?.busy} onChange={(e) => { void uploadProductImage(row.rowNumber,e.currentTarget.files?.[0]); e.currentTarget.value = ""; }}/></label>
        {imageUploads[row.rowNumber]?.busy && <progress className="bulk-image-progress" max="100" value={imageUploads[row.rowNumber].progress}/>}
        {row.image && <button type="button" className="bulk-remove-image" onClick={() => { edit(row.rowNumber,"image",""); setRows((current) => current.map((item) => item.rowNumber === row.rowNumber ? { ...item, imagePreviewAllowed: false } : item)); }}>Remove image</button>}
        {imageUploads[row.rowNumber]?.error && <p className="bulk-image-error" role="alert">{imageUploads[row.rowNumber].error}</p>}
        <details><summary>Edit description and additional image links</summary><label>Description<textarea value={row.description} maxLength={2000} onChange={(e) => edit(row.rowNumber,"description",e.target.value)}/></label><label>Additional image URLs, separated with |<textarea value={row.images.join(" | ")} onChange={(e) => edit(row.rowNumber,"images",e.target.value)}/></label></details>
        {row.errors?.length ? <ul className="bulk-row-errors">{row.errors.map((message,index) => <li key={index}>{message}</li>)}</ul> : null}
      </article>)}</div>
      <div className="bulk-table-scroll"><table className="bulk-preview-table"><thead><tr><th>Row / status</th><th>Product</th><th>Category</th><th>Price (NGN)</th><th>Stock</th><th>SKU</th><th>Image</th><th>Status</th></tr></thead><tbody>{rows.map((row) => <tr key={row.rowNumber}>
        <td><strong>Row {row.rowNumber}</strong><span className={`bulk-row-status ${row.statusCode || "ready"}`}>{label(row.statusCode || (row.errors?.length ? "failed" : "ready"))}</span></td>
        <td className="bulk-name-cell"><label><span className="visually-hidden">Product name, row {row.rowNumber}</span><input value={row.name} maxLength={100} onChange={(e) => edit(row.rowNumber,"name",e.target.value)}/></label><details><summary>Description and additional images</summary><label><span>Description</span><textarea value={row.description} maxLength={2000} onChange={(e) => edit(row.rowNumber,"description",e.target.value)}/></label><label><span>Additional image URLs, separated with |</span><textarea value={row.images.join(" | ")} onChange={(e) => edit(row.rowNumber,"images",e.target.value)}/></label></details>{row.errors?.length ? <ul className="bulk-row-errors">{row.errors.map((message, index) => <li key={index}>{message}</li>)}</ul> : null}</td>
        <td><label><span className="visually-hidden">Category, row {row.rowNumber}</span><select value={row.category} onChange={(e) => edit(row.rowNumber,"category",e.target.value)}><option value="">Choose…</option>{categories.map((category) => <option key={category}>{category}</option>)}</select></label></td>
        <td><label><span className="visually-hidden">Price in naira, row {row.rowNumber}</span><input type="number" min="100" step="1" value={row.price} onChange={(e) => edit(row.rowNumber,"price",e.target.value)}/></label></td>
        <td><label><span className="visually-hidden">Stock quantity, row {row.rowNumber}</span><input type="number" min="0" max="100000" step="1" value={row.stock} onChange={(e) => edit(row.rowNumber,"stock",e.target.value)}/></label></td>
        <td><label><span className="visually-hidden">SKU, row {row.rowNumber}</span><input maxLength={80} value={row.sku} onChange={(e) => edit(row.rowNumber,"sku",e.target.value)}/></label></td>
        <td><div className="bulk-image-cell"><ImageAsset src={row.imagePreviewAllowed ? row.image : row.image || "/image-unavailable.svg"} alt={row.image ? `${row.name} preview` : "No product image added"} loading="lazy" referrerPolicy="no-referrer"/><label><span className="visually-hidden">Optional main image URL, row {row.rowNumber}</span><input value={row.image} placeholder="Optional image URL" onChange={(e) => edit(row.rowNumber,"image",e.target.value)}/><input className="bulk-row-file-input" type="file" accept="image/jpeg,image/png,image/webp" aria-label={`Upload image for ${row.name || `row ${row.rowNumber}`}`} disabled={imageUploads[row.rowNumber]?.busy} onChange={(e) => { void uploadProductImage(row.rowNumber,e.currentTarget.files?.[0]); e.currentTarget.value = ""; }}/>{imageUploads[row.rowNumber]?.busy ? <small role="status">{imageUploads[row.rowNumber].phase === "optimizing" ? "Preparing smaller photo…" : `Uploading photo… ${imageUploads[row.rowNumber].progress}%`}</small> : <small>{row.image ? "Replace image from device" : "No image required; upload from device if you like."}</small>}{imageUploads[row.rowNumber]?.busy && imageUploads[row.rowNumber].phase === "uploading" && <progress className="bulk-image-progress" max="100" value={imageUploads[row.rowNumber].progress} />}{imageUploads[row.rowNumber]?.error && <small className="bulk-image-error" role="alert">{imageUploads[row.rowNumber].error}</small>}</label>{row.image && <button type="button" className="bulk-remove-image" onClick={() => { edit(row.rowNumber,"image",""); setRows((current) => current.map((item) => item.rowNumber === row.rowNumber ? { ...item, imagePreviewAllowed: false } : item)); }}>Remove</button>}</div></td>
        <td><label><span className="visually-hidden">Publish status, row {row.rowNumber}</span><select value={row.status || "Draft"} onChange={(e) => edit(row.rowNumber,"status",e.target.value)}><option>Draft</option><option>Publish</option></select></label></td>
      </tr>)}</tbody></table></div>
      <div className="bulk-preview-actions"><button type="button" className="bulk-secondary" onClick={() => downloadErrorReport(rows)} disabled={!preview.invalid && !preview.duplicates}><Download size={16}/> Download error report</button><button type="button" className="bulk-primary" onClick={() => setConfirm(true)} disabled={busy || !preview.canImport || (importValidOnly ? preview.valid === 0 : preview.invalid > 0 || preview.duplicates > 0)}><Upload size={17}/> Import {importValidOnly ? preview.valid : preview.total} products</button></div>
    </section>}

    {busy && (result === null && preview) && <div className="bulk-progress" role="status"><div><span>Importing your products…</span><strong>{progress}%</strong></div><progress value={progress} max="100"/></div>}

    {result && <section className="bulk-card bulk-result-card" aria-live="polite"><div className="bulk-result-icon"><CheckCircle2 size={28}/></div><p className="eyebrow">IMPORT RESULTS</p><h2>{result.import?.status === "completed" ? "Import completed" : result.import?.status === "partial" ? "Import finished with rows to review" : "Import status"}</h2><div className="bulk-summary-grid"><div className="is-good"><strong>{result.import?.imported ?? result.imported ?? 0}</strong><span>Successfully imported</span></div><div className="is-bad"><strong>{result.import?.failed ?? result.failed ?? 0}</strong><span>Failed / needs correction</span></div><div className="is-warn"><strong>{result.import?.duplicates ?? result.duplicates ?? 0}</strong><span>Duplicates skipped</span></div></div>{result.error && <div className="bulk-alert is-error">{result.error}</div>}<div className="bulk-result-actions"><Link className="bulk-primary-link" href="/?browse=1&sellerTab=Products#seller">View imported products <ExternalLink size={16}/></Link><button className="bulk-secondary" type="button" onClick={() => downloadErrorReport(result.rows)}><Download size={16}/> Download error report</button><button className="bulk-secondary" type="button" onClick={reset}>Upload another file</button></div></section>}

    {confirm && preview && <div className="bulk-confirm-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setConfirm(false); }}><section className="bulk-confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="bulk-confirm-title"><h2 id="bulk-confirm-title">Confirm product import</h2><p>You are about to import <strong>{importValidOnly ? preview.valid : preview.total}</strong> product rows. Each row will use its selected Draft or Publish status. Published products still pass seller eligibility and product checks.</p><div className="bulk-confirm-actions"><button className="bulk-secondary" type="button" onClick={() => setConfirm(false)}>Review again</button><button className="bulk-primary" type="button" onClick={importProducts}>Confirm import</button></div></section></div>}

    <section className="bulk-card bulk-history-card"><div className="bulk-preview-heading"><div><span className="bulk-icon"><History size={19}/></span><div><h2>Import history</h2><p>Review results from your last 25 uploads.</p></div></div><button type="button" className="bulk-secondary" onClick={() => load().catch((e) => setError(e.message))}><RefreshCw size={16}/> Refresh</button></div>{history.length ? <div className="bulk-history-list">{history.map((item) => <button type="button" key={item.id} onClick={() => showHistory(item.id)}><span><strong>{new Date(item.created).toLocaleString()}</strong><small>{item.total} rows · {item.imported} imported · {item.failed} errors · {item.duplicates} duplicates</small></span><span className={`bulk-history-status ${item.status}`}>{item.status}</span></button>)}</div> : <p className="bulk-history-empty">Your completed imports will appear here.</p>}</section>
  </section>;
}
