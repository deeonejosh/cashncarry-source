import { redirect } from "next/navigation";
import { getChatGPTUser } from "../chatgpt-auth";
export const dynamic = "force-dynamic";
/** One entry point for both the website and Android Account tab. */
export default async function SellerCentre() {
  if (!(await getChatGPTUser())) redirect("/sign-in?returnTo=%2Fseller");
  redirect("/?browse=1#seller");
}
