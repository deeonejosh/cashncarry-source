import { requireChatGPTUser } from "../../chatgpt-auth";
import { env } from "cloudflare:workers";
import StoreBuilder from "./builder";
export const dynamic = "force-dynamic";
export const metadata = { title: "My Website | Seller Centre | Cash N Carry", robots: { index: false, follow: false } };
export default async function SellerWebsitePage() {
  const user = await requireChatGPTUser("/seller/website");
  // A suspended store still belongs to this seller. Treating it as absent
  // incorrectly offers a second store creation flow that the API must reject.
  const store = await env.DB?.prepare("SELECT id,suspended FROM stores WHERE owner=?").bind(user.userId).first() as { id: string; suspended: number } | null;
  return <main id="main-content" className="seller-tool-page"><StoreBuilder hasStore={Boolean(store)} suspended={Boolean(store?.suspended)}/></main>;
}
