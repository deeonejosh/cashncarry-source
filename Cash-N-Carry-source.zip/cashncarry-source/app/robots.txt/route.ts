import { env } from "cloudflare:workers";
export function GET() {
  const origin = new URL(env.SITE_URL || "https://cashncarryng.com").origin;
  return new Response(
    `User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /admin\nDisallow: /account\nDisallow: /seller\nDisallow: /workspace\nDisallow: /order/\nDisallow: /sign-in\nDisallow: /sign-up\nDisallow: /forgot-password\nDisallow: /payment-return\nSitemap: ${origin}/sitemap.xml\n`,
    {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "public,max-age=3600",
      },
    },
  );
}
