"use client";
import { useEffect, useState } from "react";
export default function AccessPanel() {
  const [rows, setRows] = useState<any[]>([]),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  async function load() {
    try {
      const r = await fetch("/api/admin/access");
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      setRows(d.assignments);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Unable to load access");
    }
  }
  useEffect(() => {
    load();
  }, []);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;
    const f = new FormData(e.currentTarget);
    if (
      !confirm(
        "Apply this administrator access change? Access still requires MFA.",
      )
    )
      return;
    setBusy(true);
    try {
      const r = await fetch("/api/admin/access", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: f.get("userId"),
          role: f.get("role"),
          reason: f.get("reason"),
          confirm: true,
        }),
      });
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      setMessage("Access updated and audited.");
      await load();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Update failed");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="admin-setting-card">
      <h2>Staff access</h2>
      <p>
        Only the configured owner can grant or revoke access. All roles require
        verified email sign-in and MFA. Find the existing account ID in
        Customers; public registration never grants an admin role.
      </p>
      <form onSubmit={submit}>
        <label>
          Existing account ID
          <input name="userId" required />
        </label>
        <label>
          Role
          <select name="role">
            <option value="support">Support — orders and cases</option>
            <option value="moderator">
              Moderation — listings, streams and reports
            </option>
            <option value="finance">
              Finance — orders, payments and refunds
            </option>
            <option value="admin">Admin — marketplace operations</option>
            <option value="revoke">Revoke access</option>
          </select>
        </label>
        <label>
          Reason
          <textarea name="reason" minLength={5} required />
        </label>
        <button disabled={busy}>
          {busy ? "Saving…" : "Apply access change"}
        </button>
      </form>
      {message ? <p role="status">{message}</p> : null}
      <ul>
        {rows.map((r) => (
          <li key={r.userId}>
            {r.email} — {r.role} · {r.userId}
          </li>
        ))}
      </ul>
    </section>
  );
}
