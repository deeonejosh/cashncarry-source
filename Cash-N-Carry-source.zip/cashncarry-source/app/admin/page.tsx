import BrandLogo from "../brand-logo";
import Link from "next/link";
import { brand } from "../brand";
import { requireChatGPTUser } from "../chatgpt-auth";
import { isAdmin, requireAdminMfa } from "../admin-access";
import AdminPanel from "./panel";
import SwitchAccount from "./switch-account";
export const dynamic = "force-dynamic";
export default async function AdminPage() {
  const u = await requireChatGPTUser("/admin");
  await requireAdminMfa(u, "/admin");
  if (!await isAdmin(u))
    return (
      <main id="main-content" tabIndex={-1}>
        <div className="empty">
          <BrandLogo />
          <h1>Administrator access required.</h1>
          <p>
            This account does not have access to the {brand.name} back office.
          </p>
          <Link className="primary" href="/">
            Return to {brand.name}
          </Link>
          <SwitchAccount />
        </div>
      </main>
    );
  return <AdminPanel />;
}
