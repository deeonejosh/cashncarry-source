"use client";
import { useState } from "react";
import { signOutEmailSession } from "../auth-navigation";
export default function SwitchAccount() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  return <>
    <button className="secondary-button" disabled={busy} onClick={async () => {
      setBusy(true);
      setError("");
      try {
        await signOutEmailSession();
        window.location.assign("/signout-with-chatgpt?return_to=" + encodeURIComponent("/sign-in?returnTo=%2Fadmin"));
      } catch {
        setError("Unable to sign out. Please try again before switching accounts.");
        setBusy(false);
      }
    }}>{busy ? "Signing out…" : "Switch account"}</button>
    {error && <p role="alert">{error}</p>}
  </>;
}
