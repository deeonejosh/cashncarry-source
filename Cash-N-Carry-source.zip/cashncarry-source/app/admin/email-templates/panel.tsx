"use client";
import { useEffect, useRef, useState } from "react";
export default function EmailTemplatePanel() {
  const [data, setData] = useState<any>(null),
    [selected, setSelected] = useState("verification"),
    [width, setWidth] = useState("desktop"),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  const actionLock = useRef(false);
  const testId = useRef("");
  const testSelection = useRef("");
  async function load(id = selected) {
    const r = await fetch(
      "/api/admin/email-templates?template=" + encodeURIComponent(id),
      { signal: AbortSignal.timeout(15000) },
    );
    const d: any = await r.json().catch(() => null);
    if (!r.ok || !d) throw Error(d?.error || "Unable to load email templates");
    setData(d);
  }
  useEffect(() => {
    let active = true;
    fetch(
      "/api/admin/email-templates?template=" + encodeURIComponent(selected),
      { signal: AbortSignal.timeout(15000) },
    )
      .then(async (r) => {
        const d: any = await r.json();
        if (!r.ok) throw Error(d.error);
        if (active) setData(d);
      })
      .catch(() => {
        if (active)
          setMessage("Unable to load email templates. Retry refresh.");
      });
    return () => {
      active = false;
    };
  }, [selected]);
  async function action(body: any) {
    if (actionLock.current) return;
    actionLock.current = true;
    setBusy(true);
    setMessage("");
    try {
      const r = await fetch("/api/admin/email-templates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(20000),
      });
      const d: any = await r.json().catch(() => null);
      if (!r.ok || !d)
        throw Error(
          d?.error ||
            "Server response incomplete; check status before retrying",
        );
      setMessage(d.message || "Updated");
      await load();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Email action failed");
    } finally {
      actionLock.current = false;
      setBusy(false);
    }
  }
  return (
    <>
      <div className="email-admin-heading">
        <div>
          <p className="email-eyebrow">CASH N CARRY · COMMUNICATIONS</p>
          <h1>Email templates</h1>
          <p>
            Branded transactional messages, real server triggers and delivery
            status.
          </p>
        </div>
        <button
          disabled={busy}
          onClick={() => load().catch(() => setMessage("Unable to refresh"))}
        >
          Refresh status
        </button>
      </div>
      <p role="status" className="email-admin-feedback">
        {message}
      </p>
      {!data || data.selected !== selected ? (
        <p>Loading templates…</p>
      ) : (
        <>
          <section className="email-config-summary">
            <div>
              <h2>Sender</h2>
              <p>{data.configuration.from || "Not configured"}</p>
              <p>Provider acceptance is separate from delivery.</p>
              <button
                disabled={busy || !data.configuration.configured}
                onClick={() => action({ action: "check-domain" })}
              >
                Check sender domain
              </button>
            </div>
            <div>
              <h2>Reply-To</h2>
              <p>
                {data.configuration.replyTo ||
                  "No monitored reply address confirmed"}
              </p>
              <p>{data.configuration.replyToStatus}</p>
              <details>
                <summary>Configure monitored replies</summary>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const f = new FormData(e.currentTarget);
                    action({
                      action: "reply-to",
                      recipient: f.get("recipient"),
                      confirmed: f.get("confirmed") === "on",
                    });
                  }}
                >
                  <label>
                    Monitored email
                    <input
                      name="recipient"
                      type="email"
                      required
                      placeholder="Address you own and monitor"
                    />
                  </label>
                  <label>
                    <input name="confirmed" type="checkbox" required /> I have
                    checked this mailbox receives replies and is monitored.
                  </label>
                  <button disabled={busy}>Save Reply-To</button>
                </form>
              </details>
            </div>
            <div>
              <h2>Delivery feedback</h2>
              <p>
                {data.configuration.webhookConfigured
                  ? "Signing secret configured"
                  : "Webhook signing secret missing"}
              </p>
              <p>
                Configure RESEND_WEBHOOK_SECRET through secure server
                configuration. Subscribe to sent, delivered, delayed, bounced,
                complained, failed and suppressed events.
              </p>
              <code>{data.configuration.webhookUrl}</code>
              {data.configuration.webhookSetupAvailable && (
                <details>
                  <summary>Save webhook signing secret securely</summary>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.currentTarget,
                        f = new FormData(form);
                      action({
                        action: "webhook-secret",
                        secret: f.get("secret"),
                      }).finally(() => form.reset());
                    }}
                  >
                    <label>
                      Resend webhook signing secret
                      <input
                        name="secret"
                        type="password"
                        autoComplete="off"
                        required
                        placeholder="whsec_…"
                      />
                    </label>
                    <p>
                      The secret is encrypted in private storage and never
                      returned to this browser. Create the webhook in Resend
                      using the URL above.
                    </p>
                    <button disabled={busy}>Save signing secret</button>
                  </form>
                </details>
              )}
            </div>
          </section>
          <div className="email-template-workbench">
            <section className="email-template-list">
              <h2>Template library</h2>
              <label>
                Select template
                <select
                  value={selected}
                  disabled={busy}
                  onChange={(e) => setSelected(e.target.value)}
                >
                  {data.templates.map((t: any) => (
                    <option key={t.id} value={t.id}>
                      {t.title}
                    </option>
                  ))}
                </select>
              </label>
              {data.templates.map((t: any) => (
                <button
                  key={t.id}
                  disabled={busy}
                  className={selected === t.id ? "is-selected" : ""}
                  onClick={() => setSelected(t.id)}
                  aria-pressed={selected === t.id}
                >
                  <strong>{t.title}</strong>
                  <span>
                    {t.connected
                      ? t.enabled
                        ? "Connected"
                        : "Connected · sender unavailable"
                      : "Designed · workflow unavailable"}
                  </span>
                </button>
              ))}
            </section>
            <section className="email-preview-section">
              <div className="email-preview-toolbar">
                <h2>Sample preview</h2>
                <div>
                  <button
                    onClick={() => setWidth("desktop")}
                    aria-pressed={width === "desktop"}
                  >
                    Desktop
                  </button>
                  <button
                    onClick={() => setWidth("mobile")}
                    aria-pressed={width === "mobile"}
                  >
                    Mobile
                  </button>
                </div>
              </div>
              <p>
                <strong>Subject:</strong> {data.preview.subject}
              </p>
              <p>
                <strong>Preview text:</strong> {data.preview.preview}
              </p>
              <p>
                <strong>Trigger:</strong>{" "}
                {data.templates.find((t: any) => t.id === selected)?.trigger}
              </p>
              <p className="email-sample-note">
                Illustrative sample data only. This preview does not verify a
                payment, change an account or create an order.
              </p>
              <div className="email-preview-frame">
                <iframe
                  key={selected}
                  title={"Sample " + selected + " email — " + width}
                  sandbox=""
                  srcDoc={data.preview.html}
                  style={{
                    width: width === "mobile" ? "360px" : "100%",
                    maxWidth: "100%",
                    height: 900,
                    border: 0,
                  }}
                />
              </div>
              <details>
                <summary>Plain-text version</summary>
                <pre className="email-plain-text">{data.preview.text}</pre>
              </details>
              <form
                className="email-test-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  const f = new FormData(e.currentTarget),
                    recipient = String(f.get("recipient"));
                  const key = selected + ":" + recipient;
                  if (testSelection.current !== key) {
                    testSelection.current = key;
                    testId.current = crypto.randomUUID();
                  }
                  action({
                    action: "test",
                    template: selected,
                    recipient,
                    confirmed: f.get("confirmed") === "on",
                    requestId: testId.current,
                  });
                }}
              >
                <h3>Send a controlled test</h3>
                <label>
                  Test recipient
                  <input
                    name="recipient"
                    type="email"
                    required
                    placeholder="Enter the exact test address"
                  />
                </label>
                <label>
                  <input type="checkbox" name="confirmed" required /> I control
                  this test address or have permission to send this clearly
                  labelled sample.
                </label>
                <button disabled={busy || !data.configuration.configured}>
                  {busy ? "Working…" : "Send sample email"}
                </button>
                <p>
                  Retry uses the same identity to prevent duplicate sends.
                  Reload this page for a new test.
                </p>
              </form>
            </section>
          </div>
          <section className="email-delivery-log">
            <h2>Recent sending status</h2>
            <p>
              Accepted means Resend accepted the request. Delivered means the
              recipient server accepted it; it does not prove inbox placement or
              that the message was read.
            </p>
            {data.logs.length ? (
              <div className="email-log-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>Template</th>
                      <th>Queue</th>
                      <th>Delivery feedback</th>
                      <th>Attempts</th>
                      <th>Information</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.logs.map((l: any) => (
                      <tr key={l.id}>
                        <td>{l.template}</td>
                        <td>{l.status === "sent" ? "Accepted" : l.status}</td>
                        <td>{l.delivery_status}</td>
                        <td>{l.attempts}</td>
                        <td>
                          {l.last_error || "—"}
                          {l.retry_at ? " · retry " + l.retry_at : ""}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p>No messages recorded yet.</p>
            )}
          </section>
        </>
      )}
    </>
  );
}
