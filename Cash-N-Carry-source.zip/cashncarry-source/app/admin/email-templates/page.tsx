import { requireChatGPTUser } from "../../chatgpt-auth";
import Link from "next/link";
import { isAdmin, requireAdminMfa } from "../../admin-access";
import BrandLogo from "../../brand-logo";
import EmailTemplatePanel from "./panel";
export const dynamic = "force-dynamic";
export default async function Page() {
  const user = await requireChatGPTUser("/admin/email-templates");
  await requireAdminMfa(user, "/admin/email-templates");
  if (!await isAdmin(user, "settings"))
    return (
      <main className="account-page">
        <BrandLogo />
        <h1>Administrator access required</h1>
        <Link href="/">Return to Cash N Carry</Link>
      </main>
    );
  return (
    <main className="email-admin">
      <header>
        <BrandLogo />
        <a href="/admin/settings#settings-email">Back to email settings</a>
      </header>
      <EmailTemplatePanel />
    </main>
  );
}
