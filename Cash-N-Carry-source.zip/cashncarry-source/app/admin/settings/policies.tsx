"use client";
import { useEffect, useState } from "react";
import { policyBlockerMatches, policyBlockers, publicPolicyLinks } from "../../policy-drafts";

type Version = { id: string; policy_id: string; version: number; title: string; content: string; status: string; created_at: string; created_by_email: string; submitted_at?: string; approved_by_email?: string; approved_at?: string; published_by_email?: string; published_at?: string; effective_date?: string; reason: string };
type Policy = { id: string; title: string; path: string; content: string; versions: Version[] };
type PolicyResponse = { policies: Policy[]; audit: Array<{id:string; action:string; target:string; email:string; created:string; reason:string; after_json:string}>; canEdit: boolean; isOwner: boolean };
const labels: Record<string, string> = { draft: "Draft", pending_review: "Pending Review", approved: "Approved", published: "Published" };
const checks = [
  ["legalReview", "Qualified Nigerian legal review is complete for this exact version."],
  ["operationalReview", "Payment, delivery, returns, moderation and payout statements were checked against working platform features."],
  ["supportMailbox", "support@cashncarryng.com is receiving messages and has assigned response coverage."],
  ["privacyInventory", "Data fields, cookies, processors, retention, backups and international transfers were verified."],
  ["addressReview", "A separate correspondence address was reviewed; no residential street address is included."],
] as const;

export default function PolicyManagement() {
  const [data, setData] = useState<PolicyResponse | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  async function load() {
    const response = await fetch("/api/admin/policies", { cache: "no-store" });
    const result = await response.json() as PolicyResponse & {error?:string};
    if (!response.ok) throw Error(result.error || "Policy records could not be loaded");
    return result;
  }
  useEffect(() => {
    let active = true;
    load().then((result) => { if (active) setData(result); }).catch((error) => { if (active) setMessage(error instanceof Error ? error.message : "Policy records could not be loaded"); });
    return () => { active = false; };
  }, []);
  async function act(event: React.FormEvent<HTMLFormElement>, action: string, policyId: string, version?: Version) {
    event.preventDefault();
    if (busy) return;
    const form = new FormData(event.currentTarget);
    const reason = String(form.get("reason") || "");
    const confirmAction = action !== "save-draft";
    if (confirmAction && !window.confirm(`Confirm ${action.replaceAll("-", " ")} for ${policyId}${version ? ` version ${version.version}` : ""}? The action will be recorded in the audit trail.`)) return;
    const checklist: Record<string, boolean> = {};
    for (const [key] of checks) checklist[key] = form.get(key) === "on";
    setBusy(true); setMessage("Saving policy workflow action…");
    try {
      const response = await fetch("/api/admin/policies", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action, policyId, versionId: version?.id,
          content: form.get("content"), reason,
          confirm: confirmAction,
          effectiveDate: form.get("effectiveDate"), checklist,
        }),
      });
      const result = await response.json() as {error?:string; blockers?:string[]; status?:string; version?:number};
      if (!response.ok) throw Error([result.error, ...(result.blockers || [])].filter(Boolean).join(" "));
      setData(await load()); setMessage(`${(result.status && labels[result.status]) || "Saved"}${result.version ? ` · version ${result.version}` : ""}. Recorded in the audit trail.`);
    } catch (error) { setMessage(error instanceof Error ? error.message : "Policy action failed"); }
    finally { setBusy(false); }
  }

  return <section className="admin-setting-card legal-policy-management" id="settings-policies">
    <h2>Legal Policies</h2>
    <p>Policy drafts are private to authorised administrators. Each change creates a new version. Approval and publication require the configured owner identity, an active MFA-backed session and an explicit confirmation.</p>
    <p className="notice">A policy is public only after its version is approved and published. Approval and publication are never automatic; resolve each version’s displayed blockers first.</p>
    {message && <p role="status" aria-live="polite">{message}</p>}
    {!data && <p role="status">Loading policy versions…</p>}
    {data?.policies.map((policy) => {
      const latest = policy.versions[0];
      const published = policy.versions.find((v) => v.status === "published");
      const blockers = latest ? policyBlockers(latest.content) : [];
      const blockerMatches = latest ? policyBlockerMatches(latest.content) : [];
      const newDraftContent = latest?.content || policy.content;
      return <article className="policy-editor" key={policy.id}>
        <div className="policy-editor-heading">
          <div><h3>{policy.title}</h3><p>Public page: <a href={policy.path} target="_blank" rel="noopener noreferrer">{policy.path}</a></p></div>
          <span className="policy-status">{latest ? `v${latest.version} · ${labels[latest.status] || latest.status}` : "Draft · unversioned"}</span>
        </div>
        <details>
          <summary>Read-only preview · {latest ? `version ${latest.version}` : "initial source draft"}</summary>
          <div className="policy-preview">{newDraftContent}</div>
        </details>
        {published && <p>Currently public: version {published.version}, published {published.published_at?.slice(0, 10)}.</p>}
        {blockers.length > 0 && <div className="notice" role="note">
          <strong>Approval blockers</strong>
          <ul>{blockers.map((blocker) => <li key={blocker}>{blocker}</li>)}</ul>
          <p>Text matches in this version (review the full clauses in the preview):</p>
          <ul>{blockerMatches.map(({ blocker, matches }) => <li key={blocker}><strong>{blocker}:</strong> {matches.map((match) => `“${match}”`).join(", ")}</li>)}</ul>
        </div>}

        {data.canEdit && <form onSubmit={(event) => act(event, "save-draft", policy.id)}>
          <h4>Create a new draft version</h4>
          <label>Policy text<textarea name="content" required minLength={100} maxLength={30000} defaultValue={newDraftContent} rows={18} /></label>
          <label>Reason for this change<input name="reason" minLength={5} required /></label>
          <div className="policy-actions"><button disabled={busy}>Save as new draft</button></div>
        </form>}

        {latest?.status === "draft" && data.canEdit && <form onSubmit={(event) => act(event, "submit-review", policy.id, latest)}>
          <h4>Submit version {latest.version} for review</h4>
          <label><input type="checkbox" required />I have checked this exact version and am submitting it for review.</label>
          <label>Reason for review<input name="reason" minLength={5} required /></label>
          <button disabled={busy}>Submit for review</button>
        </form>}

        {latest?.status === "pending_review" && data.isOwner && <form onSubmit={(event) => act(event, "approve", policy.id, latest)}>
          <h4>Owner approval · version {latest.version}</h4>
          <p>Approval records the owner identity, MFA-backed session, timestamp and reason. The button is disabled while this exact version has unresolved text blockers.</p>
          {blockers.length > 0 && <p className="notice" role="note">Approval is disabled for this version: {blockers.join(" ")}</p>}
          <p>Saving an edit creates a new draft version. Resolve its blockers, submit that version for review, then approve it.</p>
          <label>Approval reason<input name="reason" minLength={5} required /></label>
          <button disabled={busy || blockers.length > 0}>Approve this version</button>
        </form>}

        {latest?.status === "approved" && data.isOwner && <form onSubmit={(event) => act(event, "publish", policy.id, latest)}>
          <h4>Publication checks · approved version {latest.version}</h4>
          {checks.map(([key, label]) => <label key={key}><input type="checkbox" name={key} required />{label}</label>)}
          <label>Effective date<input name="effectiveDate" type="date" required /></label>
          <label>Publication reason<input name="reason" minLength={5} required /></label>
          <button disabled={busy || blockers.length > 0}>Publish approved version</button>
        </form>}

        <details><summary>Version history ({policy.versions.length})</summary>
          {policy.versions.map((version) => <details key={version.id} className="policy-history-row">
            <summary>Version {version.version} · {labels[version.status] || version.status} · {version.created_at?.slice(0, 10)}</summary>
            <p>Created by {version.created_by_email} · {version.reason}</p>
            {version.approved_at && <p>Approved by {version.approved_by_email} · {version.approved_at}</p>}
            {version.published_at && <p>Published by {version.published_by_email} · {version.published_at} · effective {version.effective_date}</p>}
            <pre className="policy-preview">{version.content}</pre>
          </details>)}
        </details>
      </article>;
    })}
    <details><summary>Approval and publication audit trail ({data?.audit.length || 0})</summary>
      {(data?.audit || []).map((entry) => <div className="policy-history-row" key={entry.id}>
        <strong>{entry.action} · {entry.target}</strong><p>{entry.email} · {entry.created} · {entry.reason}</p>
        <pre>{entry.after_json}</pre>
      </div>)}
    </details>
    <nav className="policy-link-list" aria-label="Policy page routes">{publicPolicyLinks.map((link) => <a key={link.id} href={link.path}>{link.title}</a>)}</nav>
  </section>;
}
