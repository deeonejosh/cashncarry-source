"use client";
import StreamingSettings from "./streaming";
import EmailSettings from "./email";
import PolicyManagement from "./policies";
import { androidPackage, androidLinkConfiguration } from "../../android-links";
import { brand } from "../../brand";
import { useEffect, useRef, useState } from "react";
export default function Settings() {
  const [d, setD] = useState<any>(null),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [loading, setLoading] = useState(false);
  const saving = useRef(false);
  const feedback = useRef<HTMLParagraphElement>(null);
  async function load() {
    const r = await fetch("/api/admin/settings", { signal: AbortSignal.timeout(15000) });
    const b: any = await r.json();
    if (!r.ok) throw Error(b.error);
    setD(b);
  }
  async function retryLoad() {
    if (loading) return;
    setLoading(true); setMessage("");
    try { await load(); }
    catch (e) { setMessage(e instanceof Error ? e.message : "Settings could not be loaded."); }
    finally { setLoading(false); }
  }
  useEffect(() => { void retryLoad(); }, []);
  async function submit(
    e: React.FormEvent<HTMLFormElement>,
    action: string,
    id: string,
  ) {
    e.preventDefault();
    if (saving.current) return;
    const confirmations: Record<string,string> = {
      "refund-process": "Submit this approved refund to Flutterwave? Approval alone does not complete a refund. Check the provider status before retrying.",
      "run-maintenance": "Run maintenance now? This retries existing transactional emails, reconciles existing pending payments and expires stale streams. It does not initiate charges or refunds.",
      "owner-business-setup": "Apply the stored owner business setup? Review the affected delivery and policy settings before continuing.",
    };
    if (confirmations[action] && !confirm(confirmations[action])) return;
    const f = new FormData(e.currentTarget);
    const body: any = { action, id, ...Object.fromEntries(f) };
    if (["refund-process","run-maintenance","owner-business-setup"].includes(action)) body.confirm = true;
    for (const k of ["reviewed", "active", "featured", "confirmed"]) body[k] = f.has(k);
    saving.current = true;
    setBusy(true);
    setMessage("Saving…");
    try {
      const r = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(90000),
      });
      const b: any = await r.json();
      if (!r.ok) throw Error(b.error);
      try {
        await load();
        setMessage("Saved and recorded in audit log");
      } catch {
        setMessage("Saved and recorded in audit log. Reload to see the latest settings.");
      }
    } catch (e: any) {
      setMessage(e.name === "TimeoutError" ? "The request timed out. Reload to check whether it completed before retrying." : e.message);
    } finally {
      saving.current = false;
      setBusy(false);
      feedback.current?.focus();
    }
  }
  const reason = (
    <label>
      Reason for this change
      <input name="reason" minLength={5} required />
    </label>
  );
  let androidLinks: { packageName?: string; fingerprints?: string[] } = {};
  try { androidLinks = androidLinkConfiguration(JSON.parse(d?.platform_settings.find((s: any) => s.key === "android_app_links")?.value || "{}")); } catch {}
  return (
    <main id="main-content" tabIndex={-1} className="workspace-page admin-settings-panel">
      <h2>Configuration & operations</h2>
      <p>Choose a section above. Each change keeps its existing approval and audit requirements.</p>
      <p ref={feedback} tabIndex={-1} role={!d && message ? "alert" : "status"}>{message}</p>
      {!d && message && <button type="button" disabled={loading} onClick={retryLoad}>{loading ? "Retrying…" : "Retry loading settings"}</button>}
      {!d && !message && <p role="status">Loading settings…</p>}
      {d && (
        <fieldset className="settings-controls" disabled={busy} aria-busy={busy}>
          <section id="settings-streaming"><StreamingSettings /></section>
          <section id="settings-android">
            <h2>Android Play Store app</h2>
            <p>Connect the Android app to this website after creating it in Play Console. Use the App signing key certificate SHA-256 fingerprint from App integrity, not only the upload key. Certificates are public; never enter a keystore, private key or password here.</p>
            <p>{androidLinks.fingerprints?.length ? "Certificate association published. Verification and device testing are still required." : "Awaiting your app signing certificate. The Android app will show a browser toolbar until the association is verified."}</p>
            <form onSubmit={(e) => submit(e, "android-app-links", "android_app_links")}>
              <label>Android package name<input name="packageName" required defaultValue={androidLinks.packageName || androidPackage} /></label>
              <label>SHA-256 signing certificate fingerprints<textarea name="fingerprints" rows={4} maxLength={1000} required defaultValue={(androidLinks.fingerprints || []).join("\n")} /></label>
              <label><input name="confirmed" type="checkbox" required />I confirm these public certificate fingerprints and package name belong to my app.</label>
              {reason}
              <button>Publish Android app association</button>
            </form>
          </section>
          <section className="admin-setting-card" id="settings-backup"><h2>Private database backup</h2>
          <p>
            The export contains personal data and password hashes. Store it
            encrypted with restricted access. Media files require a separate
            storage backup.
          </p>
          <button
            onClick={async () => {
              if (saving.current) return;
              saving.current = true; setBusy(true); setMessage("Preparing private backup…");
              try {
                const r = await fetch("/api/admin/backup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ confirm: "EXPORT PRIVATE BACKUP" }), signal: AbortSignal.timeout(90000) });
                if (!r.ok) throw Error("Backup export failed. Please retry.");
                const url = URL.createObjectURL(await r.blob());
                const a = document.createElement("a"); a.href = url; a.download = `${brand.filePrefix}-private-backup.json`; a.click();
                setTimeout(() => URL.revokeObjectURL(url), 1000);
                setMessage("Private backup downloaded. Encrypt it before storage.");
              } catch { setMessage("Backup export failed or timed out. Please retry."); }
              finally { saving.current = false; setBusy(false); feedback.current?.focus(); }
            }}
          >
            Download private backup
          </button>
          </section>
          <section className="admin-setting-card" id="settings-image-uploads">
            <h2>Product image uploads</h2>
            <p>Per-seller image limits are enforced by the upload API. Defaults below are proposed launch settings; review storage capacity and cost before applying them. Video uploads keep their existing limits.</p>
            <div className="settings-metrics" aria-label="Image upload metrics">
              <p><strong>{d.imageUploadMetrics?.successfulImagesToday || 0}</strong><br/>Images uploaded today</p>
              <p><strong>{Math.round((d.imageUploadMetrics?.uploadedBytesToday || 0) / 1048576)} MB</strong><br/>Image data uploaded today</p>
              <p><strong>{Math.round((d.imageUploadMetrics?.allTimeUploadedBytes || 0) / 1048576)} MB</strong><br/>Tracked original image uploads</p>
<p><strong>{d.imageUploadMetrics?.successRateToday == null ? "—" : `${d.imageUploadMetrics.successRateToday}%`}</strong><br/>Today&apos;s upload success rate</p>
              <p><strong>{d.imageUploadMetrics?.failed || 0}</strong><br/>Failed upload attempts today</p>
              <p><strong>{d.imageUploadMetrics?.quotaRejected || 0}</strong><br/>Quota rejections today</p>
              <p><strong>{d.imageUploadMetrics?.accountsApproachingLimit || 0}</strong><br/>Sellers at 80% or more of a limit</p>
            </div>
            <p>Successful uploads only count after storage confirms completion. The allowance resets at midnight UTC. An upload does not guarantee publication; save the product to attach the image.</p>
            <form onSubmit={(e) => submit(e, "image-upload-policy", "image_upload_policy")}>
              <label>Successful images per seller per UTC day<input name="dailyImages" type="number" min="1" max="500" required defaultValue={d.imageUploadPolicy?.dailyImages ?? 100}/></label>
              <label>Original image allowance per seller (MB/day)<input name="dailyMegabytes" type="number" min="10" max="2048" step="1" required defaultValue={Math.round((d.imageUploadPolicy?.dailyBytes ?? 524288000) / 1048576)}/></label>
              <label>Maximum original image size (MB)<input name="maxImageMegabytes" type="number" min="1" max="10" step="1" required defaultValue={Math.round((d.imageUploadPolicy?.maxImageBytes ?? 10485760) / 1048576)}/></label>
              <label>Maximum images per product<input name="maxImagesPerProduct" type="number" min="1" max="20" required defaultValue={d.imageUploadPolicy?.maxImagesPerProduct ?? 10}/></label>
              <label>Upload attempts per seller per minute<input name="uploadsPerMinute" type="number" min="1" max="60" required defaultValue={d.imageUploadPolicy?.uploadsPerMinute ?? 10}/></label>
              <p>Supported formats are fixed to JPEG, PNG and WebP. Upload-rate limits remain active.</p>
              {reason}
              <button>Save image upload limits</button>
            </form>
          </section>
<section className="admin-setting-card" id="settings-sellers"><h2>Seller approval policy</h2>
          <p>
            Require approval before creating or editing product listings.
            Existing listings stay available. Changing this setting is recorded
            in the audit log.
          </p>
          <form
            onSubmit={(e) =>
              submit(e, "seller-approval", "seller_approval_required")
            }
          >
            <label>
              Listing approval
              <select
                name="value"
                defaultValue={
                  d.platform_settings.find(
                    (s: any) => s.key === "seller_approval_required",
                  )?.value || "0"
                }
              >
                <option value="0">
                  Allow listings while verification is pending
                </option>
                <option value="1">
                  Require approved business verification
                </option>
              </select>
            </label>
            {reason}
            <button>Save seller policy</button>
          </form>
          </section>
<section className="admin-setting-card" id="settings-support"><h2>Public customer support</h2>
          <p>Publish a business contact you control and monitor. This address appears on Help &amp; contact without sign-in. It does not configure email authentication or send messages.</p>
          <form onSubmit={(e) => submit(e, "public-support", "public_support_email")}>
            <label>Public support email<input name="value" type="email" maxLength={254} required defaultValue={d.platform_settings.find((s: any) => s.key === "public_support_email")?.value || ""} /></label>
            <label><input type="checkbox" name="confirmed" required />I confirm this contact is monitored and approved for public customer support.</label>
            {reason}
            <button>Publish support contact</button>
          </form>
          </section>
<section className="admin-setting-card" id="settings-email"><h2>Email accounts and delivery</h2>
          <EmailSettings />
          <h3>Email delivery queue</h3>
          <p>
            Retries use backoff and recover interrupted deliveries. Failed or
            reconciliation-required deliveries need operator review. Background
            delivery requires a configured email service and verified sender.
          </p>
          <ul>
            {(d.email_outbox || []).map((m: any) => (
              <li key={m.id}>
                {m.id} · {m.status} · {m.attempts} attempts{" "}
                {m.retry_at ? "· Next attempt after " + m.retry_at : ""}
              </li>
            ))}
          </ul>
          </section>
<section className="admin-setting-card" id="settings-commission"><h2>Commission</h2>
          <p>
            Configured commission is informational until seller settlement is
            integrated. No payout is simulated.
          </p>
          <form onSubmit={(e) => submit(e, "commission", "commission_percent")}>
            <label>
              Commission percent
              <input
                name="value"
                type="number"
                min="0"
                max="30"
                step="0.1"
                defaultValue={
                  d.platform_settings.find(
                    (x: any) => x.key === "commission_percent",
                  )?.value || 0
                }
              />
            </label>
            {reason}
            <button>Save commission</button>
          </form>
          </section>
<PolicyManagement />
<section className="admin-setting-card" id="settings-categories"><h2>Categories</h2>
          {d.categories.map((c: any) => (
            <form key={c.id} onSubmit={(e) => submit(e, "category", c.id)}>
              <input name="name" defaultValue={c.name} />
              <label>
                <input
                  type="checkbox"
                  name="active"
                  defaultChecked={Boolean(c.active)}
                />
                Active
              </label>
              {reason}
              <button>Save category</button>
            </form>
          ))}
          <form
            onSubmit={(e) =>
              submit(
                e,
                "category",
                String(new FormData(e.currentTarget).get("id")),
              )
            }
          >
            <h3>Add category</h3>
            <label>
              Category key
              <input name="id" required maxLength={100} />
            </label>
            <label>
              Name
              <input name="name" required maxLength={40} />
            </label>
            <label>
              <input name="active" type="checkbox" defaultChecked />
              Active
            </label>
            {reason}
            <button>Add category</button>
          </form>
          </section>
<section className="admin-setting-card" id="settings-featured"><h2>Featured products</h2>
          <form
            onSubmit={(e) => {
              const id = String(new FormData(e.currentTarget).get("id"));
              submit(e, "featured", id);
            }}
          >
            <label>
              Product ID
              <input name="id" required />
            </label>
            <label>
              <input name="featured" type="checkbox" />
              Featured
            </label>
            {reason}
            <button>Update featured product</button>
          </form>
          </section>
<section className="admin-setting-card" id="settings-transactions"><h2>Payments</h2>
          {d.payments.length ? (
            d.payments.map((p: any) => (
              <article key={p.id}>
                <strong>
                  {p.mode.toUpperCase()} · ₦{p.amount.toLocaleString()} ·{" "}
                  {p.status}
                </strong>
                <p>{p.order_id}</p>
              </article>
            ))
          ) : (
            <p>No payments yet.</p>
          )}
          </section>
<section className="admin-setting-card" id="settings-refunds"><h2>Refund requests</h2>
          <p>
            Approval records the review decision. Use provider operations below
            to initiate approved refunds in the original transaction mode and verify status before
            a payment is marked refunded.
          </p>
          {d.refunds.length ? (
            d.refunds.map((r: any) => (
              <form
                key={r.id}
                onSubmit={(e) => submit(e, "refund-review", r.id)}
              >
                <p>
                  {r.order_id} · ₦{r.amount} · {r.status}
                </p>
                <p>{r.reason}</p>
                <select name="status">
                  <option value="approved_for_processing">
                    Approve for processing
                  </option>
                  <option value="rejected">Reject</option>
                </select>
                {reason}
                <button>Record review</button>
              </form>
            ))
          ) : (
            <p>No refund requests.</p>
          )}
          </section>
<section className="admin-setting-card" id="settings-maintenance"><h2>Expired checkout reservations</h2>
          <p>Check expired payments and release stock only after verified cancellation. Uncertain payments remain reserved. Background maintenance uses a protected service endpoint and must have an active scheduler. Site visits do not run maintenance.</p>
          <p>Last completed background check: {(() => {
            const saved = d.platform_settings.find((s: any) => s.key === "last_maintenance_run");
            if (!saved) return "No completed run recorded";
            try { return new Date(JSON.parse(saved.value).completedAt).toLocaleString(); } catch { return "Status unavailable"; }
          })()}</p>
          <form onSubmit={e => submit(e, "reconcile-payments", "expired-reservations")}>
            {reason}
            <button>Check expired payments</button>
          </form>
          <h3>Provider operations</h3>
          <form
            onSubmit={(e) => {
              const f = new FormData(e.currentTarget);
              submit(e, String(f.get("operation")), String(f.get("target")));
            }}
          >
            <label>
              Operation
              <select name="operation">
                <option value="run-maintenance">Run protected maintenance</option>
                <option value="refund-process">
                  Initiate approved refund
                </option>
                <option value="refund-reconcile">
                  Verify provider refund status
                </option>
                <option value="flush-emails">
                  Send pending transactional emails
                </option>
              </select>
            </label>
            <label>
              Refund ID (or “outbox” for email)
              <input name="target" required />
            </label>
            {reason}
            <button>Run operation</button>
          </form>
          </section>
        </fieldset>
      )}
    </main>
  );
}
