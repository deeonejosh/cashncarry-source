"use client";
import { useEffect, useRef, useState } from "react";

type EmailResponse = {
  configured: boolean;
  from: string;
  acceptedAt?: string | null;
  environmentManaged?: boolean;
  setupAvailable?: boolean;
  error?: string;
  ok?: boolean;
  message?: string;
};

export default function EmailSettings() {
  const [status, setStatus] = useState<EmailResponse | null>(null);
  const [from, setFrom] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [failed, setFailed] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const saving = useRef(false);
  const requestId = useRef<string | null>(null);
  const feedback = useRef<HTMLParagraphElement>(null);
  async function load(signal?: AbortSignal) {
    const response = await fetch("/api/admin/email", {
      cache: "no-store",
      signal: signal
        ? AbortSignal.any([signal, AbortSignal.timeout(15000)])
        : AbortSignal.timeout(15000),
    });
    const result = (await response.json()) as EmailResponse;
    if (!response.ok)
      throw Error(result.error || "Unable to load email settings.");
    if (signal?.aborted) return;
    setStatus(result);
    setFrom(result.from);
  }
  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal).catch((error) => {
      if (!controller.signal.aborted) {
        setFailed(true);
        setMessage(error.message);
      }
    });
    return () => controller.abort();
  }, []);
  useEffect(() => {
    if (message) {
      feedback.current?.focus();
      feedback.current?.scrollIntoView({ block: "nearest" });
    }
  }, [message]);
  useEffect(() => {
    if (!cooldown) return;
    const timer = setTimeout(
      () => setCooldown((value) => Math.max(0, value - 1)),
      1000,
    );
    return () => clearTimeout(timer);
  }, [cooldown]);
  return (
    <section aria-labelledby="email-setup-heading">
      <h3 id="email-setup-heading">Secure email setup</h3>
      <p><a href="/admin/email-templates">Email templates, previews and delivery status</a></p>
      <p>
        {status
          ? status.configured
            ? "Email sender configured. Registration, verification and password recovery use the saved sender."
            : "Email accounts are disabled until a sender is configured. ChatGPT sign-in is available."
          : "Loading email configuration…"}
      </p>
      {message && (
        <p
          ref={feedback}
          tabIndex={-1}
          role={failed ? "alert" : "status"}
          aria-live={failed ? "assertive" : "polite"}
          className={
            "email-setup-feedback " + (failed ? "is-error" : "is-success")
          }
        >
          {message}
        </p>
      )}
      <button
        type="button"
        disabled={busy}
        onClick={() =>
          load()
            .then(() => {
              setFailed(false);
              setMessage(
                "Email status refreshed. See the saved configuration status above.",
              );
            })
            .catch((error) => {
              setFailed(true);
              setMessage(error.message);
            })
        }
      >
        Refresh saved email status
      </button>
      {cooldown > 0 && (
        <p role="status">
          Wait {cooldown} seconds before another setup attempt.
        </p>
      )}
      {status?.acceptedAt && (
        <p>
          Last setup test accepted by the provider:{" "}
          <time dateTime={status.acceptedAt}>{status.acceptedAt}</time>. Inbox
          receipt must be checked separately.
        </p>
      )}
      {status?.environmentManaged ? (
        <p>
          This sender is managed through secure server settings. Update
          RESEND_API_KEY and EMAIL_FROM there to replace it. The key is never
          displayed here.
        </p>
      ) : (
        <>
          {status && !status.setupAvailable && (
            <p role="alert">
              Private configuration storage or authentication settings are
              missing. Secure email setup is unavailable; do not paste a key
              until configuration is ready.
            </p>
          )}
          <form
            noValidate
            onSubmit={async (event) => {
              event.preventDefault();
              if (saving.current || cooldown > 0) return;
              const sender = from.trim(),
                key = apiKey.trim();
              const consent =
                new FormData(event.currentTarget).get("consent") === "on";
              const problem = !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(sender)
                ? "Enter a valid sender email address on your verified domain."
                : /@(?:[^@]+\.)?resend\.dev$/i.test(sender)
                  ? "Use your own verified sender domain. The Resend demo sender cannot enable customer accounts."
                  : !/^re_[A-Za-z0-9_-]{10,200}$/.test(key)
                    ? "Enter your complete Resend API key in the secure key field."
                    : !consent
                      ? "Tick the confirmation box to authorise the setup email."
                      : "";
              if (problem) {
                setFailed(true);
                setMessage("Not saved. " + problem);
                return;
              }

              saving.current = true;
              setBusy(true);
              setFailed(false);
              setMessage("Requesting your setup test…");
              requestId.current ||= crypto.randomUUID();
              try {
                const response = await fetch("/api/admin/email", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    from: sender,
                    apiKey: key,
                    requestId: requestId.current,
                    confirm: "SEND TEST AND ENABLE",
                  }),
                  signal: AbortSignal.timeout(30000),
                });
                const result = (await response
                  .json()
                  .catch(() => null)) as EmailResponse | null;
                if (response.status === 429) setCooldown(60);
                if (!result)
                  throw Error(
                    "The server returned an unreadable response. Refresh saved status before trying again.",
                  );
                if (!response.ok || !result.ok)
                  throw Error(
                    result.error || "The server did not confirm email setup.",
                  );
                setApiKey("");
                requestId.current = null;
                setStatus((current) => ({
                  ...current,
                  configured: true,
                  from: result.from,
                  acceptedAt: result.acceptedAt,
                }));
                setMessage(
                  result.message ||
                    "Email settings saved. Check your inbox for the requested test.",
                );
              } catch (error) {
                setFailed(true);
                setMessage(
                  "Not confirmed as saved. " +
                    (error instanceof Error && error.name === "TimeoutError"
                      ? "Setup timed out. Refresh status before retrying; the provider may have accepted your test."
                      : error instanceof Error
                        ? error.message
                        : "Unable to confirm setup."),
                );
              } finally {
                saving.current = false;
                setBusy(false);
                feedback.current?.focus();
              }
            }}
          >
            <fieldset
              disabled={busy || cooldown > 0 || !status?.setupAvailable}
            >
              <label>
                Sender email on your verified domain
                <input
                  type="email"
                  value={from}
                  onChange={(event) => {
                    setFrom(event.target.value);
                    requestId.current = null;
                  }}
                  required
                  maxLength={254}
                  autoComplete="off"
                />
              </label>
              <label>
                Resend API key
                <input
                  type="password"
                  value={apiKey}
                  onChange={(event) => {
                    setApiKey(event.target.value);
                    requestId.current = null;
                  }}
                  required
                  minLength={13}
                  maxLength={203}
                  autoComplete="new-password"
                  spellCheck={false}
                  autoCapitalize="none"
                />
              </label>
              <p>
                Use a key with sending permission for your verified domain. This
                key is encrypted in private storage and is never returned to the
                browser after saving. The Resend demo sender is not supported.
              </p>
              <label>
                <input type="checkbox" name="consent" required />I authorise one
                setup email to my signed-in administrator address and enable
                email accounts if the provider accepts it.
              </label>
              <button type="submit">
                {busy
                  ? "Testing and saving…"
                  : "Send test and enable email accounts"}
              </button>
            </fieldset>
          </form>
        </>
      )}
      <p>
        The sender is not automatically published as your customer support
        contact. Publish that separately after confirming it is monitored.
      </p>
    </section>
  );
}
