"use client";
import { useEffect, useState } from "react";
export default function StreamingSettings() {
  const [accountId, setAccountId] = useState("");
  const [token, setToken] = useState("");
  const [configured, setConfigured] = useState(false);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  useEffect(() => {
    let active = true;
    fetch("/api/admin/streaming", {cache: "no-store"}).then(async r => {
      const b: any = await r.json();
      if (!r.ok) throw Error(b.error);
      if (active) {setAccountId(b.accountId); setConfigured(b.configured); setReady(true);}
    }).catch(() => {if (active) setMessage("Unable to load streaming settings. Refresh to retry.");});
    return () => {active = false;};
  }, []);
  return <section aria-labelledby="streaming-heading">
    <h2 id="streaming-heading">Cloudflare Streaming</h2>
    <p>{configured ? "Streaming credentials are saved. You can replace them below." : "Connect your Cloudflare Stream account to enable native broadcasts."}</p>
    <form noValidate onSubmit={async e => {
      e.preventDefault(); if (busy) return;
      const id = accountId.trim();
      const secret = token.trim();
      if (!/^[a-f0-9]{32}$/i.test(id)) {setMessage("Account ID must contain exactly 32 letters or numbers. Copy the Account ID from Cloudflare."); return;}
      if (secret.length < 20 || secret.length > 512 || /\s/.test(secret)) {setMessage("Paste the complete Cloudflare API token without spaces. Use the token value, not its name or ID."); return;}
      setBusy(true); setMessage("Checking your Cloudflare account…");
      try {
        const r = await fetch("/api/admin/streaming", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({accountId: id, token: secret}), signal: AbortSignal.timeout(25000)});
        const b: any = await r.json().catch(() => null);
        if (!r.ok) throw Error(b?.error || `Unable to save (status ${r.status}). Refresh and retry.`);
        if (!b?.ok) throw Error("The server did not confirm saving. Please retry.");
        setToken(""); setConfigured(true); setMessage("Streaming credentials verified and saved. You can now prepare a native broadcast.");
      } catch (error) {setMessage(error instanceof Error && error.name === "TimeoutError" ? "The request timed out. Refresh to check connection status before retrying." : error instanceof Error ? error.message : "Unable to save. Please retry.");}
      finally {setBusy(false);}
    }}>
      <label>Cloudflare Account ID<input value={accountId} onChange={e => setAccountId(e.target.value)} required pattern="[a-fA-F0-9]{32}" maxLength={32} disabled={busy || !ready} autoComplete="off" /></label>
      <label>API token<input type="password" value={token} onChange={e => setToken(e.target.value)} required minLength={20} maxLength={512} disabled={busy || !ready} autoComplete="new-password" spellCheck={false} autoCapitalize="none" /></label>
      <p>Use a token with Account → Stream → Edit permission for this account. Your token is encrypted and is never displayed after saving.</p>
      {message && <div role="alert" aria-live="assertive" style={{padding: "16px", margin: "12px 0", border: "2px solid #92400e", borderRadius: "8px", background: "#fff7ed", color: "#431407", fontSize: "16px", overflowWrap: "anywhere"}}>{message}</div>}
      <button type="submit" disabled={busy || !ready}>{busy ? "Verifying and saving…" : "Verify and save streaming"}</button>
    </form>
    {!ready && message && <p role="alert">{message}</p>}
  </section>;
}
