import AccessPanel from "../access-panel";
import Link from "next/link";
import BrandLogo from "../../brand-logo";
import { brand } from "../../brand";
import { requireChatGPTUser } from "../../chatgpt-auth";
import { isAdmin, requireAdminMfa } from "../../admin-access";
import { paymentReadiness } from "../../payments";
import { env } from "cloudflare:workers";
import { getStreamConfig } from "../../stream-config";
import Panel from "./panel";
export default async function Page() {
  const u = await requireChatGPTUser("/admin/settings");
  await requireAdminMfa(u, "/admin/settings");
  if (!await isAdmin(u, "settings"))
    return (
      <main id="main-content" tabIndex={-1} className="account-page">
        <BrandLogo />
        <h1>Administrator access required</h1>
        <Link href="/">Return to {brand.name}</Link>
      </main>
    );
  const readiness = paymentReadiness();
  const [streamConfig, webhook, maintenance] = await Promise.all([
    getStreamConfig().catch(() => null),
    env.DB?.prepare(
      "SELECT created FROM payment_events WHERE id LIKE 'charge-%' ORDER BY created DESC LIMIT 1",
    )
      .first<any>()
      .catch(() => null),
    env.DB?.prepare(
      "SELECT value FROM platform_settings WHERE key='last_maintenance_run'",
    )
      .first<any>()
      .catch(() => null),
  ]);
  let lastMaintenance = "No completed run recorded";
  try {
    if (maintenance)
      lastMaintenance =
        JSON.parse(maintenance.value).completedAt || lastMaintenance;
  } catch {}
  return (
    <div className="admin-settings-shell">
      <AccessPanel />
      <header className="settings-header">
        <BrandLogo />
        <div><p className="eyebrow">CASH N CARRY ADMIN</p><h1>Settings & integrations</h1><p>Configure services, manage policies and review payment operations.</p></div>
        <a className="secondary-button" href="/admin">
          Admin Console
        </a>
      </header>
      <nav className="settings-nav admin-settings-directory" aria-label="Settings sections">
        <div><strong>Services</strong><a href="#settings-payments">Payment readiness</a><a href="#settings-streaming">Livestream setup</a><a href="#settings-email">Email setup</a><a href="/admin/email-templates">Email templates</a><a href="#settings-android">Android app</a><a href="#settings-brand">Brand identity</a></div>
        <div><strong>Business</strong><a href="#settings-sellers">Seller approval</a><a href="#settings-support">Support contact</a><a href="#settings-policies">Policies</a><a href="#settings-categories">Categories</a><a href="#settings-featured">Featured products</a><a href="#settings-commission">Commission</a></div>
        <div><strong>Operations</strong><a href="#settings-transactions">Payment records</a><a href="#settings-refunds">Refund requests</a><a href="#settings-maintenance">Maintenance</a><a href="#settings-backup">Private backup</a><a href="#settings-image-uploads">Image upload limits</a></div>      </nav>
      <div className="integration-summary">
        <section
          className="design-card"
          id="settings-payments"
          aria-label="Payment readiness"
        >
          <h2>Flutterwave payments</h2>
          <p>
            {readiness.mode === "test"
              ? "Test mode — no real-money collections"
              : readiness.online
                ? "Live payments enabled"
                : "Live payments blocked"}
          </p>
          {readiness.blockers.length > 0 && (
            <ul>
              {readiness.blockers.map((b) => (
                <li key={b}>{b}</li>
              ))}
            </ul>
          )}
          <p>Return URL: {env.SITE_URL}/payment-return</p>
          <p>
            Last verified webhook event:{" "}
            {webhook?.created || "No verified receipt recorded"}
          </p>
          <p>Webhook URL: {env.SITE_URL}/api/payments/webhook</p>
          <p>Set this exact URL in your Flutterwave dashboard. Notifications sent to the homepage cannot update orders.</p>
          <p>
            Live activation requires server secrets, confirmed live NGN merchant
            approval and matching webhook settings. A real-payment test requires
            separate approval.
          </p>
        </section>
        <section className="design-card" id="settings-brand">
          <h2>Brand</h2>
          <BrandLogo tagline />
          <p>
            The approved Cash N Carry logo and tagline are used across the
            website.
          </p>
        </section>
        <section className="design-card">
          <h2>Streaming &amp; email</h2>
          <p>
            Cloudflare Stream:{" "}
            {streamConfig
              ? "Credentials configured; broadcast testing is separate"
              : "Not configured"}
          </p>
          <p><a href="#settings-email">Review secure email setup and sender status</a>. Email accounts remain unavailable until a sender is configured. Never enter a key in policy text or public settings.</p>
          <p>
            Google sign-in is not configured. Existing account sign-in is
            preserved.
          </p>
        </section>
        <section className="design-card">
          <h2>Maintenance</h2>
          <p>
            Protected endpoint:{" "}
            {env.MAINTENANCE_TOKEN_SHA256 ? "Configured" : "Not configured"}
          </p>
          <p>Last completed run: {lastMaintenance}</p>
          {(!Number.isFinite(Date.parse(lastMaintenance)) || Date.now() - Date.parse(lastMaintenance) > 90 * 60 * 1000) && <p className="notice" role="status">Maintenance is overdue or has not run. Check the authenticated scheduler and server logs; configured credentials alone do not prove execution.</p>}
          <a className="secondary-button" href="#settings-maintenance">
            Review maintenance
          </a>
        </section>
      </div>
      <Panel />
    </div>
  );
}
