"use client";
import { useEffect, useState } from "react";
export default function FinancePanel() {
  const [data, setData] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function load() {
    try {
      const r = await fetch("/api/admin/finance");
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      setData(d);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to load finance");
    }
  }
  useEffect(() => {
    load();
  }, []);
  async function act(e: React.FormEvent<HTMLFormElement>, id: string) {
    e.preventDefault();
    if (busy) return;
    const f = new FormData(e.currentTarget);
    if (
      !confirm(
        "Apply this refund action? Only provider-confirmed completion means money has been refunded.",
      )
    )
      return;
    setBusy(true);
    try {
      const r = await fetch("/api/admin/finance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id,
          action: f.get("action"),
          status: f.get("status"),
          reason: f.get("reason"),
          confirm: true,
        }),
      });
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      setError("");
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Action failed");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="admin-setting-card">
      <h2>Payments & refunds</h2>
      <p>
        Test transactions are labelled separately. Approval is a decision;
        processing is a provider request; only verified completion confirms a
        refund.
      </p>
      {error ? <p role="alert">{error}</p> : null}
      {!data ? (
        <p>Loading finance records…</p>
      ) : (
        <>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Amount</th>
                  <th>Environment</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {data.payments.map((p: any) => (
                  <tr key={p.id}>
                    <td>{p.order_id}</td>
                    <td>₦{p.amount.toLocaleString()}</td>
                    <td>{p.mode.toUpperCase()}</td>
                    <td>{p.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!data.payments.length ? <p>No recorded payments.</p> : null}
          <h3>Refund requests</h3>
          {data.refunds.length ? (
            data.refunds.map((r: any) => (
              <form key={r.id} onSubmit={(e) => act(e, r.id)}>
                <p>
                  {r.order_id} · ₦{r.amount.toLocaleString()} · {r.status}
                </p>
                <label>
                  Action
                  <select name="action">
                    <option value="refund-review">
                      Record review decision
                    </option>
                    <option value="refund-process">
                      Execute approved provider refund
                    </option>
                    <option value="refund-reconcile">
                      Verify provider status
                    </option>
                  </select>
                </label>
                <label>
                  Review decision
                  <select name="status">
                    <option value="approved_for_processing">
                      Approve request
                    </option>
                    <option value="rejected">Reject request</option>
                  </select>
                </label>
                <label>
                  Reason
                  <textarea name="reason" minLength={5} required />
                </label>
                <button disabled={busy}>Apply refund action</button>
              </form>
            ))
          ) : (
            <p>No refund requests.</p>
          )}
        </>
      )}
    </section>
  );
}
