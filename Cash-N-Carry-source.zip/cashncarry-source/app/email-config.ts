import { env } from "cloudflare:workers";
const objectKey = "private/email-configuration";
const additionalData = new TextEncoder().encode("cash-n-carry:email-configuration:v1");
export type EmailConfig = { apiKey: string; from: string; acceptedAt?: string };

async function encryptionKey() {
  if (!env.STREAM_CONFIG_KEY) throw Error("Private configuration storage is unavailable");
  const bytes = Uint8Array.from(atob(env.STREAM_CONFIG_KEY), c => c.charCodeAt(0));
  return crypto.subtle.importKey("raw", bytes, "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function getEmailConfig(): Promise<EmailConfig | null> {
  // Preserve installations managed through server environment secrets.
  if (env.RESEND_API_KEY && env.EMAIL_FROM) return { apiKey: env.RESEND_API_KEY, from: env.EMAIL_FROM };
  if (!env.BUCKET || !env.STREAM_CONFIG_KEY) return null;
  const saved = await env.BUCKET.get(objectKey);
  if (!saved) return null;
  const data: any = await saved.json();
  const clear = await crypto.subtle.decrypt({ name: "AES-GCM", iv: Uint8Array.from(data.iv), additionalData }, await encryptionKey(), Uint8Array.from(data.cipher));
  const config: EmailConfig = JSON.parse(new TextDecoder().decode(clear));
  if (!config.apiKey || !config.from || !config.acceptedAt) throw Error("Invalid private email configuration");
  return config;
}

export async function saveEmailConfig(config: EmailConfig) {
  if (!env.BUCKET) throw Error("Private configuration storage is unavailable");
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData }, await encryptionKey(), new TextEncoder().encode(JSON.stringify(config)));
  await env.BUCKET.put(objectKey, JSON.stringify({ iv: Array.from(iv), cipher: Array.from(new Uint8Array(cipher)) }));
}
