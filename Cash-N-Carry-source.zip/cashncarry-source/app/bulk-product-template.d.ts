export function createBulkProductTemplate(): ArrayBuffer | Uint8Array;
