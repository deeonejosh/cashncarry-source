export type PolicyId = "privacy" | "terms" | "delivery" | "refunds" | "seller-terms" | "community-guidelines";

export const policyDefinitions: Record<PolicyId, { title: string; path: string; content: string }> = {
  privacy: {
    title: "Privacy Policy",
    path: "/privacy",
    content: `Effective date: [DATE OF OWNER APPROVAL — NOT YET SET] | Last updated: [DATE OF OWNER APPROVAL — NOT YET SET]

1. Who we are
Cash N Carry is an online marketplace operated by Temidayo Ogundiya as an individual operator in Nigeria ("Cash N Carry", "we", "us") through cashncarryng.com. Customers can discover and purchase products from independent sellers, including through livestreams. Cash N Carry is not yet CAC-registered. For enquiries, contact support@cashncarryng.com (inbox activation pending). A separate business correspondence address will be provided when confirmed and where legally required.

2. Information we collect
We may collect account details (name, username, email, phone and authentication information); delivery details; order, payment-reference and transaction status data; seller/store information and verification documents where required; uploaded product media, reviews, reports and livestream chat; device, security, usage and approximate location data; and communications with support. We should collect precise location only with appropriate permission and where needed for an enabled feature. Payment card credentials are generally handled by the payment provider rather than stored by Cash N Carry; verify actual data flows before publication.

3. Why we use information
We use personal data to create and secure accounts, authenticate users, process and fulfil orders, calculate delivery eligibility, provide seller services, support livestream shopping, prevent fraud, handle complaints, provide customer support, meet legal duties, and improve reliability and user experience. Marketing communications should be sent only where permitted and with a working opt-out.

4. Legal bases
Depending on the processing, the basis may include performance of a contract, compliance with legal obligations, legitimate interests balanced against individual rights, or consent where required. Confirm and document the lawful basis for each actual processing activity under applicable Nigerian data protection law. Consent can be withdrawn where processing relies on it, without affecting earlier lawful processing.

5. Sharing
Information may be shared as needed with the relevant seller, payment processor (including Flutterwave where used), hosting/storage and email delivery providers (including Resend where used), livestream infrastructure providers, delivery partners, fraud-prevention and professional advisers, and authorities when legally required. Sellers receive only data necessary to fulfil their orders. We do not authorise sellers to use customer information for unrelated marketing without a valid basis.

6. Livestreams and public content
Seller livestreams, public product listings, reviews, public comments, and usernames may be visible to other users. Do not publish sensitive personal information in public chat. Livestream recordings or replays, if offered, must be described accurately, including how long they remain available and who can access them: [CONFIRM RECORDING/REPLAY PRACTICE].

7. Cookies and similar technology
Essential cookies and similar storage may be used for account sign-in, security, fraud prevention and checkout. RECOMMENDED CONTROL: do not enable non-essential analytics, advertising or tracking until a documented inventory, transparent notice and appropriate opt-in/opt-out choices are implemented. Cookie names, purposes, durations and vendors must be verified against the live application before publication.

8. Retention and security
We retain personal information only as long as necessary for the stated purposes, legal duties, disputes and security. PROPOSED INTERNAL SCHEDULE (NOT VERIFIED): account/profile data for the life of the account, then assess deletion requests and any legal holds; order/payment/tax records for the legally applicable accounting/tax period after the transaction; seller verification documents for the shortest period justified by compliance/fraud requirements; security logs normally 90 days unless investigation requires longer; support records normally 24 months after closure; inactive livestream media/replays according to a separately disclosed seller-controlled setting; backups on a documented rotating deletion cycle. Do not publish numeric periods until the data map, applicable statutory periods, backup mechanics and processor contracts have been checked. Rights requests and cross-border transfers follow applicable Nigerian law.

9. International processing
Some service providers may process information outside Nigeria. Where this occurs, we will use appropriate legal transfer mechanisms and safeguards required by applicable law. Confirm provider locations and mechanisms: [INTERNATIONAL TRANSFER DETAILS].

10. Your choices and rights
Subject to applicable law, you may request access, correction, deletion, restriction, objection or portability, withdraw consent, and complain to the Nigeria Data Protection Commission or another competent authority. Contact support@cashncarryng.com. We may verify identity before fulfilling requests and may retain records where legally required.

11. Children
The marketplace is not intended for children below 18 years (proposed platform rule; confirm account age controls). We do not knowingly permit children to create accounts contrary to applicable law. Contact us if you believe a child has provided personal information improperly.

12. Changes and contact
We may update this policy and will publish the revised version with an effective date, providing additional notice where required. Privacy enquiries: support@cashncarryng.com; operator: Temidayo Ogundiya.`
  },
  terms: {
    title: "Terms and Conditions",
    path: "/terms",
    content: `Effective date: [DATE OF OWNER APPROVAL — NOT YET SET]

1. Acceptance and eligibility
By using Cash N Carry, you agree to these Terms and applicable policies. You must meet the applicable age requirement and provide accurate account information. If you do not agree, do not use the service.

2. Marketplace role
Cash N Carry provides a platform connecting buyers and independent sellers. Unless expressly identified as the seller for a specific order, the seller is responsible for product descriptions, lawful supply, fulfilment and applicable product obligations. Cash N Carry may assist with payment processing, disputes and platform moderation. Consumer rights under Nigerian law are not excluded.

3. Accounts and security
Keep your credentials secure, do not share accounts, and notify support@cashncarryng.com promptly of suspected misuse. We may require email verification or other security steps. We may restrict accounts for verified fraud, abuse or legal violations, subject to applicable law and reasonable review.

4. Listings and pricing
Sellers are responsible for accurate descriptions, images, prices, stock and delivery coverage. Prices are shown in Nigerian naira unless otherwise stated. We aim to correct clear errors and will not substitute a higher price after payment without your agreement. Promotions are subject to stated conditions.

5. Orders and payment
An order is submitted when you confirm checkout; acceptance and fulfilment depend on stock, payment verification and seller confirmation. Payment may be handled by Flutterwave or another disclosed processor. An on-screen redirect alone does not prove successful payment. We will provide order status and receipts based on verified transaction information. Do not pay sellers outside authorised checkout for an on-platform order.

6. Delivery, cancellations and refunds
Delivery options, fees and estimated timing should be shown before payment. Our Delivery Policy and Returns and Refunds Policy explain the process. Nothing in these Terms limits non-excludable statutory consumer remedies for faulty, misdescribed or otherwise nonconforming goods.

7. Livestream shopping
Livestream demonstrations and chat are for product discovery. A seller’s statement during a stream must not contradict the product listing or applicable consumer rights. Availability and final prices are confirmed at checkout. Livestream access may be interrupted by network or provider conditions.

8. User content and conduct
You must not post unlawful, deceptive, harassing, infringing or unsafe material; impersonate others; manipulate reviews; or interfere with the service. You grant Cash N Carry a limited, non-exclusive licence to host and display content you submit as necessary to operate the service, subject to applicable law and your rights.

9. Intellectual property
Cash N Carry branding and platform materials belong to their respective owners. You may not copy or misuse them without permission. Sellers retain rights in their own content and must have rights to materials they upload.

10. Service changes and liability
We may maintain, improve or temporarily suspend features for security and operational reasons. To the extent permitted by law, we are not responsible for losses caused solely by circumstances outside our reasonable control. Nothing here excludes liability that cannot lawfully be excluded, including mandatory consumer protections.

11. Complaints and disputes
Send complaints with order number and evidence to support@cashncarryng.com. PROPOSED service target, only once a staffed inbox is live: acknowledge within 2 business days; provide an initial substantive update within 5 business days; update unresolved cases at least every 5 business days. Complex disputes may take longer. These are operational targets, not guaranteed outcomes, and are NOT YET ACTIVE.

12. Governing law and contact
These Terms are governed by the laws of the Federal Republic of Nigeria, without removing mandatory consumer rights. Contact support@cashncarryng.com; operator Temidayo Ogundiya, business correspondence address to be confirmed (not a residential address).`
  },
  delivery: {
    title: "Delivery and Shipping Policy",
    path: "/delivery",
    content: `Effective date: [DATE OF OWNER APPROVAL — NOT YET SET]

1. How delivery works
Independent sellers arrange delivery and are responsible for packaging, dispatch and fulfilment of their orders. Delivery methods, confirmed coverage, seller-configured fees and any available pickup option must be shown before payment. Cash N Carry facilitates order records, communication and complaints; it does not represent itself as the delivery carrier. Mandatory consumer protections remain unaffected.

2. Delivery locations
Available locations depend on the seller and the selected product. A state appearing in the app does not guarantee delivery to every address. Customers must confirm coverage and the complete delivery quote at checkout. Any address restrictions or excluded locations will be displayed where supported.

3. Delivery charges
The final delivery charge is calculated from the seller’s configured shipping settings and applicable checkout options. Some sellers may use a default fee of ₦100, but this is not a platform-wide guarantee. The actual fee presented before payment governs the order. Sellers must not impose undisclosed delivery charges after checkout without the customer’s agreement.

4. Processing and delivery estimates
Each seller must display a realistic dispatch estimate and destination-specific delivery estimate before the buyer commits to an order. RECOMMENDED DEFAULT TARGET (not a promise): dispatch within 1–2 business days after verified payment; delivery approximately 2–5 business days within the same city and 3–10 business days elsewhere in Nigeria, ONLY where the seller/carrier confirms feasibility. Seller-specific estimates override these indicative ranges; delays, remote coverage, holidays and logistics constraints must be communicated promptly. Do not display unverified platform-wide delivery guarantees.

5. Tracking and confirmation
Where tracking is available, the order page will show updates or a tracking reference. Sellers should provide accurate dispatch and delivery status. Customers should inspect packages on arrival and report shortages, damage or incorrect items promptly using support@cashncarryng.com.

6. Failed delivery and incorrect address
Customers are responsible for accurate delivery information and availability to receive parcels. Where delivery fails, the seller/support team will explain available re-delivery, pickup or cancellation options and any lawful additional charges before they are incurred.

7. Pickup
If a seller offers pickup, the location, collection window, proof of collection and contact process must be shown before the order is confirmed. Do not travel until the seller confirms readiness.

8. Lost, damaged or delayed orders
Contact support@cashncarryng.com with the order number and evidence. Cash N Carry will coordinate with the seller and any carrier to investigate. The remedy will depend on the circumstances and applicable consumer law, and may include replacement, redelivery or refund.

9. Delivery support
Delivery questions: support@cashncarryng.com | Hours: [SUPPORT HOURS — CONFIRM].`
  },
  refunds: {
    title: "Returns, Cancellations and Refunds Policy",
    path: "/refunds",
    content: `Effective date: [DATE OF OWNER APPROVAL — NOT YET SET]

1. Our approach
We aim to resolve problems fairly and transparently. This policy supplements, and does not override, rights customers have under Nigerian consumer protection law. Seller-specific conditions cannot remove mandatory legal remedies.

2. When you may request help
Proposed voluntary change-of-mind policy: all product categories may be submitted for return requests within 7 calendar days after confirmed delivery. Approval requires unused, complete goods in resalable condition with original accessories and packaging where reasonably possible, except where consumer law requires otherwise. A lawful exception may apply to perishable, customised, hygiene-sensitive or digitally supplied items where return is impracticable or prohibited; each exception must be disclosed clearly before purchase and legally reviewed. Defective, unsafe, incorrect, misdescribed or nonconforming goods remain subject to mandatory statutory rights regardless of the voluntary seven-day period.

3. Reporting period
For a voluntary change-of-mind return, submit the request within 7 calendar days after delivery using the order support flow or support@cashncarryng.com. Provide order number and product details. Do not return goods before receiving return instructions. For defective, unsafe, incorrect or misdescribed goods, contact us promptly; the seven-day voluntary window does not restrict mandatory consumer rights. Return eligibility and legal exceptions require final approval.

4. How to request a return or refund
Open your order details and use the available support/refund feature, or email support@cashncarryng.com with order number, reason, photographs/video where relevant and preferred resolution. Do not send goods to an address until return instructions are provided.

5. Assessment and remedies
We or the seller may request reasonable evidence and inspect returned goods. Depending on the issue and applicable law, a suitable remedy may be repair, replacement, partial refund or full refund. Any restrictions for hygiene, perishables, custom goods or digital items must be lawful, clearly disclosed before purchase and reviewed case by case.

6. Cancellation before dispatch
Customers may request cancellation before dispatch through the order page or support. A cancellation request is not complete until confirmed. If payment has already settled, the refund process begins after eligibility and transaction status are verified. For orders already dispatched, return procedures may apply.

7. Return shipping costs
RECOMMENDED ALLOCATION: for a voluntary change-of-mind return, the buyer pays reasonable return postage, disclosed before purchase and before authorising the return. For wrong, defective, unsafe, damaged-on-arrival or materially misdescribed goods, the seller bears reasonable necessary return shipping costs where legally required. Neither party may impose a charge that defeats statutory remedies. Any special collection method must be agreed in the case record.

8. Refund processing
A refund is not complete merely because a request is approved. PROPOSED internal target, subject to staffing and payment-provider integration: review a complete return/refund request within 5 business days; once eligibility is confirmed and any required return inspection is complete, initiate the authorised refund within 3 business days. The actual arrival of funds depends on Flutterwave and the buyer’s bank/payment method; do not promise a fixed settlement date without provider confirmation. If payment cannot be safely refunded through the original method, obtain documented approval for an appropriate lawful alternative. These targets are NOT ACTIVE until tested and approved.

9. Disputes and escalation
To appeal a return or refund decision, contact support@cashncarryng.com. PROPOSED service target after inbox activation: acknowledge within 2 business days, provide an initial substantive response within 5 business days, and issue updates every 5 business days for unresolved cases. Customers retain applicable rights to escalate to the relevant regulator or court.

10. Contact
Returns and refunds: support@cashncarryng.com | Operator: Temidayo Ogundiya.`
  },
  "seller-terms": {
    title: "Seller Terms",
    path: "/seller-terms",
    content: `Effective date: [DATE OF OWNER APPROVAL — NOT YET SET]

1. Seller agreement
These Seller Terms apply to individuals and businesses listing or selling through Cash N Carry. Sellers must be legally able to trade, provide accurate registration/contact details and comply with Nigerian laws and applicable product, advertising, tax and consumer obligations.

2. Verification and eligibility
We may require identity, business, bank and store verification and may decline, suspend or request additional information where justified. Approval is not a guarantee of sales or endorsement of product quality. Sellers must keep their information current.

3. Listings and prohibited products
Listings must accurately describe the item, price, condition, stock, brand, origin, variants, safety information and delivery restrictions. Sellers must own or have permission to use listing images and content. Counterfeit, stolen, illegal, dangerous or otherwise prohibited items are not allowed. The detailed prohibited-item schedule is [LINK TO APPROVED SELLER PRODUCT RULES].

4. Orders and inventory
Sellers must maintain accurate stock and promptly fulfil valid, verified paid orders. Do not request off-platform payments for orders placed on Cash N Carry. Do not confirm unpaid orders as paid. Respect the platform’s order statuses and preserve evidence of dispatch and delivery.

5. Shipping and customer service
Sellers arrange and are responsible for delivery. Each seller must accurately configure coverage, delivery fees, dispatch estimates, carriers or pickup arrangements and keep buyers informed of delays. Cash N Carry facilitates platform communication and complaints but does not guarantee a particular delivery time unless expressly confirmed.

6. Returns, refunds and consumer rights
Sellers must honour the proposed 7-calendar-day voluntary change-of-mind request window across lawful product categories, subject to disclosed condition rules and lawful exceptions; mandatory consumer remedies are separate and take priority. Buyers normally pay voluntary-return postage; sellers bear reasonable necessary costs for their own incorrect, defective or nonconforming goods where law requires. This rule becomes binding only after owner approval and implementation.

7. Livestream sales
Sellers may demonstrate and promote only eligible products they are authorised to sell. Claims must be truthful; do not fabricate scarcity, testimonials, prices or product results. Do not expose customers’ personal data, engage in harassment or direct viewers to unsafe off-platform payment methods. Seller-controlled streams may be moderated, ended or removed for violations.

8. Fees, payouts and taxes
RECOMMENDED LAUNCH COMMERCIAL MODEL — NOT YET APPROVED OR IMPLEMENTED: 0% marketplace commission during a clearly announced introductory pilot; seller pays its own shipping/fulfilment costs; disclose any payment-provider charges and never silently deduct them. Before moving to a paid commission, publish an exact rate and effective date and obtain seller acceptance. PROPOSED payout rule: release eligible cleared seller proceeds after verified payment, fulfilment confirmation and a 7-calendar-day post-delivery reserve/return-review period, with documented holds only for disputes, chargebacks, fraud or legal obligations; use a transparent seller ledger and reconciliation. Do not promise payouts or collect commission until the actual Flutterwave settlement model, merchant-of-record status, payout functionality, refunds, fees and taxes have been verified and implemented. Sellers remain responsible for applicable taxes, subject to statutory withholding/reporting.

9. Data protection
Sellers may use customer data only to fulfil orders, provide necessary support and comply with law. They must protect it, restrict access, avoid unrelated marketing without a lawful basis and notify Cash N Carry promptly of suspected compromise at [SECURITY CONTACT].

10. Enforcement and appeals
We may remove listings, restrict livestreams, pause payouts where lawful, suspend accounts or terminate access for fraud, serious safety risks or repeated violations. We will provide notice and an appeal route where practicable and legally appropriate: [SELLER APPEALS PROCESS]. Outstanding lawful customer obligations survive suspension.

11. Intellectual property and platform rights
Sellers retain rights in their content and grant Cash N Carry a limited licence to display, distribute and promote listings and streams as needed to provide the service. Sellers warrant they hold the necessary rights and will address substantiated infringement complaints.

12. Changes and contact
We will notify sellers of material changes as required. Governing law: Nigeria. Seller support: support@cashncarryng.com; operator Temidayo Ogundiya.`
  },
  "community-guidelines": {
    title: "Community Guidelines and Livestream Rules",
    path: "/community-guidelines",
    content: `Effective date: [DATE OF OWNER APPROVAL — NOT YET SET]

1. Our community
Cash N Carry is a place to discover products, watch shopping livestreams, ask questions and buy safely. These rules apply to buyers, sellers, livestream hosts, viewers, reviews, chat, profiles and other content.

2. Respectful participation
Do not bully, threaten, harass, discriminate, sexually exploit, stalk or impersonate anyone. Do not publish another person’s private information or encourage violence. Keep chat relevant to the shopping experience.

3. Honest commerce
Do not post fake reviews, manipulated ratings, misleading product claims, counterfeit listings, false giveaways, deceptive discounts, fabricated viewer activity or fraudulent payment instructions. Disclose relevant sponsorships or material relationships where required.

4. Safe livestreaming
Hosts must not broadcast unlawful, dangerous or infringing content; reveal customer addresses or payment details; demonstrate prohibited goods; or encourage off-platform payments. Viewers must not spam, disrupt streams or harass hosts. Product pins must match legitimate, available listings.

5. Content and intellectual property
Post only content you have the right to share. Do not upload pirated videos, music, images or trademarks without permission or other lawful basis. Report suspected infringement through [IP REPORTING CONTACT/PROCESS].

6. Privacy and minors
Do not share passwords, one-time codes, banking details, home addresses or identification documents in public chat. Do not exploit or endanger minors. Report suspected child-safety violations immediately through [SAFETY REPORTING CHANNEL].

7. Reporting and moderation
Users can report suspicious listings, chat, reviews, accounts or livestreams through available reporting controls or support@cashncarryng.com. We may remove content, mute chat, stop a stream, limit features or suspend accounts proportionately to the violation. Serious or illegal content may be escalated to competent authorities when appropriate.

8. Appeals
If content or an account is restricted, request review through support@cashncarryng.com (subject: Moderation Appeal). We will consider the context, evidence, seriousness and repeat behaviour. We may preserve relevant records as required for safety, disputes or law.

9. Updates and contact
These guidelines may be updated with notice where appropriate. Safety concerns: support@cashncarryng.com.`
  }
};

export const publicPolicyLinks = Object.entries(policyDefinitions).map(([id, p]) => ({
  id: id as PolicyId,
  title: p.title,
  path: p.path
}));

export function policyBlockers(content: string): string[] {
  const blockers: string[] = [];
  const bracketed = [...content.matchAll(/\[([^\]]+)\]/g)].map((match) => match[1].trim());
  const isCompletedDate = (value: string) => {
    let year: number, month: number, day: number;
    const iso = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    const dmy = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (iso) [, year, month, day] = iso.map(Number) as [number, number, number, number];
    else if (dmy) [, day, month, year] = dmy.map(Number) as [number, number, number, number];
    else return false;
    if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return false;
    const parsed = new Date(Date.UTC(year, month - 1, day));
    return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day;
  };
  if (bracketed.some((value) => !isCompletedDate(value))) blockers.push("Resolve bracketed owner or operational placeholders; valid completed dates in DD/MM/YYYY or YYYY-MM-DD format are accepted.");
  if (bracketed.some((value) => /^\d{1,4}[/-]\d{1,2}[/-]\d{1,4}$/.test(value) && !isCompletedDate(value))) blockers.push("Correct invalid bracketed dates (use DD/MM/YYYY or YYYY-MM-DD, with a year from 1900 to 2100).");
  if (/NOT YET SET|NOT YET ACTIVE|NOT VERIFIED|NOT ACTIVE|NOT YET APPROVED|NOT YET MONITORED/i.test(content)) blockers.push("Replace draft-only dates and confirm all proposed or unverified terms.");
  if (/PROPOSED|RECOMMENDED|confirm (?:account age|provider|recording|retention|cookie|data|merchant|appeal|support)/i.test(content)) blockers.push("Verify proposed operational, privacy and legal statements before approval.");
  return blockers;
}

/** Return the exact text fragments that triggered the approval checks. */
export function policyBlockerMatches(content: string): Array<{ blocker: string; matches: string[] }> {
  const findings: Array<{ blocker: string; matches: string[] }> = [];
  const add = (blocker: string, matches: string[]) => {
    const unique = [...new Set(matches.map((match) => match.trim()).filter(Boolean))].slice(0, 8);
    if (unique.length) findings.push({ blocker, matches: unique });
  };
  const bracketed = [...content.matchAll(/\[([^\]]+)\]/g)].map((match) => match[1].trim());
  const isCompletedDate = (value: string) => {
    let year: number, month: number, day: number;
    const iso = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    const dmy = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (iso) [, year, month, day] = iso.map(Number) as [number, number, number, number];
    else if (dmy) [, day, month, year] = dmy.map(Number) as [number, number, number, number];
    else return false;
    if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return false;
    const parsed = new Date(Date.UTC(year, month - 1, day));
    return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day;
  };
  const placeholders = bracketed.filter((value) => !isCompletedDate(value));
  add("Resolve bracketed owner or operational placeholders", placeholders.map((value) => `[${value}]`));

  const invalidDates = bracketed.filter((value) => /^\d{1,4}[/-]\d{1,2}[/-]\d{1,4}$/.test(value) && !isCompletedDate(value));
  add("Correct invalid bracketed dates", invalidDates.map((value) => `[${value}]`));

  const draftMarkers = content.match(/NOT YET SET|NOT YET ACTIVE|NOT VERIFIED|NOT ACTIVE|NOT YET APPROVED|NOT YET MONITORED/gi) || [];
  add("Replace draft-only dates and confirm proposed or unverified terms", draftMarkers);

  const proposed = content.match(/PROPOSED|RECOMMENDED|confirm (?:account age|provider|recording|retention|cookie|data|merchant|appeal|support)/gi) || [];
  add("Verify proposed operational, privacy and legal statements", proposed);
  return findings;
}

export function currentPolicyVersion(records: Array<{ version: number; status: string }>) {
  return records.reduce((latest, row) => !latest || row.version > latest.version ? row : latest, undefined as typeof records[number] | undefined);
}
