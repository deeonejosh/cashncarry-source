import { env } from 'cloudflare:workers';
const paymentMode=()=>env.FLW_MODE==='live'?'live':'test';
export function eligibleSellerSQL(alias='s') {
 if (!/^[a-zA-Z]+$/.test(alias)) throw Error('Invalid alias');
 return `${alias}.verified=1 AND ${alias}.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles sp WHERE sp.id=${alias}.owner AND sp.suspended=1) AND (EXISTS(SELECT 1 FROM seller_subscriptions ss WHERE ss.store=${alias}.id AND ss.mode='${paymentMode()}' AND ss.status='active' AND ss.paid_until>strftime('%Y-%m-%dT%H:%M:%fZ','now')) OR EXISTS(SELECT 1 FROM founding_enrollments fe JOIN founding_program fp ON fp.id=1 WHERE fe.store=${alias}.id AND fp.enabled=1 AND fe.status='active' AND fe.starts_at<=strftime('%Y-%m-%dT%H:%M:%fZ','now') AND fe.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now')))`;
}
export async function sellerActivation(store:string) {
 const mode=paymentMode();
 const row:any=await env.DB!.prepare(`SELECT s.verified,s.suspended,COALESCE(p.suspended,0) AS account_suspended,ss.status AS subscription_status,ss.paid_until,ss.cancel_at_end,ss.provider_subscription,ss.provider_plan,ss.customer_email,(SELECT status FROM verification_requests WHERE store=s.id ORDER BY created DESC,rowid DESC LIMIT 1) AS review_status FROM stores s LEFT JOIN profiles p ON p.id=s.owner LEFT JOIN seller_subscriptions ss ON ss.store=s.id AND ss.mode=? WHERE s.id=?`).bind(mode,store).first();
 if(!row) throw Error('Create a storefront first');
 const [paid,billing,next,founding]:any[]=await Promise.all([
  env.DB!.prepare("SELECT amount_minor FROM seller_subscription_payments WHERE store=? AND mode=? AND status='paid' ORDER BY period_end DESC,created DESC LIMIT 1").bind(store,mode).first(),
  env.DB!.prepare('SELECT value FROM platform_settings WHERE key=?').bind(`seller_subscription_billing_${mode}_${store}`).first(),
  env.DB!.prepare('SELECT value FROM platform_settings WHERE key=?').bind(`seller_subscription_next_${mode}_${store}`).first(),
  env.DB!.prepare("SELECT fe.status,fe.starts_at,fe.ends_at,fp.enabled,fp.duration_days FROM founding_enrollments fe JOIN founding_program fp ON fp.id=1 WHERE fe.store=?").bind(store).first(),
 ]);
 const suspended=Boolean(row.suspended||row.account_suspended);
 const verification=suspended?'suspended':row.verified?'verified':row.review_status==='approved'?'not_started':row.review_status||'not_started';
 const subscription=row.subscription_status==='active'&&row.paid_until>new Date().toISOString()?'active':row.paid_until?'expired':'inactive';
 const foundingActive=Boolean(founding?.enabled&&founding.status==='active'&&founding.starts_at<=new Date().toISOString()&&founding.ends_at>new Date().toISOString());
 const planConfigured=Boolean(row.provider_plan)&&!Boolean(row.cancel_at_end);
 const billingStatus=billing?.value||(row.provider_subscription&&!row.cancel_at_end?'active':row.provider_plan?'provider_confirmation_pending':'manual');
 return {verification,subscription:foundingActive?'founding':subscription,paidUntil:foundingActive?founding.ends_at:row.paid_until||'',foundingActive,foundingEnd:founding?.ends_at||'',monthlyPriceMinor:Number(paid?.amount_minor||0),cancelAtEnd:Boolean(row.cancel_at_end),renewalConfigured:planConfigured,autoRenewal:planConfigured&&billingStatus==='active'&&Boolean(row.provider_subscription),providerSubscriptionAvailable:Boolean(row.provider_subscription),nextRenewal:next?.value||'',billingStatus,canSell:!suspended&&Boolean(row.verified)&&(subscription==='active'||foundingActive),mode};
}
export async function requireSellerActive(store:string) {
 const state=await sellerActivation(store);
 if(!state.canSell) throw Error(state.verification==='suspended'?'Selling is suspended. Contact support to appeal; existing orders remain accessible.':state.verification!=='verified'?'Complete seller verification before publishing products or broadcasting.':'An active seller subscription is required. Renew in Seller Centre; existing orders remain accessible.');
 return state;
}
