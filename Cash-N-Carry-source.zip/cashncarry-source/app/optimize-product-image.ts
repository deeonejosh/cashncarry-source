/** Downsize seller product photos in the browser before sending them to storage. */
export async function optimizeProductImage(file: File): Promise<File> {
  // Product photos are displayed primarily in compact cards. Keep enough
  // resolution for detail views while avoiding multi-megabyte originals.
  const maxDimension = 1200;
  const maxUsefulBytes = 100_000;
  if (typeof createImageBitmap !== "function" || typeof document === "undefined") return file;

  let bitmap: ImageBitmap | undefined;
  try {
    bitmap = await createImageBitmap(file);
    const longest = Math.max(bitmap.width, bitmap.height);
    if (longest <= maxDimension && file.size <= maxUsefulBytes) return file;

    const scale = Math.min(1, maxDimension / longest);
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d", { alpha: file.type !== "image/jpeg" });
    if (!context) return file;
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);

    let smallest: Blob | null = null;
    for (const quality of [0.84, 0.76, 0.68]) {
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/webp", quality));
      if (!blob || blob.size >= file.size || (smallest && blob.size >= smallest.size)) continue;
      smallest = blob;
      if (blob.size <= maxUsefulBytes) break;
    }
    // Only trade photo quality for a meaningful transfer-size reduction.
    if (smallest && (smallest.size <= maxUsefulBytes || smallest.size <= file.size * 0.85)) {
      const base = file.name.replace(/\.[^.]+$/, "") || "product-image";
      return new File([smallest], `${base}.webp`, {
        type: "image/webp",
        lastModified: file.lastModified || Date.now(),
      });
    }
    return file;
  } catch {
    // Keep upload usable in older browsers or for images the browser cannot decode.
    return file;
  } finally {
    bitmap?.close();
  }
}
