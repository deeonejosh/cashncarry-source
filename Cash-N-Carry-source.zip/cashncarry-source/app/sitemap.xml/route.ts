import { env } from "cloudflare:workers";
import { ensureVideoStorefrontSchema } from "../video-storefront-schema";
const escape = (s: string) =>
  s.replace(
    /[<>&'\"]/g,
    (c) =>
      ({
        "<": "&lt;",
        ">": "&gt;",
        "&": "&amp;",
        "'": "&apos;",
        '"': "&quot;",
      })[c]!,
  );
export async function GET() {
  try {
    await ensureVideoStorefrontSchema();
    const origin = new URL(env.SITE_URL || "https://cashncarryng.com").origin;
    // Public core pages remain discoverable during a transient database outage.
    const results = await Promise.allSettled([
      env.DB!.prepare("SELECT p.id FROM products p JOIN stores s ON s.id=p.store WHERE p.active=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)").all<{id:string}>(),
      env.DB!.prepare("SELECT id FROM stores WHERE suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles x WHERE x.id=stores.owner AND x.suspended=1)").all<{id:string}>(),
      env.DB!.prepare("SELECT DISTINCT policy_id FROM policy_versions WHERE status='published'").all<{policy_id:string}>(),
    ]);
    const products = results[0].status === 'fulfilled' ? results[0].value.results : [];
    const stores = results[1].status === 'fulfilled' ? results[1].value.results : [];
    const publishedPolicies = results[2].status === 'fulfilled' ? results[2].value.results : [];
    const policyPaths: Record<string, string> = {
      privacy: "/privacy", terms: "/terms", delivery: "/delivery", refunds: "/refunds",
      "seller-terms": "/seller-terms", "community-guidelines": "/community-guidelines",
    };
    const paths = [
      "/",
      "/help",
      "/live-auctions",
      "/for-you",
      ...publishedPolicies.map((policy) => policyPaths[policy.policy_id]).filter(Boolean),
      ...products.map((p) => "/product/" + encodeURIComponent(p.id)),
      ...stores.map((s) => "/store/" + encodeURIComponent(s.id)),
    ];
    return new Response(
      `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths.map((p) => `<url><loc>${escape(origin + p)}</loc></url>`).join("")}</urlset>`,
      {
        headers: {
          "Content-Type": "application/xml; charset=utf-8",
          "Cache-Control": "public,max-age=300",
        },
      },
    );
  } catch {
    return new Response("Sitemap temporarily unavailable", {
      status: 503,
      headers: { "Cache-Control": "no-store" },
    });
  }
}
