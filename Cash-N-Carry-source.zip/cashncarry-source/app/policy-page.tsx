import { env } from "cloudflare:workers";
import { CustomerHeader, CustomerNavigation } from "./customer-shell";
import { policyDefinitions, type PolicyId } from "./policy-drafts";
import { platformWording } from "./brand";

export const dynamic = "force-dynamic";

type PublishedPolicy = { title: string; content: string; version: number; published_at: string | null; effective_date: string | null };

async function publishedPolicy(policyId: PolicyId) {
  try {
    return await env.DB?.prepare(
      "SELECT * FROM policy_versions WHERE policy_id=? AND status='published' ORDER BY version DESC LIMIT 1",
    ).bind(policyId).first<PublishedPolicy>();
  } catch {
    return null;
  }
}

export async function policyMetadata(policyId: PolicyId) {
  const p = policyDefinitions[policyId];
  const record = await publishedPolicy(policyId).catch(() => null);
  return {
    title: `${p.title} — Cash N Carry`,
    description: "Cash N Carry marketplace policy for Nigeria.",
    alternates: { canonical: p.path },
    robots: record ? { index: true, follow: true } : { index: false, follow: false },
  };
}

function PolicyContent({ content }: { content: string }) {
  // The effective date and update date are rendered from the approved record below.
  // Remove legacy copies embedded in policy prose so customers see one authoritative date.
  const displayContent = content.replace(/^\s*(?:Effective date|Effective|Last updated)(?:\s*:\s*|\s+)[^\n]*\n?/gim, "");
  const blocks = displayContent.split(/\n\s*\n/).map((block) => block.trim()).filter(Boolean);
  return <div className="policy-content">
    {blocks.map((block, index) => {
      const lines = block.split("\n");
      const first = lines[0] || "";
      if (/^\d+\.\s+/.test(first)) return <section key={index} aria-labelledby={`policy-section-${index}`}>
        <h2 id={`policy-section-${index}`}>{platformWording(first)}</h2>
        {lines.length > 1 && <p>{platformWording(lines.slice(1).join(" "))}</p>}
      </section>;
      return <p key={index}>{platformWording(block.replaceAll("\n", " "))}</p>;
    })}
  </div>;
}

export default async function PolicyPage({ policyId }: { policyId: PolicyId }) {
  const record = await publishedPolicy(policyId);
  if (!record) {
    const policy = policyDefinitions[policyId];
    return <>
      <CustomerHeader />
      <main id="main-content" tabIndex={-1} className="customer-page policy-page">
        <p className="eyebrow">CASH N CARRY POLICY</p>
        <h1>{policy.title}</h1>
        <section className="notice" role="status" aria-live="polite">
          <h2>This policy has not been published yet</h2>
          <p>The reviewed version is not available yet. No draft policy text is shown on this page.</p>
        </section>
        <p><a href="/help">Visit Help and contact</a></p>
      </main>
      <CustomerNavigation />
    </>;
  }
  const updated = String(record.published_at || record.effective_date || "").slice(0, 10);
  return <>
    <CustomerHeader />
    <main id="main-content" tabIndex={-1} className="customer-page policy-page">
      <p className="eyebrow">CASH N CARRY POLICY · VERSION {record.version}</p>
      <h1>{platformWording(record.title)}</h1>
      {policyId === "seller-terms" && /(?:^|\n)3\.\s+Listings and prohibited\s*$/i.test(String(record.content).trim()) && <section className="notice" role="alert" aria-labelledby="seller-terms-incomplete-title">
        <h2 id="seller-terms-incomplete-title">This published Seller Terms page appears incomplete</h2>
        <p>The text ends before the rest of the seller agreement. Please do not treat this page as the complete terms until a reviewed version is published.</p>
      </section>}
      <PolicyContent content={String(record.content)} />
      <p><a href="/help">Help and policy questions</a></p>
      <small>Effective {record.effective_date || updated} · Last updated {updated}</small>
    </main>
    <CustomerNavigation />
  </>;
}
