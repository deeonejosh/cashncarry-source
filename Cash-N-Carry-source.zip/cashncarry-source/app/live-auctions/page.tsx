import LiveAuctions from "./panel";
export const dynamic="force-dynamic";
export const metadata={title:"Auctions in live broadcasts — Cash N Carry",description:"Watch a Cash N Carry seller livestream to view auction countdowns and place bids during the broadcast.",alternates:{canonical:"/live-auctions"}};
export default function Page(){return <LiveAuctions/>;}
