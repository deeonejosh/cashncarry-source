"use client";
import { CustomerHeader, CustomerNavigation } from "../customer-shell";
import Link from "next/link";
export default function LiveAuctions(){return <><CustomerHeader active="Live" back="/?browse=1#live"/><main id="main-content" className="auction-board customer-page"><header><p className="eyebrow">Live shopping</p><h1>Auctions happen in the livestream</h1><p>Join a seller’s live broadcast to see the auction countdown, current bid and bidding controls. Auctions are only available while that broadcast is live.</p><Link className="primary" href="/?browse=1#live">Watch live now</Link></header></main><CustomerNavigation active="Live"/></>}
