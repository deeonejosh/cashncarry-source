import { requireSellerActive, eligibleSellerSQL } from "./seller-activation";
import { deliveryQuote } from "./delivery-quote";
import { getStreamConfig } from "./stream-config";
import { orderEmail, refundEmail, safelyEmail } from "./email-events";
import { env } from "cloudflare:workers";
import { paymentsAvailable, initiatePayment, paymentMode } from "./payments";
export const states = [
  "Abia",
  "Adamawa",
  "Akwa Ibom",
  "Anambra",
  "Bauchi",
  "Bayelsa",
  "Benue",
  "Borno",
  "Cross River",
  "Delta",
  "Ebonyi",
  "Edo",
  "Ekiti",
  "Enugu",
  "FCT",
  "Gombe",
  "Imo",
  "Jigawa",
  "Kaduna",
  "Kano",
  "Katsina",
  "Kebbi",
  "Kogi",
  "Kwara",
  "Lagos",
  "Nasarawa",
  "Niger",
  "Ogun",
  "Ondo",
  "Osun",
  "Oyo",
  "Plateau",
  "Rivers",
  "Sokoto",
  "Taraba",
  "Yobe",
  "Zamfara",
];
const q = (s: string, ...a: any[]) => env.DB!.prepare(s).bind(...a);
const all = async (s: string, ...a: any[]) => (await q(s, ...a).all()).results;
const clean = (v: any, n = 1000) =>
  String(v ?? "")
    .trim()
    .slice(0, n);
const integer = (v: any, min = 0, max = 100000000) => {
  const x = Number(v);
  if (
    v === "" ||
    v == null ||
    typeof v === "boolean" ||
    !Number.isSafeInteger(x) ||
    x < min ||
    x > max
  )
    throw Error("Enter a valid number");
  return x;
};
export async function extraData(uid: string | null, store: any) {
  const [addresses, favourites, notifications, preferences, myStreams, financials, stream, sponsored, policies, categories] = await Promise.all([
    uid ? all("SELECT * FROM addresses WHERE user=?", uid) : [],
    uid ? all("SELECT product FROM favourites WHERE user=?", uid) : [],
    uid ? all("SELECT * FROM notifications WHERE user=? ORDER BY created DESC LIMIT 100", uid) : [],
    uid ? q("SELECT * FROM preferences WHERE user=?", uid).first() : null,
    store ? all("SELECT id,store,title,url,product,featured,status,created,scheduled,provider,replay FROM streams WHERE store=? ORDER BY created DESC", store.id) : [],
    store ? all("SELECT p.id,p.order_id,p.amount,p.status,p.mode,p.created FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.store=?", store.id) : [],
    getStreamConfig().then(Boolean).catch(() => false),
    all("SELECT c.id,c.title,c.placement,c.product,p.name,p.image,p.price,s.name AS seller FROM campaigns c JOIN stores s ON s.id=c.store JOIN products p ON p.id=c.product WHERE c.status='active' AND c.payment_status='paid' AND c.starts<=? AND c.ends>? AND p.active=1 AND s.suspended=0 AND " + eligibleSellerSQL() + " LIMIT 12", new Date().toISOString(), new Date().toISOString()),
    all("SELECT policy_id AS id,title,content,version,effective_date,published_at FROM policy_versions WHERE status='published' ORDER BY policy_id,version DESC").catch(() => []),
    all("SELECT * FROM categories WHERE active=1"),
  ]);
  return { addresses, favourites, notifications, preferences, myStreams, financials,
    payments: { cod: false, online: paymentsAvailable(), mode: paymentMode() },
    services: { email: Boolean(env.RESEND_API_KEY && env.BETTER_AUTH_SECRET), stream },
    sponsored, policies, categories };
}
export async function extraAction(
  b: any,
  u: any,
  store: any,
  req?: Request,
): Promise<any | null> {
  const a = b.action,
    uid = u.userId,
    now = new Date().toISOString();
  if (a === "profile") {
    const name = clean(b.name, 100);
    if (name.length < 2) throw Error("Enter a display name with at least 2 characters");
    if (b.username === undefined) {
      await q("UPDATE profiles SET name=? WHERE id=?", name, uid).run();
    } else {
      const username = String(b.username ?? "").trim().toLowerCase();
      if (!/^[a-z][a-z0-9_]{2,23}$/.test(username))
        throw Error("Username must be 3–24 characters: start with a letter and use letters, numbers or underscores");
      if (["admin", "administrator", "support", "cashncarry", "cashncarryng", "system", "moderator", "official"].includes(username))
        throw Error("This username is reserved. Choose another");
      try {
        await q("UPDATE profiles SET name=?,username=? WHERE id=?", name, username, uid).run();
      } catch (error) {
        if (String(error).includes("UNIQUE constraint failed")) throw Error("That username is taken. Choose another");
        throw error;
      }
    }
    return { ok: true };
  }
  if (a === "address") {
    if (b.remove) {
      await q(
        "DELETE FROM addresses WHERE id=? AND user=?",
        clean(b.id),
        uid,
      ).run();
      return { ok: true };
    }
    if (
      !states.includes(b.state) ||
      !clean(b.line) ||
      !clean(b.name) ||
      !/^\+?[0-9 ()-]{8,20}$/.test(clean(b.phone))
    )
      throw Error(
        "Provide a recipient, valid phone, address and Nigerian state",
      );
    const aid = clean(b.id) || crypto.randomUUID();
    await q(
      "INSERT INTO addresses(id,user,name,phone,line,state,area,created) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,phone=excluded.phone,line=excluded.line,state=excluded.state,area=excluded.area WHERE addresses.user=excluded.user",
      aid,
      uid,
      clean(b.name, 100),
      clean(b.phone, 30),
      clean(b.line, 500),
      b.state,
      clean(b.area, 100),
      now,
    ).run();
    return { ok: true };
  }
  if (a === "favourite") {
    if (
      !(await q(
        "SELECT id FROM products WHERE id=? AND active=1",
        clean(b.product),
      ).first())
    )
      throw Error("Product unavailable");
    if (b.saved)
      await q(
        "INSERT INTO favourites(id,user,product) VALUES(?,?,?) ON CONFLICT(user,product) DO NOTHING",
        crypto.randomUUID(),
        uid,
        b.product,
      ).run();
    else
      await q(
        "DELETE FROM favourites WHERE user=? AND product=?",
        uid,
        b.product,
      ).run();
    return { ok: true };
  }
  if (a === "preferences") {
    await q(
      "INSERT INTO preferences(user,order_updates,live_alerts,marketing) VALUES(?,?,?,?) ON CONFLICT(user) DO UPDATE SET order_updates=excluded.order_updates,live_alerts=excluded.live_alerts,marketing=excluded.marketing",
      uid,
      b.order_updates ? 1 : 0,
      b.live_alerts ? 1 : 0,
      b.marketing ? 1 : 0,
    ).run();
    return { ok: true };
  }
  if (a === "read-notifications") {
    await q("UPDATE notifications SET read=1 WHERE user=?", uid).run();
    return { ok: true };
  }
  if (a === "checkout") {
    if (
      b.payment !== "flutterwave"
    )
      throw Error("Choose Debit card payment. Cash on delivery is no longer available.");
    if (b.delivery_state && !states.includes(b.delivery_state))
      throw Error("Choose a valid Nigerian delivery state");
    if (!/^[a-f0-9-]{36}$/.test(clean(b.key)))
      throw Error("Invalid checkout request");
    const existing: any = await q(
      "SELECT * FROM orders WHERE buyer=? AND id LIKE ?",
      uid,
      b.key + "-%",
    ).first();
    if (existing) {
      await safelyEmail(()=>orderEmail(existing.id,"created"));
      return {
        ok: true,
        orderIds: [existing.id],
        paymentLink:
          existing.payment === "flutterwave"
            ? await initiatePayment(existing, u.email)
            : undefined,
      };
    }
    if (
      !clean(b.name) ||
      !clean(b.address) ||
      !/^\+?[0-9 ()-]{8,20}$/.test(clean(b.phone))
    )
      throw Error("Provide your delivery name, phone and address");
    const directProduct = b.product ? clean(b.product, 100) : "";
    let rows: any[];
    if (directProduct) {
      const quantity = integer(b.quantity, 1, 99);
      const variant = clean(b.variant, 100);
      const selected = await q(
        "SELECT ? AS quantity,? AS variant,p.*,s.suspended,s.shipping_fee AS delivery_fee,s.coverage FROM products p JOIN stores s ON s.id=p.store WHERE p.id=?",
        quantity,
        variant,
        directProduct,
      ).first();
      rows = selected ? [selected] : [];
    } else {
      rows = await all(
        "SELECT c.quantity,c.variant,p.*,s.suspended,s.shipping_fee AS delivery_fee,s.coverage FROM carts c JOIN products p ON p.id=c.product JOIN stores s ON s.id=p.store WHERE c.user=?",
        uid,
      );
    }
    if (!rows.length) throw Error("Your cart is empty");
    const requestedDeals: Record<string,string> = b.deals && typeof b.deals === "object" ? b.deals : {};
    if (directProduct && b.dealId) requestedDeals[directProduct] = String(b.dealId);
    const orderDeals: Array<{id:string;product:string;quantity:number;price:number}> = [];
    for (const p of rows) {
      const variants = JSON.parse(p.variants || "[]");
      const v = variants.find((v: any) => v.name === p.variant);
      if (variants.length && !v) throw Error("A variant is unavailable");
      if (v) {
        p.price = v.price;
        p.stock = v.stock;
      }
      const dealId=String(requestedDeals[p.id]||"");
      if(dealId){
        if(p.variant)throw Error("Live deals do not apply to variant selections.");
        const deal:any=await q("SELECT d.id,d.product,d.stream,d.promo_price,d.max_quantity,d.sold_quantity,d.starts_at,d.ends_at,d.status FROM livestream_deals d JOIN streams s ON s.id=d.stream WHERE d.id=? AND d.product=? AND d.store=? AND s.id=? AND d.status IN ('active','scheduled') AND d.starts_at<=? AND d.ends_at>?",dealId,p.id,p.store,String(b.stream||""),now,now).first();
        if(!deal||deal.sold_quantity+p.quantity>deal.max_quantity)throw Error("This livestream deal has expired or its promotional quantity is no longer available.");
        p._regularPrice=p.price;p.price=deal.promo_price;p._dealId=deal.id;orderDeals.push({id:deal.id,product:p.id,quantity:p.quantity,price:p.price});
      }
    }
    if (new Set(rows.map((p) => p.store)).size !== 1)
      throw Error(
        "Single-seller checkout: keep products from one store in your cart.",
      );
    if (rows.some((p) => !p.active || p.suspended || p.quantity > p.stock))
      throw Error("An item is unavailable. Update your cart.");
    const suspended = await q(
      "SELECT x.id FROM profiles x JOIN stores s ON s.owner=x.id WHERE s.id=? AND x.suspended=1",
      rows[0].store,
    ).first();
    if (suspended) throw Error("Seller unavailable");
    await requireSellerActive(rows[0].store);
    if (deliveryQuote(rows[0]) === undefined)
      throw Error(
        "Delivery is not confirmed. Ask the seller to save delivery coverage and a fee before ordering.",
      );
    const coverage = JSON.parse(rows[0].coverage || "[]");
    if (
      coverage.length &&
      (!states.includes(b.delivery_state) ||
        !coverage.includes(b.delivery_state))
    )
      throw Error("This seller does not deliver to the selected state");
    const online = b.payment === "flutterwave";
    if (online && !paymentsAvailable())
      throw Error(
        "Debit card payment is temporarily unavailable. Please try again later.",
      );
    const oid = b.key + "-" + rows[0].store,
      fee = rows[0].delivery_fee,
      total = rows.reduce((n, p) => n + p.price * p.quantity, fee);
    let sourceStream:any=null,sourceProducts:string[]=[];
    if(b.stream){sourceStream=await q("SELECT id,store,product,featured,status FROM streams WHERE id=?",String(b.stream)).first();if(!sourceStream)throw Error("Livestream is unavailable.");const featured=[sourceStream.product,...JSON.parse(sourceStream.featured||"[]")].filter(Boolean);sourceProducts=rows.filter(p=>featured.includes(p.id)).map(p=>p.id);if(sourceProducts.length!==rows.length)throw Error("Only products featured in this livestream can be attributed to it.");for(const p of rows){if(p.store!==sourceStream.store){const partnership=await q("SELECT ap.id FROM affiliate_partnerships ap JOIN creator_profiles cp ON cp.user=ap.creator JOIN stores creator_store ON creator_store.owner=ap.creator JOIN stores product_store ON product_store.id=ap.store WHERE ap.creator=creator_store.owner AND creator_store.id=? AND ap.product=? AND ap.store=? AND ap.status='approved' AND cp.status='approved' AND product_store.suspended=0 AND product_store.verified=1",sourceStream.store,p.id,p.store).first();if(!partnership)throw Error("This livestream is not authorised to feature the seller's product.");}}}
    const stmts = [
      q(
        "INSERT INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,delivery_fee,delivery_state,created,seller_activation_required) VALUES(?,?,?,?,?,?,?,'placed',?,?,?,?,?,1)",
        oid,
        uid,
        rows[0].store,
        clean(b.name, 100),
        clean(b.phone, 30),
        clean(b.address, 700),
        total,
        "flutterwave",
        "pending",
        fee,
        clean(b.delivery_state, 50),
        now,
      ),
    ];
    for(const deal of orderDeals){
      stmts.push(q("INSERT INTO order_deal_snapshots(order_id,deal,product,quantity,price) VALUES(?,?,?,?,?)",oid,deal.id,deal.product,deal.quantity,deal.price));
    }
    if(sourceStream)for(const product of sourceProducts)stmts.push(q("INSERT INTO order_stream_snapshots(order_id,stream,product) VALUES(?,?,?)",oid,sourceStream.id,product));
    for(const p of rows){
      const bundle:any=await q("SELECT b.id,b.title,b.price FROM product_bundles b WHERE b.product=? AND b.active=1",p.id).first();
      if(bundle){const components=(await q("SELECT product AS id,name_snapshot AS name,price_snapshot AS price,quantity FROM product_bundle_items WHERE bundle=? ORDER BY name_snapshot",bundle.id).all()).results;stmts.push(q("INSERT INTO bundle_order_snapshots(order_id,bundle,title,contents,bundle_price) VALUES(?,?,?,?,?)",oid,bundle.id,bundle.title,JSON.stringify(components),p.price));}
    }
    for (const p of rows) {
      stmts.push(
        q(
          "INSERT INTO order_items(id,order_id,product,name,price,quantity,variant) VALUES(?,?,?,?,?,?,?)",
          crypto.randomUUID(),
          oid,
          p.id,
          p.name,
          p.price,
          p.quantity,
          p.variant || "",
        ),
      );
      if (!directProduct)
        stmts.push(
          q(
            "DELETE FROM carts WHERE user=? AND product=? AND quantity=? AND variant=?",
            uid,
            p.id,
            p.quantity,
            p.variant || "",
          ),
        );
    }
    if (online)
      stmts.push(
        q(
          "INSERT INTO payments(id,order_id,buyer,amount,currency,mode,status,expires,created,updated) VALUES(?,?,?,?,'NGN',?,'pending',?,?,?)",
          crypto.randomUUID(),
          oid,
          uid,
          total,
          paymentMode(),
          new Date(Date.now() + 30 * 60 * 1000).toISOString(),
          now,
          now,
        ),
      );
    const affiliateRef=req?.headers.get("cookie")?.match(/(?:^|; )cnc_aff_ref=([^;]+)/)?.[1];
    for(const p of rows){let partnership:any=null;if(affiliateRef)partnership=await q("SELECT ap.id,ap.commission_bps FROM affiliate_partnerships ap JOIN creator_profiles cp ON cp.user=ap.creator WHERE ap.id=? AND ap.product=? AND ap.store=? AND ap.status='approved' AND cp.status='approved'",affiliateRef,p.id,p.store).first();if(!partnership&&sourceStream&&p.store!==sourceStream.store)partnership=await q("SELECT ap.id,ap.commission_bps FROM affiliate_partnerships ap JOIN creator_profiles cp ON cp.user=ap.creator WHERE ap.creator=(SELECT owner FROM stores WHERE id=?) AND ap.product=? AND ap.store=? AND ap.status='approved' AND cp.status='approved'",sourceStream.store,p.id,p.store).first();if(partnership){const commission=Math.floor(p.price*p.quantity*Number(partnership.commission_bps)/10000);stmts.push(q("INSERT OR IGNORE INTO affiliate_commissions(id,partnership,order_id,amount,status,created,updated) VALUES(?,?,?,?,'pending',?,?)",crypto.randomUUID(),partnership.id,oid,commission,now,now));}}
    await env.DB!.batch(stmts);
    await safelyEmail(()=>orderEmail(oid,"created"));
    const order = {
      id: oid,
      buyer: uid,
      name: clean(b.name),
      phone: clean(b.phone),
      total,
    };
    return {
      ok: true,
      orderIds: [oid],
      paymentLink: online ? await initiatePayment(order, u.email) : undefined,
    };
  }
  if (a === "campaign") {
    if (!store || store.suspended) throw Error("Active store required");
    if (!clean(b.title) || !["discovery", "market"].includes(b.placement))
      throw Error("Add campaign title and placement");
    const starts = new Date(b.starts).toISOString(),
      ends = new Date(b.ends).toISOString(),
      days = Math.ceil((Date.parse(ends) - Date.parse(starts)) / 86400000);
    if (Date.parse(starts) < Date.now() - 60000 || days < 1 || days > 90)
      throw Error("Choose a future campaign lasting 1 to 90 days");
    if (
      !(await q(
        "SELECT id FROM products WHERE id=? AND store=? AND active=1",
        b.product,
        store.id,
      ).first())
    )
      throw Error("Choose your own product");
    const daily = b.placement === "market" ? 2000 : 1000;
    await q(
      "INSERT INTO campaigns(id,store,title,goal,budget,days,location,status,product,placement,starts,ends,created) VALUES(?,?,?,?,?,?,?,'draft',?,?,?,?,?)",
      crypto.randomUUID(),
      store.id,
      clean(b.title, 150),
      clean(b.goal, 60),
      daily,
      days,
      clean(b.location, 100),
      b.product,
      b.placement,
      starts,
      ends,
      now,
    ).run();
    return { ok: true };
  }
  if (a === "campaign-payment") {
    if (!store || store.suspended) throw Error("Active store required");
    const c: any = await q(
      "SELECT * FROM campaigns WHERE id=? AND store=? AND status='approved_draft' AND payment_status='unpaid'",
      b.id,
      store.id,
    ).first();
    if (!c) throw Error("Campaign must be approved before payment");
    if (Date.parse(c.ends) < Date.now())
      throw Error("Campaign dates have passed");
    return {
      ok: true,
      paymentLink: await initiatePayment(
        {
          id: "campaign_" + c.id,
          buyer: uid,
          name: store.name,
          phone: store.phone,
          total: c.budget * c.days,
        },
        u.email,
      ),
    };
  }
  if (a === "retry-payment") {
    const o: any = await q(
      "SELECT * FROM orders WHERE id=? AND buyer=? AND payment='flutterwave' AND payment_status='pending' AND status!='cancelled'",
      b.id,
      uid,
    ).first();
    if (!o) throw Error("No payable order found");
    return { ok: true, paymentLink: await initiatePayment(o, u.email) };
  }
  if (a === "refund-request") {
    const o: any = await q(
      "SELECT o.*,p.id AS pid FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.id=? AND o.buyer=? AND p.status='paid'",
      b.id,
      uid,
    ).first();
    if (!o || clean(b.reason).length < 10)
      throw Error("Provide a reason for your own paid order");
    await q(
      "INSERT INTO refunds(id,payment,order_id,amount,reason,status,created,updated) VALUES(?,?,?,?,?,'requested',?,?) ON CONFLICT(order_id) DO NOTHING",
      crypto.randomUUID(),
      o.pid,
      o.id,
      o.total,
      clean(b.reason, 1500),
      now,
      now,
    ).run();
    const refund:any=await q("SELECT id FROM refunds WHERE order_id=?",o.id).first();
    if(refund)await safelyEmail(()=>refundEmail(refund.id));
    return { ok: true };
  }
  if (
    [
      "delivery-settings",
      "schedule",
      "preview-session",
      "tiktok",
      "moderate-chat",
      "tracking",
    ].includes(a)
  ) {
    if (!store || store.suspended)
      throw Error("An active seller account is required");
    if (a === "delivery-settings") {
      if (!states.includes(b.state) || !clean(b.area))
        throw Error("Choose your business state and city or area");
      let coverage = Array.isArray(b.coverage)
        ? b.coverage
        : clean(b.coverage)
            .split(",")
            .map((x: string) => x.trim())
            .filter(Boolean);
      if (coverage.some((x: any) => !states.includes(x)))
        throw Error("Use Nigerian state names for delivery coverage");
      coverage = [...new Set(coverage)];
      if (!coverage.length)
        throw Error(
          "Select at least one confirmed delivery state. Delivery checkout remains unavailable until coverage and a fee are saved.",
        );
      const lat =
          b.latitude === "" || b.latitude == null ? null : Number(b.latitude),
        lng =
          b.longitude === "" || b.longitude == null
            ? null
            : Number(b.longitude);
      if (
        (lat === null) !== (lng === null) ||
        (lat !== null &&
          (!Number.isFinite(lat) ||
            lat < -90 ||
            lat > 90 ||
            !Number.isFinite(lng) ||
            lng! < -180 ||
            lng! > 180))
      )
        throw Error("Provide valid business latitude and longitude together");
      await q(
        "UPDATE stores SET state=?,area=?,location=?,coverage=?,delivery_fee=?,shipping_fee=?,delivery_days=?,return_policy=?,latitude=?,longitude=? WHERE owner=?",
        b.state,
        clean(b.area, 100),
        clean(b.area, 100) + ", " + b.state,
        JSON.stringify(coverage),
        integer(b.delivery_fee),
        integer(b.delivery_fee),
        clean(b.delivery_days, 200),
        clean(b.return_policy, 2000),
        lat,
        lng,
        uid,
      ).run();
    }
    if (a === "schedule" || a === "preview-session" || a === "tiktok") {
      await requireSellerActive(store.id);
      if (!clean(b.title)) throw Error("Add a session title");
      let url = "";
      const date = a === "preview-session" ? "" : clean(b.scheduled);
      if (
        a === "schedule" &&
        (!Number.isFinite(Date.parse(date)) || Date.parse(date) < Date.now())
      )
        throw Error("Select a future date");
      if (a === "tiktok") {
        const link = new URL(b.url);
        if (
          link.protocol !== "https:" ||
          !(
            link.hostname === "tiktok.com" ||
            link.hostname.endsWith(".tiktok.com")
          )
        )
          throw Error("Use an HTTPS TikTok link");
        url = link.href;
      }
      if (
        b.product &&
        !(await q(
          "SELECT id FROM products WHERE id=? AND store=? AND active=1",
          b.product,
          store.id,
        ).first())
      )
        throw Error("Choose your own product");
      const featured = [
        ...new Set(
          (Array.isArray(b.featured) ? b.featured : [b.product]).filter(
            Boolean,
          ),
        ),
      ].slice(0, 30);
      for (const product of featured) {
        if (
          !(await q(
            "SELECT id FROM products WHERE id=? AND store=? AND active=1",
            product,
            store.id,
          ).first())
        )
          throw Error("Choose your own active products");
      }
      const streamId = crypto.randomUUID();
      await q(
        "INSERT INTO streams(id,store,title,url,product,status,scheduled,provider,created,featured) VALUES(?,?,?,?,?,?,?,?,?,?)",
        streamId,
        store.id,
        clean(b.title, 150),
        url,
        clean(b.product, 100),
        a === "tiktok" ? "external" : "scheduled",
        date,
        a === "tiktok" ? "tiktok" : "native",
        now,
        JSON.stringify(featured),
      ).run();
      return { ok: true, streamId };
    }
    if (a === "moderate-chat") {
      if (b.block)
        await q(
          "INSERT OR IGNORE INTO live_blocks(stream,user) SELECT stream,user FROM chats WHERE id=? AND stream IN (SELECT id FROM streams WHERE store=?)",
          clean(b.id),
          store.id,
        ).run();
      await q(
        "UPDATE chats SET hidden=1 WHERE id=? AND stream IN (SELECT id FROM streams WHERE store=?)",
        clean(b.id),
        store.id,
      ).run();
    }
    if (a === "tracking") {
      await q(
        "UPDATE orders SET tracking=? WHERE id=? AND store=?",
        clean(b.tracking, 1000),
        b.id,
        store.id,
      ).run();
    }
    return { ok: true };
  }
  return null;
}
