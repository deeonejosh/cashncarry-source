import * as XLSX from "xlsx";
import { BULK_PRODUCT_HEADERS, BULK_PRODUCT_MAX_FILE_BYTES, BULK_PRODUCT_MAX_ROWS } from "./bulk-product-utils.mjs";

export function createBulkProductTemplate() {
  const workbook = XLSX.utils.book_new();
  const products = XLSX.utils.aoa_to_sheet([BULK_PRODUCT_HEADERS]);
  products["!cols"] = [
    { wch: 30 }, { wch: 52 }, { wch: 20 }, { wch: 18 }, { wch: 20 },
    { wch: 18 }, { wch: 42 }, { wch: 55 }, { wch: 18 },
  ];
  products["!autofilter"] = { ref: "A1:I1" };
  XLSX.utils.book_append_sheet(workbook, products, "Products");
  const guide = XLSX.utils.aoa_to_sheet([
    ["CASH N CARRY · BULK PRODUCT UPLOAD"],
    ["Use the Products sheet and keep its header row unchanged. The Instructions sheet can stay in the workbook."],
    ["Required fields", "Product Name, Description, Category, Price (NGN) and Stock Quantity"],
    ["Category", "Use an active Cash N Carry category. Electronics is accepted as an alias for Tech."],
    ["Price", "Whole Nigerian naira amount. Minimum ₦100, matching the existing product form."],
    ["SKU", "Optional seller stock code. If supplied, it must be unique in your store."],
    ["Stock Quantity", "Whole number from 0 to 100,000."],
    ["Main Image URL", "Optional. Leave blank to import without a photo, or upload a photo from your device in the product preview or after importing."],
    ["Additional Image URLs", "Optional; add up to 7 public HTTPS URLs or your Cash N Carry uploads separated by |. Leave blank if not needed."],
    ["Product Status", "Optional: Draft or Publish. Blank values default to Draft. Publishing still requires active seller eligibility."],
    ["Unsupported fields", "Sale price, condition, brand, colour, size, weight and per-product shipping are not part of the current product form and are not in this template."],
    ["Import limit", `Up to ${BULK_PRODUCT_MAX_ROWS} product rows per import; .xlsx up to ${Math.round(BULK_PRODUCT_MAX_FILE_BYTES / 1024 / 1024)} MB.`],
    ["Example only — do not import this row"],
    ["Sample item", "Describe the product clearly", "Fashion", 2500, "SAMPLE-001", 10, "", "", "Draft"],
  ]);
  guide["!cols"] = [{ wch: 28 }, { wch: 100 }, { wch: 20 }, { wch: 18 }, { wch: 20 }, { wch: 18 }, { wch: 42 }, { wch: 30 }, { wch: 18 }];
  XLSX.utils.book_append_sheet(workbook, guide, "Instructions");
  return XLSX.write(workbook, { type: "array", bookType: "xlsx", compression: true });
}
