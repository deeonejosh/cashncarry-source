export const sellerMoney=(n:number)=>new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN"}).format((n||0)/100);
