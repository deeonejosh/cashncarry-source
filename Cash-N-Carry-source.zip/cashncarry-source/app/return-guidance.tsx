import type { ReactNode } from "react";

/** Keep seller-specific terms visible while directing buyers to the platform's published return process. */
export default function ReturnGuidance({ sellerTerms }: { sellerTerms?: string | null }): ReactNode {
  return (
    <div className="product-return-guidance">
      {sellerTerms ? <p>Seller-provided return details: {sellerTerms}</p> : <p>Seller-specific return details are not available.</p>}
      <p>
        For return steps and eligibility, read the <a href="/refunds">Returns and Refunds Policy</a>.
        Please wait for return instructions before sending an item back.
      </p>
    </div>
  );
}
