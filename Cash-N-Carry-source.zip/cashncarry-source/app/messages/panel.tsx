"use client";
import VerifiedSellerBadge from "../verified-seller-badge";
import {useCallback,useEffect,useState,useRef} from "react";
import {messageFileType} from "../message-file-type";
import Link from "next/link";
import {ArrowLeft,MessageCircle,Paperclip,Send,X,FileText,RefreshCw,Store} from "lucide-react";
type Message={id:string;sender:string;body:string;created:string;sender_name?:string;file_name?:string;file_type?:string;file_size?:number};
type Thread={counterpart?:string;store:string;buyer:string;name:string;updated:string};
type ChatData={verified?:number;messages?:Message[];conversations?:Thread[];user?:string;name?:string;buyer?:string;selectBuyer?:boolean;isSeller?:boolean;buyerName?:string;peerName?:string};
const size=(n:number)=>n<1024*1024?`${Math.ceil(n/1024)} KB`:`${(n/1024/1024).toFixed(1)} MB`;
export default function Messages({store,buyer}:{store:string;buyer:string}){
 const [data,setData]=useState<ChatData>({});
 const [body,setBody]=useState(""),[file,setFile]=useState<File|null>(null),[error,setError]=useState(""),[sendError,setSendError]=useState(""),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[sent,setSent]=useState("");
 const keepAtBottom=useRef(true);
 const lock=useRef(false),pendingId=useRef<string|null>(null),fileInput=useRef<HTMLInputElement>(null),log=useRef<HTMLDivElement>(null);
 const query=new URLSearchParams();if(store)query.set("store",store);if(buyer)query.set("buyer",buyer);
 const url="/api/messages?"+query.toString();
 const load=useCallback(async(signal?:AbortSignal)=>{
  const r=await fetch(url,{signal:signal||AbortSignal.timeout(15000)});const next=await r.json() as ChatData & {error?:string};if(!r.ok)throw Error(next.error||"Unable to load conversation");return next as ChatData;
 },[url]);
 useEffect(()=>{
  let alive=true;const controller=new AbortController();keepAtBottom.current=true;setLoading(true);setData({});setError("");setSendError("");setBody("");setFile(null);pendingId.current=null;
  async function refresh(){try{const next=await load(AbortSignal.any([controller.signal,AbortSignal.timeout(15000)]));if(alive){setData(next);setError("");}}catch(e){if(alive)setError(e instanceof Error?e.message:"Unable to load messages");}finally{if(alive)setLoading(false);}}
  void refresh();const timer=setInterval(()=>{if(!document.hidden&&!lock.current)void refresh();},5000);
  return()=>{alive=false;controller.abort();clearInterval(timer);};
 },[load]);
 const [preview,setPreview]=useState('');
 const [conversationSearch,setConversationSearch]=useState('');
 useEffect(()=>{if(!file||!file.type.startsWith('image/')){setPreview('');return;}const url=URL.createObjectURL(file);setPreview(url);return()=>URL.revokeObjectURL(url);},[file]);
 const last=data.messages?.at(-1)?.id;
 useEffect(()=>{const el=log.current;if(el&&keepAtBottom.current)el.scrollTop=el.scrollHeight;},[last]);
 function chooseFile(selected:File|null){
  setSendError("");if(!selected)return;
  if(!messageFileType(selected)||selected.size===0||selected.size>10*1024*1024){setSendError("Choose a JPG, PNG, WebP, PDF or TXT file up to 10 MB.");if(fileInput.current)fileInput.current.value="";return;}
  setFile(new File([selected],selected.name,{type:messageFileType(selected)}));setSent("File selected — press Send to upload");pendingId.current=null;
 }
 async function retry(){setLoading(true);try{setData(await load());setError("");}catch(e){setError(e instanceof Error?e.message:"Unable to load messages");}finally{setLoading(false);}}
 async function send(e:React.FormEvent){
  e.preventDefault();if(lock.current||(!body.trim()&&!file))return;
  if(!data.buyer){setSendError("Open a buyer conversation from your inbox before sending.");return;}
  lock.current=true;setBusy(true);setSendError("");setSent("");pendingId.current||=crypto.randomUUID();
  try{
   const form=new FormData();form.set("store",store);form.set("buyer",data.buyer);form.set("body",body);form.set("id",pendingId.current);if(file)form.set("file",file);
   const r=await fetch("/api/messages",{method:"POST",body:form,signal:AbortSignal.timeout(30000)});const result=await r.json() as {id:string;error?:string;attachmentSaved?:boolean};if(!r.ok)throw Error(result.error||"Unable to send message");if(file&&!result.attachmentSaved)throw Error("The attachment was not saved. Keep your file selected and retry.");
   const message:Message={id:result.id,sender:data.user||"",body:body.trim(),created:new Date().toISOString(),...(file?{file_name:file.name,file_type:file.type,file_size:file.size}:{})};
   keepAtBottom.current=true;setData(current=>({...current,messages:current.messages?.some(m=>m.id===message.id)?current.messages:[...(current.messages||[]),message]}));
   setBody("");setFile(null);if(fileInput.current)fileInput.current.value="";pendingId.current=null;setSent(file?"File sent successfully":"Message sent");
   try{setData(await load());setError("");}catch{setError("Message sent. Conversation refresh is temporarily unavailable.");}
  }catch(e){setSendError(e instanceof Error?e.message:"Unable to send message. Your draft is saved here; retry.");}
  finally{lock.current=false;setBusy(false);}
 }
 const conversation=Boolean(store&&!data.selectBuyer);
 return <section className="seller-chat chat-workspace" aria-label="Buyer and seller chat">
  <header className="chat-header">
   <a className="chat-back" href="/messages" aria-label="All conversations"><ArrowLeft size={20}/></a>
   <span className="chat-avatar"><MessageCircle size={24}/></span>
   <div><h2>{data.peerName||data.name||"Messages"}{!data.isSeller&&!data.selectBuyer&&<VerifiedSellerBadge verified={data.verified}/>}</h2><p>{data.selectBuyer?"Your seller inbox":data.isSeller?"Private buyer conversation":"Private buyer & seller chat"}</p></div>
   {store&&<a className="chat-store" href={"/store/"+encodeURIComponent(store)}><Store size={18}/><span>Storefront</span></a>}
  </header>
  {error&&<div className="chat-feedback" role="alert"><span>{error}</span><button type="button" onClick={retry} disabled={loading}><RefreshCw size={16}/>Retry</button></div>}
  {loading&&<p className="chat-loading" role="status">Loading conversation…</p>}
  {(busy||sent)&&<p className="chat-delivery-status" role="status">{busy?(file?"Uploading file… Please keep this page open.":"Sending message…"):sent}</p>}
  {conversation?<>
   <div className="seller-chat-log" onScroll={e=>{const el=e.currentTarget;keepAtBottom.current=el.scrollHeight-el.scrollTop-el.clientHeight<80;}} ref={log} role="log" aria-label="Conversation" aria-live="polite" aria-relevant="additions">
    {!loading&&!error&&!data.messages?.length&&<div className="chat-empty"><MessageCircle size={38}/><h3>Start a conversation</h3><p>Ask about products, delivery or an order. Attach a photo or document if it helps.</p></div>}
    {data.messages?.map(m=><article className={m.sender===data.user?"chat-own":"chat-other"} key={m.id}>
     <strong>{m.sender_name||(m.sender===data.user?"You":data.peerName||data.name||"Seller")}</strong>
     {m.body&&<p>{m.body}</p>}
     {m.file_name&&<a className="chat-file" href={"/api/messages/attachment/"+encodeURIComponent(m.id)+"?download=1"}>
      {m.file_type?.startsWith("image/")?<img src={"/api/messages/attachment/"+encodeURIComponent(m.id)} alt={m.file_name} loading="lazy"/>:<FileText size={28}/>}
      <span>{m.file_name}<small>{size(m.file_size||0)} · Download</small></span>
     </a>}
     <time dateTime={m.created}>{new Date(m.created).toLocaleString(undefined,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}</time>
    </article>)}
   </div>
   <form className="chat-composer" onSubmit={send}>
    {file&&<div className="chat-selected-file">{preview?<img className="chat-draft-image" src={preview} alt="Selected attachment preview"/>:<FileText size={20}/>}<span>{file.name}<small>{size(file.size)}</small></span><button type="button" disabled={busy} aria-label="Remove attachment" onClick={()=>{setFile(null);pendingId.current=null;if(fileInput.current)fileInput.current.value="";}}><X size={18}/></button></div>}
    {sendError&&<p className="chat-send-error" role="alert">{sendError}</p>}
    <label className="chat-input-label" htmlFor="seller-message">Message</label>
    <div className="chat-composer-row">
     <input className="chat-file-input" id="chat-attachment" ref={fileInput} type="file" accept="image/jpeg,image/png,image/webp,application/pdf,text/plain,.jpg,.jpeg,.png,.webp,.pdf,.txt" disabled={busy||loading||!data.buyer} onChange={e=>chooseFile(e.target.files?.[0]||null)}/>
     <button type="button" className="chat-attach" aria-label="Attach a picture or document" disabled={busy||loading||!data.buyer} onClick={()=>fileInput.current?.click()}><Paperclip size={23}/></button>
     <textarea id="seller-message" placeholder="Write a message…" value={body} onChange={e=>{setBody(e.target.value);pendingId.current=null;setSent("");}} maxLength={2000} rows={2} disabled={busy} aria-describedby="chat-file-help"/>
     <button type="submit" className="primary chat-send" disabled={busy||loading||(!body.trim()&&!file)||!data.buyer}><Send size={20}/><span>{busy?"Sending…":"Send"}</span></button>
    </div>
    <div className="chat-composer-help"><small id="chat-file-help">JPG, PNG, WebP, PDF or TXT · Up to 10 MB</small><small role="status">{sent||`${body.length}/2000`}</small></div>
   </form>
  </>:<div className="chat-inbox">
   <label className="conversation-search">Search conversations<input type="search" value={conversationSearch} onChange={e=>setConversationSearch(e.target.value)} placeholder="Search by seller or buyer name"/></label>
   {data.selectBuyer&&<div className="chat-owner-notice"><h3>This is your store</h3><p>You are signed in as the owner of {data.name}. This inbox receives messages from buyers. Select an existing buyer conversation to reply.</p><p>To test contacting this store, open a private browser window and sign in with a different buyer account, then visit the storefront and choose Chat with seller.</p><Link href="/?browse=1#market">Browse products and other sellers</Link></div>}
   {!loading&&!error&&!data.conversations?.length&&<div className="chat-empty"><MessageCircle size={38}/><h3>No conversations yet</h3><p>{data.selectBuyer?"Buyer messages will appear here when someone contacts your store.":"Visit a seller’s storefront and select Chat with seller."}</p></div>}
   {conversationSearch && data.conversations?.length && !data.conversations.some(t => `${t.counterpart || ""} ${t.name}`.toLowerCase().includes(conversationSearch.trim().toLowerCase())) ? <p role="status">No matching conversations. Try another name.</p> : null}
   {data.conversations?.filter(t => `${t.counterpart || ""} ${t.name}`.toLowerCase().includes(conversationSearch.trim().toLowerCase())).map(t=><a className="conversation-card" key={t.store+t.buyer} href={"/messages?"+new URLSearchParams({store:t.store,buyer:t.buyer})}><span className="chat-avatar"><MessageCircle size={22}/></span><div><strong>{t.counterpart||t.name}</strong><span>{data.selectBuyer?t.name:"Open conversation"} · {new Date(t.updated).toLocaleString()}</span></div><span aria-hidden="true">›</span></a>)}
  </div>}
 </section>;
}
