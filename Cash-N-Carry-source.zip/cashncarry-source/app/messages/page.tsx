import { requireChatGPTUser } from "../chatgpt-auth";
import Messages from "./panel";
import { CustomerHeader, CustomerNavigation } from "../customer-shell";
export const dynamic="force-dynamic";
export default async function Page({searchParams}:{searchParams:Promise<{store?:string;buyer?:string}>}){
 const p=await searchParams;
 const query=new URLSearchParams();if(p.store)query.set("store",p.store);if(p.buyer)query.set("buyer",p.buyer);
 await requireChatGPTUser("/messages"+(query.size?"?"+query.toString():""));
 return <><CustomerHeader active="Account"/><main id="main-content" className="customer-page"><h1>Buyer & seller messages</h1><p>Contact sellers here without sharing email addresses or phone numbers.</p><Messages store={p.store||""} buyer={p.buyer||""}/></main><CustomerNavigation active="Account"/></>;
}
