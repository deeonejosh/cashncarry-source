import { ANALYTICS_CONSENT_KEY } from "./analytics-consent-key";

export const VIDEO_VISITOR_KEY = "cnc-video-visitor";

export function videoEventPayload(
  video: string,
  kind: string,
  storage: Pick<Storage, "getItem" | "setItem">,
  createId: () => string = () => crypto.randomUUID().replaceAll("-", ""),
) {
  if (storage.getItem(ANALYTICS_CONSENT_KEY) !== "accepted") return null;

  let visitor = storage.getItem(VIDEO_VISITOR_KEY);
  if (!visitor) {
    visitor = createId();
    storage.setItem(VIDEO_VISITOR_KEY, visitor);
  }
  return { action: "event", video, kind, visitor };
}
