import VerifiedSellerBadge from "../../verified-seller-badge";
import { eligibleSellerSQL } from "../../seller-activation";
import { CustomerHeader, CustomerNavigation } from "../../customer-shell";
import ProductGallery from "../../product-gallery";
import { getChatGPTUser } from "../../chatgpt-auth";
import ProductPurchase from "../../product-purchase";
import { brand } from "../../brand";
import { env } from "cloudflare:workers";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ensureCompetitiveSchema } from "../../competitive-schema";
import AnalyticsTracker from "../../analytics-tracker";
import { absoluteProductImage, productSeoDescription } from "../../product-seo";
import { ensureVideoStorefrontSchema } from "../../video-storefront-schema";
import ReturnGuidance from "../../return-guidance";
type ProductDetails = {
  id: string;
  store: string;
  name: string;
  description: string;
  category: string;
  price: number;
  stock: number;
  image: string;
  images: string | null;
  video: string;
  variants: string | null;
  seller: string;
  verified: number;
  delivery_fee: number | null;
  delivery_days: string | null;
  return_policy: string | null;
  coverage: string | null;
  seller_location: string | null;
  location: string;
  bundle?: { title: string; price: number; items: { name_snapshot: string; price_snapshot: number; quantity: number }[] } | null;
};
async function product(id: string) {
  await ensureCompetitiveSchema();
  const result = await env.DB?.prepare(
    "SELECT p.*,s.name AS seller,s.verified,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy,s.coverage,s.location AS seller_location FROM products p JOIN stores s ON s.id=p.store WHERE p.id=? AND p.active=1 AND s.suspended=0 AND " + eligibleSellerSQL() + " AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
  )
    .bind(id)
    .first<ProductDetails>();
  if(!result)return result;
  const bundle:any=await env.DB?.prepare("SELECT id,title,price FROM product_bundles WHERE product=? AND active=1").bind(result.id).first();
  if(bundle){const items:any=await env.DB?.prepare("SELECT name_snapshot,price_snapshot,quantity FROM product_bundle_items WHERE bundle=? ORDER BY name_snapshot").bind(bundle.id).all();result.bundle={title:bundle.title,price:Number(bundle.price),items:items.results||[]};}
  return result;
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const p = await product(id);
  const description = p
    ? productSeoDescription(p.name, p.description)
    : `Browse products from Nigerian sellers on ${brand.name}.`;
  const image = absoluteProductImage(p?.image, env.SITE_URL || "https://cashncarryng.com");
  return {
    title: p
      ? p.name + (" | " + brand.name)
      : "Product unavailable | " + brand.name,
    alternates: { canonical: "/product/" + id },
    description,
    openGraph: p
      ? {
          url: "/product/" + p.id,
          title: `${p.name} | ${brand.name}`,
          siteName: brand.name,
          description,
          ...(image ? { images: [{ url: image }] } : {}),
        }
      : undefined,
  };
}
function safeProductReturnTo(value?: string) {
  const fallback = "/?browse=1#market";
  if (!value || !value.startsWith("/") || value.startsWith("//") || value.includes("\\")) return fallback;
  try {
    const url = new URL(value, "https://cashncarryng.com");
    if (url.origin !== "https://cashncarryng.com") return fallback;
    const allowed = url.pathname === "/" || url.pathname === "/for-you" || url.pathname === "/live-auctions" || /^\/store\/[A-Za-z0-9_-]+$/.test(url.pathname);
    return allowed ? url.pathname + url.search + url.hash : fallback;
  } catch { return fallback; }
}
export default async function Product({
  params, searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ returnTo?: string }>;
}) {
  await ensureVideoStorefrontSchema();
  const p = await product((await params).id);
  if (!p) notFound();
  const user = await getChatGPTUser();
  const back = safeProductReturnTo((await searchParams).returnTo);
  const relatedVideos = (await env.DB!.prepare("SELECT v.id,v.media,v.thumbnail,v.caption,s.name AS seller,f.slug FROM video_products vp JOIN videos v ON v.id=vp.video JOIN stores s ON s.id=v.store LEFT JOIN storefronts f ON f.store=s.id WHERE vp.product=? AND v.status='approved' AND v.published=1 AND " + eligibleSellerSQL("s") + " ORDER BY v.created DESC LIMIT 6").bind(p.id).all<any>()).results;
  const saved = user
    ? Boolean(
        await env
          .DB!.prepare("SELECT id FROM favourites WHERE user=? AND product=?")
          .bind(user.userId, p.id)
          .first(),
      )
    : false;
  return (
    <>
      <AnalyticsTracker event="product_view" store={p.store} product={p.id}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({ "@context": "https://schema.org", "@type": "Product", name: p.name, description: p.description, ...(absoluteProductImage(p.image, env.SITE_URL || "https://cashncarryng.com") ? { image: absoluteProductImage(p.image, env.SITE_URL || "https://cashncarryng.com") } : {}), url: new URL("/product/" + p.id, env.SITE_URL || "https://cashncarryng.com").href, offers: { "@type": "Offer", price: p.price, priceCurrency: "NGN", availability: p.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock", seller: { "@type": "Organization", name: p.seller } } }).replace(/</g, "\\u003c") }} />
      <CustomerHeader active="Shop" back={back} />
      <main
        id="main-content"
        tabIndex={-1}
        className="customer-page public-product-page"
      >
        <div className="public-product-layout">
          <ProductGallery
            name={p.name}
            images={[
              ...new Set<string>([p.image, ...JSON.parse(p.images || "[]")]),
            ]}
            video={p.video}
          />
          <section className="public-product-information">
            <p className="eyebrow">{p.category}</p>
            <h1>{p.name}</h1>
            <a className="seller-link" href={"/store/" + p.store}>
              {p.seller}<VerifiedSellerBadge verified={p.verified}/>
            </a>
            <p>{p.description}</p>
            {p.bundle&&<section className="public-bundle-summary" aria-label="Bundle contents"><h2>Included in this bundle</h2><ul>{p.bundle.items.map((item,i)=><li key={`${item.name_snapshot}-${i}`}>{item.quantity} × {item.name_snapshot}<span>{"₦"+Number(item.price_snapshot*item.quantity).toLocaleString("en-NG")}</span></li>)}</ul><p>Individual total <strong>₦{p.bundle.items.reduce((sum,item)=>sum+item.price_snapshot*item.quantity,0).toLocaleString("en-NG")}</strong> · Bundle price <strong>₦{p.bundle.price.toLocaleString("en-NG")}</strong> · You save <strong>₦{Math.max(0,p.bundle.items.reduce((sum,item)=>sum+item.price_snapshot*item.quantity,0)-p.bundle.price).toLocaleString("en-NG")}</strong></p></section>}
            <ProductPurchase
              initiallySaved={saved}
              signedIn={Boolean(user)}
              product={{
                id: p.id,
                store: p.store,
                price: p.price,
                stock: p.stock,
                variants: p.variants,
              }}
            />
            <div className="delivery-summary">
              <h2>Delivery &amp; returns</h2>
              <p>Seller location: {p.seller_location || p.location}</p>
              <details className="product-coverage"><summary>Delivery coverage</summary><p>
                Delivers to:{" "}
                {JSON.parse(p.coverage || "[]").join(", ") ||
                  "Confirm coverage with seller"}
              </p></details>
              <p>
                Delivery: {p.delivery_fee === null || p.delivery_fee === undefined ? "Fee confirmed at checkout" : "₦" + p.delivery_fee.toLocaleString()} ·{" "}
                {p.delivery_days || "Confirm estimate with seller"}
              </p>
              <ReturnGuidance sellerTerms={p.return_policy} />
            </div>

          </section>
        </div>
        {relatedVideos.length > 0 && <section className="product-video-discovery"><div className="section-heading"><h2>See it in action</h2><a href={"/for-you?product=" + encodeURIComponent(p.id)}>More videos</a></div><div className="product-video-grid">{relatedVideos.map((v:any)=><article key={v.id}><video src={v.media} poster={v.thumbnail||undefined} controls playsInline preload="none" aria-label={v.caption||p.name+" video"}/><p>{v.caption}</p><a href={`/for-you?v=${encodeURIComponent(v.id)}`}>Open in For You · {v.seller}</a></article>)}</div></section>}
      </main>
      <CustomerNavigation active="Shop" />
    </>
  );
}
