import type { Metadata } from "next";
import { CustomerHeader, CustomerNavigation } from "../customer-shell";
import { VideoFeed } from "../video-feed";
import { brand } from "../brand";

export const metadata: Metadata = {
  title: "For You | Shop product videos | " + brand.name,
  description: "Watch seller product videos, discover new Nigerian businesses and shop tagged products through Cash N Carry.",
  alternates: { canonical: "/for-you" },
  openGraph: { title: "For You | " + brand.name, description: "Discover products through seller videos and shop directly." },
};
export default async function ForYou({ searchParams }: { searchParams: Promise<{ v?: string }> }) {
  const { v = "" } = await searchParams;
  return <><CustomerHeader active="For You" back="/?browse=1#home"/><main id="main-content" className="customer-page for-you-page"><header className="for-you-heading"><p className="eyebrow">WATCH · DISCOVER · SHOP</p><h1>For You</h1><p>Short product videos from sellers across Nigeria. Tap a product to see current price, stock and checkout options.</p></header><VideoFeed initialVideo={v.slice(0, 100)}/></main><CustomerNavigation active="Home"/></>;
}
