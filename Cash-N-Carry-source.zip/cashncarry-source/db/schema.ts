import { sql } from "drizzle-orm";
import {
  sqliteTable,
  text,
  integer,
  index,
  uniqueIndex,
  check,
  real,
  primaryKey,
} from "drizzle-orm/sqlite-core";
export const stores = sqliteTable(
  "stores",
  {
    id: text("id").primaryKey(),
    owner: text("owner").notNull(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    category: text("category").notNull(),
    location: text("location").notNull(),
    phone: text("phone").notNull().default(""),
    verified: integer("verified").notNull().default(0),
    suspended: integer("suspended").notNull().default(0),
    state: text("state").notNull().default(""),
    area: text("area").notNull().default(""),
    coverage: text("coverage").notNull().default("[]"),
    shippingFee: integer("shipping_fee").notNull().default(100),
    deliveryFee: integer("delivery_fee").notNull().default(0),
    deliveryDays: text("delivery_days")
      .notNull()
      .default("Confirm with seller"),
    returnPolicy: text("return_policy")
      .notNull()
      .default("Contact the seller before returning an item."),
    latitude: real("latitude"),
    longitude: real("longitude"),
    created: text("created").notNull(),
  },
  (t) => [uniqueIndex("stores_owner").on(t.owner)],
);
export const products = sqliteTable(
  "products",
  {
    id: text("id").primaryKey(),
    store: text("store")
      .notNull()
      .references(() => stores.id),
    name: text("name").notNull(),
    sku: text("sku").notNull().default(""),
    description: text("description").notNull(),
    category: text("category").notNull(),
    price: integer("price").notNull(),
    stock: integer("stock").notNull(),
    image: text("image").notNull(),
    video: text("video").notNull().default(""),
    active: integer("active").notNull().default(1),
    images: text("images").notNull().default("[]"),
    variants: text("variants").notNull().default("[]"),
    featured: integer("featured").notNull().default(0),
    videoStatus: text("video_status").notNull().default("ready"),
    created: text("created").notNull(),
  },
  (t) => [
    index("products_store").on(t.store),
    uniqueIndex("products_store_sku").on(t.store, sql`lower(${t.sku})`).where(sql`${t.sku} != ''`),
    index("products_catalog").on(t.active, t.created, t.id),
    check("products_stock_nonnegative", sql`${t.stock} >= 0`),
    check("products_price_positive", sql`${t.price} > 0`),
  ],
);
export const carts = sqliteTable(
  "carts",
  {
    id: text("id").primaryKey(),
    user: text("user").notNull(),
    product: text("product")
      .notNull()
      .references(() => products.id),
    quantity: integer("quantity").notNull(),
    variant: text("variant").notNull().default(""),
  },
  (t) => [uniqueIndex("carts_user_product").on(t.user, t.product)],
);
export const orders = sqliteTable(
  "orders",
  {
    id: text("id").primaryKey(),
    buyer: text("buyer").notNull(),
    store: text("store").notNull(),
    name: text("name").notNull(),
    phone: text("phone").notNull(),
    address: text("address").notNull(),
    total: integer("total").notNull(),
    status: text("status").notNull().default("placed"),
    payment: text("payment").notNull().default("cash_on_delivery"),
    paymentStatus: text("payment_status").notNull().default("cash_on_delivery"),
    deliveryFee: integer("delivery_fee").notNull().default(0),
    deliveryState: text("delivery_state").notNull().default(""),
    deliveredAt: text("delivered_at").notNull().default(""),
    sellerActivationRequired: integer("seller_activation_required").notNull().default(0),
    tracking: text("tracking").notNull().default(""),
    created: text("created").notNull(),
  },
  (t) => [index("orders_buyer").on(t.buyer), index("orders_store").on(t.store)],
);
export const items = sqliteTable(
  "order_items",
  {
    id: text("id").primaryKey(),
    order: text("order_id")
      .notNull()
      .references(() => orders.id),
    product: text("product").notNull(),
    name: text("name").notNull(),
    price: integer("price").notNull(),
    quantity: integer("quantity").notNull(),
    variant: text("variant").notNull().default(""),
  },
  (t) => [index("items_order").on(t.order)],
);
export const streams = sqliteTable(
  "streams",
  {
    id: text("id").primaryKey(),
    store: text("store")
      .notNull()
      .references(() => stores.id),
    title: text("title").notNull(),
    url: text("url").notNull(),
    product: text("product").notNull().default(""),
    status: text("status").notNull().default("live"),
    scheduled: text("scheduled").notNull().default(""),
    provider: text("provider").notNull().default("external"),
    featured: text("featured").notNull().default("[]"),
    providerId: text("provider_id").notNull().default(""),
    publishUrl: text("publish_url").notNull().default(""),
    replay: text("replay").notNull().default(""),
    heartbeat: text("heartbeat").notNull().default(""),
    created: text("created").notNull(),
  },
  (t) => [index("streams_store").on(t.store)],
);
export const chats = sqliteTable(
  "chats",
  {
    id: text("id").primaryKey(),
    stream: text("stream")
      .notNull()
      .references(() => streams.id),
    user: text("user").notNull(),
    name: text("name").notNull(),
    message: text("message").notNull(),
    hidden: integer("hidden").notNull().default(0),
    created: text("created").notNull(),
  },
  (t) => [index("chats_stream").on(t.stream, t.created)],
);
export const follows = sqliteTable(
  "follows",
  {
    id: text("id").primaryKey(),
    user: text("user").notNull(),
    store: text("store").notNull(),
  },
  (t) => [uniqueIndex("follows_user_store").on(t.user, t.store)],
);
export const reviews = sqliteTable(
  "reviews",
  {
    id: text("id").primaryKey(),
    buyer: text("buyer").notNull(),
    product: text("product").notNull(),
    order: text("order_id").notNull(),
    name: text("name").notNull(),
    rating: integer("rating").notNull(),
    comment: text("comment").notNull(),
    created: text("created").notNull(),
  },
  (t) => [
    uniqueIndex("reviews_buyer_product_order").on(t.buyer, t.product, t.order),
  ],
);
export const campaigns = sqliteTable("campaigns", {
  id: text("id").primaryKey(),
  store: text("store").notNull(),
  title: text("title").notNull(),
  goal: text("goal").notNull(),
  budget: integer("budget").notNull(),
  days: integer("days").notNull(),
  location: text("location").notNull(),
  status: text("status").notNull().default("draft"),
  product: text("product").notNull().default(""),
  placement: text("placement").notNull().default("discovery"),
  starts: text("starts").notNull().default(""),
  ends: text("ends").notNull().default(""),
  paymentStatus: text("payment_status").notNull().default("unpaid"),
  impressions: integer("impressions").notNull().default(0),
  clicks: integer("clicks").notNull().default(0),
  created: text("created").notNull(),
});

export const profiles = sqliteTable("profiles", {
  username: text("username").unique(),
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  suspended: integer("suspended").notNull().default(0),
  created: text("created").notNull(),
  lastSeen: text("last_seen").notNull(),
});
export const verification = sqliteTable(
  "verification_requests",
  {
    id: text("id").primaryKey(),
    store: text("store")
      .notNull()
      .references(() => stores.id),
    owner: text("owner").notNull(),
    legalName: text("legal_name").notNull(),
    sellerType: text("seller_type").notNull().default("individual"),
    contactEmail: text("contact_email").notNull().default(""),
    contactPhone: text("contact_phone").notNull().default(""),
    appeal: text("appeal").notNull().default(""),
    registration: text("registration").notNull().default(""),
    fileKey: text("file_key").notNull(),
    fileType: text("file_type").notNull(),
    status: text("status").notNull().default("pending"),
    note: text("note").notNull().default(""),
    created: text("created").notNull(),
    updated: text("updated").notNull(),
  },
  (t) => [
    uniqueIndex("verification_pending_store")
      .on(t.store)
      .where(sql`${t.status} = 'pending'`),
  ],
);
export const reports = sqliteTable(
  "reports",
  {
    id: text("id").primaryKey(),
    reporter: text("reporter").notNull(),
    targetType: text("target_type").notNull(),
    target: text("target").notNull(),
    reason: text("reason").notNull(),
    details: text("details").notNull(),
    status: text("status").notNull().default("open"),
    resolution: text("resolution").notNull().default(""),
    created: text("created").notNull(),
    updated: text("updated").notNull(),
  },
  (t) => [
    index("reports_reporter").on(t.reporter),
    index("reports_status").on(t.status),
  ],
);
export const audit = sqliteTable(
  "admin_audit",
  {
    id: text("id").primaryKey(),
    actor: text("actor").notNull(),
    email: text("email").notNull(),
    action: text("action").notNull(),
    target: text("target").notNull(),
    reason: text("reason").notNull(),
    before: text("before_json").notNull(),
    after: text("after_json").notNull(),
    created: text("created").notNull(),
  },
  (t) => [index("audit_created").on(t.created)],
);

export const authUser = sqliteTable("auth_user", {
  twoFactorEnabled: integer("two_factor_enabled", { mode: "boolean" }).notNull().default(false),
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: integer("email_verified", { mode: "boolean" })
    .notNull()
    .default(false),
  image: text("image"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
});
export const policyAcceptances = sqliteTable("policy_acceptances", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => authUser.id),
  policyId: text("policy_id").notNull(),
  version: integer("version").notNull(),
  acceptedAt: text("accepted_at").notNull(),
}, (t) => [uniqueIndex("policy_acceptances_user_policy_version").on(t.userId, t.policyId, t.version), index("policy_acceptances_policy_version").on(t.policyId, t.version, t.acceptedAt)]);
export const authSession = sqliteTable(
  "auth_session",
  {
    id: text("id").primaryKey(),
    expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
    token: text("token").notNull().unique(),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
    updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
    ipAddress: text("ip_address"),
    userAgent: text("user_agent"),
    userId: text("user_id")
      .notNull()
      .references(() => authUser.id),
  },
  (t) => [index("auth_session_user").on(t.userId)],
);
export const authAccount = sqliteTable(
  "auth_account",
  {
    id: text("id").primaryKey(),
    accountId: text("account_id").notNull(),
    providerId: text("provider_id").notNull(),
    userId: text("user_id")
      .notNull()
      .references(() => authUser.id),
    accessToken: text("access_token"),
    refreshToken: text("refresh_token"),
    idToken: text("id_token"),
    accessTokenExpiresAt: integer("access_token_expires_at", {
      mode: "timestamp_ms",
    }),
    refreshTokenExpiresAt: integer("refresh_token_expires_at", {
      mode: "timestamp_ms",
    }),
    scope: text("scope"),
    password: text("password"),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
    updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
  },
  (t) => [index("auth_account_user").on(t.userId)],
);
export const authVerification = sqliteTable(
  "auth_verification",
  {
    id: text("id").primaryKey(),
    identifier: text("identifier").notNull(),
    value: text("value").notNull(),
    expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
    updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
  },
  (t) => [index("auth_verification_identifier").on(t.identifier)],
);
export const addresses = sqliteTable(
  "addresses",
  {
    id: text("id").primaryKey(),
    user: text("user").notNull(),
    name: text("name").notNull(),
    phone: text("phone").notNull(),
    line: text("line").notNull(),
    state: text("state").notNull(),
    area: text("area").notNull(),
    created: text("created").notNull(),
  },
  (t) => [index("addresses_user").on(t.user)],
);
export const favourites = sqliteTable(
  "favourites",
  {
    id: text("id").primaryKey(),
    user: text("user").notNull(),
    product: text("product").notNull(),
  },
  (t) => [uniqueIndex("favourites_user_product").on(t.user, t.product)],
);
export const preferences = sqliteTable("preferences", {
  user: text("user").primaryKey(),
  orderUpdates: integer("order_updates").notNull().default(1),
  liveAlerts: integer("live_alerts").notNull().default(1),
  marketing: integer("marketing").notNull().default(0),
});
export const notifications = sqliteTable(
  "notifications",
  {
    id: text("id").primaryKey(),
    user: text("user").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    read: integer("read").notNull().default(0),
    created: text("created").notNull(),
  },
  (t) => [index("notifications_user").on(t.user, t.created)],
);
export const payments = sqliteTable("payments", {
  id: text("id").primaryKey(),
  order: text("order_id").notNull().unique(),
  buyer: text("buyer").notNull(),
  amount: integer("amount").notNull(),
  currency: text("currency").notNull().default("NGN"),
  mode: text("mode").notNull().default("test"),
  status: text("status").notNull().default("pending"),
  providerId: text("provider_id").notNull().default(""),
  link: text("link").notNull().default(""),
  expires: text("expires").notNull(),
  created: text("created").notNull(),
  updated: text("updated").notNull(),
});
export const paymentEvents = sqliteTable("payment_events", {
  id: text("id").primaryKey(),
  payment: text("payment").notNull(),
  type: text("type").notNull(),
  created: text("created").notNull(),
});
export const refunds = sqliteTable("refunds", {
  id: text("id").primaryKey(),
  payment: text("payment").notNull(),
  order: text("order_id").notNull().unique(),
  amount: integer("amount").notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("requested"),
  providerId: text("provider_id").notNull().default(""),
  created: text("created").notNull(),
  updated: text("updated").notNull(),
});
export const rateLimits = sqliteTable("rate_limits", {
  key: text("key").primaryKey(),
  count: integer("count").notNull(),
  expires: integer("expires").notNull(),
});
export const platformSettings = sqliteTable("platform_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updated: text("updated").notNull(),
});
export const categories = sqliteTable("categories", {
  id: text("id").primaryKey(),
  name: text("name").notNull().unique(),
  active: integer("active").notNull().default(1),
});
export const policies = sqliteTable("policies", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  reviewed: integer("reviewed").notNull().default(0),
  updated: text("updated").notNull(),
});
export const policyVersions = sqliteTable("policy_versions", {
  id: text("id").primaryKey(),
  policyId: text("policy_id").notNull(),
  version: integer("version").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  status: text("status").notNull().default("draft"),
  createdBy: text("created_by").notNull(),
  createdByEmail: text("created_by_email").notNull(),
  createdAt: text("created_at").notNull(),
  submittedAt: text("submitted_at"),
  approvedBy: text("approved_by"),
  approvedByEmail: text("approved_by_email"),
  approvedAt: text("approved_at"),
  publishedBy: text("published_by"),
  publishedByEmail: text("published_by_email"),
  publishedAt: text("published_at"),
  effectiveDate: text("effective_date"),
  reason: text("reason").notNull(),
}, (t) => [uniqueIndex("policy_versions_policy_version").on(t.policyId, t.version), index("policy_versions_status").on(t.policyId, t.status, t.version), check("policy_versions_status_check", sql`${t.status} IN ('draft','pending_review','approved','published')`)]);
export const uploadUsage = sqliteTable(
  "upload_usage",
  {
    user: text("user").notNull(),
    day: text("day").notNull(),
    bytes: integer("bytes").notNull().default(0),
    count: integer("count").notNull().default(0),
    imageCount: integer("image_count").notNull().default(0),
    imageBytes: integer("image_bytes").notNull().default(0),
    imageReservedCount: integer("image_reserved_count").notNull().default(0),
    imageReservedBytes: integer("image_reserved_bytes").notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.user, t.day] })],
);

export const mediaUploadRequests = sqliteTable("media_upload_requests", {
  id: text("id").primaryKey(),
  user: text("user").notNull(),
  day: text("day").notNull(),
  bytes: integer("bytes").notNull(),
  contentHash: text("content_hash").notNull().default(""),
  mediaKey: text("media_key").notNull().unique(),
  status: text("status").notNull(),
  created: text("created").notNull(),
  updated: text("updated").notNull(),
}, (t) => [index("media_upload_requests_cleanup").on(t.status, t.created), uniqueIndex("media_upload_requests_owner_hash").on(t.user, t.contentHash).where(sql`${t.contentHash} != '' AND ${t.status} = 'completed'`), check("media_upload_requests_status_check", sql`${t.status} IN ('reserved','completed','failed','stale','rejected')`)]);

export const outbox = sqliteTable(
  "email_outbox",
  {
    id: text("id").primaryKey(),
    first_attempt: text("first_attempt"),
    lease_token: text("lease_token"),
    retry_at: text("retry_at"),
    providerId: text("provider_id"),
    deliveryStatus: text("delivery_status").notNull().default("unknown"),
    lastError: text("last_error").notNull().default(""),
    template: text("template").notNull().default("notification"),
    recipient: text("recipient").notNull(),
    subject: text("subject").notNull(),
    body: text("body").notNull(),
    status: text("status").notNull().default("pending"),
    attempts: integer("attempts").notNull().default(0),
    created: text("created").notNull(),
    updated: text("updated").notNull(),
  },
  (t) => [index("email_outbox_delivery").on(t.status, t.retry_at, t.updated)],
);

export const campaignEvents = sqliteTable(
  "campaign_events",
  {
    id: text("id").primaryKey(),
    campaign: text("campaign").notNull(),
    visitor: text("visitor").notNull(),
    kind: text("kind").notNull(),
    day: text("day").notNull(),
    created: text("created").notNull(),
  },
  (t) => [
    uniqueIndex("campaign_event_once").on(t.campaign, t.visitor, t.kind, t.day),
  ],
);

export const mediaBlocks = sqliteTable("media_blocks", {
  key: text("key").primaryKey(),
  created: text("created").notNull(),
});

export const storefronts = sqliteTable(
  "storefronts",
  {
    store: text("store").primaryKey().references(() => stores.id),
    slug: text("slug").notNull(),
    displayName: text("display_name").notNull().default(""),
    description: text("description").notNull().default(""),
    category: text("category").notNull().default(""),
    logo: text("logo").notNull().default(""),
    banner: text("banner").notNull().default(""),
    template: text("template").notNull().default("market"),
    accent: text("accent").notNull().default("#164B35"),
    featuredProducts: text("featured_products").notNull().default("[]"),
    published: integer("published").notNull().default(0),
    updated: text("updated").notNull(),
  },
  (t) => [uniqueIndex("storefronts_slug").on(t.slug)],
);

export const videos = sqliteTable(
  "videos",
  {
    id: text("id").primaryKey(),
    store: text("store").notNull().references(() => stores.id),
    owner: text("owner").notNull(),
    media: text("media").notNull(),
    thumbnail: text("thumbnail").notNull().default(""),
    caption: text("caption").notNull().default(""),
    hashtags: text("hashtags").notNull().default("[]"),
    status: text("status").notNull().default("draft"),
    published: integer("published").notNull().default(0),
    created: text("created").notNull(),
    updated: text("updated").notNull(),
    moderationNote: text("moderation_note").notNull().default(""),
  },
  (t) => [index("videos_feed").on(t.status, t.published, t.created), index("videos_store").on(t.store, t.created)],
);

export const videoProducts = sqliteTable(
  "video_products",
  {
    video: text("video").notNull().references(() => videos.id, { onDelete: "cascade" }),
    product: text("product").notNull().references(() => products.id),
  },
  (t) => [primaryKey({ columns: [t.video, t.product] }), index("video_products_product").on(t.product)],
);
export const videoLikes = sqliteTable("video_likes", {
  video: text("video").notNull().references(() => videos.id, { onDelete: "cascade" }),
  user: text("user").notNull(),
  created: text("created").notNull(),
}, (t) => [primaryKey({ columns: [t.video, t.user] })]);
export const videoSaves = sqliteTable("video_saves", {
  video: text("video").notNull().references(() => videos.id, { onDelete: "cascade" }),
  user: text("user").notNull(),
  created: text("created").notNull(),
}, (t) => [primaryKey({ columns: [t.video, t.user] })]);
export const videoComments = sqliteTable("video_comments", {
  id: text("id").primaryKey(),
  video: text("video").notNull().references(() => videos.id, { onDelete: "cascade" }),
  user: text("user").notNull(),
  parent: text("parent").notNull().default(""),
  body: text("body").notNull(),
  hidden: integer("hidden").notNull().default(0),
  created: text("created").notNull(),
}, (t) => [index("video_comments_visible").on(t.video, t.hidden, t.created)]);
export const videoEvents = sqliteTable("video_events", {
  id: text("id").primaryKey(),
  video: text("video").notNull().references(() => videos.id, { onDelete: "cascade" }),
  visitor: text("visitor").notNull(),
  kind: text("kind").notNull(),
  day: text("day").notNull(),
  created: text("created").notNull(),
}, (t) => [uniqueIndex("video_events_once").on(t.video, t.visitor, t.kind, t.day), index("video_events_video").on(t.video, t.kind, t.created)]);
export const videoModerationHistory = sqliteTable("video_moderation_history", {
  id: text("id").primaryKey(),
  video: text("video").notNull().references(() => videos.id),
  actor: text("actor").notNull(),
  status: text("status").notNull(),
  note: text("note").notNull(),
  created: text("created").notNull(),
});

export const liveViewers = sqliteTable(
  "live_viewers",
  {
    stream: text("stream")
      .notNull()
      .references(() => streams.id),
    session: text("session").notNull(),
    seen: text("seen").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.stream, t.session] }),
    index("live_viewers_seen").on(t.seen),
  ],
);
export const liveBlocks = sqliteTable(
  "live_blocks",
  {
    stream: text("stream")
      .notNull()
      .references(() => streams.id),
    user: text("user").notNull(),
  },
  (t) => [primaryKey({ columns: [t.stream, t.user] })],
);

export const cartResumptions = sqliteTable("cart_resumptions", {
  id: text("id").primaryKey(),
  user: text("user").notNull(),
  product: text("product").notNull(),
  variant: text("variant").notNull(),
  quantity: integer("quantity").notNull(),
  created: text("created").notNull(),
});

export const streamLikes = sqliteTable(
  "stream_likes",
  {
    stream: text("stream").notNull(),
    user: text("user").notNull(),
    created: text("created").notNull(),
  },
  (t) => [primaryKey({ columns: [t.stream, t.user] })],
);

export const emailSuppressions = sqliteTable("email_suppressions", {
  recipient: text("recipient").primaryKey(),
  reason: text("reason").notNull(),
  created: text("created").notNull(),
});
export const emailWebhookEvents = sqliteTable("email_webhook_events", {
  id: text("id").primaryKey(),
  providerId: text("provider_id").notNull(),
  type: text("type").notNull(),
  created: text("created").notNull(),
});

export const authTwoFactor = sqliteTable("auth_two_factor", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => authUser.id),
  secret: text("secret").notNull(),
  backupCodes: text("backup_codes").notNull(),
  verified: integer("verified", { mode: "boolean" }).notNull().default(false),
  failedVerificationCount: integer("failed_verification_count").notNull().default(0),
  lockedUntil: integer("locked_until", { mode: "timestamp_ms" }),
}, t => [index("two_factor_user").on(t.userId)]);

// Financial amounts below are integer kobo; buyer-payment amounts remain NGN.
export const sellerSubscriptions = sqliteTable("seller_subscriptions", {
 store:text("store").notNull().references(()=>stores.id), mode:text("mode").notNull(), status:text("status").notNull().default("inactive"),
 paidUntil:text("paid_until").notNull().default(""), cancelAtEnd:integer("cancel_at_end").notNull().default(0),
 providerSubscription:text("provider_subscription").notNull().default(""),providerPlan:text("provider_plan").notNull().default(""),
 customerEmail:text("customer_email").notNull().default(""),updated:text("updated").notNull(),
}, t=>[primaryKey({columns:[t.store,t.mode]})]);
export const sellerSubscriptionPayments = sqliteTable("seller_subscription_payments", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),owner:text("owner").notNull(),mode:text("mode").notNull(),
 amountMinor:integer("amount_minor").notNull(),status:text("status").notNull().default("pending"),providerId:text("provider_id").notNull().default(""),
 providerPlan:text("provider_plan").notNull().default(""),recurring:integer("recurring").notNull().default(0),link:text("link").notNull().default(""),
 customerEmail:text("customer_email").notNull(),termsVersion:text("terms_version").notNull(),created:text("created").notNull(),updated:text("updated").notNull(),
 periodStart:text("period_start").notNull().default(""),periodEnd:text("period_end").notNull().default(""),
}, t=>[uniqueIndex("seller_subscription_charge_unique").on(t.mode,t.providerId).where(sql`${t.providerId}!=''`)]);
export const sellerBanks = sqliteTable("seller_banks", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),mode:text("mode").notNull(),
 bankCode:text("bank_code").notNull(),bankName:text("bank_name").notNull(),accountNumber:text("account_number").notNull(),accountName:text("account_name").notNull(),
 status:text("status").notNull().default("resolved"),note:text("note").notNull().default(""),created:text("created").notNull(),updated:text("updated").notNull(),
});
export const sellerEarningsReleases = sqliteTable("seller_earnings_releases", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),payment:text("payment").notNull().unique().references(()=>payments.id),mode:text("mode").notNull(),
 amountMinor:integer("amount_minor").notNull(),settlementReference:text("settlement_reference").notNull(),evidence:text("evidence").notNull(),actor:text("actor").notNull(),created:text("created").notNull(),
});
export const sellerAdjustments = sqliteTable("seller_adjustments", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),mode:text("mode").notNull(),amountMinor:integer("amount_minor").notNull(),
 reference:text("reference").notNull().unique(),reason:text("reason").notNull(),actor:text("actor").notNull(),created:text("created").notNull(),
});
export const sellerWithdrawals = sqliteTable("seller_withdrawals", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),mode:text("mode").notNull(),bank:text("bank").notNull().references(()=>sellerBanks.id),
 amountMinor:integer("amount_minor").notNull(),feeMinor:integer("fee_minor").notNull(),status:text("status").notNull().default("requested"),
 providerId:text("provider_id").notNull().default(""),reference:text("reference").notNull().unique(),note:text("note").notNull().default(""),created:text("created").notNull(),updated:text("updated").notNull(),
});

// Competitive marketplace features. Event identifiers and daily visitor keys are
// opaque, deduplicated analytics identifiers; no payment credentials are stored.
export const livestreamDeals = sqliteTable("livestream_deals", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),product:text("product").notNull().references(()=>products.id),stream:text("stream").notNull().references(()=>streams.id),
 promoPrice:integer("promo_price").notNull(),maxQuantity:integer("max_quantity").notNull(),soldQuantity:integer("sold_quantity").notNull().default(0),startsAt:text("starts_at").notNull(),endsAt:text("ends_at").notNull(),status:text("status").notNull().default("scheduled"),created:text("created").notNull(),updated:text("updated").notNull(),
},t=>[index("live_deals_stream_status").on(t.stream,t.status,t.startsAt,t.endsAt)]);
export const sellerAnalyticsEvents = sqliteTable("seller_analytics_events", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),product:text("product").notNull().default(""),stream:text("stream").notNull().default(""),visitor:text("visitor").notNull(),event:text("event").notNull(),day:text("day").notNull(),orderId:text("order_id").notNull().default(""),created:text("created").notNull(),
},t=>[uniqueIndex("seller_analytics_daily_dedupe").on(t.store,t.product,t.stream,t.visitor,t.event,t.day),index("seller_analytics_store_day").on(t.store,t.day,t.event)]);
export const productBundles = sqliteTable("product_bundles", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),product:text("product").notNull().unique().references(()=>products.id),title:text("title").notNull(),description:text("description").notNull(),image:text("image").notNull(),price:integer("price").notNull(),active:integer("active").notNull().default(0),created:text("created").notNull(),updated:text("updated").notNull(),
},t=>[index("product_bundles_store_active").on(t.store,t.active)]);
export const productBundleItems = sqliteTable("product_bundle_items", {
 bundle:text("bundle").notNull().references(()=>productBundles.id),product:text("product").notNull().references(()=>products.id),quantity:integer("quantity").notNull(),nameSnapshot:text("name_snapshot").notNull(),priceSnapshot:integer("price_snapshot").notNull(),
},t=>[primaryKey({columns:[t.bundle,t.product]})]);
export const bundleOrderSnapshots = sqliteTable("bundle_order_snapshots", {
 orderId:text("order_id").notNull().references(()=>orders.id),bundle:text("bundle").notNull(),title:text("title").notNull(),contents:text("contents").notNull(),bundlePrice:integer("bundle_price").notNull(),
},t=>[primaryKey({columns:[t.orderId,t.bundle]})]);
export const creatorProfiles = sqliteTable("creator_profiles", {
 user:text("user").primaryKey(),displayName:text("display_name").notNull(),socialLinks:text("social_links").notNull().default("[]"),categories:text("categories").notNull().default("[]"),status:text("status").notNull().default("pending"),note:text("note").notNull().default(""),created:text("created").notNull(),updated:text("updated").notNull(),
});
export const affiliatePartnerships = sqliteTable("affiliate_partnerships", {
 id:text("id").primaryKey(),creator:text("creator").notNull().references(()=>creatorProfiles.user),store:text("store").notNull().references(()=>stores.id),product:text("product").notNull().references(()=>products.id),commissionBps:integer("commission_bps").notNull(),status:text("status").notNull().default("pending"),created:text("created").notNull(),updated:text("updated").notNull(),
},t=>[uniqueIndex("affiliate_creator_product_unique").on(t.creator,t.product),index("affiliate_store_status").on(t.store,t.status)]);
export const affiliateClicks = sqliteTable("affiliate_clicks", {
 id:text("id").primaryKey(),partnership:text("partnership").notNull().references(()=>affiliatePartnerships.id),visitor:text("visitor").notNull(),created:text("created").notNull(),
},t=>[uniqueIndex("affiliate_click_dedupe").on(t.partnership,t.visitor)]);
export const affiliateCommissions = sqliteTable("affiliate_commissions", {
 id:text("id").primaryKey(),partnership:text("partnership").notNull().references(()=>affiliatePartnerships.id),orderId:text("order_id").notNull().references(()=>orders.id),amount:integer("amount").notNull(),status:text("status").notNull().default("pending"),created:text("created").notNull(),updated:text("updated").notNull(),
},t=>[uniqueIndex("affiliate_commission_order").on(t.partnership,t.orderId)]);
export const liveAuctions = sqliteTable("live_auctions", {
 id:text("id").primaryKey(),store:text("store").notNull().references(()=>stores.id),product:text("product").notNull().references(()=>products.id),stream:text("stream").notNull().references(()=>streams.id),startPrice:integer("start_price").notNull(),increment:integer("increment").notNull(),reservePrice:integer("reserve_price"),startsAt:text("starts_at").notNull(),endsAt:text("ends_at").notNull(),status:text("status").notNull().default("scheduled"),winningBid:text("winning_bid").notNull().default(""),orderId:text("order_id").notNull().default(""),created:text("created").notNull(),updated:text("updated").notNull(),
},t=>[index("live_auctions_stream_status").on(t.stream,t.status,t.endsAt)]);
export const auctionBids = sqliteTable("auction_bids", {
 id:text("id").primaryKey(),auction:text("auction").notNull().references(()=>liveAuctions.id),bidder:text("bidder").notNull(),amount:integer("amount").notNull(),requestId:text("request_id").notNull().unique(),created:text("created").notNull(),
},t=>[index("auction_bids_rank").on(t.auction,t.amount,t.created)]);
export const foundingProgram = sqliteTable("founding_program", {
 id:integer("id").primaryKey(),enabled:integer("enabled").notNull().default(0),durationDays:integer("duration_days").notNull().default(30),maxParticipants:integer("max_participants").notNull().default(100),eligibility:text("eligibility").notNull().default("Verified sellers approved by an administrator."),updated:text("updated").notNull(),
});
export const foundingEnrollments = sqliteTable("founding_enrollments", {
 id:text("id").primaryKey(),store:text("store").notNull().unique().references(()=>stores.id),status:text("status").notNull().default("pending"),startsAt:text("starts_at").notNull().default(""),endsAt:text("ends_at").notNull().default(""),approvedBy:text("approved_by").notNull().default(""),note:text("note").notNull().default(""),created:text("created").notNull(),updated:text("updated").notNull(),
},t=>[index("founding_enrollments_status_end").on(t.status,t.endsAt)]);
