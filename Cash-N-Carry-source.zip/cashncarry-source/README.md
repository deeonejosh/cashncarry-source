# Cash N Carry — social-commerce MVP

Existing Vinext/React, Cloudflare Worker, D1 and R2 stack retained. This release is **ready for controlled testing, not approved to accept real customers or real payments**. The hosted Site is public; authenticated customer, seller and admin actions retain server-side permissions. No fabricated products, reviews, sales, viewer counts, verification badges or payouts are seeded. Coins, gifts, battles and gift wallets are excluded.

## Implemented

- Mobile-first marketplace, real empty/loading/error states, search, category filtering, sorting and pagination. State/area matching distinguishes seller location from delivery coverage. Optional browser location is used locally for distance filtering only against seller-supplied public business coordinates.
- Shareable product and storefront routes, media, variant prices/stock, delivery fees/time and returns information. Seller photos/video uploads have file signatures, size limits, progress and range playback. Direct uploads are ready after storage validation; they are not represented as transcoded/processed provider assets.
- Existing ChatGPT sign-in preserved. Better Auth email registration, verified sessions, password reset and session revocation are implemented behind required email configuration. Existing verified email identities map to existing profiles.
- Customer profile, private saved addresses, favourites, orders, download order records, notifications/preferences, reports and return/refund requests. Updates enqueue transactional email; configured mail is sent with bounded retries, failed mail remains in the outbox for admin retry.
- Seller storefront/catalog/inventory, public area and delivery coverage, verification documents, order fulfilment/tracking, scheduled broadcasts, product pins, chat moderation and real payment records. Private verification files are inaccessible from the public media route.
- Single-seller checkout with server-calculated price/delivery/stock and database inventory guards. D1 batches reserve stock; cancellation restores the same variant stock. Browser-supplied totals are ignored. Flutterwave Standard initiation, independent transaction verification, authenticated v3 webhooks, duplicate-event protection, pending/paid/failed/cancelled/refunded states and refund reconciliation are implemented with guarded test/live support. Production remains in test mode as confirmed on 8 October 2026.
- Cloudflare Stream native WHIP host/WHEP viewer integration (browser broadcasts are not recorded), camera permission/connection errors, heartbeat expiry, scheduling, host ending and provider recording refresh. External TikTok links explicitly open **Watch on TikTok**; they do not embed TikTok LIVE. Existing direct HLS streams remain supported.
- Protected `/admin`: real operational metrics, users/stores, verification review, product/video/live moderation, orders, campaigns, reports, audit logs. `/admin/settings`: categories, featured products, commission configuration, policy editing, payment/refund oversight, email retry and private database backup.
- Cash N Carry Ads product promotion submissions with discovery (NGN 1,000/day) or marketplace (NGN 2,000/day), dates and review. Approved campaigns can use sandbox checkout. Sponsored display requires verified payment, active dates and available products. Recorded, deduplicated impressions/clicks are actual app events, not invented metrics.
- Migrations, indexes, same-origin mutation checks, ownership checks, persistent account/upload/chat/advertising rate controls, structured operational errors and editable policy drafts.

## Access

Open the hosted Site while signed into the owner account **ogundiyatemidayo1@gmail.com** (note the `1`). The different account shown in the earlier access-denied screenshot is not the owner. Existing private sharing is preserved.

- Customer: account icon → Account workspace; My orders for purchases. Email sign-in is `/account` once configured; ChatGPT sign-in is still available.
- Seller: Seller Centre → create storefront → list products. Account workspace → Delivery, Verification, Broadcasts, Sales and Support.
- Admin: `/admin`. First admin is bootstrapped by the private server variable `REVIBE_ADMIN_EMAIL`, currently the owner email. There is no public admin signup, default password or self-promotion endpoint. A trusted operator changes this allowlist through Sites configuration, then redeploys.

Creating a storefront currently enables selling while verification is pending; verification badges require administrator approval. If the business requires approval before any listing, change and validate this onboarding policy before launch.

## Configuration

D1 binding `DB` and R2 binding `BUCKET` are managed by Sites through `.openai/hosting.json`. Do not put secrets in that file or client-side variables. `.env.example` lists local keys; runtime values must be set through Sites and redeployed.

| Variable | Purpose |
|---|---|
| `REVIBE_ADMIN_EMAIL` | Trusted first-admin verified email; no default |
| `SITE_URL` | Exact HTTPS site origin for authentication/payment callbacks |
| `BETTER_AUTH_SECRET` | Random secret of at least 32 bytes |
| `RESEND_API_KEY`, `EMAIL_FROM` | Transactional email and verified sending domain |
| `FLW_SECRET_KEY` | Flutterwave **test** secret (`FLWSECK_TEST…`); must match configured mode; live requires explicit merchant readiness approval |
| `FLW_WEBHOOK_HASH` | Strong secret matching Flutterwave v3 webhook `verif-hash` |
| `FLW_MODE` | `test`; production-money mode is intentionally not enabled |
| `STREAM_ACCOUNT_ID`, `STREAM_API_TOKEN` | Paid Cloudflare Stream account and account-scoped Stream permissions |

Configure Flutterwave webhook URL as `{SITE_URL}/api/payments/webhook`. Do not whitelist the browser redirect as payment evidence. Webhooks must be reachable from Flutterwave: owner-private Site access may prevent delivery, so validate provider access before payment testing. Provider callbacks may require a separate publicly reachable authenticated webhook service if the private Site gate applies to the route.

Cloudflare Stream publishing secrets are returned only to the owning active seller and excluded from public and admin listing payloads. Host permissions require HTTPS. Run real host/viewer tests on iPhone/Android before activation.

## Deployment and verification

Use the Sites source workflow to open this existing project, build the exact pushed commit and deploy its archive. Preserve the current audience; this existing Site is public. All applied migrations are immutable; add new ones. Inventory decrement belongs to triggers, never duplicate it in application code.

Checks:

```sh
node node_modules/typescript/bin/tsc --noEmit
node tests/commerce.test.mjs
node tests/media.test.mjs
node tests/recovery.test.mjs
node tests/operations.test.mjs
```

API checks use actual route code and an SQLite D1 adapter, covering ownership, CSRF, checkout retry/rollback, concurrent price changes, stock/variant reservation and restock, single-seller enforcement, delivery fees/coverage, private addresses/favourites, following/reviews, chat/schedules/TikTok labels, publish-secret omission, reports, suspension, admin authorization and audit logs. Payment tests use a controlled provider-response fixture for independent verification and duplicate webhooks; they are **not** a provider integration pass.

Current browser evidence: browser QA is unavailable in the 8 October audit because the Sites-required control-browser capability is not exposed. Visual checks at 360/390/768/1440px, signed customer/seller/admin journeys, native email delivery, real provider playback/payment and phone behaviour remain untested release gates. Do not infer those passed from successful compilation or API fixtures.

## Payments and inventory operations

- Cash-on-delivery orders reserve stock until fulfilment or permitted cancellation; collected cash is not inferred from order creation.
- Sandbox online checkout creates a pending order and a 30-minute provider link. A failed initiation leaves the order visible for retry/support.
- Releasing an online reservation requires disabling the payment link and independently verifying a failed/cancelled transaction. Uncertain/pending transactions retain stock for reconciliation; do not manually free it while a charge could succeed.
- A successful late charge to an already-cancelled order is `review_required`, never automatically fulfilled. Resolve it through provider reconciliation/refund.
- Refunds: customer request → admin approval → sandbox provider initiation → provider-status verification. Timeout during initiation becomes `reconciliation_required`; do not blindly retry and risk duplicate refunds. Confirm the provider record before recovery.
- Seller payout allocation, settlement transfers and collected commissions are not implemented. Commission is a saved setting, not booked revenue. Financial records are labelled test mode.

## Backup, restoration and maintenance

1. Admin settings → private database export. It contains personal data, verification metadata and password hashes. Encrypt immediately and restrict access; do not store in public folders. Database export does not contain R2 object bytes.
2. A trusted storage operator must separately back up R2 objects, preserving keys, including private `verification/` objects. Protect the media backup with equivalent access controls.
3. For recovery, create an isolated recovery Site/database, apply the same migrations and restore media. Generate recovery SQL with `node scripts/restore-backup.mjs backup.json restore.sql`. Apply only to the empty migrated recovery database. The script suppresses inventory triggers during import, then restores them; importing order items must not decrement already-backed-up stock. Email sessions/verification tokens are intentionally not restored.
4. Verify foreign keys, order totals, product and variant stock, private document permissions and media keys in recovery. Re-run tests and representative real-account journeys before cutover. Rotate provider/auth secrets if compromise is suspected. Never restore an unverified backup directly over production.
5. Retain release commits/archives and encrypted daily backups under an owner-approved retention policy. **Scheduled off-site backups and restoration drills are not configured or verified yet.** Sites owns the backing resources; request operator-assisted storage exports/platform recovery as needed rather than assuming a user Cloudflare account has access.
6. Monitor Site worker error logs and payment/refund reconciliation queues daily. Use admin email retry for failed outbox entries. Establish external alerting, response ownership, log retention and uptime checks before public launch. No external monitoring destination has been configured.

## Launch blockers

- Current owner-private access prevents ordinary customer access; the owner must choose intended sharing/public access and test multiple real accounts.
- Missing Resend credentials/verified sender prevent independent email signup/recovery. Set these securely; never paste secrets into chat.
- Missing Flutterwave sandbox credentials/webhook delivery prevent actual payment/refund verification. Live merchant mode is not activated by this release.
- Missing Cloudflare Stream account/token prevent real native host/viewer/recording tests. TikTok outbound links and scheduling work independently.
- Seller settlement/commission collection is absent. Adopt a reviewed commercial settlement model before accepting online customer payments.
- Policy drafts require operator identity, support contacts, delivery/return/dispute rules and owner/legal review. No legal-compliance claim is made.
- Phone-device/signed-account/browser provider journeys, off-site backup drill and monitoring must pass before declaring launch readiness.

## Branding

Public platform branding is centralised in `app/brand.ts`: **Cash N Carry**, **Watch Live. Discover. Shop.** Header/admin/mobile wordmarks, emails, payment checkout display title, receipts, metadata, structured website data, manifest and generated favicon use this configuration. Policy copy is updated by an additive data migration; accounts, seller content, inventory and order/payment records are preserved.

The existing domain, `SITE_URL`, `REVIBE_ADMIN_EMAIL`, internal component paths and `revibe-backup-v1` recovery format are intentionally retained. The displayed Site title is changed independently of its URL. The existing email sender/display name, verified sending domain, payment provider merchant profile/statement descriptor, any custom domain and registered legal entity require owner configuration; none is invented or changed by this rebrand. Manifest metadata does not add offline caching or change authentication. Old browser icons/installed app labels may need refresh/reinstallation after their cache expires.


## Operational fixes after review

- The public product catalogue uses server search, category/location/coverage and coordinate-distance filters, stable sorting and 12-item database pages. General discovery data includes at most 60 products plus separately fetched live pins. Private seller inventory remains complete. Filtering aborts superseded requests and has loading/error/retry states.
- Public product/store detail pages and stream lookup now honour account suspension as well as store suspension.
- Seller media uploads enforce an admin-configurable per-seller rate limit (10 attempts/minute by default). Product images use an admin-configurable per-seller UTC-day allowance (development defaults: 100 completed images / 500 MB, maximum 10 MB per image and 10 photos per product); image quota is charged only after storage confirms completion, failed requests release reservations, idempotency keys prevent duplicate retry charges, and stale reservations are reclaimed. Video uploads retain the legacy 20-file / 200 MB daily allowance and 40 MB/file limit. Quota settings and tracked usage are available in Admin → Settings → Image upload limits. Storage-cost capacity must be reviewed before production deployment.
- Email outbox deliveries have exclusive leases, bounded exponential backoff and stable Resend idempotency keys. Interrupted leases can recover after 10 minutes; uncertain deliveries outside the 23-hour safe retry window require provider reconciliation instead of automatic resend. Failed and uncertain states are visible in admin settings. Recovery runs when new notifications trigger delivery or an admin sends pending emails. A private Worker scheduled-event handler is included. **Its cron trigger still needs platform/operator configuration (every five minutes)**; transactional email credentials and scheduled queue processing remain launch requirements.
- Admin settings now provide an audited seller approval policy for creating/editing products. The existing policy remains the default, so enabling it does not hide existing listings. First verify seller evidence, then enable this policy if required by the business.
- Tests exercise pagination beyond the initial discovery slice, exact search/location/distance semantics, concurrent upload reservations, storage failure, email claim concurrency/recovery/backoff, seller-policy authorization and complete seller inventory.

External payment/stream/email credentials, real-account/mobile/provider tests, seller settlement, public sharing, reviewed legal/support details, off-site backups and external monitoring remain owner/service-dependent release gates. These fixes do not activate live merchant payments or change sharing.


## Purchase and discovery regression fixes

Shared product links wait for account/discovery loading, then retrieve the selected product by ID independently of catalogue pagination. They open purchase options without redirecting back to the detail page. Missing/archived/suspended products show an error and retry control. Featured products are fetched separately (up to six), with the active catalogue filters, so page changes do not hide featured items. The broadcast overview counts live, scheduled, replay, ended and TikTok-link states separately; an external TikTok link is not counted as a confirmed native live session. Browser regression testing verifies the detail-page buy button opens the product dialog.

### Refund, media moderation and storefront follow-up
Refund reviews use a status compare-and-swap inside the audit transaction. Progressed or concurrently changed refunds return 409; no unchanged refund is recorded as successfully reviewed. Uploaded media is public only while referenced by an available product in an active storefront. Permissions are checked before ETag and range responses; unlinked draft uploads remain accessible only to their active seller owner or an administrator. Admin review can access hidden assets. Media responses use no-store. Hidden uploaded files are now blocked independently of listing references, including files shared by another listing; an explicit administrator product restoration releases the associated blocks; previously downloaded or cached copies and external third-party URLs cannot be recalled by this application.

Storefront broadcasts now link to their live, scheduled or replay viewer. TikTok links are explicitly outbound, and ended sessions without a replay have no playback action. Shared broadcast retrieval rejects unavailable or suspended broadcasts without exposing host credentials.

Verification: TypeScript and commerce, media, recovery and operations suites pass. New regressions cover progressed refunds, concurrent review changes, hidden-media ranges/ETags, gallery media, suspended stores/owners, draft ownership and broadcast retrieval. Browser preview confirms storefront scheduled and replay actions; provider playback and real financial operations remain credential-gated launch checks.

### Media republication and native connection fixes
Migration 0009 adds persistent media blocks, backfills existing archived product uploads and prevents publication writes from racing moderation. Images, videos and gallery uploads must belong to the submitting seller; old uploads without ownership metadata may be reused only when already attached to that seller’s listings. Local upload links are canonicalised before validation. Public download also checks uploader ownership where available. Admin product restoration clears the referenced media blocks in the same audited transaction. Block records are included in export/restoration, with legacy-backup backfill. Shared files hidden through any listing require administrator review before reuse. External media and previously cached/downloaded copies remain outside this revocation boundary.

Native connection requests validate session state and confirm one guarded database update, rechecking seller ownership and suspension at write time. Ended sessions or concurrent termination return 409, rather than success. Regression fixtures verify owner/cross-seller image/video/gallery permissions, copied/encoded links, SQL moderation guards, admin restoration, native connection conflicts and backup persistence. Actual provider playback remains credential-gated.

Readiness fixes and remaining launch gates: [docs/readiness-improvements.md](docs/readiness-improvements.md). Run `node tests/readiness.test.mjs` alongside the existing commerce, media, operations and recovery suites.

Welcome/sign-in/signup routes and configuration: [docs/entry-pages.md](docs/entry-pages.md). Run `node tests/auth-entry.test.mjs` for return-navigation and registration safeguards.

## Audit update — 8 October 2026

Targeted fixes cover normalized variant uniqueness, suspended-seller cart guards, supported payment/state validation, explicit concurrent order/review conflicts, native preparation leases, single-native-live guards, ending without provider configuration, backup moderation tables, verification upload throttling, bounded Save requests and viewer autoplay recovery. Existing order-transition and single-review database triggers already prevented invalid transitions; this audit did not identify duplicate restocking from those guarded routes.

Production `FLW_MODE` remains `test`; transactional email sender credentials are absent. The existing hourly maintenance schedule is paused, so scheduled runs are not active. Do not infer current operational health from credential presence or test fixtures. Run all tests with `node --test tests/*.test.mjs`; type-check using `node node_modules/typescript/bin/tsc --noEmit --incremental false`. Test identities/data are local and isolated. No money was charged, no refund/payout was run, no genuine broadcast was ended and no customer email was sent during the audit.

## Portrait livestream update — 9 October 2026 (Europe/London)

Host and viewer now use immersive viewport-height stages, centred cover video, safe-area padding, visual-viewport keyboard sizing and compact lower overlays. Desktop uses one centred portrait stage. Native publishing normalizes the outgoing video to 720×1280 through a camera-only canvas capture track, preserving native microphone audio. Camera changes feed the same publisher; rotation reads actual video dimensions every frame, and capture preferences are reapplied. Canvas media and animation resources are stopped with the session. Unsupported canvas capture reports an error rather than publishing a differently shaped feed. Real-device performance and provider delivery remain unverified.

Public discovery excludes ended sessions without replay; private history retains them. Ended viewers have store/discovery actions and optional replay, no composer or empty Shop control, and retain cart access. Followed broadcasts are in Live/Following; duplicate navigation, one-page pagination and plural counts were simplified.

Empty seller delivery coverage means unconfirmed delivery, even if the default fee is zero. Checkout now requires saved coverage and a nonnegative stored integer fee before creating a delivery order. Explicit zero delivery remains valid when coverage is configured. No pickup integration exists in this source and none was invented. Gearpulse UK’s Headset listing was read-only reviewed: no demo/test evidence was found, so it remains published. Its empty delivery coverage blocks delivery checkout until the seller configures it.

32 reported regression tests pass, including outgoing crop/audio cleanup, delivery quote validation, server checkout blocking and discovery/private-history preservation. TypeScript passes. Browser screenshots, 360/390/768/1440px visual QA and two-device host/viewer confirmation remain blocked by unavailable required control-browser capability. These changes are not proof of successful provider playback.

Material references: [Canvas capture](https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement/captureStream), [camera constraints](https://developer.mozilla.org/en-US/docs/Web/API/MediaStreamTrack/applyConstraints), [Cloudflare WHIP/WHEP](https://developers.cloudflare.com/stream/examples/browser-based-webrtc/).
