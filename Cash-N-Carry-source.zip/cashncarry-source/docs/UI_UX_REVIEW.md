# Cash N Carry UI/UX implementation review

Baseline: deployed version 88. Source review covers every page route below plus hash-based Home, Shop, Live, Seller, Orders, product/cart/checkout dialogs, account and workspace tabs. Source inspection is not authenticated rendered-page verification.

## Proposed changes before implementation

1. Consolidate seller navigation across Seller Centre, workspace and finance pages into grouped destinations. Keep existing APIs, roles and business logic.
2. Replace seller activity-only overview cards with server-derived earnings, pending order counts, activation progress and focused task actions.
3. Add separate withdrawal interface with fee/recipient amount preview, accurate unavailable states and history; no new payout mechanics.
4. Inspect guest return-to-browsing and saved cart intent; preserve existing sign-in gating. No reproducible guest loop found in this source review.
5. Improve buyer header/account shortcuts, product contact access, checkout progress, message composition and error recovery.
6. Group admin destinations and add explicit policy/settings/email links with existing permissions.
7. Extend verification and payout email previews; no emails sent or automatic delivery enabled.
8. Preserve portrait streaming controls and add safe-area/accessibility refinements where needed.

## Route inventory (all inspected in source)

- `/account`
- `/admin/email-templates`
- `/admin`
- `/admin/settings`
- `/community-guidelines`
- `/delivery`
- `/forgot-password`
- `/help`
- `/messages`
- `/order/[id]`
- `/`
- `/payment-return`
- `/policies/[id]`
- `/privacy`
- `/product/[id]`
- `/refunds`
- `/seller-terms`
- `/seller/billing-return`
- `/seller/finance`
- `/seller`
- `/sign-in`
- `/sign-up`
- `/store/[id]`
- `/terms`
- `/two-factor`
- `/welcome`
- `/workspace`

## Verification boundaries

Protected buyer, seller and admin interaction requires a signed-in session. No physical Android/iPhone testing or independent participant study is available in this session. Public before/after inspection and automated tests are separate evidence. No claim of 10/10 usability or full launch readiness. No legal policies will be published and no real financial transactions performed.

## Implemented changes

- Shared grouped seller menu, desktop Seller Centre sidebar and collapsible mobile destinations; removed duplicate hardcoded Seller Centre menus.
- Canonical verification link replaces the incomplete legacy workspace submission form.
- Seller overview adds reconciled available, pending and reserved earnings and activation steps.
- Dedicated Withdrawals section; amount, fee, recipient amount and total deduction shown separately; amount maximum accounts for fees. Provider configuration accurately marks unavailable payouts.
- Buyer shared header gains Messages; account shortcuts add notification preferences with clearer icons.
- Admin sections group subscriptions and finances; policy and email template shortcuts respect settings permissions.
- Chat previews selected images, cleans up object URLs and preserves scroll position when reading older messages.
- Eight state-specific verification/withdrawal email previews added. Existing subscription and buyer/seller order templates retained. No email automation enabled or messages sent.

## Pages affected

Seller Centre, seller finance tabs, workspace verification/shipping/broadcast wrappers, account, admin, admin email templates, messaging, and all pages using CustomerHeader (product, order, storefront, help, policies and payment status). Other pages retain reviewed existing UI; no decorative rewrite or finance/backend behaviour change.

## Remaining verification

Signed-in buyer, seller and admin rendered-page tests need an authorised session. Physical device testing and representative user studies are outstanding. Only desktop public screenshots are available. No independent before/after rating can be issued from source review or regression tests alone. Live billing/payout readiness and email delivery remain separate operational blockers.
