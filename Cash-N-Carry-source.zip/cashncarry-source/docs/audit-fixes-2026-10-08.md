# Cash N Carry audit corrections — 8 October 2026

The existing visual style, public audience, accounts, database identifiers and provider settings are preserved. No real transactions, account creation or legal approval were performed.

| Audited defect | Implemented correction | Evidence |
|---|---|---|
| Cart/Seller login lost the requested action | Validated internal return URLs carry a recognised cart action or Seller/Orders destination. An authenticated return opens the cart once and consumes the action marker. | Browser Cart → sign-in URL contains `open=cart`; Seller → sign-in contains `#seller`. Isolated UI fixture reopens the empty cart at 360/390/768/1440px without internal horizontal overflow. Actual credential login remains untested. |
| Workspace sign-in lost the requested tab | Notifications/Support URLs are retained through sign-in. | Rendered signed-out Notifications link points back to `/workspace?tab=Notifications`. |
| Logout swallowed failed email-session termination | Response status and timeout are checked. The UI blocks duplicate attempts, stays on the page on failure, and shows a persistent accessible retry message. ChatGPT-only configuration can continue its existing logout without requiring unavailable email auth. | Network/HTTP failure unit tests and isolated browser failure fixtures; actual session-cookie termination remains untested. |
| Abandoned payment reservations had no sweep | Database lease prevents overlapping sweeps; scheduled Worker handler and traffic-driven background maintenance reconcile expired pending online orders. Each run checks up to three rows; uncertain rows rotate so they cannot starve later rows. | Fixture tests verify failed/cancelled restock, success settlement, unknown response retention, future exclusion, duplicate sweep protection and concurrent late-success safety. |
| Payment reservation could be orphaned if initiation failed | The payment intent is persisted in the same atomic batch as the online order and stock reservation. Expired payment links cannot be returned for another attempt. | Transactional checkout suite and expired-link regression. |
| Historical policy content still displayed ReVibe | Public policy title/body rendering uses central platform wording. Existing migration remains intact; editable content and owner-review status are preserved. | Rendered Terms body now says Cash N Carry, including databases retaining historical draft wording. |
| Live empty state skipped a heading level | Main Live empty-state heading now uses H2. | Browser accessibility tree confirms H1 → H2. |

## Verification

TypeScript and seven automated suites: auth-entry, commerce, payment-reservations, readiness, media, operations and recovery. Provider responses and UI customer identity used for regression tests are explicitly isolated fixtures, not real sessions or transactions.

Temporary QA routes were removed before packaging. Reproduction fixtures remain under `tests/visual-qa/audit-page.tsx.txt` and `audit-width.html`; copy them temporarily to `app/qa-audit/page.tsx` and `public/qa-audit-width.html` to repeat the checks, then remove both before publishing. These fixtures do not create accounts or alter production data.

## Configuration and remaining launch gates

- Email accounts: configure `BETTER_AUTH_SECRET`, existing `SITE_URL`, `RESEND_API_KEY` and a verified `EMAIL_FROM`; apply the existing authentication migrations. Never rotate an existing production authentication secret without a session migration plan. Verify registration, email verification, correct/incorrect login, reset/expired reset links, actual logout and protected-page access with authorised test accounts.
- Payments: configure Flutterwave test `FLW_SECRET_KEY`, `FLW_WEBHOOK_HASH`, existing `SITE_URL` and test mode. Verify actual sandbox success/failure/cancellation, duplicates and refunds. Live mode intentionally remains disabled; adding real credentials alone does not activate merchant payments.
- Reservation maintenance: traffic triggers a sweep when sandbox payments are configured. The scheduled handler is implemented, but an operator must enable and confirm a Worker cron (for example every five minutes) for reliable maintenance during periods without traffic. No public maintenance endpoint or new persistent admin credential is added. Unknown/pending/not-found provider responses keep stock reserved for support reconciliation; expiry alone never proves that no charge occurred. Legacy online orders lacking a payment intent need operator review.
- Owner policy review: complete legal operator/contact information, dispute handling and delivery/returns/commission details in the protected admin editor. The draft notice is deliberately retained until reviewed.
- Authorised real customer/seller/admin browser journeys and representative product/broadcast data are still required. Native broadcasts, email delivery and real payment/refund processing remain service-gated.
- Offsite D1/R2 backups, restoration drill and operational alerting remain unverified.

This update is ready for further testing, not certified ready for real customers and payments.
