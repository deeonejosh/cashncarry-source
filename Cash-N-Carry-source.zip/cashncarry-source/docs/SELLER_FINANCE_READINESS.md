# Cash N Carry seller monetisation readiness

Implementation is sandbox only. Live subscription collection and live payout execution are rejected server-side, irrespective of the site's buyer-payment mode. This release does not establish a regulated wallet or prove provider approval.

## Activation

Create store → resolve Nigerian bank → submit individual/business identity evidence → human bank ownership review → human verification review → verified monthly subscription payment → publish/list/go live. Existing verified badges remain, but do not create subscriptions. All sellers without a paid period are paused for new selling. No records are deleted. Existing order management, document submission, messaging and dashboard access remain.

Status is evaluated at request time; an expired period cannot keep access by waiting for a scheduler. Catalogue and public shopping queries exclude inactive sellers. Storefront contact pages remain available. Fulfilment remains possible after expiry. Suspensions are distinct from subscription expiry and use existing moderation and support appeal processes.

## Billing

Proposed price NGN 2,000/month; owner settings can change and confirm the proposal. Manual verified renewal adds one calendar month, clamped to the last valid day. Pending/failed attempts do not activate access. Unique provider transaction identifiers and a renewal lock make retries safe. Only authenticated raw-body HMAC/v3 secret-hash webhook requests may verify payments. The return page independently verifies with the provider. History records each paid period and provides a receipt reference.

Automatic renewal is not offered until Flutterwave merchant capability is established. No recurring plan/card mandate is created, no card credentials stored and no automatic billing is represented as active. Provider recurring integration, cancellation callbacks and verified recurring-cycle matching require a separate capability-confirmed release.

## Earnings and payouts

All amounts use integer kobo. Test/live histories are isolated. Total buyer payments, refunds, unreleased/held earnings, released earnings, payout reservations and paid withdrawals are separate. Only evidence-backed release rows produce available credit; a delivered order alone does not. Release is limited to verified paid amounts and requires settlement reference, hold period and absence of refunds/disputes. A delivery timestamp is recorded on fulfilment. Historical delivered orders without timestamp evidence cannot be released automatically.

Current models: unconfirmed (withdrawals blocked); sandbox platform simulation (test requests only); direct settlement (no platform withdrawal balance). Processor net settlement must be evidenced and recorded conservatively after costs; there is no automatic settlement-import integration yet. Administrators must never label a test release as real settlement evidence.

Completed refunds, unresolved refunds/disputes and append-only debit adjustments reduce eligible amounts. Already reserved or paid requests are deducted. A negative balance is a reconciliation deficit, not withdrawable funds. Duplicate request IDs are idempotent and amounts/destinations are immutable. Atomic database checks prevent concurrent overdraw. Requests require provider-resolved and human-approved bank ownership. Only authorised finance administrators with existing MFA access may review/process/reconcile payouts.

A transfer POST timeout leaves processing reserved. Query the original reference; do not retry a transfer POST with a new ID. Only an independently matched final provider status can mark Paid/Failed. Paid/Failed cannot be manually selected. Sandbox API calls are explicitly test-mode only.

## Owner / operational blockers before live enablement

- Confirm legal operator registration, merchant onboarding eligibility and written Flutterwave marketplace payout approval.
- Choose provider direct split settlement or approved platform-controlled payouts; do not mix models.
- Confirm processor settlement evidence/API access and net amounts, refunds, reserves and chargebacks.
- Approve NGN price, payout fees, taxes, minimums, holding periods, service timelines and cancellations.
- Review Nigerian payment, consumer, tax and privacy requirements with suitable professional advice.
- Approve the seller policy draft through the existing policy workflow; published policies are not auto-replaced.
- Document data minimisation, retention/deletion of identity documents and bank data, human-review criteria and appeal/contact handling.
- Confirm recurring mandate support before enabling automatic billing.
- Run representative sandbox buyer/seller/admin journeys and device checks, then separately authorised live transaction tests.

No live-enable switch is provided in the admin UI in this release. Removing server locks requires a separate reviewed implementation and explicit owner instruction.

## Bank detail capture and provider verification

Bank details can be saved privately with seller-declared account holder name and pending_resolution status. Saving does not verify the bank account or ownership. Flutterwave v3 sandbox accepts only test accounts; real account lookups are unavailable in the current configuration. Pending records cannot be approved by the bank review action or selected for payouts. Sandbox test accounts can separately be resolved, with exact account-number matching, before a human ownership review. Live bank resolution remains an operational blocker; this change enables neither real collection nor transfers. Saved accounts remain isolated by store and payment mode, and public/history responses expose only the last four account digits.

## Independent identity review

Human seller identity approval no longer requires an approved bank account. Both administrative review endpoints retain administrator permissions, MFA and concurrent-review safeguards. Seller publishing still requires identity verification and an active subscription. Payout requests independently require provider-resolved, ownership-approved banks and eligible settled earnings. Pending bank capture cannot grant payout access. The bank form uses shared server/client validation and focused inline feedback rather than browser-only submission blocking.
