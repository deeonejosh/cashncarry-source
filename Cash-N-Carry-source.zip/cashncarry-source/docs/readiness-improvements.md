# Cash N Carry readiness improvements

Brand: Cash N Carry — Watch Live. Discover. Shop.

## Corrections

| Area | Confirmed problem | Correction | Verification |
|---|---|---|---|
| Payment return | Temporary verification failure had no recovery action | Retry with timeout, pending/failed/refunded/review states, spaced actions; payment remains server verified | Browser fixture: failure → retry → pending at 360, 390, 768 and 1440px; no horizontal overflow |
| Account | Recovery links opened the wrong mode; session requests could fail without feedback | Reset-token landing, actionable errors, timeout and request completion | Browser token landing and isolated session network failure |
| Product gallery | Browser URL validation rejected uploaded internal media paths | Accept HTTPS or /api/media/ paths; label removal controls | Browser internal-path validity check |
| Live playback | Requests and peer sessions could outlive the component | Abort, timeout, captured video cleanup and accessible retry | Isolated rejected playback endpoint; real broadcast untested |
| Accessibility | No keyboard shortcut to main content | Focusable main regions, skip link that preserves shopping route, reduced-motion preference | Browser keyboard focus and preserved marketplace view |
| Images | Noncritical images loaded immediately | Lazy decoding/loading, eager priority for primary imagery | Type and build checks; existing live-player lazy loading retained |
| Backup | Sequential table reads could represent inconsistent database states | Transactional D1 batch snapshot, explicit confirmation validation | Authorization, origin, format and batch tests |
| Payment verification | Repeated and malformed requests reached verification logic | Per-user rate limit and strict reference/transaction validation | Invalid/foreign references and rate-limit tests; no provider request |

Screenshot: [mobile payment recovery](readiness/payment-retry-mobile.jpg).

## Validation

Commerce, media, operations, recovery and readiness automated suites passed. Fixtures verify server-side behavior, not real merchant transactions. TypeScript and deployment build are required before publication.

The isolated browser harness is retained under tests/visual-qa. To reproduce locally, temporarily copy readiness-page.tsx.txt to app/qa-readiness/page.tsx and readiness-width.html to public/qa-readiness-width.html. Start the managed preview and use its screen and width controls. Remove these temporary routes before building or publishing. Fixtures intercept requests only in this test document. They do not establish authentication or change real orders.

## Remaining launch gates

- Signed-in customer, seller and admin browser journeys need authorized test accounts and representative catalog/broadcast data. These screens remain unverified end to end.
- Configure transactional email and confirm verification/reset delivery with a real sender.
- Configure Flutterwave sandbox credentials; verify real sandbox success, failure, cancellation, duplicate webhooks and refunds before enabling merchant payments.
- Configure the streaming/media services; test actual broadcasting, reconnects, uploads and playback.
- Payment reservation reconciliation now runs in a throttled background sweep during traffic and through the Worker scheduled handler. Enable an operator cron for periods without traffic; verify actual provider results. Unknown/pending charges retain stock.
- Configure offsite database/media backups, perform a restoration drill and connect operational alerts.
- Public site access is preserved. Paid-launch readiness still depends on the service and operational gates above.

This build is ready for further testing, not certified ready to accept real customers and payments. No fabricated accounts, sales, viewers or payment outcomes were introduced.
