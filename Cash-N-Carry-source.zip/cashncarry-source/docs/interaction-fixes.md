# Cash N Carry interaction fixes and expanded QA — 7 October 2026

## Corrections

| Severity | Component | Reproduction | Correction | Verification |
|---|---|---|---|---|
| High | Navigation | Home → Shop → search → Live → Back | Push navigation entries, restore prior filters/search/page/tab, synchronise page and search URL | Real local app: Back restores marketplace and search; search from Live survives reload; clearing search stays cleared after reload |
| Medium | Filters | Change distance or clear device location, then dismiss | Radius and coordinates are drafted alongside other filters and committed only on Apply | Source checked; manual location Apply → Clear draft → dismiss retains Lagos. Actual device permission/coordinates not exercised |
| High | Cart | Open populated cart with long product name at 360px | Fixed image/remove columns, flexible name column, quantity controls below | 360/390/768/1440px; no dialog overflow; mobile screenshot |
| Medium | Checkout | Continue to checkout over local HTTP | Secure getRandomValues UUID fallback where randomUUID is unavailable | Browser opens checkout successfully; no insecure random source used |
| Medium | Checkout | Submit valid form to failing API | Persistent inline error near submit, retaining fields | Isolated fixture API rejects mutation; message remains in checkout |
| Medium | Seller videos | Products exist but none has a video | Explicit empty state and Manage products action | Source correction; Content tab previously rendered an empty inventory |
| Medium | Seller broadcasts | View a scheduled broadcast from a device in another timezone | Show Africa/Lagos time with WAT | Same conversion as viewer; viewer fixture displays 13:00 WAT for 12:00 UTC |

## Expanded browser coverage

Real production components were rendered in an isolated, temporary local QA route. Its fetch adapter supplied only test fixtures and blocked every API mutation. This is component/UI testing, **not authenticated end-to-end testing**. No accounts were impersonated on protected routes and no real API authentication was weakened. Temporary routes were removed before build/publication.

Widths: 360, 390, 768, 1440 CSS pixels. Scrollbar widths reduce some content viewports by 15px.

- Customer workspace: profile at all widths; Saved products, Addresses, Notifications, Delivery, Verification, Broadcasts, Support and Sales tabs inspected at desktop. Empty lists and delivery forms rendered.
- Seller Centre: overview with order and stock data at all widths; Store, Products, Orders, Live, Content, Ads, Analytics and Settings tabs inspected at mobile.
- AdminPanel: overview at all widths; Verification, Stores, Users, Products, Orders, Live, Ads, Reports and Audit log tabs inspected at desktop. Admin route/session guard remains outside this fixture test.
- Cart and checkout dialogs: all widths without horizontal overflow. Long product name, missing image, delivery fee, naira totals, required-field blocking, loading and API rejection checked at mobile.
- Marketplace: product/missing-image fixture, manual location filter draft cancellation.
- Live marketplace/viewer: scheduled fixture, WAT date, linked pinned product and disabled pre-live chat inspected at mobile. This does not test live provider playback.

All twenty width/component measurements (account, admin, seller, cart, checkout × four widths) had scrollWidth equal to clientWidth.

Screenshots: `interaction-fixes/cart-mobile.jpg`, `interaction-fixes/seller-mobile.jpg`. Both show local test records, not real operational statistics.

## Functional checks and remaining gates

The commerce, media, operations and recovery suites passed using isolated SQLite and explicit test identities. They exercise actual route logic for ownership, admin denial/approval, single-seller checkout, inventory races, cancellation/fulfilment, private verification documents, webhook verification/idempotency, failed payments/refunds, media ownership and backup restoration. Provider responses are fixtures; these are not actual Flutterwave transactions.

Still unverified end to end: real customer/seller/admin login sessions, email verification/reset delivery, browser successful order persistence, actual Flutterwave sandbox and refund requests, native live connection/playback and upload processing with configured provider services. Requires authorised sessions, configured transactional email/payment/streaming services and provider test credentials. Off-site backup and restoration remain launch gates. Do not treat component QA as clearance to accept real customers/payments.

## Repeat isolated UI QA

Copy `tests/visual-qa/fixture-page.tsx.txt` to temporary `app/qa-local/page.tsx` and `tests/visual-qa/width-harness.html` to temporary `public/qa-width.html`, run the managed preview and inspect `/qa-width.html`. The fixture adapter intercepts API requests only in that QA document and blocks mutations. Delete both temporary routes before building or publishing. Never use this harness to test authentication or actual payment success.
