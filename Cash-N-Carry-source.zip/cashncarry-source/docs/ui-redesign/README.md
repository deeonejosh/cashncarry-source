# Cash N Carry UI redesign — 10 October 2026

## Scope and rollback

Existing site: https://cashncarryng.com. No replacement application, schema changes, credentials, permission changes or payment-mode changes.

Rollback source: `b5501398faaad92bde20f710ca2b6bcbc7aaadf0`, retained locally as `rollback/ui-20261010`. Before implementation the public site was version 66. Version 67 published the first design pass successfully. The final refinement is recorded by the next saved version.

## Changes

- One shared premium presentation layer for typography, spacing, forms, cards, dashboard panels, tables, focus and reduced-motion behavior.
- Shopping opens directly; `/welcome` remains available separately.
- Mobile navigation: Home, Shop, Live, Cart, Account. Cart includes a quantity badge; customer pages share the same ordering.
- Desktop shopping search remains prominent; detail pages include a search destination.
- Compact homepage hero, early category discovery, honest live availability, product feed and real seller cards.
- Product imagery uses contain sizing; prices remain NGN. Product-card nationwide coverage is concise; details preserve complete coverage in expandable sections.
- Purchase controls precede delivery details. Desktop purchase panel remains in normal document flow to prevent overlap.
- Duplicate additional product photos are filtered in the product dialog.
- Inactive advertising drafts removed from primary seller/admin menus; backend, existing campaigns and direct draft pages preserved.
- Seller daily actions, admin navigation, filters and record menus retain behavior and permissions with refreshed shared styles.
- Storefront video/broadcast sections and links appear only when populated.
- Help topics use native accessible disclosure controls; support contact remains prominent.
- Portrait video and working live controls retained. Compact pin/button presentation refined without changing media logic.

## Page coverage

“Shared styling” means the existing page uses the new globally imported design layer; it does not mean authenticated interaction was tested.

| Existing page or surface | Implementation | Rendered verification |
|---|---|---|
| `/` homepage | Structure, categories, hero, seller discovery, navigation | Desktop inspected; direct entry verified |
| Shop/categories/search (`#market`, `#explore`) | Cards, filters, headings, categories | Category selection and empty search tested |
| Live discovery (`#live`) | Shared heading, tabs, controls | Navigation and honest empty state tested |
| Product dialog | Deduplicated images, expandable coverage, card/buttons | Opened; final refinement requires reinspection |
| `/product/[id]` | Shared layout and reordered purchase/coverage | Inspected; overlap found and repaired |
| `/store/[id]` | Cards/navigation; hides empty content | Inspected; final refinement requires reinspection |
| Cart/checkout dialogs | Shared form, item, total and action styles | Signed-in transaction journey not tested |
| `/payment-return` | Shared result card/actions | No transaction initiated |
| Orders (`#orders`), `/order/[id]` | Shared cards/actions; correct payment label | Authentication required |
| `/account` | Shared identity/menu/forms/navigation | Authentication required |
| `/workspace` profile, saved items, addresses, preferences, support | Shared dashboard/forms | Authentication required |
| `/seller`, seller overview/store/products/inventory/orders/videos/analytics | Shared panels/nav; simpler menus | Source inspected; authenticated rendering unverified |
| `/workspace?tab=Delivery` | Shared shipping forms/state selectors | Source inspected; authenticated rendering unverified |
| `/workspace?tab=Broadcasts` | Preserved portrait studio; shared presentation | Live device task unverified |
| `/workspace?tab=Verification`, `Sales` | Shared evidence/payment panels | Authentication required |
| Livestream viewer | Preserved portrait, rail, pin, composer | No available live stream for interaction test |
| `/admin` overview/customers/stores/verification/products/orders/payments/support/moderation/live/activity | Shared dashboard/sidebar/tables/menus | Admin/MFA session unavailable |
| `/admin/settings` | Shared directory/cards/forms | Admin/MFA session unavailable |
| `/admin/email-templates` | Shared workbench/log/table styles | Admin/MFA session unavailable; no emails sent |
| `/help` | Contact card and disclosure topics | Initial desktop layout inspected |
| `/policies/[id]` | Shared readable document layout | Legal text unchanged |
| `/sign-in`, `/sign-up`, `/forgot-password`, `/two-factor`, `/welcome` | Shared entry panels/forms/buttons | No account created or credentials entered |

## Evidence and limits

- TypeScript check passed.
- All 100 existing Node regression tests passed on the initial implementation, then passed again after menu/navigation refinements. Later presentation refinements receive a final build and type check.
- Production build passed; existing warning about chunks over 500 kB remains. No measured performance score is claimed.
- Desktop public browser viewport: 1363 px. Homepage document width 1348 px, no horizontal overflow observed.
- Public interactions: category selection, query with no matching product, live discovery, product dialog, standalone product link, seller storefront link, help navigation.
- Browser-only extension metadata errors were observed; they are not application errors.
- Responsive CSS includes phone <=767 px and tablet 768–1100 px. Mobile/tablet rendered testing is NOT complete: supported local preview/browser resizing is unavailable in this environment.
- Signed-in customer/seller/admin journeys, keyboard opening during live video, camera/microphone, multi-device live shopping and sandbox payment completion are NOT tested here. No production data changes, charges, refunds or messages were initiated during QA.

## Rating criteria

No certified final 0–10 scores are awarded. The requested scoring standard requires rendered mobile pages, authenticated tasks, representative users and independent evaluation, which this session cannot provide. Desktop inspection is evidence of improvement, not evidence of 100/100 usability.

| Category | Evidence | Remaining acceptance work |
|---|---|---|
| Visual design | Public desktop inspected | Inspect all authenticated surfaces |
| Navigation | Category/search/live/product/store tasks exercised | Mobile and role-specific tasks |
| Button placement | Product hierarchy repaired; cart tab implemented | Device touch and full form tasks |
| Mobile responsiveness | Responsive rules implemented | Actual phone/tablet rendered checks |
| Homepage usability | Direct entry/categories verified | Representative first-time user task |
| Product discovery | Search/category/store verified | Larger catalogue and filtering tasks |
| Checkout | Shared UI and backend regression tests | Signed-in sandbox checkout |
| Seller Centre | Shared implementation/source review | Seller account task completion |
| Livestream shopping | Existing regression tests and portrait preserved | Two devices and mobile keyboard |
| Admin portal | Shared implementation and guards preserved | Authorised MFA admin task completion |

## Remaining issues

- Existing catalogue content calls a pictured microphone “Headset”; owner must correct the factual listing.
- Nationwide fee remains owner-requested ₦100; fulfillment economics and delivery estimates require operational confirmation.
- Actual business identity/policy approval, monitored support address and verified live payment readiness remain separate launch prerequisites.
- Global legacy styles remain, with a final shared presentation layer. Consolidating the earlier CSS files further should follow authenticated visual coverage to avoid regressions.

## Modified source files

`app/premium.css`, `app/layout.tsx`, `app/customer-shell.tsx`, `app/welcome.tsx`, `app/revibe.tsx`, `app/admin/panel.tsx`, `app/product/[id]/page.tsx`, `app/store/[id]/page.tsx`, `app/help/page.tsx`.

Baseline screenshot: [before-home.jpg](before-home.jpg).
