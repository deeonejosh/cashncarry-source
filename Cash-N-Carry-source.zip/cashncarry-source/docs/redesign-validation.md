# Cash N Carry redesign and verification

Implemented 7 October 2026. Cash N Carry — Watch Live. Discover. Shop.

## What changed

The existing working application now uses a warm cream background, forest-green primary controls, terracotta accents, ochre highlights and small indigo geometric banner-edge details. CSS design tokens apply across customer, seller and administrator screens. Headings use expressive system serif typography; forms and shopping content retain readable system sans-serif text.

A reusable shopping hero, category section and seller invitation complement the redesigned header. Search and location are near the top; desktop navigation offers Live, Shop and Sell, and mobile navigation offers Home, Live, Shop and Account. Create, seller tools and order history remain available from the account menu. Notifications and support links open their corresponding workspace tabs after authentication.

The homepage includes the requested exact hero copy, active live previews or a truthful empty state, local product discovery, category selection and seller invitation. Scheduled broadcasts and replays remain on the Live page rather than appearing as currently live. There are no fabricated sellers, reviews, viewers or verification claims.

Product cards now offer a separate save action and distinguish seller location from delivery coverage. Existing platform records supply listings and prices. The requested Electronics category maps to the existing Tech value; Bags searches the existing Fashion category for bags. Existing categories remain available, and no stored category values were renamed.

Product pages show a photo gallery, description, prices, stock, available variants, storefront, seller location, coverage, delivery fee/estimate and returns. The existing product-options purchase journey remains intact. Variants without stock cannot be selected and add-to-cart waits for an available option. Checkout shows the total including the seller's delivery fee before submission. Existing entered form values remain mounted after recoverable errors.

Desktop broadcast viewing places the video beside product information and chat; mobile places the purchase area below the video. Chat and product details collapse independently. Variant selection, delivery details and adding to cart stay within the broadcast. Scheduled time includes Nigeria's WAT timezone. Existing ended, failed-media and retry states remain functional. Large details can require vertical scrolling, especially on mobile.

## Assets

`public/seller-hero.webp` is an original AI-generated illustrative scene, not a photograph of a verified Cash N Carry seller. Its accessible description says illustrative. The final optimized image is approximately 80KB and does not autoplay. Product/category imagery comes from actual catalogue records, with a truthful missing-photo fallback; empty categories use simple icons. No third-party stock photograph was copied. The supplied external visual-reference image was not visible in this Codex thread; implementation follows the written direction.

Final homepage screenshots: [desktop](redesign/desktop.jpg) and [mobile](redesign/mobile.jpg).

## Browser verification

Actual local application routes were rendered in responsive browser frames at 360, 390, 768 and 1440 CSS pixels. Frame scrollbars can reduce content width by 15px. [Recorded measurements](redesign/widths.json) cover 28 route/dialog-width combinations; scroll width equalled available width in each. Screenshots show the surrounding local test surface, which may be narrower than a 1440px frame. Horizontal scrolling of that outer test surface is not page overflow.

| Surface/journey | Browser verification | Result/limit |
|---|---|---|
| Home | All four widths, loading/empty-live states, hero and navigation | Fit without page overflow; mobile uses four requested destinations. |
| Marketplace | All four widths, search, empty results, clear filters, category selection | Working rendered responses; category-only empty results corrected to offer Clear filters. |
| Location/filter sheet | All four widths; manual location, located/delivers distinction, Apply and Clear | Ogun delivery finds Lagos seller coverage; Ogun seller-location correctly produces no matches. Device permission was not requested during QA. |
| Product page | All four widths; long unbroken name, large price and missing images | Two-column desktop/one-column phone layout fits; available options and delivery/returns visible. |
| Product dialog | 360px; choice-dependent disabled/enabled state, Shift+Tab focus wrap and Escape | Correct UI response. No authenticated cart mutation performed. |
| Seller storefront | All four widths | Rendered public storefront fits. |
| Account entry | All four widths; mobile account menu | Entry/menu fit; authenticated account data and credential workflows not exercised. |
| Scheduled viewer | All four widths; long pin, variants, details and chat collapse | [Desktop evidence](redesign/live-desktop.jpg), [mobile purchase-panel evidence](redesign/live-mobile.jpg). Fields fit. No live provider connection established. |
| Replay failure | 360px; Retry video, disabled ended-stream chat | Honest error/retry state; deliberately invalid test media does not play. |
| Workspace | 390px notification entry | Correct sign-in boundary, no nested-hook runtime error. Protected workspace remains untested. |
| Enlarged text | Controlled 200% computed-text stress at 390px | Fixed logo/notification overlap; brand boundary ends before notification control and body fits. This is not native device zoom or assistive-technology certification. |
| Cart, checkout, orders, seller/admin operational screens | Source review plus existing backend regression tests | No authorised browser session; rendered protected interactions remain untested. |

Temporary QA records were explicitly named fixtures and existed only in the local preview database. They exercised stock zero, missing images, ₦99,999,999, variants and unavailable replay media. The records and test harness were removed before packaging; no production accounts, products, orders, migrations or integrations were replaced.

## Checks and limitations

Commerce, media, operations and recovery regression suites passed. Publication also runs TypeScript and the production build. The existing large-client-chunk build warning remains a performance follow-up. This document records local browser QA, not production traffic or real provider verification.

Signed-in cart, checkout, saved products, seller and admin interactions need authorised browser test accounts. Real Flutterwave, native broadcast, email and upload provider journeys remain configuration/credential gated. Native keyboards, device safe areas, full screen-reader/contrast certification and mobile network performance remain untested. Policies still require the owner's business/legal review. The site is ready for further testing; this redesign alone does not establish readiness for real customers/payments.
