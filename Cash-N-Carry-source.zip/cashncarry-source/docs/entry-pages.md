# Welcome and account pages

Cash N Carry — Watch Live. Discover. Shop.

The supplied references are implemented as real responsive components, with the existing transparent logo, cream/forest-green/terracotta palette, subtle indigo corner patterns and optimised Nigerian seller imagery reused from the site. No reference screenshots are used as pages.

## Routes and behaviour

- `/`: first unsigned visit without query/hash shows welcome. Get Started remembers the choice in localStorage and opens `/?browse=1#market`; returning visitors enter the shopping homepage. Signed-in users bypass welcome. A storage restriction does not prevent browsing.
- `/welcome`: explicitly opens welcome.
- `/sign-up`: ordinary customer registration, required name/email/password/Terms, linked Privacy Notice, submission lock, timeout and errors. Backend validates acceptance and strips unrequested role/seller fields before forwarding to existing Better Auth. Seller application and admin assignment paths are unchanged.
- `/sign-in`: existing email authentication, password visibility, forgot-password link and validated internal return destination. Existing ChatGPT sign-in remains available; no new social provider is introduced.
- `/forgot-password`: existing reset-request endpoint.
- `/account`: existing route preserved for email reset tokens, legacy registration query and session management. Invalid/expired link query opens reset guidance. Session list/revocation retained under a disclosure.

Password minimum is 12 characters, shared with the existing backend configuration. Sign-in does not impose a new minimum on an existing password. Password managers, autofill and pasting remain supported. Sign-in does not require agreement acceptance. Registration remains email-verification gated.

Shopping links retain their query/hash, while product/store/order and payment-return routes remain outside the homepage welcome gate. The cart tables and APIs are unchanged. Signup does not create a public admin or auto-approve sellers.

## Verification completed

- Browser: initial welcome, Get Started → marketplace, returning homepage, empty signup/sign-in validation, show/hide control without entering credentials, forgot-password navigation, expired-reset guidance with retained order destination, callback bypass.
- Layout: 360px welcome/signup, 390px sign-in, 768px signup and 1440px sign-in; body client/scroll widths matched at each checked width, with scrollable pages and no fixed form actions.
- Automated: safe return paths reject external/protocol-relative/backslash/control-character/auth-loop paths; signup requires Terms and password minimum, strips role fields, restricts verification callbacks, and reports missing service. Commerce regression suite passed including cart, authorization and inventory cases. Provider payment outcomes in that suite are fixtures.
- TypeScript and deployment build required before publication.

## Blocked or untested

Real registration, verification-email delivery, correct/incorrect credential login, password-reset delivery/completion, sign-out, signed-in protected pages and cart preservation across a real session need configured services and authorized accounts. No real users, passwords or account records were created or changed during QA. Mobile widths were tested in browser iframes; native phone keyboard behaviour and password-manager behaviour remain untested.

Required email-auth configuration: `BETTER_AUTH_SECRET`, `SITE_URL` matching the deployed HTTPS origin, `RESEND_API_KEY`, `EMAIL_FROM` with a verified sender, and the existing migrated D1 `DB`. Configure these securely, then perform the blocked journeys before calling email accounts launch-ready. Cart data is preserved in source and regression tests; real authenticated browser preservation is not claimed.

Temporary width harness is stored in tests/visual-qa/entry-width.html for local reproduction; copy to public/qa-entry.html only during testing and remove before publishing.
