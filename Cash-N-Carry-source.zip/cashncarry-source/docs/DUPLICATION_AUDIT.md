# Cash N Carry duplication cleanup

Baseline: version 94. Source inventory covers every discovered page and handler, plus conditional marketplace screens and role-specific tabs. This is source and regression evidence, not a complete authenticated rendered-page audit.

## Confirmed issues and fixes

| Page / feature | Original duplication or defect | Severity | Action taken | Verification |
|---|---|---|---|---|
| My Account | Name card and Account settings row reached the same editor; requested name-overview behaviour was unclear | Medium | Non-editing summary with one explicit Edit Profile link; retain the single workspace editing component | TypeScript/build; source confirms one editor import/render |
| Seller Products / Content | Header Add Product and section Add Product repeated the same modal action | Low | Retain the primary header action and remove section duplicate | Source inspection; production build |
| Admin verification | Two queues maintained separate decision UI and handler logic | High | Both entry points render the same review panel; both API endpoints call one review function; legacy URLs retained | Approval, permission and concurrent review regression tests |
| Workspace verification | Old upload event handler remained after form consolidation | Low | Remove unreferenced handler; keep canonical verification upload form | TypeScript/build; reference search |
| Bank account submission | Check-then-insert allowed simultaneous saves to create the same account twice; legacy resolution also reinserted accounts | High | Database insert guard; existing record reused; retry conflict returns existing account | New migration tests preserve records and reject duplicate insert; existing bank/privacy tests |
| Verification submission | Pending check before upload did not atomically prevent two pending inserts | High | Database insert guard rejects a second pending application; existing upload cleanup removes an unsuccessful orphan upload | New pending-insert/history regression test |
| Verification history | Older more-information request could be reviewed after a newer decision; latest-state queries used inconsistent tie ordering | High | Latest-request review guard and consistent created/rowid ordering; historical evidence retained | New historical-review test and full suite |

Total: 7 confirmed source-level issues addressed. No existing production duplicate record count is inferred from these race conditions. No historical record was deleted or merged.

## Canonical destinations

| Task | Destination |
|---|---|
| Account overview | /account |
| Edit profile and private account settings | /workspace?tab=Account |
| Seller dashboard | /seller |
| Product management | /?browse=1&sellerTab=Products#seller |
| Seller orders | /?browse=1&sellerTab=Orders#seller |
| Livestream studio | /workspace?tab=Broadcasts |
| Identity documents | /seller/finance?tab=Activation |
| Subscription and renewal | /seller/finance?tab=Subscription |
| Earnings | /seller/finance?tab=Earnings |
| Withdrawals | /seller/finance?tab=Withdrawals |
| Bank accounts | /seller/finance?tab=Bank%20account |
| Financial history | /seller/finance?tab=History |
| Seller identity review | /admin?tab=Verification (shared review panel) |

## Intentional repetition retained

Mobile and desktop navigation share destinations but are mutually hidden at their breakpoints. Useful shortcuts point to canonical tasks. Public seller storefronts and private account settings are different functions. Buyer payments and seller subscription payments represent different transactions. Earnings summary cards reuse the server calculation rather than creating balances. Public policy aliases render the published source rather than copying policy records. Order quantities and product variants remain valid separate selections. Existing cart, order, payment/webhook and withdrawal idempotency protections remain in place and covered by regression fixtures.

## Database boundaries

Migration 0019 adds two future-insert triggers only. It does not delete, merge, relabel or alter stored identity evidence, banking information, orders, payments, withdrawals or audit history. Existing duplicate history is left intact. No subscription price, fees, payout eligibility, legal publication or live-payment configuration changes. Concurrent review responses retain HTTP 409.

## Validation and limits

TypeScript and the full automated suite passed before packaging. New tests cover duplicate pending inserts, bank duplicates/history preservation, and historical identity decisions. Existing tests cover profile, role permissions/MFA, checkout, cart inventory, subscriptions, withdrawal reservations/reconciliation, private attachments and streaming lifecycle fixtures. Build and deployment result will be reported separately.

Desktop/mobile rendered checks, navigation interaction on every protected page, actual provider requests and representative device testing remain unverified: no authorised browser role sessions were available. No before/after screenshots of changed authenticated screens are available; unrelated public screenshots are not presented as evidence. Source breakpoint review is not a physical-device result. Remaining high-priority QA: signed-in profile saving, both admin entry points, mobile Add Product/navigation, real bank detail capture and complete sandbox buyer/seller/admin tasks.

## Complete route inventory

27 page routes and 34 request-handler routes (61 total). Route aliases and hash/tab states are additional interface states, not counted as separate files.

| Route | Kind |
|---|---|
| `/account` | Page |
| `/admin/email-templates` | Page |
| `/admin` | Page |
| `/admin/settings` | Page |
| `/community-guidelines` | Page |
| `/delivery` | Page |
| `/forgot-password` | Page |
| `/help` | Page |
| `/messages` | Page |
| `/order/[id]` | Page |
| `/` | Page |
| `/payment-return` | Page |
| `/policies/[id]` | Page |
| `/privacy` | Page |
| `/product/[id]` | Page |
| `/refunds` | Page |
| `/seller/billing-return` | Page |
| `/seller/finance` | Page |
| `/seller` | Page |
| `/seller-terms` | Page |
| `/sign-in` | Page |
| `/sign-up` | Page |
| `/store/[id]` | Page |
| `/terms` | Page |
| `/two-factor` | Page |
| `/welcome` | Page |
| `/workspace` | Page |
| `/.well-known/assetlinks.json` | Handler |
| `/api/admin/access` | Handler |
| `/api/admin/backup` | Handler |
| `/api/admin/email` | Handler |
| `/api/admin/email-templates` | Handler |
| `/api/admin/finance` | Handler |
| `/api/admin/policies` | Handler |
| `/api/admin` | Handler |
| `/api/admin/seller-finance` | Handler |
| `/api/admin/settings` | Handler |
| `/api/admin/streaming` | Handler |
| `/api/ads-events` | Handler |
| `/api/auth/[...all]` | Handler |
| `/api/brand-icon` | Handler |
| `/api/catalog` | Handler |
| `/api/commerce` | Handler |
| `/api/emails/webhook` | Handler |
| `/api/live-presence` | Handler |
| `/api/maintenance` | Handler |
| `/api/manifest` | Handler |
| `/api/media/[key]` | Handler |
| `/api/media` | Handler |
| `/api/messages/attachment/[id]` | Handler |
| `/api/messages` | Handler |
| `/api/orders/receipt` | Handler |
| `/api/payments/verify` | Handler |
| `/api/payments/webhook` | Handler |
| `/api/policies/terms` | Handler |
| `/api/seller-finance` | Handler |
| `/api/streams` | Handler |
| `/api/verification` | Handler |
| `/llms.txt` | Handler |
| `/robots.txt` | Handler |
| `/sitemap.xml` | Handler |
