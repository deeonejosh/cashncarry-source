# Sandbox cancellation error handling

An authenticated sandbox lookup using a fresh diagnostic reference returned HTTP 400, `status: error`, `message: No transaction was found for this id`. The application previously labelled every unsuccessful Flutterwave response as a provider outage. Production error logs returned no events for the reported screenshot, so the specific order's response was not independently established.

Changes:
- Separate a missing transaction, provider rejection, and upstream outage without exposing provider response bodies or secrets.
- Query transaction status before disabling a checkout link. Missing or processing transactions preserve the usable link.
- Require a positive link-disable acknowledgement before verifying a failed/cancelled transaction again and releasing stock.
- Explain payment uncertainty in the cancellation confirmation.
- Use Flutterwave Standard's singular `configuration` parameter for session duration and retry limits.

Verification: automated SQLite/provider-fixture tests cover missing transactions, processing transactions, unconfirmed link closure, provider rejection and outage, verified failure, success, and concurrent settlement. The real sandbox diagnostic was read-only and did not complete a payment.

Remaining limitation: a missing transaction is not proof that no payment can settle. Cancellation remains blocked while its outcome is uncertain. Legacy orders with missing or already disabled links, or expired sessions, require provider reconciliation by an authorised operator. End-to-end successful payment and webhook receipt remain launch gates. Do not represent these cases as safely cancelled or release inventory based on absence of a transaction alone.
