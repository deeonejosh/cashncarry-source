# Cash N Carry Seller Centre & Admin Console Audit

**Audit date:** 18 October 2026  
**Source checkout:** `cashncarry-site-sync`, starting revision `39890f6`  
**Production deployment:** None. The requested audit fixes remain in the local development checkout.  
**Evidence level:** Mixed: source and isolated automated tests, plus read-only live UI checks. This is not a claim that every authenticated workflow or control has been exercised.

## Executive result

- Inspected the live Seller Centre dashboard, product list, My Website page, Product Videos page, Add Product form, and Admin Console dashboard and sampled tabs.
- Read-only actions only on the live site. No product, store, order, video, payment, seller, or moderation data was submitted or changed.
- Fixed one seller-state defect in the local source: suspended sellers with an existing store no longer receive the “Create Your Free Store” flow; they see “Manage My Store,” the suspension state, and a seller-status link. 
- Added a regression test rendering the suspended state. Full suite: **241 passed, 0 failed**. Build completed successfully with a large-chunk warning.
- Full lint remains a release blocker: the repository-wide command reports **992 errors and 86 warnings** (mostly existing violations across the project). The edited `builder.tsx` already contains 15 `no-explicit-any` errors and two warnings; the new server page and regression test pass focused lint.
- The existing session loaded the Admin Console after its initial loading state. Seller verification, buyer management, products, videos, livestreams, orders, disputes, payment monitoring, subscriptions/payouts and dashboard were inspected read-only. No admin mutation was performed.

## Live UI checks

| Page / control | Expected behaviour | Observed behaviour | Status | Retest |
|---|---|---|---|---|
| Seller dashboard | Show seller overview and navigation | Dashboard rendered with seller subscription, verification, earnings summary, order cards, website link, and quick actions | PASS — visual/AX inspection only | Read-only |
| Dashboard “Add a product” | Open a product form | Opened “List a product” with name, SKU, description, price, stock, category, product media and save control | PASS — open/close only | Closed without saving |
| Seller product list | Show catalogue actions | Product rows rendered with Edit and Archive; Bulk upload shortcut visible; Add a product remains available in the dashboard header | PASS — visibility only | No row mutation |
| Seller navigation | Provide destinations for seller tools | Dashboard, Products, Bulk Product Upload, Orders, Storefront, My Website, Shipping, Product Videos, Bundles, Live Studio, finance, growth and account links present | PARTIAL — destination pages not all opened | No submissions |
| Seller Centre → My Website | Create one custom store if none exists; manage an existing storefront | Current account displays “Create Your Free Store” with draft/publish form because no custom storefront is present | PASS — state observed; form actions not submitted | No write |
| Seller Centre → Product Videos | Upload once, tag products, draft/publish through moderation | Empty-video state displayed; video and optional thumbnail upload, caption, hashtags, product tagging, Save Draft and Publish for Review controls were visible | PARTIAL — no upload attempted | No write |
| Admin Console | Require an authorised admin session | Dashboard and sampled tabs loaded after an initial loading state; footer still claimed access was restricted | PARTIAL — read-only screens and control labels inspected; write actions not tested | No privileged operation |

Desktop screenshots were displayed during the audit session. Admin and seller screens contained customer/seller account details, so screenshots are not embedded or saved in the report. No mobile screenshot was captured.

## Complete source route inventory

The project contains **38 page route files** and **40 API route files**. “Source inventory” does not mean the route was visited or its controls were tested.

### Page routes

| Route | Source file | Evidence status |
|---|---|---|
| `/account` | `app/account/page.tsx` | Source inventory; runtime status varies by scope below |
| `/admin/competitive` | `app/admin/competitive/page.tsx` | Source inventory; runtime status varies by scope below |
| `/admin/email-templates` | `app/admin/email-templates/page.tsx` | Source inventory; runtime status varies by scope below |
| `/admin` | `app/admin/page.tsx` | Source inventory; runtime status varies by scope below |
| `/admin/settings` | `app/admin/settings/page.tsx` | Source inventory; runtime status varies by scope below |
| `/community-guidelines` | `app/community-guidelines/page.tsx` | Source inventory; runtime status varies by scope below |
| `/creator` | `app/creator/page.tsx` | Source inventory; runtime status varies by scope below |
| `/delivery` | `app/delivery/page.tsx` | Source inventory; runtime status varies by scope below |
| `/for-you` | `app/for-you/page.tsx` | Source inventory; runtime status varies by scope below |
| `/forgot-password` | `app/forgot-password/page.tsx` | Source inventory; runtime status varies by scope below |
| `/help` | `app/help/page.tsx` | Source inventory; runtime status varies by scope below |
| `/live` | `app/live/page.tsx` | Source inventory; runtime status varies by scope below |
| `/live-auctions` | `app/live-auctions/page.tsx` | Source inventory; runtime status varies by scope below |
| `/messages` | `app/messages/page.tsx` | Source inventory; runtime status varies by scope below |
| `/order/[id]` | `app/order/[id]/page.tsx` | Source inventory; runtime status varies by scope below |
| `/page.tsx` | `app/page.tsx` | Source inventory; runtime status varies by scope below |
| `/payment-return` | `app/payment-return/page.tsx` | Source inventory; runtime status varies by scope below |
| `/policies/[id]` | `app/policies/[id]/page.tsx` | Source inventory; runtime status varies by scope below |
| `/privacy` | `app/privacy/page.tsx` | Source inventory; runtime status varies by scope below |
| `/product/[id]` | `app/product/[id]/page.tsx` | Source inventory; runtime status varies by scope below |
| `/refunds` | `app/refunds/page.tsx` | Source inventory; runtime status varies by scope below |
| `/seller/billing-return` | `app/seller/billing-return/page.tsx` | Source inventory; runtime status varies by scope below |
| `/seller/bulk-upload` | `app/seller/bulk-upload/page.tsx` | Source inventory; runtime status varies by scope below |
| `/seller/competitive` | `app/seller/competitive/page.tsx` | Source inventory; runtime status varies by scope below |
| `/seller/finance` | `app/seller/finance/page.tsx` | Source inventory; runtime status varies by scope below |
| `/seller` | `app/seller/page.tsx` | Source inventory; runtime status varies by scope below |
| `/seller/videos` | `app/seller/videos/page.tsx` | Source inventory; runtime status varies by scope below |
| `/seller/website` | `app/seller/website/page.tsx` | Source inventory; runtime status varies by scope below |
| `/seller-terms` | `app/seller-terms/page.tsx` | Source inventory; runtime status varies by scope below |
| `/sign-in` | `app/sign-in/page.tsx` | Source inventory; runtime status varies by scope below |
| `/sign-up` | `app/sign-up/page.tsx` | Source inventory; runtime status varies by scope below |
| `/social` | `app/social/page.tsx` | Source inventory; runtime status varies by scope below |
| `/start-selling` | `app/start-selling/page.tsx` | Source inventory; runtime status varies by scope below |
| `/store/[id]` | `app/store/[id]/page.tsx` | Source inventory; runtime status varies by scope below |
| `/terms` | `app/terms/page.tsx` | Source inventory; runtime status varies by scope below |
| `/two-factor` | `app/two-factor/page.tsx` | Source inventory; runtime status varies by scope below |
| `/welcome` | `app/welcome/page.tsx` | Source inventory; runtime status varies by scope below |
| `/workspace` | `app/workspace/page.tsx` | Source inventory; runtime status varies by scope below |

### API route files

| Endpoint | Source file | Evidence status |
|---|---|---|
| `/admin/access` | `app/api/admin/access/route.ts` | Source inventory; individual live calls not tested |
| `/admin/backup` | `app/api/admin/backup/route.ts` | Source inventory; individual live calls not tested |
| `/admin/competitive` | `app/api/admin/competitive/route.ts` | Source inventory; individual live calls not tested |
| `/admin/email` | `app/api/admin/email/route.ts` | Source inventory; individual live calls not tested |
| `/admin/email-templates` | `app/api/admin/email-templates/route.ts` | Source inventory; individual live calls not tested |
| `/admin/finance` | `app/api/admin/finance/route.ts` | Source inventory; individual live calls not tested |
| `/admin/policies` | `app/api/admin/policies/route.ts` | Source inventory; individual live calls not tested |
| `/admin` | `app/api/admin/route.ts` | Source inventory; individual live calls not tested |
| `/admin/seller-finance` | `app/api/admin/seller-finance/route.ts` | Source inventory; individual live calls not tested |
| `/admin/settings` | `app/api/admin/settings/route.ts` | Source inventory; individual live calls not tested |
| `/admin/streaming` | `app/api/admin/streaming/route.ts` | Source inventory; individual live calls not tested |
| `/ads-events` | `app/api/ads-events/route.ts` | Source inventory; individual live calls not tested |
| `/affiliate` | `app/api/affiliate/route.ts` | Source inventory; individual live calls not tested |
| `/auth/[...all]` | `app/api/auth/[...all]/route.ts` | Source inventory; individual live calls not tested |
| `/brand-icon` | `app/api/brand-icon/route.ts` | Source inventory; individual live calls not tested |
| `/catalog` | `app/api/catalog/route.ts` | Source inventory; individual live calls not tested |
| `/commerce` | `app/api/commerce/route.ts` | Source inventory; individual live calls not tested |
| `/emails/webhook` | `app/api/emails/webhook/route.ts` | Source inventory; individual live calls not tested |
| `/founding-sellers` | `app/api/founding-sellers/route.ts` | Source inventory; individual live calls not tested |
| `/live-auctions` | `app/api/live-auctions/route.ts` | Source inventory; individual live calls not tested |
| `/live-deals` | `app/api/live-deals/route.ts` | Source inventory; individual live calls not tested |
| `/live-presence` | `app/api/live-presence/route.ts` | Source inventory; individual live calls not tested |
| `/maintenance` | `app/api/maintenance/route.ts` | Source inventory; individual live calls not tested |
| `/manifest` | `app/api/manifest/route.ts` | Source inventory; individual live calls not tested |
| `/media/[key]` | `app/api/media/[key]/route.ts` | Source inventory; individual live calls not tested |
| `/media` | `app/api/media/route.ts` | Source inventory; individual live calls not tested |
| `/messages/attachment/[id]` | `app/api/messages/attachment/[id]/route.ts` | Source inventory; individual live calls not tested |
| `/messages` | `app/api/messages/route.ts` | Source inventory; individual live calls not tested |
| `/orders/receipt` | `app/api/orders/receipt/route.ts` | Source inventory; individual live calls not tested |
| `/payments/verify` | `app/api/payments/verify/route.ts` | Source inventory; individual live calls not tested |
| `/payments/webhook` | `app/api/payments/webhook/route.ts` | Source inventory; individual live calls not tested |
| `/policies/terms` | `app/api/policies/terms/route.ts` | Source inventory; individual live calls not tested |
| `/product-bundles` | `app/api/product-bundles/route.ts` | Source inventory; individual live calls not tested |
| `/seller/bulk-products` | `app/api/seller/bulk-products/route.ts` | Source inventory; individual live calls not tested |
| `/seller-analytics` | `app/api/seller-analytics/route.ts` | Source inventory; individual live calls not tested |
| `/seller-finance` | `app/api/seller-finance/route.ts` | Source inventory; individual live calls not tested |
| `/storefront` | `app/api/storefront/route.ts` | Source inventory; individual live calls not tested |
| `/streams` | `app/api/streams/route.ts` | Source inventory; individual live calls not tested |
| `/verification` | `app/api/verification/route.ts` | Source inventory; individual live calls not tested |
| `/videos` | `app/api/videos/route.ts` | Source inventory; individual live calls not tested |

### Admin Console tabs found in source

Dashboard/Overview; Seller Subscriptions & Payouts; Payment monitoring; Orders; Disputes & support; Seller verification; Seller & storefront management; Buyer management; Product management; Video moderation; Livestream management; Advertising drafts; Reports & moderation; Audit logs. Admin subpages also include competitive feature management, email templates and settings. Live operation of those tabs remains untested because the session is not an administrator.

### Seller navigation groups found in source

Overview; Selling (Products, Bulk Product Upload, Orders, Storefront, My Website, Shipping, Product Videos, Bundles); Livestream (Studio, Scheduled Lives, Live Deals, Auctions); Growth (Analytics, Affiliates, Founding Seller); Customers (Messages); Finances (Earnings, Withdrawals, Transactions); Account (Verification, Subscription, Bank accounts, Settings).

## Button and control register (observed subset)

| Page | Element | Expected behaviour | Actual behaviour | Duplicate? | Status | Fix | Retest result |
|---|---|---|---|---|---|---|---|
| Seller dashboard | Add a product | Open product creation form | Opened form without submitting | No | PASS — open only | None | Closed successfully |
| Seller dashboard | View storefront | Open seller storefront | Visible; not clicked | No | NOT TESTED | — | — |
| Seller dashboard | Manage My Store | Open My Website | Visible as a contextual shortcut; page also appears in sidebar | Useful shortcut retained | PASS — visibility | None | Route loaded separately |
| Seller navigation | Products | Open product workspace | Product list loaded via route | Navigation link and dashboard quick action are separate contexts | PASS — route | None | Product list visible |
| Seller product list | Bulk upload | Open spreadsheet import | Visible; not clicked | Sidebar contains the same destination as a contextual shortcut | KEEP — useful shortcut | None | NOT TESTED |
| Seller product row | Edit / Archive | Edit or archive only selected item | Visible on rows; not clicked | One pair per product is contextual, not duplicate UI | NOT TESTED | — | — |
| My Website | Save Draft / Publish Website | Persist draft or publish website | Visible; not clicked | Different actions | NOT TESTED | — | — |
| Product Videos | Save Draft / Publish for review | Save draft or submit for moderation | Visible; not clicked | Different actions | NOT TESTED | — | — |
| Admin Console | Refresh back office | Reload authorised admin data | Enabled after dashboard data loaded | No | NOT TESTED — read-only control not clicked | — | — |

This register covers observed controls only. It does not represent every interactive control in the application. No click/save/delete/approve/reject/upload/payment action was performed against production.

## Duplicate control and functionality review

- **Confirmed unnecessary duplicate controls in observed pages:** 0.
- **Duplicates safely consolidated:** 0.
- The Dashboard “Add a product” and Products sidebar destination are retained as a useful quick action plus navigation entry.
- Dashboard “Manage My Store” and sidebar “My Website” are retained as a contextual shortcut plus navigation entry.
- Bulk upload appears as both a sidebar route and a product-list shortcut. Retained as contextual access; both lead to one upload page.
- The Create/Manage website copy uses mutually exclusive branches. A suspended existing seller record is now explicitly handled in development.
- Functionality deduplication beyond static source review was not exhaustively verified.

## Forms and workflows

- Add Product form labels and the upload/options loading area were observed. Required/invalid submission, upload failures, persistence and duplicate submission were not tested on production.
- Website identity, logo/banner, slug, template, accent, featured products, Save Draft and Publish controls are present in source and visible in the live form. No store changes were submitted.
- Video upload, optional thumbnail, caption, hashtags, product tags, progress/error states, draft and moderation submission are present. No video was uploaded.
- Orders, refunds, subscription, seller verification, livestream, and admin review workflows were not run against live records.

## API, database, security and reliability evidence

- Source inspection identified **40 API route files**, **38 page route files**, SQLite/Drizzle schema and 24 migration files in the checked-out app.
- The isolated automated suite covers duplicate submission protections, database uniqueness, order retry/atomicity, seller ownership checks, moderator/admin permission gates, MFA, storefront ownership/slug uniqueness, video moderation visibility, media validation, streaming recovery and other flows.
- Role-controlled admin access was exercised through the existing session; no role was granted, changed or bypassed. Admin tabs were read-only.
- API persistence and database behaviour were verified by tests using in-memory SQLite fixtures, not by writing to production.
- Production logs, real database contents, provider webhook delivery, live payment billing, and seller payouts were not inspected or changed.

## Performance and responsive checks

- Local production build passed. Vite emitted a warning for chunks above 500 KB. Largest output assets included the HLS player chunk (**575,178 bytes**) and spreadsheet chunk (**487,314 bytes**); HLS is dynamically imported for browsers that need HLS.js. These are emitted chunk sizes, not measured initial page transfer or Core Web Vitals.
- No Lighthouse, Core Web Vitals, API latency, database timing, or before/after runtime benchmark was recorded.
- Live desktop viewport: observed. Mobile breakpoints 320–430 px, tablet/desktop width matrix, Android Chrome, Samsung Internet, iPhone Safari and keyboard/screen-reader journeys were not run.
- Visual inspection and the accessibility tree showed named controls on sampled pages. This is not a full accessibility conformance test.

## Automated verification

| Check | Result |
|---|---|
| `pnpm test` | PASS — 241 tests, 241 passed, 0 failed, isolated test fixtures |
| `pnpm build` | PASS — production build completed; route manifest emitted; large-chunk warning remains |
| Focused ESLint: `app/seller/website/page.tsx` and the two new regression tests | PASS |
| `pnpm lint` | FAIL — 992 errors, 86 warnings across the repository; broad cleanup is not included in this targeted fix |
| Manual live read-only UI checks | Partial; see register |

## Defect register

| ID | Page | Element / issue | Severity | Reproduction / cause | Fix | Status / retest |
|---|---|---|---|---|---|---|
| CNC-SELLER-001 | Seller Centre → My Website | A suspended existing seller store was filtered out by the page’s `suspended=0` lookup, making the UI offer “Create Your Free Store” while the API rejects creation for suspended stores. | Medium | Source-level branch mismatch; reproduced as a state case using a React SSR regression test. No production record was changed. | Query the owned store including suspension state; show “Manage My Store,” suspension notice and seller-status link. | FIXED AND VERIFIED — regression test passes; build passes. Not deployed. |
| CNC-ADMIN-001 | Admin Console footer | The footer said “Restricted administrator access” while an authorised admin dashboard and tabs were loaded. | Low | Reproduced live after the admin dashboard finished loading. | Reworded to “Access is role controlled.” | FIXED AND VERIFIED — copy regression test passes; full build passes. Not deployed. |

No other defect is marked fixed or confirmed from the sampled live evidence. Observed controls not clicked are recorded as NOT TESTED.

## Scores and production readiness

| Score | Result |
|---|---|
| Seller Centre | Not scored — many pages/workflows, mobile breakpoints and write paths remain untested |
| Admin Console | Not scored — write paths, all tabs and mobile behaviour were not fully tested |
| Combined dashboard | Not scored — required evidence is incomplete |
| Before/after score | Not available — no full baseline scoring run was performed |

**Production readiness: Not approved by this audit.** The targeted local fix is verified, but release readiness is blocked by the full-lint failure and the untested authenticated mobile, upload, livestream and admin write workflows. No deployment was performed.

## Changed source files

- `app/seller/website/page.tsx`
- `app/seller/website/builder.tsx`
- `tests/seller-website-state.test.mjs`
- `tests/admin-console-label.test.mjs`
