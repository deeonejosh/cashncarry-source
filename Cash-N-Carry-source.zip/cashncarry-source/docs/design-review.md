# Cash N Carry design and usability review

Reviewed 7 October 2026. Brand: **Cash N Carry** — **Watch Live. Discover. Shop.**

## Method and evidence

Inspected the actual local Worker application in browser frames at 360, 390, 768 and 1440 CSS pixels, together with its React, CSS and route source. Frames exercise real routes and responsive layouts; they are not recreated mockups. Vertical scrollbars consume approximately 15px of content width. Browser screenshots preserve surrounding context; some show only a portion of the frame because the outer browser is narrower than 1440px or scrolled. The category strip intentionally scrolls horizontally; page-level horizontal scrolling was checked separately.

Temporary, explicitly named local QA fixtures exercised an unusually long unbroken product name, ₦99,999,999, unavailable images, stock zero, scheduled broadcasts and a deliberately unavailable replay. These records and the temporary inspection page were removed before packaging; no production records were edited. The enlarged-text check doubled computed text sizes locally to 200%; it does not replace native device font/zoom testing.

## Prioritised confirmed defects

All rows below are design/content defects, corrected within the existing visual style. No critical design defect was established in the accessible scope.

| Page/component | Problem and reproduction | Affected width | Severity | Screenshot evidence | Correction and recheck |
|---|---|---|---|---|---|
| Product page, product dialog, storefront | Open a product with a long unbroken name. The page widened to 3077px at 360px and the dialog's content to 2122px at 390px, clipping shopping information. | 360, 390, 768, 1440 | High | [Before page](design-review/before-product.jpg), [before dialog](design-review/before-modal.jpg), [after page](design-review/after-product.jpg) | Allow text wrapping and shrinking grid/flex children; constrain media. All four product/page/dialog/storefront widths fit after corrections. |
| Live viewer/pinned product | Open a scheduled broadcast pinning that product. Pinned content widened to about 1458px inside a 332px mobile dialog, moving actions off-screen. | 360, 390; shared layout at 768, 1440 | High | [Before](design-review/before-live.jpg), [after](design-review/after-live.jpg) | Wrap pinned rows, allow text column to shrink, limit the visual title to three lines, preserve complete accessible text. Scheduled viewer fits all four widths. |
| Live viewer/status | Open a scheduled broadcast. Dark text on the dark player is difficult to read. | All four | Medium | [Before](design-review/before-live.jpg), [after](design-review/after-live.jpg) | White, centred status text, with clearance beneath the state badge. Rechecked in scheduled viewer. |
| Live marketplace cards | At phone widths long titles, seller names, play controls and state badges crowd each other; enlarged text overlaps the badge. | 360, 390; 200% text stress | Medium | [Before](design-review/before-mobile.jpg), [after phone](design-review/after-mobile.jpg), [after tablet](design-review/after-tablet.jpg) | Flexible card height, reserved badge space, two-line titles, seller ellipsis and stable media layering. Enlarged text now grows cards instead of colliding with badges. |
| Account entry | Open account page. Login/register/reset choices run together and use ~24px targets with weak selected-state visibility. | 390; shared component at all widths | Medium | [Before](design-review/before-account.jpg), [after](design-review/after-account.jpg) | Spaced, wrapping controls with a bordered selected state and at least 44px targets (measured 46px). Native empty-field validation and tab choice verified. |
| Mobile search/location | At <=420px the search placeholder is transparent and the search icon hidden; location controls and labels are crowded. | 360, 390 | Medium | [Before](design-review/before-mobile.jpg), [after](design-review/after-mobile.jpg) | Restore search prompt/icon, 16px form text, readable placeholder colour and full-line manual location entry. Keep seller-location and delivery-coverage choices distinct. |
| Product/media surfaces | Load a product whose image fails before or after hydration. Browser broken-image text replaces the image and can destabilise presentation. | All four | Medium | [Before](design-review/before-product.jpg), [after](design-review/after-product.jpg) | Shared accessible photo-unavailable fallback catches both early SSR failures and later image errors. Reserve public gallery dimensions and contain product images; keep fallback text out of live-card overlays. |
| Shared icon/form controls | Inspect close/add/quantity controls: 30–32px targets are small on touch screens. Two-column forms and fixed modal height also need more room at phone widths. | 360, 390 | Medium | [Before dialog](design-review/before-modal.jpg) | At least 44px targets, single-column mobile form rows, dynamic viewport modal height and safe-area padding. Dialog close/Escape and keyboard focus cycling checked. |
| Stock and playback copy | Stock-zero product still presents a generic buying invitation. Failed replay tells viewers to ask the seller to check a live connection. | 360, 1440 checked | Low | [Replay recovery](design-review/after-replay.jpg) | Explicit out-of-stock label and product-options invitation; retain disabled add-to-cart. Playback error now suggests retry or contacting the seller, without assuming a live host connection. |

## Coverage and results

- Home, product marketplace, long-name public product, product dialog, seller storefront, account entry and scheduled viewer checked at 360/390/768/1440. Recorded [24 width measurements](design-review/width-checks.json) show page/dialog scroll width equals available width. Subsequent affected-page spot checks confirmed final image, card and stock corrections.
- Marketplace empty search and Clear filters, high-price sorting and disabled out-of-stock action checked at all four widths.
- Explore navigation inspected at 360/1440 and Live navigation at 1440. Scheduled, replay and out-of-stock labels are explicit; replay failure and Retry video inspected at 360/1440. Deliberately invalid media continues to fail honestly after retry.
- Account entry, login/register switching, native required-field validation, dialog closing and focus wrap were exercised without entering credentials or creating accounts.
- Privacy, terms, delivery and returns pages inspected at 360/1440; seller policy route inspected at 360. Missing-product 404 and cancelled-payment return inspected at 360/1440.
- Workspace sign-in boundary inspected at 360/768/1440. Admin redirects to the authentication dispatcher; that platform dispatcher is not available in the local preview. This is an access/testing limitation, not a confirmed published-site navigation defect.
- Source reviewed for customer, seller, admin, cart and checkout layouts. Shared corrections apply there, but source inspection is not rendered verification.
- Public branding remains Cash N Carry. Internal ReVibe identifiers, existing domain and integration configuration were preserved to avoid breaking compatibility.

## Remaining and untested

No authorised customer, seller or admin session was available. Populated cart, checkout, order history/tracking, saved addresses, seller dashboard, admin back office, authenticated success/error states and add-to-cart confirmation remain **untested in the browser**. Seller uploads, native live playback/chat/product pinning, real payments/refunds and external notifications require configured services and authorised test accounts. This review does not establish readiness to accept real customers or payments.

Native mobile keyboards, hardware safe areas, assistive technologies, all media aspect ratios, real network throttling, full contrast certification and every authenticated loading/error state were not verified. Policy text is openly marked for owner review and still needs business/legal decisions before launch. No fabricated products, reviews, viewers or performance statistics were introduced into production.

## Build verification

TypeScript and commerce, media, operations and recovery test suites passed. Final production build result is recorded by the publication workflow. No backend, data model, payment allocation or access rules were changed by this design pass.
