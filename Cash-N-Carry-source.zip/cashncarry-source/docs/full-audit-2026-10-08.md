# Cash N Carry audit and corrections — 8 October 2026

Scope: latest published source a1ec615268eff3d6e9be4cf433f5c7b7c83c30e1, existing route map, database table inventory, production request metadata, provider documentation, source permissions and isolated regression fixtures. Existing branding, records, credentials and payment mode are preserved. No live payment, refund, customer message or production test record was created.

## Issue register

| Severity | Finding and evidence | Reproduction and root cause | Correction | Status |
|---|---|---|---|---|
| High | Flutterwave requests to `/` return 405 in production logs | Provider notifications target homepage; only `/api/payments/webhook` handles authenticated notifications | Admin settings explicitly explain the exact endpoint; merchant dashboard must use `https://revibe-commerce.ogundiyatemidayo1.chatgpt.site/api/payments/webhook` | Unresolved external configuration; actual provider delivery untested |
| High | Hosting request logs include the webhook authentication header | Hosting collector records request headers independently of application logging | Application reports never reproduce values. Hosting log redaction and secure webhook-hash rotation in both provider and server settings are required | Unresolved hosting/merchant configuration; no secret rotated |
| High | Host camera occupies viewport | Open Broadcasts and preview camera; `position:fixed`, inset 0, 100dvh stage and full-sized absolute video, plus viewport-height JS override | Bounded inline video frame with object-fit contain; normal document scrolling; separate controls below on mobile and beside on desktop; removed body scroll lock, viewport sizing and modal focus trap | Fixed in source; actual rendered device checks untested |
| Medium | Ending while switching can leave new camera running | Delay getUserMedia, end session, then resolve acquisition; switch lacked generation guard | Stop obsolete acquired tracks before replacement and after asynchronous replaceTrack; serialise switches | Fixed; executable race and repeat-click tests pass |
| Medium | Rapid preview clicks overlap camera acquisitions | Trigger preview twice before getUserMedia resolves; state busy alone was not a synchronous lock | Ref lock blocks second request; existing generation check stops superseded tracks | Fixed in source; physical-camera check untested |
| Medium | Viewer can remain blank after successful negotiation | Provider accepts SDP but no picture arrives; HTTP timeout is cleared after negotiation | Separate 30-second playback deadline, retry feedback and connection cleanup; playing/unmount clear timer | Fixed in source; real viewer playback untested |
| High | Failed end request can temporarily leave LIVE metadata | Disconnect network before End live; local capture stops but database end fails | Three bounded end attempts, explicit failure message and retry instructions; existing heartbeat expiry remains fallback | Mitigated; complete offline end cannot be guaranteed |
| Medium | Leaving Broadcasts tab can hide running camera | Change workspace tab with preview/broadcast active | Confirmation for active broadcast, then synchronous capture cleanup before switching tab | Fixed in source; device check untested |

## Existing safeguards verified with fixtures

- Customer-only registration payload, safe return destinations/cart intent, logout failures and origin checks.
- Buyer/seller/admin ownership, suspended-account restrictions, private verification documents, media ownership and upload quotas.
- Server pricing/variant inventory/delivery coverage and fees; transactional stock reservations and duplicate checkout protection.
- Flutterwave v3 verification checks reference, transaction ID, exact expected amount, NGN currency, mode and successful status. Duplicate events are idempotent. Pending/failed attempts retain reservations until reconciliation; sandbox payments are excluded from live sales totals.
- v3 `verif-hash` authentication and raw-body HMAC support; tampered signatures rejected.
- Encrypted streaming credentials, seller-only publishing details, ownership for featured products, chat moderation, active viewer-session expiry and provider-confirmed LIVE status.
- Backup authorization and isolated restoration, email retry leases, maintenance persistence and catalog filtering/pagination.

These tests use provider fixtures, not real external transactions or camera broadcasts. Database table inventory was read; production customer rows were not exported. No broad dependency upgrade or database migration was needed.

## Verification boundaries and remaining checks

All 14 existing top-level test results passed before final documentation changes. New host-camera lifecycle tests pass. TypeScript passed. The publication workflow runs the final full test set, TypeScript and production build.

The managed preview instructions require the unavailable control-browser skill; no alternate browser path was used. Consequently screenshots, actual rendered widths 360/390/768/1440, landscape/short screens, enlarged text, mobile keyboard, console/network browser inspection and complete authorized customer/seller/admin sessions are **untested**. Layout changes are source-verified, not screenshot-verified.

Real host-to-viewer audio/video, permissions/reconnect on physical devices, sandbox checkout/provider webhook receipt, account email verification/reset delivery, new-session settings persistence, offsite backup/restore drill and alerting remain untested. Linked background maintenance automation is disabled; automatic scheduling is not verified. Existing delivery uses one fee per seller with state coverage; pickup and destination-specific rates remain unsupported.

## Official references

- https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/object-fit
- https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/video
- https://developers.cloudflare.com/stream/examples/browser-based-webrtc/
- https://developers.cloudflare.com/stream/webrtc-beta/
- https://developer.flutterwave.com/v3.0.0/docs/webhooks
- https://developer.flutterwave.com/v3.0.0/docs/transaction-verification
- https://better-auth.com/docs/reference/security
- https://better-auth.com/docs/concepts/rate-limit

This audit does not establish that the whole website is error-free or ready for customer payments.
