# Cash N Carry fixes — 10 October 2026

Base: v68, dca15b12ab5d2fd18ae953f611b332d03bc4c52f. Preserve this saved version as the rollback point.

## Implemented

- Require session-specific, expiring proof of a successful real MFA challenge for admin access. An account with MFA enabled cannot promote an older session.
- Keep owner/admin navigation visible to assigned accounts while protecting every privileged action behind the server gate. Preserve the destination through enrolment, challenge and sign-in.
- Expire MFA proof records during authenticated maintenance.
- Explain overdue maintenance and remove the inaccurate statement that ordinary site visits run maintenance. Use action-specific confirmations.
- Give each draft policy its own canonical URL; retain draft/noindex status until owner approval.
- Avoid error-level logging for expected catalog validation failures.
- Patch Next, React, React DOM, React server components, Vite and matching Next ESLint configuration.

## Verification

- Unmodified full test command: `node --test --test-reporter=spec tests/*.test.mjs` — 101 passed, 0 failed, 0 skipped; 8992.222204 ms.
- TypeScript `tsc --noEmit` — passed.
- Sites production build helper — passed.
- Dependency audit: 52 advisories (0 critical, 27 high, 18 moderate, 7 low), down from 62 (1 critical). This is not a vulnerability-free claim.
- Real installed Better Auth tested in an isolated database: old pre-enrolment session rejected, valid challenge accepted, invalid challenge rejected, recovery code single use and proof expiration enforced.

## Remaining launch gates

- Browser/mobile validation and separate-device real camera/remote-stream testing unavailable in this run.
- Approved Flutterwave sandbox checkout, signed provider callbacks and reconciliation still require provider/browser access. Live money collection not activated.
- Delivery-tested emails and monitored Reply-To require explicitly approved test inboxes and receiving evidence.
- Six policies need verified operator/contact and operational terms before approval. Ambiguous listing details must not be guessed.
- Background schedule remains paused following the earlier automatic approval rejection; this release does not bypass that restriction or claim maintenance execution.
- Remaining dependency advisories require applicability review and compatible upstream changes.
- Production backup restoration and staging separation need operational evidence.

No production account, product, order or payment record was edited as part of these source fixes. No charges, refunds or test customer messages were initiated. Production readiness remains unproven.
