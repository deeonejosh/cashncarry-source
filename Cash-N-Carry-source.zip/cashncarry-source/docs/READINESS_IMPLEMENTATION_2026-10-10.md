# Cash N Carry readiness implementation — 10 October 2026

## Baseline and architecture

Baseline: public release v65, `aa193a7688d7e651bfe0f90df9f2a441498bb614`. Local rollback tag: `readiness-baseline-v65-20261010`. The saved v65 archive and remote commit are the primary recoverable source/deployment points. This tag is not a database backup.

Existing architecture is retained: Vinext/React 19 routes on Cloudflare Workers; D1 SQLite through Drizzle and prepared statements; R2 media and encrypted service configuration; Better Auth email accounts plus preserved Sites/ChatGPT identities; Flutterwave v3 hosted checkout and independent server verification; Cloudflare Stream WebRTC/HLS; Resend transactional outbox and signed feedback. No Android rebuild, new marketplace or replacement provider was introduced. Dependency versions are recorded in package.json and pnpm-lock.yaml; no dependencies were added or upgraded.

Test isolation: existing migration-based SQLite memory fixtures, Better Auth memory accounts, `.invalid` identities and stubbed provider responses. These are staging-like execution of actual backend logic, not a separate hosted staging deployment. Browser capability is unavailable; the managed Sites skill prohibits substituting an improvised browser. No production test accounts, charges, refunds or test customer messages are created.

## Implemented reliability and access changes

- Commerce GET no longer applies owner setup, creates/updates profiles or expires streams. Authenticated POST explicitly creates/updates the acting profile. Stale native streams are classified as ended in read responses and excluded from public discovery without writing the database.
- One-time owner business setup is now an explicit owner/MFA-confirmed operation. Existing setup marker and seller data are preserved.
- Maintenance has a single atomic ten-minute job lease, ownership-safe release, expired-lease recovery, stale-stream expiry, bounded payment reconciliation, encrypted-config-aware email retry, last-success/failure records and structured logs. Read-only credential/status GET permits runner checks without sending messages. Worker scheduled handler uses the same runner. Traffic-driven housekeeping is removed.
- Old race fixtures inject cancellation at the order update batch rather than at unrelated setup. Reactions fixture implements D1 transaction batch. Obsolete duplicate export rewrite removed. Updated auth fixtures accommodate the actual MFA plugin schema.
- Live payment readiness additionally requires a verified merchant account ID. Verification rejects configured merchant mismatches. Live collection remains disabled. The existing reference/amount/currency/status checks, mode separation, webhook authentication, provider idempotency and uncertain reservation handling are retained.
- Better Auth's installed two-factor plugin implements TOTP enrolment, encrypted recovery codes, pending sign-in challenges and single-use recovery. Sign-in handles twoFactorRedirect and preserves destination. `/two-factor` provides labelled enrolment/code/recovery forms; secrets are not placed in URLs or stored by frontend code. Recovery codes must be saved privately by the owner.
- Every administrative page/API/private-document gate awaits server authorization. A matching verified email MFA session is required; ChatGPT identity alone does not unlock administration. Enrolment is required on first owner access. Suspended accounts are denied.
- Owner, admin, support, finance and moderator permissions are server-enforced. Only configured owner can assign/revoke staff roles, operate secure service settings or export backups. No public signup role input is accepted. Grant/revoke requires existing verified account, explicit confirmation and a reason, and is audited. Finance sees bounded payment/refund records and does not receive customer addresses through the general admin response. Support and moderation have separate case/content access. The configured owner cannot be suspended through ordinary account moderation.
- Audit update/delete triggers make existing and future admin audit records append-only through normal database operations. This is not protection against a privileged database operator dropping the triggers. MFA records are included in private backup export.
- Admin navigation filters permitted sections and adds finance/refund operations. Refund approval, provider request and verified completion remain distinct; provider execution requires explicit confirmation.

## Content, security, SEO and performance changes

- Added robots.txt and a database-backed sitemap excluding suspended/hidden listings and private routes. Root, actual product and store canonical metadata added; Help canonical corrected. Product JSON-LD uses actual stored values without fabricated reviews/specifications. Social metadata retains approved assets. Development preview marker removed.
- Homepage server renders branded welcome content and a real heading. Marketplace code is lazy-loaded after entry selection. This improves bundle separation; no measured LCP/INP/CLS claim is made.
- Worker responses set CSP, HSTS, nosniff, Referrer-Policy, Permissions-Policy, frame protection and private-route noindex. Camera/mic remain same-origin enabled. Checkout/stream origins and same-origin template previews are preserved. CSP permits inline React hydration/styles and HTTPS/WSS connections for existing external media; stricter nonce/origin narrowing requires browser/provider compatibility testing. No claim of a fully strict XSS-proof CSP is made.
- Seller Terms and Community/Livestream Rules drafts expanded to actual verification, inventory, payment/fulfilment, privacy, reporting and moderation workflows. Community draft added without overwriting existing policies. Existing approved/owner-edited policies are preserved. Operator/address/contact, commercial arrangements, return/refund timelines, eligibility, retention and appeals still require owner approval. No draft was represented as an approved legal promise.
- Existing homepage-only notification bell, portrait video pipeline, host/viewer rail, cart resumption, delivery coverage/fee snapshots, seller stock/fulfilment, email templates and order history are retained.

## Migration and rollback

`0016_motionless_black_knight.sql` adds an MFA table and a default-false MFA flag, append-only audit triggers, and inserts a Community Rules draft only if absent. It does not drop/rename columns or remove records. Existing data is left intact. Test migrations and fresh SQLite integrity are verified before deployment. Old source remains schema-compatible with these additions.

Application rollback: redeploy the exact saved v65 version via Sites; preserve audience and environment. Do not restore production data casually or erase transactions. A v65 rollback removes MFA enforcement/security improvements and must not be called a secure launch release. Prefer a forward fix when possible. Keep additive MFA/audit schema during emergency source rollback. Never run destructive down-migration on production as part of application rollback.

Before financial launch, owner must export an authorised private D1 snapshot and back up R2 objects/configuration with encrypted offsite storage; restore into an isolated environment and check totals, references, stock/reservations, email deduplication and media. Public read-only table pages are not a transactionally consistent backup. Offsite disaster recovery is not yet demonstrated.

## Operational launch gates

1. Enrol the owner in MFA through secure email sign-in; verify a real authenticated admin and role-denial journey in a browser.
2. Authenticate, enable and observe the existing scheduled maintenance job. A configured endpoint or scheduled handler is not proof that an unattended runner executed. Never remove authentication to make it run.
3. Complete genuine Flutterwave sandbox checkout and signed provider webhook in an isolated environment. Verify merchant account ID securely, live keys and owner approval before changing FLW_MODE. Hosted checkout uses server secret configuration; no frontend secret/public-key workaround is necessary.
4. Select and authorise controlled email inboxes; verify Resend domain, delivery feedback, mailbox receiving and replies. Outbox `sent`/`accepted` means provider acceptance only.
5. Provide and approve the outstanding business/policy details. Verify the ambiguous Headset/Gearpulse identity, location/category and imagery with actual seller information; no legitimate listing is deleted or guessed.
6. Test real phone publisher to separate viewer, pinned purchase/cart, reconnect, mic/flip/rotation, safe areas, keyboard and sheets. Preserve portrait sizing during these checks.
7. Run 360/390/768/1440px browser, keyboard, screen reader/contrast, Lighthouse and real Core Web Vitals checks. Source and mocked-media tests do not satisfy these gates.
8. Perform an offsite restore drill and verify production consistency from a protected transactional snapshot.

## Reference review

Implementation consulted installed Better Auth two-factor source/schema and official two-factor docs, Flutterwave transaction verification documentation, FCCPC consumer rights guidance and NDPC guidance. Draft policies avoid invented statutory deadlines or operator details; owner/legal review remains required.
- https://better-auth.com/docs/plugins/2fa
- https://developer.flutterwave.com/docs/transaction-verification
- https://fccpc.gov.ng/consumers/consumer-rights-responsibilities/rights-responsibilities/
- https://ndpc.gov.ng/wp-content/uploads/2025/07/NDP-ACT-GAID-2025-MARCH-20TH.pdf
