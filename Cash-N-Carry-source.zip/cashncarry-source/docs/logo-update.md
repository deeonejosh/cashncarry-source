# Supplied logo update

The final PNGs derive directly from the uploaded artwork: original lettering and coloured pixels are retained, the off-white surrounding background is removed, and the artwork is cropped with transparent edge padding. The generated background-removal candidate was not used because it changed the colours.

Shared paths and intrinsic dimensions live in app/brand.ts. app/brand-logo.tsx supplies the homepage link and accessible name “Cash N Carry home”. Full wordmarks appear in desktop headers, the footer, account login/registration, customer/seller workspace, product/store/policy pages, and admin navigation/settings. At widths below 375px the marketplace header uses the standalone symbol to preserve space for account and cart controls. The tagline remains separate text.

PNG favicon, ICO fallback, 192/512px app icons, a padded maskable icon and Apple touch icon use the supplied bag/play symbol. The previous brand-icon endpoint redirects to the new symbol for compatibility. No database identifiers, integration settings or business data were changed.

HTML transactional emails now include the wordmark, separate tagline and escaped content with clickable links; plain-text content is retained. Actual delivery is untested without configured email credentials. External email images require the site’s asset URL to be accessible to recipients; owner-private access is preserved.

Browser QA: 360px symbol, 390px full header, 1440px desktop header, and 768px account login/register. Images loaded, retained aspect ratio and did not overlap adjacent controls. Desktop page had equal body client/scroll widths. Header homepage link and PNG favicon loading were checked. Real signed-in seller/admin screens remain unavailable for browser checks; their shared component integration was inspected in source. Temporary QA routes were removed before publishing.

TypeScript, operations and recovery checks passed. Deployment build must pass before publication.
