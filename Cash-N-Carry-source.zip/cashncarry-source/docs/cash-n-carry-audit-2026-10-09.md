# Cash N Carry audit — 9 October 2026

Scope: seller dashboard, marketplace, livestream host, viewer, discovery and delivery/stock flows. Source synchronized from the existing Site before editing. Branding, accounts, product/order records, permissions, payment mode and provider credentials preserved. No financial transactions or production data mutations performed during testing.

| Severity | Finding and evidence | Reproduction | Root cause | Correction | Status |
|---|---|---|---|---|---|
| High | Host/viewer landscape video left empty space. Both final CSS video rules used `object-fit: contain`. | Preview or watch a landscape camera source on mobile. | Contain preserves letterboxing inside a portrait stage. | Full-height cover video, centred crop, explicit video layer and accessible overlay layers. Existing 720×1280 outgoing canvas pipeline retained and tested. | Fixed in source; real phone/provider path untested. |
| High | Viewer modal reserved an unused column; `.live-modal` still inherited `display:grid` and two columns from an older layout. | Open any viewer stream on desktop or mobile. | Later rules changed width without clearing the old layout. | Explicit block modal; one centred portrait stage on desktop. | Fixed in source; rendered QA blocked. |
| High | Keyboard viewport sizes were recorded but never consumed by final host/viewer CSS. | Focus host reply or viewer message input on mobile. | Unused `--host-viewport` / `--visible-viewport` values. | Stages use measured viewport height and offset; resize/scroll listeners cleaned up; scrollable lower controls. | Fixed in source; physical keyboard/panning untested. |
| Medium | Viewer composer had no matching styling; only `.live-chat form/input` were styled, although the composer is a separate element. | Open a live viewer and enter a message. | Selector mismatch after component restructuring. | Shared accessible composer styling, 16px inputs and 44px controls. | Fixed in source; rendered QA blocked. |
| Medium | Host video frame/identity classes had no dedicated styling; negative video layers complicated stacking. | Open seller camera preview. | Markup and stylesheet diverged. | Explicit full-stage video frame at layer 0 and controls at layers 2/3; seller identity layout. | Fixed in source; rendered QA blocked. |
| Medium | Compact host overlays needed short-screen handling and unknown/empty viewer controls were distracting. | Open a short or landscape screen, or an ended stream with an empty cart. | Oversized card/spacing and unconditional cart/reaction controls. | Smaller product cards, bounded lower panels, horizontal tools on short screens; hide empty cart and ended reactions, preserve populated carts. | Fixed in source; rendered QA blocked. |
| Low | Seller Live help still instructed sellers to connect an external HTTPS stream. | Open seller Live tab. | Copy predates native camera workspace. | Direct sellers to workspace Broadcasts for preview and Go Live. | Fixed. |
| High | Gearpulse UK delivery coverage is empty and fee is stored as zero. | Read delivery settings or attempt checkout. | Delivery settings are not configured. | Existing quote guard displays unknown fee and backend rejects unconfirmed delivery; no invented fee. | Confirmed operational blocker; seller must save real coverage/fee. |
| Informational | Headset from Gearpulse UK is an active stored listing with a Black variant and stock. | Inspect deployed product/store records. | No field/evidence establishes it as demo content. | Left published; did not infer test status from sparse description or price. | Reviewed; authenticity not established. |
| Informational | Ended sessions without replays are excluded from discovery; private history is retained. | Regression fixture creates ended/replay/scheduled/live streams. | Existing correction in latest source. | Preserved and regression verified. | Verified with isolated backend fixtures. |
| Informational | Unknown delivery, stock/variant enforcement, roles, moderation, order/payment integrity and media access protections already have regression coverage. | Run all existing tests using isolated SQLite databases and provider fixtures. | Existing implementation. | Preserved. | Automated checks passed; external payment/auth/email journeys untested. |

## Verification

- All 18 existing test files passed (Node reported 32 tests before final viewport-only changes). Re-run final checks recorded below during publication.
- TypeScript passed; production build result must be checked before deployment.
- No recent error events returned by the bounded production Worker error-log query. This does not establish complete operational health.
- Reviewed current MDN camera capture and canvas capture documentation, and Cloudflare WHIP/WHEP browser publishing documentation. Existing native provider integration and outgoing portrait canvas were retained.
- Automated portrait tests cover centred landscape/portrait/square crops, changing frame dimensions, 720×1280 output, retained audio and cleanup. Camera lifecycle tests cover rear-camera constraints, concurrent switch suppression and late-track cleanup.
- No local camera preview, HTTP 200, mock provider response or build pass is treated as proof of remote video/audio delivery.

## Blocked/unverified checks

The required control-browser skill is unavailable. Managed Sites preview guidance explicitly prohibits substituting a different browser path. Consequently no browser console/network capture, rendered screenshots, 360/390/768/1440px visual verification, enlarged-text verification or live phone-to-viewer test was performed. CSS supports these layouts, but they are not visually verified.

Real-device launch checks: front/back switching, rotation, microphone, outgoing portrait picture and sound on a separate viewer, background/foreground handling, keyboard panning, product sheets, live chat, product pinning and end confirmation. Actual email and provider sandbox payments were not exercised. Existing backend has one seller fee plus state coverage; pickup checkout and destination-specific rates are not implemented. Maintenance schedule is paused and was preserved.

## Official documentation

- https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
- https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement/captureStream
- https://developers.cloudflare.com/stream/examples/browser-based-webrtc/

No payment integration or API-version changes were made during this pass.

## Continued audit — reliability corrections

| Severity | Evidence / reproduction | Root cause | Correction | Verification |
|---|---|---|---|---|
| High | Make Better Auth's asynchronous handler reject. The route's catch is bypassed. | Handler promise returned without awaiting inside try/catch. | Await the handler; return safe 503 on service failure and 429 plus Retry-After only on throttling. | Regression covers async rejection, storage failure and throttling; no private provider text returned. |
| High | Server/admin ends a live broadcast while the host screen is open. Host polling reads the ended status but only updates chats/counts. | Host refresh ignores authoritative stream status. | Stop local camera/microphone, portrait publisher and connection, invalidate pending camera requests and leave host mode when server reports ended. Do not send another end mutation. | Regressions cover ended/live responses and a late response from an older broadcast. |
| Medium | Trigger terminal viewer failure or no-media timeout; attached tracks/listeners persist until navigation or Retry. | Error branches close peer only, without complete resource cleanup. | One idempotent release path clears tracks, attached media, listeners, timers and provider session; late provider response is closed safely. | Regressions cover terminal failure, playback timeout, unmount and late negotiation. |
| Medium | Temporarily disconnect then reconnect viewer; old error remains and conceals successful recovery. | Feedback never cleared on connected state. | Allow 8 seconds for recovery, clear stale feedback on connected, release resources if recovery fails. | Regression simulates state recovery and timeout cleanup. |

Latest bounded production error query returned cancelled catalogue and stream requests, without an exception or response status establishing a server defect. These remain observations, not proof of a failed broadcast. No production records were altered and no genuine streams were ended by the audit.

Additional official reference: https://developer.mozilla.org/en-US/docs/Web/API/RTCPeerConnection/connectionState

Browser and device checks remain blocked as documented above. Regression tests use mocks/isolated data; real account persistence, email delivery, provider payment and phone-to-viewer media remain unverified.

## Customer journey implementation — latest review

Implemented: unavailable email forms and registration/recovery links are hidden; configured forms remain real Better Auth flows. ChatGPT sign-in remains available. Production metadata confirms no RESEND_API_KEY or EMAIL_FROM; existing authentication secrets were preserved. No authentication was simulated.

A temporary, one-hour selection draft in session storage preserves product, variant, quantity and original destination through sign-in. The resumed cart action checks current product availability, variant stock and quantity against server data and records an atomic, account-scoped receipt. Retries cannot add the same selection twice or overwrite subsequent cart edits. Success opens the real cart with a return link; failures retain the selection and offer retry. This is a single pending action, not a full guest checkout/cart implementation.

Scheduled cards and waiting screens display date/time in WAT (UTC+1), a countdown within an hour, and an overdue explanation. Past sessions are labelled Awaiting seller. Schedules over 24 hours overdue are omitted from public discovery/storefronts without changing seller history. Ended sessions require a stored replay to appear there. Zero-value summary groups are omitted.

Public /help provides sign-in, delivery, returns, payment/order and livestream help. Private case handling remains authenticated. A verified platform contact has not been found: optional SUPPORT_EMAIL is supported, but no seller/admin address was repurposed.

Unchanged legacy policy drafts are expanded to match existing flows; approved and owner-edited policies are preserved. Draft banners remain. Owner information still required: legal operator identity/address, public support contact, fulfilment responsibilities, return window/exceptions, refund timeline, dispute escalation and privacy retention/contact. Draft preparation consulted official sources: https://fccpc.gov.ng/consumers/consumer-rights-responsibilities/rights-responsibilities/ ; https://fccpc.gov.ng/consumers/complaint-handling/ ; https://ndpc.gov.ng/ . Owner review is required before approval.

Read-only records confirm Gearpulse UK stores location Captital, Abia and Fashion category; the active Headset listing stores Tech category, description Headset, price 1000 and Black variant stock 20. No verified alternative identity, location, specifications or photo provenance was found. Seller-only review prompts identify these ambiguities. The listing stays published; records, prices, stock, orders and permissions were not changed.

New regressions exercise real commerce handler against isolated SQLite migrations: authentication requirement, exact variant/quantity resumption, duplicate and concurrent retries, cross-account isolation, subsequent cart edits, insufficient stock and stale schedule visibility. SSR checks cover unavailable/configured forms; additional tests cover draft-policy preservation, safe return paths, selection expiry and schedule labels. Existing payment tests exercise server-side verification/order transitions using provider fixtures, not an external Flutterwave sandbox transaction.

Browser verification and screenshots remain blocked by the unavailable required managed-browser capability. The managed Sites preview instructions prohibit an alternate browser-control path. No real phone-to-viewer broadcast, email delivery, account registration/recovery, deployed cart journey, mobile keyboard/safe-area/rotation, browser console/network audit or provider sandbox charge has been verified. Portrait media code and compact product layout were preserved. No real charge was attempted.

## Livestream control arrangement — reference design

Host: store initial/avatar, stored name/title, real viewer count, connection status and elapsed time since provider confirmation. The right rail contains Mic/Muted, Flip, Products and More. One compact stored product card links to pin management. Reply input, Send and a terracotta outlined End Live sit above the safe area. Close/Escape opens an explanation and Continue broadcasting; ending needs explicit confirmation. Before-unload warning protects navigation where the browser supports it. Moderation is in More rather than attached to each comment. Product management, moderation and More use a shared bottom sheet with focus containment and a labelled close control.

Viewer: Follow near identity, real LIVE/viewer status, close, then right rail Like/count, Share, Products/count and More/Report. Added unique per-account, per-broadcast stored reactions because the previous heart was local-only. Authentication, origin checks, suspension and live-state checks apply; counts come from storage. Buy Now opens the existing variant/quantity flow, with no charge. Cart quantity is the sum of real cart item quantities and appears beside Ask the seller/Send. Ended broadcasts retain carts and suppress the composer; absent pinned/products content is hidden.

The approved brand and portrait sizing, camera constraints, published portrait stream, video orientation, WebRTC negotiation and reconnect logic were preserved. Overlay styling uses forest green controls, cream compact cards, terracotta accents, dark gradients, 44px targets, safe-area offsets, stage anchors, title truncation and scrollable sheets/rails. Existing visualViewport listeners keep input areas in the visible viewport; compact styling reduces comments when that viewport is under 520px high. Browser force-close and OS lifecycle events cannot be guaranteed to present an unload warning.

New tests exercise actual rendered component event handlers with isolated hook/browser fixtures: rail order/role separation; follow, share, real count refresh, product details without a payment action, cart quantity, comments, report, microphone, camera switch wiring, moderation, close/continue/end confirmation, fullscreen, Escape and Tab containment and the navigation warning. Isolated SQLite tests verify real reaction deduplication, user isolation, unavailable/suspended reactions and seller-scoped pin/moderation. Existing media regressions continue to cover portrait publishing, switch lifecycles, server ending and viewer reconnection. These are automated fixtures, not real-device or browser visual tests.

Screenshots and small/large phone, keyboard, desktop, real camera and remote viewer checks remain unverified. Required control-browser capability is unavailable in this managed environment; Sites preview instructions explicitly prohibit a substitute path. No old screenshot or design mockup is presented as the implementation. No production account, product, order or payment test mutation was made. A schema-only migration adds stream_likes; no existing records are rewritten.

Final automated result for this control arrangement: 52 Node tests passed with zero failures; TypeScript and the production build passed. Build emitted an existing large-client-chunk warning. Final overlay refinements retain the viewer top gradient and anchor essential input/end controls while comments and short-screen rails scroll. These CSS refinements were rebuilt; event/backend inputs remained unchanged.

## Preview Go Live visibility correction

Owner's phone screenshot confirms camera preview and the action rail render while Go Live/Cancel preview are clipped at the bottom. Source inspection found stale grid-row placement on absolutely positioned overlays. In a grid container, those placements resolve their containing block to an empty grid area; viewport-relative maximum heights then collapse and the stage clips the action row. The host stage now uses a block overlay container, and obsolete grid-row/column assignments are removed. Stage dimensions, visualViewport sizing, safe areas, portrait video and capture/publish code are unchanged. This also removes the stale grid placement from top status controls.

Added a regression for the preview state: Go Live exists and is enabled with an acquired camera, pending operations disable it, Cancel preview stops without an end mutation, and End Live is absent until broadcasting. Added a source-layout guard against reintroducing the empty grid-row containing block. Existing camera-switch and server-ending regressions pass. Browser pixel verification remains unavailable under the managed preview restriction; the root cause is established from the owner screenshot and CSS inspection, not from a claimed browser test.


## Remaining owner setup safeguards

Added an administrator-only public support contact form with a monitored/publication confirmation, email validation, same-origin protection and an audit record. Help reads the saved verified-by-owner contact without authentication; an existing SUPPORT_EMAIL server setting takes precedence. No contact was invented or published. Account support remains protected. Mail links encode the address.

Seller delivery settings now expose a state checkbox list rather than an error-prone comma string, explicitly warn that empty coverage blocks checkout, and do not infer coverage from business location. The server requires at least one valid state and deduplicates selections before saving a confirmed fee. The existing checkout coverage/stock/payment guards are preserved. No Gearpulse delivery state, location or product record was changed.

Policy approval now rejects unresolved draft/owner-required markers server-side; drafts remain editable and saveable. The editor explains required operator, contact, delivery, return, refund and dispute facts. This is a safeguard, not a legal-completeness check. Existing approved policies are preserved. Administrator email readiness identifies the missing secure configuration names and explains verified-sender requirements; unavailable email authentication remains hidden and working ChatGPT sign-in remains available. No credential is requested through chat.

New isolated SQLite handler regressions verify administrator and origin restrictions, required public-contact confirmation and validation, public contact lookup and environment precedence, rejection of approving actual generated drafts, draft saving, invalid/empty delivery-state rejection and valid-state deduplication. No production business records or real payment/email/provider actions were exercised. Browser screenshots, device keyboard and actual host-to-viewer streaming remain blocked by the unavailable control-browser capability and the managed preview prohibition on substitute browser paths. Credentials, legal facts, return/refund commitments, delivery coverage and ambiguous listing identity still require owner input.


## Secure email setup and cart identity follow-up

Added an admin-only Resend setup form. The owner explicitly authorises a setup email to their authenticated admin address; the server rejects non-admin/cross-origin/invalid/oversized requests and demo senders, limits attempts and uses a stable retry idempotency key. An accepted provider message is required before AES-GCM encrypted private configuration is saved. API responses and audit rows never contain the key. Existing server-managed email configuration takes precedence and cannot be overwritten by the form. No real email was sent while implementing or testing. Provider acceptance is explicitly distinguished from inbox receipt. The existing Better Auth implementation now asynchronously reads either secure configuration source for sign-in readiness, verification and recovery; it never fabricates authentication. Existing ChatGPT identity, permissions and secure-cookie/password settings are preserved. Dynamic auth pages reflect current configuration.

Cart resumption now watches the actual public identity field (email), rather than a nonexistent id, so a pending selection is reconsidered when a shopper becomes authenticated without a full reload. The existing server-side account scoping and idempotency receipt still prevent duplicate additions. Help remains readable if the support-contact database lookup fails.

New tests use provider fixtures only: admin/origin/consent validation, provider rejection, encrypted persistence, redacted audit/status, fixed authenticated recipient, demo-sender rejection, stable retry identity, setup throttling, server-secret precedence, tamper/storage failure, real auth configuration readiness and verification/reset callback wiring. No credentials have been supplied and email accounts therefore remain unavailable on production until the owner uses the secure setup form. Legal policy facts, confirmed delivery coverage and ambiguous product/store details cannot be inferred. No live charge, external real email, camera broadcast or production order mutation was performed.


## Android Play Store preparation

Generated a real Android Trusted Web Activity source project using pinned GoogleChromeLabs Bubblewrap core 1.27.0 and existing approved icon assets. The app targets API 36, launches only the existing Cash N Carry origin, retains default device orientation and uses Custom Tabs as the fallback. It introduces no native billing, notification, location or background hosting feature. No private signing key or Play developer credential was created. Added an admin-only audited certificate association form and a public /.well-known/assetlinks.json endpoint; with no owner certificate saved it returns an empty list rather than claiming verified ownership. Certificate fingerprints are validated and deduplicated. Brand launch colours match cream and forest green.

Source generation, XML parsing, SDK/package/origin configuration and website certificate authorization handlers can be checked here. A debug APK build was attempted but failed because Gradle's distribution host is unreachable; there is also no Android SDK, emulator or phone. No APK/AAB, device install, camera/payment/authentication in Android, Play signing association or store acceptance is claimed. The README contains concrete Android Studio build/sign/test instructions and owner release prerequisites including approved policies, support/deletion details, accurate Data safety and real screenshots.


## Connected workflow pass — 2026-10-09

Implemented in this pass:
- Header Account now uses the shared Account hub used by Android navigation. Removed the unreachable duplicate account/create modals and redundant broadcast setup modal. Removed duplicate Analytics/Settings seller tabs and the legacy Live management panel; retained Content and Ads because they have working consumers. No accounts, listings, orders or seller history were deleted.
- Canonical `/seller` entry preserves the destination through either configured email or ChatGPT authentication. Account authentication returns to Account, rather than silently falling back to Shop; unsafe/token return URLs remain rejected. Seller Centre workspace tabs and customer account tabs are separated, with links back to Products/Inventory and Orders/Fulfilment. Existing direct workspace links remain supported.
- Go live now creates a private non-live setup, then opens the existing camera preview. Setup is not publicly discoverable and unauthorised direct retrieval is rejected. Existing future scheduling remains available. Featured products are validated as active products owned by the seller. A client in-flight guard prevents duplicate setup submissions. Streaming start retains the existing connection and duplicate-start guards.
- Preview Go Live stays in the existing safe-area action area with an explicit reason while unavailable. Portrait camera/publisher pipeline is unchanged. Waiting messages reserve space for the action rail. Host ending shows confirmed success only after server confirmation, with Browse live/Visit store/prepare another preview guidance; uncertain endings are labelled explicitly. External session ending now asks for confirmation.
- Admin Support lists private order/return cases; Reports handles product/store/stream reports. These use the same owner-protected audited API and records. Provider refund execution requires confirmation; approval remains separate from provider verification.
- Seller delivered value explicitly describes gross delivered order value, rather than claiming a settlement/payout balance. Account load errors and workspace load failures offer Retry without a perpetual loading indicator.
- Android source documentation explains the shared web/backend journey and its unverified device requirements. No new Android binary or native features are claimed.

Verification:
- 62 automated test entries pass, including new private setup/public discovery/direct access and authentication destination assertions. The operations entry contains multiple isolated database/API assertions.
- TypeScript check and production build are required before publication. Provider requests in tests are fixtures, not real money operations. No test charges, production order mutations or credentials were created.
- Existing tests cover account-scoped cart resumption/deduplication, stored stock/price checks, confirmed coverage/fee, Flutterwave reference/amount/currency/status verification, webhook authentication, duplicate/uncertain payment states, owner/admin denial, private documents, seller pin/moderation permissions, camera lifecycle controls, viewer controls, sheets and reconnect cleanup.
- Managed browser capability remains unavailable. The Sites skill expressly requires skipping browser QA in this environment. No new customer/seller/live/admin screenshots, real phone broadcast, separate remote viewer, keyboard/rotation rendering or browser console/network verification are claimed.

Remaining requirements / owner decisions:
- Real email/provider and camera/broadcast tests require configured credentials and authorised accounts/devices. Email must be configured through the existing encrypted admin form or platform secrets, never chat/front-end. Flutterwave production readiness and live settlement require provider/owner verification; fixture tests do not establish that.
- Operator identity/address, verified public support/privacy contacts, delivery responsibilities, return period, refund timing and dispute process remain needed for policy approval. Draft labels are preserved. Gearpulse location/category/Headset image identity remain ambiguous and unchanged pending verified information.
- No delegated admin roles or platform MFA were added; the console remains restricted server-side to the configured owner identity. Owner-controlled grants/revocation, separate finance/support/moderation permissions and MFA remain additional implementation work. No public admin role registration is exposed.
- Broadcast category currently comes from existing store/product categories rather than a separately stored broadcast-category field. Native recordings/replays are not promised by the current provider flow. No native notification/background broadcast implementation was added.
- Android source exists, but signed APK/AAB, SDK/Gradle build, verified Play certificate association, authentication redirects/app-link/offline device tests and Play internal release remain unverified. The prior Gradle download attempt failed because the required host was unreachable. App signing and Play account work require the owner's secure environment.
