# Cash N Carry design implementation

Existing routes were inspected before editing. Existing records, APIs, payment mode and provider configuration were preserved. No production seed data or new migrations were introduced.

| Surface | Existing route | Connected system |
| --- | --- | --- |
| Home, live discovery, marketplace | `/?browse=1#home`, `#live`, `#market` | Commerce search, category, location and broadcast data |
| Seller dashboard, products/editor, fulfilment | `/?browse=1#seller` | Existing seller actions, product uploads and orders |
| Cart and checkout | `/?open=cart` | Authenticated cart, variants, shipping, idempotent orders and Flutterwave |
| Product | `/product/[id]` | Public catalog, saved products and protected cart mutation |
| Storefront | `/store/[id]` | Products, videos, broadcasts and authenticated follows |
| Welcome | `/welcome` | Approved brand and browsing entry |
| Account entry | `/sign-up`, `/sign-in`, `/forgot-password` | Existing email authentication and verification callbacks |
| Customer account | `/account` | Authenticated account hub; signed-out authentication fallback |
| Saved, addresses, notifications, profile, support | `/workspace?tab=...` | Existing private account actions |
| Orders | `/?browse=1#orders`, `/order/[id]` | Buyer/seller-authorised orders and tracking |
| Payment result | `/payment-return` | Independent server payment verification |
| Delivery, verification, broadcasts, financials | `/workspace?tab=Delivery`, `Verification`, `Broadcasts`, `Sales` | Existing seller permissions, delivery settings and provider session controls |
| Live viewer and product sheet | `/?stream=[id]` | Streaming, presence, chat, pinning, cart and checkout |
| Admin | `/admin` | Existing owner-authorised management and moderation |
| Platform settings | `/admin/settings` | Payment readiness, encrypted Stream settings, email queue and maintenance records |
| Policies | `/policies/[id]` | Existing reviewed/draft policy content |

## Design implementation

- Shared tokens and responsive rules live in `app/design-system.css`.
- Reusable customer header/navigation/page heading, product gallery, purchase controls, storefront actions and account hub are connected to existing APIs.
- The approved existing PNG brand assets are unchanged. No board screenshots are part of the website.
- Responsive rules cover narrow mobile (360/390), tablet (768), and desktop layouts (1440). Browser rendering at those widths remains unverified.
- Product subtotal, seller shipping fee and estimated cart total are distinct. Checkout remains authoritative for delivery coverage and price/stock validation.
- Product/gallery media uses explicit viewing and lazy loading; native live playback retains its existing streaming behaviour.
- Live keyboard resizing uses the browser's visual viewport when available. Real mobile keyboard/camera behaviour needs device QA.
- Admin settings show configuration and actual stored timestamps, without asserting provider health from configuration alone.

## Existing limitations

- Delivery is one fixed fee per seller. Destination-specific rates and pickup checkout do not exist in the current backend; the UI explains this rather than presenting fake controls.
- Browser broadcasts do not have recorded replays. Discovery and storefront replay links appear only when actual replay data exists.
- Google sign-in is not configured and is not shown.
- Email delivery and live-payment activation require their missing service configuration. No payment mode was changed and no real financial transaction was made.
- The required managed-preview browser skill is unavailable. Actual implementation screenshots, width verification, device uploads and seller-to-viewer broadcast testing cannot be claimed.
