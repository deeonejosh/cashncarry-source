# ChatGPT admin MFA correction — deployed and browser verified

Root cause: requireAdminMfa rejected the ChatGPT-only identity because it required a verified Better Auth email/password session before offering MFA.

Correction: assigned, non-suspended administrators authenticated through trusted Sites identity may request a 10-minute signed Better Auth pending challenge for their existing verified, MFA-enabled identity. The existing TOTP/recovery endpoints retain attempt limits, lockout and successful-session proof. No account, password, MFA secret, permission or pre-MFA session is created. Foreign origins and missing trusted identities are rejected.

Accounts without an existing enrolled Cash N Carry authenticator remain blocked with an explicit setup message. This change does not establish that the owner's authenticator is enrolled.

Validation: three challenge/authorization regression tests passed; TypeScript and production build passed. Full regression suite result is recorded in the delivery message. Version 116 deployed successfully; real Chrome verified ChatGPT identity → pending challenge → securely entered authenticator → authenticated Admin Console.

Publishing this change allows ChatGPT identity to act as the first factor for already-authorised admins, with existing authenticator verification as the second factor. Explicit owner approval is required before production deployment because this changes the accepted admin authentication path.
