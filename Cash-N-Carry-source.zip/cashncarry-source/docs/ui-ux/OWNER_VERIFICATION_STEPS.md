# Cash N Carry — owner-assisted acceptance session

Baseline: production version 109. Camera-first path: https://cashncarryng.com/live . Keep test records pending until actual results and evidence are returned. Use only accounts and test inventory you control. Do not share passwords, identity documents, tokens or bank details. Do not submit live payment or payout requests.

## First session: two physical devices, 15–20 minutes
1. On your Samsung A54, open Android Chrome at cashncarryng.com. Sign in to a verified seller account with existing active access. Record Chrome version and device model. Do not bypass verification or subscription restrictions.
2. On a second phone or computer, sign in as a separate buyer. Use headphones on that device to prevent echo. Record its browser/version. An iPhone Safari run must be separate if available.
3. Start a screen recording on the seller phone. Tap the bottom Live button. Record whether the camera opens directly with controls, without a setup page. Grant camera and microphone access. Confirm front camera opens and no stream is public yet.
4. Close once before going live. Confirm the OS camera/microphone indicators disappear. Reopen Live. Test Flip, mute/unmute, camera off/on, optional Settings and supported flashlight. If denied permission, reset this site's camera/mic permission in browser settings and retry; record both states.
5. Select one controlled product with known stock, price and delivery settings. Leave title empty to verify it is optional. Tap Go Live once. Record Connecting, then LIVE and time-to-connect; capture any exact error. Repeat the start test in another session with rapid double tap and check only one session exists.
6. Buyer opens the seller's actual stream from discovery or shared link. Record video and audio. Seller says a unique phrase such as “QA 13 October, blue bag”; buyer repeats it in chat. Buyer taps video to enable audio if browser autoplay blocks it. A preview or LIVE badge alone is insufficient evidence.
7. Buyer joins/leaves once; record counts on both devices before and after the polling delay. Do not expect a fixed count or invent viewers. Exchange uniquely numbered chat messages.
8. Pin product, unpin, then pin again. Buyer checks title, image and price. Open/close shopping bag; collapse/expand pin. Check that camera/video stays visible and the seller's face remains clear.
9. Test Add to Cart and Buy Now with known quantity/variant. Check line item, total, delivery and existing cart; stop before payment. Return to stream.
10. Seller briefly turns Wi-Fi off/on while mobile data is also disabled to cause a genuine 5–10 second interruption. Record reconnect status and whether the same stream resumes. Restore connectivity; record buyer playback/audio and any error. Test a longer interruption separately. Avoid repeating uncontrolled failures on a public live.
11. Open keyboard and type a long message; record whether Send, shopping controls and Close remain reachable. Background and return to the browser once; record what actually happens rather than assuming continuity.
12. Confirm End Live. Record ended screens on both devices, OS indicators off and provider dashboard status if accessible. Do not expose provider credentials. Record stream ID, timestamp and observed summary. Reload viewer link: it must not continue presenting a live broadcast.
13. Return seller and viewer recordings plus completed OWNER_LIVESTREAM_ACCEPTANCE.csv. Include exact failure step, screenshot, browser, stream ID and timestamp. Evidence will be reviewed before any item is marked passed.

## Competitive feature sessions, controlled data only
- Live Deal: create a small offer on the test stream with a 2–3 minute window. Record regular/deal price, cap and expiry on viewer pin, bag and direct checkout. API/database tests already cover reservations; real-money orders must not be used to test capacity.
- Bundle: two controlled products, known quantities and stock; create bundle, feature/pin it, check buyer contents and price. Stock allocation/restoration needs an isolated test environment and database access; production live checkout is excluded.
- Analytics: explicitly consent to analytics on buyer device; perform uniquely timed view/click/cart actions. Check selected date range and downloaded CSV. Deduplication means reloads do not necessarily increment counts. Do not equate estimated events with paid revenue.
- Affiliate: controlled creator applies; authorised admin approves; seller invites, creator accepts; buyer follows generated referral. Record dashboard attribution. Commission state transitions need controlled unpaid/paid fixtures in isolated storage; never initiate payout.
- Auction: seller schedules short test auction; two separate buyer accounts submit valid bids at almost the same time, then an invalid lower bid. Record highest bid, minimum, countdown and bid history. After expiry check exactly one winner order, explicitly unpaid, and no charge. Test only if you intend the test inventory to be reserved.
- Founding seller: use dedicated test seller; authorised admin approval/rejection, expiry and restrictions. Do not alter real seller access or production clock. Exact expiry simulation needs isolated storage.

## Full browser and viewport session
Use OWNER_VIEWPORT_ACCEPTANCE.csv at 320, 360, 375, 390, 414, 768, 1024 and 1440px. Device emulation is viewport evidence, not physical-device evidence. Replace [id] routes with your controlled product/store/order IDs. On the homepage also open marketplace, categories/search, cart, checkout and live discovery; on /workspace test conditional seller tabs; on /seller/competitive test every growth tab; on /admin test every permitted management tab. For each state record loading, empty, failed-request and populated appearance where safely possible.

Capture screenshots before reporting a defect and again after its correction. Check horizontal overflow, 200% text/zoom, labels, keyboard focus, contrast, safe areas, bottom navigation and open-keyboard layout. Record failures in CSV; do not mark a whole route passed if an authenticated/conditional state is untested.

## Current result
No owner/device results received yet. Every real-device, real-broadcast and viewport row remains Not tested or Blocked by external dependency. Original evidence-limited scores remain livestream 53/100 and website 52/100. Deferred payment, recurring billing, payout and support-email work does not deduct score points.
