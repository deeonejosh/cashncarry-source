# Live Deals redesign

Route: /seller/competitive?tab=Live%20Deals

Warm cream seller workspace with brand header, studio shortcut, summary cards, numbered offer form, actual product price preview, searchable/filterable deal cards, reservation progress, expandable recorded performance and cancellation confirmation. Responsive form and card layouts collapse for small screens. Inputs have labels, controls retain focus styling, status/errors are announced, and edit scrolling respects reduced motion.

Existing save/cancel APIs and server selling eligibility remain authoritative. Product selection excludes unsupported variants and unavailable inventory. Private scheduled streams now appear using commerce.myStreams. Live status requires the selected stream to be live. Reserved units remain distinct from paid orders and verified revenue. No payment, payout, billing, support-email or database changes.

Validation: TypeScript check passed. Five new component/runtime tests cover stream-aware status, eligible product/stream choices, validation, exact submission and failed-save retry. Existing competitive-feature tests passed (6). Full regression suite and production build results recorded during publication.

Browser screenshot review and actual device testing unavailable in the managed environment; no visual or camera test pass is claimed.
