# Broadcast connection recovery — 13 October 2026

Story: an eligible seller's mobile WebRTC connection drops → the studio waits briefly → authenticated resume reuses the existing stream/provider input → provider confirmation restores LIVE, or the seller remains in the studio with an explicit retry/end choice.

The supplied Android Chrome recording confirmed camera preview and initial provider-confirmed LIVE, followed by Reconnecting and a studio exit. Source showed an eight-second disconnect timer calling stop(), which ended the session and destroyed camera resources. The recording does not establish why the network connection dropped or prove that product selection caused it.

Implemented changes:

- A brief disconnect has a 15-second recovery grace period. Reconnection cancels its timer.
- Persistent disconnect or failed transport initiates a bounded reconnect against the same stream ID and provider input. No duplicate stream record is created.
- Transport replacement deletes the prior provider session and closes the peer/canvas transport while retaining physical camera/microphone tracks for automatic reconnection.
- The initial connection timeout is cancelled once the transport connects; it can no longer terminate a later interruption.
- Exhausted/unsuccessful recovery stays in the studio with Retry broadcast and End session. Retry can reacquire camera permission if needed.
- Reconnects retain server owner/verification/selling-access checks. Ended sessions cannot resume.
- Heartbeat confirmation cannot display LIVE while the peer is disconnected, and stale confirmation responses cannot override newer recovery state.
- End/close invalidates pending recovery, cancels timers and releases media. Closing during provider cleanup prevents a late reconnect.

Validation: complete suite 157 passed, zero failed/skipped; TypeScript passed before final packaging. Seven new tests cover transient recovery, duplicate disconnect events, failed transport/exhaustion/stale timers, transport-only teardown, closing during cleanup, same-stream API resume, and owner/access/ended-state restrictions. Client tests use controlled timers/media fixtures; server tests use the actual route against an in-memory SQLite schema and provider configuration fixtures.

| Boundary | Evidence |
|---|---|
| Initial mobile entry / camera / Go Live | User-supplied recording, prior to this fix |
| Client recovery state and request | Controlled callback/function tests |
| Resume endpoint / database ownership and access | Actual route with SQLite fixtures |
| Stream identity / response | Same stream count, same publish URL, unchanged heartbeat before connected confirmation |
| Full provider reconnect on the user's mobile network | Not yet tested |
| Native publication | Reported in the delivery message |

No payment, billing, payouts, email configuration or database migration is changed. No production broadcast was started by the tests. This fixes recovery behaviour; it does not guarantee uninterrupted video on an unreliable network or identify the original transport-loss cause.
