# SEO checker follow-up —15 October2026

Development candidate based on deployedversion130 /6d943545e30d5e69a03eaf4482c84783c9a05f8f. No production deployment.

## Observed baseline
Backlinko report in actual Chrome returned homepage SEO93/100, mobile performance93, desktop99 and automated accessibility100. Content381 words, text/code ratio6.10%; tool labels these content findings. Also missing social profiles, dedicated local-business schema/contact/map signals and a skip-link warning. These are automated homepage results, not an all-route audit or live ranking guarantee.

## Changes
- Added six native, keyboard-operable FAQ disclosures below the existing shopping guide. Covers actual livestream shopping, options/stock, Nigerian delivery coverage, verification limits, live offer/checkout validation and order/help guidance. No new promises about delivery/refunds/payment readiness. Existing shopping content and product navigation retained; no keyword stuffing or hidden search-engine-only text. FAQs remain in server-rendered HTML while collapsed visually.
- Root structured data now exposes separately identified Organization and WebSite nodes in one graph, with consistent publisher reference, actual brand/logo, Nigeria target market and Help contact URL. No invented address, telephone, opening hours, map coordinates, ratings or social accounts. Existing SEO title, description, canonical, sitemap, robots and social preview metadata preserved.
- Moved existing SkipLink before JSON-LD and analytics content as first body component. No duplicate skip link.
- Added understated FAQ spacing/focus styles and SSR regressions.

## Findings resolved or blocked
| Finding | Outcome |
|---|---|
| Thin shopping explanation | Expanded relevant, factual guidance; SSR test passes. New checker score not measured |
| Low text/code ratio | More useful text; no guarantee threshold passes. Interactive app JS retained rather than breaking features to chase a ratio |
| Skip link missing | Actual production Chrome Enter test focused document.activeElement.id=main-content; exactly one target with tabindex=-1. Existing warning is a detection mismatch. Link retained and moved first |
| Business identity markup | Clear Organization graph and Help URL added; tests verify relationships |
| Missing social profiles | Blocked on owner-confirmed official Cash N Carry profile URLs. No personal/seller profiles guessed |
| LocalBusiness/address/map | Not applied without a confirmed public physical customer-facing location. National online marketplace Organization is appropriate; no private address exposed |
| AI visibility/sentiment unknown | Not measured by this checker; no invented improvement or external account connection |

## Evidence
Actual production Chrome homepage inspected and existing skip link activated using Enter. Focus reached the intended main region. Browser check preceded deployment of these changes; new FAQ visual/keyboard acceptance has not been browser-tested because no authorised managed preview is available. No after screenshot or revised93→100 score claimed. External scan can be rerun after an approved deployment.

Tests:227 automated passes,0 failures; new2 SSR tests check accessible native disclosures, links, non-guarantee wording, Organization/WebSite references and omission of unverified location/social fields. TypeScript passed; supported production build passed; git diff --check passed. Prior full-repository lint backlog not resolved or claimed clean.

Files:app/shopping-design.tsx,app/layout.tsx,app/shop-redesign.css,tests/seo-home-content.test.mjs,this report. No database, payments, subscriptions, payouts, email configuration or approved legal terms changed.

## Remaining owner inputs and release
Supply official Cash N Carry social profile URLs; optionally confirm whether there is a public customer-facing business location and its approved public contact details. A map is not added solely to satisfy a generic checker. Explicit production approval required before publishing. Retainversion130 for rollback. Recheck live homepage, FAQ disclosures, skip focus, JSON-LD and checker after release; search rankings and a100 score are not guaranteed.

References:Google Search Central Organization structured data (https://developers.google.com/search/docs/appearance/structured-data/organization), local business guidance (https://developers.google.com/search/docs/appearance/structured-data/local-business), helpful content guidance (https://developers.google.com/search/docs/fundamentals/creating-helpful-content). Google guidance prioritises useful content and says there is no preferred word count.
