# Seller and buyer screenshot corrections
14 October2026. Prepared for review; not deployed.

Source screenshots: owner-provided1002643774(1).jpg buyer and1002643864.jpg seller. These are actual device evidence of the prior layout, not after-state screenshots.

Confirmed defects and corrections:
- Buyer Follow/status overlap: design-system.css used absolute Follow top52px and status top64px despite variable-height identity. Follow now participates in header flex layout. ResizeObserver measures header height and positions status/feedback below it; shrunk avatar/title and fixed badge keep long names truncating.
- Seller LIVE overlaps identity: inherited absolute status/connection rules now overridden with flow-relative layout, keeping status rows after identity.
- Buyer cream card rendered a dark inner button with nearly invisible stock/shipping: broad .live-shopping button styling overrode less-specific new card classes. Added explicit scoped card, text, price and purchase styles; no opacity/text-shadow inherited on product details.
- Seller pinned card clipped and heading white on cream: flex children shrank under the dock height constraint; broad host button theme hid heading text. Card sections/forms/navigation now do not shrink; lower dock scrolls rather than clipping the card. Explicit scoped forest heading/Unpin on cream and adequate product row height.
- Control rail competes with lower content: viewer dock and header measured; rail reserves dock height with scroll recovery. Seller retains its measured dock and scrollable control rail.
- Resolved variant prompt persisted after choosing option: now clears only that specific resolved prompt. New component handler regression verifies option state and notice clear.

Files: app/live-shopping.tsx, app/premium.css, tests/live-controls.test.mjs, this report. No provider/payment/verification/data/schema modifications. Existing pin/cart/BuyNow/stock/server totals and camera lifecycle preserved. Report-only prior deployment evidence retained.

Verification: full215 tests passed0 failed and production build passed. TypeScript passed. Real screenshots identify before-state. Supported remote browser lacks requested viewport emulation/local staging preview; new360/390/430/768/desktop screenshots, keyboard testing and real seller/viewer acceptance remain unperformed. No device-camera or actual broadcasting pass claimed. Owner approval required before production deployment. Saved candidate may be reviewed as tested code but is not a complete physical-device layout certification.
