# Seller mobile control rail correction
14 October2026. Not deployed.

Owner screenshot1791991430039.jpeg shows actual seller LIVE screen with provider-confirmed label, duration and premium Verified badge. It does not establish buyer playback/audio. No pinned product or messages are visible. Buyer-only shopping controls from the approved reference should not be exposed to the broadcaster.

Confirmed visual defect: right-side Settings is partially clipped and More is below the visible rail. app/premium.css changes the mobile seller rail to two44px columns, six controls in three rows, with explicit scroll recovery for short screens; compact truncated subtitle and reply/end dock spacing. Chat reserves rail width. Existing product selection, pinning, camera controls, provider and checkout handlers unchanged.

TypeScript,13 existing live control tests and production build pass. CSS-only change does not require mirroring layout rules in a source-pattern test. Physical360/390/430px overflow/keyboard/portrait acceptance remains unverified; actual new-screen screenshots pending approved deployment/device retest. No production session was started/ended or records altered. Report-only deployment evidence from123 is also retained in this source. Owner approval required for release.
