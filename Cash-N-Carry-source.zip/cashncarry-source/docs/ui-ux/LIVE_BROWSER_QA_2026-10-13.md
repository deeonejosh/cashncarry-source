# Live production Chrome QA — 13 October 2026

## Actual environment
Remote Chrome/CDP browser, authenticated owner-selected session retained from secure sign-in. Desktop DOM viewport measured 1363 × 936. Browser version/user-agent unavailable through the documented read-only DOM surface. Actual Chrome UI interaction, not unit-test simulation or physical Android/iPhone. Test timestamps in browser console: around 21:27 UTC (22:27 London). Production cashncarryng.com, baseline version110. No browser resize/emulation API advertised; all requested mobile widths remain untested.

## Reproduced defects
| ID | Route / role | Severity | Reproduction and actual result | Root cause / correction | Retest |
|---|---|---|---|---|---|
| QA-001 | seller/competitive, eligible seller | High | Open growth tools; Affiliates fails with D1 trigger already-exists error. Changing analytics date range reproduces same error in Live Deals instead. Other sections survive. | Independent Worker isolates interleave runtime DROP/CREATE trigger calls. All three guard replacements now run in a single transactional D1 batch. No trigger definitions, payment settings or records changed. | Concurrent initializer SQLite regression passes. Version111 production Chrome retest: Affiliates loaded with product choices and no schema alert. |
| QA-002 | workspace studio, eligible seller | Low | Remote browser has no camera/mic; Settings says no device found while studio status says permission required and generic allow-permission copy. | Catch branch and fallback UI obscured actual failure. Distinct denied/missing-device/secure-context statuses; studio shows actual recovery message. | Missing-device vs denied regression passes. Version111 production Chrome retest: truthful unavailable-device label and specific recovery message; Go Live remains disabled. |

Changed application files: app/competitive-schema.ts, app/workspace/page.tsx. Tests: camera-first-studio, schema-concurrent-init, maintenance and readiness-security (D1 transactional batch mocks). Regression result:169 pass,0 fail; TypeScript passes. Two initial maintenance fixture failures were corrected by implementing the production D1 batch interface in fixtures; final suite passes. Production build and deployment evidence are reported with release delivery.

Schema effect: replacement of already-existing guards occurs transactionally on runtime initialization, keeping their definitions unchanged. No new tables/columns/migrations and no customer-record edits.

## Actual interactions and observed outcomes
| Test | Result | Evidence/limit |
|---|---|---|
| Authenticated account page | Confirmed pass in prior Chrome turn | Owner-selected signed-in session; no secrets recorded |
| Live navigation | Confirmed pass | Seller routed directly to studio; no mandatory title/setup; actual DOM |
| Camera permission/media acquisition | Blocked | Browser explicitly reports no camera or microphone; no broadcast created |
| Optional settings | Confirmed pass | Opens title/media-status sheet; close returns to studio |
| Product selection | Confirmed pass in private preview | Selected Mic; correct ₦1,000 card appeared; no server live pin claimed |
| Collapse pinned product | Confirmed pass | Card disappears, Show pinned product control remains |
| More menu | Confirmed pass | Opens labelled tools links, moderation/fullscreen actions; close works |
| Cancel preview | Confirmed pass for UI | Leaves studio; no physical media cleanup could be measured |
| Empty search / clear | Confirmed pass | Unique nonsense search yielded 0 products and Clear filters restored two products |
| Product modal / variant | Confirmed pass | Black selection enables purchase controls; unselected controls disabled |
| Add to Cart | Confirmed pass | Owner-authorised cart changed from empty to one Mic; loading disables actions; shopping bag subtotal₦1,000 + delivery₦100 =₦1,100 |
| Checkout interface | Confirmed pass for entry/totals | Delivery fields and totals displayed; no submission, agreement acceptance or payment |
| Buy Now | Confirmed pass for entry/cart independence | Direct summary Mic/Black/Qty1 and₦1,100 total; reopening cart still showed original item |
| QA cart cleanup | Confirmed pass | Removed only QA-added Mic; final bag empty, matching starting state |
| Policy routes | Confirmed pass for rendering only | Privacy,Terms,Delivery,Refunds,Seller Terms,Community Guidelines headings/content loaded; no legal edits |
| Help | Rendered | Contact/support and policies links; no support message submitted |
| Public auctions | Empty state rendered | No auctions available; bids/closure untested |
| All six growth tabs | Navigation confirmed | Live Deals,Analytics,Bundles,Affiliates,Auctions,Founding Seller render; schema API failure found |
| Analytics range | Confirmed pass for reload | Selected7 days; range changed to2026-10-06–2026-10-13; figures source-backed, no fabricated metrics |
| Analytics CSV | Download confirmed | Browser download completed; numeric reconciliation not completed |
| Creator | Unregistered state rendered | Application fields,zero recorded activity,no partnership/history; approved workflow requires controlled creator account |
| Seller finance | Rendered | Verification/subscription interface; explicitly disabled live billing/withdrawals; no financial action |
| Admin routes | Blocked by authentication | /admin,/admin/settings,/admin/competitive redirect to sign-in; no approvals/settings modified |
| Messages/Seller Centre | Route smoke inspection only | Initial page structure observed; complete workflows untested |

## Page inventory versus coverage
Source inventory: AUDIT_ROUTE_INVENTORY_2026-10-13.json (32 page routes). Twenty route entries visited/attempted in Chrome: /,/live,/account,/workspace,/help,/privacy,/terms,/delivery,/refunds,/seller-terms,/community-guidelines,/live-auctions,/seller,/seller/finance,/creator,/admin,/admin/settings,/admin/competitive,/messages,/seller/competitive. Admin entries redirected; rendering/loading does not equal page-wide pass. The product was tested in marketplace modal, not its separate shareable route. Conditional seller/admin/account states and remaining routes still require testing.

## Livestream control coverage
Settings,Add Products,private pin selection,Collapse,More,Close/Cancel were actually clicked. Go Live correctly disabled without media. Flip,Mic,Camera disabled without media;Flash absent. Real pin/unpin,viewer Chat/Send/Like/Follow/Share,Shopping Bag,BuyNow/Cart during streaming,EndLive and reconnect remain blocked by media plus separate controlled viewer session. Seller-tool links are exposed; integrated live deal/bundle/auction execution is unverified. Existing OWNER_LIVESTREAM_ACCEPTANCE.csv remains pending except the precise non-broadcast UI checks above.

## Outstanding feature verification
All six features remain partially verified, not fully end-to-end tested. Live deals require eligible non-variant test products and actual live stream. Bundles require two controlled component products. Affiliate requires approved creator/test partnership. Auction requires separate controlled buyers and non-binding inventory. Founding programme needs authorised admin/test seller with reversible fixture records. Seller restriction checks need dedicated unverified/expired-access accounts. Physical-device/provider video and audio session remain unperformed.

## Completion and scoring
Complete role journeys:0 of6 (buyer,seller,verified seller,unverified seller,approved creator,admin). Full end-to-end QA completion by that denominator:0%; individual UI checks above are real passes but do not imply a complete journey. Route visit coverage20/32=62.5%; this is not functional completion. Six features:0 fully verified,6 partially verified. At discovery:0 confirmed critical defects,1 confirmed high defect. Broader defect count remains unknown because coverage is incomplete. No full WCAG2.2AA or responsive certificate.

Conservative scores remain53/100 livestream and52/100 website using baseline category weights. New browser evidence is recorded without awarding full-category credit for partial checks. Payment/recurring billing/payout/support email exclusions unchanged and not deducted.

## Needed from owner
Secure access to dedicated buyer,unverified/expired seller,approved creator and authorised admin test accounts; approved disposable inventory and test documents; physical Android/iPhone and second viewer device; permission to create explicitly identified reversible test records. Never send credentials in chat: use secure browser sign-in. Follow OWNER_VERIFICATION_STEPS.md for the genuine media session. Mobile screenshot matrix,complete role journeys,commission/auction concurrency flows and accessibility checks remain open.

## Production retest evidence
Version111 deployment succeeded,2026-10-13T21:30:43Z. Both defects retested through cashncarryng.com after publication. No remaining confirmed critical/high defects from this limited session; this is not an assurance that undiscovered defects are absent. Before/after screenshots are in browser-evidence/. Final source includes these records.
