# Premium pinned-product card implementation

15 October2026. Development candidate based on deployedversion129 (63a3c3e2f1ad6227befb18b1f50c9d5af363c53a). No production deployment performed.

## Implemented
Seller expanded card: cream surface, forest pin header,16–18px rounding,64px mobile/72px desktop product image,14px clamped title,18px terracotta NGN price,12px real stock,44px Manage product link and forest-green Unpin button with white icon. Expected height roughly140–170px depending title length/font scaling; not a measured viewport guarantee. No example product data hardcoded.

Collapsed seller and buyer strips retain actual thumbnail, ellipsised name, NGN price, pin/shopping indicator and44px expand target. Collapse only changes local presentation; it never unpins. No dismiss/close button introduced because independent dismissal is not an established state. Seller expanded action is Unpin; buyer retains variants, Add to Cart and Buy Now without seller controls.

Thumbnail selection and product dropdown now select a candidate only. Explicit Pin selected product invokes existing pin API. Thumbnails retain horizontal scroll,44px targets, current-pin gold outline and selected-product outline. Product selector remains accessible through existing rail. Product-image fallback uses existing ImageAsset component.

Pin/unpin requests use a ref lock against repeated concurrent taps. Seller stream product updates optimistically; failed request restores previous pin and keeps error feedback. Successful request reloads authoritative data, with clear viewer-sync feedback. Existing buyer metadata polling receives updated stream.product and products; no new realtime transport. Therefore synchronization is polling-based and not instantaneous. Buyer purchasing pauses when metadata refresh detects disconnection. Existing server stock, options, prices and checkout authority remain intact.

Server pin endpoint now rejects sold-out owned products; affiliate eligibility query also requires stock. No schema or verification/payment/subscription change. Existing ownership/selling permissions preserved. No provider replacement, gifting, bottom End Live or duplicate More controls added. Top X confirmation preserved.

## Modified files
- app/workspace/page.tsx
- app/live-shopping.tsx
- app/premium.css
- app/api/commerce/route.ts
- tests/live-controls.test.mjs
- tests/live-shopping-bag-history.test.mjs
- this report and browser-evidence/pin-before-20261015.jpg

## Evidence and tests
- Complete automated suite:225 passed,0 failed.
- Targeted control and pin-history tests:27 passed,0 failed.
- TypeScript:passed.
- Supported production build:passed.
- git diff --check:passed.
- Prior repository-wide lint backlog is unresolved; no clean full-lint claim.

New component tests confirm selection does not submit, explicit Pin uses existing product ID, collapse retains identity without a request, expand restores seller actions, Unpin clears seller pin immediately, duplicate taps issue one request, failure restores old pin, buyer card hides seller actions, and disconnected purchase buttons disable. Existing variant/cart/direct-checkout tests pass.

SQLite/API test switches authorised seller/buyer identities: seller pins product; buyer GET returns exact ID/price; repeated Unpin leaves cleared stream.product and removes product from featured results; sold-out pin returns400 without updating pin. This tests backend state/response propagation, not two independent authenticated browser sessions or real provider broadcasting.

Actual Chrome production before inspection: /workspace?tab=Broadcasts&studio=1 with authorised seller, PREVIEW and no camera/mic. Selected Mic only in camera-preview local state (no stream write), observed actual card/image/price/stock and captured before screenshot, then Unpin restored local preview. No broadcast or production customer record created/modified. Before screenshot:browser-evidence/pin-before-20261015.jpg.

## Remaining verification
Development preview is unavailable in the managed environment, so no after screenshots or360/390/430/768/desktop rendered acceptance claim. CSS specifies responsive sizes, clamping, touch targets and short-screen scrolling but these need visual tests. Real camera/audio/provider, two-browser pin/unpin synchronization, network recovery, mobile keyboard, missing-image rendering and long-name screenshots remain pending. Existing fallback and safe-area/visualViewport code retained. No physical device evidence claimed.

Owner-assisted acceptance: on an authorised candidate environment, seller starts real test broadcast; buyer joins independently; select thumbnail and confirm nothing changes until Pin; verify new ID/image/NGN price/options on buyer; collapse/expand without losing pin; Unpin and wait for buyer poll; interrupt network and verify shopping disabled until reconnect. Test sold-out state, long name, missing image, keyboard and360/390/430/768 widths. Buy Now stops before payment. Record device/browser/date and screenshots. No live payment, payouts, recurring billing or support-email configuration changes.

## Readiness
Build and automated regressions pass; saved candidate ready for owner review. Full visual and broadcast acceptance remains pending. Explicit approval required before production deployment. Rollback is prior savedversion129; no database rollback required.
