# Cash N Carry price-authority security review
14 October 2026. No production deployment or transaction made.

## Outcome
No exploitable buyer price-override defect was confirmed in the inspected flows. Existing server-authoritative pricing was retained. Added five behavioural regression tests in tests/price-tampering.test.mjs using the actual commerce and payment modules with isolated SQLite migrations and simulated Flutterwave HTTP responses. All197 automated tests pass; TypeScript passes. Application source/build inputs are unchanged from the verified version122 build; no new build is claimed.

## Endpoint and authority trace
- /api/commerce POST cart: persists product/variant/quantity only; ignores price fields; validates quantity and inventory. Cart reads join current products and variants rather than stored browser prices.
- /api/commerce POST checkout via commerce-extra.ts: direct Buy Now reads product and selected variant from DB; cart checkout reads user-owned cart rows. Live/pinned purchases use the same checkout. Client price, total, delivery fee, currency and discount override fields do not enter calculation. Seller eligibility, availability and delivery coverage checked.
- Live deal checkout: matching product/store/stream, server price, date range, status and remaining promotional allocation required. Expired references rejected. DB snapshot/inventory guards protect atomic checkout.
- Bundles: existing ordinary bundle product price is database-backed; checkout captures components and stock triggers enforce allocation. Existing bundle regressions pass. New dedicated browser bundle payment-tampering test not performed.
- Auctions: server validates bids, minimum increment, winner and resulting unpaid order. Existing actual API/SQLite regression verifies duplicate bid, invalid increment, winner price and duplicate settlement. Auction amount is an intentional bid input, not a product price override. No auction payment settlement activated.
- app/payments.ts initiation: server-created order total stored in payment record and sent as amount, NGN currency and server-generated tx_ref.
- /api/payments/verify: authenticated buyer ownership of reference checked; body amount is not trusted. Trusted server provider lookup validates transaction id, reference, currency, amount and optional configured merchant before paid state. Conditional writes and unique payment order references prevent duplicate settlement. Webhook uses same verification routine and existing hash validation.
- Product edit: owned store and selling permissions required; buyers cannot edit another seller's product.

## Before/after behavioural results
No failing application price-override case preceded a fix; baseline protections already pass. New tests extend coverage rather than represent a repaired vulnerability.

| Case | Actual isolated result |
|---|---|
| ₦20,000 product forged to ₦200; fee forged to₦0; currency USD | Stored order/payment/provider request remain₦21,500 NGN, fee₦1,500 |
| Cart request price1, quantity2; checkout total2 | Stored total₦41,500 using database price |
| Selected Black option forged to200 | Stored item price₦20,000; total₦21,500; unknown option rejected |
| Quantity -1,0,1.5,100 for direct purchase | Rejected; negative cart quantity rejected |
| Buyer product-edit request price1 | Rejected; seller price remains₦20,000 |
| Live price forged to1 | Valid stored deal₦15,000 + trusted fee₦1,500; expired timestamp rejected |
| Verified provider amount200/currencyUSD/wrong reference | Rejected; order remains pending |
| Repeat matching confirmed transaction | Paid response idempotent; one payment row and no extra stock debit |

Initial test fixture used an unsupported expired status and failed its database CHECK; corrected fixture uses actual expired timestamps. This was a test-data defect, not a production failure. Final targeted and complete suites pass.

## Browser evidence and limits
Actual production Chrome product page inspected: Mic₦1,000, Black option, delivery₦100 and purchase controls visible. No DOM mutation, storage manipulation or forged production checkout request was submitted, because these could create real order/payment records. Remote browser APIs do not expose an authorised Developer Tools manipulation workflow here. Do not interpret display-text editing as a change to server payable amount: targeted API tests establish calculation separately.

Simulated provider responses are not a genuine Flutterwave sandbox transaction. Owner-controlled staging/test payment access is still required for hosted checkout, real sandbox verification/webhook, browser storage/DOM manipulation and complete bundle/auction shopping acceptance. No physical-device test claimed. Production ingress/session permission matrix remains a broader security-review dependency. No new critical/high price-tampering finding established; this is scoped evidence, not proof against every attack.

## Changes and safety
Only tests/price-tampering.test.mjs and this report were added. No application/security/payment credential/settings/customer/order/schema mutation in production. Legitimate seller editing preserved. No deployment needed for behavioural test additions; no production deployment is authorised by this request. Retain these regressions for future pricing changes.
