# Deployment recovery — 13 October 2026

Version 100 deployed successfully. Version 101 failed with `incomplete input: SQLITE_ERROR`, before the premium UI changes. Versions 102 and 103 subsequently failed with the same message. Thus the problem predates the redesign.

The live database overview contained 50 tables and none of the competitive-feature tables, confirming that migration 0020 had not completed. Its three compound trigger bodies were simplified:

- Insert and update live-deal validation now each have a separate validation trigger and overlap trigger, with one statement per body.
- Deal reservation uses a BEFORE INSERT validation trigger and AFTER INSERT reservation trigger. Both run inside the same insertion transaction. An invalid deal snapshot aborts; valid snapshots increment reserved promotional quantity exactly once.
- The retained idempotent bootstrap definitions match the migration definitions.
- Migration 0019 was restored to its original formatting because it could already have been applied. No applied migration is intentionally rewritten.

The repair changes no product/order records, no payment processing, no recurring collection, no payout behaviour and no email settings. Existing uniqueness, seller activation and inventory controls are preserved.

Validation before publication: full suite 143 passed / 0 failed; TypeScript passed. Existing competitive-feature tests verify invalid/overlapping deals, promotional capacity, cancelled-order capacity restoration, bundle ownership/inventory/snapshot restoration, affiliate states, auctions and founding access. Production compilation and native deployment are the final checks. The precise backend failing statement was not returned; successful native deployment is needed to confirm the compatibility repair resolves the blocker.
