# Upload and livestream corrections — 15 October 2026

Authorised targeted production release. This is not completion of the full platform audit.

- Product photos optional for individual product creation/editing and bulk import; supplied images retain validation and ownership checks.
- Bulk preview includes device photo selection, bounded upload timeout and duplicate-upload guard. Remote URLs remain optional and are not loaded in preview.
- Daily authenticated seller upload cap raised from20 to100 files, retaining200MB/day,40MB/file,10attempts/minute, signature checks and atomic quota reservation/rollback. Quota error includes UTC reset and Retry-After.
- Legacy native endstream requests rejected rather than marking broadcast ended without stopping provider. Current provider-backed studio endpoint remains authoritative; external closure preserved.

Validation:230 automated tests passed,0failed; TypeScript noEmit passed; supported production build passed. New actual SQLite/API tests cover20 image-free technology fixtures, import idempotency, individual image-free creation, concurrent quota edge, storage rollback and native legacy-end protection.

Browser evidence before release: production homepage/product/cart/checkout, signed-in seller dashboard, camera-first studio unavailable-device state, More and Products sheets and top-X private preview exit observed. No order/payment submitted. No camera/mic hardware available. Genuine publisher/viewer, physical devices, full mobile width matrix, creator/unverified/admin fixture workflows, browser retest of new device picker remain unverified. Full lint backlog from earlier audit remains outstanding; this release does not certify full production readiness.

No database migration, live payment configuration, billing activation, payout, support-email, approved legal content or customer-order change.

Rollback: prior saved version131; no schema rollback required.
