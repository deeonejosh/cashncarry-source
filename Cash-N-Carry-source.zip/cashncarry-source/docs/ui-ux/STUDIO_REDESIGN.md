# Dedicated Live Studio redesign — 13 October 2026

Scope: `/workspace?tab=Broadcasts&studio=1`. This update changes presentation and entry/exit screens while preserving existing camera, broadcasting, eligibility, product pinning and connection recovery operations.

The URL has dedicated Cash N Carry branding, Explore Lives, a calm cream landing card, clear loading/sign-in/seller-access states, and Open camera / Scheduled Lives actions. After ending, the same card offers actual observed summary values, recorded analytics and another private preview. Account navigation and legacy broadcast-management forms are hidden only on this dedicated studio URL; Scheduled Lives opens the existing management page.

The portrait studio uses a centred phone-sized frame on desktop and a full-width safe-area-aware layout on mobile. Floating tools use consistent circles, visible labels and 44–46px targets. The private-preview badge differs from LIVE. Go Live is a prominent cream action; End Live uses a distinct destructive colour. Front-camera preview is mirrored for comfortable framing; CSS mirroring does not change outgoing canvas video. A permission/loading overlay explains the blank camera area. Camera-off state explains why Go Live is disabled.

Pinned product management, viewer replies, feedback, camera settings and product drawers have refined typography, spacing, surfaces and hierarchy. Settings and studio-tools sheets use meaningful titles. Recovery and confirmation callbacks remain unchanged. No payment, billing, payout, email or database changes.

Validation: 25 relevant live-control, camera-first and recovery tests passed; TypeScript passed. Production build and deployment are verified through the publication workflow. Actual rendered browser/device review is unavailable in this managed environment because the required control-browser capability is absent. This report does not claim screenshots, physical device testing or a perfect design score.
