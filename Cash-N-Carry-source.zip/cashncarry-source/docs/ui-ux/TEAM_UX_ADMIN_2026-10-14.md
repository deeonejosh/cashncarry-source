# Senior UI/UX and Admin Console UX review — 14 October 2026

## Evidence boundary
This specialist review inspects current source, CSS and the authenticated browser report for version 117. The team lead owns the current Chrome session and live retests. No new browser interaction, physical-device test or record mutation is claimed by this document. Current working-tree Product Bundles administration changes are visible but not yet certified by this specialist. The previous report's missing-bundle finding must therefore be reassessed after the team lead tests and publishes those changes.

Current source inventory: 32 page routes, 42 API route modules and 51 non-page/non-layout TSX modules. The latter is a module inventory, not a count of every internal reusable component. TEAM_ROUTE_INVENTORY_2026-10-14.json lists sources and imports; route presence never means acceptance passed. Conditional tabs are identified below and must be tested separately.

## Admin information architecture
/admin has Overview, Orders, Support & returns, Seller subscriptions/finances, Payments, Verification, Stores, Users, Products, Livestreams, Advertising, Moderation and Activity state implementations. The sidebar groups organise work sensibly and filter visibility by supplied permissions. Related protected routes are /admin/competitive, /admin/settings and /admin/email-templates. Competitive administration now has Founding Sellers, Live Deals, Creator Affiliates, Product Bundles and Auctions in the working tree. Settings groups services, business and operations, including deferred financial/email interfaces; these excluded integrations were not changed or tested here.

## Confirmed source defects provided to the lead
| ID | Severity | Source / reproduction | Expected / actual | Status |
|---|---|---|---|---|
| UX-ADMIN-01 | Medium | /admin; inspect sidebar and mobile selector | Advertising renderer and tab exist, but Ads is absent from navigation groups; the workflow requires knowing ?tab=Ads | Lead notified; correction and browser retest pending |
| UX-ADMIN-02 | Medium | /admin at <=850px | Sidebar disappears; mobile selector omits utility routes. Competitive features has no visible mobile entry from the console | Lead notified; responsive browser verification pending |
| UX-ADMIN-03 | Medium | /admin/competitive initial fetch rejection | Alert appears without Retry/Refresh; initial failure leaves a nonrecoverable shell until browser reload | Lead notified; error recovery correction pending |
| UX-ADMIN-04 | Low | /admin/settings initial /api/admin/settings rejection | Fetch catch writes generic role=status message, without retry; initial settings forms remain absent | Lead notified; excluded integrations must remain unchanged while improving load recovery |
| UX-ADMIN-05 | Low | /admin Overview under restricted role | Attention tasks and quick links are not permission-filtered although navigation is; users can enter inaccessible/empty sections. Backend permission gates still apply | Source confirmed; restricted-role browser test pending |

These are observed implementation problems, not allegations of successful privilege escalation. The lead should update their final state after fixes.

## Existing strengths confirmed in source
Main admin lists provide label-based search, status filtering, twenty-record client pagination and clear-filter recovery. Result counts expose matching records; API limits of 300 records and 100 livestreams are disclosed. This does not establish complete historical search or server pagination.

Verification revocation uses confirmation and a five-character reason aligned with its backend. The confirmation preserves focus, traps Tab, supports Escape when idle and shows errors. The shared ActionConfirmation uses native modal dialog semantics, labels/descriptions and reason constraints; saving prevents dismissal/duplicate submission. Buttons and settings links generally target at least 44px. Reduced-motion CSS disables refresh spinning. Forest-green actions, cream surfaces and compact cards support consistent presentation.

VerifiedSellerBadge is reusable and requires approved boolean/numeric authority; blue/white icon includes an accessible name and explanatory title. Source integration covers major seller identities. The administrator approve/revoke cycle, propagation, screen-reader explanation, long-name alignment and active broadcast header remain acceptance tests, not source passes.

## Outstanding acceptance
No physical Android/iPhone, full-width matrix, native mobile keyboard, measured screen-reader test or complete WCAG 2.2 AA audit has been performed in this specialist work. CSS rules and visible focus are supporting implementation evidence only. New-record creation, real approval/revocation, role-restricted navigation and nonempty competitive tables require approved fixtures. Genuine livestream video/audio is outside this source inspection.

No independent score increase is awarded. Production approval remains conditional/blocked until mandatory real-broadcast, mobile and controlled-role state-change tests have evidence. Financial/email exclusions should not count against UI/UX design scores, but commercial launch approval is separate.
