# Cash N Carry route and component inventory

Discovered 31 page routes, 143 TSX source modules and 58 livestream button/control declarations. Conditional controls are separate declarations. API routes are not public design pages. Inventory generation does not constitute browser testing.

| Route | Source | Direct components | Review |
|---|---|---|---|
| /account | app/account/page.tsx | app/account/auth-form.tsx, app/account/hub.tsx | Shared styling applied; visual review pending |
| /admin/competitive | app/admin/competitive/page.tsx | app/admin/competitive/panel.tsx | Shared styling applied; visual review pending |
| /admin/email-templates | app/admin/email-templates/page.tsx | app/brand-logo.tsx, app/admin/email-templates/panel.tsx | Shared styling applied; visual review pending |
| /admin | app/admin/page.tsx | app/brand-logo.tsx, app/admin/panel.tsx, app/admin/switch-account.tsx | Shared styling applied; visual review pending |
| /admin/settings | app/admin/settings/page.tsx | app/admin/access-panel.tsx, app/brand-logo.tsx, app/admin/settings/panel.tsx | Shared styling applied; visual review pending |
| /community-guidelines | app/community-guidelines/page.tsx | app/policy-page.tsx | Shared styling applied; visual review pending |
| /creator | app/creator/page.tsx | app/creator/panel.tsx | Shared styling applied; visual review pending |
| /delivery | app/delivery/page.tsx | app/policy-page.tsx | Shared styling applied; visual review pending |
| /forgot-password | app/forgot-password/page.tsx | app/account/auth-form.tsx | Shared styling applied; visual review pending |
| /help | app/help/page.tsx | app/customer-shell.tsx | Shared styling applied; visual review pending |
| /live-auctions | app/live-auctions/page.tsx | app/live-auctions/panel.tsx | Shared styling applied; visual review pending |
| /messages | app/messages/page.tsx | app/messages/panel.tsx, app/customer-shell.tsx | Shared styling applied; visual review pending |
| /order/[id] | app/order/[id]/page.tsx | app/customer-shell.tsx | Shared styling applied; visual review pending |
| / | app/page.tsx | app/welcome.tsx | Shared styling applied; visual review pending |
| /payment-return | app/payment-return/page.tsx | app/customer-shell.tsx | Shared styling applied; visual review pending |
| /policies/[id] | app/policies/[id]/page.tsx | Inline | Shared styling applied; visual review pending |
| /privacy | app/privacy/page.tsx | app/policy-page.tsx | Shared styling applied; visual review pending |
| /product/[id] | app/product/[id]/page.tsx | app/customer-shell.tsx, app/product-gallery.tsx, app/product-purchase.tsx, app/analytics-tracker.tsx | Shared styling applied; visual review pending |
| /refunds | app/refunds/page.tsx | app/policy-page.tsx | Shared styling applied; visual review pending |
| /seller/billing-return | app/seller/billing-return/page.tsx | Inline | Shared styling applied; visual review pending |
| /seller/competitive | app/seller/competitive/page.tsx | app/seller/competitive-panel.tsx | Shared styling applied; visual review pending |
| /seller/finance | app/seller/finance/page.tsx | app/seller/finance/panel.tsx | Shared styling applied; visual review pending |
| /seller | app/seller/page.tsx | Inline | Shared styling applied; visual review pending |
| /seller-terms | app/seller-terms/page.tsx | app/policy-page.tsx | Shared styling applied; visual review pending |
| /sign-in | app/sign-in/page.tsx | app/account/auth-form.tsx | Shared styling applied; visual review pending |
| /sign-up | app/sign-up/page.tsx | app/account/auth-form.tsx | Shared styling applied; visual review pending |
| /store/[id] | app/store/[id]/page.tsx | app/customer-shell.tsx, app/store-actions.tsx, app/store-product-actions.tsx, app/image-asset.tsx | Shared styling applied; visual review pending |
| /terms | app/terms/page.tsx | app/policy-page.tsx | Shared styling applied; visual review pending |
| /two-factor | app/two-factor/page.tsx | app/two-factor/form.tsx | Shared styling applied; visual review pending |
| /welcome | app/welcome/page.tsx | app/welcome.tsx | Shared styling applied; visual review pending |
| /workspace | app/workspace/page.tsx | app/seller/navigation.tsx, app/brand-logo.tsx, app/account/profile-editor.tsx, app/image-asset.tsx, app/live-overlay.tsx | Shared styling applied; visual review pending |

## Conditional interfaces

The root application contains Home, Market, Explore, Live, Orders and Seller views; product, store, cart, checkout, review, cancellation, filters, notification and seller forms are modal/conditional interfaces. The workspace includes account/profile, addresses, notification preferences, saved products, delivery, broadcasts/setup/live studio, orders and support. Seller finance includes Activation, Subscription, Earnings, Withdrawals, Bank account and History. Seller competitive includes Live Deals, Analytics, Bundles, Affiliates, Auctions and Founding Seller. Admin panel includes Overview, Seller Subscriptions & Payouts, Payments, Orders, Support, Verification, Stores, Users, Products, Live, Ads, Reports and Audit log, filtered by role permissions. Admin competitive includes Founding Sellers, Live Deals, Creator Affiliates and Auctions. Admin settings includes platform, email, streaming and legal approval interfaces.

## Complete component source inventory

| Module | Exports | Direct component dependencies |
|---|---|---|
| app/account/auth-form.tsx | AuthForm | app/brand-logo.tsx, app/account/sessions.tsx |
| app/account/hub.tsx | AccountHub | app/customer-shell.tsx, app/account/sessions.tsx |
| app/account/page.tsx | Account | app/account/auth-form.tsx, app/account/hub.tsx |
| app/account/profile-editor.tsx | ProfileEditor | Inline or third party |
| app/account/sessions.tsx | Sessions | Inline or third party |
| app/action-confirmation.tsx | ActionConfirmation | Inline or third party |
| app/admin/access-panel.tsx | AccessPanel | Inline or third party |
| app/admin/competitive/page.tsx | Page | app/admin/competitive/panel.tsx |
| app/admin/competitive/panel.tsx | CompetitiveAdminPanel | app/action-confirmation.tsx |
| app/admin/email-templates/page.tsx | Page | app/brand-logo.tsx, app/admin/email-templates/panel.tsx |
| app/admin/email-templates/panel.tsx | EmailTemplatePanel | Inline or third party |
| app/admin/finance-panel.tsx | FinancePanel | Inline or third party |
| app/admin/page.tsx | AdminPage | app/brand-logo.tsx, app/admin/panel.tsx, app/admin/switch-account.tsx |
| app/admin/panel.tsx | AdminPanel | app/admin/finance-panel.tsx, app/admin/seller-finance-panel.tsx, app/image-asset.tsx, app/brand-logo.tsx |
| app/admin/seller-finance-panel.tsx | SellerFinanceAdmin | Inline or third party |
| app/admin/settings/email.tsx | EmailSettings | Inline or third party |
| app/admin/settings/page.tsx | Page | app/admin/access-panel.tsx, app/brand-logo.tsx, app/admin/settings/panel.tsx |
| app/admin/settings/panel.tsx | Settings | app/admin/settings/streaming.tsx, app/admin/settings/email.tsx, app/admin/settings/policies.tsx |
| app/admin/settings/policies.tsx | PolicyManagement | Inline or third party |
| app/admin/settings/streaming.tsx | StreamingSettings | Inline or third party |
| app/admin/switch-account.tsx | SwitchAccount | Inline or third party |
| app/analytics-consent.tsx | AnalyticsConsent | Inline or third party |
| app/analytics-tracker.tsx | AnalyticsTracker | Inline or third party |
| app/brand-logo.tsx | BrandLogo | Inline or third party |
| app/community-guidelines/page.tsx | Page | app/policy-page.tsx |
| app/creator/page.tsx | CreatorPage | app/creator/panel.tsx |
| app/creator/panel.tsx | CreatorPanel | app/customer-shell.tsx |
| app/customer-shell.tsx | CustomerHeader, CustomerNavigation, PageHeading | app/brand-logo.tsx |
| app/delivery/page.tsx | Page | app/policy-page.tsx |
| app/error.tsx | ErrorPage | Inline or third party |
| app/forgot-password/page.tsx | Page | app/account/auth-form.tsx |
| app/help/page.tsx | Help | app/customer-shell.tsx |
| app/image-asset.tsx | ImageAsset | Inline or third party |
| app/layout.tsx | RootLayout | app/skip-link.tsx, app/analytics-consent.tsx |
| app/live-auctions/page.tsx | Page | app/live-auctions/panel.tsx |
| app/live-auctions/panel.tsx | LiveAuctions | Inline or third party |
| app/live-overlay.tsx | LiveSheet, LiveAction, ElapsedBroadcast | Inline or third party |
| app/live-shopping.tsx | LiveShopping | app/live-overlay.tsx, app/webrtc-video.tsx, app/schedule-info.tsx, app/live-video.tsx, app/image-asset.tsx |
| app/live-video.tsx | LiveVideo | Inline or third party |
| app/messages/page.tsx | Page | app/messages/panel.tsx, app/customer-shell.tsx |
| app/messages/panel.tsx | Messages | Inline or third party |
| app/not-found.tsx | NotFound | Inline or third party |
| app/notification-panel.tsx | NotificationPanel | Inline or third party |
| app/order/[id]/page.tsx | Order | app/customer-shell.tsx |
| app/page.tsx | Page | app/welcome.tsx |
| app/payment-return/page.tsx | PaymentReturn | app/customer-shell.tsx |
| app/policies/[id]/page.tsx | LegacyPolicy | Inline or third party |
| app/policy-page.tsx | policyMetadata, PolicyPage | app/customer-shell.tsx |
| app/privacy/page.tsx | Page | app/policy-page.tsx |
| app/product/[id]/page.tsx | generateMetadata, Product | app/customer-shell.tsx, app/product-gallery.tsx, app/product-purchase.tsx, app/analytics-tracker.tsx |
| app/product-gallery.tsx | ProductGallery | app/image-asset.tsx |
| app/product-options.tsx | ProductOptions | app/product-photo.tsx |
| app/product-photo.tsx | ProductPhoto | Inline or third party |
| app/product-purchase.tsx | ProductPurchase | Inline or third party |
| app/refunds/page.tsx | Page | app/policy-page.tsx |
| app/revibe.tsx | ReVibe | app/seller/navigation.tsx, app/seller/activation-card.tsx, app/image-asset.tsx, app/shopping-design.tsx, app/brand-logo.tsx, app/notification-panel.tsx, app/schedule-info.tsx, app/product-options.tsx, app/product-photo.tsx, app/webrtc-video.tsx, app/live-video.tsx, app/live-shopping.tsx |
| app/schedule-info.tsx | ScheduleInfo | Inline or third party |
| app/seller/activation-card.tsx | SellerActivationCard | app/seller/subscription-summary.tsx |
| app/seller/billing-return/page.tsx | BillingReturn | Inline or third party |
| app/seller/competitive/page.tsx | Page | app/seller/competitive-panel.tsx |
| app/seller/competitive-panel.tsx | SellerCompetitivePanel | app/seller/navigation.tsx, app/product-photo.tsx |
| app/seller/finance/page.tsx | Page | app/seller/finance/panel.tsx |
| app/seller/finance/panel.tsx | SellerFinancePanel | app/brand-logo.tsx, app/seller/navigation.tsx, app/seller/subscription-summary.tsx |
| app/seller/navigation.tsx | SellerNavigation | Inline or third party |
| app/seller/page.tsx | SellerCentre | Inline or third party |
| app/seller/subscription-summary.tsx | SubscriptionSummary | Inline or third party |
| app/seller-terms/page.tsx | Page | app/policy-page.tsx |
| app/shopping-design.tsx | ShoppingHero, ShopCategories, SellerInvitation, ShoppingGuide | app/image-asset.tsx |
| app/sign-in/page.tsx | Page | app/account/auth-form.tsx |
| app/sign-up/page.tsx | Page | app/account/auth-form.tsx |
| app/skip-link.tsx | SkipLink | Inline or third party |
| app/store/[id]/page.tsx | generateMetadata, Store | app/customer-shell.tsx, app/store-actions.tsx, app/store-product-actions.tsx, app/image-asset.tsx |
| app/store-actions.tsx | StoreActions | Inline or third party |
| app/store-product-actions.tsx | StoreProductActions | Inline or third party |
| app/terms/page.tsx | Page | app/policy-page.tsx |
| app/two-factor/form.tsx | MfaForm | app/brand-logo.tsx |
| app/two-factor/page.tsx | Page | app/two-factor/form.tsx |
| app/webrtc-video.tsx | WebRTCVideo | Inline or third party |
| app/welcome/page.tsx | Page | app/welcome.tsx |
| app/welcome.tsx | Welcome, Entry | app/brand-logo.tsx, app/revibe.tsx |
| app/workspace/page.tsx | Workspace | app/seller/navigation.tsx, app/brand-logo.tsx, app/account/profile-editor.tsx, app/image-asset.tsx, app/live-overlay.tsx |
| components/connector-error.tsx | ConnectorError | Inline or third party |
| components/ui/accordion.tsx | See module | Inline or third party |
| components/ui/alert-dialog.tsx | See module | Inline or third party |
| components/ui/alert.tsx | See module | Inline or third party |
| components/ui/aspect-ratio.tsx | See module | Inline or third party |
| components/ui/attachment.tsx | See module | Inline or third party |
| components/ui/avatar.tsx | See module | Inline or third party |
| components/ui/badge.tsx | See module | Inline or third party |
| components/ui/breadcrumb.tsx | See module | Inline or third party |
| components/ui/bubble.tsx | See module | Inline or third party |
| components/ui/button-group.tsx | See module | Inline or third party |
| components/ui/button.tsx | See module | Inline or third party |
| components/ui/calendar.tsx | See module | Inline or third party |
| components/ui/card.tsx | See module | Inline or third party |
| components/ui/carousel.tsx | See module | Inline or third party |
| components/ui/chart.tsx | See module | Inline or third party |
| components/ui/checkbox.tsx | See module | Inline or third party |
| components/ui/collapsible.tsx | See module | Inline or third party |
| components/ui/combobox.tsx | See module | Inline or third party |
| components/ui/command.tsx | See module | Inline or third party |
| components/ui/context-menu.tsx | See module | Inline or third party |
| components/ui/dialog.tsx | See module | Inline or third party |
| components/ui/direction.tsx | See module | Inline or third party |
| components/ui/drawer.tsx | See module | Inline or third party |
| components/ui/dropdown-menu.tsx | See module | Inline or third party |
| components/ui/empty.tsx | See module | Inline or third party |
| components/ui/field.tsx | See module | Inline or third party |
| components/ui/form.tsx | See module | Inline or third party |
| components/ui/hover-card.tsx | See module | Inline or third party |
| components/ui/input-group.tsx | See module | Inline or third party |
| components/ui/input-otp.tsx | See module | Inline or third party |
| components/ui/input.tsx | See module | Inline or third party |
| components/ui/item.tsx | See module | Inline or third party |
| components/ui/kbd.tsx | See module | Inline or third party |
| components/ui/label.tsx | See module | Inline or third party |
| components/ui/marker.tsx | See module | Inline or third party |
| components/ui/menubar.tsx | See module | Inline or third party |
| components/ui/message-scroller.tsx | See module | Inline or third party |
| components/ui/message.tsx | See module | Inline or third party |
| components/ui/native-select.tsx | See module | Inline or third party |
| components/ui/navigation-menu.tsx | See module | Inline or third party |
| components/ui/pagination.tsx | See module | Inline or third party |
| components/ui/popover.tsx | See module | Inline or third party |
| components/ui/progress.tsx | See module | Inline or third party |
| components/ui/radio-group.tsx | See module | Inline or third party |
| components/ui/resizable.tsx | See module | Inline or third party |
| components/ui/scroll-area.tsx | See module | Inline or third party |
| components/ui/select.tsx | See module | Inline or third party |
| components/ui/separator.tsx | See module | Inline or third party |
| components/ui/sheet.tsx | See module | Inline or third party |
| components/ui/sidebar.tsx | See module | Inline or third party |
| components/ui/skeleton.tsx | See module | Inline or third party |
| components/ui/slider.tsx | See module | Inline or third party |
| components/ui/sonner.tsx | See module | Inline or third party |
| components/ui/spinner.tsx | See module | Inline or third party |
| components/ui/switch.tsx | See module | Inline or third party |
| components/ui/table.tsx | See module | Inline or third party |
| components/ui/tabs.tsx | See module | Inline or third party |
| components/ui/textarea.tsx | See module | Inline or third party |
| components/ui/toggle-group.tsx | See module | Inline or third party |
| components/ui/toggle.tsx | See module | Inline or third party |
| components/ui/tooltip.tsx | See module | Inline or third party |

## Livestream control inventory

| Source line | Control | Expected handler | Device/browser result |
|---|---|---|
| app/live-shopping.tsx:309 | Browse live streams | {onClose} | Pending; consult handler test report |
| app/live-shopping.tsx:317 | Watch replay  | {() => setReplayPlaying(true)} | Pending; consult handler test report |
| app/live-shopping.tsx:327 | Browse live streams | {onClose} | Pending; consult handler test report |
| app/live-shopping.tsx:357 |  {data.follows.some((f: any) => f.store === stream.store) ? "Following" : "Follow"}  | {() =>                 act(                   {                     action: "follow",                     store: stream.store,                     follow: !data | Pending; consult handler test report |
| app/live-shopping.tsx:378 | "Close broadcast" | {onClose} | Pending; consult handler test report |
| app/live-shopping.tsx:400 | {               (liked ? "Unlike broadcast" : "Like broadcast") +               (likes === null ? "" | {reactToStream} | Pending; consult handler test report |
| app/live-shopping.tsx:418 | "Share broadcast" | {share} | Pending; consult handler test report |
| app/live-shopping.tsx:425 | {`Browse ${products.length} featured ${products.length === 1 ? "product" : "products"}`} | {() => setSheet("products")} | Pending; consult handler test report |
| app/live-shopping.tsx:433 | "More broadcast options" | {() => setSheet("more")} | Pending; consult handler test report |
| app/live-shopping.tsx:456 | {pinCollapsed ? "Expand pinned product" : "Collapse pinned product"} | {() => setPinCollapsed(v => !v)} | Pending; consult handler test report |
| app/live-shopping.tsx:460 | {`Buy Now: ${pinned.name}. Choose product options`} | {() => {                 trackAnalyticsEvent("product_click",pinned.store,{product:pinned.id,stream:stream.id});                 setSelected(pinned.id);         | Pending; consult handler test report |
| app/live-shopping.tsx:505 | "Send question" | Containing form submit or shared callback | Pending; consult handler test report |
| app/live-shopping.tsx:509 | {`Open cart, ${cartQuantity} ${cartQuantity === 1 ? "item" : "items"}`} | {openCart} | Pending; consult handler test report |
| app/live-shopping.tsx:526 |  <ShoppingCart /> Cart · {cartQuantity}  | {openCart} | Pending; consult handler test report |
| app/live-shopping.tsx:540 | "Dismiss message" | {() => setFeedback("")} | Pending; consult handler test report |
| app/live-shopping.tsx:566 |  <Maximize /> Enter fullscreen  | {() =>                     viewportRef.current                       ?.requestFullscreen()                       .then(() => setSheet(""))                       | Pending; consult handler test report |
| app/live-shopping.tsx:620 |  <Flag /> Submit report  | Containing form submit or shared callback | Pending; consult handler test report |
| app/live-shopping.tsx:630 |  <ImageAsset src={item.image} alt={item.name} /> <span> <strong>{item.name}</strong> {dealFor(item.i | {() => {                       setSelected(item.id);                       setSheet("product");                     }} | Pending; consult handler test report |
| app/live-shopping.tsx:716 | Buy Now  | {buyNowProduct} | Pending; consult handler test report |
| app/live-shopping.tsx:723 | Add to Cart  | {addProduct} | Pending; consult handler test report |
| app/live-shopping.tsx:730 | View cart and checkout  | {() => {                   setDirectPurchase(null);                   setCheckoutKey(crypto.randomUUID());                   setSheet("checkout");               | Pending; consult handler test report |
| app/live-shopping.tsx:739 | All featured products  | {() => setSheet("products")} | Pending; consult handler test report |
| app/live-shopping.tsx:831 | Place order  | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:699 | Retry  | {() => load().catch((e) => setMessage(e.message))} | Pending; consult handler test report |
| app/workspace/page.tsx:749 |  {({ Delivery: "Shipping", Broadcasts: "Broadcast studio", Sales: "Payments & refunds", Account: "Pr | {() => {                     if (hostOpen && t !== "Broadcasts") {                       if (                         (active // starting) &&                    | Pending; consult handler test report |
| app/workspace/page.tsx:806 | Remove  | {() =>                             request({                               action: "favourite",                               product: f.product,                | Pending; consult handler test report |
| app/workspace/page.tsx:832 | Delete  | {() =>                         request({ action: "address", id: a.id, remove: true })                       } | Pending; consult handler test report |
| app/workspace/page.tsx:847 | Save address | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:881 | Save preferences | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:990 | Save shipping settings | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:1086 | "Close broadcast" | {() =>                           active // starting ? setHostSheet("leave") : stop()                         } | Pending; consult handler test report |
| app/workspace/page.tsx:1128 | {                           muted ? "Unmute microphone" : "Mute microphone"                          | {() => {                           const next = !muted;                           camera.current                             ?.getAudioTracks()                  | Pending; consult handler test report |
| app/workspace/page.tsx:1151 | "Switch camera" | {switchCamera} | Pending; consult handler test report |
| app/workspace/page.tsx:1165 | "Manage broadcast products" | {() => setHostSheet("products")} | Pending; consult handler test report |
| app/workspace/page.tsx:1172 | "More host options" | {() => setHostSheet("more")} | Pending; consult handler test report |
| app/workspace/page.tsx:1215 | "Manage pinned product" | {() => setHostSheet("products")} | Pending; consult handler test report |
| app/workspace/page.tsx:1246 | "Send reply" | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:1261 | Go Live  | {() => start(previewId)} | Pending; consult handler test report |
| app/workspace/page.tsx:1268 | Cancel preview  | {() => stop()} | Pending; consult handler test report |
| app/workspace/page.tsx:1273 |  {starting ? "Cancel connection" : "End Live"}  | {() => {                               if (                                 confirm(                                   starting                                  | Pending; consult handler test report |
| app/workspace/page.tsx:1357 | Hide message  | {async () => {                                         if (                                           await request({                                            | Pending; consult handler test report |
| app/workspace/page.tsx:1375 | Mute viewer  | {async () => {                                         if (                                           confirm(                                             "Mute | Pending; consult handler test report |
| app/workspace/page.tsx:1414 | Continue broadcasting  | {() => setHostSheet("")} | Pending; consult handler test report |
| app/workspace/page.tsx:1420 | End Live and close  | {() => {                                 if (                                   confirm(                                     "End this broadcast for all viewers | Pending; consult handler test report |
| app/workspace/page.tsx:1436 | Moderate comments  | {() => setHostSheet("moderation")} | Pending; consult handler test report |
| app/workspace/page.tsx:1440 |  <Maximize /> Enter fullscreen  | {(e) => {                                   const stage = e.currentTarget.closest(                                     ".host-live-stage",                       | Pending; consult handler test report |
| app/workspace/page.tsx:1461 | Closing and leaving  | {() => setHostSheet("leave")} | Pending; consult handler test report |
| app/workspace/page.tsx:1486 | Preview camera &amp; microphone  | {() => previewCamera(s.id)} | Pending; consult handler test report |
| app/workspace/page.tsx:1499 | End session  | {() =>                           s.provider === "native"                             ? confirm("End this session?")                               ? broadcast.cu | Pending; consult handler test report |
| app/workspace/page.tsx:1560 | Preview camera  | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:1588 | Schedule | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:1598 | Share Watch on TikTok link | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:1611 | {({placed: "Confirm order", confirmed: "Mark shipped", shipped: "Mark delivered"} as Record<string,s | {() => request({action: "status", id: o.id, status: ({placed: "confirmed", confirmed: "shipped", shipped: "delivered"} as Record<string,string>)[o.status]})} | Pending; consult handler test report |
| app/workspace/page.tsx:1621 | Save shipment details | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:1651 | Request refund review | Containing form submit or shared callback | Pending; consult handler test report |
| app/workspace/page.tsx:1671 | Submit case | Containing form submit or shared callback | Pending; consult handler test report |
| app/live-overlay.tsx:58 | {"Close " + title} | {onClose} | Pending; consult handler test report |
| app/live-overlay.tsx:78 | {label} | Containing form submit or shared callback | Pending; consult handler test report |
