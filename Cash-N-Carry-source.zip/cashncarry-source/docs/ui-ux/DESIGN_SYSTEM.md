# Cash N Carry premium interface specification

Implemented 13 October 2026. The existing brand and tagline are retained. Tokens and application styling live in `app/premium.css`, loaded after the retained base and design-system styles by `app/layout.tsx`. Existing classes and commerce callbacks are retained.

## Identity and semantic colours

| Token | Value | Use |
|---|---|---|
| cream / bg | #FFF8EF | Warm page backgrounds and live shopping sheets |
| forest / primary | #164B35 | Purchase controls, navigation selection, headings |
| forest-hover | #103B29 | Primary hover |
| forest-soft | #EDF3ED | Selected surfaces and account summary |
| terracotta / accent | #B94D32 | Live discovery, live status and reactions |
| ochre | #D4A574 | Founding programme and auction accents |
| indigo | #4338CA | Focus indicator |
| charcoal / ink | #1F2937 | Body text |
| surface-raised | #FFFFFF | Cards, inputs and dashboards |
| surface-muted | #F4F1E9 | Image and secondary surfaces |
| danger | #A32F2F | Form errors |
| warning | #77500F | Warning text |
| border-control | #89988E | Input boundaries |

Measured primary combinations pass normal-text AA: forest/white 10.04:1; terracotta/white 5.04:1; charcoal/cream 13.93:1; muted/cream 5.36:1. This is token-level verification, not whole-page WCAG certification. Ochre is a decorative accent, not low-contrast body text.

## Typography and layout

The stack uses Inter when present, Segoe UI and Arial as fallbacks; no additional font request or heavy dependency is introduced. Body text is 16px with 1.5 line height. Hero type uses clamp(2.25rem,4.1vw,3.65rem), with a mobile 2–2.65rem scale. Product titles use two lines, 15px desktop and 13px mobile; purchase actions retain 44px targets. Money uses tabular numerals. Dashboard values use stronger size and forest contrast.

Spacing scale: 4, 8, 12, 16, 20, 24, 32, 40, 48px. Corner radii: 10px controls, 16px ordinary cards, 24px primary panels, 999px pills. Card shadows are intentionally light; modal shadows communicate elevation. Icons normally use 16–24px drawing sizes within 44px controls.

Responsive rules target 374px, 767px, 1024px and 1440px boundaries; existing 900px/1100px rules remain. These cover the requested range in source, but individual widths 320,360,375,390,414,768,1024,1280,1440 are **not visually tested**.

## Interaction conventions

- Buy Now is the primary forest action; Add to Cart is a bordered secondary action.
- Product variants remain mandatory where applicable. Existing quantity, stock, cart and checkout validation is retained.
- Search has a visible focus-within ring. Conversation search filters actual conversation names locally.
- All live rail buttons have a default accessible name and tooltip, while explicit labels still override defaults.
- The pinned live product can collapse; active deal prices and remaining promotional stock use real loaded records.
- Shopping sheets preserve broadcast state. Underlying broadcast controls are inert while a sheet is open.
- Admin competitive decisions use a native modal dialog, cancel action, reason field and audit submission. Failed decisions remain in the dialog with an alert.
- Creator submissions and partnership decisions have an in-flight lock, error feedback and refreshed API data.
- A 140ms control transition and 220ms reaction animation provide brief feedback. Existing global reduced-motion rules suppress animation.
- Sticky mobile navigation and safe-area padding remain in the existing shells. Live video continues to use the existing portrait pipeline.

## Component surfaces

Shared presentation covers customer headers/navigation, category tiles, marketplace product cards, account lists, authentication forms, product details, cart rows, purchase controls, seller navigation, KPI panels, competitive forms/records, financial summaries, admin navigation/tables, messaging, help/legal pages, live rails/pins/sheets and creator dashboard cards. The existing UI primitives remain in `components/ui`; this update does not create a parallel component library.

States inherited from the working application include empty/loading/error/success, stream connecting/offline/ended/replay, disabled stock and variants, seller activation restrictions and expired or inactive features. No synthetic metrics or fake testimonials are added.
