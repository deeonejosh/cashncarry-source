# Security and backend QA review — 14 October 2026

Scope: non-destructive source review plus isolated Node/SQLite/Better Auth regressions. This is not a penetration-test certification. Production browser checks are performed separately by the QA lead. No production mutations or credentials were used by this reviewer.

## Evidence

Command: `node --test tests/admin-access-gate.test.mjs tests/admin-mfa.test.mjs tests/chatgpt-mfa-challenge.test.mjs tests/verified-seller-badge.test.mjs tests/media.test.mjs tests/commerce.test.mjs tests/competitive-features.test.mjs`.

Result: 18 tests passed, 0 failed. Some fixture files contain many assertions within a single test; this is the runner's exact test count. Provider/production coverage must not be inferred from fixtures.

| Area | Finding | Status |
|---|---|---|
| ChatGPT admin MFA bridge | Requires platform-authenticated identity, assigned admin role, valid origin, non-suspension, matching verified email and an enrolled authenticator. Creates only a signed pending challenge expiring in ten minutes plus attempt counter; no account or authenticated session is created by the bridge. | Source and isolated bridge regressions passed |
| Admin access | Role assignment alone is insufficient. Gate requires matching verified Better Auth identity, enabled MFA, explicit recorded session proof with bounded lifetime and non-suspension. | Gate regression passed; QA lead production sign-in evidence remains separate |
| MFA provider | Real Better Auth library tests exercise enrolment, invalid-code denial, verification and single-use recovery codes. | Isolated provider test passed; bridge endpoint test uses mocked context |
| Verification badges | Sellers cannot set the store verification flag through storefront/product mutation fields. Admin approval/revocation paths enforce verification permission. Revocation atomically clears flag and records actor/reason; existing authoritative flag is used. | Isolated strict badge, permission and SQLite mutation tests passed |
| Ownership | Product updates, archiving and stream pinning scope records to the authenticated seller's store. Cart/order operations are buyer-scoped. Affiliate pinning requires approved partnerships. | Inspected; commerce fixture assertions passed |
| Private files | Verification documents require owner or verification-admin access and download with no-store/nosniff. Message attachment retrieval checks authorised conversation membership, adds sandbox CSP and no-store. | Source inspected; verification outsider denial fixture passed; message browser retrieval not independently tested |
| Public uploads | Authenticated active-store owner required; suspended profiles denied. Allowlisted media types, magic bytes, 40 MB limit, atomic daily quota, opaque keys and ownership checks on publishing. | Media fixture passed; physical image/video uploads not performed |
| Auction/competitive state | Fixtures validate authenticated bids, request deduplication, unpaid winner orders, bundle ownership/inventory and admin-approved founding eligibility. | Isolated fixture coverage passed; production multirole/concurrency acceptance remains outstanding |

## Confirmed defects

No new confirmed exploitable critical or high-severity issue was established in this scoped source review. That does not imply absence of unknown vulnerabilities. No application security correction was made solely on speculation.

## Outstanding security verification

1. Confirm the hosting ingress strips or overwrites client-supplied `oai-authenticated-*` headers. The application intentionally trusts Dispatch identity headers; local source cannot establish this infrastructure property. This is a dependency verification, not a demonstrated spoofing exploit. Use an authorised unauthenticated test request at public ingress and confirm the resulting request remains unauthenticated; never target customer records.
2. Run controlled buyer, unverified seller, creator, support, finance and moderator browser sessions against protected interfaces and ordinary application actions. Owner MFA success does not prove every role boundary.
3. Perform approve/revoke verification with an explicitly disposable seller account and verify all public badge surfaces refresh. Existing atomic/API regressions do not substitute for browser acceptance.
4. Complete physical-device publishing/viewing, provider session termination and network recovery. Source/fixture media checks do not demonstrate real broadcasting.
5. Review backup/recovery of enrolled admin MFA and expiry behavior using controlled accounts. Do not disable MFA to resolve access friction.

Security approval: **conditional / incomplete**, pending ingress trust-boundary and multirole production verification. No disruptive requests, production data modification, payment/payout/billing/email configuration changes or legal edits were performed.
