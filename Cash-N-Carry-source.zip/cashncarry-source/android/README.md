# Cash N Carry Android project

This is Android **source**, generated with GoogleChromeLabs Bubblewrap 1.27.0. It is not an APK or a signed Play Store upload bundle. It launches the existing Cash N Carry HTTPS website as a Trusted Web Activity, preserving browser-based authentication, shopping and streaming. No native payment or background-broadcast capability has been added.

## Configuration

- App name: Cash N Carry; approved existing icon and cream/forest-green launch colours.
- Website: https://revibe-commerce.ogundiyatemidayo1.chatgpt.site
- Proposed application ID: `site.chatgpt.ogundiyatemidayo1.cashncarry`. Confirm this ID in Play Console before the first upload; it becomes permanent after publication.
- Version: 1.0.0, code 1. Compile/target Android API 36; minimum API 21.
- Browser fallback: Custom Tabs, with visible browser identity. Only the Cash N Carry origin is trusted. Sign-in/payment provider sites retain their browser UI.
- No location, notification, billing or background service feature is configured.
- The project contains no upload/signing keys or passwords.

## Build and sign on your computer

1. Install Android Studio and SDK Platform 36. Open this `android` directory, let Gradle sync and accept the Android SDK licences yourself.
2. Confirm `applicationId` and `namespace` in `app/build.gradle` match your intended app ID. Keep generated Java package paths aligned if changing it; alternatively change `packageId` in `twa-manifest.json` and regenerate with Bubblewrap.
3. Connect an Android phone and test a debug build. Without certificate association, a browser toolbar is expected. For a local debug install, add its debug signing certificate SHA-256 in the website settings if needed; never treat it as the Play signing certificate.
4. Use Android Studio → Build → Generate Signed App Bundle / APK → Android App Bundle. Create or select **your own upload key**. Store it and passwords securely outside Git and chat. Output is normally `app/release/app-release.aab`.
5. Create the app in your Play Console account and use Play App Signing. Upload the bundle to Internal testing first.
6. Copy App integrity → **App signing key certificate → SHA-256**. In the website's Admin Settings → Android app, confirm the package ID and publish this public fingerprint. The website will serve it at `/.well-known/assetlinks.json`. The upload certificate alone will not verify Play-installed builds. If retaining local testing, add its separate certificate on another line.
7. Install the Play testing build and confirm the toolbar disappears on the verified website origin. Verify external sign-in/payment navigation and return to the app. Do not list Flutterwave or ChatGPT as trusted origins without their verified reciprocal association.

## Release checks and missing owner information

Test small/large Android phones; anonymous browsing; real sign-in, registration/recovery after sender setup; cart persistence; stock and delivery validation; provider-sandbox checkout with independently verified orders; seller/admin role isolation; camera/mic permissions and denial; actual host-to-viewer portrait broadcast; camera switching/rotation/reconnect; keyboard; sheets; Back/close/end confirmation; offline and app resume. Background hosting is not guaranteed; keep the broadcast screen open.

Complete legal operator, support contact and policy drafts before store submission. Confirm the disputed seller location/category/product identity. In Play Console supply accurate Data safety, app access/reviewer instructions, content rating, account-deletion policy and required deletion routes, and moderation controls for user-generated content. Do not claim deletion, offline shopping, native notifications or background streaming that is not implemented. Use real app screenshots after device testing; none have been fabricated.

Google Play requires a developer account, identity/device verification as applicable, and store review. New qualifying personal accounts require a closed test before production access. Store acceptance is not guaranteed.

## Verification completed here

- Offline source generation from the existing approved icon assets succeeded.
- Target SDK 36 and package/origin configuration inspected.
- Website association validation and admin permissions tested with isolated records; no production certificate was invented.
- Android build attempt failed while downloading Gradle because this environment cannot reach the distribution host. Android SDK and an emulator/device are also unavailable. No compiled APK/AAB or Android runtime test is claimed.

## Regeneration

The companion `android-tools` directory pins Bubblewrap core. From that directory run `npm install`, then `npm run generate`. It regenerates source from repository icon assets, without fetching private site/account data. It will overwrite generated Android source, so preserve intentional native changes before regeneration. `twa-manifest.json` contains public configuration only.

Upstream generated templates retain Google's Apache-2.0 notices. Source: https://github.com/GoogleChromeLabs/bubblewrap .

## Connected website workflows

The TWA reuses the hosted website and its backend; no second account, cart, product or order database is created. Bottom navigation is Home, Live, Shop, Account. Account opens the shared `/seller` entry (sign-in return preserved) and exposes `/admin` only when the server returns the owner/admin flag. The protected web console remains the initial Android admin experience. Product, store and broadcast links remain on the verified origin and use the website routes.

Camera/microphone permissions are requested by the existing seller preview flow. Notifications have not been added to the Android package; no notification permission or background broadcasting is promised. Offline and error handling currently use the website/browser behavior. Phone camera, keyboard, TWA authentication redirects, app links, offline behavior and Play build require physical-device testing after signing and association setup. Scoped delegated admin roles/MFA are not implemented; current console access is restricted to the configured owner identity.
