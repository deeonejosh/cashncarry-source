declare namespace Cloudflare {
  interface Env {
    SUPPORT_EMAIL?: string;
    MAINTENANCE_TOKEN_SHA256?: string;
    REVIBE_ADMIN_EMAIL?: string;
    BETTER_AUTH_SECRET?: string;
    SITE_URL?: string;
    RESEND_API_KEY?: string;
    RESEND_WEBHOOK_SECRET?: string;
    EMAIL_FROM?: string;
    FLW_SECRET_KEY?: string;
    FLW_WEBHOOK_HASH?: string;
    FLW_MODE?: string;
    FLW_MERCHANT_ACCOUNT_ID?: string;
    FLW_TEST_MERCHANT_ACCOUNT_ID?: string;
    FLW_TEST_SECRET_KEY?: string;
    FLW_LIVE_APPROVED?: string;
    STREAM_CONFIG_KEY?: string;
    STREAM_ACCOUNT_ID?: string;
    STREAM_API_TOKEN?: string;
    DB?: D1Database;
    BUCKET?: R2Bucket;
  }
}
