import { readFileSync, readdirSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import ts from "typescript";
function walk(root) { return readdirSync(root, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(root,e.name)) : [path.join(root,e.name)]); }
const files = [...walk('app'), ...walk('components')].filter(p => p.endsWith('.tsx'));
const components = files.map(file => {
 const source = readFileSync(file,'utf8');
 const imports = [...source.matchAll(/from\s+["'](\.[^"']+)["']/g)].map(m => path.normalize(path.join(path.dirname(file),m[1]))).filter(p => files.includes(p+'.tsx')).map(p => p+'.tsx');
 return { file, imports, exports: [...source.matchAll(/export\s+(?:default\s+)?(?:async\s+)?function\s+(\w+)/g)].map(m=>m[1]), sharedPresentation: ['app/globals.css','app/design-system.css','app/premium.css'], browserReview: 'Not performed' };
});
const routes=files.filter(file=>file.endsWith('/page.tsx')).map(file=>({ route: '/'+path.dirname(file).replace(/^app\/?/,'').replace(/\([^/]+\)\/?/g,''), file, directComponents: components.find(c=>c.file===file).imports, access: /getChatGPTUser|redirect\("\/sign-in|isAdmin|adminRole/.test(readFileSync(file,'utf8'))?'Authenticated or conditional — see source':'Public or client-gated — see source', desktop: 'Unverified', mobile: 'Unverified' }));
const controls=[];
for(const file of ['app/live-shopping.tsx','app/workspace/page.tsx','app/live-overlay.tsx']) {
 const raw=readFileSync(file,'utf8'); const ast=ts.createSourceFile(file,raw,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 function visit(node) {
  if(ts.isJsxElement(node)||ts.isJsxSelfClosingElement(node)) {
   const opening=ts.isJsxElement(node)?node.openingElement:node;
   const tag=opening.tagName.getText(ast);
   if(tag==='button'||tag==='LiveAction') {
    const attrs=Object.fromEntries(opening.attributes.properties.filter(ts.isJsxAttribute).map(a=>[a.name.getText(ast),a.initializer?.getText(ast)||'true']));
    const text=ts.isJsxElement(node)?node.children.map(c=>c.getText(ast)).join(' ').replace(/\s+/g,' ').slice(0,180):'';
    controls.push({file,line:ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1,name:attrs['aria-label']||attrs.label||text||'Dynamic button — see source',location:attrs.className||tag,expectedAction:attrs.onClick||'Containing form submit or shared callback',disabled:attrs.disabled||'No explicit disabled condition',actualAction:'See automated test mapping where available',mobile:'Not tested on device',desktop:'Not browser-tested',accessibility:attrs['aria-label']?'Label present; screen-reader test pending':'Text or delegated label; screen-reader test pending',retest:'Do not treat source discovery as a pass'});
   }
  }
  ts.forEachChild(node,visit);
 }
 visit(ast);
}
mkdirSync('docs/ui-ux',{recursive:true});
writeFileSync('docs/ui-ux/inventory.json',JSON.stringify({routes,components,livestreamControls:controls},null,2)+'\n');
const md=['# Cash N Carry route and component inventory','',`Discovered ${routes.length} page routes, ${components.length} TSX source modules and ${controls.length} livestream button/control declarations. Conditional controls are separate declarations. API routes are not public design pages. Inventory generation does not constitute browser testing.`,'','| Route | Source | Direct components | Review |','|---|---|---|---|',...routes.map(r=>`| ${r.route} | ${r.file} | ${r.directComponents.join(', ')||'Inline'} | Shared styling applied; visual review pending |`),'','## Conditional interfaces','', 'The root application contains Home, Market, Explore, Live, Orders and Seller views; product, store, cart, checkout, review, cancellation, filters, notification and seller forms are modal/conditional interfaces. The workspace includes account/profile, addresses, notification preferences, saved products, delivery, broadcasts/setup/live studio, orders and support. Seller finance includes Activation, Subscription, Earnings, Withdrawals, Bank account and History. Seller competitive includes Live Deals, Analytics, Bundles, Affiliates, Auctions and Founding Seller. Admin panel includes Overview, Seller Subscriptions & Payouts, Payments, Orders, Support, Verification, Stores, Users, Products, Live, Ads, Reports and Audit log, filtered by role permissions. Admin competitive includes Founding Sellers, Live Deals, Creator Affiliates and Auctions. Admin settings includes platform, email, streaming and legal approval interfaces.','', '## Complete component source inventory','', '| Module | Exports | Direct component dependencies |','|---|---|---|',...components.map(c=>`| ${c.file} | ${c.exports.join(', ')||'See module'} | ${c.imports.join(', ')||'Inline or third party'} |`),'','## Livestream control inventory','', '| Source line | Control | Expected handler | Device/browser result |','|---|---|---|',...controls.map(c=>`| ${c.file}:${c.line} | ${c.name.replaceAll('|','/').replaceAll('\n',' ').slice(0,100)} | ${c.expectedAction.replaceAll('|','/').replaceAll('\n',' ').slice(0,160)} | Pending; consult handler test report |`)];
writeFileSync('docs/ui-ux/INVENTORY.md',md.join('\n')+'\n');
console.log(JSON.stringify({routes:routes.length,componentModules:components.length,liveControlDeclarations:controls.length}));
