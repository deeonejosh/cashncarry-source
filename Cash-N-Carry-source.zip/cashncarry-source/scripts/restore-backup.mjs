// Generate a restore script for a NEW, migrated recovery database. Never run against production.
import { readFileSync, writeFileSync } from "node:fs";
const [input, output] = process.argv.slice(2);
if (!input || !output)
  throw Error("Usage: node scripts/restore-backup.mjs backup.json restore.sql");
const b = JSON.parse(readFileSync(input, "utf8"));
if (b.format !== "revibe-backup-v1") throw Error("Unsupported backup");
const tables = [
  "auth_user",
  "policy_acceptances",
  "auth_account",
  "profiles",
  "stores",
  "products",
  "carts",
  "orders",
  "order_items",
  "streams",
  "chats",
  "reviews",
  "follows",
  "campaigns",
  "campaign_events",
  "addresses",
  "favourites",
  "preferences",
  "notifications",
  "payments",
  "payment_events",
  "refunds",
  "reports",
  "verification_requests",
  "admin_audit",
  "platform_settings",
  "categories",
  "policies",
  "policy_versions",
  "email_outbox",
  "email_suppressions",
  "email_webhook_events",
  "upload_usage",
  "media_blocks",
  "seller_subscriptions",
  "seller_subscription_payments",
  "seller_banks",
  "seller_earnings_releases",
  "seller_adjustments",
  "seller_withdrawals",
];
const quote = (v) =>
  v === null
    ? "NULL"
    : typeof v === "number"
      ? String(v)
      : "'" + String(v).replaceAll("'", "''") + "'";
let sql =
  "-- NEW migrated recovery database only. Existing records cause rollback. Sessions are revoked.\nBEGIN;\nDROP TRIGGER item_stock_guard;\nDROP TRIGGER item_stock_decrement;\nDROP TRIGGER order_cancel_restock;\nDELETE FROM categories;\nDELETE FROM policies;\nDELETE FROM platform_settings;\nDELETE FROM policy_versions WHERE status='draft';\nDROP TRIGGER seller_new_order_activation;\nDROP TRIGGER seller_withdrawal_balance;\n";
for (const table of tables) {
  for (const row of b.tables[table] || []) {
    const keys = Object.keys(row);
    if (keys.some((k) => !/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(k)))
      throw Error("Invalid column");
    sql += `INSERT INTO "${table}" (${keys.map((k) => '"' + k + '"').join(",")}) VALUES (${keys.map((k) => quote(row[k])).join(",")});\n`;
  }
}
const migration = readFileSync("drizzle/0004_variant_inventory.sql", "utf8");
for (const part of migration.split("--> statement-breakpoint"))
  if (/^\s*CREATE TRIGGER/.test(part)) sql += part.trim() + "\n";
for (const part of readFileSync('drizzle/0018_seller_activation.sql','utf8').split('--> statement-breakpoint')) if (/^\s*CREATE TRIGGER (seller_new_order_activation|seller_withdrawal_balance)\b/.test(part)) sql += part.trim()+'\n';
// Backfill blocks for older backups that predate media moderation.
sql += `INSERT OR IGNORE INTO media_blocks SELECT substr(url,instr(url,'/api/media/')+11),datetime('now') FROM (SELECT image AS url FROM products WHERE active=0 UNION ALL SELECT video FROM products WHERE active=0 UNION ALL SELECT j.value FROM products p,json_each(p.images) j WHERE p.active=0) WHERE instr(url,'/api/media/')>0 AND substr(url,instr(url,'/api/media/')+11)!='';\n`;
sql += "COMMIT;\n";
writeFileSync(output, sql, { mode: 0o600 });
console.log(
  "Recovery SQL created. Apply only to an isolated migrated database, then verify inventory, access and media before cutover.",
);
