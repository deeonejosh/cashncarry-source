"""Static rendering QA of exact email HTML at 360px and 600px; not a mail-client test."""
from pathlib import Path
from weasyprint import HTML, CSS
import fitz
folder=Path('docs/email-previews')
count=0
for f in sorted(folder.glob('*.html')):
    if f.stem=='index': continue
    for width,label in [(600,'desktop'),(360,'mobile')]:
        css=f'@page{{size:{width}px 2200px;margin:0}}html,body{{margin:0;width:{width}px}} .email-outer{{padding:24px 12px!important}}' + ('.email-card{padding:24px 18px!important}' if width==360 else '')
        pdf=HTML(filename=str(f)).write_pdf(stylesheets=[CSS(string=css)])
        doc=fitz.open(stream=pdf,filetype='pdf')
        assert len(doc)==1,(f.name,label,len(doc))
        page=doc[0]
        blocks=page.get_text('blocks')
        bottom=max((b[3] for b in blocks),default=500)+16
        for block in blocks:
            assert block[0]>=-1 and block[2]<=page.rect.width+1,(f.name,label,'horizontal overflow',block[:4])
        clip=fitz.Rect(0,0,page.rect.width,min(bottom,page.rect.height))
        page.get_pixmap(matrix=fitz.Matrix(96/72,96/72),clip=clip,alpha=False).save(str(folder/f'{f.stem}-{label}.png'))
        count+=1
print(f'Rendered {count} static previews with no horizontal text overflow. Gmail/Outlook not verified.')
