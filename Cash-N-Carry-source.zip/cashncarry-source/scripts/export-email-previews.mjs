// Reproducible sample previews of the exact production renderer. No emails are sent.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import ts from "typescript";
const url = (source) =>
  "data:text/javascript;base64," +
  Buffer.from(
    ts.transpileModule(source, {
      compilerOptions: {
        target: ts.ScriptTarget.ES2023,
        module: ts.ModuleKind.ESNext,
      },
    }).outputText,
  ).toString("base64");
const brand = url(readFileSync("app/brand.ts", "utf8"));
const source = readFileSync("app/email-templates.ts", "utf8").replace(
  '"./brand"',
  JSON.stringify(brand),
);
const { emailTemplates, renderEmail, sampleEmail } = await import(url(source));
mkdirSync("docs/email-previews", { recursive: true });
const logo =
  "data:image/png;base64," +
  readFileSync("public/brand/cash-n-carry-logo.png").toString("base64");
for (const t of emailTemplates) {
  const preview = renderEmail(t.id, sampleEmail(t.id));
  writeFileSync(
    `docs/email-previews/${t.id}.html`,
    preview.html.replace(
      "https://cashncarryng.com/brand/cash-n-carry-logo.png",
      logo,
    ),
  );
  writeFileSync(`docs/email-previews/${t.id}.txt`, preview.text);
}
writeFileSync(
  "docs/email-previews/index.html",
  `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cash N Carry email samples</title><body style="font-family:Arial;background:#fff8ef;color:#164b35;max-width:700px;margin:30px auto;padding:20px"><h1>Cash N Carry email previews</h1><p>Illustrative samples from the production renderer. No email was sent and no account, order or payment action occurred.</p><ul>${emailTemplates.map((t) => `<li style="padding:10px"><a href="${t.id}.html">${t.title}</a> — ${t.connected ? "Connected server trigger" : "Designed; workflow unavailable"} · <a href="${t.id}.txt">Plain text</a></li>`).join("")}</ul></body></html>`,
);
console.log(
  `Exported ${emailTemplates.length} labelled sample HTML and plain-text previews.`,
);
