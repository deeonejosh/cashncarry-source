# Cash N Carry Website Audit

**Date:** 2026-10-23  
**Working branch:** `audit-fixes-20261023`  
**Production:** unchanged; no deployment performed  
**Scope:** current application source, automated tests/build, public website inspection in Chrome

## Executive summary

The public homepage and live-discovery route rendered in Chrome. The home page exposed product cards, seller links, search, cart, pagination and clear empty-live messaging. The live-discovery page exposed broadcast filters and an honest “No broadcasts available” state.

The codebase has substantial automated coverage for livestream state, seller history routing, admin access and commerce integrity. I fixed one confirmed route defect: the post-live **Done** action was hard-coded to `www.cashncarryng.com`, which could take a preview/staging session out of its own host. It now uses a same-origin marketplace route.

No production write, payment, admin action, camera permission grant or deployment was performed. Real authenticated buyer/seller/admin journeys and provider-backed cross-device synchronization remain unverified because no signed-in test accounts or second device were available.

## Findings and fixes

| Page / feature | Severity | Issue and reproduction | Root cause / affected file | Fix and test | Status |
|---|---|---|---|---|---|
| Post-live summary → Done | Medium | On a non-production host, ending a stream and selecting **Done** could leave the current host. | Absolute production URL in `app/workspace/page.tsx`. | Changed to `/?browse=1#live`; strengthened `tests/live-controls.test.mjs` to reject absolute-host links. | **FIXED AND VERIFIED** |
| Livestream popup contrast | High | Supplied screenshots show cream popup surfaces and near-white text, making product/deal forms hard to read. | Historical cream rules remain in `app/globals.css`, `app/design-system.css`, and `app/premium.css`; the current source has a later dark-glass override in `app/shop-redesign.css`. | The dark theme, form controls, sheet scrolling and mobile action styling are covered by existing livestream CSS regression tests. I could not open an authenticated studio popup in Chrome to verify computed production styles. | **PARTIAL** |
| Host microphone / flip / products / More placement | High | Supplied screenshot shows these controls stacked vertically through the camera view. | Older right-rail rules remain in `app/premium.css`; current studio stylesheet applies a compact bottom dock in `app/shop-redesign.css`. | Existing host layout tests confirm the source uses one compact bottom action dock. No production seller-session screenshot was available to verify the rendered result. | **PARTIAL** |
| + → camera → LIVE handoff | Critical | Earlier reports described an extra preview/setup step before connection. | Current source uses `app/camera-handoff.ts`, `app/video-creation.tsx`, and `app/workspace/page.tsx`. | Tests cover one camera stream handoff, immediate connecting state, duplicate taps, permission denial, provider confirmation and cleanup. Tests are automated fixtures, not a live provider broadcast. | **WORKING AND VERIFIED** (local tests) |
| Seller Centre livestream entries | High | Legacy Broadcasts route could compete with the camera-first studio. | `app/workspace/page.tsx` and seller navigation. | Tests confirm Seller Centre navigation exposes livestream history, while legacy Broadcasts/deal/auction routes resolve to history and do not open another studio. | **WORKING AND VERIFIED** (source/tests) |
| Deal synchronization | High | Deal may be absent from buyer stream if the seller-only state is not refreshed. | `app/api/live-deals/route.ts`, `app/live-feature-polling.ts`, `app/workspace/page.tsx`, and buyer `app/live-shopping.tsx`. | Automated tests cover server deal validation, seller refresh after create, buyer polling and deal rendering/price consistency. Real two-device/provider verification was unavailable. | **PARTIAL** |
| Auctions and bundles | High | Financial and inventory-affecting features require server-authoritative validation. | `/api/live-auctions`, `/api/product-bundles`, settlement and checkout code. | Existing tests exercise permissions, bid validation, duplicate handling and bundle inventory/checkout rules. No live multi-account auction or sandbox checkout was run. | **PARTIAL** |
| End Live lifecycle | Critical | A failed provider stop must not be reported as ended; summary must not open before termination confirmation. | `app/api/streams/route.ts`, `app/workspace/page.tsx`. | Tests verify provider-failure recovery, owner checks, confirmed termination, track release, viewer state and summary navigation behavior. Provider calls are mocked. | **PARTIAL** |
| Admin access | Critical | Admin modules must reject forged membership, unverified, non-MFA or suspended accounts. | `app/admin-access.ts`, `app/admin-permissions.ts`, `/api/admin/*`. | Existing tests exercise MFA-backed gates, roles and unauthorised route denial. No authenticated production Admin Console session was inspected. | **WORKING AND VERIFIED** (tests) |
| Public marketplace navigation | Medium | Verify visible public destinations and empty states. | Public home and live discovery. | Chrome inspection found navigation, product cards, seller links and browse controls; live discovery clearly reported no matching streams. No checkout was submitted. | **PARTIAL** |
| Client bundle size | Medium | Build emits a warning for one or more minified client chunks over 500 kB. | Build output; detailed bundle attribution not yet run. | Build completed. No before/after bundle split or Lighthouse measurement was taken. | **PARTIAL** |

## Route and code audit

The build enumerated buyer routes (`/`, `/for-you`, `/live`, `/live-auctions`, `/product/:id`, `/store/:id`, `/messages`, `/account`, `/order/:id`), seller routes (`/workspace`, `/seller`, `/seller/website`, `/seller/videos`, `/seller/live-history`, `/seller/competitive`, `/seller/finance`, `/seller/bulk-upload`) and admin routes (`/admin`, `/admin/competitive`, `/admin/email-templates`, `/admin/settings`), plus the related API routes.

Relevant implementations reviewed include:

- `app/customer-shell.tsx` and `app/video-creation.tsx` for the central + entry and camera flow.
- `app/camera-handoff.ts` and `app/workspace/page.tsx` for camera transfer, studio start, end and summary.
- `app/live-overlay.tsx`, `app/live-shopping.tsx`, `app/live-feature-polling.ts` and `app/shop-redesign.css` for buyer/seller overlays and popup styling.
- `/api/streams`, `/api/live-deals`, `/api/live-auctions`, `/api/product-bundles` for broadcast and shopping operations.
- `app/admin-access.ts`, `app/admin-permissions.ts`, and `app/api/admin/*` for admin authorization.

The source still contains older livestream style declarations in earlier CSS files; the final dark-glass and compact-dock rules override them. This cascade is fragile and remains a cleanup risk. I did not delete the legacy CSS in this audit because the authenticated rendered views could not be regression-checked across devices.

## Verification evidence

- Full automated suite before the one-line route fix: **279 passed, 0 failed**.
- Focused livestream suite after the route fix: **71 passed, 0 failed** across camera-first startup, handoff, recovery, live controls, deals, CSS checks, polling and seller live history.
- Production build: **completed successfully**; Vite warned about client chunks larger than 500 kB.
- Targeted ESLint on `app/workspace/page.tsx` reports **59 errors and 9 warnings**, mostly existing `any` usage and style/complexity issues in this large legacy component. The full lint gate is therefore not clean.
- Public Chrome inspection: homepage and `/ ?browse=1#live` discovery view rendered; the latter showed no active/scheduled/replay broadcasts. The optional analytics choice was rejected.
- Performance: no Lighthouse/Core Web Vitals run was completed. No numeric performance claim is made.
- Responsive/device screenshots: not captured at the requested viewport matrix. CSS/static regression tests do not substitute for those visual checks.

## Remaining work / blockers

| Area | Status | Required evidence to close |
|---|---|---|
| Seller camera permission and Go Live on Android Chrome / Samsung Internet / iOS Safari | **NOT TESTED** | Authenticated eligible seller and explicit camera/microphone permission in target browsers. |
| Provider-confirmed broadcast with separate buyer device | **NOT TESTED** | Safe seller/buyer test accounts and configured non-production stream provider. |
| Buyer product/deal/auction/bundle checkout | **NOT TESTED** | Sandbox checkout and concurrent buyer accounts; do not use real payments. |
| Seller Centre and Admin Console interactive workflows | **NOT TESTED** | Authorized test accounts; current public browser has no authenticated session. |
| Mobile viewport, keyboard, orientation and safe-area visual QA | **NOT TESTED** | Device/browser matrix at 320–1440 px, with screenshots and keyboard-open states. |
| Lighthouse and bundle attribution | **NOT TESTED** | Run Lighthouse and bundle analyzer against a local or staging build. |
| Full lint cleanup | **PARTIAL** | Address 59 existing errors and 9 warnings in `app/workspace/page.tsx`, then run full lint. |

## Deployment readiness

**Not ready for production sign-off.** The local build and tests pass, but the popup/control layout still needs authenticated mobile visual verification, real provider-backed buyer/seller testing, performance measurement and lint cleanup. Production remains unchanged. The branch `audit-fixes-20261023` contains the same-origin Done-link correction and its regression test; deploy only after explicit approval and closure of the blockers above.
