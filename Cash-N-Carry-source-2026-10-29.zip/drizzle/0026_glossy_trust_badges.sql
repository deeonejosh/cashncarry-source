ALTER TABLE `stores` ADD COLUMN `official_store` integer NOT NULL DEFAULT 0 CHECK (`official_store` IN (0, 1));
