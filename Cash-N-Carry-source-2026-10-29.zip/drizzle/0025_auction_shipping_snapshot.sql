ALTER TABLE auction_bids ADD COLUMN recipient TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE auction_bids ADD COLUMN phone TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE auction_bids ADD COLUMN delivery_address TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE auction_bids ADD COLUMN delivery_state TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE auction_bids ADD COLUMN delivery_area TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE auction_bids ADD COLUMN delivery_fee INTEGER NOT NULL DEFAULT 0;
