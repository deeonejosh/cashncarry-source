CREATE TABLE video_creation_requests (
  owner TEXT NOT NULL,
  request_key TEXT NOT NULL,
  video TEXT NOT NULL,
  created TEXT NOT NULL,
  PRIMARY KEY(owner, request_key)
);
CREATE INDEX video_creation_requests_video ON video_creation_requests(video);
