# Cash N Carry transactional email system

The approved full horizontal logo and “Watch Live. Discover. Shop.” tagline are used in the shared layout. All 41 registered templates use one responsive, table-based renderer, inline colours, a 600px maximum width, an image-independent heading, a primary action, fallback link, plain text, preview text and a current-year footer. The renderer uses the approved email palette, a high-contrast payment/refund status panel, and safe optional product thumbnails. Links use https://cashncarryng.com. Private destinations retain existing authentication and role checks. Signed-out visitors use the Cash N Carry sign-in page when email accounts are configured, preserving their destination; the existing ChatGPT fallback remains available.

## Template and event audit

### Registered template inventory

“Connected” means the existing application has a server event for the template. “Designed only” means the template is available in the shared renderer and preview gallery but must not imply an unavailable workflow.

| Template | Current trigger status |
| --- | --- |
| `seller-verification-received` | Connected — stored verification submission |
| `seller-verification-approved` | Connected — stored human verification decision |
| `seller-verification-information` | Connected — stored human verification decision |
| `seller-verification-rejected` | Connected — stored human verification decision |
| `seller-withdrawal-requested` | Connected — stored withdrawal request |
| `seller-withdrawal-approved` | Connected — stored withdrawal approval |
| `seller-withdrawal-paid` | Connected — provider-confirmed withdrawal result |
| `seller-withdrawal-failed` | Connected — provider-confirmed failed withdrawal |
| `seller-subscription-activated` | Connected — verified first subscription payment |
| `seller-subscription-renewed` | Connected — verified recurring renewal |
| `seller-subscription-expiring` | Connected — existing expiry reminder |
| `seller-subscription-expired` | Connected — confirmed expired paid period |
| `seller-subscription-payment-failed` | Connected — provider-verified failed renewal |
| `seller-subscription-cancelled` | Connected — provider-confirmed renewal cancellation |
| `verification` | Connected — expiring account verification link |
| `welcome` | Connected — first successful email verification |
| `password-reset` | Connected — expiring, single-use reset link |
| `password-changed` | Connected — successful reset completion |
| `email-change-verification` | Designed only — email change is not offered |
| `email-change-notice` | Designed only — email change is not offered |
| `order-confirmation` | Connected — committed order |
| `order-update` | Connected — seller-confirmed order transition |
| `payment-receipt` | Connected — independently verified provider payment |
| `payment-issue` | Connected — verified checkout failure or uncertain reconciliation |
| `seller-order` | Connected — COD order or verified online payment |
| `dispatched` | Connected — stored shipped transition |
| `pickup-ready` | Designed only — no stored pickup-ready state |
| `delivered` | Connected — stored delivered transition |
| `order-cancelled` | Connected — stored cancellation, real payment/refund state |
| `return-request` | Connected — stored return case |
| `seller-return` | Connected — stored return case for seller |
| `return-decision` | Connected — existing case review/resolution states |
| `refund-update` | Connected — stored refund event/reconciliation |
| `seller-verification` | Connected — submission and human decision |
| `support-acknowledgement` | Connected — stored support case |
| `support-response` | Connected — stored case response |
| `support-resolution` | Connected — stored case resolution |
| `restriction` | Connected — confirmed account/listing moderation action |
| `review-request` | Connected — eligible delivered-order review request |
| `admin-alert` | Connected — verification, support or payment review queue |
| `notification` | Connected — existing transactional fallback |

Marketing, wishlist/product alerts, inventory notices, livestream announcements, buyer/seller message notices and operational security messages do not have separate active templates/events in the current codebase. No new triggers were added as part of this visual/system update.

| Templates | Connected server event | Limits |
| --- | --- | --- |
| Email verification, password reset | Better Auth callbacks; durable queue and provider acceptance check | Both expire after 3,600 seconds. Reset tokens are single-use. Expired queued links are not sent. |
| Welcome | Successful first email verification | Durable user-based identity prevents repeat welcomes. |
| Password changed | Successful password reset completion | Notification does not contain the password. The site currently changes email passwords through reset. |
| Email change verification and previous-address notice | Designed, not connected | Account email changes are not currently offered. These templates cannot imply a completed change. |
| Order confirmation | A committed order and checkout retries | Stored items, variant, quantity, seller, delivery fee, total and actual payment state. Pending is not paid. |
| Payment receipt | Independent successful Flutterwave verification | Stored reference, amount, NGN currency, provider ID and paid order/payment required. Sandbox messages are marked TEST. |
| Payment issue | Expired checkout reconciliation retains an uncertain payment | No duplicate-payment prompt. Confirmed failed/closed checkout is explained in the cancellation email to avoid redundant notices. |
| New seller order | Cash-on-delivery order or verified paid online order | No fulfilment notice for unverified online payment. |
| Seller confirmation, dispatched, delivered, cancellation | Confirmed stored order transition | Delivery is described as marked by the seller. Cancellation includes actual refund state. |
| Pickup ready | Designed, not connected | Current fulfilment model has no stored pickup-ready state; no readiness promise is invented. |
| Return acknowledgement and seller notice | Stored return case for a delivered purchase | Case reference and actual state, not automatic return approval. |
| Return decision | Recorded case review/resolution | Current case system has in-review/resolved/rejected states; no separate automated return approval or more-information workflow is invented. |
| Refund update | Request, administrator review, provider processing and reconciliation | Requested/approved/processing/uncertain/completed/failed remain separate. Only validated provider completion says refunded. |
| Seller verification | Submission and administrator approval/rejection | Stored note and status only; no document or private file URL. Additional-information requests have no dedicated backend state. |
| Support acknowledgement, response, resolution | Stored report/case creation and administrator review | Private details require sign-in. No response-time promise. |
| Restriction | Confirmed suspension or listing/broadcast moderation | Actual reviewer reason and existing Help route. Owner must publish a usable monitored contact for appeals. |
| Review request | One delivered-purchase notification | Respects existing order-update preference and uses the protected eligible-purchase workflow. |
| Admin alert | New verification/report queues and payment reconciliation discrepancy | No sensitive details in the subject. Email failures are visible in the admin queue instead of recursively emailing through a failing channel. |
| Notification fallback | Existing queued plain-text notices | Historical queue entries remain intact and use the new branded layout. |

Scheduled/live email reminders, marketing, abandoned-cart campaigns and payouts are not enabled: no dedicated requested-email subscription/reminder, marketing-send or genuine payout workflow exists. Existing follows, alert preferences, advertising and accounts are preserved.

## Delivery and administration

- `/admin/email-templates` and `/api/admin/email-templates` use existing server-side administrator checks. Mutations require the same origin, explicit inputs and rate limits.
- Samples are prominently labelled. Test sending requires a selected recipient and consent; only the selected sample is flushed, and retry uses a stable identity. Subjects are prefixed `[SAMPLE TEST]`.
- Sender keys continue using existing secure environment or AES-GCM encrypted private storage. The queue now reads both, fixing the previous environment-only send gate.
- Reply-To is an owner-confirmed monitored mailbox or the approved public support address. The From address is never automatically presented as a support mailbox. Receiving capability is not proof of mailbox monitoring.
- The read-only sender-domain check queries Resend and reports missing domain-inspection permission without exposing or broadening the sending key. Existing setup acceptance is not called inbox delivery.
- Configure `RESEND_WEBHOOK_SECRET` through secure server configuration or the encrypted admin signing-secret form, then create the Resend webhook at `https://cashncarryng.com/api/emails/webhook`. Subscribe to sent, delivered, delivery_delayed, bounced, complained, failed and suppressed.
- Webhooks verify the exact raw body with Svix HMAC-SHA256 and a five-minute timestamp tolerance. Recorded event identities and monotonic terminal states protect retries and out-of-order feedback. Early feedback is reconciled when provider acceptance arrives.
- Accepted, delivered-to-recipient-server, delayed, failed, bounced and complained are distinct. No inbox-placement or read receipt is inferred. Bounce/complaint suppression prevents further sends; use a verified new address or review the provider suppression deliberately rather than automatically clearing it.
- Durable event identities prevent duplicates. Atomic queue leases, five bounded attempts, exponential backoff and stable Resend idempotency keys preserve retry behaviour. Uncertain messages beyond the provider's 24-hour window require reconciliation instead of automatic resend.
- The protected existing maintenance endpoint and administrator queue operation process retries. Continuous retries while no one is using the site depend on the existing maintenance scheduler; a deployed external scheduler was not independently exercised in this work.
- New queue fields and delivery/suppression records use additive database migrations and are included in backup/restore. No accounts, orders, listings or history are deleted.

## Verification

Automated tests use isolated SQLite, the installed Better Auth implementation with an in-memory adapter, controlled `.invalid` recipients and stubbed Resend/Flutterwave responses. No real customer messages or charges are made.

Checks cover actual signup/verification/reset, secure session cookies, verification expiry, reset expiry and single-use, welcome deduplication, stored order snapshots, paid-receipt/seller gates, refund wording, seller/case events, administrator denial, origin checks, test-send isolation/idempotency, raw webhook signatures, timestamp replay rejection, bounce suppression, encrypted webhook configuration and early delivery feedback.

`scripts/export-email-previews.mjs` exports exact-renderer labelled HTML/plain-text samples. This update regenerated all 41 HTML and text samples. `scripts/render-email-previews.py` can use WeasyPrint and PyMuPDF for 360px and 600px static previews, but WeasyPrint is not installed in the current environment, so fresh PNG screenshots could not be produced here. The HTML preview embeds the approved logo for offline viewing; delivered emails use the public approved JPEG asset.

**Not verified:** delivery through the production Resend account, receipt in a monitored inbox, Gmail/Outlook/client dark mode, live sender-domain verification, production webhook registration, externally scheduled retries or interactive admin browser QA. The managed browser capability is unavailable. Static renderings and provider acceptance fixtures are not substitutes for these tests.

## Owner/configuration decisions

Confirm a mailbox that receives replies and is monitored; `notifications@cashncarryng.com` is not assumed to receive mail. Supply the webhook signing secret only through secure configuration. Use a controlled test inbox in the admin section to complete actual delivery/client tests.

Legal operator identity, legal/contact address, return periods, return delivery responsibility, refund timelines and dispute/appeal process remain unresolved in the existing draft policies. Email templates make no promises about these matters and do not remove draft labels. Account email-change, pickup readiness and dedicated additional-information workflows need product/backend decisions before their corresponding templates can be connected.
