# Cash N Carry master audit — 21 October 2026

## Scope and status

This audit used the existing Cash N Carry Sites project, starting from published version 195 (source `7e29e38f6d383f2bf88a12c5d1c1cf0b7baba49f`). A duplicate Shop sort control was fixed in the source and saved as unpublished version 196 (source `f173882d4f654da90cce9219b04e6837c7422d7a`). No production deployment was made.

The route inventory below is complete for filesystem routes in this source snapshot. The hands-on browser audit is partial: the public homepage, Shop anchor, Live anchor, For You feed, one product quick view, and public authentication screens were inspected. Buyer, seller, admin, payment, message-send, and live-stream workflows were not exercised because there are no authorised test accounts in this session and the live site must not receive state-changing test actions. Internal preview startup reported running, but Chrome returned `ERR_CONNECTION_REFUSED` at the documented preview URL; preview was stopped. Therefore no updated-page or before/after screenshots were captured.

## Architecture discovered

- Frontend and server: Next.js 16 app-router source, built with Vinext/Vite for Cloudflare Workers.
- Persistence: Cloudflare D1 through Drizzle ORM; R2 binding for private/public media objects.
- Authentication: Better Auth, with email-account flows and ChatGPT sign-in support. Admin operations use server-side role checks and MFA-related enforcement in source/tests.
- Main integration surfaces: Flutterwave Standard payments and webhooks; Cloudflare Stream / WebRTC broadcast APIs; D1-backed messages, video, products, orders, seller subscriptions and audit records.
- Automated coverage: 78 test files. The full Node test suite passed: 248 passed, 0 failed. These include SQLite-backed route tests and provider-response fixtures; they do not prove live provider delivery or authenticated production workflows.
- Build: `pnpm build` passed. Vinext reported a client chunk above 500 kB.
- Lint: `pnpm lint` failed with 968 errors and 42 warnings across the existing codebase. Examples include `no-explicit-any` and React set-state-in-effect findings. This remains an unresolved code-quality gate.

## Route inventory

### Page routes

| Route | Source file | Audit status |
|---|---|---|
| `/account` | `app/account/page.tsx` | NOT TESTED — route discovered from source only |
| `/admin/competitive` | `app/admin/competitive/page.tsx` | NOT TESTED — route discovered from source only |
| `/admin/email-templates` | `app/admin/email-templates/page.tsx` | NOT TESTED — route discovered from source only |
| `/admin` | `app/admin/page.tsx` | NOT TESTED — route discovered from source only |
| `/admin/settings` | `app/admin/settings/page.tsx` | NOT TESTED — route discovered from source only |
| `/community-guidelines` | `app/community-guidelines/page.tsx` | NOT TESTED — route discovered from source only |
| `/creator` | `app/creator/page.tsx` | NOT TESTED — route discovered from source only |
| `/delivery` | `app/delivery/page.tsx` | NOT TESTED — route discovered from source only |
| `/for-you` | `app/for-you/page.tsx` | PARTIAL — feed and controls observed; playback and actions not verified |
| `/forgot-password` | `app/forgot-password/page.tsx` | PARTIAL — public form rendered; no credentials or submission used |
| `/help` | `app/help/page.tsx` | NOT TESTED — route discovered from source only |
| `/live` | `app/live/page.tsx` | NOT TESTED — route discovered from source only |
| `/live-auctions` | `app/live-auctions/page.tsx` | NOT TESTED — route discovered from source only |
| `/messages` | `app/messages/page.tsx` | PARTIAL — route entry redirected to sign-in; authenticated inbox not tested |
| `/order/[id]` | `app/order/[id]/page.tsx` | NOT TESTED — route discovered from source only |
| `/.` | `app/page.tsx` | NOT TESTED — route discovered from source only |
| `/payment-return` | `app/payment-return/page.tsx` | NOT TESTED — route discovered from source only |
| `/policies/[id]` | `app/policies/[id]/page.tsx` | NOT TESTED — route discovered from source only |
| `/privacy` | `app/privacy/page.tsx` | NOT TESTED — route discovered from source only |
| `/product/[id]` | `app/product/[id]/page.tsx` | NOT TESTED — route discovered from source only |
| `/refunds` | `app/refunds/page.tsx` | NOT TESTED — route discovered from source only |
| `/seller/billing-return` | `app/seller/billing-return/page.tsx` | NOT TESTED — route discovered from source only |
| `/seller/bulk-upload` | `app/seller/bulk-upload/page.tsx` | NOT TESTED — route discovered from source only |
| `/seller/competitive` | `app/seller/competitive/page.tsx` | NOT TESTED — route discovered from source only |
| `/seller/finance` | `app/seller/finance/page.tsx` | NOT TESTED — route discovered from source only |
| `/seller` | `app/seller/page.tsx` | NOT TESTED — route discovered from source only |
| `/seller/videos` | `app/seller/videos/page.tsx` | NOT TESTED — route discovered from source only |
| `/seller/website` | `app/seller/website/page.tsx` | NOT TESTED — route discovered from source only |
| `/seller-terms` | `app/seller-terms/page.tsx` | NOT TESTED — route discovered from source only |
| `/sign-in` | `app/sign-in/page.tsx` | PARTIAL — public form rendered; no credentials or submission used |
| `/sign-up` | `app/sign-up/page.tsx` | PARTIAL — public form rendered; no credentials or submission used |
| `/social` | `app/social/page.tsx` | NOT TESTED — route discovered from source only |
| `/start-selling` | `app/start-selling/page.tsx` | NOT TESTED — route discovered from source only |
| `/store/[id]` | `app/store/[id]/page.tsx` | NOT TESTED — route discovered from source only |
| `/terms` | `app/terms/page.tsx` | NOT TESTED — route discovered from source only |
| `/two-factor` | `app/two-factor/page.tsx` | NOT TESTED — route discovered from source only |
| `/welcome` | `app/welcome/page.tsx` | NOT TESTED — route discovered from source only |
| `/workspace` | `app/workspace/page.tsx` | NOT TESTED — route discovered from source only |

### API routes

| Route | Source file | Audit status |
|---|---|---|
| `/api/admin/access` | `app/api/admin/access/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/backup` | `app/api/admin/backup/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/competitive` | `app/api/admin/competitive/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/email` | `app/api/admin/email/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/email-templates` | `app/api/admin/email-templates/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/finance` | `app/api/admin/finance/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/message-reports` | `app/api/admin/message-reports/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/policies` | `app/api/admin/policies/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin` | `app/api/admin/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/seller-finance` | `app/api/admin/seller-finance/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/settings` | `app/api/admin/settings/route.ts` | NOT TESTED live; route inventoried |
| `/api/admin/streaming` | `app/api/admin/streaming/route.ts` | NOT TESTED live; route inventoried |
| `/api/ads-events` | `app/api/ads-events/route.ts` | NOT TESTED live; route inventoried |
| `/api/affiliate` | `app/api/affiliate/route.ts` | NOT TESTED live; route inventoried |
| `/api/auth/[...all]` | `app/api/auth/[...all]/route.ts` | NOT TESTED live; route inventoried |
| `/api/brand-icon` | `app/api/brand-icon/route.ts` | NOT TESTED live; route inventoried |
| `/api/catalog` | `app/api/catalog/route.ts` | NOT TESTED live; route inventoried |
| `/api/commerce` | `app/api/commerce/route.ts` | NOT TESTED live; route inventoried |
| `/api/emails/webhook` | `app/api/emails/webhook/route.ts` | NOT TESTED live; route inventoried |
| `/api/founding-sellers` | `app/api/founding-sellers/route.ts` | NOT TESTED live; route inventoried |
| `/api/live-auctions` | `app/api/live-auctions/route.ts` | NOT TESTED live; route inventoried |
| `/api/live-deals` | `app/api/live-deals/route.ts` | NOT TESTED live; route inventoried |
| `/api/live-presence` | `app/api/live-presence/route.ts` | NOT TESTED live; route inventoried |
| `/api/maintenance` | `app/api/maintenance/route.ts` | NOT TESTED live; route inventoried |
| `/api/manifest` | `app/api/manifest/route.ts` | NOT TESTED live; route inventoried |
| `/api/media/[key]` | `app/api/media/[key]/route.ts` | NOT TESTED live; route inventoried |
| `/api/media` | `app/api/media/route.ts` | NOT TESTED live; route inventoried |
| `/api/messages/attachment/[id]` | `app/api/messages/attachment/[id]/route.ts` | NOT TESTED live; route inventoried |
| `/api/messages` | `app/api/messages/route.ts` | NOT TESTED live; route inventoried |
| `/api/orders/receipt` | `app/api/orders/receipt/route.ts` | NOT TESTED live; route inventoried |
| `/api/payments/verify` | `app/api/payments/verify/route.ts` | NOT TESTED live; route inventoried |
| `/api/payments/webhook` | `app/api/payments/webhook/route.ts` | NOT TESTED live; route inventoried |
| `/api/policies/terms` | `app/api/policies/terms/route.ts` | NOT TESTED live; route inventoried |
| `/api/product-bundles` | `app/api/product-bundles/route.ts` | NOT TESTED live; route inventoried |
| `/api/seller/bulk-products` | `app/api/seller/bulk-products/route.ts` | NOT TESTED live; route inventoried |
| `/api/seller-analytics` | `app/api/seller-analytics/route.ts` | NOT TESTED live; route inventoried |
| `/api/seller-finance` | `app/api/seller-finance/route.ts` | NOT TESTED live; route inventoried |
| `/api/storefront` | `app/api/storefront/route.ts` | NOT TESTED live; route inventoried |
| `/api/storefront-image/[key]` | `app/api/storefront-image/[key]/route.ts` | NOT TESTED live; route inventoried |
| `/api/streams` | `app/api/streams/route.ts` | NOT TESTED live; route inventoried |
| `/api/verification` | `app/api/verification/route.ts` | NOT TESTED live; route inventoried |
| `/api/videos` | `app/api/videos/route.ts` | NOT TESTED live; route inventoried |

### Other route handlers

| Route | Source file | Audit status |
|---|---|---|
| `/.well-known/assetlinks.json` | `app/.well-known/assetlinks.json/route.ts` | NOT TESTED live; route inventoried |
| `/affiliate/go` | `app/affiliate/go/route.ts` | NOT TESTED live; route inventoried |
| `/llms.txt` | `app/llms.txt/route.ts` | NOT TESTED live; route inventoried |
| `/robots.txt` | `app/robots.txt/route.ts` | NOT TESTED live; route inventoried |
| `/sitemap.xml` | `app/sitemap.xml/route.ts` | NOT TESTED live; route inventoried |

## Verified public observations

| Surface | Evidence from current browser run | Status |
|---|---|---|
| Homepage `/` | Page loaded; hero, navigation, categories, live empty state, product cards, seller cards, shopping guide, policies/footer were present. Product count displayed as 22. Click destinations and data authority were not comprehensively tested. | PARTIAL |
| Shop (`/#market`) | Shop heading, filter, location fallback, category controls, 22 products, pagination and Help & policies rendered. One product quick view opened with seller, price, stock, delivery and an honest “No reviews yet” message. | PARTIAL |
| Shop sort controls | The Market view rendered two separate sort inputs bound to the same `sort` state; the top one called `newest` “Recommended” while the lower one called it “Newest”. | FIXED IN SOURCE; saved as version 196, not deployed |
| For You `/for-you` | For You/Following/Watch Live tabs and video actions were visible. A video card appeared with controls, but the captured frame was black; playback and product action outcomes were not verified. | PARTIAL |
| Live `/#live` | No-broadcast empty state rendered. No active publisher was available; real publisher-to-viewer streaming, chat, deals and auctions were not tested. | PARTIAL |
| Messages `/messages` | Route entry redirected to sign-in. No authenticated conversation data or send/reply action was accessed. | PARTIAL |
| Sign-in / sign-up / password reset | Forms and links rendered. No credentials, account creation, password reset, or legal acceptance were submitted. | PARTIAL |

## Defect register

| Page | Component | Expected behaviour | Actual behaviour before fix | Duplicate? | Severity | Root cause | Fix and retest | Evidence |
|---|---|---|---|---|---|---|---|---|
| `/#market` | Sort products | One unambiguous sort selector with labels matching the selected ordering | Two selectors shared the same state; “Recommended” and “Newest” both mapped to `newest` | Yes | Medium | Market toolbar and lower market-controls block both rendered sort selectors for `view === "Market"` | Lower selector is now Home-only; Market selector label now says “Newest”. Full tests (248), build and `git diff --check` passed. Browser preview visual retest is blocked. | `app/revibe.tsx`; tests/build outputs |

## Duplicate controls

- **FIXED AND VERIFIED IN SOURCE:** Shop/Market sort appeared twice. Kept the top Shop selector and hid the lower selector on Market; retained the lower selector on Home where no top Market selector exists.
- Category dropdown and category button row both select category. They remain because they serve the mobile Shop design’s category-navigation and All Products requirements; no evidence established that one is broken.
- Repeated “Shop” and “Watch Live” calls to action appear in different homepage sections/footer locations. They are contextual entry points; no duplicate workflow was confirmed.

## Buyer, seller, admin and commerce audit

| Workflow group | Status | Limitation |
|---|---|---|
| Buyer account, wishlist, following, messages, order history | NOT TESTED | Authenticated test buyer unavailable; live account actions not attempted |
| Seller Centre, storefront creation, products, videos, messages, orders | NOT TESTED | No authorised seller test account; no mutations made |
| Admin console, review/moderation, roles, audit logs | NOT TESTED | No authorised admin test account; no privileged actions attempted |
| Checkout, payment initiation/verification, refunds | NOT TESTED live | No payment attempted; tests use provider fixtures only |
| Livestream publisher/viewer and auctions | NOT TESTED live | No active stream or authorised publisher test environment |
| Media transfer sizes, Lighthouse, browser matrix, responsive widths | NOT TESTED | Internal preview unavailable; production page was observed only at the current desktop viewport |

## Security and production readiness

Source and automated tests cover server-side ownership checks, admin permissions, webhook replay/idempotency, price tampering protections, stock reservations, duplicate submissions, private records and security headers. These tests use local fixtures and do not substitute for a live penetration test or role-based end-to-end run. No production security probes, real payments, account changes or customer-data writes were made.

The project README states the site is for controlled testing and is not approved to accept real customers or real payments; Flutterwave is documented as in test mode. This turn made no live settings changes. **Production readiness remains unverified and should not be claimed.**

## Quality scoring

A whole-site score out of 100 is **not assigned**: private roles, checkout, provider integrations, mobile breakpoints, accessibility interactions and performance metrics were not verified. Assigning scores to untested categories would be misleading. Public-surface findings above are provisional.

## Outstanding work, prioritised

1. Run responsive browser QA against the saved version after preview infrastructure is restored; capture before/after screenshots at the requested widths.
2. Use authorised buyer, seller and admin test accounts to complete the specified end-to-end journeys in a non-production environment.
3. Verify live message persistence, real stream publishing/playback and sandbox Flutterwave callbacks; do not use production transactions.
4. Measure Lighthouse/Core Web Vitals, image/video transfers and API timings; investigate the >500 kB client chunk.
5. Triage the 968 lint errors and 42 warnings, starting with auth/permission and runtime correctness findings.
6. Extend the button/form-level ledger after authenticated pages are available; all routes marked NOT TESTED above remain open items.

## Source changes

- `app/revibe.tsx`: removed duplicate Market sort control and corrected the `newest` option label.
- No deployment, real payment, customer data change, or live configuration change occurred.
