# Cash N Carry approved logo update

The approved logo attachment is retained byte-for-byte as `public/brand/cash-n-carry-approved-source.jpg` (the uploaded file had a `.png` filename but is JPEG data). The original legacy assets remain in `public/brand/` for rollback and historical references.

## Active web assets

- `cash-n-carry-logo-transparent-v2.webp`: trimmed transparent horizontal logo used by the shared `BrandLogo` component.
- `cash-n-carry-logo-fallback-v2.jpg`: light-background fallback used by browsers without WebP support and by email templates.
- `cash-n-carry-logo-horizontal-v2.webp`: trimmed opaque cream/light version.
- `cash-n-carry-logo-compact-v2.webp`: smaller responsive horizontal variant.
- `cash-n-carry-logo-dark-surface-v2.webp`: unchanged logo shown on a light panel for contrast on dark surfaces.
- `cash-n-carry-icon-transparent-v2.png`: icon-only transparent asset.
- `cash-n-carry-icon-v2-{16,32,48,180,192,512}.png`, `cash-n-carry-icon-v2-maskable.png`, `/favicon.ico`, and `/favicon.svg`: browser and install icon variants.

The transparent cutout uses a low-tolerance flood fill from the image edge. The white play symbol stays enclosed and visible; the opaque approved artwork remains available as the fallback. The WebP assets are small and the 512px app icon is 162 KB. The dark-surface rendition retains the exact logo on a cream panel to keep its approved dark-green lettering legible.

## Active placements

The shared logo component updates customer and marketplace headers, account screens, seller tools, admin tools, workspaces, and the email-template preview. Email delivery uses the JPEG fallback. Browser metadata, the web manifest, Android TWA manifest/source assets, and app icons use versioned V2 assets. Seller storefronts retain seller-provided logos and banners; the storefront and product-detail pages show only a small linked "Powered by" attribution in the neutral footer. Product details no longer use the Cash N Carry marketplace logo header.

## Rollback

Old logo files are intentionally retained. Reverting `app/brand.ts`, `app/brand-logo.tsx`, `app/layout.tsx`, and the manifest references restores the prior web assets. No seller media, customer data, or product data is modified.
