"use client";

import { useState } from "react";
import { CreditCard } from "lucide-react";
import { states } from "./nigeria-states";

export function OrderPaymentAction({ orderId, label, needsDelivery = false, initialName = "", initialPhone = "" }: { orderId: string; label: string; needsDelivery?: boolean; initialName?: string; initialPhone?: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [addressStep, setAddressStep] = useState(false);

  async function continuePayment(form?: HTMLFormElement) {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const details = form ? Object.fromEntries(new FormData(form)) : {};
      const response = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "retry-payment", id: orderId, ...details }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Payment could not be started.");
      if (!result.paymentLink) throw new Error("The secure payment link was not returned. Please retry or contact support.");
      window.location.assign(result.paymentLink);
    } catch (cause: any) {
      setError(cause?.message || "Payment could not be started. Please retry.");
      setBusy(false);
    }
  }

  return <div className="order-payment-action">
    {needsDelivery && (addressStep ? <form onSubmit={event => { event.preventDefault(); void continuePayment(event.currentTarget); }} className="auction-delivery-checkout">
      <p>Add your delivery details to confirm the delivery fee. You’ll continue to secure payment after this.</p>
      <label>Recipient name<input name="name" autoComplete="name" defaultValue={initialName} required maxLength={100}/></label>
      <label>Phone number<input name="phone" type="tel" autoComplete="tel" defaultValue={initialPhone} required maxLength={30}/></label>
      <label>Delivery state<select name="delivery_state" autoComplete="address-level1" defaultValue="" required><option value="">Choose state</option>{states.map(state => <option key={state} value={state}>{state}</option>)}</select></label>
      <label>Full delivery address<textarea name="address" autoComplete="street-address" placeholder="Street, area and city" required maxLength={700}/></label>
      <button type="submit" className="order-payment-action-button" disabled={busy}><CreditCard size={16} aria-hidden="true" />{busy ? "Preparing secure checkout…" : "Continue to secure payment"}</button>
    </form> : <button type="button" className="order-payment-action-button" onClick={() => setAddressStep(true)} disabled={busy}>
      <CreditCard size={16} aria-hidden="true" />Add delivery address &amp; pay
    </button>)}
    {!needsDelivery && <button type="button" className="order-payment-action-button" onClick={() => void continuePayment()} disabled={busy}>
      <CreditCard size={16} aria-hidden="true" />{busy ? "Preparing secure checkout…" : label}
    </button>}
    {error && <p role="alert">{error}</p>}
  </div>;
}
