import { env } from "cloudflare:workers";

let ready: Promise<void> | null = null;

export async function ensureVideoStorefrontSchema() {
  const db = env.DB;
  if (!db) throw Error("Database unavailable");
  const statements = [
    "CREATE TABLE IF NOT EXISTS storefronts (store TEXT PRIMARY KEY NOT NULL REFERENCES stores(id),slug TEXT NOT NULL UNIQUE,logo TEXT NOT NULL DEFAULT '',banner TEXT NOT NULL DEFAULT '',promo_banner TEXT NOT NULL DEFAULT '',template TEXT NOT NULL DEFAULT 'market',accent TEXT NOT NULL DEFAULT '#164B35',featured_products TEXT NOT NULL DEFAULT '[]',published INTEGER NOT NULL DEFAULT 0,updated TEXT NOT NULL,display_name TEXT NOT NULL DEFAULT '',description TEXT NOT NULL DEFAULT '',category TEXT NOT NULL DEFAULT '',surface_color TEXT NOT NULL DEFAULT '#FFFFFF')",
    "CREATE UNIQUE INDEX IF NOT EXISTS storefronts_slug ON storefronts(slug)",
    "CREATE INDEX IF NOT EXISTS reviews_product_rating_order ON reviews(product,order_id,rating)",
    "CREATE TABLE IF NOT EXISTS videos (id TEXT PRIMARY KEY NOT NULL,store TEXT NOT NULL REFERENCES stores(id),owner TEXT NOT NULL,media TEXT NOT NULL,thumbnail TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',hashtags TEXT NOT NULL DEFAULT '[]',status TEXT NOT NULL DEFAULT 'draft',published INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL,updated TEXT NOT NULL,moderation_note TEXT NOT NULL DEFAULT '')",
    "CREATE INDEX IF NOT EXISTS videos_feed ON videos(status,published,created)",
    "CREATE INDEX IF NOT EXISTS videos_store ON videos(store,created)",
    "CREATE TABLE IF NOT EXISTS video_creation_requests (owner TEXT NOT NULL,request_key TEXT NOT NULL,video TEXT NOT NULL,created TEXT NOT NULL,PRIMARY KEY(owner,request_key))",
    "CREATE INDEX IF NOT EXISTS video_creation_requests_video ON video_creation_requests(video)",
    "CREATE TABLE IF NOT EXISTS video_products (video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,product TEXT NOT NULL REFERENCES products(id),PRIMARY KEY(video,product))",
    "CREATE INDEX IF NOT EXISTS video_products_product ON video_products(product)",
    "CREATE TABLE IF NOT EXISTS video_likes (video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,user TEXT NOT NULL,created TEXT NOT NULL,PRIMARY KEY(video,user))",
    "CREATE TABLE IF NOT EXISTS video_saves (video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,user TEXT NOT NULL,created TEXT NOT NULL,PRIMARY KEY(video,user))",
    "CREATE TABLE IF NOT EXISTS video_comments (id TEXT PRIMARY KEY NOT NULL,video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,user TEXT NOT NULL,parent TEXT NOT NULL DEFAULT '',body TEXT NOT NULL,hidden INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL)",
    "CREATE INDEX IF NOT EXISTS video_comments_visible ON video_comments(video,hidden,created)",
    "CREATE TABLE IF NOT EXISTS video_events (id TEXT PRIMARY KEY NOT NULL,video TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,visitor TEXT NOT NULL,kind TEXT NOT NULL,day TEXT NOT NULL,created TEXT NOT NULL,UNIQUE(video,visitor,kind,day))",
    "CREATE INDEX IF NOT EXISTS video_events_video ON video_events(video,kind,created)",
    "CREATE TABLE IF NOT EXISTS video_moderation_history (id TEXT PRIMARY KEY NOT NULL,video TEXT NOT NULL REFERENCES videos(id),actor TEXT NOT NULL,status TEXT NOT NULL,note TEXT NOT NULL,created TEXT NOT NULL)",
  ];
  // D1 exposes `run()` on prepared statements. Test adapters and read-only
  // database wrappers can omit it when their migrations were loaded upfront.
  if (typeof db.prepare(statements[0]).run !== "function") return;
  ready ??= (async () => {
    for (const statement of statements) await db.prepare(statement).run();
    const backgroundColumn = await db.prepare("SELECT COUNT(*) AS count FROM pragma_table_info('storefronts') WHERE name='background_color'").first<{ count: number }>();
    if (!Number(backgroundColumn?.count || 0)) {
      try {
        await db.prepare("ALTER TABLE storefronts ADD COLUMN background_color TEXT NOT NULL DEFAULT '#fff8ef'").run();
      } catch (error) {
        const concurrentlyAdded = await db.prepare("SELECT COUNT(*) AS count FROM pragma_table_info('storefronts') WHERE name='background_color'").first<{ count: number }>();
        if (!Number(concurrentlyAdded?.count || 0)) throw error;
      }
    }
    const promoBannerColumn = await db.prepare("SELECT COUNT(*) AS count FROM pragma_table_info('storefronts') WHERE name='promo_banner'").first<{ count: number }>();
    if (!Number(promoBannerColumn?.count || 0)) {
      try {
        await db.prepare("ALTER TABLE storefronts ADD COLUMN promo_banner TEXT NOT NULL DEFAULT ''").run();
      } catch (error) {
        const concurrentlyAdded = await db.prepare("SELECT COUNT(*) AS count FROM pragma_table_info('storefronts') WHERE name='promo_banner'").first<{ count: number }>();
        if (!Number(concurrentlyAdded?.count || 0)) throw error;
      }
    }
    const buyNowColorColumn = await db.prepare("SELECT COUNT(*) AS count FROM pragma_table_info('storefronts') WHERE name='buy_now_color'").first<{ count: number }>();
    if (!Number(buyNowColorColumn?.count || 0)) {
      try {
        await db.prepare("ALTER TABLE storefronts ADD COLUMN buy_now_color TEXT NOT NULL DEFAULT '#164B35'").run();
      } catch (error) {
        const concurrentlyAdded = await db.prepare("SELECT COUNT(*) AS count FROM pragma_table_info('storefronts') WHERE name='buy_now_color'").first<{ count: number }>();
        if (!Number(concurrentlyAdded?.count || 0)) throw error;
      }
    }
    const surfaceColorColumn = await db.prepare("SELECT COUNT(*) AS count FROM pragma_table_info('storefronts') WHERE name='surface_color'").first<{ count: number }>();
    if (!Number(surfaceColorColumn?.count || 0)) {
      try {
        await db.prepare("ALTER TABLE storefronts ADD COLUMN surface_color TEXT NOT NULL DEFAULT '#FFFFFF'").run();
      } catch (error) {
        const concurrentlyAdded = await db.prepare("SELECT COUNT(*) AS count FROM pragma_table_info('storefronts') WHERE name='surface_color'").first<{ count: number }>();
        if (!Number(concurrentlyAdded?.count || 0)) throw error;
      }
    }
    const viewIndex = await db
      .prepare("SELECT name FROM sqlite_master WHERE type='index' AND name=?")
      .bind("video_events_unique_device_view")
      .first();
    if (!viewIndex) {
      // Older view rows were recorded once per day. Keep one historical row
      // per browser/device and video before enforcing lifetime deduplication.
      await db
        .prepare("DELETE FROM video_events WHERE kind='view' AND rowid NOT IN (SELECT MIN(rowid) FROM video_events WHERE kind='view' GROUP BY video,visitor)")
        .run();
      await db
        .prepare("CREATE UNIQUE INDEX video_events_unique_device_view ON video_events(video,visitor) WHERE kind='view'")
        .run();
    }
  })().catch((error) => { ready = null; throw error; });
  await ready;
}
