import { env } from "cloudflare:workers";

let ready: Promise<void> | null = null;
let readyDatabase: unknown = null;

export async function ensureLiveStreamEventsSchema() {
  if (!env.DB) throw Error("Storage unavailable");
  if (!ready || readyDatabase !== env.DB) {
    readyDatabase = env.DB;
    ready = (async () => {
      await env.DB!.prepare(`CREATE TABLE IF NOT EXISTS live_stream_events (
        id TEXT PRIMARY KEY,
        stream TEXT NOT NULL REFERENCES streams(id),
        type TEXT NOT NULL CHECK(type IN ('bid','purchase')),
        name TEXT NOT NULL,
        message TEXT NOT NULL,
        created TEXT NOT NULL
      )`).run();
      await env.DB!.prepare("CREATE INDEX IF NOT EXISTS live_stream_events_recent ON live_stream_events(stream,created DESC)").run();
    })().catch((error) => {
      ready = null;
      readyDatabase = null;
      throw error;
    });
  }
  await ready;
}
