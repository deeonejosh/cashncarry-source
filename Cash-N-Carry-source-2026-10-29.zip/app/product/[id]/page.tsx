import { eligibleSellerSQL } from "../../seller-activation";
import ProductGallery from "../../product-gallery";
import { getChatGPTUser } from "../../chatgpt-auth";
import ProductPurchase from "../../product-purchase";
import { brand } from "../../brand";
import { env } from "cloudflare:workers";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ensureCompetitiveSchema } from "../../competitive-schema";
import AnalyticsTracker from "../../analytics-tracker";
import { absoluteProductImage, productSeoDescription, usableProductDescription } from "../../product-seo";
import { ensureVideoStorefrontSchema } from "../../video-storefront-schema";
import ReturnGuidance from "../../return-guidance";
import ProductReviews from "../../product-reviews";
import StoreLogo from "../../store-logo";
import { MessageSquare, ShoppingCart } from "lucide-react";
import ProductShare from "../../product-share";
import { MarketplaceFooter, StorefrontFooter } from "../../shopping-design";
import MarketplaceHeader from "../../marketplace-header";
import ImageAsset from "../../image-asset";
import { storefrontImageSrcSet, storefrontImageUrl } from "../../storefront-image-url";
import Link from "next/link";
import { trustBadgeImage } from "../../trust-badge-image";
import { acceptsReturns, qualifiesForFastDelivery, topSellerEligibilitySQL } from "../../trust-badge-eligibility";
import { ensureTrustBadgeSchema } from "../../trust-badge-schema";
type ProductDetails = {
  id: string;
  store: string;
  name: string;
  description: string;
  category: string;
  price: number;
  stock: number;
  image: string;
  images: string | null;
  video: string;
  variants: string | null;
  seller: string;
  store_slug?: string | null;
  store_buy_now_color?: string | null;
  seller_logo?: string | null;
  seller_owner: string;
  verified: number;
  official_store: number;
  top_seller: number;
  delivery_fee: number | null;
  delivery_days: string | null;
  return_policy: string | null;
  coverage: string | null;
  seller_location: string | null;
  location: string;
  bundle?: { title: string; price: number; items: { name_snapshot: string; price_snapshot: number; quantity: number }[] } | null;
};
function safeJsonArray(value: unknown): any[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== "string" || !value) return [];
  try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : []; } catch { return []; }
}
async function product(id: string) {
  await ensureCompetitiveSchema();
  await ensureVideoStorefrontSchema();
  await ensureTrustBadgeSchema();
  const result = await env.DB?.prepare(
    `SELECT p.*,COALESCE(NULLIF(f.display_name,''),s.name) AS seller,s.owner AS seller_owner,s.verified,s.official_store,CASE WHEN ${topSellerEligibilitySQL("s")} THEN 1 ELSE 0 END AS top_seller,CASE WHEN f.published=1 THEN f.logo END AS seller_logo,CASE WHEN f.published=1 THEN f.slug END AS store_slug,CASE WHEN f.published=1 THEN f.buy_now_color END AS store_buy_now_color,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy,s.coverage,s.location AS seller_location FROM products p JOIN stores s ON s.id=p.store LEFT JOIN storefronts f ON f.store=s.id WHERE p.id=? AND p.active=1 AND s.suspended=0 AND ` + eligibleSellerSQL() + " AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
  )
    .bind(id)
    .first<ProductDetails>();
  if(!result)return result;
  const bundle:any=await env.DB?.prepare("SELECT id,title,price FROM product_bundles WHERE product=? AND active=1").bind(result.id).first();
  if(bundle){const items:any=await env.DB?.prepare("SELECT name_snapshot,price_snapshot,quantity FROM product_bundle_items WHERE bundle=? ORDER BY name_snapshot").bind(bundle.id).all();result.bundle={title:bundle.title,price:Number(bundle.price),items:items.results||[]};}
  return result;
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const p = await product(id);
  const description = p
    ? productSeoDescription(p.name, p.description)
    : `Browse products from Nigerian sellers on ${brand.name}.`;
  const image = absoluteProductImage(p?.image, env.SITE_URL || "https://cashncarryng.com");
  return {
    title: p
      ? p.name + (" | " + brand.name)
      : "Product unavailable | " + brand.name,
    alternates: { canonical: "/product/" + id },
    description,
    openGraph: p
      ? {
          url: "/product/" + p.id,
          title: `${p.name} | ${brand.name}`,
          siteName: brand.name,
          description,
          ...(image ? { images: [{ url: image }] } : {}),
        }
      : undefined,
    twitter: p
      ? {
          card: "summary_large_image",
          title: `${p.name} | ${brand.name}`,
          description,
          images: image ? [image] : [],
        }
      : undefined,
  };
}
function safeProductReturnTo(value?: string) {
  const fallback = "/?browse=1#market";
  if (!value || !value.startsWith("/") || value.startsWith("//") || value.includes("\\")) return fallback;
  try {
    const url = new URL(value, "https://cashncarryng.com");
    if (url.origin !== "https://cashncarryng.com") return fallback;
    const allowed = url.pathname === "/" || url.pathname === "/for-you" || url.pathname === "/live-auctions" || /^\/store\/[A-Za-z0-9_-]+$/.test(url.pathname);
    return allowed ? url.pathname + url.search + url.hash : fallback;
  } catch { return fallback; }
}
export default async function Product({
  params, searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ returnTo?: string }>;
}) {
  await ensureVideoStorefrontSchema();
  const p = await product((await params).id);
  if (!p) notFound();
  const productDetails = usableProductDescription(p.description);
  const hasDetailedDescription = productDetails.length >= 20;
  const structuredProductDescription = hasDetailedDescription
    ? productDetails
    : productSeoDescription(p.name, p.description);
  const user = await getChatGPTUser();
  const returnTo = safeProductReturnTo((await searchParams).returnTo);
  const sellerContext = returnTo.startsWith("/store/");
  const relatedVideos = (await env.DB!.prepare("SELECT v.id,v.media,v.thumbnail,v.caption,s.name AS seller,f.slug FROM video_products vp JOIN videos v ON v.id=vp.video JOIN stores s ON s.id=v.store LEFT JOIN storefronts f ON f.store=s.id WHERE vp.product=? AND v.status='approved' AND v.published=1 AND " + eligibleSellerSQL("s") + " ORDER BY v.created DESC LIMIT 6").bind(p.id).all<any>()).results;
  const relatedProducts = (await env.DB!.prepare("SELECT p.id,p.name,p.price,p.stock,p.image,p.variants,(SELECT ROUND(AVG(r.rating),1) FROM reviews r JOIN orders o ON o.id=r.order_id AND o.status='delivered' WHERE r.product=p.id) AS rating,(SELECT COUNT(*) FROM reviews r JOIN orders o ON o.id=r.order_id AND o.status='delivered' WHERE r.product=p.id) AS review_count FROM products p WHERE p.store=? AND p.id!=? AND p.active=1 AND p.stock>0 ORDER BY p.featured DESC,p.created DESC LIMIT 5").bind(p.store,p.id).all<any>()).results;
  const [reviewSummary, productReviews] = await Promise.all([
    env.DB!.prepare("SELECT COUNT(*) AS count,COALESCE(AVG(r.rating),0) AS average FROM reviews r JOIN orders o ON o.id=r.order_id WHERE r.product=? AND o.status='delivered'").bind(p.id).first<any>(),
    env.DB!.prepare("SELECT r.rating,r.comment,r.created FROM reviews r JOIN orders o ON o.id=r.order_id WHERE r.product=? AND o.status='delivered' ORDER BY r.created DESC LIMIT 20").bind(p.id).all<any>(),
  ]);
  const saved = user
    ? Boolean(
        await env
          .DB!.prepare("SELECT id FROM favourites WHERE user=? AND product=?")
          .bind(user.userId, p.id)
          .first(),
      )
    : false;
  return (
    <>
      <AnalyticsTracker event="product_view" store={p.store} product={p.id}/>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Product",
            name: p.name,
            description: structuredProductDescription,
            ...(absoluteProductImage(p.image, env.SITE_URL || "https://cashncarryng.com")
              ? { image: absoluteProductImage(p.image, env.SITE_URL || "https://cashncarryng.com") }
              : {}),
            url: new URL("/product/" + p.id, "https://www.cashncarryng.com").href,
            offers: {
              "@type": "Offer",
              price: p.price,
              priceCurrency: "NGN",
              availability: p.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
              seller: { "@type": "Organization", name: p.seller },
            },
          }).replace(/</g, "\\u003c"),
        }}
      />
      {sellerContext ? <header className="seller-product-header">
        <Link href={returnTo} className="seller-product-back" aria-label="Back to store">‹</Link>
        <a href={"/store/" + (p.store_slug || p.store)} className="seller-product-identity"><StoreLogo name={p.seller} src={p.seller_logo} size={42} /><span><strong>{p.seller}</strong></span></a>
          <Link href="/?browse=1&open=cart#market" className="seller-product-cart" aria-label="Open shopping cart"><ShoppingCart size={19}/></Link>
      </header> : <MarketplaceHeader />}
      <main
        id="main-content"
        tabIndex={-1}
        className={`customer-page public-product-page seller-product-page${sellerContext ? " seller-context-product-page" : " marketplace-product-page"}`}
      >
        <nav className="seller-product-breadcrumb" aria-label="Breadcrumb"><a href={"/store/" + (p.store_slug || p.store)}>{p.seller}</a><span aria-hidden="true">/</span><span>{p.category}</span></nav>
        <div className="public-product-layout">
          <ProductGallery
            name={p.name}
            images={[...new Set<string>([p.image, ...safeJsonArray(p.images).filter((image): image is string => typeof image === "string")].filter(Boolean))]}
            video={p.video}
          />
          <section className="public-product-information">
            <p className="eyebrow">{p.category}</p>
            <h1>{p.name}</h1>
            <div className="product-review-summary-line">{Number(reviewSummary?.count || 0) > 0 ? <a href="#product-reviews" aria-label={`${Number(reviewSummary.average).toFixed(1)} out of 5 from ${reviewSummary.count} reviews`}>★ {Number(reviewSummary.average).toFixed(1)} <span>({Number(reviewSummary.count)} reviews)</span></a> : <span>No reviews yet</span>}{p.stock > 0 ? <span className="product-stock-status">In stock</span> : <span className="product-stock-status is-out">Out of stock</span>}</div>
            <p className="product-variant-subtitle">{p.category}</p>
            <div className="product-price-summary"><strong>₦{Number(p.price).toLocaleString("en-NG")}</strong><span>NGN</span></div>
            {p.bundle&&<section className="public-bundle-summary" aria-label="Bundle contents"><h2>Included in this bundle</h2><ul>{p.bundle.items.map((item,i)=><li key={`${item.name_snapshot}-${i}`}>{item.quantity} × {item.name_snapshot}<span>{"₦"+Number(item.price_snapshot*item.quantity).toLocaleString("en-NG")}</span></li>)}</ul><p>Individual total <strong>₦{p.bundle.items.reduce((sum,item)=>sum+item.price_snapshot*item.quantity,0).toLocaleString("en-NG")}</strong> · Bundle price <strong>₦{p.bundle.price.toLocaleString("en-NG")}</strong> · You save <strong>₦{Math.max(0,p.bundle.items.reduce((sum,item)=>sum+item.price_snapshot*item.quantity,0)-p.bundle.price).toLocaleString("en-NG")}</strong></p></section>}
            <ProductPurchase
              initiallySaved={saved}
              signedIn={Boolean(user)}
              buyNowColor={sellerContext ? p.store_buy_now_color || "#164B35" : "#164B35"}
              product={{
                id: p.id,
                store: p.store,
                price: p.price,
                stock: p.stock,
                variants: p.variants,
              }}
            />
            <div className="marketplace-product-seller"><StoreLogo name={p.seller} src={p.seller_logo} size={42}/><span><strong>{p.seller}</strong><span className="cnc-seller-trust-badges">{p.official_store===1&&<img {...trustBadgeImage("official-store")} className="cnc-trust-badge cnc-trust-badge--small"/>}{p.top_seller===1&&<img {...trustBadgeImage("top-seller")} className="cnc-trust-badge cnc-trust-badge--small"/>}</span></span><a href={"/store/" + (p.store_slug || p.store)}>Visit Store</a></div>
            <div className="product-secondary-actions">{user?.userId!==p.seller_owner&&<a className="messages-contact-seller" href={`/messages?${new URLSearchParams({store:p.store,product:p.id})}`}><MessageSquare size={18}/>Message seller</a>}<ProductShare name={p.name}/></div>
            <div className="delivery-summary" id="product-delivery">
              <h2>Delivery &amp; returns</h2>
              <p>Seller location: {p.seller_location || p.location}</p>
              <details className="product-coverage"><summary>Delivery coverage</summary><p>
                Delivers to:{" "}
                {safeJsonArray(p.coverage).filter((value) => typeof value === "string").join(", ") ||
                  "Confirm coverage with seller"}
              </p></details>
              <p>
                Delivery: {p.delivery_fee === null || p.delivery_fee === undefined ? "Fee confirmed at checkout" : "₦" + p.delivery_fee.toLocaleString()} ·{" "}
                {p.delivery_days || "Confirm estimate with seller"}
              </p>
              <p className="product-delivery-estimate-note">Delivery coverage, fee and timing are confirmed for your address at checkout.</p>
              {qualifiesForFastDelivery(p.delivery_days) && <img {...trustBadgeImage("fast-delivery")} className="cnc-trust-badge" />}
              {acceptsReturns(p.return_policy) && <a className="cnc-trust-badge-link" href="/refunds" aria-label="Easy Returns — read the returns and refunds policy"><img {...trustBadgeImage("easy-returns")} className="cnc-trust-badge" /></a>}
              <ReturnGuidance sellerTerms={p.return_policy} />
            </div>

          </section>
        </div>
        <nav className="product-detail-tabs" aria-label="Product information"><a href="#product-details">Details</a><a href="#product-reviews">Reviews ({Number(reviewSummary?.count||0)})</a><a href="#product-delivery">Delivery &amp; returns</a><a href="#product-specifications">Specifications</a></nav>
        <section id="product-details" className="product-information-panel"><h2>Product details</h2>{hasDetailedDescription ? <p>{p.description}</p> : <p>The seller has not provided additional product details yet.</p>}</section>
        <section id="product-specifications" className="product-information-panel"><h2>Specifications</h2><dl><div><dt>Category</dt><dd>{p.category}</dd></div><div><dt>Seller</dt><dd>{p.seller}</dd></div><div><dt>Availability</dt><dd>{p.stock > 0 ? "In stock" : "Out of stock"}</dd></div></dl>{safeJsonArray(p.variants).length > 0 && <p>Available options and stock are shown above.</p>}</section>
        {relatedVideos.length > 0 && <section className="product-video-discovery"><div className="section-heading"><h2>See it in action</h2><a href={"/for-you?product=" + encodeURIComponent(p.id)}>More videos</a></div><div className="product-video-grid">{relatedVideos.map((v:any)=><article key={v.id}><video src={v.media} poster={v.thumbnail||undefined} controls playsInline preload="none" aria-label={v.caption||p.name+" video"}/><p>{v.caption}</p><a href={`/for-you?v=${encodeURIComponent(v.id)}`}>Open in For You · {v.seller}</a></article>)}</div></section>}
        {relatedProducts.length > 0 && <section className="more-from-store" aria-labelledby="more-from-store-title"><div className="section-heading"><h2 id="more-from-store-title">More from this store</h2><Link href={`/store/${encodeURIComponent(p.store_slug || p.store)}#store-products`}>See all</Link></div><div>{relatedProducts.map((item: any) => <article key={item.id}><Link href={`/product/${encodeURIComponent(item.id)}?returnTo=${encodeURIComponent(`/store/${p.store_slug || p.store}#store-products`)}`}><ImageAsset src={storefrontImageUrl(item.image, 320)} srcSet={storefrontImageSrcSet(item.image, [320,480,640])} sizes="(max-width: 720px) 42vw, 220px" fallbackSrc={item.image} alt={item.name} width="220" height="220" loading="lazy"/><strong>{item.name}</strong></Link><span>₦{Number(item.price).toLocaleString("en-NG")}</span>{Number(item.review_count)>0&&<small>★ {Number(item.rating).toFixed(1)} · {Number(item.review_count)} reviews</small>}</article>)}</div></section>}
        <ProductReviews productName={p.name} productId={p.id} signedIn={Boolean(user)} average={Number(reviewSummary?.average || 0)} count={Number(reviewSummary?.count || 0)} reviews={productReviews.results.map((review: any) => ({ rating: Number(review.rating), comment: String(review.comment || ""), created: String(review.created || "") }))} />
      </main>
      {sellerContext ? <StorefrontFooter storeName={p.seller} storeDescription={p.description} storeId={p.store}/> : <MarketplaceFooter />}
    </>
  );
}
