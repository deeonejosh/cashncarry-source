"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Eye, EyeOff } from "lucide-react";
import BrandLogo from "../brand-logo";
import { MIN_PASSWORD_LENGTH, safeReturnPath } from "../auth-navigation";
type Mode = "sign-in" | "sign-up" | "reset" | "password" | "verify";
export default function AuthForm({
  initialMode = "sign-in",
  available = false,
  legacy = false,
  destination = "/#market",
}: {
  initialMode?: Mode;
  available?: boolean;
  legacy?: boolean;
  destination?: string;
}) {
  const [mode, setMode] = useState<Mode>(initialMode);
  const [returnTo, setReturnTo] = useState(safeReturnPath(destination));
  const [verificationEmail, setVerificationEmail] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const lock = useRef(false);
  const controller = useRef<AbortController | null>(null);
  const status = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const p = new URLSearchParams(location.search);
    setReturnTo(
      safeReturnPath(p.get("returnTo") || p.get("return_to") || destination),
    );
    if (p.get("token")) setMode("password");
    else if (legacy && p.get("mode") === "sign-up") setMode("sign-up");
    else if (legacy && p.has("reset")) setMode("reset");
    if (p.get("error")) {
      setMode("reset");
      setMessage(
        "This reset link is invalid or expired. Request a new password-reset email.",
      );
    } else if (p.get("verified")) {
      setSuccess(true);
      setMessage("If you’ve verified your email, sign in to continue.");
    }
    return () => controller.current?.abort();
  }, [legacy, destination]);
  function link(path: string) {
    return path + "?returnTo=" + encodeURIComponent(returnTo);
  }
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (lock.current || !available) return;
    const form = e.currentTarget;
    const f = new FormData(form);
    const email = String(f.get("email") || "").trim();
    const name = String(f.get("name") || "").trim();
    const password = String(f.get("password") || "");
    const next: Record<string, string> = {};
    if (mode === "sign-up" && (!name || name.length > 100))
      next.name = "Enter your full name (up to 100 characters).";
    if (mode !== "password" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      next.email = "Enter a valid email address.";
    if (["sign-in", "sign-up", "password"].includes(mode) && !password)
      next.password = "Enter your password.";
    else if (
      (mode === "sign-up" || mode === "password") &&
      password.length < MIN_PASSWORD_LENGTH
    )
      next.password = `Use at least ${MIN_PASSWORD_LENGTH} characters.`;
    if (
      ["sign-up", "password"].includes(mode) &&
      password !== String(f.get("confirmPassword") || "")
    )
      next.confirmPassword = "The passwords do not match.";
    if (mode === "sign-up" && f.get("terms") !== "on")
      next.terms = "Accept the Terms to create an account.";
    setErrors(next);
    setMessage("");
    setSuccess(false);
    if (Object.keys(next).length) {
      form
        .querySelector<HTMLElement>(`[name="${Object.keys(next)[0]}"]`)
        ?.focus();
      return;
    }
    const params = new URLSearchParams(location.search);
    if (mode === "password" && !params.get("token")) {
      setMessage("Open your email reset link, or request a new one below.");
      return;
    }
    lock.current = true;
    setBusy(true);
    const abort = new AbortController();
    controller.current = abort;
    const timeout = setTimeout(() => abort.abort(), 15000);
    const verifyReturn = link("/sign-in") + "&verified=1";
    const paths = {
      "sign-in": "sign-in/email",
      "sign-up": "sign-up/email",
      reset: "request-password-reset",
      password: "reset-password",
      verify: "send-verification-email",
    };
    try {
      let body: Record<string, unknown>;
      if (mode === "sign-up") {
        const versionResponse = await fetch("/api/policies/terms", { cache: "no-store", signal: abort.signal });
        const versionData = await versionResponse.json().catch(() => null) as {version?:number; error?:string} | null;
        if (!versionResponse.ok || typeof versionData?.version !== "number" || !Number.isSafeInteger(versionData.version))
          throw Error(versionData?.error || "Current Terms are unavailable. Please try again later.");
        body = { email, name, password, termsAccepted: true, termsVersion: versionData.version, callbackURL: verifyReturn };
      } else if (mode === "verify") body = { email, callbackURL: verifyReturn };
      else if (mode === "password") body = { newPassword: password, token: params.get("token") };
      else if (mode === "reset") body = { email, redirectTo: location.origin + link("/forgot-password") };
      else body = { email, password, callbackURL: returnTo };
      const r = await fetch("/api/auth/" + paths[mode], {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: abort.signal,
      });
      const d = await r.json().catch(() => null) as { message?: string; code?: string; twoFactorRedirect?: boolean } | null;
      if (!d || typeof d !== "object" || Array.isArray(d))
        throw Error("The server could not confirm this request. Please retry. If you were creating an account, try signing in or requesting another verification email first.");
      if (!r.ok) {
        if (d.code === "EMAIL_NOT_VERIFIED") setVerificationEmail(email);
        throw Error(
          d.code === "EMAIL_NOT_VERIFIED"
            ? "Verify your email before signing in. You can request another verification email below."
            : d.message || "Unable to continue. Please retry.",
        );
      }
      if (mode === "sign-in" && d.twoFactorRedirect) {
        window.location.assign("/two-factor?returnTo=" + encodeURIComponent(returnTo));
        return;
      }
      if (mode === "sign-in") {
        try {
          localStorage.setItem("cash-n-carry:welcome-seen:v1", "1");
        } catch {}
        window.location.assign(returnTo);
        return;
      }
      setSuccess(true);
      setMessage(
        mode === "sign-up"
          ? "Check your email to verify your account before signing in."
          : mode === "password"
            ? "Password changed. Sign in with your new password."
            : mode === "verify"
              ? "If this account needs verification, a new verification email will be sent."
              : "If this email has an account, a reset link will be sent.",
      );
      form.reset();
      if (mode === "sign-up") setVerificationEmail(email);
      if (mode === "password") {
        window.history.replaceState(null, "", link("/sign-in"));
        setMode("sign-in");
        setShowPassword(false);
      }
    } catch (err) {
      if (!abort.signal.aborted || controller.current === abort)
        setMessage(
          err instanceof Error && err.name !== "AbortError"
            ? err.message
            : "The request timed out. Check your connection and retry.",
        );
    } finally {
      clearTimeout(timeout);
      lock.current = false;
      setBusy(false);
      controller.current = null;
      status.current?.focus();
    }
  }
  const fieldError = (name: string) =>
    errors[name] ? (
      <span id={name + "-error"} className="entry-field-error">
        {errors[name]}
      </span>
    ) : null;
  const title =
    mode === "verify"
      ? "Verify your email."
      : mode === "sign-up"
        ? "Create your account."
        : mode === "sign-in"
          ? "Welcome back."
          : mode === "reset"
            ? "Forgot your password?"
            : "Choose a new password.";
  return (
    <main id="main-content" tabIndex={-1} className="entry-shell">
      <section
        className="entry-panel auth-panel"
        aria-labelledby="auth-heading"
      >
        <a className="entry-back" href={returnTo} aria-label="Back">
          <ArrowLeft aria-hidden="true" size={24} />
        </a>
        <BrandLogo />
        <h1 id="auth-heading">
          {available
            ? title
            : mode === "sign-up"
              ? "Join Cash N Carry."
              : "Sign in to Cash N Carry."}
        </h1>
        <p className="entry-intro">
          {!available
            ? mode === "sign-up"
              ? "Get started with your ChatGPT account, then discover sellers and shop your favourites."
              : "Sign in with ChatGPT to save your cart and place an order."
            : mode === "sign-in"
              ? "Sign in to continue shopping."
              : mode === "sign-up"
                ? "Discover local sellers and shop your favourites."
                : mode === "reset"
                  ? "Enter your email and we’ll send you a reset link."
                  : mode === "verify"
                    ? "Enter your email to request a new verification link."
                    : "Use a strong password to protect your account."}
        </p>
        {!available && (
          <p className="entry-notice" role="status">
            Email accounts are not configured yet. You can browse freely or use
            the existing ChatGPT sign-in below.
          </p>
        )}
        {available && (
          <form key={mode} onSubmit={submit} noValidate aria-busy={busy}>
            <fieldset className="entry-fields" disabled={busy}>
              {mode === "sign-up" && (
                <div className="entry-field">
                  <label htmlFor="name">Full name</label>
                  <input
                    id="name"
                    name="name"
                    autoComplete="name"
                    placeholder="Enter your full name"
                    required
                    maxLength={100}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? "name-error" : undefined}
                  />
                  {fieldError("name")}
                </div>
              )}
              {mode !== "password" && (
                <div className="entry-field">
                  <label htmlFor="email">Email address</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    inputMode="email"
                    autoComplete="email"
                    defaultValue={verificationEmail}
                    autoCapitalize="none"
                    spellCheck={false}
                    placeholder="Enter your email"
                    required
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? "email-error" : undefined}
                  />
                  {fieldError("email")}
                </div>
              )}
              {["sign-in", "sign-up", "password"].includes(mode) && (
                <div className="entry-field">
                  <label htmlFor="password">
                    {mode === "password" ? "New password" : "Password"}
                  </label>
                  <div className="entry-password">
                    <input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      autoComplete={
                        mode === "sign-in" ? "current-password" : "new-password"
                      }
                      placeholder={
                        mode === "sign-up"
                          ? "Create a password"
                          : "Enter your password"
                      }
                      required
                      minLength={
                        mode === "sign-in" ? undefined : MIN_PASSWORD_LENGTH
                      }
                      aria-invalid={Boolean(errors.password)}
                      aria-describedby={
                        [
                          mode !== "sign-in" ? "password-help" : "",
                          errors.password ? "password-error" : "",
                        ]
                          .filter(Boolean)
                          .join(" ") || undefined
                      }
                    />
                    <button
                      type="button"
                      aria-label={
                        showPassword ? "Hide password" : "Show password"
                      }
                      aria-pressed={showPassword}
                      onClick={() => setShowPassword((v) => !v)}
                    >
                      {showPassword ? <EyeOff size={21} /> : <Eye size={21} />}
                    </button>
                  </div>
                  {mode !== "sign-in" && (
                    <small id="password-help">
                      Use at least {MIN_PASSWORD_LENGTH} characters.
                    </small>
                  )}
                  {fieldError("password")}
                </div>
              )}
              {["sign-up", "password"].includes(mode) && (
                <div className="entry-field">
                  <label htmlFor="confirmPassword">Confirm password</label>
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showPassword ? "text" : "password"}
                    autoComplete="new-password"
                    required
                    aria-invalid={Boolean(errors.confirmPassword)}
                    aria-describedby={
                      errors.confirmPassword
                        ? "confirmPassword-error"
                        : undefined
                    }
                  />
                  {fieldError("confirmPassword")}
                </div>
              )}
              {mode === "sign-in" && (
                <a className="entry-forgot" href={link("/forgot-password")}>
                  Forgot password?
                </a>
              )}
              {mode === "sign-up" && (
                <div className="entry-terms">
                  <label>
                    <input
                      type="checkbox"
                      name="terms"
                      required
                      aria-invalid={Boolean(errors.terms)}
                      aria-describedby={
                        errors.terms ? "terms-error" : undefined
                      }
                    />
                    <span>
                      I agree to the{" "}
                      <a href="/terms" target="_blank" rel="noopener">
                        Terms
                      </a>{" "}
                      and have read the{" "}
                      <a
                        href="/privacy"
                        target="_blank"
                        rel="noopener"
                      >
                        Privacy Notice
                      </a>
                      .
                    </span>
                  </label>
                  {fieldError("terms")}
                </div>
              )}
              <button className="entry-primary" disabled={busy}>
                {busy
                  ? "Please wait…"
                  : mode === "sign-up"
                    ? "Create account"
                    : mode === "sign-in"
                      ? "Sign in"
                      : mode === "reset"
                        ? "Send reset link"
                        : mode === "verify"
                          ? "Send verification email"
                          : "Update password"}
              </button>
            </fieldset>
          </form>
        )}
        <div
          ref={status}
          tabIndex={-1}
          className={
            message
              ? `entry-message ${success ? "is-success" : "is-error"}`
              : ""
          }
          role={success ? "status" : "alert"}
        >
          {message}
        </div>
        {available && verificationEmail && mode !== "verify" && (
          <button
            className="entry-resend"
            disabled={busy}
            onClick={() => {
              setMode("verify");
              setMessage("");
              setSuccess(false);
              setErrors({});
            }}
          >
            Resend verification email
          </button>
        )}
        {available && ["sign-in", "sign-up"].includes(mode) && (
          <p className="entry-switch">
            {mode === "sign-up" ? (
              <>
                Already have an account? <a href={link("/sign-in")}>Sign in</a>
              </>
            ) : (
              <>
                New to Cash N Carry?{" "}
                <a href={link("/sign-up")}>Create account</a>
              </>
            )}
          </p>
        )}
        {available && mode !== "sign-in" && mode !== "sign-up" && (
          <p className="entry-switch">
            <a href={link("/sign-in")}>Back to sign in</a>
            {mode === "password" && (
              <>
                {" "}
                ·{" "}
                <a href={link("/forgot-password")}>Request a new reset link</a>
              </>
            )}
          </p>
        )}
        <Link className="entry-browse" href="/?browse=1#market">
          Browse without an account
        </Link>
        {available && <p className="entry-divider">or</p>}
        <a
          className={
            available ? "entry-chatgpt" : "entry-chatgpt entry-provider-primary"
          }
          href={
            "/signin-with-chatgpt?return_to=" + encodeURIComponent(returnTo)
          }
        >
          Continue with ChatGPT
        </a>
        <footer className="entry-footer">
          <a href="/terms">Terms</a>
          <a href="/privacy">Privacy Notice</a>
        </footer>
      </section>
    </main>
  );
}
