"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import {
  Package,
  Heart,
  LifeBuoy,
  Bell,
  Store,
  ShieldCheck,
  ChevronRight,
  LogOut,
} from "lucide-react";
import { CustomerNavigation } from "../customer-shell";
import { signOutEmailSession } from "../auth-navigation";
const sections = [
  ["Creator Centre", "/creator", Store],
  ["Orders & tracking", "/?browse=1#orders", Package],
  ["Saved items", "/workspace?tab=Saved%20products", Heart],
  ["Notification preferences", "/workspace?tab=Notification%20preferences", Bell],
  ["Help & support", "/help", LifeBuoy],
] as const;
export default function AccountHub({adminEntry = false}: {adminEntry?: boolean}) {
  const [data, setData] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function load() {
    try {
      const response = await fetch("/api/commerce", {
        signal: AbortSignal.timeout(15000),
      });
      const body: any = await response.json();
      if (!response.ok)
        throw Error(body.error || "Unable to load your account");
      setData(body);
      setError("");
    } catch {
      setError("Unable to load your account. Please try again.");
    }
  }
  useEffect(() => {
    load();
  }, []);
  async function signOut() {
    setBusy(true);
    try {
      await signOutEmailSession();
      window.location.assign("/signout-with-chatgpt?return_to=/");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to sign out");
      setBusy(false);
    }
  }
  return (
    <>
      <main
        id="main-content"
        tabIndex={-1}
        className="customer-page account-hub"
      >
        <div className="profile-page-heading">
          <p className="profile-page-kicker">YOUR PROFILE</p>
          <h1>Profile</h1>
        </div>
        {error && (
          <div className="design-alert" role="alert">
            {error}
            <button onClick={load} disabled={busy}>
              Retry
            </button>
          </div>
        )}
        {!data && !error ? (
          <p role="status" aria-busy="true">
            Loading your account…
          </p>
        ) : !data ? null : !data.user ? (
          <div className="design-card">
            <p>Your session has ended.</p>
            <a className="primary" href="/sign-in?returnTo=%2Faccount">
              Sign in
            </a>
          </div>
        ) : (
          <>
            <section className="account-welcome">
              <div>
                <p className="eyebrow">YOUR ACCOUNT</p>
                <h2>Good to see you, {(data.user.name || "there").split(" ")[0]}.</h2>
                <p>Your shopping, saved finds and account details in one place.</p>
              </div>
            </section>
            <section className="account-identity design-card">
              <span className="account-initial" aria-hidden="true">
                {(data.user.name || data.user.email || "C").slice(0, 1).toUpperCase()}
              </span>
              <div>
                <h2 className="seller-identity"><span className="seller-name-text">{data.user.name}</span></h2>
                <p className="profile-handle">{data.user.username ? "@" + data.user.username : "Choose a username in profile settings"}</p>
                <p>{data.user.email}</p>
              </div>
              <a className="secondary-button" href="/workspace?tab=Account">Edit Profile</a>
            </section>
            <section className="account-stat-grid" aria-label="Your activity">
              <Link href="/?browse=1#orders"><span>Orders</span><strong>{Array.isArray(data.orders) ? data.orders.length : 0}</strong><small>Track your purchases</small></Link>
              <a href="/for-you?feed=following"><span>Following</span><strong>{Array.isArray(data.follows) ? data.follows.length : 0}</strong><small>Your favourite sellers</small></a>
              <div><span>Bag items</span><strong>{Array.isArray(data.cart) ? data.cart.reduce((sum: number, item: any) => sum + Number(item.quantity || 0), 0) : 0}</strong><small>Ready when you are</small></div>
            </section>
            <h2 className="account-section-title">Shopping & account</h2>
            <nav className="account-menu" aria-label="Your account">
              {sections.map(([label, href, Icon]) => (
                <a key={label} href={href}>
                  <Icon size={22} />
                  <span>{label}</span>
                  <ChevronRight size={20} />
                </a>
              ))}
            </nav>
            <h2 className="account-section-title">Business tools</h2>
            <div className="account-business-links">
              <a className="design-card" href={data.myStore ? "/seller" : "/start-selling"}>
                <Store />
                <span>{data.myStore ? "Seller Centre" : "Start selling"}</span>
                <ChevronRight />
              </a>
              {(adminEntry || data.user.admin) && (
                <a className="design-card" href="/admin">
                  <ShieldCheck />
                  <span>Admin Console</span>
                  <ChevronRight />
                </a>
              )}
            </div>
            <button
              className="account-signout"
              onClick={signOut}
              disabled={busy}
            >
              <LogOut size={21} />
              {busy ? "Signing out…" : "Sign out"}
            </button>
          </>
        )}
      </main>
      <CustomerNavigation active="Profile" />
    </>
  );
}
