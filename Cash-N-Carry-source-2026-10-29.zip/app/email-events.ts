import { getEmailConfig } from "./email-config";
import { emailEventId } from "./notifications";
import { env } from "cloudflare:workers";
import { queueTemplate, queueUserTemplate, flushEmails } from "./notifications";
import { naira, type EmailData, type TemplateId } from "./email-templates";
const q = (sql: string, ...args: any[]) => env.DB!.prepare(sql).bind(...args);
export async function safelyEmail(action: () => Promise<unknown>) {
  try {
    await action();
  } catch {
    console.error("email_event_enqueue_failed");
  }
}
// Flush only after durable enqueue, never make a commerce action depend on provider delivery.
export async function deliverQueuedEmails() {
  if (!(await getEmailConfig())) return;
  await flushEmails().catch(() => console.error("email_queue_flush_failed"));
}
export async function orderEmail(
  orderId: string,
  event:
    | "created"
    | "confirmed"
    | "paid"
    | "shipped"
    | "delivered"
    | "cancelled"
    | "payment-issue",
) {
  const o: any = await q(
    "SELECT o.*,s.name AS store_name,s.owner AS seller FROM orders o JOIN stores s ON s.id=o.store WHERE o.id=?",
    orderId,
  ).first();
  if (!o) return;
  if (event === "created" && o.status !== "placed") return;
  const p: any = await q(
    "SELECT status,mode,provider_id FROM payments WHERE order_id=?",
    orderId,
  ).first();
  if (
    event === "paid" &&
    (o.status === "cancelled" ||
      o.payment_status !== "paid" ||
      p?.status !== "paid" ||
      !p.provider_id)
  )
    return;
  if (
    ["confirmed", "shipped", "delivered", "cancelled"].includes(event) &&
    o.status !== event
  )
    return;
  const refund: any =
    event === "cancelled"
      ? await q("SELECT status FROM refunds WHERE order_id=?", orderId).first()
      : null;
  const payment =
    o.payment === "cash_on_delivery"
      ? "Cash on delivery — pay on fulfilment"
      : o.payment_status === "paid"
        ? "Verified paid"
        : o.payment_status === "refunded"
          ? "Provider-confirmed refunded"
          : o.payment_status === "pending"
            ? "Pending — not yet verified"
            : o.payment_status;
  const data: EmailData = {
    name: o.name,
    actionUrl: "/order/" + encodeURIComponent(orderId),
    items: (
      await q(
        "SELECT oi.name,oi.variant,oi.quantity,oi.price,p.image FROM order_items oi LEFT JOIN products p ON p.id=oi.product WHERE oi.order_id=?",
        orderId,
      ).all<any>()
    ).results,
    details: [
      ["Order", orderId],
      ["Seller", o.store_name],
      ["Delivery fee", naira(o.delivery_fee)],
      ["Total", naira(o.total)],
      ["Payment", payment],
      ["Order status", o.status],
      ...(p?.mode === "test"
        ? [
            ["Environment", "TEST / sandbox — no production receipt"] as [
              string,
              string,
            ],
          ]
        : []),
    ],
  };
  data.sandbox = p?.mode === "test";
  if (o.tracking) data.details!.push(["Fulfilment update", o.tracking]);
  const template: TemplateId =
    event === "created"
      ? "order-confirmation"
      : event === "confirmed"
        ? "order-update"
        : event === "paid"
          ? "payment-receipt"
          : event === "shipped"
            ? "dispatched"
            : event === "delivered"
              ? "delivered"
              : event === "cancelled"
                ? "order-cancelled"
                : "payment-issue";
  if (event === "payment-issue")
    data.message =
      o.payment_status === "pending"
        ? "Payment is still pending or uncertain. Do not pay again until the existing transaction has been checked. Open the order to see the current status or contact support."
        : "The provider confirmed the payment did not complete and the order is closed. Check your order and contact support if your bank shows a debit. Do not make a duplicate payment.";
  if (event === "cancelled")
    data.details!.push([
      "Refund",
      refund
        ? refundLabel(refund.status)
        : o.payment_status === "paid"
          ? "Refund required — contact support; not yet completed"
          : o.payment_status === "refunded"
            ? "Provider-confirmed completed"
            : o.payment_status === "pending"
              ? "Payment requires reconciliation; refund status not confirmed"
              : "No verified online payment received; contact support if you see a debit",
    ]);
  const notificationId =
    "order-" + (await emailEventId(`order:${orderId}:${event}`));
  await q(
    "INSERT INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING",
    notificationId,
    o.buyer,
    event === "created" ? "Order received" : "Order update",
    `Order ${orderId}: ${o.status}. Payment: ${payment}.`,
    new Date().toISOString(),
  ).run();
  await queueUserTemplate(
    o.buyer,
    `order:${orderId}:${event}${event === "payment-issue" ? ":" + o.payment_status : ""}`,
    template,
    data,
  );
  if (
    (event === "created" && o.payment === "cash_on_delivery") ||
    event === "paid"
  )
    await queueUserTemplate(
      o.seller,
      `order:${orderId}:seller-eligible`,
      "seller-order",
      { ...data, name: undefined, actionUrl: "/workspace?tab=Orders" },
    );
  if (event === "delivered")
    await queueUserTemplate(
      o.buyer,
      `order:${orderId}:review`,
      "review-request",
      { ...data, actionUrl: "/order/" + encodeURIComponent(orderId) },
      "order_updates",
    );
  await deliverQueuedEmails();
}
function refundLabel(status: string) {
  const labels: Record<string, string> = {
    requested: "Requested — awaiting review; no refund sent",
    approved_for_processing:
      "Approved for processing — money has not yet been refunded",
    rejected: "Request rejected — no refund sent",
    initiating: "Initiating — provider confirmation pending",
    processing: "Processing — provider completion pending",
    completed: "Completed — independently confirmed with provider",
    reconciliation_required:
      "Uncertain — provider reconciliation required; do not request a duplicate refund",
    failed: "Failed — contact support",
  };
  return labels[status] || status;
}
export async function refundEmail(id: string, reason?: string) {
  const r: any = await q(
    "SELECT r.*,o.buyer FROM refunds r JOIN orders o ON o.id=r.order_id WHERE r.id=?",
    id,
  ).first();
  if (!r) return;
  await queueUserTemplate(
    r.buyer,
    `refund:${id}:${r.status}`,
    "refund-update",
    {
      actionUrl: "/order/" + encodeURIComponent(r.order_id),
      details: [
        ["Order", r.order_id],
        ["Amount", naira(r.amount)],
        ["Refund status", refundLabel(r.status)],
        ...(reason ? [["Reviewer response", reason] as [string, string]] : []),
      ],
    },
  );
  await deliverQueuedEmails();
}
export async function verificationEmail(id: string) {
  const r: any = await q(
    "SELECT v.id,v.owner,v.status,v.note,s.name FROM verification_requests v JOIN stores s ON s.id=v.store WHERE v.id=?",
    id,
  ).first();
  if (!r) return;
  const title=r.status==='pending'?'Seller verification submitted':r.status==='approved'?'Seller verification approved':r.status==='more_information'?'More verification information required':'Seller verification decision available';
  await q("INSERT INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING",`seller-verification:${id}:${r.status}`,r.owner,title,`Store ${r.name}: verification status is ${r.status.replaceAll('_',' ')}.${r.note?` Reviewer note: ${r.note}`:''} Open Seller Centre for details.`,new Date().toISOString()).run();
  await queueUserTemplate(
    r.owner,
    `verification:${id}:${r.status}`,
    "seller-verification",
    {
      actionUrl: "/workspace?tab=Verification",
      details: [
        ["Reference", id],
        ["Store", r.name],
        ["Status", r.status],
        ...(r.note ? [["Reviewer response", r.note] as [string, string]] : []),
      ],
    },
  );
  if (r.status === "pending")
    await adminEmail(
      `verification:${id}`,
      "A seller verification application needs review.",
    );
  await deliverQueuedEmails();
}
export async function caseEmail(id: string) {
  const r: any = await q("SELECT * FROM reports WHERE id=?", id).first();
  if (!r) return;
  const isReturn = r.target_type === "return",
    template: TemplateId = isReturn
      ? r.status === "open"
        ? "return-request"
        : "return-decision"
      : r.status === "open"
        ? "support-acknowledgement"
        : r.status === "resolved"
          ? "support-resolution"
          : "support-response";
  const data: EmailData = {
    actionUrl: "/workspace?tab=Support",
    details: [
      ["Case reference", id],
      ["Case status", r.status],
      ...(r.resolution ? [["Response", r.resolution] as [string, string]] : []),
    ],
  };
  await queueUserTemplate(
    r.reporter,
    `case:${id}:${r.status}:${r.updated}`,
    template,
    data,
  );
  if (isReturn && r.status === "open") {
    const store: any = await q(
      "SELECT s.owner FROM orders o JOIN stores s ON s.id=o.store WHERE o.id=?",
      r.target,
    ).first();
    if (store)
      await queueUserTemplate(
        store.owner,
        `case:${id}:seller`,
        "seller-return",
        {
          ...data,
          actionUrl: "/workspace?tab=Orders",
          details: [...data.details!, ["Order", r.target]],
        },
      );
  }
  if (r.status === "open")
    await adminEmail(`case:${id}`, "A reported case needs review.");
  await deliverQueuedEmails();
}
export async function restrictionEmail(
  user: string,
  event: string,
  reason: string,
) {
  await queueUserTemplate(user, event, "restriction", {
    message:
      "An administrator recorded a restriction. If you believe this is incorrect, use Help & contact or your private Support area to request a review.",
    details: [["Reason", reason]],
    actionUrl: "/help",
  });
  await deliverQueuedEmails();
}
export async function adminEmail(event: string, message: string) {
  if (env.REVIBE_ADMIN_EMAIL)
    await queueTemplate(
      env.REVIBE_ADMIN_EMAIL,
      `admin:${event}`,
      "admin-alert",
      { message, actionUrl: "/admin" },
    );
}
