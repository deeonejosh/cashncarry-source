"use client";
import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
export default function LiveVideo({ url, controls = true }: { url: string; controls?: boolean }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [muted, setMuted] = useState(false);
  useEffect(() => {
    let h: any;
    let alive = true;
    const v = ref.current;
    setError(false);
    if (!v) return;
    if (
      url.split("?")[0].endsWith(".m3u8") &&
      !v.canPlayType("application/vnd.apple.mpegurl")
    ) {
      import("hls.js")
        .then(({ default: Hls }) => {
          if (!alive) return;
          if (Hls.isSupported()) {
            h = new Hls();
            h.loadSource(url);
            h.attachMedia(v);
            h.on(Hls.Events.ERROR, (_: any, d: any) => {
              if (d.fatal) setError(true);
            });
          } else setError(true);
        })
        .catch(() => {
          if (alive) setError(true);
        });
    } else {
      v.src = url;
      v.load();
    }
    return () => {
      alive = false;
      h?.destroy();
      v.pause();
      v.removeAttribute("src");
      v.load();
    };
  }, [url, attempt]);
  return (
    <>
      <video
        ref={ref}
        controls={controls}
        autoPlay
        playsInline
        onError={() => setError(true)}
      />
      {!controls && (
        <button
          type="button"
          className="live-audio-toggle"
          aria-label={muted ? "Turn live sound on" : "Mute live sound"}
          aria-pressed={muted}
          onClick={() => {
            const video = ref.current;
            if (!video) return;
            video.muted = !video.muted;
            setMuted(video.muted);
          }}
        >
          {muted ? <VolumeX aria-hidden="true" /> : <Volume2 aria-hidden="true" />}
        </button>
      )}
      {error && (
        <div className="stream-error">
          This video could not be loaded. Retry playback or contact the seller
          if the problem continues.
          <br />
          <button
            className="secondary-button"
            onClick={() => setAttempt((n) => n + 1)}
          >
            Retry video
          </button>
        </div>
      )}
    </>
  );
}
