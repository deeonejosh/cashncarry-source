import { env } from "cloudflare:workers";
import { ensureLiveStreamEventsSchema } from "./live-stream-events-schema";

const q = (sql: string, ...args: any[]) => env.DB!.prepare(sql).bind(...args);

async function publishAuctionResult(auctionId: string, created: string) {
  try {
    await ensureLiveStreamEventsSchema();
    const result: any = await q(`SELECT a.stream,a.winning_bid,a.reserve_price,p.name AS product_name,
      b.amount,COALESCE('@'||NULLIF(buyer.username,''),NULLIF(buyer.name,''),'A buyer') AS winner_name,
      (SELECT COUNT(*) FROM auction_bids WHERE auction=a.id) AS bid_count
      FROM live_auctions a JOIN products p ON p.id=a.product
      LEFT JOIN auction_bids b ON b.id=a.winning_bid LEFT JOIN profiles buyer ON buyer.id=b.bidder
      WHERE a.id=? AND a.status='ended'`, auctionId).first();
    if (!result) return;
    const productName = String(result.product_name || "the featured product").slice(0, 100);
    const message = result.winning_bid
      ? `${result.winner_name} won ${productName} for ₦${Number(result.amount).toLocaleString("en-NG")}. Add delivery details and pay from My Orders.`
      : Number(result.bid_count) > 0
        ? `The auction for ${productName} ended without a sale because its reserve or stock requirement was not met.`
        : `The auction for ${productName} ended with no bids.`;
    await q("INSERT OR IGNORE INTO live_stream_events(id,stream,type,name,message,created) VALUES(?,?,'bid','Cash N Carry',?,?)", `auction-result:${auctionId}`, result.stream, message, created).run();
  } catch {
    console.error("live_stream_auction_result_failed");
  }
}

/** Idempotently settles a time-expired auction into an explicitly unpaid order. */
export async function settleAuction(auctionId: string, at = new Date().toISOString()) {
  if (!env.DB) throw Error("Storage unavailable");
  const auction: any = await q("SELECT * FROM live_auctions WHERE id=?", auctionId).first();
  if (!auction) return { settled: false, reason: "not_found" };
  if (auction.status === "ended") {
    await publishAuctionResult(auctionId, auction.updated || at);
    return { settled: false, reason: "already_ended", orderId: auction.order_id || null };
  }
  if (!["active", "scheduled"].includes(auction.status) || auction.ends_at > at)
    return { settled: false, reason: "not_due" };

  const bid: any = await q("SELECT b.*,p.name FROM auction_bids b JOIN profiles p ON p.id=b.bidder WHERE b.auction=? ORDER BY b.amount DESC,b.created ASC LIMIT 1", auctionId).first();
  const product: any = await q("SELECT name,stock FROM products WHERE id=?", auction.product).first();
  const winner = Boolean(bid && product?.stock > 0 && (!auction.reserve_price || bid.amount >= auction.reserve_price));
  const orderId = winner ? `auc-${auctionId}` : "";
  const seller: any = await q("SELECT owner,shipping_fee FROM stores WHERE id=?", auction.store).first();
  const statements: any[] = [
    q("UPDATE live_auctions SET status='ended',winning_bid=?,order_id=?,updated=? WHERE id=? AND status IN ('active','scheduled') AND ends_at<=?", winner ? bid.id : "", orderId, at, auctionId, at),
    q(`UPDATE streams SET pinned_auction=COALESCE(
      (SELECT id FROM live_auctions WHERE stream=? AND status='active' AND ends_at>? ORDER BY starts_at ASC LIMIT 1),
      (SELECT id FROM live_auctions WHERE stream=? AND status='scheduled' AND ends_at>? ORDER BY starts_at ASC LIMIT 1),'')
      WHERE id=? AND pinned_auction=?`, auction.stream, at, auction.stream, at, auction.stream, auctionId),
  ];
  if (winner) {
    const legacyAddressReady = Boolean(bid.recipient && bid.phone && bid.delivery_address && bid.delivery_state);
    const configuredFee = seller?.shipping_fee != null && Number.isSafeInteger(Number(seller.shipping_fee)) && Number(seller.shipping_fee) >= 0 ? Number(seller.shipping_fee) : 0;
    const deliveryFee = legacyAddressReady ? Number(bid.delivery_fee || configuredFee) : configuredFee;
    const total = Number(bid.amount) + deliveryFee;
    const address = legacyAddressReady ? [bid.delivery_address, bid.delivery_area].filter(Boolean).join(", ") : "";
    statements.push(q("INSERT OR IGNORE INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,delivery_fee,delivery_state,created,seller_activation_required) VALUES(?,?,?,?,?,?,?,'placed','auction','pending',?,?,?,1)", orderId, bid.bidder, auction.store, legacyAddressReady ? (bid.recipient || bid.name) : bid.name, legacyAddressReady ? (bid.phone || "") : "", address, total, deliveryFee, legacyAddressReady ? (bid.delivery_state || "") : "", at));
    statements.push(q("INSERT INTO order_items(id,order_id,product,name,price,quantity,variant) SELECT ?,?,?,?,?,1,'' WHERE EXISTS(SELECT 1 FROM live_auctions WHERE id=? AND order_id=? AND winning_bid=?) AND NOT EXISTS(SELECT 1 FROM order_items WHERE order_id=? AND product=?)", crypto.randomUUID(), orderId, auction.product, product.name, bid.amount, auctionId, orderId, bid.id, orderId, auction.product));
    statements.push(q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)", `auction-win:${auctionId}`, bid.bidder, "You won a live auction", `Winning bid: ₦${Number(bid.amount).toLocaleString("en-NG")}; listed delivery fee: ₦${deliveryFee.toLocaleString("en-NG")}. Add your delivery address and complete secure payment from My Orders.`, at));
    if (seller?.owner) statements.push(q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)", `auction-ended:${auctionId}`, seller.owner, "Live auction ended", `Winning bid: ₦${Number(bid.amount).toLocaleString("en-NG")}. The buyer has been asked to add delivery details and complete payment.`, at));
  } else if (seller?.owner) {
    statements.push(q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)", `auction-ended:${auctionId}`, seller.owner, "Live auction ended", "No eligible winning bid met the reserve or available stock requirement.", at));
  }
  await env.DB.batch(statements);
  const saved: any = await q("SELECT status,order_id FROM live_auctions WHERE id=?", auctionId).first();
  if (saved?.status === "ended") await publishAuctionResult(auctionId, at);
  return { settled: saved?.status === "ended", orderId: saved?.order_id || null };
}

export async function settleExpiredAuctions(limit = 100) {
  if (!env.DB) throw Error("Storage unavailable");
  const stamp = new Date().toISOString();
  const due: any = await q("SELECT id FROM live_auctions WHERE status IN ('active','scheduled') AND ends_at<=? ORDER BY ends_at LIMIT ?", stamp, Math.max(1, Math.min(500, limit))).all();
  let settled = 0;
  for (const row of due.results as any[]) {
    const result = await settleAuction(row.id, stamp);
    if (result.settled) settled++;
  }
  return { due: due.results.length, settled };
}
