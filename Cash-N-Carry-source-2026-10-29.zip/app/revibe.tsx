"use client";
import { trustBadgeImage } from "./trust-badge-image";
import { lazy, Suspense, useState, useEffect, useCallback, useRef } from "react";
import {
  CART_RESUME_KEY,
  readCartIntent,
  preserveCartForSignIn,
} from "./cart-resume";
import { shoppingReturnPath } from "./auth-navigation";
import { listingReview } from "./listing-review";
import { clientId } from "./client-id";
import ImageAsset from "./image-asset";
import StoreLogo from "./store-logo";
import { storefrontImageSrcSet, storefrontImageUrl } from "./storefront-image-url";
import ReturnGuidance from "./return-guidance";
import { trackAnalyticsEvent } from "./analytics";
import {
  ShoppingGuide,
  HomeFooter,
  ShoppingHero,
  ShopCategories,
  MarketplaceFooter,
} from "./shopping-design";
import BrandLogo from "./brand-logo";
import { brand } from "./brand";
import { deliveryQuote, deliveryFee } from "./delivery-quote";
import { broadcastLabel, broadcastSummary } from "./broadcasts";
import ScheduleInfo from "./schedule-info";
import StreamReminderButton from "./stream-reminder-button";
import { LazyProductVideo, VideoFeed } from "./video-feed";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Home,
  Bell,
  Plus,
  Radio,
  ShoppingBag,
  Search,
  ShoppingCart,
  MessageCircle,
  Package,
  Store,
  ChartColumn,
  ChevronRight,
  X,
  MapPin,
  Heart,
  Check,
  LoaderCircle,
  Truck,
  ArrowUpRight,
  ArrowRight,
  SlidersHorizontal,
  Shirt,
  Sparkles,
  Utensils,
  Headphones,
  Armchair,
  Briefcase,
  Play,
  Users,
  AlertCircle,
  MessageSquare,
  FileCheck2,
  Menu,
} from "lucide-react";

// Keep seller tools and modal-only workflows out of the initial discovery bundle.
// These chunks load when a seller opens their workspace or a buyer opens a dialog.
const SellerNavigation = lazy(() => import("./seller/navigation"));
const SellerActivationCard = lazy(() =>
  import("./seller/activation-card").then((module) => ({ default: module.SellerActivationCard })),
);
const NotificationPanel = lazy(() => import("./notification-panel"));
const ProductOptions = lazy(() => import("./product-options"));
const ProductPhoto = lazy(() => import("./product-photo"));
const LiveShopping = lazy(() => import("./live-shopping"));
const VideoCreation = lazy(() => import("./video-creation"));
const money = (n: number) =>
  new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(n || 0);
const defaultCategories = [
  "All",
  "Fashion",
  "Beauty",
  "Food",
  "Tech",
  "Home",
  "Services",
];
const icons = [
  ShoppingBag,
  Shirt,
  Sparkles,
  Utensils,
  Headphones,
  Armchair,
  Briefcase,
];
const ensureDeferredStylesheet = (key: string, href: string) => new Promise<void>((resolve) => {
  const attribute = key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
  let link = document.querySelector<HTMLLinkElement>(`link[data-${attribute}]`);
  if (link?.dataset.loaded === "true" || link?.dataset.failed === "true") {
    resolve();
    return;
  }
  if (!link) {
    link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    link.dataset[key] = "true";
    document.head.appendChild(link);
  }
  link.addEventListener("load", () => {
    link!.dataset.loaded = "true";
    resolve();
  }, { once: true });
  link.addEventListener("error", () => {
    link!.dataset.failed = "true";
    resolve();
  }, { once: true });
});
const initialNow=Date.now();
const initial: any = {
  products: [],
  stores: [],
  streams: [],
  cart: [],
  orders: [],
  sellerOrders: [],
  reviews: [],
  follows: [],
  campaigns: [],
};
const Field = ({
  label,
  name,
  type = "text",
  value = "",
  required = true,
  ...p
}: any) => (
  <label className="field">
    {label}
    <input
      name={name}
      type={type}
      defaultValue={value}
      required={required}
      {...p}
    />
  </label>
);
const Empty = ({
  title,
  text,
  action,
  label,
  icon: Icon = ShoppingBag,
  headingLevel = 3,
}: any) => {
  const Heading = headingLevel === 2 ? "h2" : "h3";
  return (
    <div className="empty">
      <span className="empty-icon">
        <Icon size={30} />
      </span>
      <Heading>{title}</Heading>
      <p>{text}</p>
      {action && (
        <button className="primary" onClick={action}>
          {label}
        </button>
      )}
    </div>
  );
};

const Button = ({ children, busy, disabled, ...p }: any) => (
  <button disabled={busy || disabled} {...p}>
    {children}
  </button>
);
export default function ReVibe({initialData,initialCatalogue,initialView}: {initialData?:any;initialCatalogue?:any;initialView?:string} = {}) {
  const router = useRouter();
  const [data, setData] = useState<any>(initialData || initial),
    [view, setView] = useState(initialView || "Home"),
    [category, setCategory] = useState("All"),
    [sellerDirectorySearch, setSellerDirectorySearch] = useState(""),
    [sellerDirectoryCategory, setSellerDirectoryCategory] = useState("All"),
    [ordersQuery, setOrdersQuery] = useState(""),
    [ordersFilter, setOrdersFilter] = useState("All"),
    [tab, setTab] = useState("For You"),
    [query, setQuery] = useState(""),
    [location, setLocation] = useState(""),
    [locationMode, setLocationMode] = useState("delivers"),
    [deviceLocation, setDeviceLocation] = useState<{
      lat: number;
      lng: number;
    } | null>(null),
    [radius, setRadius] = useState(25),
    [sort, setSort] = useState("newest"),
    [minPrice, setMinPrice] = useState(""),
    [maxPrice, setMaxPrice] = useState(""),
    [inStockOnly, setInStockOnly] = useState(false),
    [shopMenuOpen, setShopMenuOpen] = useState(false),
    [page, setPage] = useState(1),
    [variant, setVariant] = useState(""),
    [uploadProgress, setUploadProgress] = useState<number | null>(null),
    [modal, setModal] = useState<any>(null),
    [creationOpen, setCreationOpen] = useState(false),
    [busy, setBusy] = useState(false),
    [loading, setLoading] = useState(!initialData),
    [error, setError] = useState(""),
    [toast, setToast] = useState(""),
    [toastKind, setToastKind] = useState("success"),
    [checkoutError, setCheckoutError] = useState(""),
    [sellerTab, setSellerTab] = useState("Overview"),
    [dashboardStylesReady, setDashboardStylesReady] = useState(false);
  const categories: string[] = data.categories?.length
    ? ["All", ...data.categories.map((c: any) => c.name)]
    : defaultCategories;
  const openVideoCreation = async () => {
    try {
      const response = await fetch("/api/commerce", { cache: "no-store" });
      const account = await response.json() as { user?: unknown };
      if (!response.ok) throw new Error("Account services are temporarily unavailable. Please retry.");
      if (!account.user) {
        router.push("/sign-in?returnTo=" + encodeURIComponent(window.location.pathname + window.location.search));
        return;
      }
      setData(account);
      setCreationOpen(true);
    } catch {
      setToastKind("error");
      setToast("Unable to confirm your account. Please retry.");
    }
  };
  const [catalogue, setCatalogue] = useState<any>(initialCatalogue || {
    products: [],
    total: 0,
    page: 1,
    pages: 1,
  });
  const [catalogueLoading, setCatalogueLoading] = useState(!initialCatalogue);
  const [catalogueError, setCatalogueError] = useState("");
  const [catalogueVersion, setCatalogueVersion] = useState(0);
  const [sharedProductLoading, setSharedProductLoading] = useState(false);
  const [sharedProductError, setSharedProductError] = useState("");
  const [sharedProductRetry, setSharedProductRetry] = useState(0);
  const [filterDraft, setFilterDraft] = useState({
    location: "",
    mode: "delivers",
    category: "All",
    sort: "newest",
    minPrice: "",
    maxPrice: "",
    inStockOnly: false,
    radius: 25,
    deviceLocation: null as { lat: number; lng: number } | null,
  });
  const openFilters = () => {
    setFilterDraft({
      location,
      mode: locationMode,
      category,
      sort,
      minPrice,
      maxPrice,
      inStockOnly,
      radius,
      deviceLocation,
    });
    setModal({ type: "filters" });
  };
  useEffect(() => {
    setVariant("");
  }, [modal?.p?.id, modal?.stream?.product]);
  const operation = useRef(false);
  const trackedAds = useRef(new Set<string>());
  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/commerce", {
        signal: AbortSignal.timeout(15000),
      });
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      setData(d);
      setCatalogueVersion((v) => v + 1);
      setModal((m: any) =>
        m?.type === "product" && d.products.find((p: any) => p.id === m.p.id)
          ? { ...m, p: d.products.find((p: any) => p.id === m.p.id) }
          : m,
      );
      setError("");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    // The server already supplies this request’s current account and marketplace.
    if (!initialData) load();
  }, [load, initialData]);
  useEffect(() => {
    if (view !== "Seller" || dashboardStylesReady) return;
    let active = true;
    void ensureDeferredStylesheet("dashboardRedesign", "/dashboard-redesign.css").then(() => {
      if (active) setDashboardStylesReady(true);
    });
    return () => { active = false; };
  }, [view, dashboardStylesReady]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 4500);
    return () => clearTimeout(t);
  }, [toast]);
  useEffect(() => {
    if (!modal) return;
    const previous = document.activeElement as HTMLElement;
    const dialog = document.querySelector("[role=dialog]") as HTMLElement;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusable = () =>
      (
        Array.from(
          (dialog?.querySelector(".live-sheet") || dialog)?.querySelectorAll(
            "button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),summary",
          ) || [],
        ) as HTMLElement[]
      ).filter(
        (element) =>
          element.getClientRects().length > 0 &&
          getComputedStyle(element).visibility !== "hidden",
      );
    focusable()[0]?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") setModal(null);
      if (e.key === "Tab") {
        const els = focusable();
        const first = els[0],
          last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.body.style.overflow = oldOverflow;
      document.removeEventListener("keydown", key);
      previous?.focus();
    };
  }, [modal?.type]);
  const signed = (intent?: string) => {
    if (data.user) return true;
    window.location.assign(
      "/sign-in?returnTo=" +
        encodeURIComponent(
          shoppingReturnPath(
            window.location.pathname +
              window.location.search +
              window.location.hash,
            intent,
          ),
        ),
    );
    return false;
  };
  const act = async (b: any, success = "Saved") => {
    if (b.action === "checkout") setCheckoutError("");
    if (operation.current) return false;
    if (!data.user && b.action === "cart" && b.quantity > 0) {
      try {
        preserveCartForSignIn(
          b.product,
          b.variant || "",
          b.quantity,
          window.location.pathname +
            window.location.search +
            window.location.hash,
        );
      } catch (error: any) {
        setToast(error.message);
      }
      return false;
    }
    if (!signed()) return false;
    operation.current = true;
    setBusy(true);
    try {
      const r = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(b),
        signal: AbortSignal.timeout(b.action === "checkout" ? 45000 : 25000),
      });
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      if (d.paymentLink) {
        window.location.assign(d.paymentLink);
        return true;
      }
      await load();
      if (success) {
        setToastKind("success");
        setToast(success);
      }
      return true;
    } catch (e: any) {
      if (b.action === "checkout") setCheckoutError(e.message);
      setToastKind("error");
      setToast(e.message);
      return false;
    } finally {
      operation.current = false;
      setBusy(false);
    }
  };
  const resumingCart = useRef(false);
  const [resumeError, setResumeError] = useState("");
  const [resumeRetry, setResumeRetry] = useState(0);
  const [resumeReturnTo, setResumeReturnTo] = useState("");
  useEffect(() => {
    const key = new URLSearchParams(window.location.search).get("resumeCart");
    if (!key || loading || !data.user || resumingCart.current) return;
    let intent;
    try {
      intent = readCartIntent(sessionStorage);
    } catch {
      return;
    }
    if (!intent || intent.id !== key) return;
    resumingCart.current = true;
    setResumeError("");
    if (intent.intent === "buy-now") {
      fetch("/api/commerce?product=" + encodeURIComponent(intent.product), {
        signal: AbortSignal.timeout(15000),
      })
        .then(async (r) => {
          const result: any = await r.json();
          if (!r.ok) throw Error(result.error || "This product is unavailable.");
          setResumeReturnTo(intent.returnTo);
          setModal({
            type: "checkout",
            key: clientId(),
            directPurchase: { product: result.product, variant: intent.variant, quantity: intent.quantity },
          });
          sessionStorage.removeItem(CART_RESUME_KEY);
          const url = new URL(window.location.href);
          url.searchParams.delete("resumeCart");
          window.history.replaceState(window.history.state, "", url.pathname + url.search + url.hash);
        })
        .catch((e) => {
          setResumeError(e instanceof Error ? e.message : "Your saved purchase could not be opened.");
          resumingCart.current = false;
        });
      return;
    }
    act(
      {
        action: "cart_resume",
        request_id: intent.id,
        product: intent.product,
        variant: intent.variant,
        quantity: intent.quantity,
      },
      "Your selection was added to the cart after sign-in.",
    ).then((ok) => {
      if (ok) {
        setResumeReturnTo(intent.returnTo);
        sessionStorage.removeItem(CART_RESUME_KEY);
        const url = new URL(window.location.href);
        url.searchParams.delete("resumeCart");
        window.history.replaceState(
          window.history.state,
          "",
          url.pathname + url.search + url.hash,
        );
        setModal({ type: "cart" });
      } else {
        setResumeError(
          "Your saved selection could not be added. Review its option and stock or retry.",
        );
        resumingCart.current = false;
      }
    });
  }, [loading, data.user?.email, resumeRetry]);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get("buyNow");
    if (!productId || loading || error || !data.user) return;
    const controller = new AbortController();
    setSharedProductLoading(true);
    setSharedProductError("");
    fetch("/api/commerce?product=" + encodeURIComponent(productId), {
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]),
    })
      .then(async (r) => {
        const result: any = await r.json();
        if (!r.ok) throw Error(result.error || "This product is unavailable.");
        const quantity = Number(params.get("quantity") || 1);
        if (!Number.isInteger(quantity) || quantity < 1 || quantity > 99)
          throw Error("Choose a valid quantity before checkout.");
        if (!controller.signal.aborted)
          setModal({
            type: "checkout",
            key: clientId(),
            directPurchase: { product: result.product, variant: params.get("variant") || "", quantity },
          });
        params.delete("buyNow");
        params.delete("variant");
        params.delete("quantity");
        window.history.replaceState(window.history.state, "", window.location.pathname + (params.size ? "?" + params.toString() : "") + window.location.hash);
      })
      .catch((e) => {
        if (!controller.signal.aborted) setSharedProductError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setSharedProductLoading(false);
      });
    return () => controller.abort();
  }, [loading, error, data.user?.email, sharedProductRetry]);
  const add = async (p: any) => {
    if (
      JSON.parse(p.variants || "[]").length &&
      !JSON.parse(p.variants).some((v: any) => v.name === variant)
    ) {
      setModal({ type: "product", p });
      setToastKind("error");
      setToast("Choose a product option before adding it");
      return false;
    }
    const option = JSON.parse(p.variants || "[]").length ? variant : "";
    const existing = data.cart.find((c: any) => c.id === p.id);
    const ok=await act(
      {
        action: "cart",
        product: p.id,
        quantity: (existing?.variant === option ? existing.quantity : 0) + 1,
        variant: option,
      },
      "Added to your cart",
    );
    if(ok)trackAnalyticsEvent("add_to_cart",p.store,{product:p.id});
    return ok;
  };
  const buyNow = (p: any, selectedVariant = "", quantity = 1) => {
    const variants: any[] = JSON.parse(p.variants || "[]");
    const selected = variants.find((v) => v.name === selectedVariant);
    const stock = variants.length ? selected?.stock || 0 : p.stock;
    if ((variants.length && !selected) || !stock) {
      setToastKind("error");
      setToast(variants.length ? "Choose an available product option first." : "This item is sold out.");
      return;
    }
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > Math.min(stock, 99)) {
      setToastKind("error");
      setToast("Choose a valid quantity for the available stock.");
      return;
    }
    if (!data.user) {
      preserveCartForSignIn(p.id, selectedVariant, quantity, "/product/" + p.id, "buy-now");
      return;
    }
    trackAnalyticsEvent("buy_now",p.store,{product:p.id});
    trackAnalyticsEvent("checkout_start",p.store,{product:p.id});
    const store = data.stores.find((s: any) => s.id === p.store);
    const product = {
      ...p,
      delivery_fee: p.delivery_fee ?? store?.delivery_fee,
      coverage: p.coverage ?? store?.coverage,
    };
    setModal({
      type: "checkout",
      key: clientId(),
      directPurchase: { product, variant: selectedVariant, quantity },
    });
  };
  const form = async (e: any, action: string, extra: any = {}) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const b: any = Object.fromEntries(formData);
    if (action === "schedule") {
      b.featured = formData.getAll("featured");
      b.product = b.featured[0] || "";
    }
    for (const key of ["scheduled", "starts", "ends"])
      if (b[key]) b[key] = new Date(b[key]).toISOString();
    if (
      await act(
        { action, ...b, ...extra },
        action === "checkout"
          ? "Order created. Complete debit card payment in secure checkout. Check My orders for payment status."
          : "Saved successfully",
      )
    ) {
      setModal(null);
      if (action === "checkout") setView("Orders");
      if (action === "schedule")
        window.location.assign("/seller/live-history");
    }
  };
  const upload = async (e: any) => {
    const file = e.target.files?.[0];
    if (!file || operation.current) return;
    const input = e.target
      .closest("form")
      ?.querySelector(`[name="${e.target.dataset.field}"]`) as HTMLInputElement;
    operation.current = true;
    setBusy(true);
    try {
      const f = new FormData();
      f.append("file", file);
      setUploadProgress(0);
      const d: any = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "/api/media");
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable)
            setUploadProgress(Math.round((e.loaded / e.total) * 100));
        };
        xhr.onerror = () =>
          reject(Error("Upload interrupted. Check your connection and retry."));
        xhr.onload = () => {
          try {
            const data = JSON.parse(xhr.responseText);
            if (xhr.status >= 200 && xhr.status < 300) resolve(data);
            else reject(Error(data.error || "Upload failed"));
          } catch {
            reject(Error("Upload failed. Please retry."));
          }
        };
        xhr.send(f);
      });
      if (input?.isConnected) input.value = d.url;
      setToastKind("success");
      setToast("Upload ready for playback. Save the product to publish it.");
    } catch (e: any) {
      setToastKind("error");
      setToast(e.message);
    } finally {
      setUploadProgress(null);
      operation.current = false;
      setBusy(false);
    }
  };
  const shoppingContext = () => ({
    view,
    query,
    category,
    location,
    locationMode,
    sort,
    minPrice,
    maxPrice,
    inStockOnly,
    page,
    tab,
    radius,
    deviceLocation,
  });
  const viewUrl = (v: string, search = "") => {
    const params = new URLSearchParams(window.location.search);
    params.set("browse", "1");
    params.set("view", v.toLowerCase());
    if (v !== "Seller") params.delete("sellerTab");
    return window.location.pathname + "?" + params.toString() + "#" + v.toLowerCase() +
      (search ? "?q=" + encodeURIComponent(search) : "");
  };
  const nav = (v: string, options: { category?: string } = {}) => {
    window.history.replaceState({ shopping: shoppingContext() }, "");
    const nextTab = v === "Home" && tab === "LIVE" ? "For You" : tab;
    const nextCategory = options.category ?? "All";
    const next = {
      ...shoppingContext(),
      view: v,
      query: "",
      category: nextCategory,
      page: 1,
      tab: nextTab,
    };
    window.history.pushState({ shopping: next }, "", viewUrl(v));
    setView(v);
    setTab(nextTab);
    setQuery("");
    setCategory(nextCategory);
    setPage(1);
  };
  useEffect(() => {
    const restore = () => {
      const [path, search = ""] = window.location.hash.slice(1).split("?");
      const hashView =
        ["Home", "Explore", "Live", "Market", "Seller", "Orders"].find(
          (v) => v.toLowerCase() === path.toLowerCase(),
        );
      const requestedView = new URLSearchParams(window.location.search).get("view") || "";
      const v = hashView || ["Home", "Explore", "Live", "Market", "Seller", "Orders"].find(
        (item) => item.toLowerCase() === requestedView.toLowerCase(),
      ) || initialView || "Home";
      const saved = window.history.state?.shopping;
      setView(v);
      const section = new URLSearchParams(window.location.search).get("sellerTab");
      if (section && ["Overview", "Store", "Products", "Orders", "Content", "Ads"].includes(section)) setSellerTab(section);
      setQuery(saved?.query ?? new URLSearchParams(search).get("q") ?? "");
      if (saved) {
        setCategory(saved.category);
        setLocation(saved.location);
        setLocationMode(saved.locationMode);
        setSort(saved.sort);
        setMinPrice(saved.minPrice || "");
        setMaxPrice(saved.maxPrice || "");
        setInStockOnly(Boolean(saved.inStockOnly));
        setPage(saved.page);
        setTab(saved.tab);
        setRadius(saved.radius);
        setDeviceLocation(saved.deviceLocation);
      }
      setModal(null);
    };
    restore();
    window.addEventListener("popstate", restore);
    window.addEventListener("hashchange", restore);
    return () => {
      window.removeEventListener("popstate", restore);
      window.removeEventListener("hashchange", restore);
    };
  }, []);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("startSelling") !== "1" || loading || error) return;
    if (!data.user) {
      const returnTo = window.location.pathname + window.location.search + window.location.hash;
      window.location.assign("/sign-in?returnTo=" + encodeURIComponent(returnTo));
      return;
    }
    setView("Seller");
    if (!data.myStore) setModal({ type: "storeForm" });
    params.delete("startSelling");
    window.history.replaceState(window.history.state, "", window.location.pathname + (params.size ? "?" + params.toString() : "") + window.location.hash);
  }, [loading, error, data.user?.email, data.myStore?.id]);
  useEffect(() => {
    if (loading || !data.user) return;
    const url = new URL(window.location.href);
    if (url.searchParams.get("open") !== "cart") return;
    setModal({ type: "cart" });
    url.searchParams.delete("open");
    window.history.replaceState(
      window.history.state,
      "",
      url.pathname + url.search + url.hash,
    );
  }, [loading, data.user]);
  const historyReady = useRef(false);
  useEffect(() => {
    if (!historyReady.current) {
      historyReady.current = true;
      return;
    }
    window.history.replaceState(
      {
        shopping: {
          view,
          query,
          category,
          location,
          locationMode,
          sort,
          minPrice,
          maxPrice,
          inStockOnly,
          page,
          tab,
          radius,
          deviceLocation,
        },
      },
      "",
      viewUrl(view, query),
    );
  }, [
    view,
    query,
    category,
    location,
    locationMode,
    sort,
    minPrice,
    maxPrice,
    inStockOnly,
    page,
    tab,
    radius,
    deviceLocation,
  ]);
  const matchesLocation = (value: string) =>
    !location.trim() ||
    String(value || "")
      .toLowerCase()
      .includes(location.trim().toLowerCase());
  const withinDistance = (s: any) => {
    if (!deviceLocation) return true;
    if (s?.latitude == null || s?.longitude == null) return false;
    const rad = (n: number) => (n * Math.PI) / 180,
      lat = Number(s.latitude),
      lng = Number(s.longitude),
      a =
        Math.sin(rad(lat - deviceLocation.lat) / 2) ** 2 +
        Math.cos(rad(deviceLocation.lat)) *
          Math.cos(rad(lat)) *
          Math.sin(rad(lng - deviceLocation.lng) / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) <= radius;
  };
  const matchesStore = (s: any) =>
    withinDistance(s) &&
    (locationMode === "delivers"
      ? matchesLocation(JSON.parse(s?.coverage || "[]").join(" "))
      : matchesLocation(s?.location));
  const stores = data.stores.filter(
    (s: any) =>
      matchesStore(s) &&
      (category === "All" || s.category === category) &&
      `${s.name} ${s.category} ${s.location}`
        .toLowerCase()
        .includes(query.trim().toLowerCase()),
  );
  const sellerDirectoryCategories = Array.from(new Set(
    data.stores.map((store: any) => String(store.category || "").trim()).filter(Boolean),
  )).sort((a, b) => a.localeCompare(b));
  const sellerDirectoryStores = data.stores.filter((store: any) => {
    const term = sellerDirectorySearch.trim().toLocaleLowerCase();
    const text = `${store.name || ""} ${store.category || ""} ${store.location || ""} ${store.description || ""}`.toLocaleLowerCase();
    return (sellerDirectoryCategory === "All" || store.category === sellerDirectoryCategory) && (!term || text.includes(term));
  });
  const liveStreams = data.streams.filter((s: any) => {
    const store = data.stores.find((t: any) => t.id === s.store);
    return (
      (s.status !== "ended" || Boolean(s.replay)) &&
      !(
        s.status === "scheduled" &&
        s.scheduled &&
        Date.parse(s.scheduled) < initialNow - 86400000
      ) &&
      (tab !== "Following" ||
        data.follows.some((f: any) => f.store === s.store)) &&
      matchesStore(store) &&
      (category === "All" || store?.category === category) &&
      `${s.title} ${s.seller}`
        .toLowerCase()
        .includes(query.trim().toLowerCase())
    );
  });
  // The mobile Home feed is a separate discovery surface from Shop. Its Live
  // tab must not inherit search, category, location, or delivery filters that
  // are hidden while the full-screen feed is open.
  const homeFeedLiveStreams = data.streams.filter((s: any) =>
    ["live", "external"].includes(s.status),
  );
  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({
      q: query,
      category,
      location,
      mode: locationMode,
      sort,
      page: String(page),
      following: tab === "Following" && view === "Home" ? "1" : "0",
    });
    if (minPrice) params.set("minPrice", minPrice);
    if (maxPrice) params.set("maxPrice", maxPrice);
    if (inStockOnly) params.set("inStock", "1");
    if (deviceLocation) {
      params.set("lat", String(deviceLocation.lat));
      params.set("lng", String(deviceLocation.lng));
      params.set("radius", String(radius));
    }
    setCatalogueLoading(true);
    setCatalogueError("");
    fetch("/api/catalog?" + params, {
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]),
    })
      .then(async (r) => {
        const result: any = await r.json();
        if (!r.ok) throw Error(result.error);
        if (!controller.signal.aborted) {
          setCatalogue(result);
          setModal((m: any) =>
            m?.type === "product"
              ? {
                  ...m,
                  p:
                    [...result.products, ...(result.featured || [])].find(
                      (p: any) => p.id === m.p.id,
                    ) || m.p,
                }
              : m,
          );
          if (result.page !== page) setPage(result.page);
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) setCatalogueError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setCatalogueLoading(false);
      });
    return () => controller.abort();
  }, [
    query,
    category,
    location,
    locationMode,
    sort,
    minPrice,
    maxPrice,
    inStockOnly,
    page,
    tab,
    view,
    deviceLocation,
    radius,
    catalogueVersion,
  ]);
  const products = catalogue.products;
  const categoryProducts = [...(data.products || []), ...(catalogue.featured || []), ...products];
  // The homepage is a discovery surface, not a second full catalogue. Fewer
  // initial product cards mean fewer large image downloads, especially on
  // mobile connections; Shop still retains the complete paginated catalogue.
  const homeProducts = view === "Home" ? products.slice(0, 4) : products;
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pid = params.has("stream") ? null : params.get("product");
    if (!pid || loading || error) return;
    const controller = new AbortController();
    setSharedProductLoading(true);
    setSharedProductError("");
    fetch("/api/commerce?product=" + encodeURIComponent(pid), {
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]),
    })
      .then(async (r) => {
        const result: any = await r.json();
        if (!r.ok) throw Error(result.error || "Unable to open this product");
        if (!controller.signal.aborted)
          setModal({ type: "product", p: result.product });
      })
      .catch((e) => {
        if (!controller.signal.aborted) setSharedProductError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setSharedProductLoading(false);
      });
    return () => controller.abort();
  }, [loading, error, sharedProductRetry]);
  useEffect(() => {
    const stream = new URLSearchParams(window.location.search).get("stream");
    if (!stream || loading || error) return;
    const controller = new AbortController();
    setSharedProductLoading(true);
    setSharedProductError("");
    fetch("/api/commerce?stream=" + encodeURIComponent(stream), {
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]),
    })
      .then(async (response) => {
        const result: any = await response.json();
        if (!response.ok)
          throw Error(result.error || "Unable to open this broadcast");
        if (!controller.signal.aborted) {
          setModal({ type: "live", stream: result.stream });
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) setSharedProductError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setSharedProductLoading(false);
      });
    return () => controller.abort();
  }, [loading, error, sharedProductRetry]);
  useEffect(
    () => setPage(1),
    [
      query,
      category,
      location,
      locationMode,
      radius,
      deviceLocation,
      tab,
      view,
    ],
  );
  useEffect(() => {
    for (const c of (data.sponsored || []).filter(
      (c: any) => c.placement === (view === "Market" ? "market" : "discovery"),
    )) {
      if (!trackedAds.current.has(c.id)) {
        trackedAds.current.add(c.id);
        fetch("/api/ads-events", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ campaign: c.id, kind: "impression" }),
        }).catch(() => {});
      }
    }
  }, [data.sponsored, view]);
  const mine = data.myProducts || [];
  const cartTotal = data.cart.reduce(
    (s: number, c: any) => s + c.price * c.quantity,
    0,
  );
  const cartStores = [...new Set(data.cart.map((p: any) => p.store))];
  const cartShipping =
    cartStores.length === 1
      ? deliveryQuote(data.stores.find((s: any) => s.id === cartStores[0]))
      : undefined;
  const cartFee = cartStores.length === 1 ? deliveryFee(data.stores.find((s: any) => s.id === cartStores[0])) : undefined;
  const directCheckout = modal?.type === "checkout" ? modal.directPurchase : null;
  const directVariants: any[] = directCheckout
    ? JSON.parse(directCheckout.product.variants || "[]")
    : [];
  const directOption = directVariants.find((v) => v.name === directCheckout?.variant);
  const checkoutProductTotal = directCheckout
    ? (directOption?.price ?? directCheckout.product.price) * directCheckout.quantity
    : cartTotal;
  const checkoutDelivery = directCheckout
    ? deliveryQuote(directCheckout.product)
    : cartShipping;
  const checkoutDeliveryFee = directCheckout
    ? deliveryFee(directCheckout.product)
    : cartFee;
  const sales = data.sellerOrders
    .filter(
      (o: any) =>
        o.status === "delivered" &&
        (o.payment !== "flutterwave" ||
          (o.payment_mode === "live" && o.payment_status === "paid")),
    )
    .reduce((s: number, o: any) => s + o.total, 0);

  const requestDeviceLocation = () => {
    if (!navigator.geolocation) {
      setToast(
        "Device location is unavailable. Enter your state or area manually.",
      );
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setDeviceLocation({
          lat: p.coords.latitude,
          lng: p.coords.longitude,
        });
        setLocationMode("located");
        setPage(1);
        setToast(
          "Showing sellers with public business coordinates within the selected distance.",
        );
      },
      () =>
        setToast(
          "Location access was denied or unavailable. Enter your state or area manually.",
        ),
    );
  };
  const renderProduct = (p: any, large = false, prioritizeImage = false) => {
    const variants: any[] = JSON.parse(p.variants || "[]");
    const available = variants.length
      ? variants.some((option) => option.stock > 0)
      : p.stock > 0;
    const productStore = data.stores.find((store: any) => store.id === p.store);
    let coverage: string[] = [];
    try { coverage = JSON.parse(productStore?.coverage || p.coverage || "[]"); } catch { coverage = []; }
    const coverageLabel = coverage.length
      ? coverage.length === 37 ? "Nationwide delivery" : `Delivery to ${coverage.slice(0, 2).join(", ")}${coverage.length > 2 ? ` +${coverage.length - 2}` : ""}`
      : "Confirm delivery with seller";
    return (
    <article key={p.id} className={"product " + (large ? "featured" : "") + (view === "Market" ? " shop-market-product" : "")}>
      <button
        className={"product-image" + (view === "Market" ? " shop-market-product-image" : "")}
        onClick={() => {trackAnalyticsEvent("product_view",p.store,{product:p.id});if(view === "Market") window.location.assign(`/product/${encodeURIComponent(p.id)}?returnTo=${encodeURIComponent("/?browse=1#market")}`);else setModal({ type: "product", p });}}
      >
        <ImageAsset
          src={storefrontImageUrl(p.image, 320)}
          srcSet={storefrontImageSrcSet(p.image, [320, 480, 640])}
          sizes="(max-width: 767px) 47vw, (max-width: 1100px) 30vw, 23vw"
          fallbackSrc={p.image}
          alt={p.name}
          width="480"
          height="480"
          loading={prioritizeImage ? "eager" : "lazy"}
          fetchPriority={prioritizeImage ? "high" : undefined}
        />
        {p.video && (
          <span className="video-tag">
            <Play size={13} fill="currentColor" /> Product video
          </span>
        )}
        <span className="category-tag product-category-tag">{p.category}</span>
      </button>
      <button
        className="product-save"
        aria-label={
          (data.favourites?.some((f: any) => f.product === p.id)
            ? "Unsave "
            : "Save ") + p.name
        }
        aria-pressed={!!data.favourites?.some((f: any) => f.product === p.id)}
        disabled={busy}
        onClick={() =>
          signed() &&
          act(
            {
              action: "favourite",
              product: p.id,
              saved: !data.favourites?.some((f: any) => f.product === p.id),
            },
            "Saved products updated",
          )
        }
      >
        <Heart size={18} />
      </button>
      <div className={"product-info" + (view === "Market" ? " shop-market-product-info" : "")}>
        <div className={"product-seller-row" + (view === "Market" ? " shop-market-product-seller" : "")}>
          <button
            className="seller-link"
            onClick={() => setModal({ type: "store", store: productStore })}
          >
            <StoreLogo name={p.seller} src={p.seller_logo} size={24} className="product-seller-logo" />
            <span className="product-seller-name">{p.seller}</span><ChevronRight size={13} />
          </button>
          <span className="cnc-seller-trust-badges" aria-label="Store status">
            {p.official_store === 1 && <img {...trustBadgeImage("official-store")} alt="Official Store" className="cnc-trust-badge cnc-trust-badge--small" />}
            {p.top_seller === 1 && <img {...trustBadgeImage("top-seller")} alt="Top Seller" className="cnc-trust-badge cnc-trust-badge--small" />}
          </span>
        </div>
        <button
          className={"product-name" + (view === "Market" ? " shop-market-product-name" : "")}
        onClick={() => {trackAnalyticsEvent("product_click",p.store,{product:p.id});if(view === "Market") window.location.assign(`/product/${encodeURIComponent(p.id)}?returnTo=${encodeURIComponent("/?browse=1#market")}`);else setModal({ type: "product", p });}}
        >
          {p.name}
        </button>
        <div className={"product-bottom" + (view === "Market" ? " shop-market-product-price" : "")}>
          <strong>{money(p.price)}</strong>
          {Number(p.review_count) > 0 && <span className="product-card-rating" aria-label={`${Number(p.rating_average).toFixed(1)} out of 5 from ${p.review_count} product reviews`}><span aria-hidden="true">★</span> {Number(p.rating_average).toFixed(1)} <small>({Number(p.review_count)})</small></span>}
        </div>
        <small className={`delivery-note product-delivery-note${!available ? " is-unavailable" : ""}${view === "Market" ? " shop-market-product-delivery" : ""}`}>
          <Truck size={14} aria-hidden="true" />
          <span>{p.active === 0 ? "No longer listed" : !available ? "Sold out" : [p.location, coverageLabel].filter(Boolean).join(" · ")}</span>
        </small>
        <div className={"product-card-actions" + (view === "Market" ? " shop-market-product-actions" : "")}>
          <button
            className="product-card-buy"
            disabled={busy || !available}
            onClick={() => {
              if (variants.length) {
                setModal({ type: "product", p });
                return;
              }
              buyNow(p);
            }}
          >
            Buy now
          </button>
          <button
            className="product-card-add"
            disabled={busy || !available}
            aria-label={"Add " + p.name + " to cart"}
            onClick={() => add(p)}
          >
            <Plus size={15} /> <span>Add to cart</span>
          </button>
        </div>
      </div>
    </article>
    );
  };
  const orderList = (orders: any[], seller = false) =>
    orders.length ? (
      <div className="orders-list">
        {orders.map((o) => (
          <article className="order" key={o.id}>
            <div className="order-top">
              <div>
                <small>
                  ORDER {o.id.slice(0, 8).toUpperCase()}
                  {o.payment === "flutterwave" &&
                    (o.payment_mode === "live"
                      ? " · LIVE PAYMENT"
                      : " · SANDBOX TEST")}
                </small>
                <h3 className="order-seller-heading">{!seller && <StoreLogo name={o.seller} src={o.seller_logo} size={30} className="order-seller-logo" />}{seller ? o.name : o.seller}</h3>
              </div>
              <span className={"status " + o.status}>{o.status}</span>
              <a href={"/order/" + o.id}>Order details</a>
            </div>
            {o.items?.map((i: any) => (
              <div className="order-line" key={i.id}>
                <span>
                  {i.quantity} × {i.name}
                </span>
                <strong>{money(i.price * i.quantity)}</strong>
                {!seller &&
                  (o.payment === "flutterwave" || o.payment === "auction") &&
                  o.payment_status === "pending" && (
                    <button
                      onClick={() => o.payment === "auction" ? window.location.assign("/order/" + encodeURIComponent(o.id)) : act({ action: "retry-payment", id: o.id })}
                    >
                      {o.payment === "auction" ? "Add delivery address & pay" : `Continue ${o.payment_mode === "live" ? "" : "sandbox "}payment`}
                    </button>
                  )}
                {!seller && o.payment_status === "paid" && (
                  <a href={"/workspace?tab=Support&order=" + encodeURIComponent(o.id)}>Request refund through support</a>
                )}
                {!seller && (
                  <a
                    href={"/api/orders/receipt?id=" + encodeURIComponent(o.id)}
                  >
                    Download order record
                  </a>
                )}
                {o.tracking && <p>Shipment: {o.tracking}</p>}
                {!seller && o.status === "delivered" && (
                  <button
                    onClick={() =>
                      setModal({ type: "review", item: i, order: o })
                    }
                  >
                    Review
                  </button>
                )}
              </div>
            ))}
            <div className="order-footer">
              <span>
                {new Date(o.created).toLocaleDateString("en-GB")} · {o.payment === "flutterwave" ? "Debit card" : "Cash on delivery"}
              </span>
              <strong>{money(o.total)}</strong>
            </div>
            <details>
              <summary>Delivery details</summary>
              <p>
                {o.name} · {o.phone}
                <br />
                {o.address}
              </p>
            </details>
            {!seller && o.status === "placed" && (
              <div className="order-actions">
                <Button
                  busy={busy}
                  className="secondary-button"
                  onClick={() => setModal({ type: "cancelOrder", order: o })}
                >
                  Cancel order
                </Button>
              </div>
            )}
            {seller &&
              ["placed", "confirmed", "shipped"].includes(o.status) && (
                <div className="order-actions">
                  {o.payment === "flutterwave" && o.payment_status !== "paid" && <p role="status">Awaiting verified payment. The customer must complete payment before you can confirm or fulfil this order. Pending payment does not mean it failed; ask the customer to check My orders before retrying.</p>}
                  {o.status !== "shipped" && o.payment !== "flutterwave" && (
                    <Button
                      busy={busy}
                      className="secondary-button"
                      onClick={() =>
                        act(
                          { action: "status", id: o.id, status: "cancelled" },
                          "Order cancelled; stock restored",
                        )
                      }
                    >
                      Cancel order
                    </Button>
                  )}
                  <Button
                    busy={busy}
                    disabled={o.payment === "flutterwave" && o.payment_status !== "paid"}
                    className="primary"
                    onClick={() =>
                      act(
                        {
                          action: "status",
                          id: o.id,
                          status: (
                            {
                              placed: "confirmed",
                              confirmed: "shipped",
                              shipped: "delivered",
                            } as any
                          )[o.status],
                        },
                        "Order updated",
                      )
                    }
                  >
                    {
                      (
                        {
                          placed: "Confirm order",
                          confirmed: "Mark shipped",
                          shipped: "Mark delivered",
                        } as any
                      )[o.status]
                    }
                  </Button>
                </div>
              )}
          </article>
        ))}
      </div>
    ) : (
      <Empty
        icon={Package}
        title="No orders yet"
        text={
          seller
            ? "Your customer orders will appear here."
            : "Your purchases and delivery updates will appear here."
        }
        action={() => nav("Market")}
        label="Browse the market"
      />
    );
  const buyerOrders = Array.isArray(data.orders) ? data.orders : [];
  const filteredBuyerOrders = buyerOrders.filter((order: any) => {
    const status = String(order.status || "").toLowerCase();
    const matchesStatus = ordersFilter === "All" ||
      (ordersFilter === "In progress" && ["placed", "confirmed", "shipped"].includes(status)) ||
      (ordersFilter === "Delivered" && status === "delivered") ||
      (ordersFilter === "Cancelled" && status === "cancelled");
    const search = ordersQuery.trim().toLocaleLowerCase();
    const searchable = [order.id, order.seller, ...(order.items || []).map((item: any) => item.name)].join(" ").toLocaleLowerCase();
    return matchesStatus && (!search || searchable.includes(search));
  });
  const buyerOrderList = filteredBuyerOrders.length ? <div className="buyer-orders-list">
    {filteredBuyerOrders.map((order: any) => {
      const status = String(order.status || "pending").toLowerCase();
      const progress = ["placed", "confirmed", "shipped", "delivered"].indexOf(status);
      const orderDate = order.created ? new Date(order.created).toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" }) : "Date unavailable";
      return <article className="buyer-order-card" key={order.id}>
        <header className="buyer-order-header">
          <div><p className="buyer-order-overline">ORDER PLACED</p><strong>{orderDate}</strong><small>Order #{String(order.id).slice(0, 10).toUpperCase()}</small></div>
          <span className={`buyer-order-status status ${status}`}>{status.replaceAll("_", " ")}</span>
        </header>
        <div className="buyer-order-seller"><StoreLogo name={order.seller || "Cash N Carry seller"} src={order.seller_logo} size={38}/><div><small>SELLER</small><strong>{order.seller || "Seller"}</strong></div><a href={"/order/" + encodeURIComponent(order.id)}>View order <ChevronRight size={16}/></a></div>
        {progress >= 0 && <div className="buyer-order-progress" aria-label={"Order " + status}>{["Placed", "Confirmed", "Shipped", "Delivered"].map((step, index) => <div className={"buyer-order-step" + (index <= progress ? " is-complete" : "") + (index === progress ? " is-current" : "")} key={step}><span aria-hidden="true">{index < progress ? "✓" : index + 1}</span><small>{step}</small></div>)}</div>}
        <div className="buyer-order-items">{(order.items || []).map((item: any) => <div className="buyer-order-item" key={item.id}>
          <div><strong>{item.name || "Product"}</strong><small>Qty {item.quantity || 1}</small></div><strong>{money(Number(item.price || 0) * Number(item.quantity || 1))}</strong>
          {status === "delivered" && <button type="button" className="buyer-order-review" onClick={() => setModal({ type: "review", item, order })}>Review item</button>}
        </div>)}</div>
        {order.tracking && <div className="buyer-order-tracking"><Truck size={18}/><span><small>TRACKING REFERENCE</small><strong>{order.tracking}</strong></span><a href={"/order/" + encodeURIComponent(order.id)}>Track order</a></div>}
        <footer className="buyer-order-footer"><div><small>{order.payment_status === "pending" ? "Payment pending" : order.payment_status === "paid" ? "Payment confirmed" : order.payment_status === "refunded" ? "Payment refunded" : order.payment === "cash_on_delivery" ? "Cash on delivery" : order.payment === "auction" ? "Auction payment" : "Payment details in order"}</small><strong>Total {money(Number(order.total || 0))}</strong></div><div className="buyer-order-actions">
          {(order.payment === "flutterwave" || order.payment === "auction") && order.payment_status === "pending" && <button type="button" className="primary" disabled={busy} onClick={() => order.payment === "auction" ? window.location.assign("/order/" + encodeURIComponent(order.id)) : act({ action: "retry-payment", id: order.id })}>{order.payment === "auction" ? "Add delivery address & pay" : "Continue payment"}</button>}
          {status === "placed" && <button type="button" className="buyer-order-secondary" onClick={() => setModal({ type: "cancelOrder", order })}>Cancel order</button>}
          <details className="buyer-order-more"><summary>More</summary><div><a href={"/api/orders/receipt?id=" + encodeURIComponent(order.id)}>Download order record</a><a href={"/workspace?tab=Support&order=" + encodeURIComponent(order.id)}>Get help with this order</a><details><summary>Delivery address</summary><p>{order.name} · {order.phone}<br/>{order.address}</p></details></div></details>
        </div></footer>
      </article>;
    })}
  </div> : buyerOrders.length ? <div className="buyer-orders-empty"><Package size={28}/><h2>No matching orders</h2><p>Try another search or status filter.</p><button type="button" onClick={() => { setOrdersQuery(""); setOrdersFilter("All"); }}>Clear filters</button></div> : <Empty icon={Package} title="No orders yet" text="Your purchases and delivery updates will appear here." action={() => nav("Market")} label="Browse the market"/>;
  return (
    <div className="app">
      <div className="workspace">
        {view !== "Orders" && <header className={`topbar shopping-header${view === "Market" ? " mobile-shop-header" : view === "Home" ? " mobile-home-header" : ""}`}>
          {view === "Market" && <button type="button" className="marketplace-shop-menu-button" aria-label={shopMenuOpen ? "Close shop navigation" : "Open shop navigation"} aria-expanded={shopMenuOpen} onClick={() => setShopMenuOpen((open) => !open)}>{shopMenuOpen ? <X size={20}/> : <Menu size={20}/>}</button>}
          <BrandLogo tagline compact />
          <button className="delivery-location" onClick={openFilters}>
            <MapPin size={18} />
            <span>
              <small>
                {locationMode === "delivers"
                  ? "Delivery to"
                  : "Seller location"}
              </small>
              <strong>{location || "Choose location"}</strong>
            </span>
          </button>
          <form className="search" role="search" onSubmit={(event) => { event.preventDefault(); if (view !== "Market") nav("Market"); else setPage(1); }}>
            <Search size={19} />
            <input
              aria-label="Search products and businesses"
              placeholder="Search products, brands or sellers"
              enterKeyHint="search"
              value={query}
              onChange={(e) => {
                const nextQuery = e.target.value;
                const mobile = window.matchMedia("(max-width: 767px)").matches;
                const nextView = mobile && view === "Home"
                  ? "Market"
                  : ["Home", "Explore", "Market"].includes(view)
                  ? view
                  : "Market";
                if (nextView !== view) {
                  window.history.replaceState(
                    { shopping: shoppingContext() },
                    "",
                  );
                  window.history.pushState(
                    {
                      shopping: {
                        ...shoppingContext(),
                        view: nextView,
                        query: nextQuery,
                        page: 1,
                      },
                    },
                    "",
                    viewUrl(nextView, nextQuery),
                  );
                } else {
                  window.history.replaceState(
                    {
                      shopping: {
                        ...shoppingContext(),
                        query: nextQuery,
                        page: 1,
                      },
                    },
                    "",
                    viewUrl(nextView, nextQuery),
                  );
                }
                setQuery(nextQuery);
                setView(nextView);
                setPage(1);
              }}
            />
            <button className="marketplace-search-submit" type="submit" aria-label="Show search results"><Search size={18}/></button>
          </form>
          <nav className="shopping-links" aria-label="Main navigation">
            <button
              aria-current={view === "Home" ? "page" : undefined}
              onClick={() => nav("Home")}
            >
              Home
            </button>
            <button
              aria-current={view === "Market" && category === "All" ? "page" : undefined}
              onClick={() => { nav("Market"); setCategory("All"); setPage(1); }}
            >
              Shop
            </button>
            <button
              className="nav-live-button"
              aria-current={view === "Live" ? "page" : undefined}
              onClick={() => nav("Live")}
            >
              <Radio size={18} aria-hidden="true" /> Live
            </button>
            <button onClick={() => window.location.assign("/for-you")}>For You</button>
            {(data.categories || []).filter((item: any) => String(item.name).trim().toLocaleLowerCase() !== "home").slice(0, 5).map((item: any) => (
              <button
                className="desktop-category-nav"
                key={item.name}
                aria-current={view === "Market" && category === item.name ? "page" : undefined}
                onClick={() => { nav("Market", { category: item.name }); setPage(1); }}
              >
                {item.name}
              </button>
            ))}
          </nav>
          {view === "Home" && <button
            className="notification-button"
            onClick={() => signed("notifications") && setModal({type: "notifications"})}
            aria-label={"Notifications" + (data.notifications?.filter((n: any) => !n.read).length ? ", " + data.notifications.filter((n: any) => !n.read).length + " unread" : "")}
            aria-haspopup="dialog"
            aria-expanded={modal?.type === "notifications"}
          >
            <Bell size={21} aria-hidden="true" />
            {data.notifications?.some((n: any) => !n.read) && <span className="notification-badge">{Math.min(99,data.notifications.filter((n: any) => !n.read).length)}</span>}
          </button>}
          <button
            className="cart-button"
            onClick={() => signed("cart") && setModal({ type: "cart" })}
            aria-label="Shopping cart"
          >
            <ShoppingCart size={22} />
            {data.cart.length > 0 && (
              <b>
                {data.cart.reduce((s: number, p: any) => s + p.quantity, 0)}
              </b>
            )}
          </button>
          <Link className="wishlist-button" href="/workspace?tab=Saved%20products" aria-label="Wishlist">
            <Heart size={21} aria-hidden="true" /><span>Wishlist</span>
          </Link>
          <button
            className="profile-button"
            aria-label="My account"
            onClick={() => window.location.assign("/account")}
          >
            <span className="avatar">
              {data.user ? (
                data.user.name[0].toUpperCase()
              ) : (
                <Users size={17} />
              )}
            </span>
          </button>
        </header>}
        {shopMenuOpen && view === "Market" && <><button className="marketplace-menu-scrim" aria-label="Close shop navigation" onClick={() => setShopMenuOpen(false)}/><nav className="marketplace-mobile-drawer" aria-label="Shop navigation">
          <div className="marketplace-mobile-drawer-brand"><BrandLogo compact/><button type="button" aria-label="Close shop navigation" onClick={() => setShopMenuOpen(false)}><X size={20}/></button></div>
          {[["Home","Home"],["Shop","Market"],["Live shopping","Live"],["Orders","Orders"]].map(([label,destination])=><button type="button" key={label} onClick={()=>{setShopMenuOpen(false);nav(destination);}}><ShoppingBag size={18}/><span>{label}</span></button>)}
          <a href="/for-you" onClick={()=>setShopMenuOpen(false)}><Play size={18}/><span>For You</span></a><a href="/workspace?tab=Saved%20products" onClick={()=>setShopMenuOpen(false)}><Heart size={18}/><span>Wishlist</span></a><a href="/messages" onClick={()=>setShopMenuOpen(false)}><MessageSquare size={18}/><span>Messages</span></a><a href="/account" onClick={()=>setShopMenuOpen(false)}><Users size={18}/><span>Profile</span></a>{(data.myStore || data.sellerAccess?.canSell) && <a href="/seller" onClick={()=>setShopMenuOpen(false)}><Store size={18}/><span>Seller Centre</span></a>}<a href="/help" onClick={()=>setShopMenuOpen(false)}><FileCheck2 size={18}/><span>Customer help</span></a>
        </nav></>}
        <main id="main-content" tabIndex={-1} className={view === "Market" ? "shop-market-page" : view === "Orders" ? "buyer-orders-page" : view === "Home" ? "mobile-discovery-home storefront-home" : view === "Explore" ? "marketplace-explore-page" : undefined}>
          {view === "Explore" ? (
            <section className="seller-directory" aria-labelledby="seller-directory-title">
              <header className="seller-directory-heading">
                <div><h1 id="seller-directory-title">Seller storefronts</h1><p>Browse each seller’s own collection, story and available products.</p></div>
                <span aria-live="polite">{sellerDirectoryStores.length} {sellerDirectoryStores.length === 1 ? "store" : "stores"}</span>
              </header>
              <div className="seller-directory-tools" role="search" aria-label="Find a seller">
                <label><span className="sr-only">Search sellers</span><Search size={15} aria-hidden="true"/><input type="search" value={sellerDirectorySearch} onChange={(event) => setSellerDirectorySearch(event.target.value)} placeholder="Search sellers" /></label>
                <label><span className="sr-only">Filter sellers by category</span><select value={sellerDirectoryCategory} onChange={(event) => setSellerDirectoryCategory(event.target.value)}><option value="All">All categories</option>{sellerDirectoryCategories.map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
              </div>
              {loading && !data.stores.length ? <p className="seller-directory-status" role="status">Loading seller storefronts…</p> : error && !data.stores.length ? <div className="seller-directory-status" role="alert">{error}<button type="button" onClick={load}>Retry</button></div> : sellerDirectoryStores.length ? (
                <div className="explore-store-grid">
                  {sellerDirectoryStores.map((s: any) => (
                    <a className="explore-store-card" key={s.id} href={`/store/${encodeURIComponent(s.slug || s.id)}`} aria-label={`Visit ${s.name} storefront`}>
                      <span className="explore-store-cover">{s.banner && <ImageAsset src={storefrontImageUrl(s.banner, 640)} srcSet={storefrontImageSrcSet(s.banner, [320,480,640])} sizes="(max-width: 700px) 90vw, 420px" fallbackSrc={s.banner} alt="" width="640" height="250" loading="lazy"/>}<span className="explore-store-mark"><StoreLogo name={s.name} src={s.logo} size={72}/></span></span>
                      <span className="explore-store-copy"><strong className="explore-store-name"><span>{s.name}</span></strong><span className="explore-store-meta">{[s.category, s.location].filter(Boolean).join(" · ")}</span>{s.description && <span className="explore-store-description">{s.description}</span>}<span className="explore-store-visit">Visit storefront <ArrowUpRight size={16}/></span></span>
                    </a>
                  ))}
                </div>
              ) : <p className="seller-directory-status">{sellerDirectorySearch || sellerDirectoryCategory !== "All" ? "No matching sellers. Try a different search or category." : "Seller storefronts will appear here as sellers join Cash N Carry."}</p>}
            </section>
          ) : <>
          {view === "Home" && <section className="mobile-home-feed desktop-home-feed" aria-label="Video and live discovery"><VideoFeed liveStreams={homeFeedLiveStreams} products={[...data.products, ...(data.pinnedProducts || []), ...catalogue.products, ...(catalogue.featured || [])]} myStoreId={data.myStore?.id} onOpenLive={(stream) => setModal({ type: "live", stream })}/></section>}
          {view === "Seller" &&
            data.myStore &&
            listingReview(data.myStore, data.myProducts || []).length > 0 && (
              <section className="notice" aria-label="Seller details to review">
                <h2>Details needing your review</h2>
                <ul>
                  {listingReview(data.myStore, data.myProducts || []).map(
                    (w) => (
                      <li key={w}>{w}</li>
                    ),
                  )}
                </ul>
                <a href="/workspace?tab=Account">Manage seller account</a>
              </section>
            )}
          {resumeError && (
            <div className="error-banner" role="alert">
              {resumeError}{" "}
              <button onClick={() => setResumeRetry((v) => v + 1)}>
                Retry saved selection
              </button>
            </div>
          )}
          {sharedProductLoading && <p role="status">Opening selected item…</p>}
          {sharedProductError && (
            <div role="alert" className="error-banner">
              {sharedProductError}{" "}
              <button onClick={() => setSharedProductRetry((v) => v + 1)}>
                Retry selected item
              </button>
            </div>
          )}
          {error ? (
            <div className="error-banner">
              {error} <button onClick={load}>Retry</button>
            </div>
          ) : null}
          {error && !data.products.length && !data.user ? (
            <Empty
              title={brand.name + " is temporarily unavailable"}
              text="Your connection or the service may be unavailable. Please try again."
              action={load}
              label="Retry"
            />
          ) : loading ? (
            <div className="loading">
              <LoaderCircle className="spin" /> Opening {brand.name}…
            </div>
          ) : view === "Seller" && !dashboardStylesReady ? (
            <div className="loading" role="status">Opening seller workspace…</div>
          ) : view === "Seller" ? (
            <>
              {data.myStore && <div className="page-heading seller-dashboard-heading">
                <div>
                  <p className="eyebrow">YOUR BUSINESS WORKSPACE</p>
                  <h1>Welcome back{data.myStore?.name ? `, ${data.myStore.name}` : ""}</h1>
                  <p>Your store, orders and next steps at a glance.</p>
                  {data.myStore && <div className="seller-dashboard-identity"><span>{data.myStore.suspended ? "Store needs attention" : "Store is active"}</span><span className="seller-dashboard-status-dot" aria-hidden="true"/></div>}
                </div>
                {data.myStore ? (
                  <div className="seller-dashboard-actions">
                  <a className="seller-view-store" href={`/store/${data.myStore.id}`}><Store size={17}/> View storefront</a>
                  <button
                    className="primary"
                    onClick={() => setModal({ type: "productForm" })}
                  >
                    <Plus size={18} />
                    Add a product
                  </button>
                  </div>
                ) : null}
              </div>}
              <details className="seller-policy-disclosure"><summary>Seller policies &amp; guidance</summary><nav className="seller-policy-links" aria-label="Seller policies">
                <a href="/seller-terms" target="_blank" rel="noopener noreferrer">Seller Terms</a>
                <a href="/community-guidelines" target="_blank" rel="noopener noreferrer">Community Guidelines</a>
                <a href="/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a>
              </nav></details>
              {!data.myStore ? (
                <div className="seller-workspace-layout">
                  <Suspense fallback={<div className="seller-workspace-nav-loading" aria-hidden="true" />}><SellerNavigation active="Dashboard"/></Suspense>
                  <section className="seller-workspace-content" aria-label="Seller dashboard">
                <section className="onboarding panel">
                  <div>
                    <span className="pill">START SELLING</span>
                    <h2>
                      Give your business
                      <br />a home on {brand.name}.
                    </h2>
                    <p>
                      List your products, share demonstrations and manage orders
                      in one place.
                    </p>
                    <p className="policy-link-list"><a href="/seller-terms">Seller Terms</a><a href="/community-guidelines">Community Guidelines</a></p>
                    <ul>
                      <li>
                        <Check size={18} />A dedicated storefront
                      </li>
                      <li>
                        <Check size={18} />
                        Products, videos and inventory
                      </li>
                      <li>
                        <Check size={18} />
                        Live shopping and customer chat
                      </li>
                    </ul>
                    <button
                      className="primary"
                      onClick={() => setModal({ type: "storeForm" })}
                    >
                      Create my store
                    </button>
                  </div>
                  <Store size={100} strokeWidth={1} />
                </section>
                  </section>
                </div>
              ) : (
                <>
<div className="seller-workspace-layout"><Suspense fallback={<div className="seller-workspace-nav-loading" aria-hidden="true" />}><SellerNavigation active={sellerTab==='Overview'?'Dashboard':sellerTab==='Store'?'Storefront':sellerTab}/></Suspense>

                    <section
                      className="seller-workspace-content"
                      aria-label={sellerTab}
                    >
                      {["Overview", "Analytics"].includes(sellerTab) ? (
                        <>
                          <Suspense fallback={<div className="panel seller-activation-loading" aria-hidden="true" />}><SellerActivationCard /></Suspense>
                          <div className="stats">
                            {[
                              ["Delivered order value", money(sales), ChartColumn],
                              ["Pending orders", data.sellerOrders.filter((o: any) => !["delivered", "cancelled"].includes(o.status)).length, Package],
                              ["Listed products", mine.length, ShoppingBag],
                              ["Live now", data.streams.filter((s: any) => s.store === data.myStore.id && ["live", "external"].includes(s.status)).length, Radio],
                            ].map(([l, n, I]: any) => (
                              <div className="stat panel" key={l}>
                                <span>{l}<I size={19} /></span>
                                <strong>{n}</strong>
                                <small>{l === "Delivered order value" ? "Gross value of delivered orders" : "From your store activity"}</small>
                              </div>
                            ))}
                          </div>
                          <section className="panel">
                            <div className="section-heading">
                              <h2>Recent orders</h2>
                              <button onClick={() => setSellerTab("Orders")}>
                                View all
                              </button>
                            </div>
                            {orderList(data.sellerOrders.slice(0, 4), true)}
                          </section>
                          <p className="dashboard-footnote">Sales figures reflect delivered orders. Settlement records are available in Payments &amp; refunds.</p>
                        </>
                      ) : sellerTab === "Products" ||
                        sellerTab === "Content" ? (
                        <>
                          <div className="section-heading">
                            <h2>
                              {sellerTab === "Content"
                                ? "Product videos"
                                : "Your products"}
                            </h2>
                            {sellerTab === "Products" && <Link className="secondary-button" href="/seller/bulk-upload">Bulk upload</Link>}

                          </div>
                          {sellerTab === "Content" &&
                          !mine.some((p: any) => p.video) ? (
                            <Empty
                              title="No product videos yet"
                              text="Edit a product to upload a video and link it to your listing."
                              action={() => setSellerTab("Products")}
                              label="Manage products"
                            />
                          ) : mine.length ? (
                            <div className="inventory">
                              {mine
                                .filter(
                                  (p: any) =>
                                    sellerTab !== "Content" || p.video,
                                )
                                .map((p: any) => (
                                  <div className="inventory-row" key={p.id}>
                                    <ImageAsset src={p.image} alt={p.name} />
                                    <div>
                                      <strong>{p.name}</strong>
                                      <small>
                                        {p.category} · {p.stock} in stock
                                      </small>
                                    </div>
                                    <strong>{money(p.price)}</strong>
                                    <button
                                      onClick={() =>
                                        setModal({ type: "productForm", p })
                                      }
                                    >
                                      Edit
                                    </button>
                                    <button
                                      className="danger-link"
                                      onClick={() =>
                                        setModal({ type: "archive", p })
                                      }
                                    >
                                      Archive
                                    </button>
                                  </div>
                                ))}
                            </div>
                          ) : (
                            <Empty
                              title="Your first product starts here"
                              text="Upload a photo, set a price and add stock. Customers can then place real orders."
                              action={() => setModal({ type: "productForm" })}
                              label="List a product"
                            />
                          )}
                        </>
                      ) : sellerTab === "Orders" ? (
                        orderList(data.sellerOrders, true)
                      ) : sellerTab === "Ads" ? (
                        <>
                          <div className="section-heading">
                            <h2>Ad campaigns</h2>
                            <button
                              className="primary"
                              onClick={() => setModal({ type: "campaign" })}
                            >
                              Create draft
                            </button>
                          </div>
                          <div className="notice">
                            Save your campaign plan here. Paid delivery and ad
                            billing are not active; drafts do not run or spend
                            money.
                          </div>
                          {data.campaigns.map((c: any) => (
                            <div className="panel campaign" key={c.id}>
                              <div>
                                <h3>{c.title}</h3>
                                <p>
                                  {c.goal} · {c.location} · {c.days} days
                                </p>
                              </div>
                              <strong>
                                {money(c.budget)}/day · {c.placement} ·{" "}
                                {c.payment_status}
                              </strong>
                              <span className="status">Draft</span>
                            </div>
                          ))}
                        </>
                      ) : (
                        <section className="panel store-settings">
                          <span className="eyebrow">YOUR STOREFRONT</span>
                          <h2 className="seller-identity"><span className="seller-name-text">{data.myStore.name}</span></h2>
                          <p>{data.myStore.description}</p>
                          <p>
                            <MapPin size={17} />
                            {data.myStore.location} · {data.myStore.category}
                          </p>
                          <p>{data.myStore.phone}</p>
                          <button
                            className="primary"
                            onClick={() =>
                              setModal({
                                type: "storeForm",
                                store: data.myStore,
                              })
                            }
                          >
                            Edit store
                          </button>
                          <button
                            className="secondary-button"
                            onClick={() =>
                              setModal({ type: "store", store: data.myStore })
                            }
                          >
                            View storefront
                          </button>
                          <p>
                            Shipping fee:{" "}
                            {deliveryFee(data.myStore) === undefined
                              ? "Not set"
                              : money(deliveryFee(data.myStore)!)}{" "}
                            per order
                          </p>
                          <a
                            className="secondary-button"
                            href="/workspace?tab=Delivery"
                          >
                            Set shipping fee
                          </a>
                          <div className="notice">
                            Verification:{" "}
                            {data.myVerification?.status || "Not submitted"}.{" "}
                            <a href="/workspace">
                              Submit documents and manage delivery, broadcasts
                              and support
                            </a>
                          </div>
                        </section>
                      )}
                    </section>
                  </div>
                </>
              )}
            </>
          ) : view === "Orders" ? (
            <section className="buyer-orders-shell" aria-labelledby="buyer-orders-title">
              <a className="buyer-orders-back" href="/account">← Back to Profile</a>
              <div className="buyer-orders-heading"><div><p className="eyebrow">YOUR PURCHASES</p><h1 id="buyer-orders-title">Orders &amp; tracking</h1><p>View order progress, payment status and delivery details.</p></div><span className="buyer-orders-count">{buyerOrders.length} {buyerOrders.length === 1 ? "order" : "orders"}</span></div>
              {buyerOrders.length > 0 && <><div className="buyer-orders-summary" aria-label="Order summary"><div><span>Total orders</span><strong>{buyerOrders.length}</strong></div><div><span>In progress</span><strong>{buyerOrders.filter((o: any) => ["placed", "confirmed", "shipped"].includes(String(o.status).toLowerCase())).length}</strong></div><div><span>Delivered</span><strong>{buyerOrders.filter((o: any) => String(o.status).toLowerCase() === "delivered").length}</strong></div></div>
                <div className="buyer-orders-tools"><label><Search size={17}/><span className="sr-only">Search orders</span><input type="search" value={ordersQuery} onChange={(event) => setOrdersQuery(event.target.value)} placeholder="Search by order, seller or product"/></label><div className="buyer-orders-filters" aria-label="Filter orders">{["All", "In progress", "Delivered", "Cancelled"].map((filter) => <button type="button" key={filter} aria-pressed={ordersFilter === filter} onClick={() => setOrdersFilter(filter)}>{filter}</button>)}</div></div></>}
              {buyerOrderList}
            </section>
          ) : (
            <>
              {view === "Home" ? (
                <ShoppingHero
                  liveCount={data.streams.filter((stream: any) => stream.status === "live").length}
                  onLive={() => nav("Live")}
                  onShop={() => nav("Market")}
                />
              ) : (
                <>
                  {" "}
                  {view !== "Market" && <div className={`page-heading${view === "Market" ? " marketplace-page-heading" : ""}`}>
                    <div>
                      <p className="eyebrow">
                        {view === "Live"
                          ? "REAL-TIME DISCOVERY"
                          : view === "Market"
                            ? "THE " + brand.name + " MARKET"
                            : "MADE FOR YOUR NEXT DISCOVERY"}
                      </p>
                      <h1>
                        {view === "Live"
                          ? "Meet your next find. Live."
                          : view === "Market"
                            ? "Shop"
                            : view === "Explore"
                              ? "Find your kind of business."
                              : "Discover something good."}
                      </h1>
                      <p>
                        {view === "Live"
                          ? "Watch product demonstrations, ask sellers questions and shop while they’re live."
                          : view === "Market"
                            ? "Discover products from trusted Nigerian sellers."
                            : "Fresh products, local businesses and a closer way to shop."}
                      </p>
                    </div>
                  </div>}
                  {view === "Live" && <section className="buyer-live-intro" aria-label="Watch live shopping">
                    <div className="buyer-live-pulse" aria-hidden="true"><Radio size={22}/></div>
                    <div><p className="eyebrow">LIVE SHOPPING</p><h2>Watch sellers show you the details.</h2><p>Join an active broadcast, browse upcoming sessions or catch a replay. You can watch and shop with a buyer account.</p></div>
                    <div className="buyer-live-actions"><button className="secondary-button" onClick={() => nav("Market")}>Shop products</button><a href="/start-selling">Have a business? Start selling</a></div>
                  </section>}
                </>
              )}
          {view === "Home" && !loading && !error && (
            <ShopCategories
              products={categoryProducts}
              categories={categories.slice(1)}
              onSelect={(label, stored, term) => {
                nav("Market");
                setCategory(stored);
                setQuery(term);
              }}
            />
          )}
          {view === "Market" && (
            <>
              <section className="shop-campaign-hero" aria-labelledby="shop-campaign-title">
                <div className="shop-campaign-copy">
                  <p className="shop-campaign-eyebrow"><span aria-hidden="true"/> THE CASH N CARRY EDIT</p>
                  <h1 id="shop-campaign-title">Quality finds.<br/>Trusted local sellers.</h1>
                  <p>Discover fashion, electronics, home essentials and more from businesses across Nigeria.</p>
                  <a href="#market-products">Shop all products <ArrowRight size={17} aria-hidden="true"/></a>
                </div>
                <div className="shop-campaign-image">
                  <ImageAsset src="/seller-hero.webp" srcSet="/seller-hero-640.webp 640w, /seller-hero.webp 1050w" sizes="(max-width: 700px) 100vw, 54vw" alt="Nigerian seller presenting a product in her shop" width="1050" height="700" loading="eager" fetchPriority="high"/>
                  <span>Shop Nigerian businesses</span>
                </div>
              </section>
              <div className="marketplace-shop-categories">
                <ShopCategories
                  products={categoryProducts}
                  categories={categories.slice(1)}
                  mobileVariant
                  activeCategory={category}
                  onSelect={(_label, stored, term) => {
                    setCategory(stored);
                    setQuery(term);
                    setPage(1);
                  }}
                />
              </div>
            </>
          )}

              {view === "Home" && (
                <div className="feed-tabs">
                  {["For You", "Following"].map((t) => (
                    <button
                      className={tab === t ? "selected" : ""}
                      key={t}
                      onClick={() => {
                        setTab(t);
                        if (t === "LIVE") nav("Live");
                      }}
                    >
                      {t === "LIVE" && <Radio size={15} />} {t}
                    </button>
                  ))}
                </div>
              )}
              {view === "Live" && (
                <div className="feed-tabs" aria-label="Broadcast discovery">
                  <button
                    className={tab !== "Following" ? "selected" : ""}
                    onClick={() => setTab("For You")}
                  >
                    All broadcasts
                  </button>
                  <button
                    className={tab === "Following" ? "selected" : ""}
                    onClick={() => setTab("Following")}
                  >
                    Following
                  </button>
                </div>
              )}
              <div className={`browse-toolbar${view === "Market" ? " marketplace-browse-toolbar" : ""}`}>
                <button className="secondary-button" onClick={openFilters}>
                  <SlidersHorizontal size={17} /> Filter
                  {category !== "All" || location || minPrice || maxPrice || inStockOnly ? " · active" : ""}
                </button>
                <span>
                  {location
                    ? (locationMode === "delivers"
                        ? "Delivers to "
                        : "Sellers in ") + location
                    : "Discover across Nigeria"}
                </span>
                {view === "Market" ? <>
                  <label className="shop-toolbar-select"><span className="sr-only">Sort products</span><select aria-label="Sort products" value={sort} onChange={(event) => { setSort(event.target.value); setPage(1); }}><option value="featured">Recommended</option><option value="newest">Newest</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option><option value="rating">Highest rated</option></select></label>
                  <label className="shop-toolbar-select shop-category-select"><span className="sr-only">Product category</span><select aria-label="Product category" value={category} onChange={(event) => { setCategory(event.target.value); setPage(1); }}><option value="All">All products</option>{categories.slice(1).map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
                </> : view === "Explore" ? <a className="explore-seller-anchor" href="#explore-storefronts">Discover storefronts <ChevronRight size={15} /></a> : <button onClick={() => nav("Explore")}>Discover sellers</button>}
              </div>
              {view !== "Market" && <div className={`category-bar${view === "Home" ? " home-category-strip" : ""}${view === "Market" ? " marketplace-category-bar" : ""}${view === "Explore" ? " explore-category-bar" : ""}`}>
                {categories.map((c, i) => {
                  const I = icons[i] || ShoppingBag;
                  return (
                    <button
                      key={c}
                      className={category === c ? "selected" : ""}
                      onClick={() => setCategory(c)}
                    >
                      <I size={17} />
                      {c}
                    </button>
                  );
                })}
              </div>}
              {view === "Explore" ? (
                <>
                  <div className="explore-intro-row">
                    <div><p className="eyebrow">CURATED FOR YOUR NEXT DISCOVERY</p><h2>Browse by interest</h2><p>Choose a category, then explore products and independent seller storefronts.</p></div>
                    <a href="#explore-storefronts">Meet the sellers <ArrowRight size={16}/></a>
                  </div>
                  <div className="category-grid">
                    {categories.slice(1).map((c, i) => {
                      const I = icons[i + 1] || ShoppingBag;
                      const categoryProduct = categoryProducts.find((product: any) => product.category === c && product.image);
                      return (
                        <button
                          key={c}
                          onClick={() => {
                            setView("Market");
                            setCategory(c);
                          }}
                          className={"category-tile cat-" + i}
                          aria-label={`Explore ${c}`}
                        >
                          <span className="explore-category-image">{categoryProduct?.image ? <ImageAsset src={storefrontImageUrl(categoryProduct.image, 640)} srcSet={storefrontImageSrcSet(categoryProduct.image, [320,480,640])} sizes="(max-width: 700px) 78vw, 30vw" fallbackSrc={categoryProduct.image} alt="" width="640" height="360" loading="lazy" /> : <I size={38} aria-hidden="true" />}</span>
                          <span className="explore-category-copy"><strong>{c}</strong><span>Explore category <ChevronRight size={16} /></span></span>
                        </button>
                      );
                    })}
                  </div>
                  <div className="explore-storefront-heading" id="explore-storefronts">
                    <div><p className="eyebrow">MEET THE PEOPLE BEHIND THE PRODUCTS</p><h2>Seller storefronts</h2><p>Browse each seller’s own collection, story and available products.</p></div>
                    <span>{stores.length} {stores.length === 1 ? "store" : "stores"}</span>
                  </div>
                  {stores.length ? (
                    <div className="explore-store-grid">
                      {stores.map((s: any) => (
                        <a
                          className="explore-store-card"
                          key={s.id}
                          href={`/store/${encodeURIComponent(s.slug || s.id)}`}
                          aria-label={`Visit ${s.name} storefront`}
                        >
                          <span className="explore-store-cover">{s.banner && <ImageAsset src={storefrontImageUrl(s.banner, 640)} srcSet={storefrontImageSrcSet(s.banner, [320,480,640])} sizes="(max-width: 700px) 90vw, 420px" fallbackSrc={s.banner} alt="" width="640" height="250" loading="lazy"/>}<span className="explore-store-mark"><StoreLogo name={s.name} src={s.logo} size={72}/></span></span>
                          <span className="explore-store-copy"><strong className="explore-store-name"><span>{s.name}</span></strong><span className="explore-store-meta">{[s.category, s.location].filter(Boolean).join(" · ")}</span>{s.description && <span className="explore-store-description">{s.description}</span>}<span className="explore-store-visit">Visit storefront <ArrowUpRight size={16}/></span></span>
                        </a>
                      ))}
                    </div>
                  ) : (
                    <Empty
                      icon={Store}
                      title={
                        location || query || category !== "All"
                          ? "No matching businesses"
                          : "Room for your business"
                      }
                      text={
                        location || query || category !== "All"
                          ? "Try another location or clear your filters."
                          : "Be one of the first businesses on " +
                            brand.name +
                            "."
                      }
                      action={() =>
                        location || query || category !== "All"
                          ? (setLocation(""), setQuery(""), setCategory("All"))
                          : signed("seller") && nav("Seller")
                      }
                      label={
                        location || query || category !== "All"
                          ? "Clear filters"
                          : "Open a store"
                      }
                    />
                  )}
                </>
              ) : (
                <>
                  {((view === "Home" || view === "Market")
                      ? liveStreams.filter((s: any) =>
                          ["live", "external"].includes(s.status),
                        )
                      : liveStreams
                    ).length > 0 ? (
                      <section>
                        <div className="section-heading">
                          <h2>
                            <span className="red-dot" />
                            {view === "Home" || view === "Market" ? "Live now" : "Watch broadcasts"}
                          </h2>
                          <span>{broadcastSummary(liveStreams)}</span>
                        </div>
                        <div className="live-grid">
                          {(view === "Home" || view === "Market"
                            ? liveStreams.filter((s: any) =>
                                ["live", "external"].includes(s.status),
                              )
                            : liveStreams
                          ).map((s: any) => {
                            const p = [
                              ...data.products,
                              ...(data.pinnedProducts || []),
                              ...catalogue.products,
                              ...(catalogue.featured || []),
                              ...(data.myProducts || []),
                            ].find((p: any) => p.id === s.product);
                            return (
                              <div className="live-card-reminder-wrap" key={s.id}>
                              <button
                                className="live-card"
                                onClick={() =>
                                  setModal({ type: "live", stream: s })
                                }
                              >
                                {p ? (
                                  <ImageAsset src={p.image} alt={p.name} />
                                ) : (
                                  <div className="live-placeholder">
                                    <Radio size={50} />
                                  </div>
                                )}
                                <span className="live-badge">
                                  {broadcastLabel(s)}
                                </span>
                                <span className="play-circle">
                                  <Play fill="currentColor" size={21} />
                                </span>
                                <div>
                                  <small className="live-card-seller"><StoreLogo name={s.seller} src={s.seller_logo} size={28} className="live-card-seller-logo"/>{s.seller}</small>
                                  <h3>{s.title}</h3>
                                  {s.status === "scheduled" && (
                                    <ScheduleInfo scheduled={s.scheduled} />
                                  )}
                                  <span>
                                    {s.status === "scheduled"
                                      ? "Scheduled broadcast"
                                      : s.status === "ended"
                                        ? s.replay
                                          ? "Watch replay"
                                          : "Session ended"
                                        : s.provider === "tiktok"
                                          ? "Watch on TikTok"
                                          : p
                                            ? money(p.price)
                                            : "Join the conversation"}
                                  </span>
                                </div>
                              </button>
                              {s.status === "scheduled" && <StreamReminderButton streamId={s.id} />}
                              </div>
                            );
                          })}
                        </div>
                      </section>
                    ) : view === "Live" ? (
                      <Empty
                        icon={Radio}
                        headingLevel={2}
                        title="No broadcasts available"
                        text="There are no live streams, scheduled sessions or replays matching your filters."
                        action={() => nav("Market")}
                        label="Browse products"
                      />
                    ) : (
                      <section className="live-empty">
                        <div className="section-heading">
                          <h2>Live now</h2>
                        </div>
                        <div className="live-empty-body">
                          <Radio size={28} />
                          <div>
                            <h3>No sellers are live right now</h3>
                            <p>
                              Browse scheduled sessions and replays, or explore
                              products while you wait.
                            </p>
                          </div>
                          <button
                            className="secondary-button"
                            onClick={() => nav("Live")}
                          >
                            Browse broadcasts
                          </button>
                        </div>
                      </section>
                    )}
                  {view !== "Live" && (
                    <>
                        <div className="section-heading" id={view === "Market" ? "market-products" : undefined}>
                        <h2>
                          {view === "Market" ? (
                            <>
                              <span className="desktop-market-products-heading">{query || category !== "All" ? "Search results" : location || deviceLocation ? "Products near you" : sort === "newest" ? "New arrivals" : sort === "featured" ? "Featured products" : "Explore products"}</span>
                              <span className="mobile-market-products-heading">{query || category !== "All" ? "Search results" : location || deviceLocation ? "Products near you" : sort === "newest" ? "New arrivals" : sort === "featured" ? "Featured products" : "Explore products"}</span>
                            </>
                          ) : tab === "Following" && view === "Home"
                            ? "From stores you follow"
                            : "Discover local favourites"}
                        </h2>
                        <span>
                          {catalogue.total}{" "}
                          {catalogue.total === 1 ? "product" : "products"}{" "}
                          <SlidersHorizontal size={15} />
                        </span>
                      </div>
                      {catalogueLoading && !catalogue.products.length ? (
                        <div className="product-grid catalogue-skeleton" role="status" aria-label="Loading products">{Array.from({length:4},(_,i)=><div className="product-skeleton" key={i}/>)}</div>
                      ) : catalogueError ? (
                        <div role="alert">
                          <p>{catalogueError}</p>
                          <button
                            onClick={() => setCatalogueVersion((v) => v + 1)}
                          >
                            Retry products
                          </button>
                        </div>
                      ) : products.length ? (
                        <div className={`product-grid${view === "Home" ? " home-product-grid" : ""}${view === "Market" ? " shop-market-product-grid" : ""}`}>
                          {homeProducts.map((p: any, index: number) =>
                            renderProduct(p, false, view === "Market" && index === 0),
                          )}
                        </div>
                      ) : (
                        <Empty
                          title={
                            query || location || category !== "All"
                              ? "No matching products"
                              : tab === "Following"
                                ? "Your favourite stores, right here"
                              : view === "Market" ? "No products available yet" : "No products to show yet"
                          }
                          text={
                            query || location || category !== "All"
                              ? "Try a different location, search or category."
                              : tab === "Following"
                                ? "Explore businesses and follow a store to see its products."
                              : view === "Market" ? "New products from Nigerian sellers will appear here as they become available. Check back soon." : "Browse businesses and explore products from sellers across Nigeria."
                          }
                          action={() =>
                            query || location || category !== "All"
                              ? (setQuery(""),
                                setCategory("All"),
                                setLocation(""))
                              : tab === "Following"
                                ? nav("Explore")
                                : nav("Explore")
                          }
                          label={
                            query || location || category !== "All"
                              ? "Clear filters"
                              : "Explore stores"
                          }
                        />
                      )}
                      {view === "Home" && products.length > homeProducts.length && (
                        <div className="home-product-more">
                          <button className="secondary-button" onClick={() => nav("Market")}>
                            Browse all products
                          </button>
                        </div>
                      )}
                    </>
                  )}
                </>
              )}
            </>
          )}
          {view === "Home" &&
            !catalogueLoading &&
            !catalogueError &&
            catalogue.featured?.length > 0 && (
              <section className="home-featured-products">
                <h2>Featured products</h2>
                <div className="product-grid">
                  {catalogue.featured.slice(0, 2).map((p: any) => renderProduct(p))}
                </div>
              </section>
            )}
          {view === "Home" && !catalogueLoading && !catalogueError && (() => {
            const shoppableVideos = Array.from(new Map((catalogue.products || []).filter((p: any) => p.video && p.video_status !== "removed").map((p: any) => [p.video, p])).values()).slice(0, 4);
            if (!shoppableVideos.length) return null;
            return <section className="shoppable-video-shelf" aria-labelledby="shoppable-videos-title">
              <div className="section-heading"><div><p className="eyebrow">Watch · discover · shop</p><h2 id="shoppable-videos-title">Shop through product videos</h2></div><button onClick={() => nav("Market")}>Browse products <ChevronRight size={16} /></button></div>
              <div className="shoppable-video-grid">{shoppableVideos.map((p: any) => {
                const variants: any[] = JSON.parse(p.variants || "[]");
                const available = variants.length ? variants.some((v) => v.stock > 0) : p.stock > 0;
                return <article key={p.id} className="shoppable-video-card">
                  <div className="shoppable-video-player">
                    <LazyProductVideo src={p.video} poster={p.image} label={`${p.name} product video`} />
                  </div>
                  <div className="shoppable-video-copy"><a href={`/product/${p.id}`}><strong>{p.name}</strong></a><span className="shoppable-video-seller"><StoreLogo name={p.seller} src={p.seller_logo} size={24} className="shoppable-seller-logo"/>{money(p.price)} · {p.seller}</span></div>
                  <div className="product-card-actions"><button className="product-card-buy" disabled={busy || !available} onClick={() => variants.length ? setModal({ type: "product", p }) : buyNow(p)}>Buy now</button><button className="product-card-add" disabled={busy || !available} onClick={() => add(p)}><Plus size={16} /> Add to cart</button></div>
                </article>;
              })}</div>
            </section>;
          })()}
          {view === "Home" && !loading && stores.length > 0 && (
            <section className="home-sellers" aria-label="Discover sellers">
              <div className="section-heading"><h2>Meet the sellers</h2><button onClick={() => nav("Explore")}>View all sellers <ChevronRight size={16} /></button></div>
              <div className="home-seller-list">{stores.slice(0, 4).map((store: any) => <a key={store.id} className="home-seller-card" href={"/store/" + (store.slug || store.id)}><StoreLogo name={store.name} src={store.logo} size={48}/><div><h3>{store.name}</h3><p>{store.category} · {store.location}</p></div><ChevronRight size={18} aria-hidden="true" /></a>)}</div>
            </section>
          )}
          {view === "Market" && (
            <section className="shop-discovery-sections" aria-label="Seller storefront discovery">
              <div className="section-heading">
                <div><p className="eyebrow">Find your next favourite</p><h2>Seller storefronts</h2></div>
                <button onClick={() => nav("Explore")}>Explore all sellers <ChevronRight size={16} /></button>
              </div>
              {stores.length ? (
                <div className="home-seller-list">
                  {stores.slice(0, 6).map((store: any) => (
                    <a key={store.id} className="home-seller-card" href={`/store/${store.slug || store.id}`}>
                      <StoreLogo name={store.name || "Seller"} src={store.logo} size={48} />
                      <div><h3>{store.name}</h3><p>{store.category} · {store.location}</p></div>
                      <ChevronRight size={18} aria-hidden="true" />
                    </a>
                  ))}
                </div>
              ) : <p>Seller storefronts will appear here as sellers join Cash N Carry.</p>}
            </section>
          )}
          {data.sponsored?.length > 0 && (
            <section>
              <h2>Sponsored</h2>
              <div className="product-grid">
                {data.sponsored
                  .filter(
                    (c: any) =>
                      c.placement ===
                      (view === "Market" ? "market" : "discovery"),
                  )
                  .map((c: any) => (
                    <a
                      key={c.id}
                      href={"/product/" + c.product}
                      onClick={() =>
                        fetch("/api/ads-events", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({
                            campaign: c.id,
                            kind: "click",
                          }),
                          keepalive: true,
                        }).catch(() => {})
                      }
                    >
                      <ImageAsset src={c.image} alt={c.name} width="160" />
                      <small>Sponsored</small>
                      <h3>{c.name}</h3>
                      <p>
                        <StoreLogo name={c.seller} src={data.stores.find((store: any) => store.id === c.store)?.logo} size={22} className="product-seller-logo" />{money(c.price)} · {c.seller}
                      </p>
                    </a>
                  ))}
              </div>
            </section>
          )}
          {["Home", "Market"].includes(view) && (
            <>
              <div className="market-controls">
                {view === "Home" && (
                  <label>
                    Sort products{" "}
                    <select
                      value={sort}
                      onChange={(e) => {
                        setSort(e.target.value);
                        setPage(1);
                      }}
                    >
                      <option value="featured">Recommended</option>
                      <option value="newest">Newest</option>
                      <option value="low">Price: low to high</option>
                      <option value="high">Price: high to low</option>
                      <option value="rating">Highest rated</option>
                    </select>
                  </label>
                )}
                {catalogue.pages > 1 && (
                  <>
                    <button
                      disabled={catalogueLoading || page <= 1}
                      onClick={() => setPage((p) => p - 1)}
                    >
                      Previous
                    </button>
                    <span>
                      Page {page} of {catalogue.pages}
                    </span>
                    <button
                      disabled={catalogueLoading || page >= catalogue.pages}
                      onClick={() => setPage((p) => p + 1)}
                    >
                      Next
                    </button>
                  </>
                )}
              </div>
            </>
          )}
          {view === "Home" && <ShoppingGuide onShop={() => nav("Market")} onLive={() => nav("Live")} />}
          {view !== "Orders" && (view === "Market" ? <MarketplaceFooter /> : view === "Home" ? <HomeFooter onShop={() => nav("Market")} onLive={() => nav("Live")} /> : <footer><BrandLogo tagline /><span><a href="/help">Help &amp; contact</a> · <a href="/privacy">Privacy</a> · <a href="/terms">Terms</a> · <a href="/delivery">Delivery</a> · <a href="/refunds">Returns and refunds</a> · <a href="/seller-terms">Seller Terms</a> · <a href="/community-guidelines">Community Guidelines</a></span></footer>)}
          </>}
        </main>
      </div>
      <nav className="mobile-nav" aria-label="Customer navigation">
        {[
          [Home, "Home"],
          [ShoppingBag, "Shop"],
          [Plus, "Create"],
          [MessageCircle, "Messages"],
          [Users, "Profile"],
        ].map(([I, l]: any) => (
          <button
            className={`${l === "Create" ? "mobile-create-button" : ""} ${
              view === (l === "Shop" ? "Market" : l) ||
              (l === "Profile" && (modal?.type === "account" || view === "Orders"))
                ? "active"
                : ""}`}
            key={l}
            aria-current={view === (l === "Shop" ? "Market" : l) || (l === "Profile" && (modal?.type === "account" || view === "Orders")) ? "page" : undefined}
            aria-label={l === "Create" ? "Create video or go live" : l}
            onClick={() =>
              l === "Create"
                ? void openVideoCreation()
                : l === "Profile"
                ? window.location.assign("/account")
                : l === "Messages"
                  ? window.location.assign("/messages")
                : nav(l === "Shop" ? "Market" : l)
            }
          >
            <I size={l === "Create" ? 27 : 22} strokeWidth={l === "Create" ? 4 : 2} aria-hidden="true" />
            <span>{l}</span>
          </button>
        ))}
      </nav>
      {creationOpen && <VideoCreation onClose={() => setCreationOpen(false)} />}
      {toast && (
        <div
          className={"toast " + toastKind}
          role={toastKind === "error" ? "alert" : "status"}
        >
          {toastKind === "error" ? (
            <AlertCircle size={18} />
          ) : (
            <Check size={18} />
          )}
          {toast}
        </div>
      )}
      {modal && (
        <div
          className="modal-backdrop"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setModal(null);
          }}
        >
          <section
            className={
              "modal modal--" +
              modal.type +
              " " +
              (modal.type === "live"
                ? "live-modal"
                : modal.type === "filters"
                  ? "filter-sheet"
                  : "")
            }
            role="dialog"
            aria-modal="true"
            aria-label={modal.type}
          >
            <button
              className="modal-close"
              aria-label="Close dialog"
              onClick={() => setModal(null)}
            >
              <X size={22} />
            </button>
            {modal.type === "notifications" ? (
              <Suspense fallback={<p className="muted" role="status">Loading notifications…</p>}><NotificationPanel items={data.notifications || []} busy={busy} markRead={() => act({action:"read-notifications"}, "Notifications marked as read")} /></Suspense>
            ) : modal.type === "filters" ? (
              <>
                <p className="eyebrow">FIND YOUR NEXT DISCOVERY</p>
                <h2>Search &amp; filters</h2>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setLocation(filterDraft.location.trim());
                    setLocationMode(filterDraft.mode);
                    setCategory(filterDraft.category);
                    setSort(filterDraft.sort);
                    setMinPrice(filterDraft.minPrice);
                    setMaxPrice(filterDraft.maxPrice);
                    setInStockOnly(filterDraft.inStockOnly);
                    setRadius(filterDraft.radius);
                    setDeviceLocation(filterDraft.deviceLocation);
                    setPage(1);
                    setModal(null);
                  }}
                >
                  <label className="field">
                    Match location
                    <select
                      value={filterDraft.mode}
                      onChange={(e) =>
                        setFilterDraft({ ...filterDraft, mode: e.target.value })
                      }
                    >
                      <option value="located">Seller located here</option>
                      <option value="delivers">Delivers here</option>
                    </select>
                  </label>
                  <label className="field">
                    Nigerian state, city or area
                    <input
                      value={filterDraft.location}
                      placeholder="Try Lagos or Lekki"
                      onChange={(e) =>
                        setFilterDraft({
                          ...filterDraft,
                          location: e.target.value,
                        })
                      }
                      list="filter-locations"
                    />
                  </label>
                  <datalist id="filter-locations">
                    {Array.from(
                      new Set(data.stores.map((s: any) => s.location)),
                    ).map((l: any) => (
                      <option key={l} value={l} />
                    ))}
                  </datalist>
                  <label className="field">
                    Category
                    <select
                      value={filterDraft.category}
                      onChange={(e) =>
                        setFilterDraft({
                          ...filterDraft,
                          category: e.target.value,
                        })
                      }
                    >
                      {categories.map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    Sort products
                    <select
                      value={filterDraft.sort}
                      onChange={(e) =>
                        setFilterDraft({ ...filterDraft, sort: e.target.value })
                      }
                    >
                    <option value="featured">Recommended</option>
                    <option value="newest">Newest</option>
                      <option value="low">Price: low to high</option>
                      <option value="high">Price: high to low</option>
                    <option value="rating">Highest rated</option>
                    </select>
                  </label>
                <div className="filter-price-range"><label className="field">Minimum price (₦)<input type="number" min="0" max="1000000000" inputMode="numeric" value={filterDraft.minPrice} onChange={(e) => setFilterDraft({ ...filterDraft, minPrice: e.target.value })} placeholder="0" /></label><label className="field">Maximum price (₦)<input type="number" min="0" max="1000000000" inputMode="numeric" value={filterDraft.maxPrice} onChange={(e) => setFilterDraft({ ...filterDraft, maxPrice: e.target.value })} placeholder="No limit" /></label></div>
                <label className="marketplace-availability-filter"><input type="checkbox" checked={filterDraft.inStockOnly} onChange={(e) => setFilterDraft({ ...filterDraft, inStockOnly: e.target.checked })}/>Show available products only</label>
                  <button
                    type="button"
                    className="secondary-button"
                    onClick={() => {
                      requestDeviceLocation();
                      setModal(null);
                    }}
                  >
                    Use device location
                  </button>
                  <p className="secondary">
                    Optional. Distance results include only sellers with
                    reliable public business coordinates.
                  </p>
                  {filterDraft.deviceLocation && (
                    <label className="field">
                      Distance
                      <select
                        value={filterDraft.radius}
                        onChange={(e) =>
                          setFilterDraft({
                            ...filterDraft,
                            radius: Number(e.target.value),
                          })
                        }
                      >
                        {[5, 10, 25, 50, 100].map((n) => (
                          <option key={n} value={n}>
                            {n} km
                          </option>
                        ))}
                      </select>
                    </label>
                  )}
                  <div className="filter-actions">
                    <button
                      type="button"
                      className="secondary-button"
                      onClick={() => {
                        setFilterDraft({
                          location: "",
                          mode: "delivers",
                          category: "All",
                          sort: "featured",
                          minPrice: "",
                          maxPrice: "",
                          inStockOnly: false,
                          radius: 25,
                          deviceLocation: null,
                        });
                      }}
                    >
                      Clear
                    </button>
                    <button type="submit" className="primary">
                      Apply filters
                    </button>
                  </div>
                </form>
              </>
            ) : modal.type === "cancelOrder" ? (
              <>
                <h2>Cancel this order?</h2>
                <p>
                  {modal.order.payment === "flutterwave"
                    ? "We’ll verify your debit card payment before cancelling. If the payment outcome is not confirmed, your order stays pending and stock remains reserved. A paid order requires a refund."
                    : "You can cancel before the seller confirms it. Reserved stock will be returned to the store."}
                </p>
                <Button
                  busy={busy}
                  className="primary full"
                  onClick={async () => {
                    if (
                      await act(
                        { action: "cancel", id: modal.order.id },
                        "Order cancelled",
                      )
                    )
                      setModal(null);
                  }}
                >
                  Cancel order
                </Button>
                <button
                  className="secondary-button full"
                  onClick={() => setModal(null)}
                >
                  Keep order
                </button>
              </>
            ) : modal.type === "storeForm" ? (
              <>
                <h2>{modal.store ? "Edit your store" : "Open your store"}</h2>
                <p>Make it easy for customers to get to know your business.</p>
                <form onSubmit={(e) => form(e, "store")}>
                  <Field
                    label="Business name"
                    name="name"
                    value={modal.store?.name}
                  />
                  <label className="field">
                    About your business
                    <textarea
                      name="description"
                      defaultValue={modal.store?.description}
                      maxLength={1000}
                    />
                  </label>
                  <div className="form-row">
                    <label className="field">
                      Category
                      <select
                        name="category"
                        defaultValue={modal.store?.category || "Fashion"}
                      >
                        {categories.slice(1).map((c) => (
                          <option key={c}>{c}</option>
                        ))}
                      </select>
                    </label>
                    <Field
                      label="City / location"
                      name="location"
                      value={modal.store?.location}
                      placeholder="Lekki, Lagos, Nigeria"
                    />
                  </div>
                  <Field
                    label="Customer contact phone"
                    name="phone"
                    type="tel"
                    value={modal.store?.phone}
                  />
                  <Button
                    busy={busy}
                    className="primary full"
                  >
                    {busy ? "Saving…" : "Save storefront"}
                  </Button>
                </form>
              </>
            ) : modal.type === "productForm" ? (
              <>
                <h2>{modal.p ? "Edit product" : "List a product"}</h2>
                {uploadProgress !== null && (
                  <p role="status">
                    {uploadProgress < 100
                      ? "Uploading: " + uploadProgress + "%"
                      : "Validating and storing media…"}
                  </p>
                )}
                <form
                  onSubmit={(e) =>
                    form(e, "product", modal.p ? { id: modal.p.id } : {})
                  }
                >
                  <Field
                    label="Product name"
                    name="name"
                    value={modal.p?.name}
                  />
                  <Field label="SKU (optional)" name="sku" value={modal.p?.sku} />
                  <label className="field">
                    Description
                    <textarea
                      name="description"
                      required
                      defaultValue={modal.p?.description}
                    />
                  </label>
                  <div className="form-row">
                    <Field
                      label="Price (₦)"
                      name="price"
                      type="number"
                      min="100"
                      value={modal.p?.price}
                    />
                    <Field
                      label="Available stock"
                      name="stock"
                      type="number"
                      min="0"
                      max="100000"
                      value={modal.p?.stock ?? 1}
                    />
                  </div>
                  <label className="field">
                    Category
                    <select
                      name="category"
                      defaultValue={modal.p?.category || "Fashion"}
                    >
                      {categories.slice(1).map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                  </label>
                  <p className="muted">Your store can list products across different categories.</p>
                  <fieldset className="product-options">
                    <legend>Product photo</legend>
                    <Suspense fallback={<p className="muted" role="status">Loading product tools…</p>}>
                      <ProductPhoto
                        initial={modal.p?.image || ""}
                        name="image"
                        showQuota
                        disabled={busy}
                        onBusy={(value) => {
                          operation.current = value;
                          setBusy(value);
                        }}
                      />
                    </Suspense>
                  </fieldset>
                  <Suspense fallback={<p className="muted" role="status">Loading product options…</p>}>
                    <ProductOptions
                      product={modal.p}
                      disabled={busy}
                      onBusy={(value) => {
                        operation.current = value;
                        setBusy(value);
                      }}
                    />
                  </Suspense>
                  <Field
                    label="Product video URL (optional)"
                    name="video"
                    required={false}
                    value={modal.p?.video}
                  />
                  <label className="upload-label">
                    Upload product video · up to 40 MB
                    <input
                      type="file"
                      accept="video/mp4,video/webm"
                      data-field="video"
                      onChange={upload}
                    />
                  </label>
                  <p className="muted">
                    Video uploads have a separate daily allowance of 20 files or 200 MB per seller. Up to 10 upload attempts per minute.
                  </p>
                  <Button
                    busy={busy}
                    className="primary full"
                  >
                    {busy ? "Saving…" : "Save product"}
                  </Button>
                </form>
              </>
            ) : modal.type === "product" ? (
              <>
                <ImageAsset
                  className="detail-image"
                  src={modal.p.image}
                  alt={modal.p.name}
                />
                <p className="eyebrow">
                  <StoreLogo name={modal.p.seller} src={modal.p.seller_logo} size={24} className="product-seller-logo" />{modal.p.seller} · {modal.p.category}
                </p>
                <h2>{modal.p.name}</h2>
                {Array.from(new Set<string>(JSON.parse(modal.p.images || "[]"))).filter((url) => url !== modal.p.image).map((url: string) => (
                  <ImageAsset
                    key={url}
                    src={url}
                    alt={modal.p.name}
                    className="detail-image"
                  />
                ))}
                {JSON.parse(modal.p.variants || "[]").length > 0 && (
                  <label className="field">
                    Variant
                    <select
                      value={variant}
                      onChange={(e) => setVariant(e.target.value)}
                    >
                      <option value="">Choose variant</option>
                      {JSON.parse(modal.p.variants).map((v: any) => (
                        <option key={v.name} value={v.name} disabled={!v.stock}>
                          {v.name} · {money(v.price)} · {v.stock} available
                        </option>
                      ))}
                    </select>
                  </label>
                )}
                <strong className="detail-price">
                  {money(
                    JSON.parse(modal.p.variants || "[]").find(
                      (v: any) => v.name === variant,
                    )?.price || modal.p.price,
                  )}
                </strong>
                <p>{modal.p.description}</p>
                <a href={"/product/" + modal.p.id}>Shareable product page</a>
                <p>
                  Delivery: {modal.p.delivery_days || "Confirm with seller"} ·{" "}
                  {deliveryFee(modal.p) === undefined
                    ? "Delivery fee confirmed at checkout"
                    : money(deliveryFee(modal.p)!)}
                </p>
                <details className="product-coverage">
                  <summary>Delivery coverage</summary>
                  <p>Delivers to:{" "}
                  {JSON.parse(
                    data.stores.find((s: any) => s.id === modal.p.store)
                      ?.coverage || "[]",
                  ).join(", ") || "Confirm coverage with seller"}</p>
                </details>
                <ReturnGuidance sellerTerms={modal.p.return_policy} />
                <button
                  className="secondary-button"
                  onClick={() =>
                    act(
                      {
                        action: "favourite",
                        product: modal.p.id,
                        saved: !data.favourites?.some(
                          (f: any) => f.product === modal.p.id,
                        ),
                      },
                      "Saved products updated",
                    )
                  }
                >
                  {data.favourites?.some((f: any) => f.product === modal.p.id)
                    ? "Remove from favourites"
                    : "Save product"}
                </button>
                <p className="secondary">
                  {modal.p.stock
                    ? `${modal.p.stock} available`
                    : "Out of stock"}{" "}
                  · Seller location: {modal.p.location}
                </p>
                {modal.p.video && (
                  <video
                    className="product-video"
                    controls
                    playsInline
                    src={modal.p.video}
                    poster={modal.p.image}
                    preload="none"
                  />
                )}
                <div className="product-purchase-actions">
                <Button
                  busy={busy}
                  disabled={
                    busy ||
                    !modal.p.stock ||
                    (JSON.parse(modal.p.variants || "[]").length > 0 &&
                      !JSON.parse(modal.p.variants || "[]").some(
                        (v: any) => v.name === variant && v.stock > 0,
                      ))
                  }
                  className="primary"
                  onClick={() => buyNow(modal.p, variant, 1)}
                >
                  Buy now
                </Button>
                <Button
                  busy={busy}
                  disabled={
                    busy ||
                    !modal.p.stock ||
                    (JSON.parse(modal.p.variants || "[]").length > 0 &&
                      !JSON.parse(modal.p.variants || "[]").some(
                        (v: any) => v.name === variant && v.stock > 0,
                      ))
                  }
                  className="secondary-button"
                  onClick={() => add(modal.p)}
                >
                  <ShoppingCart size={18} />
                  {modal.p.stock ? "Add to cart" : "Sold out"}
                </Button>
                </div>
                <div className="section-heading">
                  <h3>Customer reviews</h3>
                </div>
                {data.reviews
                  .filter((r: any) => r.product === modal.p.id)
                  .map((r: any) => (
                    <div className="review" key={r.id}>
                      <strong>
                        {r.name} · {"★".repeat(r.rating)}
                      </strong>
                      <p>{r.comment}</p>
                      <small>Verified purchase</small>
                    </div>
                  ))}
                {!data.reviews.some((r: any) => r.product === modal.p.id) && (
                  <p className="secondary">
                    No reviews yet. Reviews are available after delivery.
                  </p>
                )}
              </>
            ) : modal.type === "store" ? (
              <>
                <StoreLogo name={modal.store.name} src={modal.store.logo} size={53} />
                <h2 className="seller-identity"><span className="seller-name-text">{modal.store.name}</span></h2>
                <p>{modal.store.description}</p>
                <p>
                  <MapPin size={16} /> {modal.store.location} ·{" "}
                  {modal.store.category}
                </p>
                <div className="store-actions">
                  <Button
                    busy={busy}
                    className="secondary-button"
                    onClick={() =>
                      act(
                        {
                          action: "follow",
                          store: modal.store.id,
                          follow: !data.follows.some(
                            (f: any) => f.store === modal.store.id,
                          ),
                        },
                        "Follow preference updated",
                      )
                    }
                  >
                    <Heart size={17} />
                    {data.follows.some((f: any) => f.store === modal.store.id)
                      ? "Following"
                      : "Follow store"}
                  </Button>
                  <a
                    className="secondary-button"
                    href={"/messages?store=" + encodeURIComponent(modal.store.id)}
                  >
                    Chat with seller
                  </a>
                </div>
                <div className="product-grid mini">
                  <a
                    className="secondary-button"
                    href={"/store/" + modal.store.id}
                  >
                    View all products in this storefront
                  </a>
                </div>
              </>
            ) : modal.type === "cart" ? (
              <>
                {resumeReturnTo && (
                  <p>
                    <a href={resumeReturnTo}>
                      Return to your selected product or broadcast
                    </a>
                  </p>
                )}
                <header className="cart-dialog-heading">
                  <p className="eyebrow">YOUR BAG</p>
                  <h2>Your shopping bag <span>{data.cart.reduce((sum: number, item: any) => sum + item.quantity, 0)}</span></h2>
                  <p>Review your picks before heading to checkout.</p>
                </header>
                {data.cart.length ? (
                  <>
                    <div className="cart-items">
                      {data.cart.map((p: any) => (
                        <div className="cart-row" key={p.id}>
                          <ImageAsset src={p.image} alt={p.name} />
                          <div>
                            <strong>{p.name}</strong>
                            <small className="cart-seller"><StoreLogo name={p.seller} src={p.seller_logo} size={22} className="product-seller-logo" />{p.seller}</small>
                            <span>{money(p.price)}</span>
                          </div>
                          <button
                            className="cart-remove"
                            disabled={busy}
                            onClick={() =>
                              act(
                                { action: "cart", product: p.id, quantity: 0 },
                                "Item removed",
                              )
                            }
                            aria-label={"Remove " + p.name + " from cart"}
                          >
                            <X size={16} />
                          </button>
                          <div className="quantity">
                            <Button
                              busy={busy}
                              onClick={() =>
                                act(
                                  {
                                    action: "cart",
                                    product: p.id,
                                    variant: p.variant,
                                    quantity: p.quantity - 1,
                                  },
                                  "Cart updated",
                                )
                              }
                              aria-label={"Decrease quantity of " + p.name}
                            >
                              −
                            </Button>
                            <span>{p.quantity}</span>
                            <Button
                              busy={busy}
                              onClick={() =>
                                act(
                                  {
                                    action: "cart",
                                    product: p.id,
                                    variant: p.variant,
                                    quantity: p.quantity + 1,
                                  },
                                  "Cart updated",
                                )
                              }
                              aria-label={"Increase quantity of " + p.name}
                            >
                              +
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="cart-order-summary">
                    <div className="cart-total">
                      <span>Subtotal</span>
                      <strong>{money(cartTotal)}</strong>
                    </div>
                    <div className="cart-total">
                      <span>Shipping</span>
                      <strong>
                        {cartFee == null ? "Fee not set" : money(cartFee)}
                      </strong>
                    </div>
                    {cartShipping != null && (
                      <div className="cart-total cart-grand-total">
                        <span>Estimated total</span>
                        <strong>{money(cartTotal + cartShipping)}</strong>
                      </div>
                    )}
                    </div>
                    <p className="secondary">
                      Single-seller checkout. Delivery fees are calculated from
                      the seller’s saved settings. Online payments, when
                      available, run in{" "}
                      {data.payments?.mode === "live" ? "live" : "sandbox"}{" "}
                      mode.
                    </p>
                    <Button
                      busy={busy}
                      className="primary full"
                      onClick={() =>
                        setModal({ type: "checkout", key: clientId() })
                      }
                    >
                      Continue to checkout
                    </Button>
                  </>
                ) : (
                  <Empty
                    title="Your bag is empty"
                    text="Find something you love in the marketplace."
                    action={() => {
                      setModal(null);
                      nav("Market");
                    }}
                    label="Browse products"
                  />
                )}
              </>
            ) : modal.type === "checkout" ? (
              <>
                <p className="eyebrow">SINGLE-SELLER CHECKOUT</p>
                <h2>Where should it go?</h2>
                <form onSubmit={(e) => form(e, "checkout", {
                  key: modal.key,
                  ...(directCheckout
                    ? { product: directCheckout.product.id, variant: directCheckout.variant, quantity: directCheckout.quantity }
                    : {}),
                })}>
                  <Field
                    label="Recipient name"
                    name="name"
                    value={data.user?.name.split("@")[0]}
                  />
                  <Field label="Phone number" name="phone" type="tel" />
                  <label className="field">
                    Delivery state
                    <select name="delivery_state" required>
                      <option value="">Choose state</option>
                      {[
                        "Abia",
                        "Adamawa",
                        "Akwa Ibom",
                        "Anambra",
                        "Bauchi",
                        "Bayelsa",
                        "Benue",
                        "Borno",
                        "Cross River",
                        "Delta",
                        "Ebonyi",
                        "Edo",
                        "Ekiti",
                        "Enugu",
                        "FCT",
                        "Gombe",
                        "Imo",
                        "Jigawa",
                        "Kaduna",
                        "Kano",
                        "Katsina",
                        "Kebbi",
                        "Kogi",
                        "Kwara",
                        "Lagos",
                        "Nasarawa",
                        "Niger",
                        "Ogun",
                        "Ondo",
                        "Osun",
                        "Oyo",
                        "Plateau",
                        "Rivers",
                        "Sokoto",
                        "Taraba",
                        "Yobe",
                        "Zamfara",
                      ].map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    Payment
                    <select name="payment" disabled={!data.payments?.online}>
                      {!data.payments?.online && <option value="">Debit card payment unavailable</option>}
                      {data.payments.online && (
                        <option value="flutterwave">
                          Debit card payment
                          {data.payments?.mode === "live"
                            ? ""
                            : " · SANDBOX TEST"}
                        </option>
                      )}
                    </select>
                  </label>
                  {data.payments?.online && <div className="cnc-checkout-trust"><img {...trustBadgeImage("secure-checkout")} className="cnc-trust-badge"/><span>Payments are processed through the configured checkout provider.</span></div>}
                  <label className="field">
                    Full delivery address
                    <textarea
                      name="address"
                      required
                      placeholder="Street, area, city, state and postcode"
                    />
                  </label>
                  {directCheckout && (
                    <div className="cart-total">
                      <span>{directCheckout.product.name}{directCheckout.variant ? ` · ${directCheckout.variant}` : ""} · Qty {directCheckout.quantity}</span>
                      <strong>{money(checkoutProductTotal)}</strong>
                    </div>
                  )}
                  <div className="cart-total">
                    <span>Product total</span>
                    <strong>{money(checkoutProductTotal)}</strong>
                  </div>
                  <div className="cart-total">
                    <span>Total including delivery</span>
                    <strong>
                      {checkoutDeliveryFee === undefined ? "Delivery fee not set" : money(checkoutProductTotal + checkoutDeliveryFee)}
                    </strong>
                  </div>
                  <div className="notice">
                    Checkout supports one seller at a time. Delivery fee:{" "}
                    {checkoutDeliveryFee === undefined ? "Fee not set" : money(checkoutDeliveryFee)}
                    . {checkoutDelivery === undefined && "The seller must set delivery coverage before payment. "}Delivery coverage is checked by the server. Sandbox
                    payments do not charge real money.
                  </div>
                  <nav className="checkout-policy-links" aria-label="Checkout policies">
                    <span>By placing an order, you agree to the <a href="/terms" target="_blank" rel="noopener noreferrer">Terms</a>. See also <a href="/privacy" target="_blank" rel="noopener noreferrer">Privacy</a>, <a href="/delivery" target="_blank" rel="noopener noreferrer">Delivery</a> and <a href="/refunds" target="_blank" rel="noopener noreferrer">Returns and refunds</a>.</span>
                  </nav>
                  {checkoutError && (
                    <div className="error-banner" role="alert">
                      {checkoutError}
                    </div>
                  )}
                  <Button
                    busy={busy}
                    disabled={checkoutDelivery === undefined || !data.payments?.online}
                    className="primary full"
                  >
                    {busy
                      ? "Placing order…"
                      : "Place order · " +
                        (checkoutDelivery === undefined
                          ? "Seller must set delivery coverage"
                          : money(checkoutProductTotal + checkoutDelivery))}
                  </Button>
                </form>
              </>
            ) : modal.type === "live" ? (
              <Suspense fallback={<p className="muted" role="status">Connecting to livestream…</p>}>
                <LiveShopping
                  initial={modal.stream}
                  data={data}
                  act={act}
                  busy={busy}
                  onClose={() => setModal(null)}
                  availableStreams={homeFeedLiveStreams}
                />
              </Suspense>
            ) : modal.type === "campaign" ? (
              <>
                <h2>Submit a promotion for review</h2>
                <p>
                  Discovery placement: ₦1,000/day. Marketplace placement:
                  ₦2,000/day. Content is labelled Sponsored and runs only after
                  approval, payment and the scheduled start.
                </p>
                <form onSubmit={(e) => form(e, "campaign")}>
                  <Field label="Campaign name" name="title" />
                  <label className="field">
                    Promoted product
                    <select name="product" required>
                      <option value="">Choose product</option>
                      {mine.map((p: any) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    Placement
                    <select name="placement">
                      <option value="discovery">Discovery · ₦1,000/day</option>
                      <option value="market">Marketplace · ₦2,000/day</option>
                    </select>
                  </label>
                  <Field label="Starts" name="starts" type="datetime-local" />
                  <Field label="Ends" name="ends" type="datetime-local" />
                  <label className="field">
                    Goal
                    <select name="goal">
                      {[
                        "More sales",
                        "Website visits",
                        "WhatsApp enquiries",
                        "Followers",
                        "Live viewers",
                      ].map((g) => (
                        <option key={g}>{g}</option>
                      ))}
                    </select>
                  </label>
                  <Field
                    label="Target location"
                    name="location"
                    placeholder="Lagos"
                  />
                  <div className="form-row">
                    <Field
                      label="Daily budget (₦)"
                      name="budget"
                      type="number"
                      min="1000"
                    />
                    <Field
                      label="Duration (days)"
                      name="days"
                      type="number"
                      min="1"
                      max="90"
                      value="7"
                    />
                  </div>
                  <div className="notice">
                    Draft only. Your campaign will not run and no payment will
                    be taken.
                  </div>
                  <Button busy={busy} className="primary full">
                    Save draft
                  </Button>
                </form>
              </>
            ) : modal.type === "archive" ? (
              <>
                <h2>Archive {modal.p.name}?</h2>
                <p>
                  This removes the product from discovery and the market.
                  Existing orders remain available.
                </p>
                <Button
                  busy={busy}
                  className="primary"
                  onClick={async () => {
                    if (
                      await act(
                        { action: "archive", id: modal.p.id },
                        "Product archived",
                      )
                    )
                      setModal(null);
                  }}
                >
                  Archive product
                </Button>
              </>
            ) : modal.type === "review" ? (
              <>
                <h2>Review {modal.item.name}</h2>
                <form
                  onSubmit={(e) =>
                    form(e, "review", {
                      product: modal.item.product,
                      order: modal.order.id,
                    })
                  }
                >
                  <label className="field">
                    Rating
                    <select name="rating">
                      {[5, 4, 3, 2, 1].map((n) => (
                        <option key={n} value={n}>
                          {n} stars
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="field">
                    Your experience
                    <textarea name="comment" required maxLength={1000} />
                  </label>
                  <Button busy={busy} className="primary full">
                    Publish review
                  </Button>
                </form>
              </>
            ) : null}
          </section>
        </div>
      )}
    </div>
  );
}
