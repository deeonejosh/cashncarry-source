"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Heart, Share2, MessageSquare } from "lucide-react";
import {trackAnalyticsEvent} from "./analytics";
export default function StoreActions({
  id,
  following = false,
  shareUrl,
  ownerId,
  viewerId,
}: {
  id: string;
  following?: boolean;
  shareUrl?: string;
  ownerId?: string;
  viewerId?: string;
}) {
  const router = useRouter();
  const [followed, setFollowed] = useState(following),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  useEffect(()=>{trackAnalyticsEvent("store_view",id);},[id]);
  const publicUrl = new URL(shareUrl || "/store/" + id, typeof window === "undefined" ? "https://www.cashncarryng.com" : window.location.origin).href;
  async function follow() {
    setBusy(true);
    try {
      const r = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "follow",
          store: id,
          follow: !followed,
        }),
        signal: AbortSignal.timeout(15000),
      });
      if (r.status === 401) {
        router.push("/sign-in?returnTo=" + encodeURIComponent("/store/" + id));
        return;
      }
      const b = await r.json() as { error?: string };
      if (!r.ok) throw Error(b.error || "Unable to update follow preference");
      setFollowed(!followed);
      router.refresh();
      if(!followed)trackAnalyticsEvent("follow",id);
      setMessage(
        !followed ? "You are following this seller." : "Seller unfollowed.",
      );
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Please retry.");
    } finally {
      setBusy(false);
    }
  }
  async function share() {
    try {
      if (navigator.share) { await navigator.share({ title: "Shop " + id, url: publicUrl }); return; }
      await copyLink(publicUrl);
      setMessage("Store link copied.");
    } catch {
      try { await copyLink(publicUrl); setMessage("Store link copied."); }
      catch { setMessage("You can copy the store link from your address bar."); }
    }
  }
  async function copyLink(value: string) {
    if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(value); return; }
    const input = document.createElement("textarea");
    input.value = value; input.setAttribute("readonly", "");
    input.style.position = "fixed"; input.style.opacity = "0";
    document.body.append(input); input.select();
    const copied = document.execCommand("copy"); input.remove();
    if (!copied) throw Error("Clipboard unavailable");
  }
  return (
    <div className="store-follow-controls">
      {ownerId !== viewerId && <button
        className="primary"
        onClick={follow}
        aria-pressed={followed}
        disabled={busy}
      >
        <Heart size={18} />
        {busy ? "Saving…" : followed ? "Following" : "Follow seller"}
      </button>}
      {ownerId!==viewerId&&<a className="store-message-seller" href={`/messages?${new URLSearchParams({store:id})}`}><MessageSquare size={18}/>Message seller</a>}
      <button
        className="icon-control"
        onClick={share}
        aria-label="Share storefront"
      >
        <Share2 size={21} />
      </button>
      <a className="store-share-whatsapp" href={`https://wa.me/?text=${encodeURIComponent(publicUrl)}`} target="_blank" rel="noopener noreferrer">Share on WhatsApp</a>
      <a className="store-share-facebook" href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(publicUrl)}`} target="_blank" rel="noopener noreferrer">Share on Facebook</a>
      <p role="status">{message}</p>
    </div>
  );
}
