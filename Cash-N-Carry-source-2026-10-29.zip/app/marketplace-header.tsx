"use client";
import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Search, ShoppingCart, Menu, X, MapPin, Package, Heart, UserRound, MessageSquare } from "lucide-react";
import BrandLogo from "./brand-logo";

type CommerceSummary = { cart?: Array<{ quantity?: number }>; user?: unknown };
export default function MarketplaceHeader() {
  const router = useRouter();
  const [cartCount, setCartCount] = useState(0);
  const [cartHref, setCartHref] = useState("/?browse=1&open=cart#market");
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    let active = true;
    fetch("/api/commerce", { cache: "no-store", signal: AbortSignal.timeout(12000) })
      .then(async (response) => {
        const data = await response.json() as CommerceSummary;
        if (!response.ok) throw new Error("Cart unavailable");
        if (active) {
          setCartCount(Array.isArray(data.cart) ? data.cart.reduce((total, item) => total + Number(item.quantity || 0), 0) : 0);
          if (!data.user) setCartHref("/sign-in?returnTo=" + encodeURIComponent("/?browse=1&open=cart#market"));
        }
      }).catch(() => {});
    return () => { active = false; };
  }, []);
  const search = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const query = new FormData(event.currentTarget).get("q")?.toString().trim() || "";
    router.push("/?browse=1#market" + (query ? "?q=" + encodeURIComponent(query) : ""));
  };
  const links = [
    ["Orders", "/workspace?tab=Orders", Package],
    ["Wishlist", "/workspace?tab=Saved%20products", Heart],
    ["Messages", "/messages", MessageSquare],
    ["Profile", "/account", UserRound],
    ["Help & contact", "/help", MapPin],
  ] as const;
  return <>
    <header className="marketplace-product-header">
      <button type="button" className="marketplace-header-menu" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)}>{menuOpen ? <X size={21}/> : <Menu size={21}/>}</button>
      <BrandLogo compact className="marketplace-product-logo" />
      <form className="marketplace-product-search" role="search" onSubmit={search}><label className="sr-only" htmlFor="marketplace-product-query">Search products</label><input id="marketplace-product-query" name="q" placeholder="Search products, brands and more…" /><button type="submit" aria-label="Search"><Search size={19}/></button></form>
      <nav className="marketplace-product-quicklinks" aria-label="Account links"><Link href="/workspace?tab=Orders"><Package size={17}/>Orders</Link><Link href="/workspace?tab=Saved%20products"><Heart size={17}/>Wishlist</Link><Link href="/account"><UserRound size={17}/>Profile</Link></nav>
      <Link className="marketplace-product-cart" href={cartHref} aria-label={`Open cart${cartCount ? `, ${cartCount} items` : ""}`}><ShoppingCart size={21}/><span>Cart</span>{cartCount > 0 && <b>{cartCount > 99 ? "99+" : cartCount}</b>}</Link>
    </header>
    {menuOpen && <><button className="marketplace-menu-scrim" aria-label="Close navigation" onClick={() => setMenuOpen(false)}/><nav className="marketplace-mobile-drawer" aria-label="Marketplace navigation">
      <div className="marketplace-mobile-drawer-brand"><BrandLogo compact/><button type="button" aria-label="Close navigation" onClick={() => setMenuOpen(false)}><X size={20}/></button></div>
      {links.map(([label, href, Icon]) => <Link key={label} href={href} onClick={() => setMenuOpen(false)}><Icon size={19}/><span>{label}</span></Link>)}
    </nav></>}
    <nav className="marketplace-product-category-nav" aria-label="Marketplace categories"><Link href="/?browse=1#market">Shop</Link><Link href="/live">Live shopping</Link><Link href="/for-you">For You</Link><Link href="/start-selling">Sell on Cash N Carry</Link></nav>
    <div className="marketplace-product-location"><MapPin size={15} aria-hidden="true"/><span>Delivery options and fees are confirmed for your address at checkout.</span></div>
  </>;
}
