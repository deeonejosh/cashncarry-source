import Entry from "./welcome";
import { GET as commerce } from "./api/commerce/route";
import { catalog } from "./catalog";
import { headers } from "next/headers";
export const dynamic = "force-dynamic";
type PageProps = {
 searchParams: Promise<Record<string, string | string[] | undefined>>;
};
const supportedViews = new Set(["home", "market", "live", "explore", "seller", "orders"]);
export default async function Page({ searchParams }: PageProps) {
 const [params, requestHeaders] = await Promise.all([searchParams, headers()]);
 const requestedView = typeof params.view === "string" ? params.view.toLowerCase() : "";
 const userAgent = requestHeaders.get("user-agent") || "";
 const mobileClient = /Mobi|Android.*Mobile|iPhone|iPod|IEMobile|Windows Phone/i.test(userAgent);
 const initialView = params.sellerTab || params.startSelling === "1"
  ? "Seller"
  : supportedViews.has(requestedView)
   ? requestedView[0].toUpperCase() + requestedView.slice(1)
   : params.browse === "1" ? "Market" : mobileClient ? "Home" : "Market";
 const [response, catalogue] = await Promise.all([commerce(new Request("https://cashncarryng.com/api/commerce")), catalog(new URLSearchParams(),null).catch(()=>null)]);
 const data=response.ok ? await response.json() : null;
 return <Entry initialData={data} initialCatalogue={catalogue} initialView={initialView}/>;
}
