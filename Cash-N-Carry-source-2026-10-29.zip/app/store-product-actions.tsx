"use client";

import { preserveCartForSignIn } from "./cart-resume";
import { useState } from "react";
import { readableButtonText } from "./storefront-button-color";
import { ShoppingCart } from "lucide-react";

export default function StoreProductActions({
  product,
  storeId,
  signedIn,
  buyNowColor,
}: {
  product: { id: string; stock: number; variants: string | null };
  storeId: string;
  signedIn: boolean;
  buyNowColor: string;
}) {
  let variants: { name: string; stock: number; price?: number }[] = [];
  try {
    const parsed = JSON.parse(product.variants || "[]");
    if (Array.isArray(parsed)) variants = parsed.filter((item): item is { name: string; stock: number; price?: number } => item && typeof item.name === "string" && Number.isFinite(Number(item.stock)));
  } catch {
    variants = [];
  }
  const [variant, setVariant] = useState(
      variants.find((item) => item.stock > 0)?.name || "",
    ),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  const option = variants.find((item) => item.name === variant),
    stock = variants.length ? option?.stock || 0 : product.stock;
  const buttonColor = /^#[0-9a-f]{6}$/i.test(buyNowColor) ? buyNowColor : "#164B35";

  function buyNow() {
    if (!stock) return;
    if (!signedIn) {
      preserveCartForSignIn(product.id, variant, 1, "/store/" + storeId, "buy-now");
      return;
    }
    const params = new URLSearchParams({
      buyNow: product.id,
      quantity: "1",
      ...(variant ? { variant } : {}),
    });
    window.location.assign("/?" + params.toString());
  }

  async function addToCart() {
    if (!stock || busy) return;
    if (!signedIn) {
      preserveCartForSignIn(product.id, variant, 1, "/store/" + storeId);
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "cart",
          product: product.id,
          quantity: 1,
          variant,
        }),
        signal: AbortSignal.timeout(15000),
      });
      const result = await response.json() as { error?: string };
      if (response.status === 401) {
        preserveCartForSignIn(product.id, variant, 1, "/store/" + storeId);
        return;
      }
      if (!response.ok) throw Error(result.error || "Unable to add this item.");
      setMessage("Added to your cart.");
    } catch (error) {
      setMessage(
        error instanceof Error ? error.message : "Please check your connection and retry.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="storefront-product-actions">
      {variants.length > 0 && (
        <label>
          <span>Option</span>
          <select
            value={variant}
            onChange={(event) => setVariant(event.target.value)}
            aria-label="Choose a product option"
          >
            {variants.map((item) => (
              <option key={item.name} value={item.name} disabled={!item.stock}>
                {item.name}{!item.stock ? " — sold out" : ""}
              </option>
            ))}
          </select>
        </label>
      )}
      <div className="storefront-product-action-buttons">
        <button type="button" className="primary" style={{ backgroundColor: buttonColor, borderColor: buttonColor, color: readableButtonText(buttonColor) }} onClick={buyNow} disabled={!stock || busy}>
          Buy now
        </button>
        <button className="secondary-button storefront-product-cart-button" type="button" onClick={addToCart} disabled={!stock || busy} aria-label={busy ? "Adding to cart" : "Add to cart"} title={busy ? "Adding to cart" : "Add to cart"}>
          <ShoppingCart size={15} aria-hidden="true" /><span>{busy ? "Adding…" : "Add to cart"}</span>
        </button>
      </div>
      <p role="status" aria-live="polite">{message}</p>
    </div>
  );
}
