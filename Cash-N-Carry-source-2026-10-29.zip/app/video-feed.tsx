"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Bookmark, Heart, MessageCircle, Share2, Store, Volume2, VolumeX, ShoppingBag, Flag, Play, Pause, RefreshCw, Radio, EyeOff } from "lucide-react";
import ImageAsset from "./image-asset";
import StoreLogo from "./store-logo";
import { storefrontImageSrcSet, storefrontImageUrl } from "./storefront-image-url";
import { videoEventPayload } from "./video-event-analytics";

const money = (n: number) => new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(n || 0);
type Video = { id: string; store: string; store_slug?: string; seller: string; seller_logo?: string | null; verified: number; media: string; thumbnail: string; caption: string; hashtags: string[] | string; likes: number; comments: number; views: number; liked: number; saved: number; following: number; products: any[] };
const FEED_POSITION_KEY = "cnc-video-feed-position:v1";
const NOT_INTERESTED_KEY = "cnc-for-you-not-interested:v1";
type FeedPosition = { path: string; tab: string; scrollTop: number; savedAt: number };

function productHref(product: string) {
  const returnTo = window.location.pathname === "/for-you" ? "/for-you" : "/?browse=1#home";
  return "/product/" + encodeURIComponent(product) + "?returnTo=" + encodeURIComponent(returnTo);
}

async function event(video: string, kind: string) {
  try {
    const payload = videoEventPayload(video, kind, localStorage);
    if (!payload) return;
    await fetch("/api/videos", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), keepalive: true });
  } catch { /* analytics must never block shopping */ }
}

function VideoCard({ video, isActive, onActivate, onUpdate, onNotInterested, showNotInterested }: { video: Video; isActive: boolean; onActivate: (id: string) => void; onUpdate: (id: string, patch: any) => void; onNotInterested: (id: string) => void; showNotInterested: boolean }) {
  const videoRef = useRef<HTMLVideoElement>(null), viewTracked = useRef(false), completionTracked = useRef(false), skipTracked = useRef(false);
  const [muted, setMuted] = useState(true), [playing, setPlaying] = useState(false), [sourceRequested, setSourceRequested] = useState(false), [error, setError] = useState(false), [busy, setBusy] = useState(false), [followingBusy, setFollowingBusy] = useState(false), [commentsOpen, setCommentsOpen] = useState(false), [comments, setComments] = useState<any[]>([]), [commentsLoading, setCommentsLoading] = useState(false), [comment, setComment] = useState(""), [commentBusy, setCommentBusy] = useState(false), [commentMessage, setCommentMessage] = useState(""), [replyTo, setReplyTo] = useState(""), [message, setMessage] = useState("");
  useEffect(() => {
    const player = videoRef.current;
    if (!isActive) {
      if (player) {
        if (!skipTracked.current && !completionTracked.current && player.duration > 0 && player.currentTime >= 2 && player.currentTime / player.duration < 0.4) {
          skipTracked.current = true;
          void event(video.id, "watch_skip");
        }
        player.pause();
        if (player.currentSrc) {
          player.removeAttribute("src");
          player.load();
        }
      }
      setPlaying(false);
      setSourceRequested(false);
      completionTracked.current = false;
      return;
    }
    completionTracked.current = false;
    skipTracked.current = false;
    if (!viewTracked.current) {
      viewTracked.current = true;
      void event(video.id, "view");
    }
    setSourceRequested(true);
  }, [isActive, video.id]);
  useEffect(() => {
    const player = videoRef.current;
    if (!isActive || !sourceRequested || !player) return;
    player.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
  }, [isActive, sourceRequested]);
  const mutate = async (action: string, enabled: boolean) => {
    setBusy(true); setMessage("");
    try {
      const r = await fetch("/api/videos", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, id: video.id, enabled }) });
      const data: any = await r.json();
      if (r.status === 401) { window.location.assign("/sign-in?returnTo=" + encodeURIComponent("/for-you?v=" + video.id)); return; }
      if (!r.ok) throw Error(data.error || "Please retry.");
      onUpdate(video.id, action === "like" ? { liked: enabled ? 1 : 0, likes: Math.max(0, Number(video.likes) + (enabled ? 1 : -1)) } : { saved: enabled ? 1 : 0 });
    } catch (e: any) { setMessage(e.message); } finally { setBusy(false); }
  };
  const followSeller = async () => { if (followingBusy) return; setFollowingBusy(true); setMessage(""); try { const r = await fetch("/api/commerce", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "follow", store: video.store, follow: !video.following }) }); const d: any = await r.json(); if (r.status === 401) { window.location.assign("/sign-in?returnTo=" + encodeURIComponent(window.location.pathname + window.location.search)); return; } if (!r.ok) throw Error(d.error || "Unable to update your followed sellers."); onUpdate(video.id, { following: video.following ? 0 : 1 }); } catch (e: any) { setMessage(e.message || "Unable to update your followed sellers."); } finally { setFollowingBusy(false); } };
  const loadComments = async () => {
    const open = !commentsOpen; setCommentsOpen(open);
    if (open) {
      setCommentsLoading(true); setCommentMessage("");
      try { const r = await fetch("/api/videos?id=" + encodeURIComponent(video.id)); const d: any = await r.json(); if (!r.ok) throw Error(d.error || "Comments could not be loaded."); setComments(d.comments || []); }
      catch (e: any) { setCommentMessage(e.message || "Comments could not be loaded."); }
      finally { setCommentsLoading(false); }
    }
  };
  const submitComment = async (e: React.FormEvent) => {
    e.preventDefault(); if (!comment.trim() || commentBusy) return;
    setCommentBusy(true); setCommentMessage("");
    try {
      const r = await fetch("/api/videos", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "comment", video: video.id, body: comment, parent: replyTo }) });
      const d: any = await r.json();
      if (r.status === 401) { window.location.assign("/sign-in?returnTo=" + encodeURIComponent("/for-you?v=" + video.id)); return; }
      if (!r.ok) throw Error(d.error || "Unable to post comment.");
      setComment(""); setReplyTo("");
      const fresh = await fetch("/api/videos?id=" + encodeURIComponent(video.id));
      const freshData: any = await fresh.json();
      if (!fresh.ok) throw Error(freshData.error || "Your comment posted, but comments could not be refreshed.");
      setComments(freshData.comments || []);
      onUpdate(video.id, { comments: Number(freshData.videos?.[0]?.comments ?? Number(video.comments) + 1) });
    } catch (e: any) { setCommentMessage(e.message || "Unable to post comment."); }
    finally { setCommentBusy(false); }
  };
  const share = async () => { const url = new URL("/for-you?v=" + encodeURIComponent(video.id), window.location.origin).href; try { if (navigator.share) await navigator.share({ title: video.caption || video.seller + " product video", url }); else { await navigator.clipboard.writeText(url); setMessage("Video link copied."); } } catch { setMessage("Copy the video link from your browser address bar."); } };
  const report = async () => { const reason = window.prompt("Why are you reporting this video?"); if (!reason) return; try { const r = await fetch("/api/videos", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "report", video: video.id, reason }) }); const d: any = await r.json(); if (!r.ok) throw Error(d.error || "Unable to report video."); setMessage("Thanks. This video has been reported for review."); } catch (e: any) { setMessage(e.message); } };
  const togglePlayback = () => {
    const player = videoRef.current;
    if (!player) return;
    if (!isActive) {
      onActivate(video.id);
      setSourceRequested(true);
      return;
    }
    if (!sourceRequested) {
      setSourceRequested(true);
      return;
    }
    if (player.paused) {
      void player.play().then(() => setPlaying(true)).catch(() => setError(true));
    } else {
      player.pause();
    }
  };
  const addToCart = async (product: any) => { const variants = Array.isArray(product.variants) ? product.variants : (() => { try { return JSON.parse(product.variants || "[]"); } catch { return []; } })(); if (variants.length) { window.location.assign(productHref(product.id)); return; } try { const r = await fetch("/api/commerce", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "cart", product: product.id, quantity: 1 }) }); const d: any = await r.json(); if (!r.ok) throw Error(d.error || "Unable to add this product."); setMessage("Added to your bag. Open the bag to continue checkout."); void event(video.id, "add_to_cart"); } catch (e: any) { setMessage(e.message); } };
  const tags = Array.isArray(video.hashtags) ? video.hashtags : (() => { try { return JSON.parse(video.hashtags || "[]"); } catch { return []; } })();
  return <article className="video-feed-card" data-video-id={video.id} aria-label={`Video from ${video.seller}`}>
    <video ref={videoRef} className="video-feed-player" src={isActive && sourceRequested ? video.media : undefined} poster={video.thumbnail || undefined} autoPlay={isActive && sourceRequested} playsInline muted={muted} loop preload="none" aria-label={video.caption || `Product video from ${video.seller}`} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onTimeUpdate={(e) => { const player=e.currentTarget;if(!completionTracked.current&&Number.isFinite(player.duration)&&player.duration>0&&player.currentTime/player.duration>=0.9){completionTracked.current=true;void event(video.id,"watch_complete");} }} onError={() => setError(true)} />
    {error && <div className="video-error"><p>This video could not be loaded.</p><button type="button" onClick={() => { setError(false); setSourceRequested(true); const player = videoRef.current; player?.load(); if (player) void player.play().then(() => setPlaying(true)).catch(() => setPlaying(false)); }}><RefreshCw size={16}/> Retry</button></div>}
    {!error && <button className="video-play-prompt" type="button" aria-label={playing ? "Pause video" : "Play video"} title={playing ? "Pause video" : "Play video"} onClick={togglePlayback}>{playing ? <Pause fill="currentColor" size={25}/> : <Play fill="currentColor" size={32}/>}</button>}
    <button type="button" className="video-mute" aria-label={muted ? "Unmute video" : "Mute video"} onClick={() => { setMuted(!muted); if (videoRef.current) videoRef.current.muted = !muted; }}>{muted ? <VolumeX/> : <Volume2/>}</button>
    <div className="video-feed-shade" />
    <div className="video-feed-details">
      <div className="video-seller-line"><StoreLogo name={video.seller} src={video.seller_logo} size={34} className="video-avatar"/><a href={"/store/" + (video.store_slug || video.store)}>{video.seller}</a><button className="video-follow-button" type="button" aria-pressed={Boolean(video.following)} disabled={followingBusy} onClick={() => void followSeller()}>{followingBusy ? "Saving…" : video.following ? "Following" : "Follow"}</button><a className="video-store-link" href={"/store/" + (video.store_slug || video.store)} onClick={() => void event(video.id,"store_visit")}><Store size={15}/> Visit Store</a></div>
      <p>{video.caption}</p><div className="video-hashtags">{tags.map((tag: string) => <span key={tag}>#{tag}</span>)}</div>
      {!!video.products?.length && <div className="video-product-tags">{video.products.map((p: any) => <div className="video-product-card" key={p.id}><a href={productHref(p.id)} onClick={() => void event(video.id,"product_click")}><ImageAsset src={storefrontImageUrl(p.image,160)} srcSet={storefrontImageSrcSet(p.image,[160,256,320])} sizes="42px" alt="" width={42} height={42} loading="lazy" decoding="async" fetchPriority="low"/><span><strong>{p.name}</strong><small>{money(p.price)} · {p.stock > 0 ? "In stock" : "Out of stock"}</small></span></a><div><button type="button" disabled={!p.stock || busy} onClick={() => void addToCart(p)}><ShoppingBag size={15}/> {Array.isArray(p.variants) ? p.variants.length ? "Choose options" : "Add to bag" : (() => { try { return JSON.parse(p.variants || "[]").length ? "Choose options" : "Add to bag"; } catch { return "Add to bag"; } })()}</button><a href={productHref(p.id)} onClick={() => void event(video.id,"product_click")}>Shop now</a></div></div>)}</div>}
      {message && <p role="status" className="video-feedback">{message}</p>}
    </div>
    <aside className="video-social" aria-label="Video actions">
      <button type="button" aria-pressed={Boolean(video.liked)} aria-label={video.liked ? "Unlike video" : "Like video"} onClick={() => void mutate("like", !video.liked)}><Heart fill={video.liked ? "currentColor" : "none"}/><span>{Number(video.likes) || 0}</span></button>
      <button type="button" aria-expanded={commentsOpen} aria-label="Comments" onClick={() => void loadComments()}><MessageCircle/><span>{Number(video.comments) || 0}</span></button>
      <button type="button" aria-pressed={Boolean(video.saved)} aria-label={video.saved ? "Unsave video" : "Save video"} onClick={() => void mutate("save", !video.saved)}><Bookmark fill={video.saved ? "currentColor" : "none"}/></button>
      <button type="button" aria-label="Share video" onClick={() => void share()}><Share2/></button>
      <button type="button" aria-label="Report video" onClick={() => void report()}><Flag/></button>
      {showNotInterested && <button type="button" aria-label="Not interested in this video" title="Not interested" onClick={() => { void event(video.id,"not_interested"); onNotInterested(video.id); }}><EyeOff/><span className="video-not-interested-label">Not interested</span></button>}
    </aside>
    {commentsOpen && <section className="video-comments" aria-label="Video comments"><h3>Comments <span>({Number(video.comments) || 0})</span></h3>{commentMessage&&<p role="status">{commentMessage}</p>}<div className="video-comments-list" aria-live="polite">{commentsLoading ? <p role="status">Loading comments…</p> : comments.length ? comments.map((c) => <div className={c.parent ? "video-comment reply" : "video-comment"} key={c.id}><p><strong>@{c.username}</strong> {c.body}</p>{!c.parent&&<button type="button" onClick={()=>setReplyTo(c.id)}>Reply</button>}</div>) : !commentMessage&&<p>No comments yet. Start the conversation.</p>}</div>{replyTo&&<p className="video-reply-label">Replying to a comment <button type="button" onClick={()=>setReplyTo("")}>Cancel</button></p>}<form onSubmit={submitComment}><label className="sr-only" htmlFor={`comment-${video.id}`}>{replyTo?"Write a reply":"Write a comment"}</label><input id={`comment-${video.id}`} value={comment} onChange={(e) => setComment(e.target.value)} maxLength={500} placeholder={replyTo?"Write a reply":"Add a comment"} disabled={commentBusy}/><button type="submit" disabled={commentBusy||!comment.trim()}>{commentBusy?"Posting…":"Post"}</button></form></section>}
  </article>;
}

export function VideoFeed({
  initialVideo = "",
  liveStreams = [],
  products = [],
  onOpenLive,
  myStoreId,
}: {
  initialVideo?: string;
  liveStreams?: any[];
  products?: any[];
  onOpenLive?: (stream: any) => void;
  myStoreId?: string;
}) {
  const [tab, setTab] = useState("For You"), [ready, setReady] = useState(false), [videos, setVideos] = useState<Video[]>([]), [activeVideoId, setActiveVideoId] = useState(""), [pageVisible, setPageVisible] = useState(true), [loading, setLoading] = useState(true), [error, setError] = useState("");
  const [endingStreamId, setEndingStreamId] = useState(""), [endedStreamIds, setEndedStreamIds] = useState<string[]>([]), [liveMessage, setLiveMessage] = useState("");
  const listRef = useRef<HTMLDivElement>(null), restoreRef = useRef<FeedPosition | null>(null), restoreApplied = useRef(false), saveTimer = useRef<number | null>(null), tabRef = useRef(tab);
  const loadedDeepLink = useRef(false);
  const touchStart = useRef<{ x: number; y: number } | null>(null);
  useEffect(() => {
    try {
      const hidden = JSON.parse(localStorage.getItem(NOT_INTERESTED_KEY) || "[]");
      if (!Array.isArray(hidden)) localStorage.removeItem(NOT_INTERESTED_KEY);
      const requestedFeed = new URLSearchParams(window.location.search).get("feed");
      if (requestedFeed === "following") { setTab("Following"); setReady(true); return; }
      const saved = JSON.parse(sessionStorage.getItem(FEED_POSITION_KEY) || "null") as FeedPosition | null;
      if (saved && saved.path === window.location.pathname && Date.now() - saved.savedAt < 60 * 60 * 1000) {
        restoreRef.current = saved;
        setTab(["Following", "Live broadcasts"].includes(saved.tab) ? saved.tab : "For You");
      }
    } catch { /* The feed starts at the top if session storage is unavailable. */ }
    setReady(true);
  }, []);
  const savePosition = useCallback((nextTab: string, top = listRef.current?.scrollTop || 0) => {
    try { sessionStorage.setItem(FEED_POSITION_KEY, JSON.stringify({ path: window.location.pathname, tab: nextTab, scrollTop: top, savedAt: Date.now() } satisfies FeedPosition)); } catch { /* Feed navigation remains usable without storage. */ }
  }, []);
  const load = useCallback(async (nextTab: string) => { setLoading(true); setError(""); try { const url = new URL("/api/videos", window.location.origin); url.searchParams.set("limit", "24"); if (nextTab === "Following") url.searchParams.set("following", "1"); if (initialVideo && !loadedDeepLink.current && nextTab === "For You") { url.searchParams.set("id", initialVideo); loadedDeepLink.current = true; } const r = await fetch(url, { signal: AbortSignal.timeout(15000) }); const d: any = await r.json(); if (!r.ok) throw Error(d.error || "Unable to load videos."); const unique = new Map<string, Video>(); for (const item of Array.isArray(d.videos) ? d.videos : []) if (item?.id && !unique.has(String(item.id))) unique.set(String(item.id), item); let hidden = new Set<string>(); try { const saved = JSON.parse(localStorage.getItem(NOT_INTERESTED_KEY) || "[]"); if (Array.isArray(saved)) hidden = new Set(saved.filter((id): id is string => typeof id === "string")); } catch { /* Ignore unavailable local storage. */ } setVideos([...unique.values()].filter((video) => nextTab !== "For You" || !hidden.has(video.id))); } catch (e: any) { setError(e?.name === "TimeoutError" || e?.name === "AbortError" ? "Videos are taking longer than expected. Please retry." : e?.message || "Unable to load videos. Please retry."); } finally { setLoading(false); } }, [initialVideo]);
  useEffect(() => {
    if (!ready) return;
    if (tab === "Live broadcasts") { setLoading(false); setError(""); return; }
    void load(tab);
  }, [load, tab, ready]);
  useEffect(() => {
    const saved = restoreRef.current;
    const node = listRef.current;
    if (!ready || loading || !saved || !node || restoreApplied.current) return;
    restoreApplied.current = true;
    requestAnimationFrame(() => {
      if (listRef.current) listRef.current.scrollTop = saved.scrollTop;
      try { sessionStorage.removeItem(FEED_POSITION_KEY); } catch { /* Ignore unavailable storage. */ }
    });
  }, [loading, ready, videos]);
  useEffect(() => { tabRef.current = tab; }, [tab]);
  useEffect(() => {
    const syncVisibility = () => setPageVisible(document.visibilityState === "visible");
    syncVisibility();
    document.addEventListener("visibilitychange", syncVisibility);
    return () => document.removeEventListener("visibilitychange", syncVisibility);
  }, []);
  useEffect(() => {
    const root = listRef.current;
    if (!ready || loading || tab === "Live broadcasts" || !root) {
      setActiveVideoId("");
      return;
    }
    const visibility = new Map<string, number>();
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        const id = (entry.target as HTMLElement).dataset.videoId;
        if (id) visibility.set(id, entry.isIntersecting ? entry.intersectionRatio : 0);
      }
      let nextId = "", maxRatio = 0;
      for (const [id, ratio] of visibility) {
        if (ratio > maxRatio) { nextId = id; maxRatio = ratio; }
      }
      setActiveVideoId(maxRatio >= 0.65 ? nextId : "");
    }, { root, threshold: [0, .25, .5, .65, .85, 1] });
    root.querySelectorAll<HTMLElement>("[data-video-id]").forEach((card) => observer.observe(card));
    return () => observer.disconnect();
  }, [ready, loading, tab, videos]);
  useEffect(() => () => {
    if (saveTimer.current !== null) window.clearTimeout(saveTimer.current);
    savePosition(tabRef.current);
  }, []);
  const onScroll = () => {
    if (saveTimer.current !== null) window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(() => savePosition(tabRef.current), 120);
  };
  const changeTab = (next: string) => {
    if (next === tab) return;
    savePosition(next, 0);
    if (listRef.current) listRef.current.scrollTop = 0;
    restoreApplied.current = true;
    setTab(next);
  };
  const swipeMode = (direction: "left" | "right") => {
    const modes = ["For You", "Following", "Live broadcasts"];
    const current = Math.max(0, modes.indexOf(tab));
    const next = current + (direction === "left" ? 1 : -1);
    if (next >= 0 && next < modes.length) changeTab(modes[next]);
  };
  const update = (id: string, patch: any) => setVideos((list) => list.map((v) => v.id === id ? { ...v, ...patch } : v));
  const markNotInterested = (id: string) => {
    try {
      const prior = JSON.parse(localStorage.getItem(NOT_INTERESTED_KEY) || "[]");
      const hidden = new Set<string>(Array.isArray(prior) ? prior.filter((value): value is string => typeof value === "string") : []);
      hidden.add(id);
      localStorage.setItem(NOT_INTERESTED_KEY, JSON.stringify([...hidden].slice(-200)));
    } catch { /* The current feed can still hide this video for this visit. */ }
    setVideos((list) => list.filter((video) => video.id !== id));
  };
  const refreshFeed = () => {
    try { localStorage.removeItem(NOT_INTERESTED_KEY); } catch { /* Refresh the current list even if storage is unavailable. */ }
    if (listRef.current) listRef.current.scrollTop = 0;
    loadedDeepLink.current = true;
    void load("For You");
  };
  const endBroadcast = async (stream: any) => {
    if (endingStreamId || !myStoreId || stream.store !== myStoreId) return;
    if (!window.confirm(`End “${stream.title || "your live broadcast"}” now? Viewers will be disconnected.`)) return;
    setEndingStreamId(stream.id);
    setLiveMessage("");
    try {
      const response = await fetch("/api/streams", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "end", id: stream.id }),
        signal: AbortSignal.timeout(45000),
      });
      const result: any = await response.json().catch(() => ({}));
      if (response.status === 401) {
        window.location.assign("/sign-in?returnTo=" + encodeURIComponent(window.location.pathname + window.location.search));
        return;
      }
      if (!response.ok) throw Error(result.error || "We could not confirm the broadcast ended. Retry End Live.");
      setEndedStreamIds((ids) => ids.includes(stream.id) ? ids : [...ids, stream.id]);
      setLiveMessage("Your broadcast has ended. Viewers have been disconnected.");
    } catch (e: any) {
      setLiveMessage(e?.name === "TimeoutError" ? "The end request timed out. Check the broadcast status and retry if it is still live." : e.message || "We could not confirm the broadcast ended. Retry End Live.");
    } finally {
      setEndingStreamId("");
    }
  };
  const currentLive = liveStreams.filter((stream) => ["live", "external"].includes(stream.status) && !endedStreamIds.includes(stream.id));
  return <section className="for-you-feed" aria-label="Video and live broadcast feed" onTouchStart={(e) => { const touch = e.touches[0]; touchStart.current = { x: touch.clientX, y: touch.clientY }; }} onTouchEnd={(e) => { const start = touchStart.current, touch = e.changedTouches[0]; touchStart.current = null; if (!start || !touch) return; const dx = touch.clientX - start.x, dy = touch.clientY - start.y; if (Math.abs(dx) > 64 && Math.abs(dx) > Math.abs(dy) * 1.25) swipeMode(dx < 0 ? "left" : "right"); }}>
    <div className="for-you-feed-controls"><div className="for-you-feed-tabs" role="tablist" aria-label="Choose feed"><button role="tab" aria-selected={tab === "For You"} className={tab === "For You" ? "selected" : ""} onClick={() => changeTab("For You")}>For You</button><button role="tab" aria-selected={tab === "Following"} className={tab === "Following" ? "selected" : ""} onClick={() => changeTab("Following")}>Following</button><button role="tab" aria-selected={tab === "Live broadcasts"} className={tab === "Live broadcasts" ? "selected" : ""} onClick={() => changeTab("Live broadcasts")}>Watch Live</button></div>{tab === "For You" && <button type="button" className="for-you-refresh" onClick={refreshFeed}><RefreshCw size={15}/> Refresh feed</button>}</div>
    {liveMessage && <p className="live-feed-feedback" role="status">{liveMessage}</p>}
    {tab === "Live broadcasts" ? currentLive.length ? <div className="video-feed-list live-feed-list" aria-label="Live broadcasts"><div className="video-feed-cards">{currentLive.map((stream) => { const product = products.find((item) => item.id === stream.product), ownBroadcast = Boolean(myStoreId && stream.store === myStoreId), backgroundImage = product?.image ? `linear-gradient(180deg, transparent 35%, #000b), url("${product.image}")` : "linear-gradient(180deg, #21392d, #070b09)"; return <article className="live-feed-card" key={stream.id} style={{ backgroundImage }}><button type="button" className="live-feed-watch" onClick={() => onOpenLive?.(stream)} aria-label={`Watch live: ${stream.title} from ${stream.seller}`}/><span className="live-feed-badge"><i aria-hidden="true"/>LIVE</span><span className="live-feed-play" aria-hidden="true"><Play fill="currentColor" size={30}/></span><div className="live-feed-caption"><strong className="live-feed-seller"><StoreLogo name={stream.seller} src={stream.seller_logo} size={34} className="live-feed-seller-logo"/>{stream.seller}</strong><b>{stream.title || "Live now"}</b><small>Tap to watch broadcast</small>{ownBroadcast && <button type="button" className="live-feed-end" disabled={Boolean(endingStreamId)} onClick={() => void endBroadcast(stream)}>{endingStreamId === stream.id ? "Ending broadcast…" : "End Live"}</button>}</div></article>; })}</div></div> : <div className="video-empty live-feed-empty"><Radio size={30}/><h2>No live broadcasts right now</h2><p>Swipe to videos or check back when a seller goes live.</p></div>
      : loading ? <p className="video-empty" role="status">Loading videos…</p> : error ? <div className="video-empty" role="alert"><p>{error}</p>{error.toLowerCase().includes("sign in")&&<a className="secondary-button" href="/sign-in?returnTo=%2Ffor-you">Sign in to see Following</a>}<button type="button" onClick={() => void load(tab)}>Retry</button></div> : videos.length ? <div ref={listRef} className="video-feed-list" tabIndex={0} aria-label="Swipe vertically through product videos" onScroll={onScroll} onKeyDown={(e) => { if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); const cards = Array.from(e.currentTarget.querySelectorAll<HTMLElement>(".video-feed-card")); const step = cards[0]?.offsetHeight || 600; const current = Math.round(e.currentTarget.scrollTop / step); const next = Math.max(0,Math.min(cards.length - 1,current + (e.key === "ArrowDown" ? 1 : -1))); e.currentTarget.scrollTo({ top: next * step, behavior: "smooth" }); } }}><div className="video-feed-cards">{videos.map((v) => <VideoCard key={v.id} video={v} isActive={pageVisible && activeVideoId === v.id} onActivate={setActiveVideoId} onUpdate={update} onNotInterested={markNotInterested} showNotInterested={tab === "For You"}/>)}</div></div> : <div className="video-empty"><h2>{tab === "Following" ? "Follow sellers to fill your feed" : "Videos are coming soon"}</h2><p>{tab === "Following" ? "Follow a seller storefront and their approved product videos will appear here." : "Seller videos appear here after they pass review."}</p>{tab === "For You" && <button type="button" onClick={refreshFeed}>Refresh recommendations</button>}</div>}
  </section>;
}

export function LazyProductVideo({ src, poster, label }: { src: string; poster?: string; label: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [nearViewport, setNearViewport] = useState(false);
  useEffect(() => {
    const player = videoRef.current;
    if (!player) return;
    if (!("IntersectionObserver" in window)) { setNearViewport(true); return; }
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        setNearViewport(true);
        observer.disconnect();
      }
    }, { rootMargin: "200px 0px", threshold: 0 });
    observer.observe(player);
    return () => observer.disconnect();
  }, []);
  return <video ref={videoRef} src={nearViewport ? src : undefined} poster={poster} controls playsInline preload="none" aria-label={label} />;
}
