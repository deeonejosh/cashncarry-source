const LIVE_STATUSES = new Set(["live", "external"]);

export function liveStreamCandidates(streams) {
  if (!Array.isArray(streams)) return [];
  const seen = new Set();
  return streams
    .filter((stream) => {
      if (!stream?.id || !LIVE_STATUSES.has(stream.status) || seen.has(stream.id)) return false;
      seen.add(stream.id);
      return true;
    })
    .sort((a, b) => Date.parse(b.created || 0) - Date.parse(a.created || 0));
}

// A positive direction means swipe up/next; negative means swipe down/previous.
export function adjacentLiveStream(streams, currentId, direction) {
  const candidates = liveStreamCandidates(streams);
  if (candidates.length < 2) return null;
  const currentIndex = candidates.findIndex((stream) => stream.id === currentId);
  if (currentIndex < 0) return direction > 0 ? candidates[0] : candidates.at(-1);
  const step = direction > 0 ? 1 : -1;
  return candidates[(currentIndex + step + candidates.length) % candidates.length];
}
