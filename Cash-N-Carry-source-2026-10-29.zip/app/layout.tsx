import SkipLink from "./skip-link";
import AnalyticsConsent from "./analytics-consent";
import { brand } from "./brand";
import type { Metadata } from "next";
import "./globals.css";
import "./design-system.css";
import "./premium.css";
import "./shop-redesign.css";

const publicSiteUrl = "https://www.cashncarryng.com";

export const metadata: Metadata = {
  metadataBase: new URL(publicSiteUrl),
  alternates: { canonical: "/" },
  title: `${brand.name} — Live Shopping & Online Marketplace Nigeria`,
  description: brand.description,
  manifest: "/api/manifest",
  applicationName: brand.name,
  appleWebApp: { title: brand.name },
  openGraph: {
    title: `${brand.name} — Live Shopping & Online Marketplace Nigeria`,
    siteName: brand.name,
    description: brand.description,
    type: "website",
    url: "/",
    images: [
      {
        url: "/seller-hero.webp",
        width: 1050,
        height: 700,
        alt: "A Nigerian seller presenting a handbag in her shop",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: `${brand.name} — Live Shopping & Online Marketplace Nigeria`,
    description: brand.description,
    images: ["/seller-hero.webp"],
  },
  icons: {
    icon: [
      { url: "/favicon.svg?v=2", type: "image/svg+xml" },
      { url: "/brand/cash-n-carry-icon-v2-32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon.ico?v=2", sizes: "16x16 32x32 48x48" },
    ],
    shortcut: "/favicon.ico?v=2",
    apple: "/brand/cash-n-carry-icon-v2-180.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="sitemap" type="application/xml" href="/sitemap.xml" />
        <script
          dangerouslySetInnerHTML={{
            __html: `try{var choice=localStorage.getItem("cnc:analytics-consent:v1");if(choice==="accepted"||choice==="rejected")document.documentElement.dataset.analyticsConsent=choice;}catch{}`,
          }}
        />
      </head>
      <body className="antialiased">
        <SkipLink />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@graph": [
                {"@type":"Organization","@id":new URL("/#organization",publicSiteUrl).href,name:brand.name,url:publicSiteUrl,description:brand.description,logo:new URL(brand.logo,publicSiteUrl).href,areaServed:{"@type":"Country",name:"Nigeria"},contactPoint:{"@type":"ContactPoint",contactType:"customer support",url:new URL("/help",publicSiteUrl).href,availableLanguage:"English"}},
                {"@type":"WebSite","@id":new URL("/#website",publicSiteUrl).href,name:brand.name,description:brand.description,url:publicSiteUrl,inLanguage:"en",publisher:{"@id":new URL("/#organization",publicSiteUrl).href}}
              ],
            }).replace(/</g, "\\u003c"),
          }}
        />
        <AnalyticsConsent />
        {children}
      </body>
    </html>
  );
}
