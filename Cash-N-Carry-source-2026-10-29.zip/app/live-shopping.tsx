"use client";
import { trustBadgeImage } from "./trust-badge-image";
import { liveProductSelection } from "./live-product-selection";
import { startLiveFeaturePolling } from "./live-feature-polling";
import { useEffect, useRef, useState } from "react";
import { adjacentLiveStream, liveStreamCandidates } from "./live-stream-navigation.mjs";
import {
  Heart,
  ShoppingBag,
  ShoppingCart,
  Share2,
  MessageCircle,
  CheckCircle2,
  Flag,
  X,
  Send,
  MoreHorizontal,
  Maximize,
  ChevronDown,
  ChevronUp,
  Zap,
  Radio,
  Play,
} from "lucide-react";
import { LiveAction, LiveSheet } from "./live-overlay";
import { broadcastLabel } from "./broadcasts";
import { deliveryQuote, deliveryFee } from "./delivery-quote";
import WebRTCVideo from "./webrtc-video";
import ScheduleInfo from "./schedule-info";
import LiveVideo from "./live-video";
import ImageAsset from "./image-asset";
import StoreLogo from "./store-logo";
const initialClock = Date.now();
const trackAnalyticsEvent=(event:string,store:string,details:{product?:string;stream?:string}={})=>{if(typeof window==="undefined"||!store)return;try{if(window.localStorage.getItem("cnc:analytics-consent:v1")!=="accepted")return;let visitor=window.localStorage.getItem("cnc:analytics-visitor:v1");if(!visitor){visitor=crypto.randomUUID();window.localStorage.setItem("cnc:analytics-visitor:v1",visitor);}void fetch("/api/seller-analytics",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({event,store,visitorId:visitor,...details}),keepalive:true}).catch(()=>{});}catch{/* Analytics must not block livestream shopping. */}};
const money = (n: number) =>
  new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(n);
export default function LiveShopping({
  initial,
  data,
  act,
  busy,
  onClose,
  availableStreams = [],
}: any) {
  const [stream, setStream] = useState(initial),
    [products, setProducts] = useState<any[]>([]),
    [chats, setChats] = useState<any[]>([]);
  const [viewers, setViewers] = useState<number | null>(null),
    [offline, setOffline] = useState(false),
    [sheet, setSheet] = useState("");
  const [selected, setSelected] = useState(""),
    [options, setOptions] = useState<Record<string, string>>({}),
    [quantities, setQuantities] = useState<Record<string, number>>({});
  const [message, setMessage] = useState(""),
    [feedback, setFeedback] = useState(""),
    [liked, setLiked] = useState(false),
    [checkoutKey, setCheckoutKey] = useState("");
  const [replayPlaying, setReplayPlaying] = useState(false);
  const [fullscreenAvailable, setFullscreenAvailable] = useState(false);
  const [likes, setLikes] = useState<number | null>(null);
  const [reacting, setReacting] = useState(false);
  const [heartBurst, setHeartBurst] = useState(0);
  const [reportReason, setReportReason] = useState("");
  const [directPurchase, setDirectPurchase] = useState<any>(null);
  const [deals, setDeals] = useState<any[]>([]);
  const [pinnedDealId,setPinnedDealId]=useState("");
  const [bundles, setBundles] = useState<any[]>([]);
  const [pinnedBundleId,setPinnedBundleId]=useState("");
  const [pinnedBundleEndsAt,setPinnedBundleEndsAt]=useState("");
  const [clock, setClock] = useState(initialClock);
  const [auctions, setAuctions] = useState<any[]>([]);
  const [pinnedAuctionId,setPinnedAuctionId]=useState("");
  const [auctionBusy, setAuctionBusy] = useState("");
  const [auctionFeedback, setAuctionFeedback] = useState("");
  const [pinCollapsed, setPinCollapsed] = useState(false);
  const [streamList, setStreamList] = useState<any[]>(liveStreamCandidates([...availableStreams, initial]));
  const [nextStream, setNextStream] = useState<any>(null);
  const [endCountdown, setEndCountdown] = useState(5);
  const [autoAdvancePaused, setAutoAdvancePaused] = useState(false);
  const [endedBackdrop, setEndedBackdrop] = useState("");
  const viewportRef = useRef<HTMLDivElement>(null);
  const touchOrigin = useRef<{x:number;y:number}|null>(null);
  const chatMessagesRef = useRef<HTMLDivElement>(null);
  const chatStickToBottom = useRef(true);
  const seenStreams = useRef(new Set<string>([initial.id]));
  const originalLocation = useRef("");
  const streamListRef = useRef(streamList);
  const endedFrameStream = useRef("");
  const auctionBidRequestIds = useRef<Record<string, string>>({});
  const auctionFeedbackKey = useRef<{ auctionId: string; snapshot: string } | null>(null);
  const auctionSettling = useRef(new Set<string>());
  useEffect(() => {
    const messages = chatMessagesRef.current;
    if (messages && chatStickToBottom.current) messages.scrollTop = messages.scrollHeight;
  }, [stream.id, chats]);
  useEffect(() => {
    const next = liveStreamCandidates([...availableStreams, stream]);
    streamListRef.current = next;
    setStreamList(next);
  }, [availableStreams, stream]);
  async function refreshLiveStreams() {
    try {
      const response = await fetch("/api/commerce", { cache: "no-store", signal: AbortSignal.timeout(10000) });
      if (!response.ok) throw Error();
      const payload = await response.json() as any;
      const fresh = liveStreamCandidates(payload.streams);
      streamListRef.current = fresh;
      setStreamList(fresh);
      return fresh;
    } catch {
      return liveStreamCandidates(streamListRef.current);
    }
  }
  function switchStream(target:any) {
    if (!target?.id || target.id === stream.id) return;
    seenStreams.current.add(stream.id);
    seenStreams.current.add(target.id);
    setStream(target);
    setProducts([]); setChats([]); setViewers(null); setLikes(null); setLiked(false);
    setOffline(false); setFeedback(""); setSheet(""); setReplayPlaying(false);
    setNextStream(null); setAutoAdvancePaused(false); setEndCountdown(5);
    setEndedBackdrop(""); endedFrameStream.current = "";
    setSelected(""); setPinCollapsed(false); setDeals([]); setAuctions([]); setPinnedAuctionId("");
    setBundles([]);
  }
  async function moveToAdjacentStream(direction:number) {
    if (sheet) return;
    if (stream.status === "ended" && direction > 0 && nextStream) { switchStream(nextStream); return; }
    let target = adjacentLiveStream(streamListRef.current, stream.id, direction);
    if (!target) {
      const fresh = await refreshLiveStreams();
      target = adjacentLiveStream(fresh, stream.id, direction);
    }
    if (target) switchStream(target);
    else setFeedback("No other sellers are live right now.");
  }
  function switchToNextStream() {
    if (nextStream) switchStream(nextStream);
  }
  function captureEndedFrame() {
    const video=viewportRef.current?.querySelector("video");
    if(!video || !video.videoWidth || !video.videoHeight)return "";
    try {const canvas=document.createElement("canvas");canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext("2d")?.drawImage(video,0,0);return canvas.toDataURL("image/jpeg",0.82);} catch {return "";}
  }
  function onTouchStart(event:React.TouchEvent<HTMLDivElement>) {
    if (sheet || event.touches.length !== 1) { touchOrigin.current = null; return; }
    const target = event.target as HTMLElement;
    if (target.closest("button,a,input,textarea,select,[role='dialog'],.live-lower,.live-viewer-tools")) { touchOrigin.current = null; return; }
    touchOrigin.current = { x:event.touches[0].clientX, y:event.touches[0].clientY };
  }
  function onTouchEnd(event:React.TouchEvent<HTMLDivElement>) {
    const origin = touchOrigin.current;
    touchOrigin.current = null;
    if (!origin || sheet || event.changedTouches.length !== 1) return;
    const dx = event.changedTouches[0].clientX - origin.x;
    const dy = event.changedTouches[0].clientY - origin.y;
    if (Math.abs(dy) < 56 || Math.abs(dy) < Math.abs(dx) * 1.25) return;
    void moveToAdjacentStream(dy < 0 ? 1 : -1);
  }
  useEffect(() => {
    const stage = viewportRef.current;
    const header = stage?.querySelector<HTMLElement>(".live-top");
    const dock = stage?.querySelector<HTMLElement>(".live-lower");
    const fit = () => {
      if (header) stage?.style.setProperty("--live-header-height", `${Math.ceil(header.getBoundingClientRect().height)}px`);
      if (dock) stage?.style.setProperty("--live-dock-height", `${Math.ceil(dock.getBoundingClientRect().height) + 8}px`);
    };
    fit();
    const observer = typeof ResizeObserver !== "undefined" ? new ResizeObserver(fit) : null;
    if (header) observer?.observe(header);
    if (dock) observer?.observe(dock);
    return () => observer?.disconnect();
  }, [sheet, pinCollapsed, products.length]);
  useEffect(() => {
    setFullscreenAvailable(Boolean(document.fullscreenEnabled));
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const viewport = window.visualViewport;
    const resize = () => {
      if (viewportRef.current)
        viewportRef.current.dataset.compact = String(
          (viewport?.height || window.innerHeight) < 520,
        );
      viewportRef.current?.style.setProperty(
        "--visible-viewport",
        `${Math.round(viewport?.height || window.innerHeight)}px`,
      );
      viewportRef.current?.style.setProperty(
        "--visible-viewport-top",
        `${viewport?.offsetTop || 0}px`,
      );
    };
    resize();
    viewport?.addEventListener("resize", resize);
    viewport?.addEventListener("scroll", resize);
    window.addEventListener("resize", resize);
    return () => {
      document.body.style.overflow = previousOverflow;
      viewport?.removeEventListener("resize", resize);
      viewport?.removeEventListener("scroll", resize);
      window.removeEventListener("resize", resize);
    };
  }, []);
  useEffect(() => {
    if (!originalLocation.current) originalLocation.current = location.pathname + location.search + location.hash;
    const url = new URL(location.href);
    url.searchParams.set("stream", stream.id);
    history.replaceState(
      history.state,
      "",
      url.pathname + url.search + url.hash,
    );
    return () => {
      if (new URL(location.href).searchParams.get("stream") === stream.id)
        history.replaceState(history.state, "", originalLocation.current);
    };
  }, [stream.id]);
  useEffect(()=>{trackAnalyticsEvent("livestream_view",stream.store,{stream:stream.id});},[stream.id,stream.store]);
  useEffect(()=>{if(stream.status==="ended"&&!replayPlaying)viewportRef.current?.querySelector<HTMLElement>("#live-ended-title")?.focus({preventScroll:true});},[stream.id,stream.status,replayPlaying]);
  useEffect(() => startLiveFeaturePolling(
    "/api/live-deals?stream=" + encodeURIComponent(stream.id),
    (data) => {setDeals(data.deals || []);setPinnedDealId(data.pinnedDeal||"");},
  ), [stream.id]);
  useEffect(() => startLiveFeaturePolling(
    "/api/product-bundles?stream=" + encodeURIComponent(stream.id) + "&store=" + encodeURIComponent(stream.store || ""),
    (data) => {setPinnedBundleId(data.pinnedBundle||"");setPinnedBundleEndsAt(data.pinnedBundleEndsAt||"");setBundles((data.bundles || []).filter((bundle:any)=>bundle.active&&bundle.product_active&&bundle.available_quantity>0).map((bundle:any)=>({id:bundle.product,bundleId:bundle.id,name:bundle.title,description:bundle.description,price:bundle.price,image:bundle.image,stock:bundle.available_quantity,variants:"[]",seller:stream.seller,liveBundle:true})));},
  ), [stream.id,stream.store,stream.seller]);
  useEffect(()=>{const timer=setInterval(()=>setClock(Date.now()),1000);return()=>clearInterval(timer);},[]);
  useEffect(() => startLiveFeaturePolling(
    "/api/live-auctions?stream=" + encodeURIComponent(stream.id),
    (data) => {
      const nextAuctions = data.auctions || [];
      const feedbackKey = auctionFeedbackKey.current;
      if (feedbackKey) {
        const latest = nextAuctions.find((auction: any) => auction.id === feedbackKey.auctionId);
        const snapshot = latest && `${latest.status}|${Number(latest.highest_bid || 0)}|${latest.highest_bidder_name || ""}|${latest.ends_at || ""}`;
        if (!latest || latest.status !== "active" || snapshot !== feedbackKey.snapshot) {
          auctionFeedbackKey.current = null;
          setAuctionFeedback("");
        }
      }
      setAuctions(nextAuctions);setPinnedAuctionId(data.pinnedAuction||"");
    },
  ), [stream.id]);
  useEffect(() => {
    if (!(["live", "external"].includes(stream.status))) return;
    const pending = allStreamAuctions.filter((auction: any) => auction.status === "expired" || (auction.status === "ended" && !auction.resultEventPublished));
    for (const auction of pending) {
      if (auctionSettling.current.has(auction.id)) continue;
      auctionSettling.current.add(auction.id);
      void (async () => {
        try {
          await fetch("/api/live-auctions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "settle", auction: auction.id }) });
          const refreshed = await fetch("/api/live-auctions?stream=" + encodeURIComponent(stream.id), { cache: "no-store" });
          if (refreshed.ok) {
            const data = await refreshed.json();
            setAuctions(data.auctions || []);
            setPinnedAuctionId(data.pinnedAuction || "");
          }
        } catch { /* The next auction poll retries settlement if the request failed. */ }
        finally { auctionSettling.current.delete(auction.id); }
      })();
    }
  }, [auctions, stream.id, stream.status]);
  useEffect(() => {
    auctionFeedbackKey.current = null;
    setAuctionFeedback("");
  }, [stream.id]);
  const dealFor=(productId:string)=>(Array.isArray(deals)?deals:[]).find(d=>d.product===productId&&(d.status==="active"||new Date(d.starts_at).getTime()<=clock+10000)&&new Date(d.ends_at).getTime()>clock&&Number(d.sold_quantity)<Number(d.max_quantity));
  const countdown=(value:string)=>{const seconds=Math.max(0,Math.ceil((new Date(value).getTime()-clock)/1000));const hours=Math.floor(seconds/3600),minutes=Math.floor((seconds%3600)/60),rest=seconds%60;return hours?`${hours.toString().padStart(2,"0")}:${minutes.toString().padStart(2,"0")}:${rest.toString().padStart(2,"0")}`:`${minutes.toString().padStart(2,"0")}:${rest.toString().padStart(2,"0")}`;};
  const allStreamAuctions=Array.isArray(auctions)?auctions:[];
  const streamAuctions=allStreamAuctions.filter(a=>["active","scheduled"].includes(a.status)).sort((a,b)=>{const aActive=a.status==="active",bActive=b.status==="active";if(aActive!==bActive)return aActive?-1:1;return Date.parse(aActive?a.ends_at:a.starts_at)-Date.parse(bActive?b.ends_at:b.starts_at);});
  const closingAuctions=allStreamAuctions.filter(a=>a.status==="expired");
  const recentAuctionResults=allStreamAuctions.filter(a=>a.status==="ended").sort((a,b)=>Date.parse(b.updated||b.ends_at)-Date.parse(a.updated||a.ends_at)).slice(0,8);
  const pinnedAuction=streamAuctions.find((auction:any)=>auction.id===pinnedAuctionId);
  const availableDeals=[...deals].filter(d=>dealFor(d.product)).sort((a,b)=>Date.parse(a.ends_at)-Date.parse(b.ends_at));
  const soonestDeal=availableDeals.find(d=>d.id===pinnedDealId)||availableDeals[0];
  const dealProducts=(Array.isArray(deals)?deals:[]).map((deal:any)=>({id:deal.product,name:deal.name,description:deal.description||"Limited offer available during this livestream.",price:deal.price,image:deal.image,stock:deal.stock,variants:deal.variants||"[]",seller:deal.seller,store:stream.store,liveDeal:true}));
  async function submitAuctionBid(e:React.FormEvent<HTMLFormElement>,auction:any){
    e.preventDefault();
    const form=e.currentTarget;
    const values=Object.fromEntries(new FormData(form));
    const maxBid=Number(values.maxBid),current=Number(auction.highest_bid||0),minimum=current?current+Number(auction.increment):Number(auction.start_price),myMax=Number(auction.myMaxBid||0),requiredMax=Math.max(minimum,myMax+1);
    if(!Number.isSafeInteger(maxBid)||maxBid<requiredMax){setAuctionFeedback(`Enter a whole-number maximum of at least ₦${requiredMax.toLocaleString("en-NG")}.`);(form.elements.namedItem("maxBid") as HTMLElement|null)?.focus();return;}
    setAuctionBusy(auction.id);setAuctionFeedback("");auctionFeedbackKey.current=null;
    const requestId=auctionBidRequestIds.current[auction.id]||(auctionBidRequestIds.current[auction.id]=crypto.randomUUID());
    try{
      const response=await fetch("/api/live-auctions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"bid",auction:auction.id,maxBid,requestId})});
      const result:{error?:string;duplicate?:boolean;currentBid?:number;leader?:{name:string;isYou:boolean}|null;outbid?:boolean;youAreLeading?:boolean;myMaxBid?:number;endsAt?:string}=await response.json();
      if(!response.ok)throw Error(result.error||"Maximum bid could not be saved. Retry safely; the same request will not create a duplicate.");
      delete auctionBidRequestIds.current[auction.id];
      setAuctions((current:any[])=>current.map(item=>item.id===auction.id?{...item,highest_bid:Number(result.currentBid||0),highest_bidder_name:result.leader?.name||"",youAreLeading:Boolean(result.youAreLeading),myMaxBid:Number(result.myMaxBid||maxBid),ends_at:result.endsAt||item.ends_at}:item));
      const currentBid=Number(result.currentBid||0).toLocaleString("en-NG");
      auctionFeedbackKey.current={auctionId:auction.id,snapshot:`active|${Number(result.currentBid||0)}|${result.leader?.name||""}|${result.endsAt||auction.ends_at}`};
      setAuctionFeedback(result.outbid?`Your maximum was saved, but you are currently outbid at ₦${currentBid}. Increase your maximum to take the lead.`:result.leader?.isYou?`You're leading at ₦${currentBid}. We'll bid only as needed, up to your maximum.`:"Your maximum bid was saved.");
      try{
        const refreshed=await fetch("/api/live-auctions?stream="+encodeURIComponent(stream.id),{cache:"no-store"});
        if(refreshed.ok){const current:{pinnedAuction?:string;auctions?:Array<Record<string,unknown>>}=await refreshed.json();if(Array.isArray(current.auctions))setAuctions(current.auctions);if(typeof current.pinnedAuction==="string")setPinnedAuctionId(current.pinnedAuction);}
      }catch{/* The accepted bid remains confirmed; live polling will refresh totals. */}
    }catch(error:unknown){auctionFeedbackKey.current={auctionId:auction.id,snapshot:`${auction.status}|${Number(auction.highest_bid||0)}|${auction.highest_bidder_name||""}|${auction.ends_at||""}`};setAuctionFeedback(error instanceof Error?error.message:"Bid could not be recorded. Please retry.");}
    finally{setAuctionBusy("");}
  }

  useEffect(() => {
    let alive = true;
    let refreshing = false;
    const refresh = async () => {
      if (refreshing) return;
      refreshing = true;
      try {
        const r = await fetch(
          "/api/commerce?stream=" + encodeURIComponent(stream.id),
          { signal: AbortSignal.timeout(10000) },
        );
        if (r.status === 404) {
          if(alive){setStream((previous:any)=>({...previous,status:"unavailable",verified:0,url:"",replay:"",product:""}));setProducts([]);setOffline(false);setFeedback("This broadcast is no longer available.");}
          return;
        }
        if (!r.ok) throw Error();
        const d = (await r.json()) as any;
        if (alive) {
          if(d.stream?.status==="ended"){
            if(endedFrameStream.current!==stream.id){endedFrameStream.current=stream.id;setEndedBackdrop(captureEndedFrame());}
            setSheet("");setSelected("");setDirectPurchase(null);setReplayPlaying(false);
          }
          setStream(d.stream);
          setProducts(d.products || []);
          setChats((d.chats || []).reverse());
          setViewers(d.viewers);
          setLikes(d.likes);
          setLiked(Boolean(d.liked));
          setOffline(false);
        }
      } catch {
        if (alive) setOffline(true);
      } finally {
        refreshing = false;
      }
    };
    refresh();
    const timer = setInterval(refresh, 3500);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [stream.id]);
  useEffect(() => {
    if (stream.status !== "ended" || replayPlaying) return;
    let alive = true;
    setNextStream(null);
    setEndCountdown(5);
    void refreshLiveStreams().then((fresh) => {
      if (!alive) return;
      const candidates = liveStreamCandidates(fresh).filter((candidate:any) => candidate.id !== stream.id);
      const currentIndex = fresh.findIndex((candidate:any) => candidate.id === stream.id);
      const ordered = currentIndex < 0
        ? candidates
        : [...fresh.slice(currentIndex + 1), ...fresh.slice(0, currentIndex)].filter((candidate:any) => candidate.id !== stream.id);
      const unseen = ordered.find((candidate:any) => !seenStreams.current.has(candidate.id));
      setNextStream(unseen || ordered[0] || null);
    });
    return () => { alive = false; };
  }, [stream.id, stream.status, replayPlaying]);
  useEffect(() => {
    if (stream.status !== "ended" || !nextStream || autoAdvancePaused || replayPlaying || sheet) return;
    const timer = setInterval(() => {
      setEndCountdown((remaining) => {
        if (remaining <= 1) {
          clearInterval(timer);
          switchToNextStream();
          return 0;
        }
        return remaining - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [stream.id, stream.status, nextStream, autoAdvancePaused, replayPlaying, sheet]);
  useEffect(() => {
    if (stream.status !== "live") return;
    const ping = () => {
      if (document.visibilityState === "visible")
        fetch("/api/live-presence", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: stream.id }),
        }).catch(() => {});
    };
    ping();
    const timer = setInterval(ping, 15000);
    const leave = () =>
      fetch("/api/live-presence", {
        method: "POST",
        keepalive: true,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: stream.id, leave: true }),
      }).catch(() => {});
    const visibility = () =>
      document.visibilityState === "hidden" ? leave() : ping();
    document.addEventListener("visibilitychange", visibility);
    window.addEventListener("pagehide", leave);
    return () => {
      clearInterval(timer);
      leave();
      document.removeEventListener("visibilitychange", visibility);
      window.removeEventListener("pagehide", leave);
    };
  }, [stream.id, stream.status]);
  const shoppingProducts = [...products, ...bundles, ...dealProducts.filter((deal:any)=>!products.some((item:any)=>item.id===deal.id)&&!bundles.some((item:any)=>item.id===deal.id))];
  const pinnedDealProduct=soonestDeal&&shoppingProducts.find((item:any)=>item.id===soonestDeal.product);
  const pinned = pinnedDealProduct||shoppingProducts.find((p) => p.id === stream.product),
    p = shoppingProducts.find((p) => p.id === selected) || pinned || shoppingProducts[0];
  const otherShoppingProducts = shoppingProducts.filter((item:any) => item.id !== pinned?.id);
  const selection = liveProductSelection(p, options[p?.id] || "", quantities[p?.id] || 1);
  const { variants, variant, stock } = selection;
  const price = variant?.price ?? (dealFor(p?.id||"")?.promo_price ?? p?.price);
  const pinnedSelection = liveProductSelection(pinned, options[pinned?.id] || "", quantities[pinned?.id] || 1);
  const cartTotal = data.cart.reduce(
      (sum: number, c: any) => sum + (dealFor(c.id)?.promo_price??c.price) * c.quantity,
      0,
    ),
    delivery = deliveryQuote(
      data.stores.find((s: any) => s.id === data.cart[0]?.store),
    );
  const savedDeliveryFee = deliveryFee(data.stores.find((s: any) => s.id === data.cart[0]?.store));
  const directVariant = directPurchase
    ? JSON.parse(directPurchase.product.variants || "[]").find((v: any) => v.name === directPurchase.variant)
    : null;
  const checkoutProductTotal = directPurchase
    ? (directVariant?.price ?? directPurchase.deal?.promo_price ?? directPurchase.product.price) * directPurchase.quantity
    : cartTotal;
  const checkoutDelivery = directPurchase
    ? deliveryQuote(directPurchase.product)
    : delivery;
  const checkoutDeliveryFee = directPurchase
    ? deliveryFee(directPurchase.product)
    : savedDeliveryFee;
  async function addProduct(target = p) {
    if (!target) return;
    if (offline) {setFeedback("Connection interrupted. Reconnect before purchasing this product.");return;}
    const choice = liveProductSelection(target, options[target.id] || "", quantities[target.id] || 1);
    if (choice.error) { setSelected(target.id); setSheet("product"); setFeedback(choice.error); return; }
    setDirectPurchase(null);
    const existing = data.cart.find(
      (c: any) => c.id === target.id && c.variant === (options[target.id] || ""),
    );
    const ok = await act(
      {
        action: "cart",
        product: target.id,
        variant: options[target.id] || "",
        quantity: (existing?.quantity || 0) + (quantities[target.id] || 1),
      },
      "Added to cart",
    );
    if(ok)trackAnalyticsEvent("add_to_cart",target.store,{product:target.id,stream:stream.id});
    setFeedback(
      ok
        ? "Added to cart. Continue watching or checkout."
        : "Unable to add this product. Check the current price, option and stock, then retry.",
    );
  }
  function buyNowProduct(target = p) {
    if (!target) return;
    if (offline) {setFeedback("Connection interrupted. Reconnect before purchasing this product.");return;}
    const selectedVariant = options[target.id] || "";
    const quantity = quantities[target.id] || 1;
    const choice = liveProductSelection(target, selectedVariant, quantity);
    if (choice.error) { setSelected(target.id); setSheet("product"); setFeedback(choice.error); return; }
    const deal=dealFor(target.id);if(deal&&quantity>Number(deal.max_quantity)-Number(deal.sold_quantity)){setFeedback("Only the remaining promotional quantity is available at this price.");return;}
    setDirectPurchase({ product: target, variant: selectedVariant, quantity, deal });
    setCheckoutKey(crypto.randomUUID());
    trackAnalyticsEvent("buy_now",target.store,{product:target.id,stream:stream.id});trackAnalyticsEvent("checkout_start",target.store,{product:target.id,stream:stream.id});
    setSheet("checkout");
  }
  async function share() {
    const url = location.origin + "/?stream=" + encodeURIComponent(stream.id);
    try {
      if (navigator.share) await navigator.share({ title: stream.title, url });
      else {
        await navigator.clipboard.writeText(url);
        setFeedback("Broadcast link copied");
      }
    } catch {
      setFeedback("Sharing was cancelled or unavailable.");
    }
  }
  const cartQuantity = data.cart.reduce(
    (n: number, c: any) => n + c.quantity,
    0,
  );
  async function reactToStream() {
    if (reacting) return;
    setReacting(true);
    try {
      if (
        await act(
          { action: "stream-like", stream: stream.id, liked: !liked },
          "",
        )
      ) {
        const r = await fetch(
          "/api/commerce?stream=" + encodeURIComponent(stream.id),
          { signal: AbortSignal.timeout(10000) },
        );
        if (!r.ok) throw Error();
        const fresh: any = await r.json();
        setLikes(fresh.likes);
        setLiked(Boolean(fresh.liked));
        if (fresh.liked) setHeartBurst((value) => value + 1);
      } else
        setFeedback(
          "Sign in to react, or retry if the broadcast is unavailable.",
        );
    } catch {
      setFeedback("Reaction count could not refresh. Retrying…");
    } finally {
      setReacting(false);
    }
  }
  function openCart() {
    setDirectPurchase(null);
    setCheckoutKey(crypto.randomUUID());
    setSheet("checkout");
  }
  return (
    <div className="live-shopping" ref={viewportRef} data-stream-status={stream.status}>
      <div className="live-stage" tabIndex={0} aria-label="Live stream viewer. Swipe up or down to change streams." inert={Boolean(sheet)} onTouchStart={onTouchStart} onTouchEnd={onTouchEnd} onKeyDown={(event)=>{if(event.target instanceof HTMLElement&&event.target.closest("button,a,input,textarea,select"))return;if(event.key==="ArrowUp"||event.key==="ArrowDown"){event.preventDefault();void moveToAdjacentStream(event.key==="ArrowUp"?1:-1);}}}>
        {stream.status === "unavailable" ? <div className="live-state"><h2>Broadcast unavailable</h2><p>The seller or stream is no longer available.</p><button onClick={onClose}>Browse live streams</button></div> : stream.status === "ended" ? (
          replayPlaying && stream.replay ? (
            <LiveVideo url={stream.replay} />
          ) : (
            <div className="live-state live-ended-transition" aria-labelledby="live-ended-title">
              {endedBackdrop&&<img className="live-ended-backdrop" src={endedBackdrop} alt=""/>}
              <div className="live-ended-heading">
                <span className="live-ended-check"><CheckCircle2 aria-hidden="true" /></span>
                <h2 id="live-ended-title" tabIndex={-1}>This live has ended</h2>
                <p>Thanks for watching!</p>
              </div>
              {pinned && <a className="live-ended-product" href={"/product/" + encodeURIComponent(pinned.id)}>
                <ImageAsset src={pinned.image} alt="" />
                <span><strong>{pinned.title}</strong><b>{money(pinned.price)}</b></span>
                <span className="live-ended-link">View product <ChevronUp aria-hidden="true" /></span>
              </a>}
              {nextStream ? <section className="live-next-card" aria-live="polite">
                <div className="live-next-title"><Radio aria-hidden="true" /><span><strong>Next live</strong><small>A new live stream is ready.</small></span></div>
                <div className="live-next-stream">
                  {nextStream.thumbnail && <ImageAsset src={nextStream.thumbnail} alt="" />}
                  <span><strong>{nextStream.seller}</strong><small>{nextStream.title || "Live shopping"}</small></span>
                  <span className="live-countdown" aria-label={`Moving to next live in ${endCountdown} seconds`}>{endCountdown}</span>
                </div>
                <p className="live-countdown-copy">Moving to the next live in <strong>{endCountdown} {endCountdown === 1 ? "second" : "seconds"}</strong></p>
                <button className="live-next-primary" onClick={switchToNextStream}><Play aria-hidden="true" fill="currentColor" /> Watch next live now</button>
                <button className="live-next-secondary" onClick={() => setAutoAdvancePaused(true)}>Stay here <small>Browse more lives</small></button>
              </section> : <div className="live-next-card live-next-empty">
                <div className="live-next-title"><Radio aria-hidden="true" /><span><strong>No other sellers are live</strong><small>Browse the marketplace for more streams.</small></span></div>
                <button className="live-next-primary" onClick={onClose}>Browse live streams</button>
              </div>}
              <p className="live-ended-swipe-hint">Swipe up or down to switch live streams.</p>
              <div className="live-ended-actions">
                {stream.replay && <button className="live-next-secondary" onClick={() => setReplayPlaying(true)}>Watch replay</button>}
                <a className="live-ended-store" href={"/store/" + encodeURIComponent(stream.store)}>Visit seller’s store</a>
              </div>
            </div>
          )
        ) : stream.status === "scheduled" ? (
          <div className="live-state">
            <h2>Waiting for the seller</h2>
            <ScheduleInfo scheduled={stream.scheduled} />
            <button onClick={onClose}>Browse live streams</button>
          </div>
        ) : stream.provider === "tiktok" ? (
          <a
            className="live-state"
            href={stream.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            Watch on TikTok
          </a>
        ) : stream.provider === "native" ? (
          <WebRTCVideo url={stream.url} />
        ) : (
          <LiveVideo url={stream.url} controls={false} />
        )}
        <div className="live-top">
          <div className="live-seller">
            <StoreLogo name={stream.seller || "Seller"} src={stream.seller_logo} size={42} className="seller-initial" />
            <div>
              <strong>
                <span className="seller-name-text">{stream.seller}</span>{stream.verified===1&&<CheckCircle2 className="seller-live-verified" size={15} aria-label="Verified seller"/>}<span className="cnc-seller-trust-badges">{stream.official_store===1&&<img {...trustBadgeImage("official-store")} className="cnc-trust-badge cnc-trust-badge--small"/>}{stream.top_seller===1&&<img {...trustBadgeImage("top-seller")} className="cnc-trust-badge cnc-trust-badge--small"/>}</span>
              </strong>
              <small>{stream.seller_location || stream.title}</small>
            </div>
          </div>
          <button aria-label="Close broadcast" onClick={onClose}>
            <X />
          </button>
        </div>
        <div className="live-top-meta">
          <span className="live-status">
            {["live", "external"].includes(stream.status)
              ? "LIVE"
                : stream.status === "ended" && stream.replay
                  ? "REPLAY"
                  : broadcastLabel(stream)}
          </span>
          {stream.status === "live" && viewers !== null && (
            <span className="live-viewer-count" title="Current viewers on this broadcast">
              <span aria-hidden="true" className="live-viewer-dot" />
              {viewers.toLocaleString()} {viewers === 1 ? "viewer" : "viewers"} watching
            </span>
          )}
        </div>
        {stream.status !== "ended" && stream.status !== "unavailable" && <div className="live-swipe-hint" aria-hidden="true"><ChevronUp size={13} /> Swipe up or down to switch lives</div>}
        <div className="live-lower" inert={Boolean(sheet)}>
          {!sheet && (
            <div className="live-chat">
              <div
                ref={chatMessagesRef}
                className="live-messages"
                role="log"
                aria-label={`Live comments, ${chats.length} total`}
                aria-live="polite"
                tabIndex={0}
                onScroll={(event) => {
                  const messages = event.currentTarget;
                  chatStickToBottom.current = messages.scrollHeight - messages.scrollTop - messages.clientHeight < 24;
                }}
              >
                {chats.slice(-30).map((c) => (
                  <p key={c.id} className={`live-comment-row${c.system ? " live-system-comment" : ""}`}>
                    <span className="live-comment-avatar" aria-hidden="true">{(c.name || "?").replace(/^@/,"").slice(0,1).toUpperCase()}</span>
                    <span className="live-comment-copy"><strong>{c.name}{c.system && <small className="live-system-badge">Update</small>}</strong><span>{c.message}</span></span>
                  </p>
                ))}
              </div>
              {offline && <p role="status">Chat disconnected. Retrying…</p>}
            </div>
          )}
          {!sheet && otherShoppingProducts.length > 0 && <nav className="live-product-strip" aria-label="Other products featured in this live">
            {otherShoppingProducts.slice(0,5).map((item:any)=>{
              const itemDeal=dealFor(item.id);
              const itemAuction=streamAuctions.find((auction:any)=>auction.product===item.id);
              const isPinned=item.id===pinned?.id;
              const displayPrice=itemDeal?.promo_price??item.price;
              return <button type="button" key={item.id} aria-pressed={isPinned} aria-label={`${isPinned?"Pinned product, ":""}${item.name}, ${money(displayPrice)}${itemAuction?", auction available":itemDeal?", live deal":""}`} onClick={()=>{trackAnalyticsEvent("product_click",stream.store,{product:item.id,stream:stream.id});if(itemAuction){setAuctionFeedback("");setSheet("auction");}else{setSelected(item.id);setSheet("product");}}}>
                <span className="live-product-card-image">{item.image?<ImageAsset src={item.image} alt=""/>:<ImageAsset src="/image-unavailable.svg" alt=""/>}</span>
                {isPinned&&<span className="live-product-pin-badge">PINNED</span>}
                {itemDeal&&<span className="live-product-deal-badge"><Zap size={10} aria-hidden="true"/>FLASH · {countdown(itemDeal.ends_at)}</span>}
                {itemAuction&&<span className="live-product-auction-badge"><Radio size={10} aria-hidden="true"/>AUCTION</span>}
                {item.liveBundle&&<span className="live-product-bundle-badge">{item.bundleId===pinnedBundleId&&pinnedBundleEndsAt?`PINNED BUNDLE · ${countdown(pinnedBundleEndsAt)}`:"BUNDLE"}</span>}
                <strong>{item.name}</strong><b>{money(displayPrice)}</b>
              </button>;
            })}
          </nav>}
          {!sheet && pinnedAuction && <button type="button" className="live-buyer-pinned-auction" aria-label={`Open pinned auction for ${pinnedAuction.product_name}`} onClick={()=>{setAuctionFeedback("");setSheet("auction");}}>
            <span className="live-buyer-auction-art">{pinnedAuction.image?<ImageAsset src={pinnedAuction.image} alt=""/>:<Radio size={16} aria-hidden="true"/>}</span>
            <span className="live-buyer-auction-copy"><strong><Radio size={12} aria-hidden="true"/> {pinnedAuction.status==="active"?"AUCTION LIVE":"AUCTION UP NEXT"}</strong><span>{pinnedAuction.product_name}</span></span>
            <span className="live-buyer-auction-price"><b>₦{Number(pinnedAuction.highest_bid||pinnedAuction.start_price).toLocaleString("en-NG")}</b><small>{pinnedAuction.status==="active"?`Ends ${countdown(pinnedAuction.ends_at)}`:`Starts ${countdown(pinnedAuction.starts_at)}`}</small>{pinnedAuction.highest_bidder_name&&<small>Leading {pinnedAuction.highest_bidder_name}</small>}</span>
            <span className="live-buyer-auction-cta">{pinnedAuction.status==="active"?"View auction":"View"}</span>
          </button>}
          {pinned && !pinnedAuction && !sheet && <div className={"live-pin-shell" + (pinCollapsed ? " is-collapsed" : "")}>
            <button type="button" className="live-pin-toggle" aria-label={pinCollapsed ? "Expand pinned product" : "Collapse pinned product"} aria-expanded={!pinCollapsed} aria-controls={pinCollapsed ? undefined : "live-pinned-product"} onClick={() => setPinCollapsed(v => !v)}>
              <ShoppingBag size={16} aria-hidden="true" /> {pinCollapsed ? <><ImageAsset src={pinned.image} alt=""/><span className="pin-collapsed-name">{pinned.name}</span><b>{money(pinnedSelection.variant?.price ?? dealFor(pinned.id)?.promo_price ?? pinned.price)}</b></> : "Pinned Product"}{pinCollapsed ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
          {!pinCollapsed && (
            <div id="live-pinned-product" className="live-premium-product">
              <button className="live-premium-product-info" aria-label={`View ${pinned.name} details`} onClick={() => {trackAnalyticsEvent("product_click",pinned.store,{product:pinned.id,stream:stream.id});setSelected(pinned.id);setSheet("product");}}>
                <ImageAsset src={pinned.image} alt={pinned.name} />
                <span><strong>{pinned.name}</strong><span className="live-premium-price">{money(pinnedSelection.variant?.price ?? dealFor(pinned.id)?.promo_price ?? pinned.price)}{dealFor(pinned.id) && <s>{money(pinned.price)}</s>}</span>
                {dealFor(pinned.id) && <small className="live-pin-deal live-flash-pulse-badge">FLASH · {Math.round((1-Number(dealFor(pinned.id).promo_price)/Number(pinned.price))*100)}% OFF · {countdown(dealFor(pinned.id).ends_at)} left</small>}</span>
              </button>
              {pinnedSelection.variants.length > 0 && <label className="live-pinned-option">Choose an option<select aria-label={`Option for ${pinned.name}`} value={options[pinned.id] || ""} onChange={e=>{setOptions({...options,[pinned.id]:e.target.value});setQuantities({...quantities,[pinned.id]:1});setFeedback("");}}><option value="">Select an available option</option>{pinnedSelection.variants.map(v=><option key={v.name} value={v.name} disabled={!v.stock}>{v.name} · {money(v.price ?? pinned.price)} · {v.stock ? `${v.stock} available` : "Sold out"}</option>)}</select></label>}
              <div className="live-premium-purchase">
                <button className="primary" disabled={busy || offline || Boolean(pinnedSelection.error)} onClick={() => buyNowProduct(pinned)}>Buy Now</button>
                <button className="secondary-button" disabled={busy || offline || Boolean(pinnedSelection.error)} onClick={() => addProduct(pinned)}>Add to Cart</button>
              </div>
            </div>
          )}
          </div>}
          {!sheet && ["live", "external"].includes(stream.status) && (
            <div className="live-composer">
              {" "}
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (
                    await act(
                      { action: "chat", stream: stream.id, message },
                      "",
                    )
                  )
                    setMessage("");
                  else setFeedback("Message could not be sent. Please retry.");
                }}
              >
                <input
                  aria-label="Ask the seller a question"
                  placeholder="Ask the seller…"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  maxLength={400}
                  required
                  disabled={!["live", "external"].includes(stream.status)}
                />
                <button aria-label="Send question" disabled={busy}>
                  <Send size={19} />
                </button>
              </form>
              <button
                className="live-cart-button"
                aria-label={`Open cart, ${cartQuantity} ${cartQuantity === 1 ? "item" : "items"}`}
                onClick={openCart}
                title={
                  cartQuantity ? "View cart and checkout" : "Your cart is empty"
                }
              >
                <ShoppingCart />
                {cartQuantity > 0 && (
                  <span className="live-action-count">{cartQuantity}</span>
                )}
              </button>
            </div>
          )}
          {!["live", "external"].includes(stream.status) &&
            cartQuantity > 0 && (
              <button
                className="live-cart-button live-ended-cart"
                onClick={openCart}
              >
                <ShoppingCart />
                Cart · {cartQuantity}
              </button>
            )}
        </div>
        <div className="live-viewer-tools" aria-label="Viewer actions">
          <LiveAction label={likes === null ? "Like" : String(likes)} icon={<Heart fill={liked ? "currentColor" : "none"} />} aria-label={(liked ? "Unlike broadcast" : "Like broadcast") + (likes === null ? "" : `, ${likes} likes`)} aria-pressed={liked} disabled={busy || reacting || !["live", "external"].includes(stream.status)} title={["live", "external"].includes(stream.status) ? "Sign in to save your reaction" : "Reactions are available during a broadcast"} onClick={reactToStream} />
          <LiveAction label={String(chats.length)} icon={<MessageCircle />} aria-label={`Read ${chats.length} live comments`} onClick={() => setSheet("comments")} />
          <LiveAction label="Share" icon={<Share2 />} aria-label="Share broadcast" onClick={share} />
          <LiveAction label="More" icon={<MoreHorizontal />} aria-label="More broadcast options" aria-haspopup="dialog" onClick={() => setSheet("more")} />
        </div>
        {heartBurst>0&&<span key={heartBurst} className="live-heart-burst" aria-hidden="true" onAnimationEnd={()=>setHeartBurst(0)}><Heart size={30} fill="currentColor"/></span>}
      </div>

      <aside className="live-desktop-sidebar" aria-label="Live shopping and chat" inert={Boolean(sheet)}>
        <header className="live-desktop-sidebar-heading">
          <div><span>LIVE SHOPPING</span><h2>Shop this stream</h2></div>
          <span className="live-desktop-count">{shoppingProducts.length} {shoppingProducts.length === 1 ? "item" : "items"}</span>
        </header>
        {pinned && !pinnedAuction && <section className="live-desktop-pinned" aria-label="Pinned product">
          <div className="live-desktop-item-heading"><span>PINNED FOR THIS LIVE</span>{dealFor(pinned.id) && <b className="live-desktop-flash">FLASH DEAL</b>}</div>
          <button className="live-desktop-product-main" onClick={() => {setSelected(pinned.id);setSheet("product");}}>
            <ImageAsset src={pinned.image} alt={pinned.name} />
            <span><strong>{pinned.name}</strong><b>{money(pinnedSelection.variant?.price ?? dealFor(pinned.id)?.promo_price ?? pinned.price)}</b></span>
          </button>
          <div className="live-desktop-purchase">
            <button className="primary" disabled={busy || offline || Boolean(pinnedSelection.error)} onClick={() => buyNowProduct(pinned)}>Buy now</button>
            <button className="secondary-button" disabled={busy || offline || Boolean(pinnedSelection.error)} onClick={() => addProduct(pinned)}>Add to cart</button>
          </div>
        </section>}
        {pinnedAuction && <section className="live-desktop-pinned-auction" aria-label="Pinned live auction">
          <div><span className="live-auction-live-label"><Radio size={12} aria-hidden="true"/>{pinnedAuction.status==="active"?"LIVE AUCTION":"UP NEXT"}</span><small>{pinnedAuction.status==="active"?`Ends in ${countdown(pinnedAuction.ends_at)}`:`Starts in ${countdown(pinnedAuction.starts_at)}`}</small></div>
          <strong>{pinnedAuction.product_name}</strong>
          <span>Current bid <b>₦{Number(pinnedAuction.highest_bid||pinnedAuction.start_price).toLocaleString("en-NG")}</b></span>
          {pinnedAuction.highest_bidder_name&&<span>Leading <b>{pinnedAuction.highest_bidder_name}</b></span>}
          <button type="button" onClick={()=>{setAuctionFeedback("");setSheet("auction");}}>View auction <ChevronUp size={15} aria-hidden="true"/></button>
        </section>}
        {otherShoppingProducts.length > 0 && <section className="live-desktop-products" aria-label="More products in this live">
          <h3>More from this seller</h3>
          {otherShoppingProducts.slice(0,5).map((item:any)=>{
            const deal=dealFor(item.id);
            const auction=streamAuctions.find((entry:any)=>entry.product===item.id);
            return <button className="live-desktop-product-row" key={item.id} onClick={() => {
              if(auction){setAuctionFeedback("");setSheet("auction");}
              else{setSelected(item.id);setSheet("product");}
            }}>
              <ImageAsset src={item.image} alt="" />
              <span><strong>{item.name}</strong><small>{auction?"Auction":deal?"Flash deal":item.liveBundle?"Live bundle":"Featured product"}</small></span>
              <b>{money(deal?.promo_price ?? item.price)}</b>
            </button>;
          })}
        </section>}
        <section className="live-desktop-chat" aria-label="Live buyer chat">
          <div className="live-desktop-chat-heading"><h3>Live chat</h3><span>{chats.length}</span></div>
          <div className="live-desktop-messages" aria-live="polite">
            {chats.length ? chats.slice(-30).map((chat:any)=><p key={chat.id} className={chat.system ? "live-system-comment" : ""}><strong>{chat.name}{chat.system && <small className="live-system-badge">Update</small>}</strong><span>{chat.message}</span></p>) : <p className="live-desktop-empty-chat">No comments yet. Be the first to ask the seller a question.</p>}
          </div>
          {offline && <p role="status" className="live-desktop-offline">Chat disconnected. Retrying…</p>}
          {["live","external"].includes(stream.status) && <form className="live-desktop-composer" onSubmit={async (e) => {
            e.preventDefault();
            if(await act({action:"chat",stream:stream.id,message},"")) setMessage("");
            else setFeedback("Message could not be sent. Please retry.");
          }}>
            <input aria-label="Ask the seller a question" placeholder="Ask the seller…" value={message} onChange={(e)=>setMessage(e.target.value)} maxLength={400} required />
            <button aria-label="Send question" disabled={busy}><Send size={18}/></button>
          </form>}
        </section>
      </aside>

      {feedback && (
        <div className="live-feedback" role="status">
          {feedback}
          <button aria-label="Dismiss message" onClick={() => setFeedback("")}>
            <X size={18} />
          </button>
        </div>
      )}
      {sheet && (
        <LiveSheet
          title={
            sheet === "checkout"
              ? "Your cart"
              : sheet === "products"
                ? "Shop this broadcast"
                : sheet === "more"
                  ? "Broadcast options"
                  : sheet === "comments" ? "Live comments" : sheet === "auction" ? "Live auction" : "Product details"
          }
          onClose={() => setSheet("")}
        >
          {feedback && (
            <p role="status" className="live-sheet-notice">
              {feedback}
            </p>
          )}
          {sheet === "more" ? (
            <div className="live-option-list">
              <button onClick={()=>setSheet("comments")}>View all comments</button>
              <button onClick={openCart}><ShoppingCart/>Open cart{cartQuantity>0?` · ${cartQuantity}`:""}</button>
              <button onClick={()=>act({action:"follow",store:stream.store,follow:!data.follows.some((f:any)=>f.store===stream.store)},"Follow preference updated")}>{data.follows.some((f:any)=>f.store===stream.store)?"Following seller":"Follow seller"}</button>
              <button onClick={()=>{setSheet("");onClose();}}>Close live player</button>
              {fullscreenAvailable && (
                <button
                  onClick={() =>
                    viewportRef.current
                      ?.requestFullscreen()
                      .then(() => setSheet(""))
                      .catch(() =>
                        setFeedback(
                          "Fullscreen is unavailable. Continue watching here.",
                        ),
                      )
                  }
                >
                  <Maximize />
                  Enter fullscreen
                </button>
              )}
              <a href={"/store/" + encodeURIComponent(stream.store)}>
                Visit seller’s store
              </a>
              {!shoppingProducts.length && <p>No featured products are available.</p>}
              {!["live", "external"].includes(stream.status) && (
                <p>Reactions and comments are available during a broadcast.</p>
              )}
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (
                    await act(
                      {
                        action: "report",
                        target_type: "stream",
                        target: stream.id,
                        reason: reportReason,
                        details: "Broadcast report: " + reportReason,
                      },
                      "Report submitted",
                    )
                  ) {
                    setReportReason("");
                    setSheet("");
                  }
                }}
              >
                <label>
                  Report this broadcast
                  <textarea
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    placeholder="Tell us what happened"
                    minLength={5}
                    maxLength={1000}
                    required
                  />
                </label>
                <button disabled={busy}>
                  <Flag />
                  Submit report
                </button>
              </form>
            </div>
          ) : sheet === "comments" ? <div className="live-comments-panel">{chats.length ? chats.map(c=><p key={c.id} className={`live-comment-row${c.system ? " live-system-comment" : ""}`}><span className="live-comment-avatar" aria-hidden="true">{(c.name||"?").replace(/^@/,"").slice(0,1).toUpperCase()}</span><span className="live-comment-copy"><strong>{c.name}{c.system && <small className="live-system-badge">Update</small>}</strong><span>{c.message}</span></span></p>) : <p>No comments yet.</p>}{["live","external"].includes(stream.status)&&<form className="live-comments-composer" onSubmit={async e=>{e.preventDefault();if(await act({action:"chat",stream:stream.id,message},""))setMessage("");else setFeedback("Message could not be sent. Please retry.");}}><input aria-label="Write a live comment" placeholder="Ask the seller…" value={message} onChange={e=>setMessage(e.target.value)} maxLength={400} required/><button aria-label="Send comment" disabled={busy}><Send size={19}/></button></form>}</div> : sheet === "auction" ? (
            <div className="live-auction-list">
              {auctionFeedback&&<p className="live-sheet-notice" role="status">{auctionFeedback}</p>}
              {!!closingAuctions.length&&<p className="live-sheet-notice" role="status">Auction closing — confirming the result…</p>}
              {streamAuctions.map((auction:any)=>{const active=auction.status==="active",current=Number(auction.highest_bid||0),nextBid=current?current+Number(auction.increment):Number(auction.start_price),requiredMax=Math.max(nextBid,Number(auction.myMaxBid||0)+1);return <article className="live-auction-card" key={auction.id}>
                <div className="live-auction-card-heading"><span className={active?"is-live":"is-upcoming"}>{auction.id===pinnedAuctionId?"PINNED · ":""}{active?"LIVE NOW":"UP NEXT"}</span><span>{active?"Ends in":"Starts in"} <strong>{countdown(active?auction.ends_at:auction.starts_at)}</strong></span></div>
                <h3>{auction.product_name}</h3>
                <dl><div><dt>Current bid</dt><dd>{current?money(current):"No bids"}</dd></div><div><dt>Next bid</dt><dd>{money(nextBid)}</dd></div><div><dt>Bids</dt><dd>{auction.bid_count}</dd></div><div><dt>Leading</dt><dd>{auction.highest_bidder_name||"No bids yet"}</dd></div></dl>
                {Number(auction.myMaxBid)>0&&!auction.youAreLeading&&<p className="live-auction-outbid" role="status">You’re currently outbid. Increase your maximum to get back in front.</p>}
                {active&&auction.canBid?<form className="live-auction-bid-form" noValidate onSubmit={e=>void submitAuctionBid(e,auction)}>
                  {Number(auction.myMaxBid)>0&&<p className="live-auction-my-max">Your current maximum: {money(Number(auction.myMaxBid))}</p>}
                  <label>Maximum bid (₦)<input key={`${auction.id}-${requiredMax}-${auction.myMaxBid||0}`} name="maxBid" type="number" inputMode="numeric" min={requiredMax} step="1" defaultValue={requiredMax} required/></label>
                  <p className="live-auction-upcoming-note">Set your maximum. We’ll bid only as needed, up to that amount. Each new bid in the final 12 seconds resets the countdown to 12 seconds.</p>
                  <p className="live-auction-shipping-note">No address is needed to bid. If you win, add your delivery details and pay from My Orders. Delivery fee: ₦{Number(auction.deliveryFee||0).toLocaleString("en-NG")}.</p>
                  <button className="primary" disabled={auctionBusy===auction.id}>{auctionBusy===auction.id?"Saving maximum…":"Set maximum bid"}</button>
                </form>:active?<p className="live-auction-signin">Sign in as a buyer to bid. Sellers cannot bid on their own auctions. <a href={`/sign-in?returnTo=${encodeURIComponent(`/?browse=1&stream=${stream.id}#live`)}`}>Sign in</a></p>:<p className="live-auction-upcoming-note">Bidding opens when the countdown reaches zero while this broadcast is live.</p>}
              </article>;})}
              {!!recentAuctionResults.length&&<section className="live-auction-results" aria-label="Recent auction results"><h3>Recent results</h3>{recentAuctionResults.map((auction:any)=>{const sold=Boolean(auction.winner_name&&auction.winning_amount);const resultLabel=sold?`Sold for ${money(Number(auction.winning_amount))}`:Number(auction.bid_count)>0?"Ended · reserve not met":"Ended with no bids";return <article key={auction.id} className="live-auction-result-card">{auction.image&&<ImageAsset src={auction.image} alt="" width={48} height={48}/>}<div><strong>{auction.product_name}</strong><span>{resultLabel}</span>{sold&&<small>Winner: {auction.winner_name}</small>}</div></article>;})}</section>}
              {!streamAuctions.length&&!recentAuctionResults.length&&!closingAuctions.length&&<p>No auctions are running in this broadcast.</p>}
            </div>
          ) : sheet === "products" ? (
            <div className="live-product-list">
              {shoppingProducts.length ? (
                shoppingProducts.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setSelected(item.id);
                      setSheet("product");
                    }}
                  >
                    <ImageAsset src={item.image} alt={item.name} />
                    <span>
                      <strong>{item.name}</strong>
                      {item.liveBundle&&<small>Live bundle</small>}
                      {dealFor(item.id)?<><s>{money(item.price)}</s><b>{money(dealFor(item.id).promo_price)}</b><small>{Math.round((1-dealFor(item.id).promo_price/item.price)*100)}% off · ends in {countdown(dealFor(item.id).ends_at)} · {Math.max(0,Number(dealFor(item.id).max_quantity)-Number(dealFor(item.id).sold_quantity))} remaining</small></>:<b>{money(item.price)}</b>}
                      <small>{item.stock ? "View options" : "Sold out"}</small>
                    </span>
                  </button>
                ))
              ) : (
                <p>The seller has not featured any products yet.</p>
              )}
            </div>
          ) : sheet === "product" && p ? (
            <div className="live-product-detail">
              <ImageAsset src={p.image} alt={p.name} />
              <h3>{p.name}</h3>
              {dealFor(p.id)&&!variant?<><del>{money(p.price)}</del><strong>{money(price)} · {Math.round((1-price/p.price)*100)}% off</strong><p className="live-deal-timer">Flash deal ends in {countdown(dealFor(p.id).ends_at)} · {Math.max(0,dealFor(p.id).max_quantity-dealFor(p.id).sold_quantity)} remaining</p></>:<strong>{money(price)}</strong>}
              <p>{p.description}</p>
              {variants.length > 0 && (
                <label>
                  Variant
                  <select
                    value={options[p.id] || ""}
                    onChange={(e) => {
                      setOptions({ ...options, [p.id]: e.target.value });
                      if (e.target.value && (feedback === "Choose an available product option first." || feedback === `Choose an available option for ${p.name}.` || feedback.startsWith("This option or product is sold out."))) setFeedback("");
                    }}
                  >
                    <option value="">Choose variant</option>
                    {variants.map((v: any) => (
                      <option key={v.name} value={v.name} disabled={!v.stock}>
                        {v.name} · {money(v.price)}
                        {!v.stock ? " · Sold out" : ""}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              <label>
                Quantity
                <input
                  type="number"
                  min="1"
                  max={Math.min(stock || 1, 99)}
                  value={quantities[p.id] || 1}
                  onChange={(e) =>
                    setQuantities({
                      ...quantities,
                      [p.id]: Math.max(
                        1,
                        Math.min(stock || 1, 99, Number(e.target.value) || 1),
                      ),
                    })
                  }
                />
              </label>
              <p>
                {variants.length && !variant
                  ? "Choose an option"
                  : stock
                    ? `${stock} available`
                    : "Sold out"}
              </p>
              <details>
                <summary>Delivery and seller details</summary>
                <p>{p.location}</p>
                <p>
                  Coverage:{" "}
                  {JSON.parse(p.coverage || "[]").join(", ") ||
                    "Confirm with seller"}
                </p>
                <p>
                  Delivery:{" "}
                  {deliveryFee(p) === undefined
                    ? "Fee confirmed at checkout"
                    : money(deliveryFee(p)!) + " per order"}{" "}
                  · {p.delivery_days}
                </p>
                <p>{p.return_policy}</p>
              </details>
              <button
                className="primary"
                disabled={busy || offline || Boolean(selection.error)}
                onClick={() => buyNowProduct()}
              >
                Buy Now
              </button>
              <button
                className="secondary-button"
                disabled={busy || offline || Boolean(selection.error)}
                onClick={() => addProduct()}
              >
                Add to Cart
              </button>
              <button
                onClick={() => {
                  setDirectPurchase(null);
                  setCheckoutKey(crypto.randomUUID());
                  setSheet("checkout");
                }}
              >
                View cart and checkout
              </button>
              <button onClick={() => setSheet("products")}>
                All featured products
              </button>
            </div>
          ) : sheet === "checkout" ? (
            <div>
              {directPurchase ? (
                <p>{directPurchase.product.name}{directPurchase.variant ? ` · ${directPurchase.variant}` : ""} · {directPurchase.quantity} × {money(directVariant?.price ?? directPurchase.deal?.promo_price ?? directPurchase.product.price)}</p>
              ) : data.cart.map((c: any) => (
                <p key={c.id}>
                  {c.name} {c.variant} · {c.quantity} × {money(dealFor(c.id)?.promo_price??c.price)} {dealFor(c.id)&&<small><s>{money(c.price)}</s> live deal</small>}
                </p>
              ))}
              <p>
                Products {money(checkoutProductTotal)} ·{" "}
                {checkoutDeliveryFee === undefined ? "Delivery fee not set" : `Delivery ${money(checkoutDeliveryFee)} · Total ${money(checkoutProductTotal + checkoutDeliveryFee)}`}
                {checkoutDelivery === undefined && <span> · Seller delivery coverage is required before payment.</span>}
              </p>
              {directPurchase || data.cart.length ? (
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const body = Object.fromEntries(
                      new FormData(e.currentTarget),
                    );
                    if (body.payment === "flutterwave") {
                      try {
                        sessionStorage.setItem("cnc-live-return", stream.id);
                      } catch {}
                    }
                    const ok = await act(
                      {
                        action: "checkout",
                        ...body,
                        key: checkoutKey,
                        ...(directPurchase
                          ? {
                              product: directPurchase.product.id,
                              variant: directPurchase.variant,
                              quantity: directPurchase.quantity,
                              ...(directPurchase.deal?{dealId:directPurchase.deal.id,stream:stream.id}:{}),
                            }
                          : {deals:Object.fromEntries(data.cart.map((c:any)=>[c.id,dealFor(c.id)?.id]).filter((entry:any)=>Boolean(entry[1]))),stream:stream.id}),
                      },
                      "Order placed",
                    );
                    setFeedback(
                      ok
                        ? "Order placed. Check My orders for payment status."
                        : "Checkout failed. Check your cart, price, stock and delivery details, then retry.",
                    );
                    if (ok) {
                      setSheet("");
                      setDirectPurchase(null);
                    }
                  }}
                >
                  <label>
                    Delivery name
                    <input name="name" required />
                  </label>
                  <label>
                    Phone
                    <input name="phone" type="tel" required />
                  </label>
                  <label>
                    Address
                    <input name="address" required />
                  </label>
                  <label>
                    Delivery state
                    <input name="delivery_state" required />
                  </label>
                  <label>
                    Payment
                    <select name="payment" disabled={!data.payments?.online}>
                      {!data.payments?.online && <option value="">Debit card payment unavailable</option>}
                      {data.payments?.online && (
                        <option value="flutterwave">
                          Debit card payment
                          {data.payments?.mode === "live" ? "" : " sandbox"}
                        </option>
                      )}
                    </select>
                  </label>
                  <p>
                    {data.payments?.mode === "live"
                      ? "Online payment"
                      : "Sandbox payment"}{" "}
                    opens secure checkout powered by Flutterwave. Use Back to broadcast on the payment
                    result page to return.
                  </p>
                  <button
                    className="primary"
                    disabled={busy || checkoutDelivery === undefined || !data.payments?.online}
                  >
                    Place order
                  </button>
                </form>
              ) : (
                <p>Your cart is empty.</p>
              )}
            </div>
          ) : null}
        </LiveSheet>
      )}
    </div>
  );
}
