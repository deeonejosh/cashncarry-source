export const MIN_PASSWORD_LENGTH = 12;
export function safeReturnPath(value: string | null | undefined): string {
  if (
    !value ||
    !value.startsWith("/") ||
    value.startsWith("//") ||
    /[\\\x00-\x1f\x7f]/.test(value)
  )
    return "/#market";
  try {
    const url = new URL(value, "https://internal.invalid");
    if (
      url.origin !== "https://internal.invalid" ||
      (url.pathname === "/account" && Boolean(url.search)) ||
      /^\/(?:api|sign-in|sign-up|forgot-password|signin-with-chatgpt|signout-with-chatgpt|callback|welcome)(?:\/|$)/.test(
        url.pathname,
      )
    )
      return "/#market";
    return url.pathname + url.search + url.hash;
  } catch {
    return "/#market";
  }
}

/** Carry only recognised shopping actions through the existing sign-in flow. */
export function shoppingReturnPath(current: string, intent?: string): string {
  const url = new URL(safeReturnPath(current), "https://internal.invalid");
  if (intent === "cart") url.searchParams.set("open", "cart");
  else if (["seller", "orders"].includes(intent?.toLowerCase() || "")) {
    url.searchParams.delete("open");
    url.hash = intent!.toLowerCase();
  }
  return safeReturnPath(url.pathname + url.search + url.hash);
}

export async function signOutEmailSession(
  request: typeof fetch = fetch,
): Promise<void> {
  const response = await request("/api/auth/sign-out", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: "{}",
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok)
    throw Error("Sign-out failed. Please retry before leaving this device.");
}

export function workspaceTab(value: string | null): string {
  const allowed = [
    "Account",
    "Saved products",
    "Addresses",
    "Notification preferences",
    "Delivery",
    "Verification",
    "Studio",
    "Support",
    "Sales",
  ];
  return value && allowed.includes(value) ? value : "Account";
}

/** Recover primary sign-in without turning an existing MFA challenge into setup. */
export function mfaSignInPath(returnTo:string,enroll=false):string {
 const destination=safeReturnPath(returnTo);
 const next=enroll?"/two-factor?enroll=1&returnTo="+encodeURIComponent(destination):destination;
 return "/sign-in?returnTo="+encodeURIComponent(next);
}
