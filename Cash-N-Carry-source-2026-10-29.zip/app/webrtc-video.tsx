"use client";
import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { completeIceOffer } from "./webrtc-offer";
export default function WebRTCVideo({ url }: { url: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  const [needsPlay, setNeedsPlay] = useState(false);
  const [connecting, setConnecting] = useState(true);
  const [muted, setMuted] = useState(false);
  useEffect(() => {
    setError("");
    setNeedsPlay(false);
    setConnecting(true);
    setMuted(false);
    const video = ref.current;
    if (typeof RTCPeerConnection === "undefined") {
      setError(
        "This browser cannot play the live connection. Try a current browser or contact the seller.",
      );
      return;
    }
    const pc = new RTCPeerConnection();
    const controller = new AbortController();
    let session = "",
      closed = false;
    const timer = setTimeout(() => controller.abort(), 15000);
    const closeSession = () => {
      if (!session) return;
      const endpoint = session;
      session = "";
      fetch(new URL(endpoint, url), {
        method: "DELETE",
        signal: AbortSignal.timeout(5000),
      }).catch(() => {});
    };
    let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
    const release = () => {
      if (closed) return;
      closed = true;
      clearTimeout(timer);
      clearTimeout(playbackTimer);
      clearTimeout(reconnectTimer);
      video?.removeEventListener("playing", onPlaying);
      video?.removeEventListener("loadedmetadata", play);
      controller.abort();
      pc.ontrack = null;
      pc.onconnectionstatechange = null;
      pc.close();
      closeSession();
      media.getTracks().forEach((track) => track.stop());
      if (video) {
        video.pause();
        video.srcObject = null;
      }
    };
    const fail = (message: string) => {
      if (closed) return;
      setError(message);
      setNeedsPlay(false);
      setConnecting(false);
      release();
    };
    const playbackTimer = setTimeout(() => {
      if (!closed && (!video || video.readyState < 2)) {
        fail("No picture or sound received. Retry playback.");
      }
    }, 30000);
    const onPlaying = () => {
      clearTimeout(playbackTimer);
      setNeedsPlay(false);
      setConnecting(false);
    };
    const play = () => {
      video?.play().catch(() => {
        if (!closed) {
          setNeedsPlay(true);
          setConnecting(false);
        }
      });
    };
    video?.addEventListener("playing", onPlaying);
    video?.addEventListener("loadedmetadata", play);
    pc.addTransceiver("video", { direction: "recvonly" });
    pc.addTransceiver("audio", { direction: "recvonly" });
    const media = new MediaStream();
    if (video) video.srcObject = media;
    pc.ontrack = (e) => {
      if (!closed) media.addTrack(e.track);
    };
    pc.onconnectionstatechange = () => {
      if (closed) return;
      if (pc.connectionState === "failed")
        fail("Connection failed. Retry playback.");
      else if (pc.connectionState === "disconnected") {
        setError("Connection interrupted. Attempting to reconnect…");
        if (!reconnectTimer)
          reconnectTimer = setTimeout(
            () => fail("Connection interrupted. Retry playback."),
            8000,
          );
      } else if (pc.connectionState === "connected") {
        clearTimeout(reconnectTimer);
        reconnectTimer = undefined;
        setError("");
      }
    };
    (async () => {
      try {
        const offer = await completeIceOffer(pc);
        if (closed) return;
        const r = await fetch(url, {
          method: "POST",
          signal: controller.signal,
          headers: { "Content-Type": "application/sdp" },
          body: offer,
        });
        if (!r.ok) throw Error("Broadcast is unavailable or not started.");
        session = r.headers.get("location") || "";
        if (closed) {
          closeSession();
          return;
        }
        const answer = await r.text();
        if (closed) {
          closeSession();
          return;
        }
        await pc.setRemoteDescription({ type: "answer", sdp: answer });
      } catch (e: any) {
        if (!closed) {
          fail(
            e.name === "AbortError"
              ? "The connection took too long. Retry playback."
              : e.message,
          );
        }
      } finally {
        clearTimeout(timer);
      }
    })();
    return release;
  }, [url, attempt]);
  return (
    <>
      <video
        ref={ref}
        autoPlay
        playsInline
        aria-label="Live broadcast"
      />
      <button
        type="button"
        className="live-audio-toggle"
        aria-label={muted ? "Turn live sound on" : "Mute live sound"}
        aria-pressed={muted}
        onClick={() => {
          const video = ref.current;
          if (!video) return;
          video.muted = !video.muted;
          setMuted(video.muted);
        }}
      >
        {muted ? <VolumeX aria-hidden="true" /> : <Volume2 aria-hidden="true" />}
      </button>
      {connecting && !error && (
        <div className="live-video-connecting" role="status">
          <span aria-hidden="true" />
          <span>Connecting to seller’s stream…</span>
        </div>
      )}
      {needsPlay && !error && (
        <div className="stream-error" role="status">
          <button
            onClick={() => {
              ref.current
                ?.play()
                .then(() => setNeedsPlay(false))
                .catch(() =>
                  setError("Playback could not start. Retry playback."),
                );
            }}
          >
            Play broadcast with sound
          </button>
        </div>
      )}
      {error && (
        <div className="stream-error" role="alert">
          {error}
          <button
            className="secondary-button"
            onClick={() => setAttempt((x) => x + 1)}
          >
            Retry playback
          </button>
        </div>
      )}
    </>
  );
}
