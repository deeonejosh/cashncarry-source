import { redirect } from "next/navigation";
import { getChatGPTUser } from "../../chatgpt-auth";
import BrandLogo from "../../brand-logo";
import SellerNavigation from "../navigation";
import LiveHistoryPanel from "../live-history-panel";

export const dynamic = "force-dynamic";
export const metadata = { title: "Livestream history — Cash N Carry", robots: { index: false, follow: false } };

export default async function Page() {
  if (!(await getChatGPTUser())) redirect("/sign-in?returnTo=%2Fseller%2Flive-history");
  return <main className="workspace-page seller-live-history-page" id="main-content">
    <BrandLogo tagline />
    <div className="seller-live-history-layout"><SellerNavigation active="Livestream history"/><LiveHistoryPanel/></div>
  </main>;
}
