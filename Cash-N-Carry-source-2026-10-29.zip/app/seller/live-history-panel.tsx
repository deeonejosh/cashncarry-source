"use client";

import { useEffect, useState } from "react";

type StreamSummary = {
  id: string;
  title: string;
  created: string;
  scheduled?: string | null;
  status: string;
  replay?: string | null;
  unique_viewers?: number | null;
  views?: number | null;
  peak_viewers?: number | null;
  products_pinned?: number | null;
  product_clicks?: number | null;
  cart_adds?: number | null;
  checkout_starts?: number | null;
  likes?: number | null;
  attributed_orders?: number | null;
  attributed_revenue?: number | null;
};

const money = (value: number | null | undefined) =>
  typeof value === "number"
    ? new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(value)
    : "Not recorded";

const date = (value: string | null | undefined) => {
  if (!value) return "Date unavailable";
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp)
    ? new Intl.DateTimeFormat("en-NG", { dateStyle: "medium", timeStyle: "short", timeZone: "Africa/Lagos" }).format(timestamp) + " WAT"
    : "Date unavailable";
};
const rate = (count: number | null | undefined, total: number | null | undefined) => {
  const viewers = Number(total || 0);
  return viewers ? `${Math.round((Number(count || 0) / viewers) * 100)}%` : "—";
};

export default function LiveHistoryPanel() {
  const [streams, setStreams] = useState<StreamSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [replayBusy, setReplayBusy] = useState("");
  const [replayMessages, setReplayMessages] = useState<Record<string, string>>({});

  async function load() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/seller-analytics?days=365", { cache: "no-store" });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Livestream history is unavailable.");
      setStreams(Array.isArray(payload.livestreams) ? payload.livestreams : []);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Livestream history is unavailable.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  async function uploadReplay(streamId: string, file: File) {
    setReplayBusy(streamId);
    setReplayMessages((current) => ({ ...current, [streamId]: "" }));
    try {
      if (!["video/mp4", "video/webm", "video/quicktime"].includes(file.type))
        throw Error("Choose an MP4, WebM or QuickTime video.");
      if (file.size > 40 * 1024 * 1024) throw Error("Choose a replay video up to 40 MB.");
      const form = new FormData();
      form.set("file", file);
      const upload = await fetch("/api/media", { method: "POST", body: form });
      const uploaded: any = await upload.json();
      if (!upload.ok || !uploaded.url) throw Error(uploaded.error || "Replay upload failed.");
      const publish = await fetch("/api/streams", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "replay", id: streamId, replay: uploaded.url }),
      });
      const result: any = await publish.json();
      if (!publish.ok) throw Error(result.error || "Replay could not be published.");
      setStreams((current) => current.map((stream) => stream.id === streamId ? { ...stream, replay: result.replay } : stream));
      setReplayMessages((current) => ({ ...current, [streamId]: "Replay published. Buyers can watch it from Live." }));
    } catch (reason) {
      setReplayMessages((current) => ({ ...current, [streamId]: reason instanceof Error ? reason.message : "Replay upload failed." }));
    } finally {
      setReplayBusy("");
    }
  }

  return (
    <section className="seller-live-history" aria-labelledby="seller-live-history-title">
      <header className="seller-live-history-heading">
        <div><p className="eyebrow">SELLER CENTRE</p><h2 id="seller-live-history-title">Livestream history</h2><p>Past broadcasts and their recorded summaries.</p></div>
        <button type="button" className="secondary-button" onClick={() => void load()} disabled={loading}>Refresh history</button>
      </header>
      {error && <div className="finance-alert" role="alert"><p>{error}</p><button type="button" className="secondary-button" onClick={() => void load()} disabled={loading}>Retry</button></div>}
      {loading ? <p role="status" aria-busy="true">Loading livestream history…</p> : streams.length ? (
        <div className="seller-live-history-list">
          {streams.map((stream) => (
            <details className="seller-live-history-item" key={stream.id}>
              <summary>
                <span className="seller-live-history-title"><strong>{stream.title || "Untitled livestream"}</strong><small>{date(stream.created || stream.scheduled)}</small></span>
                <span className={`seller-live-history-status is-${stream.status.toLowerCase()}`}>{stream.status}</span>
                <span className="seller-live-history-expand">View summary</span>
              </summary>
              <dl className="seller-live-history-summary">
                <div><dt>Views</dt><dd>{stream.views ?? "Not recorded"}</dd></div>
                <div><dt>Unique viewers</dt><dd>{stream.unique_viewers ?? "Not recorded"}</dd></div>
                <div><dt>Peak viewers</dt><dd>{stream.peak_viewers ?? "Not recorded"}</dd></div>
                <div><dt>Likes</dt><dd>{stream.likes ?? "Not recorded"}</dd></div>
                <div><dt>Products pinned</dt><dd>{stream.products_pinned ?? "Not recorded"}</dd></div>
                <div><dt>Product click rate</dt><dd>{rate(stream.product_clicks, stream.unique_viewers)}</dd></div>
                <div><dt>Added to bag</dt><dd>{stream.cart_adds ?? 0}</dd></div>
                <div><dt>Checkout starts</dt><dd>{stream.checkout_starts ?? 0}</dd></div>
                <div><dt>Confirmed orders</dt><dd>{stream.attributed_orders ?? "Not recorded"}</dd></div>
                <div><dt>Viewer to order</dt><dd>{rate(stream.attributed_orders, stream.unique_viewers)}</dd></div>
                <div><dt>Verified sales</dt><dd>{money(stream.attributed_revenue)}</dd></div>
              </dl>
              {stream.status === "ended" && (stream.replay ? <p><a className="seller-live-replay-link" href={stream.replay} target="_blank" rel="noreferrer">Open published replay</a></p> : <div className="seller-live-replay-upload"><label>Upload a replay video (MP4, WebM or QuickTime · up to 40 MB)<input type="file" accept="video/mp4,video/webm,video/quicktime" disabled={replayBusy === stream.id} onChange={(event) => { const file = event.currentTarget.files?.[0]; event.currentTarget.value = ""; if (file) void uploadReplay(stream.id, file); }}/></label>{replayBusy === stream.id && <p role="status">Uploading and publishing replay…</p>}{replayMessages[stream.id] && <p role="status">{replayMessages[stream.id]}</p>}</div>)}
              <p className="seller-live-history-note">Viewer activity is counted only when optional analytics consent is available. Sales include verified paid and delivered orders attributed to this broadcast.</p>
            </details>
          ))}
        </div>
      ) : <div className="seller-live-history-empty"><h3>No livestreams yet</h3><p>Completed broadcasts and their summaries will appear here.</p></div>}
    </section>
  );
}
