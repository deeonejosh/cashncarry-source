import {redirect} from "next/navigation";
import {getChatGPTUser} from "../../chatgpt-auth";
import SellerCompetitivePanel from "../competitive-panel";
export const dynamic="force-dynamic";
export const metadata={title:"Seller growth tools — Cash N Carry",robots:{index:false,follow:false}};
export default async function Page({searchParams}:{searchParams:Promise<{tab?:string}>}){
 const requested=(await searchParams).tab||"";
 const legacyLiveTab=requested==="Live Deals"||requested==="Auctions";
 if(!await getChatGPTUser())redirect(`/sign-in?returnTo=${encodeURIComponent(legacyLiveTab?"/seller/live-history":"/seller/competitive")}`);
 if(legacyLiveTab)redirect("/seller/live-history");
 return <SellerCompetitivePanel/>;
}
