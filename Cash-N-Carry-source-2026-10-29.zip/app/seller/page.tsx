import { redirect } from "next/navigation";
import { getChatGPTUser } from "../chatgpt-auth";
export const dynamic = "force-dynamic";
/** One entry point for both the website and Android Account tab. */
export default async function SellerCentre() {
  if (!(await getChatGPTUser())) redirect("/sign-in?returnTo=%2Fseller");
  // Keep the legacy Seller Centre URL as an alias to the single canonical
  // seller dashboard instead of maintaining a second overview destination.
  redirect("/?browse=1&sellerTab=Overview#seller");
}
