"use client";

import { useEffect, useState } from "react";
import { Copy, ExternalLink, Share2, Store, UploadCloud, X } from "lucide-react";
import SellerNavigation from "../navigation";
import ImageAsset from "../../image-asset";
import { readableButtonText } from "../../storefront-button-color";

const DEFAULT_ACCENT = "#164b35";
const DEFAULT_BACKGROUND = "#fff8ef";
const DEFAULT_SURFACE = "#ffffff";
const DEFAULT_BUY_NOW_COLOR = "#164b35";

export default function StoreBuilder({ hasStore, suspended = false }: { hasStore: boolean; suspended?: boolean }) {
  const [form, setForm] = useState<any>({
    slug: "", template: "market", accent: DEFAULT_ACCENT, buyNowColor: DEFAULT_BUY_NOW_COLOR,
    backgroundColor: DEFAULT_BACKGROUND, surfaceColor: DEFAULT_SURFACE, logo: "", banner: "", promoBanner: "", featuredProducts: [],
  });
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [exists, setExists] = useState(false);
  const [published, setPublished] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [newStore, setNewStore] = useState<any>({ name: "", location: "", phone: "", category: "" });

  useEffect(() => {
    let active = true;
    Promise.all([
      fetch("/api/storefront?preview=1").then((r) => r.ok ? r.json() : null),
      fetch("/api/commerce").then((r) => r.ok ? r.json() : null),
    ]).then((results) => {
      const [site, commerce] = results as any[];
      if (!active) return;
      const storefront = site?.storefront;
      if (storefront) {
        setExists(true);
        setPublished(Boolean(storefront.published));
        setForm({
          slug: storefront.slug,
          name: storefront.display_name || "",
          description: storefront.description || "",
          category: storefront.category || "",
          // All seller stores use the shared Cash N Carry storefront layout.
          template: "market",
          accent: storefront.accent || DEFAULT_ACCENT,
          backgroundColor: storefront.background_color || DEFAULT_BACKGROUND,
          surfaceColor: storefront.surface_color || DEFAULT_SURFACE,
          buyNowColor: storefront.buy_now_color || DEFAULT_BUY_NOW_COLOR,
          logo: storefront.logo || "",
          banner: storefront.banner || "",
          promoBanner: storefront.promo_banner || "",
          featuredProducts: JSON.parse(storefront.featured_products || "[]"),
        });
      }
      setProducts(commerce?.myProducts || []);
      setCategories(commerce?.categories || []);
      if (commerce?.myStore) {
        setNewStore({ name: commerce.myStore.name, location: commerce.myStore.location, phone: commerce.myStore.phone, category: commerce.myStore.category });
      }
    }).catch(() => {
      if (active) setError("We could not load your store settings. Refresh and try again.");
    });
    return () => { active = false; };
  }, []);

  const set = (key: string, value: any) => setForm((current: any) => ({ ...current, [key]: value }));

  const upload = async (field: "logo" | "banner" | "promoBanner", file?: File) => {
    if (!file) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const body = new FormData();
      body.set("file", file);
      const response = await fetch("/api/media", { method: "POST", body });
      const data: any = await response.json();
      if (!response.ok) throw Error(data.error || "Upload failed");
      set(field, data.url);
      setNotice(field === "logo" ? "Profile image uploaded. Save to apply it to your store." : field === "banner" ? "Cover image uploaded. Save to apply it to your store." : "Promotional banner uploaded. Save to apply it to your store.");
    } catch (e: any) {
      setError(e.message || "Upload failed. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  const save = async (publish: boolean) => {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const response = await fetch("/api/storefront", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, published: publish }),
      });
      const data: any = await response.json();
      if (!response.ok) throw Error(data.error || "Unable to save your store.");
      setExists(true);
      setPublished(publish);
      setForm((current: any) => ({ ...current, slug: data.slug }));
      setNotice(publish ? "Your website is live. Share this link with customers." : "Draft saved. Review the preview, then publish when ready.");
    } catch (e: any) {
      setError(e.message || "Unable to save your store.");
    } finally {
      setBusy(false);
    }
  };

  const share = async () => {
    const url = new URL("/store/" + form.slug, window.location.origin).href;
    try {
      if (navigator.share) await navigator.share({ title: "Shop " + (form.name || "my Cash N Carry store"), url });
      else {
        await navigator.clipboard.writeText(url);
        setNotice("Store link copied.");
      }
    } catch {
      setNotice("Copy the store link from the address bar.");
    }
  };

  const createStore = async () => {
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "store", ...newStore }),
      });
      const data: any = await response.json();
      if (!response.ok) throw Error(data.error || "Unable to create your seller profile.");
      window.location.reload();
    } catch (e: any) {
      setError(e.message || "Unable to create your seller profile.");
    } finally {
      setBusy(false);
    }
  };

  if (suspended) return <>
    <SellerNavigation active="My Website" />
    <section className="store-builder-empty"><span className="eyebrow">MY WEBSITE</span><h1>Manage My Store</h1><p role="status">Your existing Cash N Carry store is suspended. Storefront changes are unavailable until the suspension is resolved.</p><a className="primary" href="/seller/finance?tab=Activation">View seller status</a></section>
  </>;

  if (!hasStore) return <>
    <SellerNavigation active="My Website" />
    <section className="store-builder-empty">
      <span className="eyebrow">MY WEBSITE</span><h1>Create Your Free Store</h1>
      <p>Build your own online store, showcase your products and videos, and share your store link with customers.</p>
      <p>Basic storefront creation is free. Selling, orders and livestreams still follow Cash N Carry verification and subscription requirements.</p>
      <div className="new-store-profile">
        <label className="field">Business name<input value={newStore.name} maxLength={100} onChange={(e) => setNewStore({ ...newStore, name: e.target.value })} /></label>
        <label className="field">Location<input value={newStore.location} maxLength={100} placeholder="City or state" onChange={(e) => setNewStore({ ...newStore, location: e.target.value })} /></label>
        <label className="field">Contact phone<input value={newStore.phone} type="tel" maxLength={30} onChange={(e) => setNewStore({ ...newStore, phone: e.target.value })} /></label>
        <label className="field">Business category<select value={newStore.category} onChange={(e) => setNewStore({ ...newStore, category: e.target.value })}><option value="">Choose a category</option>{categories.map((category: any) => <option key={category.name} value={category.name}>{category.name}</option>)}</select></label>
        {error && <p role="alert">{error}</p>}
        <button className="primary" disabled={busy} onClick={() => void createStore()}>{busy ? "Creating…" : "Create Your Free Store"}</button>
      </div>
    </section>
  </>;

  return <div className="seller-website-layout">
    <SellerNavigation active="My Website" />
    <main className="seller-website-builder">
      <header>
        <p className="eyebrow">SELLER CENTRE · MY WEBSITE</p>
        <h1>{exists ? "Design My Store" : "Create Your Free Store"}</h1>
        <p>Make the storefront yours. Add your profile image and cover, choose your colours, and see the changes in the preview.</p>
        <p className="seller-website-free">Your products, approved videos and livestreams stay connected automatically. Reviews appear on each product page.</p>
      </header>

      {published && <div className="website-live-banner"><strong>Website published</strong><a href={"/store/" + form.slug} target="_blank" rel="noreferrer"><ExternalLink size={16} /> View live website</a><button type="button" onClick={() => void share()}><Share2 size={16} /> Share Store Link</button><button type="button" onClick={() => navigator.clipboard.writeText(new URL("/store/" + form.slug, window.location.origin).href)}><Copy size={16} /> Copy link</button></div>}

      <div className="website-builder-grid">
        <section className="panel website-builder-form" aria-label="Store design settings">
          <div className="website-editor-section">
            <span className="website-section-number">01</span>
            <div><h2>Store identity</h2><p>Set the name and short introduction buyers see first.</p></div>
          </div>
          <label className="field">Store name<input maxLength={100} value={form.name || ""} placeholder="Uses your seller name if left blank" onChange={(e) => set("name", e.target.value)} /></label>
          <label className="field">About your store<textarea maxLength={1000} value={form.description || ""} placeholder="What should customers know about your store?" onChange={(e) => set("description", e.target.value)} /></label>
          <label className="field">Category<input maxLength={60} value={form.category || ""} placeholder="For example: Fashion" onChange={(e) => set("category", e.target.value)} /></label>

          <div className="website-editor-section">
            <span className="website-section-number">02</span>
            <div><h2>Photos</h2><p>Use your logo or profile picture and a wide cover image.</p></div>
          </div>
          <div className="website-media-controls">
            <div className="website-media-control">
              <label className="field">Store logo<input type="file" accept="image/png,image/jpeg,image/webp" disabled={busy} onChange={(e) => { void upload("logo", e.currentTarget.files?.[0]); e.currentTarget.value = ""; }} /><small>Shown beside your name in the storefront header and on product pages.</small></label>
              <div className="website-media-preview website-media-avatar">{form.logo ? <ImageAsset src={form.logo} alt="Current store profile" width="72" height="72" /> : <span>{(form.name || "S").slice(0, 1)}</span>}{form.logo && <button type="button" className="website-media-remove" aria-label="Remove profile photo" onClick={() => set("logo", "")}><X size={14} /></button>}</div>
            </div>
            <div className="website-media-control">
              <label className="field">Cover / background photo<input type="file" accept="image/png,image/jpeg,image/webp" disabled={busy} onChange={(e) => { void upload("banner", e.currentTarget.files?.[0]); e.currentTarget.value = ""; }} /></label>
              {form.banner ? <div className="website-media-preview website-media-banner"><ImageAsset src={form.banner} alt="Current storefront cover" width="320" height="112" /><button type="button" className="website-media-remove" aria-label="Remove cover photo" onClick={() => set("banner", "")}><X size={14} /></button></div> : <div className="website-media-hint"><UploadCloud size={18} /><span>Cover photo preview</span></div>}
            </div>
          </div>
          <div className="website-media-control website-promo-control">
            <label className="field">Promotional banner<input type="file" accept="image/png,image/jpeg,image/webp" disabled={busy} onChange={(e) => { void upload("promoBanner", e.currentTarget.files?.[0]); e.currentTarget.value = ""; }} /></label>
            {form.promoBanner ? <div className="website-media-preview website-media-banner"><ImageAsset src={form.promoBanner} alt="Current storefront promotional banner" width="320" height="90" /><button type="button" className="website-media-remove" aria-label="Remove promotional banner" onClick={() => set("promoBanner", "")}><X size={14} /></button></div> : <div className="website-media-hint"><UploadCloud size={18} /><span>Optional promotional banner</span></div>}
          </div>

          <div className="website-editor-section">
            <span className="website-section-number">03</span>
            <div><h2>Colours and layout</h2><p>Choose the page, card and section backgrounds plus your store’s signature colour.</p></div>
          </div>
          <div className="website-color-controls">
            <label className="website-color-field"><span>Brand colour</span><input type="color" aria-label="Choose brand colour" value={form.accent || DEFAULT_ACCENT} onChange={(e) => set("accent", e.target.value)} /><code>{form.accent || DEFAULT_ACCENT}</code></label>
            <label className="website-color-field"><span>Page background</span><input type="color" aria-label="Choose page background colour" value={form.backgroundColor || DEFAULT_BACKGROUND} onChange={(e) => set("backgroundColor", e.target.value)} /><code>{form.backgroundColor || DEFAULT_BACKGROUND}</code></label>
            <label className="website-color-field"><span>Cards &amp; section backgrounds</span><input type="color" aria-label="Choose product card and section background colour" value={form.surfaceColor || DEFAULT_SURFACE} onChange={(e) => set("surfaceColor", e.target.value)} /><code>{form.surfaceColor || DEFAULT_SURFACE}</code></label>
            <label className="website-color-field"><span>Buy Now button colour</span><input type="color" aria-label="Choose Buy Now button colour" value={form.buyNowColor || DEFAULT_BUY_NOW_COLOR} onChange={(e) => set("buyNowColor", e.target.value)} /><code>{form.buyNowColor || DEFAULT_BUY_NOW_COLOR}</code></label>
          </div>
          <p className="website-color-help">Cards &amp; section backgrounds control the storefront search, product cards, overview panel, collections, filters and other white panels. Choose any colour; the preview updates immediately. Save or publish to apply it.</p>
          <label className="field">Store link<input maxLength={48} value={form.slug || ""} placeholder="your-store-name" onChange={(e) => set("slug", e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))} /><small>www.cashncarryng.com/store/{form.slug || "your-store-name"}</small></label>

          <fieldset className="website-featured"><legend>Featured products</legend>{products.length ? products.slice(0, 100).map((product) => <label key={product.id}><input type="checkbox" checked={form.featuredProducts.includes(product.id)} onChange={(e) => set("featuredProducts", e.target.checked ? [...form.featuredProducts, product.id].slice(0, 8) : form.featuredProducts.filter((id: string) => id !== product.id))} />{product.name}</label>) : <p>Products you publish later will sync automatically.</p>}<small>Select up to 8. Prices, stock and product details always come from your catalogue.</small></fieldset>

          <p className="website-eligibility-note">Publishing a storefront does not change seller verification or subscription rules for products, orders or livestream selling.</p>
          {error && <p role="alert" className="notice error">{error}</p>}
          {notice && <p role="status" className="notice">{notice}</p>}
          <div className="website-actions"><button type="button" disabled={busy} onClick={() => void save(false)}>Save Draft</button><button type="button" className="primary" disabled={busy} onClick={() => void save(true)}>{busy ? "Saving…" : "Publish Website"}</button></div>
        </section>

        <section className="website-preview-wrap" aria-label="Live storefront preview">
          <div className="website-preview-label"><h2>Live preview</h2><span>Updates as you design</span></div>
          <div className={`website-preview template-${form.template}`} style={{ "--store-accent": form.accent || DEFAULT_ACCENT, "--store-background": form.backgroundColor || DEFAULT_BACKGROUND, "--store-surface": form.surfaceColor || DEFAULT_SURFACE, "--store-surface-text": readableButtonText(form.surfaceColor || DEFAULT_SURFACE), "--store-buy-now-color": form.buyNowColor || DEFAULT_BUY_NOW_COLOR } as React.CSSProperties}>
            <div className="website-preview-cover" style={form.banner ? { backgroundImage: `linear-gradient(90deg,${form.accent}bb,transparent),url("${form.banner}")` } : { background: `linear-gradient(120deg,${form.accent},${form.backgroundColor})` }} />
            <div className="website-preview-brand">
              <div className="website-preview-avatar">{form.logo ? <ImageAsset src={form.logo} alt="" width="56" height="56" /> : <span>{(form.name || "S").slice(0, 1)}</span>}</div>
              <div><strong>{form.name || "Your store name"}</strong><small>{form.description || "A short introduction to your store."}</small><span className="website-preview-rating">Customer ratings stay with each product</span></div>
              <span className="website-preview-follow">Follow</span>
            </div>
            <label className="website-preview-search"><span>Search products in this store</span><span className="website-preview-search-icon">⌕</span></label>
            <div className="website-preview-tabs"><span>All products</span><span>{form.category || "Your categories"}</span></div>
            <h3>Featured products</h3>
            <div className="website-preview-products">{(products.filter((product) => !form.featuredProducts.length || form.featuredProducts.includes(product.id)).slice(0, 4)).map((product) => <article key={product.id}><img src={product.image} alt=""/><strong>{product.name}</strong><small>₦{Number(product.price).toLocaleString("en-NG")}</small><span className="website-preview-buy" style={{ backgroundColor: form.buyNowColor || DEFAULT_BUY_NOW_COLOR, color: readableButtonText(form.buyNowColor || DEFAULT_BUY_NOW_COLOR) }}>Buy now</span></article>)}</div>
            {form.promoBanner && <ImageAsset className="website-preview-promo" src={form.promoBanner} alt="Promotional banner preview" width="480" height="120" />}
            <div className="website-preview-bottom"><span>Cash N Carry</span><span>Help &amp; policies · Delivery · Returns · Privacy · Terms</span></div>
          </div>
          <p className="website-preview-tip"><UploadCloud size={16} /> Your current products, approved videos and livestream schedule appear on the live store. Customer reviews stay with their product pages.</p>
        </section>
      </div>
    </main>
  </div>;
}
