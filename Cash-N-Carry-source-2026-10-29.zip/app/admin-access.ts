import { sessionHasMfa, type MfaSession } from "./mfa-proof";
import { env } from "cloudflare:workers";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { authAvailable, getAuth } from "./auth";
import type { ChatGPTUser } from "./chatgpt-auth";
import {
  canAdmin,
  type AdminRole,
  type AdminPermission,
} from "./admin-permissions";
export function isOwnerIdentity(user: ChatGPTUser | null): boolean {
  const email = env.REVIBE_ADMIN_EMAIL?.trim().toLowerCase();
  return Boolean(email && user && user.email.trim().toLowerCase() === email);
}
async function adminRoleUserIds(user: ChatGPTUser): Promise<string[]> {
  const ids = [user.userId];
  const matches = await env.DB!.prepare(
    "SELECT id FROM profiles WHERE lower(email)=lower(?) LIMIT 2",
  )
    .bind(user.email)
    .all<{ id: string }>();
  // Email fallback is safe only when it identifies exactly one application
  // profile. Keep direct-ID lookup available for legacy assignments.
  if (matches.results?.length === 1 && !ids.includes(matches.results[0].id))
    ids.push(matches.results[0].id);
  return ids;
}
export async function assignedAdminRole(
  user: ChatGPTUser | null,
): Promise<AdminRole | null> {
  if (!user || !env.DB) return null;
  if (isOwnerIdentity(user)) return "owner";
  const emailKey = await env.DB.prepare(
    "SELECT value FROM platform_settings WHERE key=?",
  )
    .bind("admin_role_email:" + user.email.trim().toLowerCase())
    .first<{ value: string }>();
  try {
    const data = JSON.parse(emailKey?.value || "null");
    if (
      data?.email === user.email.trim().toLowerCase() &&
      ["admin", "support", "finance", "moderator"].includes(data.role)
    )
      return data.role;
  } catch {
    // Ignore malformed pending assignments and continue with legacy IDs.
  }
  for (const id of await adminRoleUserIds(user)) {
    const row = await env.DB.prepare(
      "SELECT value FROM platform_settings WHERE key=?",
    )
      .bind("admin_role:" + id)
      .first<{ value: string }>();
    try {
      const data = JSON.parse(row?.value || "null");
      if (
        data?.email === user.email.trim().toLowerCase() &&
        ["admin", "support", "finance", "moderator"].includes(data.role)
      )
        return data.role;
    } catch {
      // Ignore malformed or stale legacy records and continue fail-closed.
    }
  }
  return null;
}
/** Email identity alone is insufficient: require verified Better Auth MFA session. */
export async function adminRole(
  user: ChatGPTUser | null,
): Promise<AdminRole | null> {
  const role = await assignedAdminRole(user);
  if (!role || !user || !(await authAvailable())) return null;
  const session = await (
    await getAuth()
  ).api.getSession({ headers: await headers() });
  if (
    !session?.user.emailVerified ||
    session.user.email.toLowerCase() !== user.email.toLowerCase() ||
    !(session.user as { twoFactorEnabled?: boolean }).twoFactorEnabled
  )
    return null;
  if (!(await sessionHasMfa(session as MfaSession))) return null;
  const suspended = await env
    .DB!.prepare("SELECT MAX(CASE WHEN suspended!=0 THEN 1 ELSE 0 END) AS suspended FROM profiles WHERE id=? OR lower(email)=lower(?)")
    .bind(user.userId, user.email)
    .first<{ suspended: number }>();
  return suspended?.suspended ? null : role;
}
export async function isAdmin(
  user: ChatGPTUser | null,
  permission: AdminPermission = "overview",
): Promise<boolean> {
  return canAdmin(await adminRole(user), permission);
}
export async function requireAdminMfa(user: ChatGPTUser, returnTo: string) {
  if (!(await assignedAdminRole(user)) || await adminRole(user)) return;
  const suspended = await env.DB!.prepare("SELECT MAX(CASE WHEN suspended!=0 THEN 1 ELSE 0 END) AS suspended FROM profiles WHERE id=? OR lower(email)=lower(?)")
    .bind(user.userId,user.email).first<{suspended:number}>();
  if (suspended?.suspended) return;
  if (!(await authAvailable())) redirect("/sign-in?returnTo=" + encodeURIComponent(returnTo));
  const session = await (await getAuth()).api.getSession({headers:await headers()});
  if (!session?.user.emailVerified || session.user.email.toLowerCase() !== user.email.toLowerCase())
  {
    const h=await headers();
    if (h.get("oai-authenticated-user-id") === user.userId && h.get("oai-authenticated-user-email")?.toLowerCase() === user.email.toLowerCase())
      redirect("/two-factor?chatgpt=1&returnTo="+encodeURIComponent(returnTo));
    redirect("/sign-in?returnTo=" + encodeURIComponent(returnTo));
  }
  const enrolled = Boolean((session.user as {twoFactorEnabled?:boolean}).twoFactorEnabled);
  redirect("/two-factor?enroll=" + (enrolled ? "0" : "1") + "&returnTo=" + encodeURIComponent(returnTo));
}
