"use client";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { X } from "lucide-react";

export function LiveSheet({
  title,
  onClose,
  children,
  className = "",
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  className?: string;
}) {
  const panel = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    // Lock the page behind the sheet, not the broadcast or its media tracks.
    document.body.style.overflow = "hidden";
    const sheet = panel.current;
    const focusable = sheet?.querySelector<HTMLElement>(
      'button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href]'
    );
    (focusable ?? sheet)?.focus({ preventScroll: true });
    return () => {
      document.body.style.overflow = previousOverflow;
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, []);
  return (
    <div className="live-sheet-backdrop" onClick={onClose}>
      <div
        className={`live-sheet ${className}`.trim()}
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => {
          if (e.key === "Escape") {
            e.preventDefault();
            e.stopPropagation();
            onClose();
          }
          if (e.key === "Tab") {
            e.stopPropagation();
            const controls = Array.from(
              e.currentTarget.querySelectorAll<HTMLElement>(
                "button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], summary",
              ),
            ).filter((el) => el.getClientRects().length > 0);
            const first = controls[0],
              last = controls.at(-1);
            if (!first) {
              e.preventDefault();
              e.currentTarget.focus();
              return;
            }
            if (!controls.includes(document.activeElement as HTMLElement)) {
              e.preventDefault();
              (e.shiftKey ? last : first)?.focus();
              return;
            }
            if (e.shiftKey && document.activeElement === first) {
              e.preventDefault();
              last?.focus();
            } else if (!e.shiftKey && document.activeElement === last) {
              e.preventDefault();
              first?.focus();
            }
          }
        }}
      >
        <header>
          <h2>{title}</h2>
          <button aria-label={"Close " + title} onClick={onClose}>
            <X />
          </button>
        </header>
        {children}
      </div>
    </div>
  );
}
export function LiveAction({
  label,
  icon,
  count,
  ...props
}: {
  label: string;
  icon: ReactNode;
  count?: number;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button type="button" className="live-rail-action" aria-label={label} title={label} {...props}>
      <span className="live-rail-circle">
        {icon}
        {count !== undefined && (
          <span className="live-action-count">{count}</span>
        )}
      </span>
      <span className="live-rail-label">{label}</span>
    </button>
  );
}
export function ElapsedBroadcast({ startedAt }: { startedAt: number | null }) {
  const [now, setNow] = useState(0);
  useEffect(() => {
    const initialFrame = requestAnimationFrame(() => setNow(Date.now()));
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => { cancelAnimationFrame(initialFrame); clearInterval(timer); };
  }, []);
  if (startedAt === null) return null;
  const seconds = Math.max(0, Math.floor((now - startedAt) / 1000));
  const elapsed = `${Math.floor(seconds / 60)
    .toString()
    .padStart(2, "0")}:${(seconds % 60).toString().padStart(2, "0")}`;
  return (
    <span aria-label={"Elapsed broadcast time " + elapsed}>{elapsed}</span>
  );
}
