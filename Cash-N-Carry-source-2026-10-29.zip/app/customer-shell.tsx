"use client";
import {
  Home,
  ShoppingBag,
  UserRound,
  ShoppingCart,
  ArrowLeft,
  Search,
  MessageSquare,
  Plus,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { lazy, Suspense, useEffect,useState } from "react";
import BrandLogo from "./brand-logo";
const VideoCreation = lazy(() => import("./video-creation"));
type CreationAccount = { user?: unknown; myProducts?: Array<{id:string;name:string;price:number;stock:number;active:boolean}>; myStore?: {name?:string}|null; sellerAccess?: {canSell?:boolean;verification?:string}|null; services?: {stream?:boolean} };
export function UnreadMessagesCount(){
  const [count,setCount]=useState(0);
  useEffect(()=>{let active=true;const load=async()=>{try{const r=await fetch("/api/messages?summary=unread",{cache:"no-store",signal:AbortSignal.timeout(8000)});if(r.ok){const b:any=await r.json();if(active)setCount(Number(b.total_unread)||0);}}catch{}};const refresh=()=>{if(document.visibilityState==="visible")void load();};void load();const timer=setInterval(refresh,15000);document.addEventListener("visibilitychange",refresh);window.addEventListener("focus",refresh);return()=>{active=false;clearInterval(timer);document.removeEventListener("visibilitychange",refresh);window.removeEventListener("focus",refresh);};},[]);
  return count>0?<span className="unread-nav-badge" aria-label={`${count} unread messages`}>{count>99?"99+":count}</span>:null;
}
const links = [
  ["Home", "/?browse=1&view=home#home", Home],
  ["Shop", "/?browse=1&view=market#market", ShoppingBag],
  ["Messages", "/messages", MessageSquare],
  ["Profile", "/account", UserRound],
] as const;
export function CustomerHeader({
  active = "",
  back = "/?browse=1&view=market#market",
  showBrand = true,
  showMessages = true,
}: {
  active?: string;
  back?: string;
  showBrand?: boolean;
  showMessages?: boolean;
}) {
  return (
    <header className="customer-header">
      <a href={back} className="icon-control" aria-label="Back to shopping">
        <ArrowLeft size={22} />
      </a>
      {showBrand && <BrandLogo />}
      <Link className="customer-search-link" href="/?browse=1&view=market#market"><Search size={18} aria-hidden="true" /><span>Search products and sellers</span></Link>
      <nav aria-label="Customer navigation">
        {[["Home", "/?browse=1&view=home#home", Home] as const, ["Shop", "/?browse=1&view=market#market", ShoppingBag] as const, ["Live", "/live", Home] as const, ["For You", "/for-you", Home] as const, ["Profile", "/account", UserRound] as const].map(([label, href]) => (
          <a
            key={label}
            href={href}
            aria-current={active === label || (label === "Profile" && active === "Account") ? "page" : undefined}
          >
            {label}
          </a>
        ))}
      </nav>
      {showMessages && <Link href="/messages" className="icon-control customer-message-link" aria-label="Buyer and seller messages"><MessageSquare size={22} /><UnreadMessagesCount/></Link>}
      <Link
        href="/?browse=1&open=cart"
        className="icon-control customer-cart"
        aria-label="Open bag"
      >
        <ShoppingCart size={23} />
      </Link>
    </header>
  );
}
export function CustomerNavigation({ active = "" }: { active?: string }) {
  const router = useRouter();
  const [creating, setCreating] = useState(false);
  const [creationData, setCreationData] = useState<CreationAccount>();
  const [creationError, setCreationError] = useState("");
  const openCreation = async () => {
    try {
      const response = await fetch("/api/commerce", { cache: "no-store" });
      const data = await response.json() as CreationAccount;
      if (!response.ok) throw new Error("Account services are temporarily unavailable. Please retry.");
      if (!data?.user) {
        router.push("/sign-in?returnTo=" + encodeURIComponent(window.location.pathname + window.location.search));
        return;
      }
      setCreationError("");
      setCreationData(data);
      setCreating(true);
    } catch (e) {
      setCreationError(e instanceof Error ? e.message : "Unable to confirm your account. Please retry.");
    }
  };
  return (
    <>
      <nav className="customer-bottom-nav" aria-label="Customer navigation">
        {links.slice(0, 2).map(([label, href, Icon]) => (
          <a key={label} href={href} aria-current={active === label || (label === "Profile" && active === "Account") ? "page" : undefined} aria-label={label}>
            <Icon size={22} aria-hidden="true" /><span>{label}</span>
          </a>
        ))}
        <button type="button" className="customer-create-button" onClick={() => void openCreation()} aria-label="Create video or go live" title="Create video or go live">
          <span className="customer-create-button-core"><Plus size={27} strokeWidth={3} aria-hidden="true" /></span><span className="sr-only">Create</span>
        </button>
        {links.slice(2).map(([label, href, Icon]) => (
          <a key={label} href={href} className={label === "Messages" ? "customer-message-link" : undefined} aria-current={active === label ? "page" : undefined} aria-label={label}>
            <span className="customer-nav-icon-wrap"><Icon size={22} aria-hidden="true" />{label === "Messages" && <UnreadMessagesCount />}</span><span>{label}</span>
          </a>
        ))}
      </nav>
      {creationError && <p className="creation-entry-error" role="alert">{creationError}<button type="button" onClick={() => void openCreation()}>Retry</button></p>}
      {creating && <Suspense fallback={null}><VideoCreation initialData={creationData} onClose={() => setCreating(false)} /></Suspense>}
    </>
  );
}
export function PageHeading({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="design-page-heading">
      <div>
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {children}
    </div>
  );
}
