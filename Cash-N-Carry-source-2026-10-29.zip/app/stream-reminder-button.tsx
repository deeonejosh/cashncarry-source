"use client";
import { useEffect, useState } from "react";
import { Bell, BellRing } from "lucide-react";

export default function StreamReminderButton({ streamId }: { streamId: string }) {
  const [reminded, setReminded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    let active = true;
    fetch("/api/stream-reminders?stream=" + encodeURIComponent(streamId), { cache: "no-store" })
      .then(async (response) => {
        const result = await response.json().catch(() => ({}));
        if (active && response.ok) setReminded(Boolean(result.reminded));
      })
      .catch(() => undefined);
    return () => { active = false; };
  }, [streamId]);

  async function toggle() {
    if (busy) return;
    setBusy(true);
    setMessage("");
    try {
      const action = reminded ? "remove" : "set";
      const response = await fetch("/api/stream-reminders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, stream: streamId }),
      });
      const result = await response.json().catch(() => ({}));
      if (response.status === 401) {
        window.location.assign("/sign-in?returnTo=" + encodeURIComponent(window.location.pathname + window.location.search));
        return;
      }
      if (!response.ok) throw Error(result.error || "Reminder could not be saved.");
      setReminded(Boolean(result.reminded));
      setMessage(result.reminded ? "Reminder set. We’ll notify you in Cash N Carry up to one hour before the stream." : "Reminder removed");
    } catch (error: any) {
      setMessage(error?.message || "Reminder could not be saved.");
    } finally {
      setBusy(false);
    }
  }

  return <div className="live-reminder-control">
    <button type="button" className="live-reminder-button" title="Cash N Carry will add an in-app notification before the scheduled livestream." aria-pressed={reminded} disabled={busy} onClick={() => void toggle()}>
      {reminded ? <BellRing size={15} aria-hidden="true" /> : <Bell size={15} aria-hidden="true" />}
      {busy ? "Saving…" : reminded ? "Reminder set" : "Remind me"}
    </button>
    {message && <span role="status">{message}</span>}
  </div>;
}
