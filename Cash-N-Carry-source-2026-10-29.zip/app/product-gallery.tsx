"use client";
import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Maximize2, X } from "lucide-react";
import ImageAsset from "./image-asset";
import { storefrontImageSrcSet, storefrontImageUrl } from "./storefront-image-url";
export default function ProductGallery({
  name,
  images,
  video,
}: {
  name: string;
  images: string[];
  video?: string;
}) {
  const safeImages = images.filter(Boolean);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [zoomed, setZoomed] = useState(false);
  const selected = safeImages[selectedIndex] || "";
  useEffect(() => {
    if (!zoomed) return;
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") setZoomed(false); };
    document.addEventListener("keydown", closeOnEscape);
    document.body.classList.add("product-image-viewer-open");
    return () => { document.removeEventListener("keydown", closeOnEscape); document.body.classList.remove("product-image-viewer-open"); };
  }, [zoomed]);
  const step = (direction: number) => setSelectedIndex((index) => (index + direction + safeImages.length) % safeImages.length);
  return (
    <section className="public-product-gallery" aria-label="Product photos">
      <div className="public-product-main-image">
      <ImageAsset
        src={storefrontImageUrl(selected, 640)}
        srcSet={storefrontImageSrcSet(selected, [480, 640, 960, 1200, 1600])}
        sizes="(max-width: 720px) 100vw, (max-width: 1200px) 50vw, 640px"
        fallbackSrc={selected}
        alt={name}
        className="public-product-image"
        onClick={() => selected && setZoomed(true)}
        role={selected ? "button" : undefined}
        tabIndex={selected ? 0 : undefined}
        onKeyDown={(event: React.KeyboardEvent<HTMLImageElement>) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); setZoomed(true); } }}
        loading="eager"
        fetchPriority="high"
      />
      {safeImages.length > 1 && <>
        <button type="button" className="product-gallery-arrow product-gallery-prev" aria-label="Previous product image" onClick={() => step(-1)}><ChevronLeft size={22}/></button>
        <button type="button" className="product-gallery-arrow product-gallery-next" aria-label="Next product image" onClick={() => step(1)}><ChevronRight size={22}/></button>
      </>}
      {selected && <button type="button" className="product-gallery-zoom" aria-label="View product image full screen" onClick={() => setZoomed(true)}><Maximize2 size={18}/></button>}
      </div>
      <div className="public-product-thumbnails">
        {safeImages.length > 1 &&
          safeImages.map((image, i) => (
            <button
              key={image}
              aria-label={"View photo " + (i + 1)}
              aria-pressed={selectedIndex === i}
              onClick={() => setSelectedIndex(i)}
            >
              <ImageAsset
                src={storefrontImageUrl(image, 160)}
                srcSet={storefrontImageSrcSet(image, [160])}
                sizes="80px"
                fallbackSrc={image}
                alt=""
                width={80}
                height={80}
              />
            </button>
          ))}
      </div>
      {video && (
        <video
          src={video}
          poster={images[0]}
          controls
          playsInline
          preload="none"
          aria-label={name + " product video"}
        />
      )}
      {zoomed && <div className="product-image-viewer" role="dialog" aria-modal="true" aria-label={`${name} image viewer`} onClick={(event) => { if (event.target === event.currentTarget) setZoomed(false); }}>
        <button type="button" className="product-image-viewer-close" aria-label="Close image viewer" onClick={() => setZoomed(false)}><X size={24}/></button>
        {safeImages.length > 1 && <button type="button" className="product-gallery-arrow product-gallery-prev" aria-label="Previous product image" onClick={() => step(-1)}><ChevronLeft size={24}/></button>}
        <ImageAsset src={storefrontImageUrl(selected, 1600)} srcSet={storefrontImageSrcSet(selected, [640, 960, 1200, 1600])} sizes="100vw" fallbackSrc={selected} alt={name} />
        {safeImages.length > 1 && <button type="button" className="product-gallery-arrow product-gallery-next" aria-label="Next product image" onClick={() => step(1)}><ChevronRight size={24}/></button>}
      </div>}
    </section>
  );
}
