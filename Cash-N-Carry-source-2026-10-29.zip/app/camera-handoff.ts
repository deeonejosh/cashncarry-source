"use client";

type CameraHandoff = { stream: MediaStream; facing: "user" | "environment" };

// A soft route from the + camera to Live Studio should keep the camera stream
// alive. This short-lived module handoff avoids opening a second camera.
let pendingCamera: CameraHandoff | null = null;

export function handoffCamera(stream: MediaStream, facing: "user" | "environment") {
  pendingCamera?.stream.getTracks().forEach((track) => track.stop());
  pendingCamera = { stream, facing };
}

export function takeCameraHandoff(): CameraHandoff | null {
  const camera = pendingCamera;
  pendingCamera = null;
  return camera;
}
