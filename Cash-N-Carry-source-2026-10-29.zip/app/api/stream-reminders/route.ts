import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { ensureCompetitiveSchema } from "../../competitive-schema";
import { limit } from "../../security";

const json = (body: any, status = 200) =>
  Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
const q = (sql: string, ...args: any[]) => env.DB!.prepare(sql).bind(...args);

export async function GET(req: Request) {
  try {
    await ensureCompetitiveSchema();
    const user = await getChatGPTUser();
    if (!user) return json({ error: "Sign in to manage reminders." }, 401);
    const stream = new URL(req.url).searchParams.get("stream") || "";
    if (!stream || stream.length > 100) return json({ error: "Livestream not found." }, 400);
    const row = await q(
      "SELECT r.created,r.reminded_at FROM stream_reminders r JOIN streams s ON s.id=r.stream WHERE r.stream=? AND r.user=? AND s.status IN ('scheduled','live')",
      stream,
      user.userId,
    ).first<any>();
    return json({ reminded: Boolean(row), remindedAt: row?.reminded_at || null });
  } catch {
    return json({ error: "Reminder status is unavailable." }, 503);
  }
}

export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return json({ error: "Invalid request origin." }, 403);
  try {
    await ensureCompetitiveSchema();
    const user = await getChatGPTUser();
    if (!user) return json({ error: "Sign in to manage reminders." }, 401);
    await limit("stream-reminder:" + user.userId, 30);
    const body: any = await req.json();
    const streamId = String(body.stream || "");
    if (!streamId || streamId.length > 100) return json({ error: "Livestream not found." }, 400);
    const stream = await q(
      "SELECT l.id,l.status,l.scheduled,s.owner FROM streams l JOIN stores s ON s.id=l.store WHERE l.id=? AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.id=s.owner AND p.suspended=1)",
      streamId,
    ).first<any>();
    if (!stream) return json({ error: "Livestream not found." }, 404);
    if (stream.owner === user.userId) return json({ error: "You cannot set a reminder for your own stream." }, 400);
    if (body.action === "remove") {
      await q("DELETE FROM stream_reminders WHERE stream=? AND user=?", streamId, user.userId).run();
      return json({ ok: true, reminded: false });
    }
    if (body.action !== "set") return json({ error: "Choose whether to set or remove the reminder." }, 400);
    const scheduled = Date.parse(stream.scheduled || "");
    if (stream.status !== "scheduled" || !Number.isFinite(scheduled) || scheduled <= Date.now())
      return json({ error: "Reminders are available for upcoming scheduled streams." }, 409);
    await q(
      "INSERT INTO stream_reminders(stream,user,created,reminded_at) VALUES(?,?,?, '') ON CONFLICT(stream,user) DO UPDATE SET created=excluded.created,reminded_at=''",
      streamId,
      user.userId,
      new Date().toISOString(),
    ).run();
    return json({ ok: true, reminded: true });
  } catch (error: any) {
    const limited = String(error?.message || "").startsWith("Too many requests");
    return json(
      { error: limited ? error.message : "The reminder could not be saved. Please retry." },
      limited ? 429 : 503,
    );
  }
}
