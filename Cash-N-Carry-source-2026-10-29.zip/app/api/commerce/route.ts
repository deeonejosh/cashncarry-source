import { requireSellerActive, sellerActivation, eligibleSellerSQL } from "../../seller-activation";
import { productPhotoProblem } from "../../product-photo-validation";
import { brand } from "../../brand";
import { cancelOnlineOrder } from "../../payments";
import { orderEmail, caseEmail, safelyEmail } from "../../email-events";
import { limit } from "../../security";
import { extraData, extraAction } from "../../commerce-extra";
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { ensureCompetitiveSchema } from "../../competitive-schema";
import { isAdmin } from "../../admin-access";
import { ensureBulkProductSchema } from "../../bulk-product-schema";
import { ensureTrustBadgeSchema } from "../../trust-badge-schema";
import { topSellerEligibilitySQL } from "../../trust-badge-eligibility";
import { ensureLiveStreamEventsSchema } from "../../live-stream-events-schema";
export const dynamic = "force-dynamic";
const json = (data: any, options: any = {}) =>
  Response.json(data, { ...options, headers: { "Cache-Control": "no-store" } });
const db = () => {
  if (!env.DB) throw Error("Storage temporarily unavailable");
  return env.DB;
};
const q = (sql: string, ...args: any[]) =>
  db()
    .prepare(sql)
    .bind(...args);
const all = async (sql: string, ...args: any[]) =>
  (await q(sql, ...args).all()).results;
const publicUsername = async (uid:string) => {
  const profile=await q("SELECT username,name FROM profiles WHERE id=?",uid).first<{username:string;name:string}>();
  return profile?.username ? "@"+profile.username : profile?.name || "Buyer";
};
const id = () => crypto.randomUUID();
const now = () => new Date().toISOString();
const str = (v: any, max = 500) =>
  String(v ?? "")
    .trim()
    .slice(0, max);
const num = (v: any, min = 0, max = 100000000) => {
  if (v === null || v === undefined || v === "" || typeof v === "boolean")
    throw Error("Please enter a valid number");
  const n = Number(v);
  if (!Number.isSafeInteger(n) || n < min || n > max)
    throw Error("Please enter a valid number");
  return n;
};
const category = (v: any) => {
  const s = str(v, 40);
  if (!s) throw Error("Choose a valid category");
  return s;
};
const phone = (v: any) => {
  const s = str(v, 30);
  if (
    !/^[+()0-9 .-]+$/.test(s) ||
    s.replace(/\D/g, "").length < 8 ||
    s.replace(/\D/g, "").length > 15
  )
    throw Error("Enter a valid contact phone number");
  return s;
};
const safeUrl = (v: any) => {
  const s = str(v, 1500);
  if (s.startsWith("/api/media/")) return s;
  const u = new URL(s);
  if (u.protocol !== "https:") throw Error("Use an HTTPS media URL");
  return u.href;
};
export async function GET(req: Request) {
  try {
    await ensureTrustBadgeSchema();
    const u = await getChatGPTUser();
    const url = new URL(req.url);
    const cacheablePublicSummary = !u && url.search === "";
    const publicSummaryCacheKey = cacheablePublicSummary
      ? new Request(`${url.origin}/__cache/public-commerce-v3`)
      : null;
    if (publicSummaryCacheKey) {
      try {
        const cached = await caches.default.match(publicSummaryCacheKey);
        if (cached) {
          const headers = new Headers(cached.headers);
          headers.set("Cache-Control", "no-store");
          return new Response(cached.body, {
            status: cached.status,
            statusText: cached.statusText,
            headers,
          });
        }
      } catch {
        // Cache is an optional acceleration; the database remains authoritative.
      }
    }
    const requestedProduct = url.searchParams.get("product");
    if (requestedProduct) {
      const product = await q(
        `SELECT p.*,s.name AS seller,(SELECT CASE WHEN f.published=1 THEN f.logo END FROM storefronts f WHERE f.store=s.id) AS seller_logo,s.location,s.description AS store_description,s.verified,s.official_store,CASE WHEN ${topSellerEligibilitySQL("s")} THEN 1 ELSE 0 END AS top_seller,s.state,s.area,s.coverage,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy,s.latitude,s.longitude FROM products p JOIN stores s ON s.id=p.store WHERE p.id=? AND p.active=1 AND s.suspended=0 AND ` + eligibleSellerSQL() + " AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
        requestedProduct.slice(0, 100),
      ).first();
      return product
        ? json({ product })
        : json(
            { error: "This product is unavailable or has been removed." },
            { status: 404 },
          );
    }
    const stream = url.searchParams.get("stream");
    if (stream) {
      const session = await q(
        `SELECT l.id,l.store,l.title,l.url,l.product,l.featured,CASE WHEN l.provider='native' AND l.status='live' AND COALESCE(julianday(l.heartbeat),0)<julianday('now','-90 seconds') THEN 'ended' ELSE l.status END AS status,l.created,l.scheduled,l.provider,l.replay,s.name AS seller,s.location AS seller_location,s.verified AS verified,s.official_store,CASE WHEN ${topSellerEligibilitySQL("s")} THEN 1 ELSE 0 END AS top_seller,CASE WHEN f.published=1 THEN f.logo END AS seller_logo FROM streams l JOIN stores s ON s.id=l.store LEFT JOIN storefronts f ON f.store=s.id WHERE l.id=? AND s.suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)`,
        stream,
      ).first();
      if (!session || (session.status === "scheduled" && !session.scheduled && (!u || !(await q("SELECT id FROM stores WHERE id=? AND owner=?", session.store, u.userId).first()))))
        return json(
          { error: "This broadcast is unavailable." },
          { status: 404 },
        );
      await ensureLiveStreamEventsSchema();
      if (!(await sellerActivation(String(session.store))).canSell) {
        const owns = u && await q("SELECT id FROM stores WHERE id=? AND owner=?", session.store, u.userId).first();
        return owns ? json({stream:{...session,status:"ended"},products:[],chats:[],viewers:0,likes:0,liked:false,reason:"Seller verification or subscription is no longer active."}) : json({error:"This broadcast is unavailable."},{status:404});
      }
      const [chatRows, systemRows] = await Promise.all([
        all(
          "SELECT c.id,CASE WHEN c.user=s.owner THEN s.name ELSE COALESCE('@'||NULLIF(p.username,''),NULLIF(p.name,''),'Buyer') END AS name,c.message,c.created,0 AS system FROM chats c JOIN streams l ON l.id=c.stream JOIN stores s ON s.id=l.store LEFT JOIN profiles p ON p.id=c.user WHERE c.stream=? AND c.hidden=0 ORDER BY c.created DESC LIMIT 80",
          stream,
        ),
        all(
          "SELECT id,name,message,created,1 AS system FROM live_stream_events WHERE stream=? ORDER BY created DESC LIMIT 80",
          stream,
        ),
      ]);
      const chats = [...chatRows, ...systemRows]
        .sort((a: any, b: any) => Date.parse(b.created) - Date.parse(a.created))
        .slice(0, 80);
      return json({
        stream: session,
        likes:
          (
            (await q(
              "SELECT COUNT(*) AS count FROM stream_likes WHERE stream=?",
              stream,
            ).first()) as any
          )?.count || 0,
        liked: u
          ? Boolean(
              await q(
                "SELECT user FROM stream_likes WHERE stream=? AND user=?",
                stream,
                u.userId,
              ).first(),
            )
          : false,
        products: await all(
          "SELECT p.*,s.name AS seller,s.location,s.coverage,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy FROM products p JOIN stores s ON s.id=p.store WHERE p.active=1 AND s.suspended=0 AND " + eligibleSellerSQL("s") + " AND (p.id=? OR p.id IN (SELECT value FROM json_each(?)))",
          session.product,
          session.featured || "[]",
        ),
        viewers:
          (
            (await q(
              "SELECT COUNT(*) AS count FROM live_viewers WHERE stream=? AND seen>?",
              stream,
              new Date(Date.now() - 45000).toISOString(),
            ).first()) as any
          )?.count || 0,

        chats,
      });
    }
    const [products, stores, streams, reviews] = await Promise.all([
      all(
        `SELECT p.*,s.name AS seller,(SELECT CASE WHEN f.published=1 THEN f.logo END FROM storefronts f WHERE f.store=s.id) AS seller_logo,s.location,s.description AS store_description,s.verified,s.official_store,CASE WHEN ${topSellerEligibilitySQL("s")} THEN 1 ELSE 0 END AS top_seller,s.state,s.area,s.coverage,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy,s.latitude,s.longitude FROM products p JOIN stores s ON s.id=p.store WHERE p.active=1 AND s.suspended=0 AND ` + eligibleSellerSQL() + " AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1) ORDER BY p.created DESC LIMIT 60",
      ),
      all(
        `SELECT stores.id,stores.name,stores.description,stores.category,stores.location,stores.verified,stores.official_store,CASE WHEN ${topSellerEligibilitySQL("stores")} THEN 1 ELSE 0 END AS top_seller,stores.state,stores.area,stores.coverage,stores.shipping_fee AS delivery_fee,stores.delivery_days,stores.return_policy,stores.latitude,stores.longitude,stores.created,CASE WHEN sf.published=1 THEN sf.logo END AS logo,CASE WHEN sf.published=1 THEN sf.banner END AS banner,CASE WHEN sf.published=1 THEN sf.slug END AS slug FROM stores LEFT JOIN storefronts sf ON sf.store=stores.id WHERE stores.suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=stores.owner AND x.suspended=1) ORDER BY stores.created DESC`,
      ),
      all(
        `SELECT l.id,l.store,l.title,l.url,l.product,l.featured,CASE WHEN l.provider='native' AND l.status='live' AND COALESCE(julianday(l.heartbeat),0)<julianday('now','-90 seconds') THEN 'ended' ELSE l.status END AS status,l.created,l.scheduled,l.provider,l.replay,s.name AS seller,s.location AS seller_location,s.verified AS verified,s.official_store,CASE WHEN ${topSellerEligibilitySQL("s")} THEN 1 ELSE 0 END AS top_seller,CASE WHEN sf.published=1 THEN sf.logo END AS seller_logo FROM streams l JOIN stores s ON s.id=l.store LEFT JOIN storefronts sf ON sf.store=s.id WHERE (l.status IN ('live','scheduled','external') OR (l.status='ended' AND l.replay!='')) AND NOT (l.provider='native' AND l.status='live' AND COALESCE(julianday(l.heartbeat),0)<julianday('now','-90 seconds')) AND NOT (l.status='scheduled' AND (l.scheduled='' OR l.scheduled<?)) AND s.suspended=0 AND ` + eligibleSellerSQL() + " AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1) ORDER BY l.created DESC",
        new Date(Date.now() - 86400000).toISOString(),
      ),
      all(
        "SELECT id,product,name,rating,comment,created FROM reviews ORDER BY created DESC,rowid DESC LIMIT 100",
      ),
    ]);
    let cart: any[] = [],
      orders: any[] = [],
      sellerOrders: any[] = [],
      myStore: any = null,
      follows: any[] = [],
      campaigns: any[] = [],
      myReports: any[] = [],
      myVerification: any = null;
    if (u) {
      myReports = await all(
        "SELECT id,target_type,reason,details,status,resolution,created FROM reports WHERE reporter=? ORDER BY created DESC",
        u.userId,
      );
      myVerification = await q(
        "SELECT id,status,note,legal_name,created FROM verification_requests WHERE owner=? ORDER BY created DESC,rowid DESC LIMIT 1",
        u.userId,
      ).first();
      myStore = await q("SELECT stores.*,stores.shipping_fee AS delivery_fee,CASE WHEN f.published=1 THEN f.logo END AS logo FROM stores LEFT JOIN storefronts f ON f.store=stores.id WHERE stores.owner=?", u.userId).first();
      [cart, orders, follows] = await Promise.all([
        all(
          "SELECT c.quantity,c.variant,p.*,s.name AS seller,s.verified,CASE WHEN f.published=1 THEN f.logo END AS seller_logo FROM carts c JOIN products p ON p.id=c.product JOIN stores s ON s.id=p.store LEFT JOIN storefronts f ON f.store=s.id WHERE c.user=?",
          u.userId,
        ),
        all(
          "SELECT o.*,s.name AS seller,s.verified,CASE WHEN f.published=1 THEN f.logo END AS seller_logo,(SELECT mode FROM payments WHERE order_id=o.id) AS payment_mode FROM orders o JOIN stores s ON s.id=o.store LEFT JOIN storefronts f ON f.store=s.id WHERE o.buyer=? ORDER BY o.created DESC",
          u.userId,
        ),
        all("SELECT store FROM follows WHERE user=?", u.userId),
      ]);
      if (myStore) {
        [sellerOrders, campaigns] = await Promise.all([
          all(
            "SELECT o.*,(SELECT mode FROM payments WHERE order_id=o.id) AS payment_mode FROM orders o WHERE store=? ORDER BY created DESC",
            myStore.id,
          ),
          all(
            "SELECT * FROM campaigns WHERE store=? ORDER BY created DESC",
            myStore.id,
          ),
        ]);
      }
      const lines = await all(
        "SELECT i.* FROM order_items i JOIN orders o ON o.id=i.order_id WHERE o.buyer=? OR o.store=?",
        u.userId,
        myStore?.id || "",
      );
      const grouped = Object.groupBy(lines, (i: any) => i.order_id);
      for (const o of [...orders, ...sellerOrders])
        o.items = grouped[o.id] || [];
    }
    for (const c of cart) {
      const v = JSON.parse(c.variants || "[]").find(
        (x: any) => x.name === c.variant,
      );
      if (v) {
        c.price = v.price;
        c.stock = v.stock;
      }
    }
    // Independent public and account lookups share one round trip window.
    const extrasPromise = extraData(u?.userId || null, myStore);
    const pinnedPromise = all("SELECT p.*,s.name AS seller,s.verified FROM products p JOIN stores s ON s.id=p.store WHERE p.active=1 AND s.suspended=0 AND " + eligibleSellerSQL() + " AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1) AND p.id IN (SELECT product FROM streams WHERE (status IN ('live','external') OR (status='scheduled' AND scheduled!='')) ORDER BY created DESC,rowid DESC LIMIT 100)");
    const myProductsPromise = myStore ? all("SELECT p.*,s.name AS seller,s.verified FROM products p JOIN stores s ON s.id=p.store WHERE p.store=? ORDER BY p.created DESC", myStore.id) : Promise.resolve([]);
    const affiliateProductsPromise=u?all("SELECT p.*,s.name AS seller,s.verified FROM affiliate_partnerships ap JOIN creator_profiles cp ON cp.user=ap.creator JOIN products p ON p.id=ap.product JOIN stores s ON s.id=p.store WHERE ap.creator=? AND ap.status='approved' AND cp.status='approved' AND p.active=1 AND s.suspended=0 AND "+eligibleSellerSQL("s")+" ORDER BY p.name",u.userId).catch(()=>[]):Promise.resolve([]);
    const [extras, pinnedProducts, myProducts, affiliateProducts] = await Promise.all([extrasPromise, pinnedPromise, myProductsPromise, affiliateProductsPromise]);
    const userProfile: any = u
      ? await q("SELECT name,username FROM profiles WHERE id=?", u.userId).first()
      : null;
    const response = json({
      user: u
        ? {
            name: userProfile?.name || u.displayName,
            username: userProfile?.username || "",
            email: u.email,
            admin: await isAdmin(u),
          }
        : null,
      products,
      pinnedProducts,
      stores,
      streams,
      reviews,
      cart,
      orders,
      sellerOrders,
      myStore,
      sellerAccess: myStore ? await sellerActivation(myStore.id) : null,
      myProducts,
      affiliateProducts,
      follows,
      campaigns,
      myReports,
      myVerification,
      ...extras,
    });
    if (publicSummaryCacheKey) {
      const headers = new Headers(response.headers);
      headers.set("Cache-Control", "public, max-age=15");
      const cacheableResponse = new Response(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers,
      });
      try {
        await caches.default.put(publicSummaryCacheKey, cacheableResponse.clone());
      } catch {
        // Cache is an optional acceleration; the database remains authoritative.
      }
      const clientHeaders = new Headers(cacheableResponse.headers);
      clientHeaders.set("Cache-Control", "no-store");
      return new Response(cacheableResponse.body, {
        status: cacheableResponse.status,
        statusText: cacheableResponse.statusText,
        headers: clientHeaders,
      });
    }
    return response;
  } catch (e: any) {
    if(/no such table:\s*(?:founding_enrollments|founding_program|affiliate_partnerships|creator_profiles|seller_analytics_events|livestream_deals|product_bundles|auction_bids|live_auctions)/i.test(String(e?.message||""))){const retry=new URL(req.url);if(retry.searchParams.get("competitive_schema_retry")!=="1"){await ensureCompetitiveSchema();retry.searchParams.set("competitive_schema_retry","1");return GET(new Request(retry,req));}}
    console.error("commerce_request_failed");
    return json(
      { error: "Unable to load " + brand.name + ". Please retry." },
      { status: 503 },
    );
  }
}
export async function POST(req: Request) {
  try {
    await ensureBulkProductSchema();
    await ensureCompetitiveSchema();
    if (req.headers.get("origin") !== new URL(req.url).origin)
      return json({ error: "Invalid request origin" }, { status: 403 });
    const u = await getChatGPTUser();
    if (!u) return json({ error: "Sign in to continue" }, { status: 401 });
    const b: any = await req.json();
    if (!b || typeof b !== "object" || Array.isArray(b))
      throw Error("Invalid request");
    const a = b.action;
    const uid = u.userId;
    await limit("commerce:" + uid, 90);
    // Profile creation/activity is an explicit authenticated mutation, never a read.
    await q("INSERT INTO profiles(id,email,name,suspended,created,last_seen) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email,last_seen=excluded.last_seen", uid, u.email, u.displayName || u.email, 0, now(), now()).run();
    const profile: any = await q(
      "SELECT suspended FROM profiles WHERE id=?",
      uid,
    ).first();
    if (profile?.suspended && a !== "report")
      throw Error(
        "Your account is suspended. Contact " + brand.name + " support.",
      );
    const store: any = await q(
      "SELECT *,shipping_fee AS delivery_fee FROM stores WHERE owner=?",
      uid,
    ).first();
    const needStore = () => {
      if (!store) throw Error("Create your storefront first");
      if (store.suspended)
        throw Error(
          "Your store is suspended. Contact " + brand.name + " support.",
        );
    };
    if (["product", "stream", "pin"].includes(a)) { needStore(); await requireSellerActive(store.id); }
    const extra = await extraAction(b, u, store, req);
    if (extra) return json(extra);
    if (
      ["store", "product"].includes(a) &&
      !(await q(
        "SELECT id FROM categories WHERE name=? AND active=1",
        str(b.category, 40),
      ).first())
    )
      throw Error("Choose an active category");
    if (a === "store") {
      if (store?.suspended) throw Error("Your store is suspended");
      if (!str(b.name) || !str(b.location) || !str(b.phone))
        throw Error("Store name, location and phone are required");
      if (store)
        await q(
          "UPDATE stores SET name=?,description=?,category=?,location=?,phone=? WHERE owner=?",
          str(b.name, 100),
          str(b.description, 1000),
          category(b.category),
          str(b.location, 100),
          phone(b.phone),
          uid,
        ).run();
      else
        await q(
          "INSERT INTO stores(id,owner,name,description,category,location,phone,created) VALUES(?,?,?,?,?,?,?,?)",
          id(),
          uid,
          str(b.name, 100),
          str(b.description, 1000),
          category(b.category),
          str(b.location, 100),
          phone(b.phone),
          now(),
        ).run();
    } else if (a === "product") {
      needStore();
      const approval: any = await q(
        "SELECT value FROM platform_settings WHERE key='seller_approval_required'",
      ).first();
      if (approval?.value === "1" && !store.verified)
        throw Error(
          "Business verification approval is required before creating or editing products. Submit verification in your workspace.",
        );
      if (!str(b.name) || !str(b.description))
        throw Error("Product name and description are required");
      const variants = b.variants ? JSON.parse(b.variants) : [];
      if (!Array.isArray(variants) || variants.length > 40)
        throw Error("Use up to 40 variants");
      const names = new Set();
      for (const v of variants) {
        v.name = str(v.name, 100);
        if (!v.name || names.has(v.name))
          throw Error("Variant names must be unique");
        names.add(v.name);
        v.price = num(v.price, 100);
        v.stock = num(v.stock, 0, 100000);
      }
      const images = b.images ? JSON.parse(b.images) : [];
      if (!Array.isArray(images) || images.length > 8)
        throw Error("Use up to 8 photos");
      const canonicalMedia = (url: any) => {
        const parsed = new URL(safeUrl(url), req.url);
        if (
          parsed.origin === new URL(req.url).origin &&
          parsed.pathname.startsWith("/api/media/")
        ) {
          const key = decodeURIComponent(parsed.pathname.slice(11));
          if (!/^[a-zA-Z0-9_-]+$/.test(key))
            throw Error("Invalid uploaded media link");
          return "/api/media/" + key;
        }
        return safeUrl(url);
      };
      b.image = str(b.image, 1500) ? canonicalMedia(b.image) : "";
      for (const photo of [b.image, ...images]) {
        const problem = productPhotoProblem(String(photo), true, false);
        if (problem) throw Error(problem);
      }
      if (b.video) b.video = canonicalMedia(b.video);
      for (let i = 0; i < images.length; i++)
        images[i] = canonicalMedia(images[i]);
      for (const url of [b.image, b.video, ...images].filter(Boolean)) {
        const parsed = new URL(safeUrl(url), req.url);
        if (
          parsed.origin !== new URL(req.url).origin ||
          !parsed.pathname.startsWith("/api/media/")
        )
          continue;
        const key = decodeURIComponent(parsed.pathname.slice(11));
        if (await q("SELECT key FROM media_blocks WHERE key=?", key).first())
          throw Error(
            "This media was removed from public listings. Ask an administrator to review it.",
          );
        const media = await env.BUCKET?.head(key);
        if (!media)
          throw Error("Uploaded media is unavailable. Upload the file again.");
        const legacy =
          !media.customMetadata?.owner &&
          (await q(
            "SELECT p.id FROM products p JOIN stores s ON s.id=p.store WHERE s.owner=? AND (p.image IN (?,?) OR p.video IN (?,?) OR EXISTS(SELECT 1 FROM json_each(p.images) WHERE value IN (?,?))) LIMIT 1",
            uid,
            parsed.pathname,
            parsed.href,
            parsed.pathname,
            parsed.href,
            parsed.pathname,
            parsed.href,
          ).first());
        if (media.customMetadata?.owner !== uid && !legacy)
          throw Error("Use media uploaded by your own seller account.");
      }
      const vals = [
        str(b.name, 100),
        str(b.sku, 80),
        str(b.description, 2000),
        category(b.category),
        num(b.price, 100),
        variants.length
          ? variants.reduce((n: any, v: any) => n + v.stock, 0)
          : num(b.stock, 0, 100000),
        b.image ? safeUrl(b.image) : "",
        b.video ? safeUrl(b.video) : "",
        JSON.stringify(images),
        JSON.stringify(variants),
      ];
      const sku = str(b.sku, 80);
      if (sku && !/^[A-Za-z0-9][A-Za-z0-9._/-]{0,79}$/.test(sku))
        throw Error("SKU may contain letters, numbers, dots, underscores, slashes and hyphens.");
      if (sku && await q("SELECT id FROM products WHERE store=? AND lower(sku)=lower(?) AND id!=? LIMIT 1", store.id, sku, b.id || "").first())
        throw Error("This SKU is already used by one of your products.");
      if (b.id) {
        const p = await q(
          "SELECT id FROM products WHERE id=? AND store=?",
          b.id,
          store.id,
        ).first();
        if (!p) throw Error("Product not found");
        await q(
          "UPDATE products SET name=?,sku=?,description=?,category=?,price=?,stock=?,image=?,video=?,images=?,variants=? WHERE id=? AND store=?",
          ...vals,
          b.id,
          store.id,
        ).run();
      } else
        await q(
          "INSERT INTO products(id,store,name,sku,description,category,price,stock,image,video,images,variants,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
          id(),
          store.id,
          ...vals,
          now(),
        ).run();
    } else if (a === "archive") {
      needStore();
      await q(
        "UPDATE products SET active=0 WHERE id=? AND store=?",
        str(b.id),
        store.id,
      ).run();
    } else if (a === "cart_resume") {
      if (!/^[a-f0-9-]{36}$/.test(b.request_id || ""))
        throw Error("Invalid cart request");
      const product = str(b.product, 100),
        variant = str(b.variant, 100),
        quantity = num(b.quantity, 1, 99);
      const receipt = () =>
        q(
          "SELECT * FROM cart_resumptions WHERE id=? AND user=?",
          b.request_id,
          uid,
        ).first<any>();
      const matches = (r: any) =>
        r &&
        r.product === product &&
        r.variant === variant &&
        r.quantity === quantity;
      const previous = await receipt();
      if (previous) {
        if (!matches(previous))
          throw Error("Cart request changed. Choose the product again.");
        return json({ ok: true, resumed: true });
      }
      // One atomic batch: repeated submissions cannot add the same intent twice.
      const target = "CASE WHEN c.variant=? THEN c.quantity+? ELSE ? END";
      await env.DB!.batch([
        q(
          `INSERT INTO carts(id,user,product,quantity,variant)
           SELECT ?,?,p.id,${target},? FROM products p JOIN stores s ON s.id=p.store
           LEFT JOIN carts c ON c.product=p.id AND c.user=?
           WHERE p.id=? AND p.active=1 AND s.suspended=0 AND ${eligibleSellerSQL()}
           AND NOT EXISTS(SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)
           AND NOT EXISTS(SELECT 1 FROM cart_resumptions WHERE id=?)
           AND ${target} BETWEEN 1 AND 99
           AND ${target} <= CASE WHEN json_array_length(p.variants)>0 THEN
             (SELECT json_extract(value,'$.stock') FROM json_each(p.variants) WHERE json_extract(value,'$.name')=? LIMIT 1) ELSE p.stock END
           ON CONFLICT(user,product) DO UPDATE SET quantity=excluded.quantity,variant=excluded.variant`,
          id(),
          uid,
          variant,
          quantity,
          quantity,
          variant,
          uid,
          product,
          b.request_id,
          variant,
          quantity,
          quantity,
          variant,
          quantity,
          quantity,
          variant,
        ),
        q(
          "INSERT INTO cart_resumptions(id,user,product,variant,quantity,created) SELECT ?,?,?,?,?,? WHERE changes()=1",
          b.request_id,
          uid,
          product,
          variant,
          quantity,
          now(),
        ),
      ]);
      if (!matches(await receipt()))
        throw Error(
          "Product or option unavailable, or not enough stock. Review your selection and retry.",
        );
      return json({ ok: true, resumed: true });
    } else if (a === "cart") {
      const quantity = num(b.quantity, 0, 99);
      if (quantity === 0) {
        await q(
          "DELETE FROM carts WHERE user=? AND product=?",
          uid,
          str(b.product),
        ).run();
        return json({ ok: true });
      }
      const p: any = await q(
        "SELECT p.* FROM products p JOIN stores s ON s.id=p.store WHERE p.id=? AND p.active=1 AND s.suspended=0 AND " + eligibleSellerSQL() + " AND NOT EXISTS(SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
        str(b.product),
      ).first();
      if (!p) throw Error("Product unavailable");
      const variants = JSON.parse(p.variants || "[]");
      const selected = variants.find(
        (v: any) => v.name === str(b.variant, 100),
      );
      if (variants.length && !selected) throw Error("Choose a product variant");
      if (quantity > (selected?.stock ?? p.stock))
        throw Error("Not enough stock available");
      if (quantity === 0)
        await q(
          "DELETE FROM carts WHERE user=? AND product=?",
          uid,
          p.id,
        ).run();
      else
        await q(
          "INSERT INTO carts(id,user,product,quantity,variant) VALUES(?,?,?,?,?) ON CONFLICT(user,product) DO UPDATE SET quantity=excluded.quantity,variant=excluded.variant",
          id(),
          uid,
          p.id,
          quantity,
          selected?.name || "",
        ).run();
    } else if (a === "checkout") {
      throw Error("Checkout is unavailable. Please refresh and choose Debit card payment.");
    } else if (a === "cancel") {
      const o: any = await q(
        "SELECT id,status,payment,payment_status FROM orders WHERE id=? AND buyer=?",
        str(b.id),
        uid,
      ).first();
      if (o?.payment === "flutterwave") {
        if (o.status !== "placed")
          throw Error("Contact support for this order");
        await cancelOnlineOrder(o);
        await safelyEmail(()=>orderEmail(o.id,"cancelled"));
        return json({ ok: true });
      }
      if (!o || o.status !== "placed")
        throw Error(
          "Only your unconfirmed orders can be cancelled. Contact the seller for later changes.",
        );
      const cancelled: any = await q(
        "UPDATE orders SET status='cancelled' WHERE id=? AND buyer=? AND status='placed' AND payment!='flutterwave'",
        o.id,
        uid,
      ).run();
      if (Number(cancelled.meta?.changes ?? cancelled.changes) !== 1)
        return json(
          { error: "Order changed during cancellation. Refresh and retry." },
          { status: 409 },
        );
      await safelyEmail(()=>orderEmail(o.id,"cancelled"));
    } else if (a === "status") {
      needStore();
      const o: any = await q(
        "SELECT * FROM orders WHERE id=? AND store=?",
        str(b.id),
        store.id,
      ).first();
      if (!o) throw Error("Order not found");
      if (o.payment === "auction" && o.payment_status !== "paid" && b.status !== "cancelled")
        throw Error("Auction orders are unpaid and cannot be fulfilled until payment is available and verified.");
      if (o.payment === "flutterwave" && b.status === "cancelled")
        throw Error(
          "Online orders must be cancelled through verified payment reconciliation",
        );
      if (
        o.payment === "flutterwave" &&
        o.payment_status !== "paid" &&
        b.status !== "cancelled"
      )
        throw Error("Payment must be verified before fulfilment");
      if (
        o.payment === "flutterwave" &&
        o.payment_status === "paid" &&
        b.status === "cancelled"
      )
        throw Error("Open a refund case before cancelling a paid order");
      const transitions: any = {
        placed: ["confirmed", "cancelled"],
        confirmed: ["shipped", "cancelled"],
        shipped: ["delivered"],
      };
      if (!transitions[o.status]?.includes(b.status))
        throw Error("Invalid order status change");
      const statements = [
        q(
          "UPDATE orders SET status=? WHERE id=? AND store=? AND status=? AND (payment!='flutterwave' OR payment_status='paid') AND (payment!='auction' OR payment_status='paid' OR ?='cancelled')",
          b.status,
          o.id,
          store.id,
          o.status,
          b.status,
        ),
      ];
      const changed: any = await db().batch(statements);
      if (Number(changed[0]?.meta?.changes ?? changed[0]?.changes) !== 1)
        return json(
          { error: "Order changed while updating. Refresh and retry." },
          { status: 409 },
        );
      if (["confirmed","shipped","delivered","cancelled"].includes(b.status))
        await safelyEmail(()=>orderEmail(o.id,b.status));
    } else if (a === "stream") {
      needStore();
      if (!str(b.title)) throw Error("Give your live session a title");
      const media = safeUrl(b.url);
      if (media.startsWith("https://")) {
        const host = new URL(media).hostname;
        if (
          [
            "tiktok.com",
            "youtube.com",
            "youtu.be",
            "instagram.com",
            "facebook.com",
          ].some((d) => host === d || host.endsWith("." + d))
        )
          throw Error(
            "This is a social-platform page link. Use a direct live video stream URL to play inside " +
              brand.name +
              ".",
          );
      }
      if (
        await q(
          "SELECT id FROM streams WHERE store=? AND status='live'",
          store.id,
        ).first()
      )
        throw Error("End your current live session before starting another.");
      if (
        b.product &&
        !(await q(
          "SELECT id FROM products WHERE id=? AND store=? AND active=1",
          str(b.product),
          store.id,
        ).first())
      )
        throw Error("Choose one of your products");
      await q(
        "INSERT INTO streams(id,store,title,url,product,status,created) VALUES(?,?,?,?,?,?,?)",
        id(),
        store.id,
        str(b.title, 150),
        media,
        str(b.product),
        "live",
        now(),
      ).run();
    } else if (a === "endstream") {
      needStore();
      // Native sessions must revoke the provider input through /api/streams.
      // The legacy external-stream action must never merely hide a broadcast
      // while leaving its publisher credentials and media session active.
      const target: any = await q("SELECT provider FROM streams WHERE id=? AND store=?", str(b.id), store.id).first();
      if (!target) throw Error("Choose your own broadcast");
      if (target.provider === "native") throw Error("End native broadcasts from Live Studio so the streaming provider can confirm termination.");
      await q(
        "UPDATE streams SET status='ended' WHERE id=? AND store=? AND provider!='native'",
        str(b.id),
        store.id,
      ).run();
    } else if (a === "pin") {
      needStore();
      const broadcast:any=await q("SELECT id,product,featured FROM streams WHERE id=? AND store=?",str(b.id),store.id).first();
      if (!broadcast)
        throw Error("Choose your own broadcast");
      if (!str(b.product)) {
        await q("UPDATE streams SET product='',featured='[]' WHERE id=? AND store=?",str(b.id),store.id).run();
        return json({ ok: true });
      }
      const productId=str(b.product),owned:any=await q("SELECT id,stock FROM products WHERE id=? AND store=? AND active=1",productId,store.id).first();
      if(owned && Number(owned.stock)<1) throw Error("This product is sold out. Choose an available product to pin.");
      if(!owned){const partner:any=await q("SELECT ap.id FROM affiliate_partnerships ap JOIN creator_profiles cp ON cp.user=ap.creator JOIN products p ON p.id=ap.product JOIN stores ps ON ps.id=p.store WHERE ap.creator=? AND ap.product=? AND ap.status='approved' AND cp.status='approved' AND p.active=1 AND p.stock>0 AND ps.suspended=0 AND "+eligibleSellerSQL("ps"),uid,productId).first();if(!partner)throw Error("Product must be yours or covered by an approved affiliate partnership.");}
      // A live has one pinned product. Replacing it also replaces the featured list
      // so older products cannot remain pinned for buyers on a stale client.
      await q("UPDATE streams SET product=?,featured=? WHERE id=? AND store=?",productId,JSON.stringify([productId]),str(b.id),store.id).run();
    } else if (a === "stream-like") {
      const target = str(b.stream, 100);
      if (typeof b.liked !== "boolean") throw Error("Choose a valid reaction");
      const available = await q(
        "SELECT l.id FROM streams l JOIN stores s ON s.id=l.store WHERE l.id=? AND l.status IN ('live','external') AND s.suspended=0 AND " + eligibleSellerSQL() + " AND NOT EXISTS(SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
        target,
      ).first();
      if (!available)
        throw Error("Reactions are unavailable for this broadcast");
      if (b.liked)
        await q(
          "INSERT OR IGNORE INTO stream_likes(stream,user,created) VALUES(?,?,?)",
          target,
          uid,
          now(),
        ).run();
      else
        await q(
          "DELETE FROM stream_likes WHERE stream=? AND user=?",
          target,
          uid,
        ).run();
    } else if (a === "chat") {
      if (!str(b.message)) throw Error("Enter a message");
      if (
        !(await q(
          "SELECT id FROM streams WHERE id=? AND status IN ('live','external')",
          str(b.stream),
        ).first())
      )
        throw Error("This live session has ended");
      if (
        await q(
          "SELECT user FROM live_blocks WHERE stream=? AND user=?",
          str(b.stream),
          uid,
        ).first()
      )
        throw Error("You cannot send messages in this broadcast");
      if(await q("SELECT user FROM live_chat_mutes WHERE stream=? AND user=? AND muted_until>?",str(b.stream),uid,now()).first())
        throw Error("You are muted in this broadcast for a short time");
      const recent: any = await q(
        "SELECT created FROM chats WHERE user=? ORDER BY created DESC,rowid DESC LIMIT 1",
        uid,
      ).first();
      if (recent && Date.now() - Date.parse(recent.created) < 1500)
        throw Error("Please wait a moment before sending again");
      await q(
        "INSERT INTO chats(id,stream,user,name,message,created) VALUES(?,?,?,?,?,?)",
        id(),
        str(b.stream),
        uid,
        await publicUsername(uid),
        str(b.message, 400),
        now(),
      ).run();
    } else if (a === "follow") {
      if (!(await q("SELECT id FROM stores WHERE id=?", str(b.store)).first()))
        throw Error("Store not found");
      if (b.follow)
        await q(
          "INSERT INTO follows(id,user,store) VALUES(?,?,?) ON CONFLICT(user,store) DO NOTHING",
          id(),
          uid,
          str(b.store),
        ).run();
      else
        await q(
          "DELETE FROM follows WHERE user=? AND store=?",
          uid,
          str(b.store),
        ).run();
    } else if (a === "review") {
      const o: any = await q(
        "SELECT o.id FROM orders o JOIN order_items i ON i.order_id=o.id WHERE o.id=? AND o.buyer=? AND o.status='delivered' AND i.product=?",
        str(b.order),
        uid,
        str(b.product),
      ).first();
      if (!o) throw Error("Only delivered purchases can be reviewed");
      if (!str(b.comment)) throw Error("Write a short review");
      await q(
        "INSERT INTO reviews(id,buyer,product,order_id,name,rating,comment,created) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(buyer,product,order_id) DO UPDATE SET rating=excluded.rating,comment=excluded.comment",
        id(),
        uid,
        str(b.product),
        o.id,
        await publicUsername(uid),
        num(b.rating, 1, 5),
        str(b.comment, 1000),
        now(),
      ).run();
    } else if (a === "report") {
      const kind = str(b.target_type, 20),
        target = str(b.target, 150);
      const tables: any = {
        product: "products",
        store: "stores",
        stream: "streams",
        order: "orders",
        return: "orders",
      };
      if (!tables[kind]) throw Error("Choose a valid report type");
      const record: any = await q(
        `SELECT * FROM ${tables[kind]} WHERE id=?`,
        target,
      ).first();
      if (!record) throw Error("The reported item could not be found");
      if ((kind === "order" || kind === "return") && record.buyer !== uid)
        throw Error("You can only open a case for your own order");
      if (kind === "return" && record.status !== "delivered")
        throw Error("Returns are available for delivered orders");
      if (!str(b.reason) || str(b.details).length < 10)
        throw Error(
          "Add a reason and at least 10 characters describing the issue",
        );
      if (
        await q(
          "SELECT id FROM reports WHERE reporter=? AND target_type=? AND target=? AND status IN ('open','in_review')",
          uid,
          kind,
          target,
        ).first()
      )
        throw Error("You already have an open case for this item");
      const caseId=id();
      await q(
        "INSERT INTO reports(id,reporter,target_type,target,reason,details,status,resolution,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?)",
        caseId,
        uid,
        kind,
        target,
        str(b.reason, 100),
        str(b.details, 2000),
        "open",
        "",
        now(),
        now(),
      ).run();
      await safelyEmail(()=>caseEmail(caseId));
    } else if (a === "campaign") {
      needStore();
      if (!str(b.title)) throw Error("Give your campaign a title");
      await q(
        "INSERT INTO campaigns(id,store,title,goal,budget,days,location,status,created) VALUES(?,?,?,?,?,?,?,?,?)",
        id(),
        store.id,
        str(b.title, 150),
        str(b.goal, 60),
        num(b.budget, 1000),
        num(b.days, 1, 90),
        str(b.location, 100),
        "draft",
        now(),
      ).run();
    } else throw Error("Unknown action");
    return json({ ok: true });
  } catch (e: any) {
    console.error("commerce_request_failed");
    return json(
      {
        error: e.message?.includes("Stock or price changed")
          ? "A product price or stock changed. Review your cart and try again."
          : e.message?.includes("CHECK constraint")
            ? "Stock changed while you were shopping. Please update your cart."
            : e.message?.includes("D1_ERROR")
              ? "Unable to save this request. Please refresh and retry."
              : e.message || "Unable to save. Please retry.",
      },
      { status: 400 },
    );
  }
}
