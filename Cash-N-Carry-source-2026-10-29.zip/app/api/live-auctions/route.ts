import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { ensureCompetitiveSchema } from "../../competitive-schema";
import { requireSellerActive } from "../../seller-activation";
import { sellerActivation } from "../../seller-activation";
import { isAdmin } from "../../admin-access";
import { settleAuction, settleExpiredAuctions } from "../../auction-settlement";
import { ensureLiveStreamEventsSchema } from "../../live-stream-events-schema";

const q=(sql:string,...args:any[])=>env.DB!.prepare(sql).bind(...args);
const json=(b:any,s=200)=>Response.json(b,{status:s,headers:{"Cache-Control":"no-store"}});
const now=()=>new Date().toISOString();
const changed=(r:any)=>Number(r?.meta?.changes??r?.changes??0);

export async function GET(req:Request){
 try{
  await ensureCompetitiveSchema();await ensureLiveStreamEventsSchema(); const stamp=now();
  const u=await getChatGPTUser(),stream=new URL(req.url).searchParams.get("stream")||"";
  let pinnedAuction="";
  const owner=u&&!stream?(await q("SELECT id FROM stores WHERE owner=?",u.userId).first<any>())?.id:"";
  if(stream){const live:any=await q("SELECT id,pinned_auction FROM streams WHERE id=? AND status IN ('live','external')",stream).first();if(!live)return json({auctions:[],pinnedAuction:""});pinnedAuction=live.pinned_auction||"";}
  if(!stream&&!owner)return json({auctions:[]});
  const historySince=new Date(Date.parse(stamp)-6*60*60*1000).toISOString();
  const rows=await q(`SELECT a.*,p.name AS product_name,p.image,p.price AS listed_price,p.stock,s.name AS seller,s.shipping_fee AS shipping_fee,s.coverage AS delivery_coverage,
      CASE WHEN s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles owner_profile WHERE owner_profile.id=s.owner AND owner_profile.suspended=1) THEN 1 ELSE 0 END AS verified,
      o.payment_status AS order_payment_status,o.total AS order_total,o.delivery_fee AS order_delivery_fee,
      (SELECT MAX(n.created) FROM notifications n WHERE n.user=s.owner AND n.id LIKE 'auction-payment-attempt:'||o.id||':%') AS payment_attempt_failed_at,
      (SELECT MAX(amount) FROM auction_bids WHERE auction=a.id) AS highest_bid,
      (SELECT bidder FROM auction_bids WHERE auction=a.id ORDER BY amount DESC,created ASC LIMIT 1) AS highest_bidder,
      (SELECT COALESCE('@'||NULLIF(pf.username,''),NULLIF(pf.name,''),'Buyer') FROM auction_bids hb LEFT JOIN profiles pf ON pf.id=hb.bidder WHERE hb.auction=a.id ORDER BY hb.amount DESC,hb.created ASC LIMIT 1) AS highest_bidder_name,
      (SELECT COUNT(*) FROM auction_bids WHERE auction=a.id) AS bid_count,
      EXISTS(SELECT 1 FROM live_stream_events WHERE id='auction-result:'||a.id) AS result_event_published,
      (SELECT '@'||COALESCE(NULLIF(pf.username,''),NULLIF(pf.name,''),'Buyer') FROM auction_bids wb LEFT JOIN profiles pf ON pf.id=wb.bidder WHERE wb.id=a.winning_bid LIMIT 1) AS winner_name,
      (SELECT amount FROM auction_bids WHERE id=a.winning_bid LIMIT 1) AS winning_amount
    FROM live_auctions a JOIN products p ON p.id=a.product JOIN stores s ON s.id=a.store LEFT JOIN orders o ON o.id=a.order_id
    WHERE ((?<>'' AND a.stream=? AND (a.status IN ('scheduled','active') OR (a.status='ended' AND a.updated>=?))) OR (?='' AND a.store=?))
      AND s.suspended=0 AND (p.active=1 OR a.status='ended') ORDER BY CASE WHEN a.status IN ('active','scheduled') THEN 0 ELSE 1 END,a.starts_at ASC LIMIT 100`,stream,stream,historySince,stream,owner).all();
  const auctions:any[]=[];
  for(const a of rows.results as any[]){
    const mine=u?await q("SELECT id FROM stores WHERE owner=? AND id=?",u!.userId,a.store).first():null;
    const myMaxBid=u?await q("SELECT max_amount FROM auction_max_bids WHERE auction=? AND bidder=?",a.id,u!.userId).first<any>():null;
    const bids=(await q("SELECT b.amount,b.created,COALESCE('@'||NULLIF(p.username,''),NULLIF(p.name,''),'Buyer') AS bidder_name FROM auction_bids b LEFT JOIN profiles p ON p.id=b.bidder WHERE b.auction=? ORDER BY b.amount DESC,b.created ASC LIMIT 20",a.id).all()).results;
    const sellerState=await sellerActivation(a.store);let deliveryCoverage:any[]=[];try{deliveryCoverage=JSON.parse(a.delivery_coverage||"[]");}catch{}
    const{order_payment_status,order_total,order_delivery_fee,payment_attempt_failed_at,shipping_fee,delivery_coverage,highest_bidder,...publicAuction}=a;
    const paymentStatus=order_payment_status==="paid"?"paid":payment_attempt_failed_at?"failed_attempt":order_payment_status;
    const effectiveStatus=["active","scheduled"].includes(a.status)&&a.ends_at<=stamp?"expired":a.status==="scheduled"&&a.starts_at<=stamp?"active":a.status;
    auctions.push({...publicAuction,status:effectiveStatus,deliveryFee:Number(shipping_fee||0),deliveryCoverage:Array.isArray(deliveryCoverage)?deliveryCoverage:[],resultEventPublished:Boolean(a.result_event_published),paymentStatus:mine?paymentStatus:undefined,orderTotal:mine?order_total:undefined,settledDeliveryFee:mine?order_delivery_fee:undefined,canBid:effectiveStatus==="active"&&!mine&&Boolean(u)&&sellerState.canSell,myMaxBid:myMaxBid?.max_amount?Number(myMaxBid.max_amount):0,youAreLeading:Boolean(u&&a.highest_bidder===u.userId),bids});
  }
  if(!pinnedAuction&&owner&&!stream){const current=await q("SELECT pinned_auction FROM streams WHERE store=? AND status IN ('live','external') ORDER BY created DESC LIMIT 1",owner).first<any>();pinnedAuction=current?.pinned_auction||"";}
  if(stream&&pinnedAuction&&!auctions.some(a=>a.id===pinnedAuction))pinnedAuction="";
  return json({auctions,pinnedAuction});
 }catch(e:any){return json({error:e.message||"Unable to load auctions"},503);}
}

export async function POST(req:Request){
 if(req.headers.get("origin")!==new URL(req.url).origin)return json({error:"Invalid origin"},403);
 try{
  await ensureCompetitiveSchema();const b:any=await req.json(),action=String(b.action||""),stamp=now();const u=await getChatGPTUser();if(!u&&action!=="settle")return json({error:"Sign in to continue"},401);
  if(action==="create"){
   const store:any=await q("SELECT id FROM stores WHERE owner=? AND suspended=0",u!.userId).first();if(!store)throw Error("Active seller store required");await requireSellerActive(store.id);
   const product=String(b.product||""),stream=String(b.stream||""),startPrice=Number(b.startPrice),increment=Number(b.increment),reserve=b.reservePrice===""||b.reservePrice==null?null:Number(b.reservePrice),start=new Date(stamp),duration=Number(b.durationMinutes),legacyEnd=new Date(b.endsAt);
   const durationMs=Number.isSafeInteger(duration)&&duration>=1&&duration<=1440?duration*60_000:legacyEnd.getTime()-start.getTime(),end=new Date(start.getTime()+durationMs);
   if(!Number.isSafeInteger(startPrice)||startPrice<1||!Number.isSafeInteger(increment)||increment<1||(reserve!==null&&(!Number.isSafeInteger(reserve)||reserve<startPrice))||!Number.isFinite(durationMs)||durationMs<1||durationMs>24*60*60*1000)throw Error("Enter valid auction prices and a duration from 1 minute to 24 hours.");
   const p:any=await q("SELECT id,stock,active,variants FROM products WHERE id=? AND store=?",product,store.id).first();if(!p||!p.active||p.stock<1||JSON.parse(p.variants||"[]").length)throw Error("Choose an available product without variants.");
   const l:any=await q("SELECT id,status FROM streams WHERE id=? AND store=?",stream,store.id).first();if(!l||!["live","external"].includes(l.status))throw Error("Start your livestream before creating an auction. The auction will appear to buyers as soon as it is saved.");
   // Finalise due auctions before enforcing the one-open-auction rule.
   await settleExpiredAuctions();
   const existing:any=await q("SELECT a.id,a.stream,a.product,p.name AS product_name,a.start_price,a.increment,a.reserve_price,a.starts_at,a.ends_at,a.status,(SELECT MAX(amount) FROM auction_bids WHERE auction=a.id) AS highest_bid,(SELECT COUNT(*) FROM auction_bids WHERE auction=a.id) AS bid_count FROM live_auctions a JOIN products p ON p.id=a.product WHERE a.stream=? AND a.product=? AND a.status IN ('active','scheduled') AND a.ends_at>? ORDER BY a.created DESC LIMIT 1",stream,product,stamp).first();
   if(existing){
    const activeAuction=existing.status==="active"?existing.id:(await q("SELECT id FROM live_auctions WHERE stream=? AND status='active' AND ends_at>? ORDER BY starts_at ASC LIMIT 1",stream,stamp).first<any>())?.id||"";
    if(activeAuction){const pinned:any=await q("UPDATE streams SET pinned_auction=? WHERE id=? AND store=? AND status IN ('live','external')",activeAuction,stream,store.id).run();if(changed(pinned)!==1)throw Error("The livestream ended before the auction could be pinned. Reopen the auction panel and try again.");}
    return json({ok:true,id:existing.id,pinned:Boolean(activeAuction),pinnedAuction:activeAuction,queued:existing.status==="scheduled",duplicate:true,auction:existing});
   }
   const queue:any=await q("SELECT MAX(ends_at) AS queue_end FROM live_auctions WHERE stream=? AND status IN ('active','scheduled') AND ends_at>?",stream,stamp).first();
   const queuedStart=queue?.queue_end&&queue.queue_end>stamp?new Date(queue.queue_end):start;
   const queuedEnd=new Date(queuedStart.getTime()+durationMs);
   const auctionStatus=queuedStart.getTime()>start.getTime()?"scheduled":"active";
   const id=crypto.randomUUID();
   try{await q("INSERT INTO live_auctions(id,store,product,stream,start_price,increment,reserve_price,starts_at,ends_at,status,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",id,store.id,product,stream,startPrice,increment,reserve,queuedStart.toISOString(),queuedEnd.toISOString(),auctionStatus,stamp,stamp).run();}
   catch(error){
    // A concurrent create can win the unique partial index between the check
    // above and INSERT. Return that canonical record instead of a false save.
    const concurrent:any=await q("SELECT a.id,a.stream,a.product,p.name AS product_name,a.start_price,a.increment,a.reserve_price,a.starts_at,a.ends_at,a.status,(SELECT MAX(amount) FROM auction_bids WHERE auction=a.id) AS highest_bid,(SELECT COUNT(*) FROM auction_bids WHERE auction=a.id) AS bid_count FROM live_auctions a JOIN products p ON p.id=a.product WHERE a.stream=? AND a.product=? AND a.status IN ('active','scheduled') AND a.ends_at>? ORDER BY a.created DESC LIMIT 1",stream,product,now()).first();
    if(!concurrent)throw error;
    const activeAuction=concurrent.status==="active"?concurrent.id:(await q("SELECT id FROM live_auctions WHERE stream=? AND status='active' AND ends_at>? ORDER BY starts_at ASC LIMIT 1",stream,now()).first<any>())?.id||"";
    if(activeAuction){const pinned:any=await q("UPDATE streams SET pinned_auction=? WHERE id=? AND store=? AND status IN ('live','external')",activeAuction,stream,store.id).run();if(changed(pinned)!==1)throw Error("The livestream ended before the auction could be pinned. Reopen the auction panel and try again.");}
    return json({ok:true,id:concurrent.id,pinned:Boolean(activeAuction),pinnedAuction:activeAuction,queued:concurrent.status==="scheduled",duplicate:true,auction:concurrent});
   }
   const activeAuction=auctionStatus==="active"?id:(await q("SELECT id FROM live_auctions WHERE stream=? AND status='active' AND ends_at>? ORDER BY starts_at ASC LIMIT 1",stream,stamp).first<any>())?.id||"";
   const pin:any=activeAuction?await q("UPDATE streams SET pinned_auction=? WHERE id=? AND store=? AND status IN ('live','external')",activeAuction,stream,store.id).run():null;
   if(activeAuction&&changed(pin)!==1){await q("UPDATE live_auctions SET status='cancelled',updated=? WHERE id=? AND status IN ('active','scheduled')",now(),id).run();throw Error("Your broadcast ended before the auction could be pinned. Reopen the live studio and try again.");}
   const productName=(await q("SELECT name FROM products WHERE id=?",product).first<any>())?.name||"Product";
   const auction={id,stream,product,product_name:productName,start_price:startPrice,increment,reserve_price:reserve,starts_at:queuedStart.toISOString(),ends_at:queuedEnd.toISOString(),status:auctionStatus,highest_bid:null,bid_count:0};
   return json({ok:true,id,pinned:Boolean(activeAuction),pinnedAuction:activeAuction,queued:auctionStatus==="scheduled",status:auctionStatus,startsAt:queuedStart.toISOString(),endsAt:queuedEnd.toISOString(),auction});
  }
  if(action==="pin"){
   const stream=String(b.stream||""),auction=String(b.auction||""),ownStore:any=await q("SELECT id FROM stores WHERE owner=? AND suspended=0",u!.userId).first();if(!ownStore)throw Error("Active seller store required");await requireSellerActive(ownStore.id);const live:any=await q("SELECT id FROM streams WHERE id=? AND store=? AND status IN ('live','external')",stream,ownStore.id).first();if(!live)throw Error("Only the owner can feature an auction during their active livestream.");
   if(auction){const item:any=await q("SELECT id FROM live_auctions WHERE id=? AND stream=? AND status IN ('active','scheduled') AND ends_at>?",auction,stream,stamp).first();if(!item)throw Error("This auction is no longer available to feature.");}
   const saved:any=await q("UPDATE streams SET pinned_auction=? WHERE id=? AND store=? AND status IN ('live','external')",auction,stream,ownStore.id).run();if(changed(saved)!==1)throw Error("The livestream ended before the auction pin could be saved. Reopen the live studio and try again.");return json({ok:true,pinnedAuction:auction});
  }
  if(action==="bid"){
   let liveEventsReady=true;try{await ensureLiveStreamEventsSchema();}catch{liveEventsReady=false;}
   const auction=String(b.auction||""),maxAmount=Number(b.maxBid??b.amount),requestId=String(b.requestId||"");if(!Number.isSafeInteger(maxAmount)||maxAmount<1||!/^[a-f0-9-]{36}$/i.test(requestId))throw Error("Enter a valid maximum bid.");
   const a:any=await q("SELECT a.*,s.owner,s.suspended AS store_suspended,p.active AS product_active,p.stock,p.name AS product_name,st.status AS stream_status FROM live_auctions a JOIN stores s ON s.id=a.store JOIN products p ON p.id=a.product JOIN streams st ON st.id=a.stream WHERE a.id=?",auction).first();if(!a||!["live","external"].includes(a.stream_status))throw Error("This auction is only available while its livestream is live.");await q("UPDATE live_auctions SET status='active',updated=? WHERE id=? AND status='scheduled' AND starts_at<=? AND ends_at>?",stamp,auction,stamp,stamp).run();const current:any=await q("SELECT status FROM live_auctions WHERE id=?",auction).first();if(!current||current.status!=="active"||a.starts_at>stamp||a.ends_at<=stamp||a.store_suspended||!a.product_active||a.stock<1)throw Error("This auction is not accepting bids.");if(a.owner===u!.userId)throw Error("Sellers cannot bid on their own auctions.");if(!(await q("SELECT id FROM profiles WHERE id=? AND suspended=0",a.owner).first())||!(await q("SELECT id FROM profiles WHERE id=? AND suspended=0",u!.userId).first())||!((await q("SELECT verified FROM stores WHERE id=?",a.store).first<any>())?.verified))throw Error("Seller is not eligible to run this auction.");await requireSellerActive(a.store);
   const describeLeader=async()=>q("SELECT b.id,b.amount,b.bidder,COALESCE('@'||NULLIF(p.username,''),NULLIF(p.name,''),'Buyer') AS name FROM auction_bids b LEFT JOIN profiles p ON p.id=b.bidder WHERE b.auction=? ORDER BY b.amount DESC,b.created ASC LIMIT 1",auction).first<any>();
   const prior:any=await q("SELECT request_id FROM auction_max_bid_requests WHERE request_id=? AND auction=? AND bidder=?",requestId,auction,u!.userId).first();
   if(prior){const leader=await describeLeader(),savedMax:any=await q("SELECT max_amount FROM auction_max_bids WHERE auction=? AND bidder=?",auction,u!.userId).first(),auctionNow:any=await q("SELECT ends_at FROM live_auctions WHERE id=?",auction).first();return json({ok:true,duplicate:true,currentBid:leader?.amount||0,leader:leader?{name:leader.name,isYou:leader.bidder===u!.userId}:null,outbid:Boolean(leader&&leader.bidder!==u!.userId),youAreLeading:Boolean(leader&&leader.bidder===u!.userId),myMaxBid:Number(savedMax?.max_amount||0),endsAt:auctionNow?.ends_at||a.ends_at});}
   const delivery:any=await q("SELECT coverage,shipping_fee FROM stores WHERE id=?",a.store).first();let deliveryCoverage:any[]=[];try{deliveryCoverage=JSON.parse(delivery?.coverage||"[]");}catch{}
   if(!Array.isArray(deliveryCoverage)||deliveryCoverage.length===0||delivery?.shipping_fee==null||!Number.isSafeInteger(Number(delivery.shipping_fee))||Number(delivery.shipping_fee)<0)throw Error("This seller has not configured delivery coverage and a fee yet. Please try another auction.");
   const leaderBefore=await describeLeader();
   const ownMax:any=await q("SELECT max_amount FROM auction_max_bids WHERE auction=? AND bidder=?",auction,u!.userId).first();
   const minimum=Math.max(Number(a.start_price),Number(leaderBefore?.amount||0)+(leaderBefore?Number(a.increment):0));
   const requiredMax=Math.max(minimum,Number(ownMax?.max_amount||0)+1);
   if(maxAmount<requiredMax)throw Error(`Your maximum must be at least ₦${requiredMax.toLocaleString("en-NG")}.`);
   const requestInsert=q(`INSERT INTO auction_max_bids(auction,bidder,max_amount,created,updated)
     SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM live_auctions la JOIN streams st ON st.id=la.stream WHERE la.id=? AND la.status='active' AND st.status IN ('live','external') AND la.starts_at<=? AND la.ends_at>? AND ? >= COALESCE((SELECT MAX(b.amount)+la.increment FROM auction_bids b WHERE b.auction=la.id),la.start_price))
     ON CONFLICT(auction,bidder) DO UPDATE SET max_amount=excluded.max_amount,updated=excluded.updated WHERE excluded.max_amount>auction_max_bids.max_amount`,auction,u!.userId,maxAmount,stamp,stamp,auction,stamp,stamp,maxAmount);
   const requestLog=q(`INSERT OR IGNORE INTO auction_max_bid_requests(request_id,auction,bidder,max_amount,created)
     SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM auction_max_bids WHERE auction=? AND bidder=? AND max_amount>=?)
       AND EXISTS(SELECT 1 FROM live_auctions la JOIN streams st ON st.id=la.stream WHERE la.id=? AND la.status='active' AND st.status IN ('live','external') AND la.ends_at>?)`,requestId,auction,u!.userId,maxAmount,stamp,auction,u!.userId,maxAmount,auction,stamp);
   const proxyBid=q(`WITH bidder_max AS (
       SELECT bidder,MAX(max_amount) AS max_amount,MIN(created) AS first_bid FROM auction_max_bids WHERE auction=? GROUP BY bidder
     ), ranked AS (
       SELECT bidder,max_amount,ROW_NUMBER() OVER(ORDER BY max_amount DESC,first_bid ASC,bidder ASC) AS position FROM bidder_max
     ), price AS (
       SELECT top.bidder,MIN(top.max_amount,MAX(la.start_price,CASE WHEN la.reserve_price IS NOT NULL AND top.max_amount>=la.reserve_price THEN la.reserve_price ELSE la.start_price END,COALESCE(second.max_amount+la.increment,la.start_price))) AS amount
       FROM live_auctions la JOIN ranked top ON top.position=1 LEFT JOIN ranked second ON second.position=2 WHERE la.id=?
     )
     INSERT OR IGNORE INTO auction_bids(id,auction,bidder,amount,request_id,created,recipient,phone,delivery_address,delivery_state,delivery_area,delivery_fee)
     SELECT ?,?,price.bidder,price.amount,?,?,'','','','','',0 FROM price
     WHERE EXISTS(SELECT 1 FROM auction_max_bid_requests WHERE request_id=? AND auction=? AND bidder=?)
       AND EXISTS(SELECT 1 FROM live_auctions la JOIN streams st ON st.id=la.stream WHERE la.id=? AND la.status='active' AND st.status IN ('live','external') AND la.ends_at>?)
       AND (COALESCE((SELECT bidder FROM auction_bids WHERE auction=? ORDER BY amount DESC,created ASC LIMIT 1),'')!=price.bidder
         OR COALESCE((SELECT amount FROM auction_bids WHERE auction=? ORDER BY amount DESC,created ASC LIMIT 1),0)<price.amount)`,auction,auction,crypto.randomUUID(),auction,requestId,stamp,requestId,auction,u!.userId,auction,stamp,auction,auction);
   const closingWindowMs=12_000,resetAt=new Date(Date.parse(stamp)+closingWindowMs).toISOString();
   const refreshAuction=q(`UPDATE live_auctions SET ends_at=?,updated=? WHERE id=? AND status='active' AND ends_at>? AND ends_at<=?
     AND EXISTS(SELECT 1 FROM auction_max_bid_requests WHERE request_id=? AND auction=? AND bidder=?)`,resetAt,stamp,auction,stamp,resetAt,requestId,auction,u!.userId);
   await env.DB!.batch([requestInsert,requestLog,proxyBid,refreshAuction]);
   const accepted:any=await q("SELECT request_id FROM auction_max_bid_requests WHERE request_id=? AND auction=? AND bidder=?",requestId,auction,u!.userId).first();
   if(!accepted)throw Error("The auction changed before your maximum bid was accepted. Refresh and try again.");
   const leader=await describeLeader();
   const savedMax:any=await q("SELECT max_amount FROM auction_max_bids WHERE auction=? AND bidder=?",auction,u!.userId).first();
   const placed:any=await q("SELECT id,amount,bidder,created FROM auction_bids WHERE request_id=?",requestId).first();
   if(placed&&liveEventsReady){try{const bidder:any=await q("SELECT COALESCE('@'||NULLIF(username,''),NULLIF(name,''),'A buyer') AS name FROM profiles WHERE id=?",placed.bidder).first();const productName=String(a.product_name||"the featured product").slice(0,80);const message=`${bidder?.name||"A buyer"} is leading at ₦${Number(placed.amount).toLocaleString("en-NG")} for ${productName}.`;await q("INSERT OR IGNORE INTO live_stream_events(id,stream,type,name,message,created) VALUES(?,?,'bid','Cash N Carry',?,?)",`bid:${placed.id}`,a.stream,message,stamp).run();}catch{console.error("live_stream_bid_event_failed");}}
   const seller:any=await q("SELECT owner FROM stores WHERE id=?",a.store).first();await q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)",`auction-max-bid:${requestId}`,seller.owner,"New auction bid activity",`A buyer updated a maximum bid. Current visible bid: ₦${Number(leader?.amount||a.start_price).toLocaleString("en-NG")}.`,stamp).run();
   if(leaderBefore?.bidder&&leader?.bidder&&leaderBefore.bidder!==leader.bidder)await q("INSERT OR IGNORE INTO notifications(id,user,title,body,created) VALUES(?,?,?,?,?)",`auction-outbid:${requestId}`,leaderBefore.bidder,"You have been outbid",`Another buyer is now leading at ₦${Number(leader.amount).toLocaleString("en-NG")}. Reopen the livestream if you want to raise your maximum.`,stamp).run();
   const auctionNow:any=await q("SELECT ends_at FROM live_auctions WHERE id=?",auction).first();
   return json({ok:true,duplicate:false,currentBid:Number(leader?.amount||0),leader:leader?{name:leader.name,isYou:leader.bidder===u!.userId}:null,outbid:Boolean(leader&&leader.bidder!==u!.userId),youAreLeading:Boolean(leader&&leader.bidder===u!.userId),myMaxBid:Number(savedMax?.max_amount||0),endsAt:auctionNow?.ends_at||a.ends_at});
  }
  if(action==="end"){
   const store:any=await q("SELECT id FROM stores WHERE owner=?",u!.userId).first();if(!store)throw Error("Seller store not found.");const a:any=await q("SELECT id,status,stream,starts_at,ends_at FROM live_auctions WHERE id=? AND store=?",String(b.auction||""),store.id).first();if(!a||!["active","scheduled"].includes(a.status))throw Error("Auction is not open for ending.");
   if(a.status==="scheduled"&&a.starts_at>stamp){await q("UPDATE live_auctions SET status='cancelled',updated=? WHERE id=? AND store=? AND status='scheduled'",stamp,a.id,store.id).run();await q(`UPDATE streams SET pinned_auction=COALESCE((SELECT id FROM live_auctions WHERE stream=? AND status='active' AND ends_at>? ORDER BY starts_at ASC LIMIT 1),(SELECT id FROM live_auctions WHERE stream=? AND status='scheduled' AND ends_at>? ORDER BY starts_at ASC LIMIT 1),'') WHERE id=? AND store=? AND pinned_auction=?`,a.stream,stamp,a.stream,stamp,a.stream,store.id,a.id).run();return json({ok:true,cancelled:true});}
   await q("UPDATE live_auctions SET status='active',ends_at=?,updated=? WHERE id=? AND store=? AND status IN ('active','scheduled') AND starts_at<=?",stamp,stamp,a.id,store.id,stamp).run();const result=await settleAuction(a.id,stamp);return json({ok:true,orderId:result.orderId||null});
  }
  if(action==="settle"){
   const result=await settleAuction(String(b.auction||""),stamp);if(result.reason==="not_found")throw Error("Auction not found");if(result.reason==="not_due")throw Error("Auction has not ended.");return json({ok:true,orderId:result.orderId||null,reserveMet:Boolean(result.orderId)});
  }
  if(action==="moderate"){if(!(await isAdmin(u,"streams")))return json({error:"Administrator access required"},403);const r:any=await q("UPDATE live_auctions SET status='suspended',updated=? WHERE id=? AND status IN ('scheduled','active')",stamp,String(b.auction||"")).run();if(!changed(r))throw Error("Auction not found or already closed");return json({ok:true});}
  throw Error("Unknown auction action");
 }catch(e:any){return json({error:e.message||"Unable to process auction"},400);}
}
