import { catalog } from "../../catalog";
import { getChatGPTUser } from "../../chatgpt-auth";
export async function GET(req: Request) {
  try {
    const user = await getChatGPTUser();
    return Response.json(
      await catalog(new URL(req.url).searchParams, user?.userId || null),
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error: any) {
    const validation = /Invalid (page|distance|minPrice|maxPrice|price range)/.test(error.message);
    if (!validation) console.error("catalog_failed");
    return Response.json(
      {
        error: validation
          ? error.message
          : "Unable to load products. Please retry.",
      },
      { status: validation ? 400 : 503 },
    );
  }
}
