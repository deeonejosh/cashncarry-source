import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { limit } from "../../security";
import { ensureVideoStorefrontSchema } from "../../video-storefront-schema";

export const dynamic = "force-dynamic";
const json = (data: any, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
const db = () => {
  if (!env.DB) throw Error("Storage unavailable");
  return env.DB;
};
const q = (sql: string, ...args: any[]) => db().prepare(sql).bind(...args);
const slugify = (value: string) => value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48);
const reserved = new Set(["admin", "api", "account", "cart", "checkout", "for-you", "seller", "store", "product", "live", "help", "privacy", "terms", "sign-in", "sign-up", "workspace"]);

async function ownedMedia(url: string, owner: string) {
  if (!url) return true;
  const match = /^\/api\/media\/([a-zA-Z0-9_-]+)$/.exec(url);
  if (!match || !env.BUCKET) throw Error("Choose an image uploaded through Cash N Carry.");
  const object = await env.BUCKET.head(match[1]);
  if (!object || object.customMetadata?.owner !== owner) throw Error("Use an image uploaded by your seller account.");
  return true;
}

export async function GET(req: Request) {
  try {
    await ensureVideoStorefrontSchema();
    const url = new URL(req.url);
    const slug = (url.searchParams.get("slug") || "").toLowerCase();
    const user = await getChatGPTUser();
    const preview = url.searchParams.get("preview") === "1";
    let row: any;
    if (preview) {
      if (!user) return json({ error: "Sign in required" }, 401);
      row = await q("SELECT f.*,s.id AS store_id,s.owner,s.name,s.description,s.category,s.location,s.verified,s.suspended FROM storefronts f JOIN stores s ON s.id=f.store WHERE s.owner=?", user.userId).first();
    } else if (slug) {
      row = await q("SELECT f.*,s.id AS store_id,s.owner,s.name,s.description,s.category,s.location,s.verified,s.suspended FROM storefronts f JOIN stores s ON s.id=f.store WHERE f.slug=? AND f.published=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.id=s.owner AND p.suspended=1)", slug).first();
    }
    if (!row) return json({ storefront: null }, 404);
    if (preview && row.owner !== user?.userId) return json({ error: "Storefront access denied" }, 403);
    const products = await q("SELECT p.id,p.name,p.description,p.category,p.price,p.stock,p.image,p.variants FROM products p WHERE p.store=? AND p.active=1 ORDER BY p.featured DESC,p.created DESC LIMIT 100", row.store_id).all();
    const streams = await q("SELECT id,title,status,scheduled FROM streams WHERE store=? AND (status IN ('live','scheduled','external') OR (status='ended' AND replay!='')) ORDER BY created DESC LIMIT 20", row.store_id).all();
    const videoQuery = preview
      ? "SELECT id,caption,media,thumbnail,status,created FROM videos WHERE store=? ORDER BY created DESC LIMIT 30"
      : "SELECT id,caption,media,thumbnail,status,created FROM videos WHERE store=? AND status='approved' AND published=1 ORDER BY created DESC LIMIT 30";
    const videos = await q(videoQuery, row.store_id).all();
    const [reviews, follows] = await Promise.all([
      q("SELECT r.id,r.name,r.rating,r.comment,r.created,p.name AS product_name FROM reviews r JOIN products p ON p.id=r.product WHERE p.store=? ORDER BY r.created DESC LIMIT 20", row.store_id).all(),
      user ? q("SELECT id FROM follows WHERE user=? AND store=?", user.userId, row.store_id).first() : Promise.resolve(null),
    ]);
    return json({ storefront: row, products: products.results, streams: streams.results, videos: videos.results, reviews: reviews.results, following: Boolean(follows) });
  } catch {
    return json({ error: "Unable to load this storefront." }, 503);
  }
}

export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin) return json({ error: "Invalid request origin" }, 403);
  const user = await getChatGPTUser();
  if (!user) return json({ error: "Sign in to continue" }, 401);
  try {
    await ensureVideoStorefrontSchema();
    await limit("storefront:" + user.userId, 30);
    const body: any = await req.json();
    const store: any = await q("SELECT id,name,owner,suspended FROM stores WHERE owner=?", user.userId).first();
    if (!store) throw Error("Create your seller account in Seller Centre first.");
    if (store.suspended) throw Error("Your store is suspended.");
    const status: any = await q("SELECT suspended FROM profiles WHERE id=?", user.userId).first();
    if (status?.suspended) throw Error("Your account is suspended.");
    const existing: any = await q("SELECT * FROM storefronts WHERE store=?", store.id).first();
    const slug = slugify(String(body.slug || body.name || store.name));
    if (!slug || reserved.has(slug)) throw Error("Choose a different store address; that name is reserved.");
    const clash = await q("SELECT store FROM storefronts WHERE slug=? AND store!=?", slug, store.id).first();
    if (clash) throw Error("That store address is already in use.");
    const template = ["market", "editorial", "catalogue"].includes(body.template) ? body.template : "market";
    const validColour = (value: unknown, fallback: string) => typeof value === "string" && /^#[0-9a-f]{6}$/i.test(value) ? value.toLowerCase() : fallback;
    const accent = validColour(body.accent, existing?.accent || "#164B35");
    const backgroundColor = validColour(body.backgroundColor, existing?.background_color || "#fff8ef");
    const surfaceColor = validColour(body.surfaceColor, existing?.surface_color || "#FFFFFF");
    const buyNowColor = validColour(body.buyNowColor, existing?.buy_now_color || "#164B35");
    const logo = String(body.logo || "").slice(0, 200);
    const banner = String(body.banner || "").slice(0, 200);
    const promoBanner = String(body.promoBanner || "").slice(0, 200);
    await ownedMedia(logo, user.userId);
    await ownedMedia(banner, user.userId);
    await ownedMedia(promoBanner, user.userId);
    const featured = Array.isArray(body.featuredProducts) ? body.featuredProducts.slice(0, 8).map((x: any) => String(x).slice(0, 100)) : [];
    if (featured.length) {
      const allowed: any = await q(`SELECT COUNT(*) AS count FROM products WHERE store=? AND active=1 AND id IN (${featured.map(() => "?").join(",")})`, store.id, ...featured).first();
      if (Number(allowed?.count) !== new Set(featured).size) throw Error("Featured products must belong to your store and be published.");
    }
    const published = body.published === true || body.published === 1 ? 1 : 0;
    const now = new Date().toISOString();
    const displayName = String(body.name || "").trim().slice(0, 100);
    const description = String(body.description || "").trim().slice(0, 1000);
    const category = String(body.category || "").trim().slice(0, 60);
    if (existing) await q("UPDATE storefronts SET slug=?,display_name=?,description=?,category=?,logo=?,banner=?,promo_banner=?,template=?,accent=?,background_color=?,surface_color=?,buy_now_color=?,featured_products=?,published=?,updated=? WHERE store=?", slug, displayName, description, category, logo, banner, promoBanner, template, accent, backgroundColor, surfaceColor, buyNowColor, JSON.stringify(featured), published, now, store.id).run();
    else await q("INSERT INTO storefronts(store,slug,display_name,description,category,logo,banner,promo_banner,template,accent,background_color,surface_color,buy_now_color,featured_products,published,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", store.id, slug, displayName, description, category, logo, banner, promoBanner, template, accent, backgroundColor, surfaceColor, buyNowColor, JSON.stringify(featured), published, now).run();
    return json({ ok: true, slug, url: "/store/" + slug, published: Boolean(published) });
  } catch (error: any) {
    return json({ error: error?.message || "Unable to save your storefront." }, 400);
  }
}
