import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../../chatgpt-auth";
import { isAdmin } from "../../../admin-access";
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{"Cache-Control":"no-store"}});
export async function GET(req:Request){
 const user=await getChatGPTUser();
 if(!user||!(await isAdmin(user,"reports")))return json({error:"Report moderation access required"},user?403:401);
 const reportId=new URL(req.url).searchParams.get("id")||"";
 if(!reportId||reportId.length>80)return json({error:"Report not found"},404);
 try{
  const report=await env.DB?.prepare("SELECT r.id,r.status,m.id AS message_id,m.sender,m.body,m.created,s.name AS store_name,CASE WHEN m.sender=s.owner THEN s.name ELSE COALESCE('@'||NULLIF(p.username,''),'Buyer') END AS sender_name FROM reports r JOIN seller_messages m ON r.target_type='seller_message' AND r.target=m.id JOIN stores s ON s.id=m.store LEFT JOIN profiles p ON p.id=m.sender WHERE r.id=? AND r.target_type='seller_message'").bind(reportId).first<any>();
  if(!report)return json({error:"Reported message unavailable"},404);
  const stamp=new Date().toISOString();
  await env.DB!.prepare("INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)").bind(crypto.randomUUID(),user.userId,user.email,"view-reported-message",reportId,"Opened the specific message attached to a customer report","{}",JSON.stringify({message_id:report.message_id}),stamp).run();
  return json({message:{id:report.message_id,sender:report.sender_name,body:report.body,created:report.created,store:report.store_name},status:report.status});
 }catch{return json({error:"Unable to load the reported message"},503);}
}
