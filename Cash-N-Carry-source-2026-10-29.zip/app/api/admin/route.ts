import {reviewSellerVerification,revokeSellerVerification} from "../../verification-review";
import { requireSellerActive } from "../../seller-activation";
import { canAdmin, adminPermissions, type AdminPermission } from "../../admin-permissions";
import { verificationEmail, caseEmail, restrictionEmail, safelyEmail } from "../../email-events";
import { paymentReadiness } from "../../payments";
import { ensureVideoStorefrontSchema } from "../../video-storefront-schema";
import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { isAdmin, adminRole } from "../../admin-access";
import { ensureTrustBadgeSchema } from "../../trust-badge-schema";
export const dynamic = "force-dynamic";
const json = (b: any, status = 200) =>
  Response.json(b, { status, headers: { "Cache-Control": "no-store" } });
const db = () => {
  if (!env.DB) throw Error("Storage unavailable");
  return env.DB;
};
const q = (sql: string, ...p: any[]) =>
  db()
    .prepare(sql)
    .bind(...p);
const all = async (sql: string, ...p: any[]) =>
  (await q(sql, ...p).all()).results;
export async function GET() {
  const u = await getChatGPTUser();
  if (!await isAdmin(u))
    return json({ error: "Administrator access required" }, u ? 403 : 401);
  try {
    await ensureVideoStorefrontSchema();
    await ensureTrustBadgeSchema();
    const role = await adminRole(u);
    const [
      metrics,
      users,
      stores,
      products,
      orders,
      streams,
      campaigns,
      verification,
      reports,
      audit,
      videos,
    ] = await Promise.all([
      q(
        "SELECT (SELECT COUNT(*) FROM profiles) AS users,(SELECT COUNT(*) FROM stores) AS stores,(SELECT COUNT(*) FROM orders) AS orders,(SELECT COALESCE(SUM(total),0) FROM orders o WHERE status='delivered' AND (payment!='flutterwave' OR (payment_status='paid' AND EXISTS(SELECT 1 FROM payments p WHERE p.order_id=o.id AND p.mode='live' AND p.status='paid')))) AS delivered_sales,(SELECT COUNT(*) FROM verification_requests WHERE status='pending') AS pending_verification,(SELECT COUNT(*) FROM reports WHERE status IN ('open','in_review')) AS open_reports,(SELECT COUNT(*) FROM stores WHERE coverage='[]' OR coverage='') AS missing_shipping,(SELECT COUNT(*) FROM policies WHERE reviewed=0) AS draft_policies,(SELECT COUNT(*) FROM payments WHERE mode='live' AND status='paid') AS live_payments",
      ).first(),
      all("SELECT * FROM profiles ORDER BY last_seen DESC LIMIT 300"),
      all(
        "SELECT s.*,p.email AS owner_email FROM stores s LEFT JOIN profiles p ON p.id=s.owner ORDER BY s.created DESC LIMIT 300",
      ),
      all(
        "SELECT p.*,s.name AS seller FROM products p JOIN stores s ON s.id=p.store ORDER BY p.created DESC LIMIT 300",
      ),
      all(
        "SELECT o.*,s.name AS seller FROM orders o JOIN stores s ON s.id=o.store ORDER BY o.created DESC LIMIT 300",
      ),
      all(
        "SELECT l.id,l.title,l.store,CASE WHEN l.provider='native' AND l.status='live' AND COALESCE(julianday(l.heartbeat),0)<julianday('now','-90 seconds') THEN 'ended' ELSE l.status END AS status,l.url,l.created,l.product,s.name AS seller FROM streams l JOIN stores s ON s.id=l.store ORDER BY l.created DESC LIMIT 100",
      ),
      all(
        "SELECT c.*,s.name AS seller FROM campaigns c JOIN stores s ON s.id=c.store ORDER BY c.created DESC LIMIT 300",
      ),
      all(
        "SELECT v.id,v.store,v.owner,v.legal_name,v.registration,v.file_type,v.status,v.note,v.created,s.name AS seller FROM verification_requests v JOIN stores s ON s.id=v.store ORDER BY v.created DESC LIMIT 300",
      ),
      all(
        "SELECT r.*,p.name AS reporter_name,p.email AS reporter_email FROM reports r LEFT JOIN profiles p ON p.id=r.reporter ORDER BY r.created DESC LIMIT 300",
      ),
      all("SELECT * FROM admin_audit ORDER BY created DESC LIMIT 300"),
      all("SELECT v.id,v.store,v.owner,v.media,v.caption,v.status,v.created,v.moderation_note,s.name AS seller FROM videos v JOIN stores s ON s.id=v.store ORDER BY CASE v.status WHEN 'pending' THEN 0 ELSE 1 END,v.created DESC LIMIT 300"),
    ]);
    const allowed = (permission: AdminPermission, rows: any[]) => canAdmin(role, permission) ? rows : [];
    return json({
      admin: u?.email, role, permissions: adminPermissions(role),
      metrics: { users: canAdmin(role,"customers") ? metrics?.users : 0, stores: canAdmin(role,"sellers") ? metrics?.stores : 0, orders: canAdmin(role,"orders") ? metrics?.orders : 0, delivered_sales: canAdmin(role,"payments") ? metrics?.delivered_sales : 0, pending_verification: canAdmin(role,"verification") ? metrics?.pending_verification : 0, open_reports: canAdmin(role,"reports") ? metrics?.open_reports : 0, draft_policies: canAdmin(role,"settings") ? metrics?.draft_policies : 0, missing_shipping: canAdmin(role,"sellers") ? metrics?.missing_shipping : 0, live_payments: canAdmin(role,"payments") ? metrics?.live_payments : 0 },
      paymentReadiness: canAdmin(role,"payments") ? paymentReadiness() : null,
      users: allowed("customers", users), stores: allowed("sellers", stores), products: allowed("products",products), videos: allowed("products",videos), orders: allowed("orders",role === "finance" ? orders.map((o:any) => ({id:o.id,store:o.store,seller:o.seller,total:o.total,status:o.status,payment:o.payment,payment_status:o.payment_status,created:o.created})) : orders), streams: allowed("streams",streams), campaigns: allowed("products",campaigns), verification: allowed("verification",verification), reports: reports.filter((r:any) => canAdmin(role, ["order","return"].includes(r.target_type) ? "support" : "reports")), audit: allowed("audit",audit),
    });
  } catch (e) {
    console.error("Admin load failed", e);
    return json(
      { error: "Unable to load the back office. Retry shortly." },
      503,
    );
  }
}
export async function POST(req: Request) {
  if (req.headers.get("origin") !== new URL(req.url).origin)
    return json({ error: "Invalid request origin" }, 403);
  const u = await getChatGPTUser();
  if (!await isAdmin(u))
    return json({ error: "Administrator access required" }, u ? 403 : 401);
  let attempted: any = null;
  try {
    const b: any = await req.json();
    attempted = b;
    if (b.action === "video") await ensureVideoStorefrontSchema();
    if (b.action === "official-store") await ensureTrustBadgeSchema();
    const permissions: Record<string, AdminPermission> = { store:"sellers", "official-store":"sellers", user:"customers", product:"products", video:"products", stream:"streams", campaign:"products", report:"reports", verification:"verification", "verification-revoke":"verification" };
    const report: any = b.action === "report" ? await q("SELECT target_type FROM reports WHERE id=?", String(b.id || "")).first() : null;
    const permission = report && ["order","return"].includes(report.target_type) ? "support" : permissions[b.action];
    if (!permission || !canAdmin(await adminRole(u), permission)) return json({error:"Permission denied"},403);
    const id = String(b.id || "");
    const reason = String(b.reason || "")
      .trim()
      .slice(0, 1000);
    if (!id || !reason) throw Error("A target and a reason are required.");
    if(b.action === "verification-revoke")return json(await revokeSellerVerification(id,reason,u!));
    const actions: any = {
      store: { table: "stores", field: "suspended", allowed: [0, 1] },
      "official-store": { table: "stores", field: "official_store", allowed: [0, 1] },
      user: { table: "profiles", field: "suspended", allowed: [0, 1] },
      product: { table: "products", field: "active", allowed: [0, 1] },
      video: { table: "videos", field: "status", allowed: ["approved", "rejected", "removed"] },
      stream: { table: "streams", field: "status", allowed: ["ended"] },
      campaign: {
        table: "campaigns",
        field: "status",
        allowed: ["approved_draft", "rejected"],
      },
      report: {
        table: "reports",
        field: "status",
        allowed: ["in_review", "resolved", "rejected"],
      },
      verification: {
        table: "verification_requests",
        field: "status",
        allowed: ["approved", "rejected"],
      },
    };
    const a = actions[b.action];
    if (!a || !a.allowed.includes(b.value)) throw Error("Invalid admin action");
    const before: any = await q(
      `SELECT * FROM ${a.table} WHERE id=?`,
      id,
    ).first();
    if (!before) throw Error("Record not found");
    if (b.action === "official-store" && b.value === 1 && (before.verified !== 1 || before.suspended !== 0 || await q("SELECT id FROM profiles WHERE id=? AND suspended=1", before.owner).first()))
      throw Error("Only an active, verified seller can be designated an Official Store.");
    if (b.action === "user" && before.email?.toLowerCase() === env.REVIBE_ADMIN_EMAIL?.toLowerCase()) throw Error("The configured owner cannot be suspended here");
    if (
      b.action === "user" &&
      before.email.toLowerCase() === u!.email.toLowerCase()
    )
      throw Error("You cannot suspend your own administrator account.");
    if (b.action === "verification" && !["pending", "more_information"].includes(before.status))
      throw Error("This application has already been reviewed.");
    if (b.action === "video" && before.status !== "pending" && b.value !== "removed")
      throw Error("Only pending videos can be approved or rejected.");
    const stamp = new Date().toISOString();
    if (b.action === "verification") {
      await reviewSellerVerification(id,b.value,reason,u!);
      await safelyEmail(()=>verificationEmail(id));
      return json({ ok: true });
    }
    const statements: any[] = [];
    if (b.action === "product" && b.value === 1) {
      await requireSellerActive(before.store);
      for (const url of [
        before.image,
        before.video,
        ...JSON.parse(before.images || "[]"),
      ].filter(Boolean)) {
        const marker = url.indexOf("/api/media/");
        if (marker >= 0)
          statements.push(
            q("DELETE FROM media_blocks WHERE key=?", url.slice(marker + 11)),
          );
      }
    }
    if (b.action === "video" && b.value === "approved") {
      await requireSellerActive(before.store);
    }
    if (b.action === "video") {
      statements.push(q("UPDATE videos SET status=?,published=?,moderation_note=?,updated=? WHERE id=?", b.value, b.value === "approved" ? 1 : 0, reason, stamp, id));
      statements.push(q("INSERT INTO video_moderation_history(id,video,actor,status,note,created) VALUES(?,?,?,?,?,?)", crypto.randomUUID(), id, u!.userId, b.value, reason, stamp));
    } else if (b.action === "report")
      statements.push(
        q(
          "UPDATE reports SET status=?,resolution=?,updated=? WHERE id=?",
          b.value,
          reason,
          stamp,
          id,
        ),
      );
    else
      statements.push(
        q(`UPDATE ${a.table} SET ${a.field}=? WHERE id=?`, b.value, id),
      );
    if ((b.action === "store" || b.action === "user") && b.value === 1)
      statements.push(
        q(
          "UPDATE streams SET status='ended' WHERE store IN (SELECT id FROM stores WHERE " +
            (b.action === "store" ? "id" : "owner") +
            "=?)",
          id,
        ),
      );
    const safeBefore = { ...before };
    delete safeBefore.file_key;
    delete safeBefore.publish_url;
    const after = { ...safeBefore, [a.field]: b.value, outcome: "applied" };
    statements.push(
      q(
        "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
        crypto.randomUUID(),
        u!.userId,
        u!.email,
        b.action,
        id,
        reason,
        JSON.stringify(safeBefore),
        JSON.stringify(after),
        stamp,
      ),
    );
    await db().batch(statements);
    if(b.action==="report")await safelyEmail(()=>caseEmail(id));
    if((b.action==="store" || b.action==="user") && b.value===1 && before.suspended!==1)
      await safelyEmail(()=>restrictionEmail(b.action==="user"?id:before.owner,`restriction:${b.action}:${id}:${stamp}`,reason));
    if((b.action==="product" && b.value===0 && before.active!==0) || (b.action==="stream" && before.status!=="ended")) {
      const store:any=await q("SELECT owner FROM stores WHERE id=?",before.store).first();
      if(store)await safelyEmail(()=>restrictionEmail(store.owner,`moderation:${b.action}:${id}:${stamp}`,reason));
    }
    return json({ ok: true });
  } catch (e: any) {
    console.error("admin_action_failed", { actor: u!.userId });
    if (attempted)
      await q(
        "INSERT INTO admin_audit(id,actor,email,action,target,reason,before_json,after_json,created) VALUES(?,?,?,?,?,?,?,?,?)",
        crypto.randomUUID(),
        u!.userId,
        u!.email,
        String(attempted.action || "invalid").slice(0, 100),
        String(attempted.id || "").slice(0, 150),
        "Action rejected",
        "{}",
        JSON.stringify({ outcome: "rejected" }),
        new Date().toISOString(),
      )
        .run()
        .catch(() => {});
    return json(
      {
        error: e.message?.includes("D1_ERROR")
          ? "Unable to apply this action. Refresh and retry."
          : e.message || "Unable to apply action",
      },
      e.message?.includes("concurrently") ? 409 : 400,
    );
  }
}
