import { env } from "cloudflare:workers";
import { notFound } from "next/navigation";
import { GET as getAuthorizedMedia } from "../../media/[key]/route";
import { PhotonImage, SamplingFilter, resize } from "@cf-wasm/photon/workerd";
import { MAX_TRANSFORM_BYTES, optimizeStorefrontImage } from "../../../resize-storefront-image";
import { imageDimensions, imageDimensionsProblem } from "../../../image-validation";

type ImageOutput = {
  response(options?: { headers?: HeadersInit }): Promise<Response>;
};
type ImageHandle = {
  transform(options: { width: number; height: number; fit: "contain" }): {
    output(options: { format: "image/webp"; quality: number }): Promise<ImageOutput>;
  };
};
type ImagesBinding = { input(stream: ReadableStream<Uint8Array>): ImageHandle };

async function readImageBytesWithinLimit(response: Response, maxBytes: number): Promise<Uint8Array | undefined> {
  if (!response.body) return undefined;
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        return undefined;
      }
      chunks.push(value);
    }
  } catch {
    return undefined;
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}


export async function GET(
  request: Request,
  { params }: { params: Promise<{ key: string }> },
) {
  const { key } = await params;
  // Product media keys are UUIDs. Never turn this endpoint into a general URL proxy.
  if (!/^[0-9a-f-]{36}$/i.test(key)) notFound();
  const images = (env as typeof env & { IMAGES?: ImagesBinding }).IMAGES;
  const requestedWidth = Number(new URL(request.url).searchParams.get("w") || 640);
  const width = [160, 256, 320, 480, 640, 960, 1200, 1600].includes(requestedWidth)
    ? requestedWidth
    : 640;
  const original = await getAuthorizedMedia(
    new Request(new URL(`/api/media/${key}`, request.url)),
    { params: Promise.resolve({ key }) },
  );
  if (!original.ok || !original.body) {
    return new Response(null, {
      status: original.status,
      headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" },
    });
  }
  // Keep an authorized original for unsupported formats and processing errors.
  const originalFallback = original.clone();
  const contentType = original.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase() || "";
  const contentLength = Number(original.headers.get("Content-Length") || 0);
  // Use the already-installed Photon processor first. The Images binding can
  // return an untransformed original on some runtimes; relying on it alone
  // caused every responsive URL to download the same full-size upload.
  const inputBytes = contentLength > MAX_TRANSFORM_BYTES
    ? undefined
    : await readImageBytesWithinLimit(original.clone(), MAX_TRANSFORM_BYTES);
  if (inputBytes) {
    const optimized = optimizeStorefrontImage(inputBytes, contentType, width, { PhotonImage, SamplingFilter, resize });
    if (optimized) return new Response(optimized.bytes, {
        headers: {
          "Content-Type": optimized.contentType,
          "Content-Length": String(optimized.bytes.byteLength),
          "Cache-Control": "private, max-age=3600",
          "X-Content-Type-Options": "nosniff",
        },
      });
  }

  if (images) {
    try {
      const imageInput = inputBytes ? new Response(inputBytes).body : original.body;
      if (imageInput) {
        const result = await images
          .input(imageInput)
          .transform({ width, height: width, fit: "contain" })
          .output({ format: "image/webp", quality: 76 });
        const transformed = await result.response({
          headers: {
            "Cache-Control": "private, max-age=3600",
            "X-Content-Type-Options": "nosniff",
          },
        });
        const transformedType = transformed.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase() || "";
        const transformedBytes = transformed.ok ? new Uint8Array(await transformed.arrayBuffer()) : new Uint8Array();
        const dimensions = ["image/jpeg", "image/png", "image/webp"].includes(transformedType)
          ? imageDimensions(transformedType, transformedBytes)
          : null;
        const sourceLength = inputBytes?.byteLength || contentLength;
        // Some Workers Images configurations choose JPEG for opaque imagery
        // despite the requested WebP output. Accept it only when signature,
        // dimensions and byte savings prove that a real resize occurred.
        if (transformed.ok && dimensions && !imageDimensionsProblem(dimensions) &&
            dimensions.width <= width && dimensions.height <= width &&
            transformedBytes.byteLength > 0 && transformedBytes.byteLength < sourceLength) {
          return new Response(transformedBytes, {
            headers: {
              "Content-Type": transformedType,
              "Content-Length": String(transformedBytes.byteLength),
              "Cache-Control": "private, max-age=3600",
              "X-Content-Type-Options": "nosniff",
            },
          });
        }
      }
    } catch {}
  }

  originalFallback.headers.set("Cache-Control", "private, max-age=3600");
  return originalFallback;
}
