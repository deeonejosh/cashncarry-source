import {
  renderEmail,
  emailTemplates,
  type TemplateId,
  type EmailData,
} from "./email-templates";
import { emailReplyTo } from "./email-reply-to";
import { queueTemplate, flushEmails } from "./notifications";
import { MIN_PASSWORD_LENGTH } from "./auth-navigation";
import { brand } from "./brand";
import { env } from "cloudflare:workers";
import { getEmailConfig } from "./email-config";
import { twoFactor } from "better-auth/plugins";
import { chatGptAdminMfa } from "./chatgpt-mfa-challenge";
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { getDb } from "../db";
import {
  authUser,
  authSession,
  authAccount,
  authVerification,
  authTwoFactor,
} from "../db/schema";
export async function authAvailable() {
  if (!env.BETTER_AUTH_SECRET || !env.SITE_URL || !env.DB) return false;
  try {
    return Boolean(await getEmailConfig());
  } catch {
    return false;
  }
}
export async function sendEmail(
  to: string,
  subject: string,
  text: string,
  idempotencyKey?: string,
) {
  const config = await getEmailConfig();
  if (!config) throw Error("Transactional email is not configured");
  let template: TemplateId = "notification",
    data: EmailData = { message: text };
  try {
    const saved = JSON.parse(text);
    if (
      saved.emailTemplateVersion === 1 &&
      emailTemplates.some((t) => t.id === saved.template)
    ) {
      template = saved.template;
      data = saved.data;
    }
  } catch {
    data.actionUrl = text.match(/https?:\/\/[^\s<>]+/)?.[0];
  }
  const rendered = renderEmail(template, data);
  const suppressed = await env.DB?.prepare(
    "SELECT reason FROM email_suppressions WHERE recipient=?",
  )
    .bind(to.trim().toLowerCase())
    .first();
  if (suppressed)
    throw Error("Email recipient is suppressed after a bounce or complaint");
  const replyTo = await emailReplyTo();
  const r = await fetch("https://api.resend.com/emails", {
    signal: AbortSignal.timeout(10000),
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      "Content-Type": "application/json",
      ...(idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {}),
    },
    body: JSON.stringify({
      from: config.from,
      to: [to],
      subject,
      html: rendered.html,
      text: rendered.text,
      ...(replyTo ? { reply_to: replyTo } : {}),
      tags: [{ name: "template", value: template }],
    }),
  });
  if (!r.ok)
    throw Error(
      r.status === 429
        ? "Email provider rate limited this request"
        : r.status === 401 || r.status === 403
          ? "Email provider rejected sender configuration"
          : "Email provider did not accept this request",
    );
  const result = (await r.json().catch(() => null)) as { id?: string } | null;
  if (!result?.id || typeof result.id !== "string")
    throw Error("Email provider response was not confirmed");
  return result.id;
}
export async function getAuth() {
  if (!(await authAvailable()))
    throw Error(
      "Email accounts are not available yet. Use the existing ChatGPT sign-in.",
    );
  return betterAuth({
    appName: brand.name,
    secret: env.BETTER_AUTH_SECRET,
    baseURL: {
      allowedHosts: [
        new URL(env.SITE_URL!).host,
        "www.cashncarryng.com",
        "revibe-commerce.ogundiyatemidayo1.chatgpt.site",
      ],
      fallback: env.SITE_URL,
      protocol: "https",
    },
    trustedOrigins: [
      new URL(env.SITE_URL!).origin,
      "https://www.cashncarryng.com",
      "https://revibe-commerce.ogundiyatemidayo1.chatgpt.site",
    ],
    database: drizzleAdapter(getDb(), {
      provider: "sqlite",
      schema: {
        user: authUser,
        session: authSession,
        account: authAccount,
        verification: authVerification,
        twoFactor: authTwoFactor,
      },
    }),
    plugins: [twoFactor({ issuer: brand.name }), chatGptAdminMfa()],
    emailAndPassword: {
      enabled: true,
      requireEmailVerification: true,
      minPasswordLength: MIN_PASSWORD_LENGTH,
      revokeSessionsOnPasswordReset: true,
      resetPasswordTokenExpiresIn: 3600,
      sendResetPassword: async ({ user, url }) => {
        await sendAccountEmail(user, "password-reset", url);
      },
      onPasswordReset: async ({ user }) => {
        await queueTemplate(
          user.email,
          `password-reset-completed:${user.id}:${crypto.randomUUID()}`,
          "password-changed",
          { name: user.name, actionUrl: "/account" },
        ).catch(() => console.error("email_event_enqueue_failed"));
        await flushEmails().catch(() =>
          console.error("email_queue_flush_failed"),
        );
      },
    },
    emailVerification: {
      sendOnSignUp: true,
      autoSignInAfterVerification: false,
      expiresIn: 3600,
      sendVerificationEmail: async ({ user, url }) => {
        await sendAccountEmail(user, "verification", url);
      },
      afterEmailVerification: async (user) => {
        await queueTemplate(user.email, `welcome:${user.id}`, "welcome", {
          name: user.name,
          actionUrl: "/?browse=1#market",
        }).catch(() => console.error("email_event_enqueue_failed"));
        await flushEmails().catch(() =>
          console.error("email_queue_flush_failed"),
        );
      },
    },
    session: { expiresIn: 60 * 60 * 24 * 7, updateAge: 60 * 60 * 24 },
    rateLimit: { enabled: true, window: 60, max: 20 },
    advanced: { useSecureCookies: true },
  });
}

async function sendAccountEmail(
  user: { email: string; name?: string },
  template: TemplateId,
  url: string,
) {
  const id = await queueTemplate(
    user.email,
    "auth:" + template + ":" + url,
    template,
    {
      name: user.name,
      actionUrl: url,
      expiresAt: new Date(Date.now() + 3600000).toISOString(),
    },
  );
  await flushEmails(id);
  const row = await env
    .DB!.prepare("SELECT status FROM email_outbox WHERE id=?")
    .bind(id)
    .first<{ status: string }>();
  if (row?.status !== "sent")
    throw Error(
      "Email provider acceptance could not be confirmed. Request a fresh link or check email status.",
    );
}
