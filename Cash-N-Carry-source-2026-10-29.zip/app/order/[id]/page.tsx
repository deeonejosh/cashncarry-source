import { CustomerNavigation } from "../../customer-shell";
import Link from "next/link";
import { env } from "cloudflare:workers";
import { requireChatGPTUser } from "../../chatgpt-auth";
import { notFound } from "next/navigation";
import { ArrowLeft, CalendarDays, CreditCard, FileText, LifeBuoy, MapPin, PackageCheck, Store, Truck } from "lucide-react";
import { trustBadgeImage } from "../../trust-badge-image";
import { OrderPaymentAction } from "../../order-payment-action";

const progressSteps = ["placed", "confirmed", "shipped", "delivered"] as const;
const stepLabels = ["Order placed", "Confirmed", "Shipped", "Delivered"];
const money = (value: unknown) => `₦${Number(value || 0).toLocaleString("en-NG")}`;

export default async function Order({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const u = await requireChatGPTUser("/order/" + id);
  const o: any = await env.DB!.prepare(
    "SELECT o.*,(SELECT mode FROM payments WHERE order_id=o.id) AS payment_mode,s.name AS seller,CASE WHEN s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles sp WHERE sp.id=s.owner AND sp.suspended=1) THEN s.verified ELSE 0 END AS verified,s.return_policy,s.delivery_days FROM orders o JOIN stores s ON s.id=o.store WHERE o.id=? AND (o.buyer=? OR s.owner=?)",
  ).bind(id, u.userId, u.userId).first();
  if (!o) notFound();
  const items = (await env.DB!.prepare(
    "SELECT product,name,variant,price,quantity FROM order_items WHERE order_id=?",
  ).bind(id).all<any>()).results;
  const status = String(o.status || "placed").toLowerCase();
  const currentStep = progressSteps.indexOf(status as (typeof progressSteps)[number]);
  const placedDate = o.created && Number.isFinite(Date.parse(o.created))
    ? new Date(o.created).toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" })
    : "Date unavailable";
  const paymentLabel = o.payment === "auction" && o.payment_status === "pending"
    ? "Winning bid · payment due"
    : o.payment === "flutterwave"
    ? `${o.payment_mode === "live" ? "Online payment" : "Online payment (test)"} · ${String(o.payment_status || "pending")}`
    : `${o.payment || "Payment"} · ${String(o.payment_status || "pending")}`;

  return <>
    <main id="main-content" tabIndex={-1} className="customer-page profile-subpage order-detail-page">
      <div className="order-detail-shell">
        <Link className="order-detail-back" href="/?browse=1#orders"><ArrowLeft size={17} aria-hidden="true"/>Back to orders</Link>
        <header className="order-detail-heading">
          <div>
            <p className="eyebrow">ORDER TRACKING</p>
            <h1>Order details</h1>
            <p className="order-detail-ref">Order #{String(o.id).slice(0, 12).toUpperCase()} · Placed {placedDate}</p>
          </div>
          <span className={`order-detail-status ${status}`}>{status.replaceAll("_", " ")}</span>
        </header>

        <div className="order-detail-layout">
          <div className="order-detail-main-column">
            <section className="order-detail-card" aria-labelledby="order-progress-title">
              <h2 id="order-progress-title">Delivery progress</h2>
              {status === "cancelled" ? (
                <p className="order-detail-cancelled">This order was cancelled. If you need help with a refund or payment status, contact support using the order details below.</p>
              ) : (
                <div className="order-detail-progress" aria-label={`Order status: ${status}`}>
                  {stepLabels.map((label, index) => {
                    const complete = currentStep >= index;
                    return <div className={`order-detail-progress-step${complete ? " is-complete" : ""}${currentStep === index ? " is-current" : ""}`} key={label}>
                      <span>{complete ? <PackageCheck size={15} aria-hidden="true"/> : index + 1}</span>
                      <small>{label}</small>
                    </div>;
                  })}
                </div>
              )}
            </section>

            <section className="order-detail-card" aria-labelledby="order-items-title">
              <h2 id="order-items-title">Items in this order</h2>
              <div className="order-detail-seller"><Store size={17} aria-hidden="true"/><span>{o.seller}</span>
                {o.buyer === u.userId && <Link href={`/store/${encodeURIComponent(o.store)}`}>Visit store</Link>}
              </div>
              <div className="order-detail-items">
                {items.map((item: any, index: number) => <article className="order-detail-item" key={`${item.product || item.name}-${index}`}>
                  <strong>{item.name || "Product"}</strong>
                  <small>{item.quantity} × {money(item.price)}{item.variant ? ` · ${item.variant}` : ""}</small>
                  <span className="order-detail-item-price">{money(Number(item.price || 0) * Number(item.quantity || 0))}</span>
                </article>)}
              </div>
            </section>

            <section className="order-detail-card" aria-labelledby="order-shipping-title">
              <h2 id="order-shipping-title">Delivery &amp; returns</h2>
              <div className="order-detail-info">
                <div className="order-detail-info-row"><MapPin size={18} aria-hidden="true"/><div><strong>Deliver to</strong><span>{o.address ? <>{o.name}{o.phone ? ` · ${o.phone}` : ""}<br/>{o.address}{o.delivery_state ? `, ${o.delivery_state}` : ""}</> : o.payment === "auction" && o.payment_status === "pending" ? "Add your delivery details when you continue to payment." : "Delivery address not provided."}</span></div></div>
                <div className="order-detail-info-row"><Truck size={18} aria-hidden="true"/><div><strong>Delivery estimate</strong><span>{o.delivery_days || "The seller will confirm the delivery estimate."}</span></div></div>
                <div className="order-detail-info-row"><PackageCheck size={18} aria-hidden="true"/><div><strong>Tracking reference{Boolean(o.tracking)&&<a className="cnc-order-tracking-badge" href="#order-progress-title" aria-label="Order Tracking — view delivery progress"><img {...trustBadgeImage("order-tracking")} className="cnc-trust-badge cnc-trust-badge--small"/></a>}</strong><span>{o.tracking || "Tracking details will appear here when the seller adds them."}</span></div></div>
                <div className="order-detail-info-row"><LifeBuoy size={18} aria-hidden="true"/><div><strong>Returns</strong><span>{o.return_policy || "Contact support for help with a return or refund."}</span></div></div>
              </div>
            </section>
          </div>

          <aside className="order-detail-side-column">
            <section className="order-detail-card" aria-labelledby="order-payment-title">
              <h2 id="order-payment-title">Payment summary</h2>
              <div className="order-detail-info-row"><CreditCard size={18} aria-hidden="true"/><div><strong>Payment status</strong><span>{paymentLabel}</span></div></div>
              <div className="order-detail-totals">
                <div><span>Items ({items.reduce((total: number, item: any) => total + Number(item.quantity || 0), 0)})</span><strong>{money(items.reduce((total: number, item: any) => total + Number(item.price || 0) * Number(item.quantity || 0), 0))}</strong></div>
                <div><span>Delivery fee</span><strong>{money(o.delivery_fee)}</strong></div>
                <div className="order-detail-grand-total"><span>{o.payment_status === "paid" ? "Total paid" : "Total due"}</span><strong>{money(o.total)}</strong></div>
              </div>
              {o.buyer === u.userId && ["auction", "flutterwave"].includes(o.payment) && o.payment_status === "pending" && <OrderPaymentAction orderId={id} label={o.payment === "auction" ? "Pay winning bid securely" : "Continue payment"} needsDelivery={o.payment === "auction" && (!o.address || !o.delivery_state || !o.phone)} initialName={o.name || ""} initialPhone={o.phone || ""} />}
            </section>
            <section className="order-detail-card" aria-labelledby="order-actions-title">
              <h2 id="order-actions-title">Need help?</h2>
              <div className="order-detail-actions">
                <Link href={`/workspace?tab=Support&order=${encodeURIComponent(id)}`}><LifeBuoy size={16} aria-hidden="true"/>Support, returns &amp; refunds</Link>
                {o.buyer === u.userId && <>
                  <Link href={`/messages?${new URLSearchParams({ store: o.store, order: id, ...(items[0]?.product ? { product: items[0].product } : {}) })}`}><Store size={16} aria-hidden="true"/>Message seller</Link>
                  <Link href={`/api/orders/receipt?id=${encodeURIComponent(id)}`}><FileText size={16} aria-hidden="true"/>Download order record</Link>
                </>}
              </div>
              <div className="order-detail-info-row order-detail-placed"><CalendarDays size={17} aria-hidden="true"/><div><strong>Order date</strong><span>{placedDate}</span></div></div>
            </section>
          </aside>
        </div>
      </div>
    </main>
    <CustomerNavigation active="Profile" />
  </>;
}
