const CASH_N_CARRY_HOSTS = new Set(["cashncarryng.com", "www.cashncarryng.com"]);
const STOREFRONT_IMAGE_VARIANT_VERSION = "11";

/** Route only Cash N Carry media through the fixed-size storefront thumbnail. */
export function storefrontImageUrl(src: string | null | undefined, width = 640): string {
  if (!src) return "";
  try {
    const url = new URL(src, "https://www.cashncarryng.com");
    const match = /^\/api\/media\/([0-9a-f-]{36})$/i.exec(url.pathname);
    if (!match || !CASH_N_CARRY_HOSTS.has(url.hostname.toLowerCase())) return src;
    const safeWidth = [160, 256, 320, 480, 640, 960, 1200, 1600].includes(width) ? width : 640;
    return `/api/storefront-image/${match[1]}?w=${safeWidth}&v=${STOREFRONT_IMAGE_VARIANT_VERSION}`;
  } catch {
    return src;
  }
}

export function storefrontImageSrcSet(src: string | null | undefined, widths: number[]): string | undefined {
  if (!src) return undefined;
  try {
    const url = new URL(src, "https://www.cashncarryng.com");
    const match = /^\/api\/media\/([0-9a-f-]{36})$/i.exec(url.pathname);
    if (!match || !CASH_N_CARRY_HOSTS.has(url.hostname.toLowerCase())) return undefined;
    return [...new Set(widths.filter((width) => [160, 256, 320, 480, 640, 960, 1200, 1600].includes(width)))]
      .sort((a, b) => a - b)
      .map((width) => `/api/storefront-image/${match[1]}?w=${width}&v=${STOREFRONT_IMAGE_VARIANT_VERSION} ${width}w`)
      .join(", ");
  } catch {
    return undefined;
  }
}

export function normalizeStorefrontSlug(value: string): string {
  return value.toLowerCase().replaceAll("-", "");
}
