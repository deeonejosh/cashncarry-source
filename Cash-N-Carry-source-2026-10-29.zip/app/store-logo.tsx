"use client";
import { useEffect, useRef, useState } from "react";
import ImageAsset from "./image-asset";
import { storefrontImageSrcSet, storefrontImageUrl } from "./storefront-image-url";

export default function StoreLogo({
  name,
  src,
  className = "store-avatar",
  size = 48,
}: {
  name: string;
  src?: string | null;
  className?: string;
  size?: number;
}) {
  const logoContainer = useRef<HTMLSpanElement>(null);
  const [hasImage, setHasImage] = useState(false);
  const [wideLogo, setWideLogo] = useState(false);
  const initial = name.trim().slice(0, 1).toUpperCase() || "S";
  const imageSrc = src ? storefrontImageUrl(src, size) : undefined;
  function markImageLoaded(image: HTMLImageElement) {
    setHasImage(true);
    setWideLogo(image.naturalWidth > image.naturalHeight * 1.2);
  }
  useEffect(() => {
    const image = logoContainer.current?.querySelector("img");
    if (image?.complete && image.naturalWidth > 0) markImageLoaded(image);
  }, [imageSrc]);
  return (
    <span ref={logoContainer} className={`${className} store-logo-avatar${hasImage ? " has-image" : ""}`} aria-hidden="true">
      <span className="store-logo-fallback">{initial}</span>
      {imageSrc && <ImageAsset
        className={`store-logo-image${wideLogo ? " store-logo-image--wide" : ""}`}
        src={imageSrc}
        srcSet={storefrontImageSrcSet(src, [160, 256, 480])}
        sizes={`${size}px`}
        fallbackSrc={src!}
        alt=""
        width={size}
        height={size}
        loading="lazy"
        decoding="async"
        onLoad={(event) => markImageLoaded(event.currentTarget)}
      />}
    </span>
  );
}
