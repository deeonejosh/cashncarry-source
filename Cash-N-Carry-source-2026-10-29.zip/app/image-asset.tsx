"use client";
import { useState, useEffect, useRef, type ImgHTMLAttributes } from "react";
export default function ImageAsset({
  src,
  alt = "",
  fallbackSrc,
  ...props
}: ImgHTMLAttributes<HTMLImageElement> & { fallbackSrc?: string }) {
  const [resolution, setResolution] = useState<{
    src: string;
    fallback: boolean;
    failed: boolean;
  } | null>(null);
  const image = useRef<HTMLImageElement>(null);
  useEffect(() => {
    // A failed SSR image can finish loading before React attaches onError.
    if (src && image.current?.complete && image.current.naturalWidth === 0) {
      const failedSrc = String(src);
      queueMicrotask(() => {
        setResolution((current) => current?.src === failedSrc ? current : {
          src: failedSrc,
          fallback: Boolean(fallbackSrc),
          failed: !fallbackSrc,
        });
      });
    }
  }, [src, fallbackSrc]);
  const sameSource = resolution?.src === String(src);
  const usingFallback = Boolean(sameSource && resolution?.fallback);
  const unavailable = !src || Boolean(sameSource && resolution?.failed);
  const displayedSrc = usingFallback && fallbackSrc ? fallbackSrc : src;
  return (
    <img
      loading="lazy"
      decoding="async"
      {...props}
      ref={image}
      className={[props.className, unavailable ? "image-unavailable" : ""]
        .filter(Boolean)
        .join(" ")}
      src={unavailable ? "/image-unavailable.svg" : displayedSrc}
      srcSet={usingFallback || unavailable ? undefined : props.srcSet}
      alt={
        unavailable && alt !== ""
          ? `Photo unavailable${alt ? ": " + alt : ""}`
          : alt
      }
      onError={(event) => {
        setResolution({
          src: String(src || ""),
          fallback: Boolean(fallbackSrc && !usingFallback),
          failed: !(fallbackSrc && !usingFallback),
        });
        props.onError?.(event);
      }}
    />
  );
}
