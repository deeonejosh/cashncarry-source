"use client";
import { useState } from "react";
import { Share2 } from "lucide-react";

export default function ProductShare({ name }: { name: string }) {
  const [message, setMessage] = useState("");
  async function copyLink(url: string) {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(url);
      return true;
    }
    const input = document.createElement("textarea");
    input.value = url;
    input.setAttribute("readonly", "");
    input.style.position = "fixed";
    input.style.opacity = "0";
    document.body.append(input);
    input.select();
    const copied = document.execCommand("copy");
    input.remove();
    return copied;
  }
  async function share() {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: name, url });
      else setMessage(await copyLink(url) ? "Product link copied." : "Copy the product link from your browser address bar.");
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      try { setMessage(await copyLink(url) ? "Product link copied." : "Copy the product link from your browser address bar."); }
      catch { setMessage("Copy the product link from your browser address bar."); }
    }
  }
  return <span className="product-share-control"><button type="button" className="secondary-button" onClick={() => void share()}><Share2 size={17}/>Share product</button><span className="sr-only" role="status" aria-live="polite">{message}</span></span>;
}
