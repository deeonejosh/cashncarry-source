"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type ProductReview = { rating: number; comment: string; created: string };
type ReviewableOrder = { id: string; status: string; created?: string; items?: { product?: string }[] };
export default function ProductReviews({
  productName, average, count, reviews, productId, signedIn,
}: {
  productName: string;
  average: number;
  count: number;
  reviews: ProductReview[];
  productId: string;
  signedIn: boolean;
}) {
  const router = useRouter();
  const [orders, setOrders] = useState<{ id: string; created: string }[]>([]);
  const [order, setOrder] = useState("");
  const [rating, setRating] = useState("5");
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [ordersLoading, setOrdersLoading] = useState(Boolean(signedIn));
  const [retryOrders, setRetryOrders] = useState(0);

  useEffect(() => {
    if (!signedIn) return;
    let active = true;
    fetch("/api/commerce", { signal: AbortSignal.timeout(15000) })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw Error(data.error || "Order history is unavailable.");
        return (Array.isArray(data.orders) ? data.orders : []) as ReviewableOrder[];
      })
      .then((buyerOrders) => {
        if (!active) return;
        const eligible = buyerOrders.filter((item) => item.status === "delivered" && Array.isArray(item.items) && item.items.some((line) => line.product === productId));
        setOrders(eligible.map((item) => ({ id: String(item.id), created: String(item.created || "") })));
        setOrder(String(eligible[0]?.id || ""));
      })
      .catch((error) => { if (active) setFeedback(error instanceof Error ? error.message : "Order history is unavailable."); })
      .finally(() => { if (active) setOrdersLoading(false); });
    return () => { active = false; };
  }, [productId, signedIn, retryOrders]);

  async function submitReview(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || !order || comment.trim().length < 2) return;
    setBusy(true); setFeedback("");
    try {
      const response = await fetch("/api/commerce", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "review", order, product: productId, rating: Number(rating), comment: comment.trim() }),
        signal: AbortSignal.timeout(15000),
      });
      const data = await response.json();
      if (!response.ok) throw Error(data.error || "Unable to submit the review.");
      setFeedback("Review submitted."); setComment(""); setExpanded(false); router.refresh();
    } catch (error) { setFeedback(error instanceof Error ? error.message : "Check your connection and try again."); }
    finally { setBusy(false); }
  }

  return (
    <section id="product-reviews" className="product-reviews" aria-labelledby="product-reviews-title">
      <div className="product-reviews-heading"><div><p className="eyebrow">Verified buyer feedback</p><h2 id="product-reviews-title">Reviews for {productName}</h2></div>{count > 0 && <p className="product-reviews-summary"><strong aria-label={`${average.toFixed(1)} out of 5 stars`}>★ {average.toFixed(1)}</strong> · {count} {count === 1 ? "review" : "reviews"}</p>}</div>
      {reviews.length ? <div className="product-reviews-list">{reviews.map((review, index) => <article className="product-review-card" key={`${review.created}-${index}`}><p className="product-review-rating" aria-label={`${review.rating} out of 5 stars`}>{"★".repeat(review.rating)}{"☆".repeat(5 - review.rating)}</p><p>{review.comment || "The buyer left a rating without a written comment."}</p><div><span>Verified purchase</span><time dateTime={review.created}>{new Date(review.created).toLocaleDateString("en-NG", { timeZone: "Africa/Lagos", dateStyle: "medium" })}</time></div></article>)}</div> : <p className="product-reviews-empty">No reviews yet. Buyers can review this product after a delivered order.</p>}
      {count > reviews.length && <p className="product-reviews-note">Showing the latest {reviews.length} of {count} reviews.</p>}
      <div className="product-review-submit">
        {!signedIn ? <Link href={`/sign-in?returnTo=${encodeURIComponent(`/product/${productId}#product-reviews`)}`}>Sign in to review this product</Link> : ordersLoading ? <p role="status">Checking delivered orders…</p> : feedback && !orders.length ? <p role="alert">{feedback} <button type="button" onClick={() => { setFeedback(""); setOrdersLoading(true); setRetryOrders((value) => value + 1); }}>Retry</button></p> : orders.length ? <>
          {!expanded && <button type="button" onClick={() => setExpanded(true)}>Write a review</button>}
          {expanded && <form onSubmit={(event) => void submitReview(event)}>
            {orders.length > 1 && <label>Delivered order<select value={order} onChange={(event) => setOrder(event.target.value)}>{orders.map((item) => <option value={item.id} key={item.id}>{new Date(item.created).toLocaleDateString("en-NG", { timeZone: "Africa/Lagos", dateStyle: "medium" })}</option>)}</select></label>}
            <label>Rating<select value={rating} onChange={(event) => setRating(event.target.value)}>{[5,4,3,2,1].map((value) => <option key={value} value={value}>{value} star{value === 1 ? "" : "s"}</option>)}</select></label>
            <label>Your review<textarea value={comment} onChange={(event) => setComment(event.target.value)} maxLength={1000} required minLength={2} placeholder="Share your experience with this product" /></label>
            <div><button type="submit" disabled={busy || comment.trim().length < 2}>{busy ? "Submitting…" : "Submit review"}</button><button type="button" disabled={busy} onClick={() => setExpanded(false)}>Cancel</button></div>
          </form>}
        </> : <p>Only buyers with a delivered order can review this product.</p>}
        <p role="status" aria-live="polite">{feedback}</p>
      </div>
    </section>
  );
}
