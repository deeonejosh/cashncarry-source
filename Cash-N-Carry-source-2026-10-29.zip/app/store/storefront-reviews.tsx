"use client";

import { useMemo, useState } from "react";
import { Search, Star } from "lucide-react";

type StoreReview = {
  rating: number;
  comment: string;
  product: string;
  created: string;
  dateLabel: string;
};

type StorefrontReviewsProps = {
  average: number;
  count: number;
  distribution: Record<number, number>;
  reviews: StoreReview[];
};

function Stars({ rating, label }: { rating: number; label: string }) {
  return (
    <span className="store-review-stars" aria-label={label}>
      <span aria-hidden="true">
        {[1, 2, 3, 4, 5].map((star) => (
          <span className={star <= rating ? "is-filled" : ""} key={star}>★</span>
        ))}
      </span>
      <span className="store-review-sr-only">{label}</span>
    </span>
  );
}

export default function StorefrontReviews({
  average,
  count,
  distribution,
  reviews,
}: StorefrontReviewsProps) {
  const [query, setQuery] = useState("");
  const [ratingFilter, setRatingFilter] = useState("all");
  const [sort, setSort] = useState("recent");

  const filteredReviews = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    return reviews
      .filter((review) => ratingFilter === "all" || review.rating === Number(ratingFilter))
      .filter((review) => !normalizedQuery || `${review.comment} ${review.product}`.toLocaleLowerCase().includes(normalizedQuery))
      .slice()
      .sort((a, b) => {
        if (sort === "highest") return b.rating - a.rating || b.created.localeCompare(a.created);
        if (sort === "lowest") return a.rating - b.rating || b.created.localeCompare(a.created);
        return b.created.localeCompare(a.created);
      });
  }, [query, ratingFilter, reviews, sort]);

  return (
    <section id="store-reviews" className="storefront-reviews" aria-labelledby="store-reviews-title">
      <div className="store-reviews-heading">
        <div>
          <p className="store-reviews-eyebrow">Buyer feedback</p>
          <h2 id="store-reviews-title">Customer reviews</h2>
          <p>Ratings and comments from delivered orders.</p>
        </div>
        <a className="store-reviews-jump" href="#store-products">Continue shopping</a>
      </div>

      <div className="store-reviews-overview">
        <div className="store-reviews-score">
          <span className="store-reviews-score-label">Store rating</span>
          <div className="store-reviews-score-line">
            <strong>{count > 0 ? average.toFixed(1) : "—"}</strong>
            <span> / 5</span>
          </div>
          {count > 0 ? (
            <>
              <Stars rating={Math.round(average)} label={`${average.toFixed(1)} out of 5 stars`} />
              <p>Based on {count} delivered-order {count === 1 ? "review" : "reviews"}</p>
            </>
          ) : (
            <p>No customer reviews yet</p>
          )}
        </div>

        <div className="store-reviews-breakdown" aria-label="Rating breakdown">
          {[5, 4, 3, 2, 1].map((stars) => {
            const amount = Number(distribution[stars] || 0);
            const percentage = count > 0 ? Math.round((amount / count) * 100) : 0;
            return (
              <div className="store-reviews-breakdown-row" key={stars}>
                <span>{stars} star{stars === 1 ? "" : "s"}</span>
                <span
                  className="store-reviews-meter"
                  role="progressbar"
                  aria-label={`${stars} star reviews`}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={percentage}
                >
                  <span style={{ width: `${percentage}%` }} />
                </span>
                <span className="store-reviews-breakdown-count">{amount}</span>
              </div>
            );
          })}
        </div>
      </div>

      {reviews.length > 0 ? (
        <div className="store-reviews-list">
          <div className="store-reviews-list-heading">
            <div>
              <h3>Latest buyer reviews</h3>
              {count > reviews.length && <p>Showing the latest {reviews.length} of {count} reviews.</p>}
            </div>
            {reviews.length > 3 && (
              <div className="store-reviews-controls">
                <label className="store-review-search">
                  <Search size={17} aria-hidden="true" />
                  <span className="store-review-sr-only">Search recent reviews</span>
                  <input
                    type="search"
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="Search recent reviews"
                  />
                </label>
                <label className="store-review-select-label">
                  <span>Rating</span>
                  <select value={ratingFilter} onChange={(event) => setRatingFilter(event.target.value)}>
                    <option value="all">All ratings</option>
                    {[5, 4, 3, 2, 1].map((rating) => <option key={rating} value={rating}>{rating} stars</option>)}
                  </select>
                </label>
                <label className="store-review-select-label">
                  <span>Sort</span>
                  <select value={sort} onChange={(event) => setSort(event.target.value)}>
                    <option value="recent">Most recent</option>
                    <option value="highest">Highest rated</option>
                    <option value="lowest">Lowest rated</option>
                  </select>
                </label>
              </div>
            )}
          </div>

          {filteredReviews.length > 0 ? (
            <div className="store-reviews-cards" aria-live="polite">
              {filteredReviews.map((review, index) => (
                <article className="store-review-card" key={`${review.created}-${index}`}>
                  <div className="store-review-card-top">
                    <Stars rating={review.rating} label={`${review.rating} out of 5 stars`} />
                    <span className="store-review-verified"><Star size={13} aria-hidden="true" /> Verified purchase</span>
                  </div>
                  <p className="store-review-product">Purchased <strong>{review.product}</strong></p>
                  <p className="store-review-comment">{review.comment || "The buyer left a rating without a written comment."}</p>
                  <div className="store-review-meta">
                    <span>Verified buyer</span>
                    <time dateTime={review.created}>{review.dateLabel}</time>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="store-reviews-empty" role="status">
              <p>No recent reviews match those filters.</p>
              <button type="button" onClick={() => { setQuery(""); setRatingFilter("all"); }}>
                Clear filters
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="store-reviews-empty">
          <p>When a buyer shares feedback after a delivered order, it will appear here.</p>
        </div>
      )}
    </section>
  );
}
