import { sellerActivation, eligibleSellerSQL } from "../../seller-activation";
import { ensureCompetitiveSchema } from "../../competitive-schema";
import { ensureVideoStorefrontSchema } from "../../video-storefront-schema";
import StoreActions from "../../store-actions";
import StoreProductActions from "../../store-product-actions";
import { getChatGPTUser } from "../../chatgpt-auth";
import ImageAsset from "../../image-asset";
import StoreLogo from "../../store-logo";
import { readableButtonText } from "../../storefront-button-color";
import { paginateStorefrontProducts } from "../../storefront-pagination";
import { normalizeStorefrontSlug, storefrontImageSrcSet, storefrontImageUrl } from "../../storefront-image-url";
import { brand } from "../../brand";
import { StorefrontFooter } from "../../shopping-design";
import { broadcastLabel } from "../../broadcasts";
import { env } from "cloudflare:workers";
import { notFound } from "next/navigation";
import { Search } from "lucide-react";
import { trustBadgeImage } from "../../trust-badge-image";
import { topSellerEligibilitySQL } from "../../trust-badge-eligibility";
import { ensureTrustBadgeSchema } from "../../trust-badge-schema";
const scheduleCutoff = () => new Date(Date.now() - 86400000).toISOString();
function safeJsonArray(value: unknown): any[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== "string" || !value) return [];
  try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : []; } catch { return []; }
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const paramId = (await params).id;
  const s: any = await env.DB?.prepare(
    "SELECT COALESCE(NULLIF(CASE WHEN f.published=1 THEN f.display_name END,''),s.name) AS name,COALESCE(NULLIF(CASE WHEN f.published=1 THEN f.description END,''),s.description) AS description,CASE WHEN f.published=1 THEN f.slug END AS slug,CASE WHEN f.published=1 THEN f.banner END AS banner FROM stores s LEFT JOIN storefronts f ON f.store=s.id WHERE (s.id=? OR (f.published=1 AND (f.slug=? OR (lower(replace(f.slug,'-',''))=? AND (SELECT COUNT(*) FROM storefronts f2 JOIN stores s2 ON s2.id=f2.store WHERE f2.published=1 AND lower(replace(f2.slug,'-',''))=lower(replace(f.slug,'-','')) AND s2.suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles x2 WHERE x2.id=s2.owner AND x2.suspended=1))=1)))) AND s.suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
  ).bind(paramId, paramId.toLowerCase(), normalizeStorefrontSlug(paramId)).first();
  const title = `${s?.name || "Store unavailable"} | ${brand.name}`;
  const canonical = "/store/" + (s?.slug || paramId);
  return {
    title,
    alternates: { canonical },
    description: s?.description,
    openGraph: { url: canonical, title, siteName: brand.name, description: s?.description, images: s?.banner ? [s.banner] : undefined },
  };
}
export default async function Store({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ q?: string; category?: string; page?: string; sort?: string }>;
}) {
  await ensureCompetitiveSchema();
  await ensureVideoStorefrontSchema();
  await ensureTrustBadgeSchema();
  const { id } = await params;
  const filters = await searchParams;
  const term = String(filters.q || "").trim().slice(0, 100);
  const category = String(filters.category || "").trim().slice(0, 60);
  const s: any = await env.DB?.prepare(
    `SELECT s.id,s.owner,s.created,COALESCE(NULLIF(CASE WHEN f.published=1 THEN f.display_name END,''),s.name) AS name,COALESCE(NULLIF(CASE WHEN f.published=1 THEN f.description END,''),s.description) AS description,COALESCE(NULLIF(CASE WHEN f.published=1 THEN f.category END,''),s.category) AS category,s.location,s.coverage,s.delivery_days,s.return_policy,s.official_store,CASE WHEN ${topSellerEligibilitySQL("s")} THEN 1 ELSE 0 END AS top_seller,CASE WHEN f.published=1 THEN f.slug END AS slug,CASE WHEN f.published=1 THEN f.logo END AS logo,CASE WHEN f.published=1 THEN f.banner END AS banner,CASE WHEN f.published=1 THEN f.promo_banner END AS promo_banner,CASE WHEN f.published=1 THEN f.template END AS template,CASE WHEN f.published=1 THEN f.accent END AS accent,CASE WHEN f.published=1 THEN f.background_color END AS background_color,CASE WHEN f.published=1 THEN f.surface_color END AS surface_color,CASE WHEN f.published=1 THEN f.buy_now_color END AS buy_now_color,CASE WHEN f.published=1 THEN f.featured_products END AS featured_products,EXISTS(SELECT 1 FROM founding_enrollments fe JOIN founding_program fp ON fp.id=1 WHERE fe.store=s.id AND fe.status='active' AND fp.enabled=1 AND fe.starts_at<=strftime('%Y-%m-%dT%H:%M:%fZ','now') AND fe.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now')) AS founding_seller FROM stores s LEFT JOIN storefronts f ON f.store=s.id WHERE (s.id=? OR (f.published=1 AND (f.slug=? OR (lower(replace(f.slug,'-',''))=? AND (SELECT COUNT(*) FROM storefronts f2 JOIN stores s2 ON s2.id=f2.store WHERE f2.published=1 AND lower(replace(f2.slug,'-',''))=lower(replace(f.slug,'-','')) AND s2.suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles x2 WHERE x2.id=s2.owner AND x2.suspended=1))=1)))) AND s.suspended=0 AND NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)`,
  )
    .bind(id, id.toLowerCase(), normalizeStorefrontSlug(id))
    .first();
  if (!s) notFound();
  const [productRows, streamRows, followCount, reviewRows] =
    await Promise.all([
      env
        .DB!.prepare(
          "SELECT p.*,stock,variants,(SELECT COALESCE(SUM(i.quantity),0) FROM order_items i JOIN orders o ON o.id=i.order_id AND o.status IN ('paid','processing','shipped','delivered') WHERE i.product=p.id) AS purchased FROM products p WHERE p.store=? AND p.active=1 AND p.store IN (SELECT s.id FROM stores s WHERE " + eligibleSellerSQL() + ") ORDER BY p.created DESC,p.id ASC",
        )
        .bind(s.id)
        .all<any>(),
      env
        .DB!.prepare(
          "SELECT l.id,l.title,l.scheduled,l.status,l.provider,l.replay,l.url,l.product,p.image AS product_image FROM streams l LEFT JOIN products p ON p.id=l.product WHERE l.store=? AND l.store IN (SELECT s.id FROM stores s WHERE " + eligibleSellerSQL('s') + ") AND (l.status IN ('live','scheduled','external') OR (l.status='ended' AND l.replay!='')) AND NOT (l.provider='native' AND l.status='live' AND COALESCE(julianday(l.heartbeat),0)<julianday('now','-90 seconds')) AND NOT (l.status='scheduled' AND (l.scheduled='' OR l.scheduled<?)) ORDER BY l.created DESC LIMIT 30",
        )
        .bind(s.id, scheduleCutoff())
        .all<any>(),
      env.DB!.prepare("SELECT COUNT(*) AS count FROM follows WHERE store=?").bind(s.id).first<any>(),
      env.DB!.prepare("SELECT r.product,ROUND(AVG(r.rating),1) AS rating_average,COUNT(*) AS review_count FROM reviews r JOIN orders o ON o.id=r.order_id AND o.status='delivered' JOIN products p ON p.id=r.product WHERE p.store=? AND p.active=1 GROUP BY r.product").bind(s.id).all<any>(),
    ]);
  const productReviewById = new Map(reviewRows.results.map((row: any) => [row.product, row]));
  const allProducts = productRows.results.map((product: any) => ({
    ...product,
    rating_average: productReviewById.get(product.id)?.rating_average || 0,
    review_count: productReviewById.get(product.id)?.review_count || 0,
  }));
  const categories = [...new Set(allProducts.map((p: any) => p.category).filter(Boolean))].sort();
  const sort = ["newest", "best"].includes(filters.sort || "") ? filters.sort : "newest";
  const filteredProducts = allProducts.filter((p: any) =>
    (!category || p.category === category) &&
    (!term || `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(term.toLowerCase())),
  ).sort((a: any,b: any) => sort === "best" ? Number(b.purchased||0)-Number(a.purchased||0) || String(b.created).localeCompare(String(a.created)) : String(b.created).localeCompare(String(a.created)));
  const { items: products, page, pageCount, pageSize, start } = paginateStorefrontProducts(filteredProducts, filters.page);
  const storeAccent = typeof s.accent === "string" && /^#[\da-f]{6}$/i.test(s.accent) ? s.accent : "#164B35";
  const storeBackground = typeof s.background_color === "string" && /^#[\da-f]{6}$/i.test(s.background_color) ? s.background_color : "#fff8ef";
  const storeSurface = typeof s.surface_color === "string" && /^#[\da-f]{6}$/i.test(s.surface_color) ? s.surface_color : "#ffffff";
  const buyNowColor = typeof s.buy_now_color === "string" && /^#[\da-f]{6}$/i.test(s.buy_now_color) ? s.buy_now_color : "#164B35";
  const streams = streamRows.results;
  const featuredIds: string[] = safeJsonArray(s.featured_products).filter((value): value is string => typeof value === "string");
  // Only show a separate featured row when the seller deliberately selected
  // featured products. Previously the first four products were duplicated
  // above the catalog, causing repeated full-size image requests.
  const featured = !term && !category && page === 1 && featuredIds.length
    ? featuredIds.map((id) => allProducts.find((p: any) => p.id === id)).filter(Boolean).slice(0, 4)
    : [];
  // The activation detail is only needed for the empty-store message. Avoid
  // its five extra D1 reads on the normal storefront path with products.
  const activation = products.length === 0 ? await sellerActivation(s.id) : null;
  const user = await getChatGPTUser();
  const following = user
    ? Boolean(
        await env
          .DB!.prepare("SELECT id FROM follows WHERE user=? AND store=?")
          .bind(user.userId, s.id)
          .first(),
      )
    : false;
  const storeQuery = new URLSearchParams();
  if (term) storeQuery.set("q", term);
  if (category) storeQuery.set("category", category);
  if (sort && sort !== "newest") storeQuery.set("sort", sort);
  const storeReturnTo = `/store/${encodeURIComponent(s.slug || s.id)}${storeQuery.size ? `?${storeQuery.toString()}` : ""}#store-products`;
  const productLink = (productId: string) => `/product/${encodeURIComponent(productId)}?returnTo=${encodeURIComponent(storeReturnTo)}`;
  const collectionLink = (value: string) => `/store/${encodeURIComponent(s.slug || s.id)}?${new URLSearchParams({ ...(term ? { q: term } : {}), category: value, ...(sort === "best" ? { sort } : {}) })}#store-products`;
  let coverage: string[] = [];
  try { const parsed = JSON.parse(s.coverage || "[]"); if (Array.isArray(parsed)) coverage = parsed.filter((value: unknown): value is string => typeof value === "string"); } catch { coverage = []; }
  const coverageLabel = coverage.length
    ? coverage.length === 37 ? "Nationwide delivery" : `Delivery to ${coverage.slice(0, 2).join(", ")}${coverage.length > 2 ? ` +${coverage.length - 2}` : ""}`
    : "Confirm delivery with seller";
  const productCard = (p: any, index: number) => {
    let variants: any[] = [];
    try { const parsed = JSON.parse(p.variants || "[]"); if (Array.isArray(parsed)) variants = parsed; } catch { variants = []; }
    const available = variants.length ? variants.some((option) => Number(option.stock) > 0) : Number(p.stock) > 0;
    return <article className="storefront-product shop-style-storefront-product" key={p.id}>
      <a className="storefront-product-image-link shop-style-product-image" href={productLink(p.id)} aria-label={`View ${p.name}`}>
        <ImageAsset src={storefrontImageUrl(p.image, 320)} srcSet={storefrontImageSrcSet(p.image, [320, 480, 640])} sizes="(max-width: 700px) 48vw, (max-width: 1050px) 31vw, 23vw" fallbackSrc={p.image} alt={p.name} width="480" height="332" loading={index === 0 ? "eager" : "lazy"} fetchPriority={index === 0 ? "high" : "auto"} />
        {p.category && <span className="storefront-product-category-tag">{p.category}</span>}
      </a>
      <div className="shop-style-product-info">
        <div className="shop-style-product-seller">
          <a href={`/store/${encodeURIComponent(s.slug || s.id)}`} aria-label={`Visit ${s.name}`}><StoreLogo name={s.name} src={s.logo} size={24} className="product-seller-logo"/><span>{s.name}</span></a>
          <span className="cnc-seller-trust-badges" aria-label="Store status">{s.official_store === 1 && <img {...trustBadgeImage("official-store")} alt="Official Store" className="cnc-trust-badge cnc-trust-badge--small"/>}{s.top_seller === 1 && <img {...trustBadgeImage("top-seller")} alt="Top Seller" className="cnc-trust-badge cnc-trust-badge--small"/>}</span>
        </div>
        <a className="shop-style-product-name" href={productLink(p.id)}>{p.name}</a>
        <div className="shop-style-product-price"><strong>₦{Number(p.price).toLocaleString("en-NG")}</strong>{Number(p.review_count) > 0 && <span className="storefront-product-rating" aria-label={`${Number(p.rating_average).toFixed(1)} out of 5 from ${Number(p.review_count)} reviews`}><span aria-hidden="true">★</span> {Number(p.rating_average).toFixed(1)} <small>({Number(p.review_count)})</small></span>}</div>
        <small className={`shop-style-product-delivery${available ? "" : " is-unavailable"}`}><span aria-hidden="true">⌁</span>{available ? [s.location, coverageLabel].filter(Boolean).join(" · ") : "Sold out"}</small>
        <StoreProductActions product={p} storeId={s.id} signedIn={!!user} buyNowColor={buyNowColor}/>
      </div>
    </article>;
  };
  return (
    <>
      {s.banner && <link rel="preload" as="image" href={storefrontImageUrl(s.banner, 640)} imageSrcSet={storefrontImageSrcSet(s.banner, [320, 480, 640, 960, 1200, 1600])} imageSizes="100vw" fetchPriority="high" />}
      <main
        id="main-content"
        tabIndex={-1}
        className="customer-page storefront-page template-market"
        style={{ "--store-accent": storeAccent, "--store-background": storeBackground, "--store-background-text": readableButtonText(storeBackground), "--store-surface": storeSurface, "--store-surface-text": readableButtonText(storeSurface), "--store-buy-now-color": buyNowColor, "--store-buy-now-text": readableButtonText(buyNowColor) } as React.CSSProperties}
      >
        <section id="store-home" className={`storefront-heading shop-storefront-heading design-card${s.banner ? "" : " storefront-heading--no-banner"}`}>
          <div className={`storefront-banner${s.banner ? "" : " storefront-banner--fallback"}`} style={{ backgroundColor: storeAccent }}>
            {s.banner && <ImageAsset src={storefrontImageUrl(s.banner, 640)} srcSet={storefrontImageSrcSet(s.banner, [320, 480, 640, 960, 1200, 1600])} sizes="100vw" fallbackSrc={s.banner} alt={`${s.name} store banner`} width="1600" height="480" loading="eager" fetchPriority="high" />}
            <div className="storefront-hero-copy"><a href="#store-products">Shop now <span aria-hidden="true">→</span></a></div>
          </div>
          <div className="storefront-brand-row">
            <div className="storefront-profile-image"><StoreLogo name={s.name} src={s.logo} size={104} /></div>
            <div className="storefront-brand-copy">
              <div className="storefront-title-line">
                <h1 className="seller-identity"><span className="seller-name-text">{s.name}</span><span className="cnc-seller-trust-badges">{s.official_store===1&&<img {...trustBadgeImage("official-store")} alt="Official Store" className="cnc-trust-badge cnc-trust-badge--compact"/>}{s.top_seller===1&&<img {...trustBadgeImage("top-seller")} alt="Top Seller" className="cnc-trust-badge cnc-trust-badge--compact"/>}</span></h1>
              </div>
            </div>
          </div>
          <div className="storefront-summary-row">
            <div className="storefront-summary-copy">
              {s.description && <p className="storefront-description">{s.description}</p>}
              <p className="storefront-location">
                {[s.location, `Since ${new Date(s.created).getFullYear()}`, `${Number(followCount?.count || 0).toLocaleString("en-NG")} followers`, `${allProducts.length.toLocaleString("en-NG")} products`].filter(Boolean).join(" · ")}
              </p>
            </div>
            <StoreActions id={s.id} following={following} shareUrl={"/store/" + (s.slug || s.id)} ownerId={s.owner} viewerId={user?.userId} />
          </div>
        </section>
        <nav className="storefront-tabs" aria-label="Storefront sections">
          <a href="#store-home">Overview</a>
          <a href="#store-products">All products</a>
          {featured.length > 0 && <a href="#store-featured">Featured</a>}
          {categories.map((value: string) => <a className="storefront-category-link" key={value} href={`/store/${encodeURIComponent(s.slug || s.id)}?${new URLSearchParams({ ...(term ? { q: term } : {}), category: value, ...(sort === "best" ? { sort } : {}) }).toString()}#store-products`} aria-current={category === value ? "page" : undefined}>{value}</a>)}
          <a href={`/store/${encodeURIComponent(s.slug || s.id)}?${new URLSearchParams({ ...(term ? { q: term } : {}), ...(category ? { category } : {}), sort: "newest" }).toString()}#store-products`}>New arrivals</a>
          <a href={`/store/${encodeURIComponent(s.slug || s.id)}?${new URLSearchParams({ ...(term ? { q: term } : {}), ...(category ? { category } : {}), sort: "best" }).toString()}#store-products`}>Best sellers</a>
          {streams.length > 0 && <a href="#store-broadcasts">Live shopping</a>}
          <form action={`/store/${encodeURIComponent(s.slug || s.id)}`} method="get" role="search" aria-label={`Search ${s.name} products`}>
            <label><Search size={16} aria-hidden="true" /><span className="sr-only">Search this store</span><input name="q" type="search" defaultValue={term} placeholder="Search this store" /></label>
          </form>
        </nav>
        {categories.length > 0 && <section className="storefront-collections" aria-labelledby="storefront-collections-title">
          <div className="storefront-section-heading"><div><p>CURATED BY {s.name.toUpperCase()}</p><h2 id="storefront-collections-title">Shop collections</h2></div><span>{categories.length} {categories.length === 1 ? "collection" : "collections"}</span></div>
          <div className="storefront-collection-grid">
            {categories.map((value: string) => {
              const sample = allProducts.find((product: any) => product.category === value && product.image);
              const count = allProducts.filter((product: any) => product.category === value).length;
              return <a className="storefront-collection-card" key={value} href={collectionLink(value)}>
                <span className="storefront-collection-image">{sample?.image && <ImageAsset src={storefrontImageUrl(sample.image, 640)} srcSet={storefrontImageSrcSet(sample.image, [320,480,640])} sizes="(max-width: 700px) 72vw, 300px" fallbackSrc={sample.image} alt="" width="640" height="420" loading="lazy"/>}</span>
                <span><strong>{value}</strong><small>{count} {count === 1 ? "product" : "products"}</small></span>
              </a>;
            })}
          </div>
        </section>}
        {s.promo_banner && <section className="storefront-collection-banner" aria-label="Featured store collection">
          <ImageAsset src={storefrontImageUrl(s.promo_banner, 1200)} srcSet={storefrontImageSrcSet(s.promo_banner, [640, 960, 1200])} sizes="(max-width: 720px) 100vw, 1180px" fallbackSrc={s.promo_banner} alt={`${s.name} featured collection`} width="1200" height="320" loading="lazy" />
          <div><p>Featured collection</p><h2>Explore the latest from {s.name}</h2><a href="#store-products">Shop collection <span aria-hidden="true">→</span></a></div>
        </section>}
        {featured.length > 0 && (
          <>
            <h2 id="store-featured">Featured products</h2>
            <div className="storefront-product-grid">
              {featured.map(productCard)}
            </div>
          </>
        )}
        <div className="storefront-section-heading storefront-products-heading" id="store-products"><div><p>EXPLORE THIS SELLER’S CATALOGUE</p><h2>Products</h2></div><span>{filteredProducts.length} {filteredProducts.length === 1 ? "product" : "products"}</span></div>
        <form method="get" className="storefront-filter" aria-label="Sort products">
          {term && <input type="hidden" name="q" value={term} />}{category && <input type="hidden" name="category" value={category} />}
          <label className="storefront-sort-label"><span>Sort by</span><select name="sort" defaultValue={sort || "newest"} aria-label="Sort products"><option value="newest">New arrivals</option><option value="best">Best sellers</option></select></label>
          <button type="submit">Apply sort</button>
          {(term || category || sort === "best") && <a href={`/store/${encodeURIComponent(s.slug || s.id)}#store-products`}>Clear filters</a>}
        </form>
        <div className="storefront-product-grid">
          {products.length ? (
            products.map(productCard)
          ) : (
            <p>{activation?.canSell ? "No products listed yet." : "This store is not accepting new orders right now. You can still contact the seller about an existing order."}</p>
          )}
        </div>
        {filteredProducts.length > 0 && <nav className="storefront-pagination" aria-label="Product pages">
          <p aria-live="polite">Showing {start + 1}–{Math.min(start + pageSize, filteredProducts.length)} of {filteredProducts.length} products</p>
          <div>
            {page > 1 && <a href={`/store/${encodeURIComponent(s.slug || s.id)}?${new URLSearchParams({ ...(term ? { q: term } : {}), ...(category ? { category } : {}), ...(sort === "best" ? { sort } : {}), page: String(page - 1) }).toString()}#store-products`}>Previous</a>}
            <span>Page {page} of {pageCount}</span>
            {page < pageCount && <a href={`/store/${encodeURIComponent(s.slug || s.id)}?${new URLSearchParams({ ...(term ? { q: term } : {}), ...(category ? { category } : {}), ...(sort === "best" ? { sort } : {}), page: String(page + 1) }).toString()}#store-products`}>Next</a>}
          </div>
        </nav>}
        {streams.length > 0 && <><h2 id="store-broadcasts">Broadcasts</h2>
        <div className="storefront-broadcast-grid">
          {streams.length ? (
            streams.map((x: any) => (
              <article key={x.id}>
                {x.product_image && <ImageAsset src={storefrontImageUrl(x.product_image, 480)} srcSet={storefrontImageSrcSet(x.product_image, [320, 480, 640])} sizes="(max-width: 700px) 90vw, 320px" fallbackSrc={x.product_image} alt="" width="320" height="180" loading="lazy" />}
                <h3>{x.title}</h3>
                <p>
                  {x.status === "live" ? <strong className="storefront-live-badge">LIVE NOW</strong> : null} {broadcastLabel(x)}
                  {x.status === "scheduled" && x.scheduled
                    ? " · " +
                      new Date(x.scheduled).toLocaleString("en-NG", {
                        timeZone: "Africa/Lagos",
                      }) +
                      " WAT"
                    : ""}
                </p>
                {x.status === "ended" && !x.replay ? (
                  <p>Session ended. No replay is available.</p>
                ) : x.provider === "tiktok" && x.status === "external" ? (
                  <a href={x.url} target="_blank" rel="noopener noreferrer">
                    Watch on TikTok
                  </a>
                ) : (
                  <a href={"/?stream=" + encodeURIComponent(x.id)}>
                    {x.status === "ended"
                      ? "Watch replay"
                      : x.status === "scheduled"
                        ? "View scheduled broadcast"
                        : "Watch live"}
                  </a>
                )}
              </article>
            ))
          ) : (
            <p>No broadcasts scheduled.</p>
          )}
        </div></>}
      </main>
      <StorefrontFooter storeName={s.name} storeDescription={s.description} storeId={s.id} categories={categories} surfaceColor={storeSurface} surfaceText={readableButtonText(storeSurface)} accentColor={storeAccent} />
    </>
  );
}
