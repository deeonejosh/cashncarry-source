"use client";

import BrandLogo from "./brand-logo";
import ReVibe from "./revibe";
export const WELCOME_KEY = "cash-n-carry:welcome-seen:v1";
export function Welcome() {
  function start() {
    try { localStorage.setItem(WELCOME_KEY, "1"); } catch { /* Browsing works without storage. */ }
    window.location.assign("/?browse=1#market");
  }
  return <main id="main-content" tabIndex={-1} className="entry-shell welcome-shell">
    <div className="entry-panel welcome-panel">
      <BrandLogo tagline />
      <img className="welcome-photo" src="/seller-hero.webp" srcSet="/seller-hero-640.webp 640w, /seller-hero.webp 1050w" sizes="(max-width: 680px) 100vw, 560px" alt="Nigerian seller presenting a handbag in her shop" width={1050} height={700} fetchPriority="high" decoding="async" />
      <h1>Welcome to Cash N Carry</h1>
      <p>Discover local sellers, watch products live and shop your favourites.</p>
      <button className="entry-primary" onClick={start}>Get Started</button>
      <a className="entry-secondary" href="/sign-in">Sign in</a>
    </div>
  </main>;
}
export default function Entry({ initialData, initialCatalogue, initialView }: {initialData?:any;initialCatalogue?:any;initialView?:string}) {
 return <ReVibe initialData={initialData} initialCatalogue={initialCatalogue} initialView={initialView}/>;
}
