import { imageDimensions, imageDimensionsProblem } from "./image-validation";

type PhotonImageLike = {
  free(): void;
  get_width(): number;
  get_height(): number;
  get_bytes(): Uint8Array;
  get_bytes_jpeg(quality: number): Uint8Array;
  get_bytes_webp(): Uint8Array;
};

type PhotonApi = {
  PhotonImage: { new_from_byteslice(bytes: Uint8Array): PhotonImageLike };
  SamplingFilter: { Lanczos3: number };
  resize(image: PhotonImageLike, width: number, height: number, filter: number): PhotonImageLike;
};

export const MAX_TRANSFORM_BYTES = 12 * 1024 * 1024;
export const MAX_TRANSFORM_PIXELS = 20_000_000;
export type OptimizedStorefrontImage = { bytes: Uint8Array; contentType: "image/jpeg" | "image/png" | "image/webp" };

function detectImageContentType(bytes: Uint8Array): string | null {
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 &&
      bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a) return "image/png";
  if (String.fromCharCode(...bytes.subarray(0, 4)) === "RIFF" &&
      String.fromCharCode(...bytes.subarray(8, 12)) === "WEBP") return "image/webp";
  return null;
}

function hasCompletePngChunks(bytes: Uint8Array): boolean {
  if (detectImageContentType(bytes) !== "image/png") return true;
  let offset = 8;
  while (offset + 12 <= bytes.length) {
    const length = new DataView(bytes.buffer, bytes.byteOffset + offset, 4).getUint32(0, false);
    const end = offset + 12 + length;
    if (end > bytes.length) return false;
    const type = String.fromCharCode(bytes[offset + 4], bytes[offset + 5], bytes[offset + 6], bytes[offset + 7]);
    // Some valid uploads contain ancillary bytes after IEND. Ignore that
    // trailing data, but reject missing/truncated chunks before IEND.
    if (type === "IEND") return true;
    offset = end;
  }
  return false;
}

function hasTransparency(bytes: Uint8Array, contentType: string): boolean {
  if (contentType === "image/jpeg") return false;
  if (contentType === "image/png") {
    // PNG color types 4 and 6 carry alpha. A tRNS chunk adds transparency to
    // palette and grayscale/RGB images, so scan chunk headers without decoding
    // the full pixel buffer.
    if (bytes[25] === 4 || bytes[25] === 6) return true;
    let offset = 8;
    while (offset + 12 <= bytes.length) {
      const length = new DataView(bytes.buffer, bytes.byteOffset + offset, 4).getUint32(0, false);
      if (offset + 12 + length > bytes.length) return true;
      const type = String.fromCharCode(bytes[offset + 4], bytes[offset + 5], bytes[offset + 6], bytes[offset + 7]);
      if (type === "tRNS") return true;
      offset += 12 + length;
      if (type === "IEND") break;
    }
    return false;
  }
  // WebP may carry alpha in VP8X/VP8L. Preserve it unless the extended header
  // explicitly declares the image opaque.
  if (contentType === "image/webp" && String.fromCharCode(...bytes.subarray(12, 16)) === "VP8X") {
    return (bytes[20] & 0x10) !== 0;
  }
  return true;
}

function hasSafeJpegOrientation(bytes: Uint8Array): boolean {
  if (bytes[0] !== 0xff || bytes[1] !== 0xd8) return false;
  let offset = 2;
  while (offset + 4 < bytes.length && bytes[offset] === 0xff) {
    const marker = bytes[offset + 1];
    if (marker === 0xda || marker === 0xd9) break;
    const length = (bytes[offset + 2] << 8) | bytes[offset + 3];
    if (length < 2 || offset + 2 + length > bytes.length) return false;
    if (marker === 0xe1 && length >= 10 &&
        String.fromCharCode(...bytes.subarray(offset + 4, offset + 10)) === "Exif\0\0") {
      const tiff = offset + 10;
      const little = bytes[tiff] === 0x49 && bytes[tiff + 1] === 0x49;
      const big = bytes[tiff] === 0x4d && bytes[tiff + 1] === 0x4d;
      if (!little && !big) return false;
      const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      const u16 = (at: number) => view.getUint16(at, little);
      const u32 = (at: number) => view.getUint32(at, little);
      if (u16(tiff + 2) !== 42) return false;
      const ifd = tiff + u32(tiff + 4);
      if (ifd + 2 > offset + 2 + length) return false;
      const count = u16(ifd);
      for (let i = 0; i < count; i++) {
        const entry = ifd + 2 + i * 12;
        if (entry + 12 > offset + 2 + length) return false;
        if (u16(entry) === 0x0112) return u16(entry + 8) === 1;
      }
      return true;
    }
    offset += 2 + length;
  }
  return true;
}

/** Resize a validated image without upscaling or changing its aspect ratio. */
export function optimizeStorefrontImage(
  bytes: Uint8Array,
  _contentType: string,
  width: number,
  photon: PhotonApi,
  onSkip?: (reason: string) => void,
): OptimizedStorefrontImage | null {
  if (bytes.byteLength > MAX_TRANSFORM_BYTES) { onSkip?.("input_too_large"); return null; }
  // Older uploads may have missing or stale R2 Content-Type metadata. Trust
  // the validated file signature for safe image processing instead.
  const detectedType = detectImageContentType(bytes);
  if (!detectedType || !["image/jpeg", "image/png", "image/webp"].includes(detectedType)) { onSkip?.("unsupported_signature"); return null; }
  if (!hasCompletePngChunks(bytes)) { onSkip?.("incomplete_png"); return null; }
  const dimensions = imageDimensions(detectedType, bytes);
  if (imageDimensionsProblem(dimensions) || !dimensions) { onSkip?.("invalid_dimensions"); return null; }
  if (dimensions.width * dimensions.height > MAX_TRANSFORM_PIXELS) { onSkip?.("pixel_limit"); return null; }
  if (detectedType === "image/jpeg" && !hasSafeJpegOrientation(bytes)) { onSkip?.("jpeg_orientation"); return null; }

  let input: PhotonImageLike | undefined;
  let output: PhotonImageLike | undefined;
  try {
    input = photon.PhotonImage.new_from_byteslice(bytes);
    const scale = Math.min(1, width / input.get_width(), width / input.get_height());
    const outputWidth = Math.max(1, Math.round(input.get_width() * scale));
    const outputHeight = Math.max(1, Math.round(input.get_height() * scale));
    output = photon.resize(input, outputWidth, outputHeight, photon.SamplingFilter.Lanczos3);
    // Keep transparency for logos and cutouts. For opaque images, compare
    // WebP with a quality-controlled JPEG because Photon WebP has no quality
    // parameter and can be larger than a well-compressed source JPEG/PNG.
    const opaque = !hasTransparency(bytes, detectedType);
    let result: Uint8Array;
    let resultType: "image/jpeg" | "image/png" | "image/webp";
    try {
      result = output.get_bytes_webp();
      resultType = "image/webp";
    } catch {
      // Some Worker WASM runtimes lack Photon’s WebP encoder. Its PNG encoder
      // keeps transparency intact and still benefits from the reduced pixels.
      result = output.get_bytes();
      resultType = "image/png";
    }
    if (opaque) {
      try {
        const jpeg = output.get_bytes_jpeg(78);
        if (jpeg.byteLength < result.byteLength) {
          result = jpeg;
          resultType = "image/jpeg";
        }
      } catch {
        // Keep the successful WebP/PNG result if JPEG encoding is unavailable.
      }
    }
    // Avoid making a small or already-optimised source larger just to convert it.
    if (result.byteLength >= bytes.byteLength) { onSkip?.("no_byte_savings"); return null; }
    return { bytes: result, contentType: resultType };
  } catch (error) {
    const detail = error instanceof Error ? `${error.name}:${error.message}`.slice(0, 160) : "unknown_error";
    onSkip?.(`photon_encode_failed:${detail}`);
    return null;
  } finally {
    input?.free();
    output?.free();
  }
}
