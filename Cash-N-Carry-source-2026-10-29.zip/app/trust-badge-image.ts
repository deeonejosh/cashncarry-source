export type TrustBadgeKind =
  | "secure-checkout"
  | "buyer-protection"
  | "fast-delivery"
  | "order-tracking"
  | "easy-returns"
  | "official-store"
  | "top-seller";

const labels: Record<TrustBadgeKind, string> = {
  "secure-checkout": "Secure Checkout",
  "buyer-protection": "Buyer Protection",
  "fast-delivery": "Fast Delivery",
  "order-tracking": "Order Tracking",
  "easy-returns": "Easy Returns",
  "official-store": "Official Store",
  "top-seller": "Top Seller",
};

/** Static optimized badge props. Callers decide eligibility on the server. */
export function trustBadgeImage(kind: TrustBadgeKind) {
  return {
    src: `/trust-badges/${kind}.webp`,
    alt: labels[kind],
    width: 288,
    height: 88,
    decoding: "async" as const,
    loading: "lazy" as const,
  };
}
