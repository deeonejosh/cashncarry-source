export const STOREFRONT_PRODUCTS_PER_PAGE = 6;

export function paginateStorefrontProducts<T>(items: T[], requestedPage?: string) {
  const parsed = /^\d+$/.test(String(requestedPage || "1"))
    ? Number(requestedPage || "1")
    : 1;
  const pageCount = Math.max(1, Math.ceil(items.length / STOREFRONT_PRODUCTS_PER_PAGE));
  const page = Number.isSafeInteger(parsed)
    ? Math.min(pageCount, Math.max(1, parsed))
    : 1;
  const start = (page - 1) * STOREFRONT_PRODUCTS_PER_PAGE;

  return {
    items: items.slice(start, start + STOREFRONT_PRODUCTS_PER_PAGE),
    page,
    pageCount,
    pageSize: STOREFRONT_PRODUCTS_PER_PAGE,
    start,
  };
}
