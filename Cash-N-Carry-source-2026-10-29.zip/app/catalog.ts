import { eligibleSellerSQL } from "./seller-activation";
import { ensureVideoStorefrontSchema } from "./video-storefront-schema";
import { env } from "cloudflare:workers";
export async function catalog(params: URLSearchParams, user: string | null) {
  await ensureVideoStorefrontSchema();
  const cacheableHomeCatalogue = user === null && params.size === 0;
  const cacheKey = cacheableHomeCatalogue
    ? new Request("https://www.cashncarryng.com/__cache/home-catalogue-v3")
    : null;
  if (cacheKey) {
    try {
      const cached = await caches.default.match(cacheKey);
      if (cached) return await cached.json();
    } catch {
      // Cache is an optional acceleration; the database remains authoritative.
    }
  }
  const text = (key: string, max = 100) =>
    (params.get(key) || "").trim().slice(0, max);
  const clauses = [
    "p.active=1",
    eligibleSellerSQL(),
    "s.suspended=0",
    "NOT EXISTS (SELECT 1 FROM profiles x WHERE x.id=s.owner AND x.suspended=1)",
  ];
  const args: any[] = [];
  const search = text("q", 200),
    category = text("category"),
    location = text("location"),
    minPrice = text("minPrice", 20),
    maxPrice = text("maxPrice", 20);
  if (search) {
    clauses.push(
      "instr(lower(p.name||' '||s.name||' '||p.description),lower(?))>0",
    );
    args.push(search);
  }
  if (category && category !== "All") {
    clauses.push("p.category=?");
    args.push(category);
  }
  if (location) {
    clauses.push(
      params.get("mode") === "delivers"
        ? "EXISTS (SELECT 1 FROM json_each(s.coverage) WHERE instr(lower(value),lower(?))>0)"
        : "instr(lower(s.location||' '||s.state||' '||s.area),lower(?))>0",
    );
    args.push(location);
  }
  for (const [key, value, operator] of [["minPrice", minPrice, ">="], ["maxPrice", maxPrice, "<="]] as const) {
    if (!value) continue;
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount < 0 || amount > 1000000000) throw Error(`Invalid ${key}`);
    clauses.push(`p.price ${operator} ?`);
    args.push(amount);
  }
  if (minPrice && maxPrice && Number(minPrice) > Number(maxPrice)) throw Error("Invalid price range");
  if (params.get("inStock") === "1") {
    clauses.push("(p.stock>0 OR EXISTS (SELECT 1 FROM json_each(CASE WHEN json_valid(p.variants) THEN p.variants ELSE '[]' END) AS variant WHERE CAST(json_extract(variant.value,'$.stock') AS INTEGER)>0))");
  }
  if (text("store")) {
    clauses.push("p.store=?");
    args.push(text("store"));
  }
  if (params.get("following") === "1") {
    clauses.push(
      "EXISTS (SELECT 1 FROM follows f WHERE f.store=p.store AND f.user=?)",
    );
    args.push(user || "");
  }
  if (params.has("lat") || params.has("lng")) {
    const lat = Number(params.get("lat")),
      lng = Number(params.get("lng")),
      radius = Number(params.get("radius") || 25);
    if (
      !params.has("lat") ||
      !params.has("lng") ||
      !Number.isFinite(lat) ||
      !Number.isFinite(lng) ||
      Math.abs(lat) > 90 ||
      Math.abs(lng) > 180 ||
      !Number.isFinite(radius) ||
      radius < 1 ||
      radius > 500
    )
      throw Error("Invalid distance filter");
    clauses.push(
      "s.latitude IS NOT NULL AND s.longitude IS NOT NULL AND sin(radians(s.latitude))*sin(radians(?))+cos(radians(s.latitude))*cos(radians(?))*cos(radians(s.longitude-?))>=cos(?/6371.0)",
    );
    args.push(lat, lat, lng, radius);
  }
  const from =
    " FROM products p JOIN stores s ON s.id=p.store WHERE " +
    clauses.join(" AND ");
  const requested = Number(params.get("page") || 1);
  if (!Number.isSafeInteger(requested) || requested < 1 || requested > 100000)
    throw Error("Invalid page");
  const order: Record<string, string> = {
    featured: "p.featured DESC,p.created DESC",
    low: "p.price ASC",
    high: "p.price DESC",
    name: "p.name COLLATE NOCASE ASC",
    newest: "p.created DESC",
    rating: "(SELECT COALESCE(AVG(r.rating),0) FROM reviews r JOIN orders o ON o.id=r.order_id AND o.status='delivered' WHERE r.product=p.id) DESC,p.created DESC",
  };
  const totalQuery = env
    .DB!.prepare("SELECT COUNT(*) AS total" + from)
    .bind(...args)
    .first();
  let total: any = null;
  let page = requested;
  // Keep out-of-range page requests from issuing a large OFFSET query. The
  // common first-page request can still run all three reads concurrently.
  if (requested > 1) {
    total = await totalQuery;
    page = Math.min(requested, Math.max(1, Math.ceil(Number(total?.total || 0) / 12)));
  }
  const productsQuery = env
    .DB!.prepare(
        "SELECT p.*,(SELECT ROUND(AVG(r.rating),1) FROM reviews r JOIN orders o ON o.id=r.order_id AND o.status='delivered' WHERE r.product=p.id) AS rating_average,(SELECT COUNT(*) FROM reviews r JOIN orders o ON o.id=r.order_id AND o.status='delivered' WHERE r.product=p.id) AS review_count,s.name AS seller,(SELECT CASE WHEN f.published=1 THEN f.logo END FROM storefronts f WHERE f.store=s.id) AS seller_logo,s.location,s.state,s.area,s.coverage,s.verified,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy,s.latitude,s.longitude" +
          from +
          " ORDER BY " +
          (order[text("sort")] || order.newest) +
          ",p.id ASC LIMIT 12 OFFSET ?",
      )
      .bind(...args, (page - 1) * 12)
      .all();
  const featuredQuery = env
      .DB!.prepare(
        "SELECT p.*,(SELECT ROUND(AVG(r.rating),1) FROM reviews r JOIN orders o ON o.id=r.order_id AND o.status='delivered' WHERE r.product=p.id) AS rating_average,(SELECT COUNT(*) FROM reviews r JOIN orders o ON o.id=r.order_id AND o.status='delivered' WHERE r.product=p.id) AS review_count,s.name AS seller,(SELECT CASE WHEN f.published=1 THEN f.logo END FROM storefronts f WHERE f.store=s.id) AS seller_logo,s.location,s.state,s.area,s.coverage,s.verified,s.shipping_fee AS delivery_fee,s.delivery_days,s.return_policy,s.latitude,s.longitude" +
          from +
          " AND p.featured=1 ORDER BY p.created DESC,p.id ASC LIMIT 6",
      )
      .bind(...args)
      .all();
  // These reads are independent. Starting them together avoids serial D1
  // round trips on the initial shop render.
  const [count, productRows, featuredRows] = await Promise.all([
    total || totalQuery,
    productsQuery,
    featuredQuery,
  ]);
  const pages = Math.max(1, Math.ceil(Number(count?.total || 0) / 12));
  const products = productRows.results;
  const featured = featuredRows.results;
  const result = {
    featured,
    products,
    total: count?.total || 0,
    page,
    pages,
  };
  if (cacheKey) {
    try {
      await caches.default.put(
        cacheKey,
        Response.json(result, {
          headers: { "Cache-Control": "public, max-age=15" },
        }),
      );
    } catch {
      // Cache is an optional acceleration; the database remains authoritative.
    }
  }
  return result;
}
