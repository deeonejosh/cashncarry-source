"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { handoffCamera } from "./camera-handoff";
import { ArrowLeft, ArrowRight, Camera, Check, CircleAlert, FileUp, FlipHorizontal, ImagePlus, LoaderCircle, Mic, MicOff, Pause, Play, Radio, RotateCcw, ShieldCheck, Video, X, Zap, ZapOff } from "lucide-react";

type Product = { id: string; name: string; price: number; stock: number; active: boolean; image?: string; variants?: string | Array<{name:string;price?:number;stock?:number}> };
type CommercePayload = { user?: unknown; myProducts?: Product[]; myStore?: {name?:string} | null; sellerAccess?: { canSell?: boolean; verification?: string } | null; services?: {stream?:boolean} };
type Props = { onClose: () => void; initialData?: CommercePayload };
type Stage = "choose" | "camera" | "publish";

// Keep the camera-first entry enabled in every environment. The previous
// production default exposed the obsolete choice screen from the + button.
const CREATION_STUDIO_V2 = true;
const MAX_VIDEO_BYTES = 40 * 1024 * 1024;
const MAX_VIDEO_SECONDS = 180;

export default function VideoCreation({ onClose, initialData }: Props) {
  const router = useRouter();
  const videoRef = useRef<HTMLVideoElement>(null);
  const recordedVideoRef = useRef<HTMLVideoElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordingLockRef = useRef(false);
  const chunksRef = useRef<Blob[]>([]);
  const busyRef = useRef(false);
  const liveLaunchLockRef = useRef(false);
  const requestKeyRef = useRef("");
  const uploadedMediaRef = useRef("");
  const uploadedCoverRef = useRef("");
  const coverPreviewUrlRef = useRef("");
  const mountedRef = useRef(false);
  const elapsedRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);
  useEffect(() => { onCloseRef.current = onClose; }, [onClose]);
  const [stage, setStage] = useState<Stage>(CREATION_STUDIO_V2 ? "camera" : "choose");
  const [creationMode, setCreationMode] = useState<"video" | "live">("video");
  const [streamTitle, setStreamTitle] = useState("");
  const [featuredProduct, setFeaturedProduct] = useState("");
  const [cameraError, setCameraError] = useState("");
  const [cameraLoading, setCameraLoading] = useState(true);
  const [cameraReady, setCameraReady] = useState(false);
  const [recording, setRecording] = useState(false);
  const [preparingRecording, setPreparingRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [limitSeconds, setLimitSeconds] = useState(60);
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [microphoneEnabled, setMicrophoneEnabled] = useState(false);
  const [flashSupported, setFlashSupported] = useState(false);
  const [flashEnabled, setFlashEnabled] = useState(false);
  const [recordingPaused, setRecordingPaused] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [coverPreviewUrl, setCoverPreviewUrl] = useState("");
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [videoSource, setVideoSource] = useState<"camera" | "upload">("upload");
  const [coverBusy, setCoverBusy] = useState(false);
  const previewUrlRef = useRef("");
  const [products, setProducts] = useState<Product[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [caption, setCaption] = useState("");
  const [description, setDescription] = useState("");
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [preparingLive, setPreparingLive] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [storeAccess, setStoreAccess] = useState<{ hasStore: boolean; canSell: boolean; activation: string; providerConfigured: boolean } | null>(null);

  const releaseCamera = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    const current = streamRef.current;
    current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    if (mountedRef.current) setCameraReady(false);
  }, []);

  const startCamera = useCallback(async (direction: "user" | "environment" = "user") => {
    releaseCamera();
    setCameraLoading(true);
    setCameraError("");
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera access is not supported in this browser. You can upload a video instead.");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: direction }, width: { ideal: 1080 }, height: { ideal: 1920 } },
      });
      if (!mountedRef.current) { stream.getTracks().forEach((track) => track.stop()); return; }
      streamRef.current = stream;
      setCameraReady(true);
      setFacing(direction);
      setMicrophoneEnabled(stream.getAudioTracks().some((track) => track.enabled && track.readyState === "live"));
      setFlashEnabled(false);
      setFlashSupported(Boolean((stream.getVideoTracks()[0]?.getCapabilities?.() as MediaTrackCapabilities & {torch?:boolean})?.torch));
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => undefined);
      }
    } catch (e) {
      const name = e instanceof DOMException ? e.name : "";
      const message = name === "NotAllowedError" || name === "SecurityError"
        ? "Camera permission was denied. Allow access in your browser settings and retry, or upload a video."
        : name === "NotFoundError"
        ? "No camera was found. You can upload a video instead."
          : e instanceof Error ? e.message : "Unable to open the camera. Retry or upload a video.";
      if (mountedRef.current) setCameraError(message);
    } finally {
      if (mountedRef.current) setCameraLoading(false);
    }
  }, [releaseCamera]);

  const toggleMicrophone = async () => {
    const current = streamRef.current;
    if (!current) return;
    const liveAudio = current.getAudioTracks().find((track) => track.readyState === "live");
    if (liveAudio) {
      liveAudio.enabled = !liveAudio.enabled;
      setMicrophoneEnabled(liveAudio.enabled);
      return;
    }
    try {
      const audio = await navigator.mediaDevices.getUserMedia({audio:true,video:false});
      const track = audio.getAudioTracks()[0];
      if (!track || streamRef.current !== current) { audio.getTracks().forEach((item)=>item.stop()); return; }
      current.addTrack(track);
      setMicrophoneEnabled(true);
      setCameraError("");
    } catch (e) {
      setCameraError(e instanceof DOMException && (e.name === "NotAllowedError" || e.name === "SecurityError")
        ? "Microphone permission was denied. Allow it in your browser settings and retry."
        : "Microphone is unavailable. You can still record without sound or upload a video.");
    }
  };

  const toggleFlash = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track || !flashSupported) return;
    try {
      await track.applyConstraints({advanced:[{torch:!flashEnabled} as MediaTrackConstraintSet]});
      setFlashEnabled((value)=>!value);
    } catch {
      setFlashSupported(false);
      setCameraError("Flash is unavailable on this camera.");
    }
  };

  useEffect(() => {
    let active = true;
    mountedRef.current = true;
    void (async () => {
      try {
        const response = initialData ? null : await fetch("/api/commerce", { cache: "no-store" });
        const data = initialData || await response!.json() as CommercePayload;
        if (response && !response.ok) throw new Error("Account services are temporarily unavailable. Close this screen and retry.");
        if (!data.user) {
          router.push("/sign-in?returnTo=" + encodeURIComponent(window.location.pathname + window.location.search));
          return;
        }
        if (!active) return;
        const owned = Array.isArray(data.myProducts) ? data.myProducts.filter((p) => p.active) : [];
        setProducts(owned);
        const access={ hasStore: Boolean(data.myStore), canSell: Boolean(data.sellerAccess?.canSell), activation: data.sellerAccess?.verification || "not_started", providerConfigured: Boolean(data.services?.stream) };
        setStoreAccess(access);
        if (data.myStore?.name) setStreamTitle(`${data.myStore.name} · Live shopping`);
        setCameraLoading(false);
        if (CREATION_STUDIO_V2) void startCamera();
      } catch {
        if (active) { setCameraLoading(false); setCameraError("We could not confirm your account. Refresh and try again."); }
      }
    })();
    return () => {
      active = false;
      mountedRef.current = false;
      if (recorderRef.current?.state === "recording") {
        recorderRef.current.onstop = null;
        recorderRef.current.onerror = null;
        recorderRef.current.stop();
      }
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
      if (coverPreviewUrlRef.current) URL.revokeObjectURL(coverPreviewUrlRef.current);
      releaseCamera();
    };
  }, [initialData, releaseCamera, router, startCamera]);

  useEffect(() => {
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const dialog = dialogRef.current;
    const getFocusable = () => Array.from(dialog?.querySelectorAll<HTMLElement>(
      'button:not([disabled]),a[href],input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])',
    ) || []).filter((element) => element.getClientRects().length > 0);
    getFocusable()[0]?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !busyRef.current) { onCloseRef.current(); return; }
      if (event.key !== "Tab") return;
      const focusable = getFocusable();
      if (!focusable.length) { event.preventDefault(); dialog?.focus(); return; }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || !dialog?.contains(document.activeElement))) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || !dialog?.contains(document.activeElement))) {
        event.preventDefault(); first.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    document.body.classList.add("creation-open");
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.classList.remove("creation-open");
      previouslyFocused?.focus();
    };
  }, []);

  const setSelectedVideo = (selectedFile: File | null) => {
    setError(""); setNotice("");
    if (!selectedFile) return;
    if (!selectedFile.type.startsWith("video/")) { setError("Choose a video file."); return; }
    if (selectedFile.size > MAX_VIDEO_BYTES) { setError("Video uploads are limited to 40 MB."); return; }
    if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    previewUrlRef.current = URL.createObjectURL(selectedFile);
    requestKeyRef.current = crypto.randomUUID();
    uploadedMediaRef.current = "";
    uploadedCoverRef.current = "";
    if (coverPreviewUrlRef.current) URL.revokeObjectURL(coverPreviewUrlRef.current);
    coverPreviewUrlRef.current = "";
    setCoverPreviewUrl(""); setCoverFile(null);
    setPreviewUrl(previewUrlRef.current);
    setFile(selectedFile); setStage("publish"); setElapsed(0); releaseCamera();
  };

  const clearSelectedVideo = () => {
    if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    previewUrlRef.current = "";
    setPreviewUrl("");
    if (coverPreviewUrlRef.current) URL.revokeObjectURL(coverPreviewUrlRef.current);
    coverPreviewUrlRef.current = "";
    setCoverPreviewUrl(""); setCoverFile(null); uploadedCoverRef.current = "";
    setFile(null);
  };

  const captureCover = async () => {
    const video = recordedVideoRef.current;
    if (!video || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || !video.videoWidth || !video.videoHeight) {
      setError("Wait for the video preview to load, then choose a frame for the cover.");
      return;
    }
    setCoverBusy(true); setError("");
    try {
      const scale = Math.min(1, 960 / video.videoWidth);
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
      canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Cover editing is not supported in this browser.");
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((result) => result ? resolve(result) : reject(new Error("Could not create a cover from this frame.")), "image/webp", 0.84));
      const nextFile = new File([blob], `cash-n-carry-cover-${Date.now()}.webp`, { type: "image/webp" });
      if (coverPreviewUrlRef.current) URL.revokeObjectURL(coverPreviewUrlRef.current);
      coverPreviewUrlRef.current = URL.createObjectURL(nextFile);
      uploadedCoverRef.current = "";
      setCoverPreviewUrl(coverPreviewUrlRef.current); setCoverFile(nextFile);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not create a video cover.");
    } finally { setCoverBusy(false); }
  };

  const startRecording = async () => {
    if (recordingLockRef.current) return;
    recordingLockRef.current = true;
    setPreparingRecording(true);
    const stream = streamRef.current;
    if (!stream || typeof MediaRecorder === "undefined") {
      setCameraError("Video recording is not supported here. Use Upload video instead.");
      recordingLockRef.current = false;
      setPreparingRecording(false);
      return;
    }
    const mimeType = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm", "video/mp4"].find((type) => MediaRecorder.isTypeSupported(type));
    if (!mimeType) {
      setCameraError("This browser cannot record a supported video format. Use Upload video instead.");
      recordingLockRef.current = false;
      setPreparingRecording(false);
      return;
    }
    try {
      if (!stream.getAudioTracks().some((track) => track.readyState === "live")) {
        const audio = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        const tracks = audio.getAudioTracks();
        if (streamRef.current !== stream || !mountedRef.current) {
          tracks.forEach((track) => track.stop());
          return;
        }
        if (!tracks.length) throw new Error("No microphone was found.");
        tracks.forEach((track) => stream.addTrack(track));
      }
      chunksRef.current = [];
      const recorder = new MediaRecorder(stream, { mimeType });
      recorderRef.current = recorder;
      recorder.ondataavailable = (event) => { if (event.data.size) chunksRef.current.push(event.data); };
      recorder.onerror = () => { setRecording(false); setCameraError("Recording stopped unexpectedly. Please retry or upload a saved video."); };
      recorder.onstop = () => {
        setRecordingPaused(false);
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || mimeType });
        if (!blob.size) { setCameraError("No video was captured. Please try recording again."); return; }
        const extension = blob.type.includes("mp4") ? "mp4" : "webm";
        setVideoSource("camera");
        setSelectedVideo(new File([blob], `cash-n-carry-${Date.now()}.${extension}`, { type: blob.type }));
      };
      recorder.start(500);
      elapsedRef.current = 0;
      setElapsed(0); setRecording(true); setCameraError("");
      startElapsedTimer();
    } catch (e) {
      const name = e instanceof DOMException ? e.name : "";
      setCameraError(name === "NotAllowedError" || name === "SecurityError"
        ? "Microphone permission is needed to record audio. Allow access and retry, or upload a video instead."
        : e instanceof Error ? e.message : "Could not start recording. Check microphone access and retry.");
    } finally {
      recordingLockRef.current = false;
      setPreparingRecording(false);
    }
  };

  const stopRecording = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
    setRecording(false);
    setRecordingPaused(false);
  };

  const startElapsedTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      const next = elapsedRef.current + 1;
      elapsedRef.current = next;
      setElapsed(Math.min(next, limitSeconds));
      if (next >= limitSeconds) {
        const recorder = recorderRef.current;
        if (recorder?.state === "recording" || recorder?.state === "paused") recorder.stop();
        setRecording(false);
        setRecordingPaused(false);
        if (timerRef.current) clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }, 1000);
  };

  const toggleRecordingPause = () => {
    const recorder = recorderRef.current;
    if (!recorder || !recording) return;
    if (recorder.state === "recording" && typeof recorder.pause === "function") {
      recorder.pause();
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = null;
      setRecordingPaused(true);
    } else if (recorder.state === "paused" && typeof recorder.resume === "function") {
      recorder.resume();
      setRecordingPaused(false);
      startElapsedTimer();
    }
  };

  const upload = (f: File, idempotencyKey?: string) => new Promise<string>((resolve, reject) => {
    const body = new FormData(); body.set("file", f);
    const xhr = new XMLHttpRequest(); xhr.open("POST", "/api/media");
    if (idempotencyKey) xhr.setRequestHeader("Idempotency-Key", idempotencyKey);
    xhr.upload.onprogress = (event) => { if (event.lengthComputable) setProgress(Math.min(90, Math.round(event.loaded / event.total * 90))); };
    xhr.onload = () => { try { const data = JSON.parse(xhr.responseText); if (xhr.status >= 200 && xhr.status < 300) resolve(data.url); else reject(new Error(data.error || "Upload failed.")); } catch { reject(new Error("Upload failed. Please retry.")); } };
    xhr.onerror = () => reject(new Error("Upload interrupted. Your video is still selected; retry when your connection is stable."));
    xhr.send(body);
  });

  const saveVideo = async (publish: boolean) => {
    if (busyRef.current) return;
    if (!storeAccess?.hasStore) { setError("Create your seller account in Seller Centre before uploading product videos."); return; }
    if (!file) { setError("Choose or record a video first."); return; }
    busyRef.current = true; setBusy(true); setError(""); setNotice(""); setProgress(0);
    try {
      const metadata = document.createElement("video");
      metadata.preload = "metadata";
      const duration = await new Promise<number>((resolve) => {
        metadata.onloadedmetadata = () => { const value = metadata.duration; URL.revokeObjectURL(metadata.src); resolve(value); };
        metadata.onerror = () => resolve(0);
        metadata.src = URL.createObjectURL(file);
      });
      if (duration && duration > MAX_VIDEO_SECONDS) throw new Error("Videos must be 3 minutes or shorter.");
      const thumbnail = coverFile ? uploadedCoverRef.current || await upload(coverFile, crypto.randomUUID()) : "";
      if (thumbnail) uploadedCoverRef.current = thumbnail;
      const media = uploadedMediaRef.current || await upload(file);
      uploadedMediaRef.current = media;
      setProgress(94);
      const fullCaption = [caption.trim(), description.trim()].filter(Boolean).join("\n").slice(0, 500);
      if (!requestKeyRef.current) requestKeyRef.current = crypto.randomUUID();
      const response = await fetch("/api/videos", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "create", requestKey: requestKeyRef.current, media, thumbnail, caption: fullCaption, hashtags: [], products: selected, publish }) });
      const result = await response.json() as { error?: string; reused?: boolean };
      if (!response.ok) throw new Error(result.error || "Could not save this video.");
      setProgress(100);
      setNotice(result.reused ? "This submission was already saved. You can find it in your video library." : publish ? "Video submitted for moderation. It will appear in discovery after approval." : "Video draft saved to your video library.");
      requestKeyRef.current = "";
      uploadedMediaRef.current = "";
      clearSelectedVideo(); setCaption(""); setDescription(""); setSelected([]);
    } catch (e) { setError(e instanceof Error ? e.message : "Could not save this video. Retry when your connection is stable."); }
    finally { busyRef.current = false; setBusy(false); window.setTimeout(() => setProgress(0), 1200); }
  };

  const goLive = async () => {
    if (!storeAccess?.providerConfigured) { setCameraError("Live broadcasting is not available right now. Your camera preview is still private; try again later."); return; }
    if (!cameraReady) { setCameraError("Wait for your camera preview to be ready before continuing to LIVE."); return; }
    if (!storeAccess?.hasStore || !storeAccess.canSell) return;
    if (liveLaunchLockRef.current) return;
    liveLaunchLockRef.current = true;
    setPreparingLive(true);
    const current = streamRef.current;
    if (!current) { setCameraError("Your camera preview needs to reconnect before you can go live. Retry camera access."); liveLaunchLockRef.current=false; setPreparingLive(false); return; }
    if (!current.getAudioTracks().some((track) => track.readyState === "live" && track.enabled)) {
      try {
        const audio = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        const track = audio.getAudioTracks()[0];
        if (!track || !mountedRef.current || streamRef.current !== current) {
          audio.getTracks().forEach((item) => item.stop());
          liveLaunchLockRef.current=false; setPreparingLive(false);
          return;
        }
        current.addTrack(track);
        setMicrophoneEnabled(true);
        setCameraError("");
      } catch (e) {
        const denied = e instanceof DOMException && (e.name === "NotAllowedError" || e.name === "SecurityError");
        setCameraError(denied
          ? "Allow microphone access to start a livestream. Your camera view is still open."
          : "Microphone is unavailable. Reconnect it with the Mic control before going live.");
        liveLaunchLockRef.current=false; setPreparingLive(false);
        return;
      }
    }
    const params = new URLSearchParams({tab:"Studio",studio:"1",autoStart:"1",studioTitle:streamTitle.trim()});
    if (featuredProduct) params.set("studioProduct",featuredProduct);
    // Keep the existing camera stream alive while the soft route changes to
    // Live Studio. The studio will consume this same MediaStream.
    handoffCamera(current, facing);
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraReady(false);
    router.push(`/workspace?${params.toString()}`);
  };

  const openCamera = () => {
    if (!storeAccess?.hasStore) { router.push("/start-selling"); return; }
    setStage("camera");
    void startCamera();
  };
  const openUpload = () => {
    if (!storeAccess?.hasStore) { router.push("/start-selling"); return; }
    setError(""); setNotice("");
    inputRef.current?.click();
  };

  return <div ref={dialogRef} className={`video-creation-overlay ${stage === "publish" ? "video-creation-publishing" : stage === "choose" ? "video-creation-choosing" : ""}`} role="dialog" aria-modal="true" aria-label={stage === "choose" ? "Create for your shop" : stage === "camera" ? "Camera creation" : "Publish video"} tabIndex={-1}>
    {stage === "choose" ? <section className="creation-choice-screen">
      <header className="creation-choice-header"><Link className="creation-choice-brand" href="/" aria-label="Cash N Carry home"><span><Video size={19} aria-hidden="true"/></span>Cash N Carry</Link><button type="button" aria-label="Close creation" disabled={busy} onClick={onClose}><X/></button></header>
      <main className="creation-choice-content">
        <p className="creation-choice-eyebrow">SELLER STUDIO</p>
        <h1>Create for your shop.</h1>
        <p className="creation-choice-intro">Bring your products to life with a live show or a short video.</p>
        {error && <p className="creation-choice-error" role="alert">{error}</p>}
      {!storeAccess && !cameraError ? <p className="creation-choice-status" role="status"><LoaderCircle className="spin" size={16}/> Checking your seller access…</p> : !storeAccess ? <p className="creation-choice-access" role="alert">{cameraError} <button type="button" onClick={() => window.location.reload()}>Retry</button></p> : !storeAccess.hasStore ? <div className="creation-choice-gate"><ShieldCheck size={19} aria-hidden="true"/><p>Set up your seller account to create shoppable videos or start a live.</p><a href="/start-selling">Set up your shop <ArrowRight size={16} aria-hidden="true"/></a></div> : !storeAccess.canSell && <p className="creation-choice-access" role="status">Your videos can be saved as drafts. Complete seller verification to publish or go live. <a href={storeAccess.activation === "verified" ? "/seller/finance?tab=Subscription" : "/seller/finance?tab=Activation"}>Finish setup</a></p>}
        <button type="button" className="creation-live-choice" disabled={!storeAccess?.hasStore || busy} onClick={goLive}>
          <span className="creation-live-orbit" aria-hidden="true"><Radio size={23}/></span>
          <span className="creation-choice-copy"><small className="creation-live-kicker">LIVE SHOPPING</small><strong>Start a live</strong><small>Preview your camera before you go on air</small></span>
          <span className="creation-live-arrow"><ArrowRight size={19} aria-hidden="true"/></span>
        </button>
        <div className="creation-choice-secondary" aria-label="Video options">
          <button type="button" disabled={!storeAccess?.hasStore || busy} onClick={openCamera}><span className="creation-choice-card-icon"><Camera size={20} aria-hidden="true"/></span><strong>Record a video</strong><small>Use your camera</small><ArrowRight className="creation-choice-arrow" size={16} aria-hidden="true"/></button>
          <button type="button" disabled={!storeAccess?.hasStore || busy} onClick={openUpload}><span className="creation-choice-card-icon"><FileUp size={20} aria-hidden="true"/></span><strong>Upload a video</strong><small>Choose from your device</small><ArrowRight className="creation-choice-arrow" size={16} aria-hidden="true"/></button>
        </div>
        <p className="creation-choice-privacy"><ShieldCheck size={16} aria-hidden="true"/> Camera permission is requested only when you choose Record or Go live.</p>
      </main>
      <input ref={inputRef} type="file" accept="video/mp4,video/webm,video/quicktime" hidden onChange={(event) => { setVideoSource("upload"); setSelectedVideo(event.target.files?.[0] || null); event.currentTarget.value = ""; }} />
    </section> : stage === "camera" ? <section className={`creation-camera-screen${CREATION_STUDIO_V2?" creation-camera-screen-v2":""}`}>
      <video ref={videoRef} className="creation-camera-preview" autoPlay muted playsInline aria-label="Live camera preview" />
      <div className="creation-camera-scrim" />
      <header className="creation-camera-top"><button type="button" aria-label={CREATION_STUDIO_V2?"Close camera studio":"Back to creation choices"} disabled={busy || recording} onClick={() => {if(CREATION_STUDIO_V2){onClose();return;}releaseCamera();setStage("choose");}}>{CREATION_STUDIO_V2?<X/>:<ArrowLeft/>}</button><span>{CREATION_STUDIO_V2?(creationMode==="video"?"Create video":"Set up LIVE"):"Record video"}</span>{!CREATION_STUDIO_V2&&<button type="button" aria-label="Switch camera" disabled={recording || cameraLoading || busy || !cameraReady} onClick={() => void startCamera(facing === "user" ? "environment" : "user")}><FlipHorizontal/></button>}</header>
      {cameraLoading && <div className="creation-camera-state" role="status"><LoaderCircle className="spin"/>Opening camera…</div>}
      {!cameraLoading && !cameraReady && <div className="creation-camera-state creation-camera-error"><CircleAlert/><p>{cameraError || (!storeAccess?.hasStore ? "Set up a seller account to publish shoppable videos or go live." : "Camera is unavailable. Retry access or upload a saved video.")}</p><button type="button" className="creation-secondary" onClick={() => void startCamera(facing)}>Retry camera</button></div>}
      <div className="creation-camera-toolbar" aria-live="polite">{(recording || recordingPaused) && <><span className="creation-camera-time">{recordingPaused?"PAUSED · ":"REC · "}{Math.floor(elapsed / 60).toString().padStart(2,"0")}:{(elapsed % 60).toString().padStart(2,"0")}</span><span className="creation-camera-label">{recordingPaused?"Recording paused":"Recording"}</span></>}</div>
      {cameraError && cameraReady && <p className="creation-camera-inline-error" role="alert">{cameraError}</p>}
      {CREATION_STUDIO_V2 && <aside className="creation-camera-tools" aria-label="Camera controls">
        <button type="button" disabled={!cameraReady||cameraLoading||busy||recording} aria-label={`Switch to ${facing==="user"?"rear":"front"} camera`} onClick={()=>void startCamera(facing==="user"?"environment":"user")}><FlipHorizontal/><span>Flip</span></button>
        <button type="button" disabled={!cameraReady||cameraLoading||busy} aria-label={microphoneEnabled?"Mute microphone":"Enable microphone"} aria-pressed={microphoneEnabled} onClick={()=>void toggleMicrophone()}>{microphoneEnabled?<Mic/>:<MicOff/>}<span>Mic</span></button>
        {flashSupported&&<button type="button" disabled={!cameraReady||cameraLoading||busy} aria-label={flashEnabled?"Turn flash off":"Turn flash on"} aria-pressed={flashEnabled} onClick={()=>void toggleFlash()}>{flashEnabled?<Zap/>:<ZapOff/>}<span>Flash</span></button>}
      </aside>}
      {CREATION_STUDIO_V2 ? <>
        <div className="creation-mode-selector" role="tablist" aria-label="Creation mode">
          <button type="button" role="tab" aria-selected={creationMode==="video"} onClick={()=>{setCreationMode("video");setCameraError("");}}>VIDEO</button>
          <button type="button" role="tab" aria-selected={creationMode==="live"} onClick={()=>{setCreationMode("live");setCameraError("");}}>LIVE</button>
        </div>
        {creationMode==="video" ? <div className="creation-v2-bottom creation-v2-video-controls">
          <div className="creation-duration-select" role="group" aria-label="Maximum recording duration">{[15,60,180].map((seconds)=><button key={seconds} type="button" disabled={recording||preparingRecording} aria-pressed={limitSeconds===seconds} onClick={()=>setLimitSeconds(seconds)}>{seconds===180?"3m":`${seconds}s`}</button>)}</div>
          <div className="creation-v2-record-row">
            <button type="button" className="creation-v2-gallery" disabled={busy||recording||!storeAccess?.hasStore} onClick={openUpload}><ImagePlus size={20} aria-hidden="true"/><span>Gallery</span></button>
            <button type="button" className={`creation-record-button ${recording?"is-recording":""}`} aria-label={recording?"Stop recording":preparingRecording?"Preparing recording":"Start recording"} disabled={!cameraReady||cameraLoading||preparingRecording||!storeAccess?.hasStore} onClick={recording?stopRecording:startRecording}>{recording?<span/>:preparingRecording?<LoaderCircle className="spin"/>:null}</button>
            {recording?<button type="button" className="creation-v2-gallery" aria-label={recordingPaused?"Resume recording":"Pause recording"} onClick={toggleRecordingPause}>{recordingPaused?<Play size={20}/>:<Pause size={20}/>}<span>{recordingPaused?"Resume":"Pause"}</span></button>:<span className="creation-v2-record-hint">Tap to record</span>}
          </div>
          {!storeAccess?.hasStore&&<p className="creation-v2-gate" role="status">Set up your seller account to upload or publish shoppable videos. <a href="/start-selling">Set up shop</a></p>}
          <input ref={inputRef} type="file" accept="video/mp4,video/webm,video/quicktime" hidden onChange={(event)=>{setVideoSource("upload");setSelectedVideo(event.target.files?.[0]||null);event.currentTarget.value="";}} />
        </div> : <div className="creation-v2-bottom creation-v2-live-controls">
          <div className="creation-live-setup-brand"><span className="creation-live-setup-mark"><Radio size={15} aria-hidden="true"/> LIVE SHOPPING</span><span className="creation-live-public">Broadcast setup</span></div>
          <label><span>Live title <small>{streamTitle.length}/100</small></span><input value={streamTitle} maxLength={100} onChange={(event)=>setStreamTitle(event.target.value)} placeholder="Your shop · Live shopping" /></label>
          <label><span>Featured product <small>Optional</small></span><select value={featuredProduct} onChange={(event)=>setFeaturedProduct(event.target.value)}><option value="">Choose during your live</option>{products.filter((product)=>product.active&&product.stock>0).map((product)=><option key={product.id} value={product.id}>{product.name} · ₦{Number(product.price).toLocaleString("en-NG")}</option>)}</select></label>
          {featuredProduct && (() => { const product=products.find((item)=>item.id===featuredProduct); return product ? <div className="creation-featured-product-preview"><span className="creation-featured-product-image">{product.image?<Image src={product.image} alt="" width={52} height={52} unoptimized/>:<ImagePlus size={20} aria-hidden="true"/>}</span><span className="creation-featured-product-copy"><small>FEATURED IN YOUR LIVE</small><strong>{product.name}</strong><b>₦{Number(product.price).toLocaleString("en-NG")}</b></span><button type="button" aria-label="Remove featured product" onClick={()=>setFeaturedProduct("")}>×</button></div> : null; })()}
          <div className="creation-live-readiness" aria-label="Live readiness"><span className={cameraReady?"is-ready":"is-unavailable"}><Check size={14}/>{cameraReady?"Camera ready":"Camera needed"}</span><span className={microphoneEnabled?"is-ready":"is-unavailable"}>{microphoneEnabled?<Mic size={14}/>:<MicOff size={14} />}{microphoneEnabled?"Mic ready":"Mic permission needed"}</span><span className={storeAccess?.providerConfigured?"is-ready":"is-unavailable"}><Radio size={14}/>{storeAccess?.providerConfigured?"Provider ready":"Provider unavailable"}</span></div>
          {!storeAccess?.hasStore?<p className="creation-v2-gate" role="status">Create your seller account before broadcasting. <a href="/start-selling">Set up shop</a></p>:storeAccess&&!storeAccess.canSell?<p className="creation-v2-gate" role="status">Seller verification and active access are required before you can go live. <a href={storeAccess.activation==="verified"?"/seller/finance?tab=Subscription":"/seller/finance?tab=Activation"}>Complete setup</a></p>:null}
          <button type="button" className="creation-v2-go-live" disabled={!cameraReady||cameraLoading||!storeAccess?.canSell||!storeAccess?.providerConfigured||busy||preparingLive} onClick={goLive}>{preparingLive?<><LoaderCircle className="spin" size={19} aria-hidden="true"/>Checking microphone…</>:<><Radio size={19} aria-hidden="true"/>Go Live</>}</button>
        </div>}
      </> : <div className="creation-record-controls">
          <div className="creation-duration-select" role="group" aria-label="Recording duration">{[15,60,180].map((seconds) => <button key={seconds} type="button" disabled={recording || preparingRecording} aria-pressed={limitSeconds === seconds} onClick={() => setLimitSeconds(seconds)}>{seconds === 180 ? "3m" : `${seconds}s`}</button>)}</div>
          <button type="button" className={`creation-record-button ${recording ? "is-recording" : ""}`} aria-label={recording ? "Stop recording" : preparingRecording ? "Preparing recording" : "Start recording"} disabled={!cameraReady || cameraLoading || preparingRecording} onClick={recording ? stopRecording : startRecording}>{recording ? <span/> : preparingRecording ? <LoaderCircle className="spin"/> : null}</button>
          <input ref={inputRef} type="file" accept="video/mp4,video/webm,video/quicktime" hidden onChange={(event) => { setVideoSource("upload"); setSelectedVideo(event.target.files?.[0] || null); event.currentTarget.value = ""; }} />
          <footer className="creation-camera-actions" aria-label="Video actions"><button type="button" className="creation-camera-upload" disabled={busy || recording} onClick={openUpload}><ImagePlus size={19} aria-hidden="true"/><span>Upload video</span></button><button type="button" className="creation-camera-live" disabled={busy || recording} onClick={goLive}><Radio size={19} aria-hidden="true"/><span>Go Live</span></button></footer>
        </div>}
    </section> : <section className="creation-publish-screen">
      <header className="creation-publish-header"><button type="button" aria-label="Back to camera" disabled={busy} onClick={() => { if (videoSource === "upload" && !CREATION_STUDIO_V2) {setStage("choose");return;} setStage("camera"); if (storeAccess?.hasStore) void startCamera(facing); }}><ArrowLeft/></button><h2>{videoSource === "upload" ? "Upload video" : "Review your video"}</h2><button type="button" aria-label="Close publishing" disabled={busy} onClick={onClose}><X/></button></header>
      {previewUrl && <div className="creation-video-preview"><video ref={recordedVideoRef} src={previewUrl} controls playsInline preload="metadata"/><button type="button" className="creation-retake" disabled={busy} onClick={() => { clearSelectedVideo(); setStage("camera"); setNotice(""); if (storeAccess?.hasStore) void startCamera(facing); }}><RotateCcw size={15}/>Retake</button><button type="button" className="creation-edit-cover" disabled={busy || coverBusy} onClick={() => void captureCover()}>{coverBusy ? <LoaderCircle className="spin" size={15}/> : <ImagePlus size={15}/>} {coverBusy ? "Creating cover…" : "Edit cover"}</button>{coverPreviewUrl && <Image className="creation-cover-selected" src={coverPreviewUrl} alt="Selected video cover" width={52} height={68} unoptimized/>}</div>}
      {!storeAccess?.hasStore && <div className="creation-access-note" role="status">Create a seller account to publish shoppable videos. <a href="/start-selling">Set up your shop</a>.</div>}
      {storeAccess?.hasStore && !storeAccess.canSell && <div className="creation-access-note" role="status">You can save this video as a draft. Seller verification and an active subscription are required to submit it for review. <a href={storeAccess.activation === "verified" ? "/seller/finance?tab=Subscription" : "/seller/finance?tab=Activation"}>Review seller access</a>.</div>}
      <label className="creation-field"><span>Title <small>{caption.length}/150</small></span><input value={caption} maxLength={150} onChange={(e) => setCaption(e.target.value)} placeholder="Add a title"/></label>
      <label className="creation-field"><span>Description <small>{description.length}/500</small></span><textarea value={description} maxLength={500} onChange={(e) => setDescription(e.target.value)} placeholder="Tell shoppers about this video"/></label>
      <div className="creation-publishing-options"><div><strong>Audience</strong><span>Public after moderation</span></div><div className="creation-products"><strong>Add product <small>(optional)</small></strong>{products.length ? products.map((product) => <label key={product.id}><input type="checkbox" checked={selected.includes(product.id)} disabled={!selected.includes(product.id) && selected.length >= 5} onChange={(event) => setSelected(event.target.checked ? [...selected, product.id] : selected.filter((id) => id !== product.id))}/><span>{product.name}<small>₦{Number(product.price).toLocaleString("en-NG")} · {product.stock > 0 ? "In stock" : "Out of stock"}</small></span><Check size={17}/></label>) : <p>Published products from your store can be tagged here. Product tags are optional.</p>}</div></div>
      {progress > 0 && <progress className="creation-progress" value={progress} max={100} aria-label="Video upload progress"/>}
      {error && <p role="alert" className="creation-message creation-error">{error}</p>}{notice && <p role="status" className="creation-message">{notice}</p>}
      <footer className="creation-publish-actions"><button type="button" className="creation-secondary" disabled={busy} onClick={() => void saveVideo(false)}>{busy ? "Saving…" : "Save draft"}</button><button type="button" className="creation-publish-button" disabled={busy || !storeAccess?.hasStore || !storeAccess.canSell} onClick={() => void saveVideo(true)}>{busy ? <><LoaderCircle className="spin"/>Uploading {progress}%</> : "Publish for review"}</button></footer>
    </section>}
  </div>;
}
