/** Redirect browser document navigations to the public www hostname.
 * API calls and non-document requests keep their original host so integrations
 * and existing signed callbacks continue to work.
 */
export function canonicalHostRedirect(request: Request): Response | null {
  const url = new URL(request.url);
  if (
    url.protocol !== "https:" ||
    url.hostname.toLowerCase() !== "cashncarryng.com" ||
    url.pathname.startsWith("/api/") ||
    (request.method !== "GET" && request.method !== "HEAD") ||
    !request.headers.get("accept")?.toLowerCase().includes("text/html")
  ) {
    return null;
  }
  url.hostname = "www.cashncarryng.com";
  return new Response(null, {
    status: 308,
    headers: {
      Location: url.href,
      "Cache-Control": "public, max-age=300",
    },
  });
}
