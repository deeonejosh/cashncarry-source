"use client";
import { useState } from "react";
import { Eye, RefreshCw } from "lucide-react";
type MessageInfo={id:string;sender:string;body:string;created:string;store:string};
export default function ReportedMessage({reportId}:{reportId:string}){
 const [open,setOpen]=useState(false),[busy,setBusy]=useState(false),[message,setMessage]=useState<MessageInfo|null>(null),[error,setError]=useState("");
 async function load(){setBusy(true);setError("");try{const r=await fetch(`/api/admin/message-reports?id=${encodeURIComponent(reportId)}`,{cache:"no-store",signal:AbortSignal.timeout(12000)});const b:any=await r.json();if(!r.ok)throw Error(b.error||"Unable to load reported message");setMessage(b.message);}catch(e){setError(e instanceof Error?e.message:"Unable to load reported message");}finally{setBusy(false);}}
 async function toggle(){const next=!open;setOpen(next);if(next&&!message&&!busy)await load();}
 return <section className="admin-reported-message"><button type="button" onClick={()=>void toggle()} aria-expanded={open}>{open?"Hide reported message":"Review reported message"} <Eye size={15}/></button>{open&&(busy?<p role="status"><RefreshCw size={15}/> Loading reported message…</p>:error?<p role="alert">{error}<button type="button" onClick={()=>void load()}>Retry</button></p>:message?<blockquote><strong>{message.sender} · {message.store}</strong><p>{message.body||"[Attachment only]"}</p><time>{new Date(message.created).toLocaleString()}</time><small>Viewing this private message was recorded in the admin audit log.</small></blockquote>:null)}</section>;
}
