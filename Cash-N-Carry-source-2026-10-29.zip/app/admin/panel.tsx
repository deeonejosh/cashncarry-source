"use client";
import VerifiedSellerBadge from "../verified-seller-badge";
import FinancePanel from "./finance-panel";
import SellerFinanceAdmin from "./seller-finance-panel";
import ReportedMessage from "./reported-message";
import Link from "next/link";
import ImageAsset from "../image-asset";
import BrandLogo from "../brand-logo";
import { brand } from "../brand";
import { useState, useEffect, useCallback } from "react";
import {
  ShieldCheck,
  Settings,
  LayoutDashboard,
  Users,
  Store,
  ShoppingBag,
  Package,
  Radio,
  Megaphone,
  FileCheck,
  MessageSquare,
  ScrollText,
  Search,
  RefreshCw,
  X,
  ChevronLeft,
  ArrowUpRight,
  Menu,
  Video,
} from "lucide-react";
const money = (n: number) =>
  new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(n || 0);
const tabs = [
  ["Overview", LayoutDashboard], ["Seller Subscriptions & Payouts", Store], ["Payments", Package], ["Orders", Package], ["Support", MessageSquare],
  ["Verification", FileCheck], ["Stores", Store], ["Users", Users],
  ["Products", ShoppingBag], ["Videos", Video], ["Live", Radio], ["Ads", Megaphone],
  ["Reports", ShieldCheck], ["Audit log", ScrollText],
] as const;
const labels: Record<string, string> = { Overview: "Dashboard", "Seller Subscriptions & Payouts": "Subscriptions & seller payouts", Payments: "Payment monitoring", Orders: "Orders", Support: "Disputes & support", Verification: "Seller verification", Stores: "Seller & storefront management", Users: "Buyer management", Products: "Product management", Videos: "Video moderation", Live: "Livestream management", Ads: "Advertising drafts", Reports: "Reports & moderation", "Audit log": "Audit logs" };
const descriptions: Record<string, string> = {
  Overview: "Your daily marketplace workspace. Start with the items that need attention.",
  Orders: "Review orders, delivery progress and recorded payment status.",
  Support: "Review customer order issues, disputes and return requests.",
  Verification: "Review private evidence before approving a seller.",
  Stores: "Manage seller profiles, storefronts and seller availability.", Users: "Review buyer accounts and access restrictions.",
  Products: "Review listings and control their public visibility.", Videos: "Review seller video posts before they enter public discovery.", Live: "Monitor broadcasts and review their status.",
  Ads: "Review seller advertising drafts. Paid delivery and billing remain disabled.", Reports: "Review reported content and moderation cases.",
  "Audit log": "See who made an administrative decision, when and why.",
};
const groups = [
  { title: "Operations", items: ["Overview", "Orders", "Support"] },
  { title: "Finance", items: ["Seller Subscriptions & Payouts", "Payments"] },
  { title: "People", items: ["Verification", "Stores", "Users"] },
  { title: "Content management", items: ["Products", "Videos", "Live", "Ads", "Reports"] },
  { title: "Administration", items: ["Audit log"] },
];
const tabPermissions: Record<string,string> = {"Seller Subscriptions & Payouts":"payments",Payments:"payments",Overview:"overview",Orders:"orders",Support:"support",Verification:"verification",Stores:"sellers",Users:"customers",Products:"products",Videos:"products",Live:"streams",Ads:"products",Reports:"reports","Audit log":"audit"};
const rowState = (tab: string, row: any) => {
  if (tab === "Users") return row.suspended ? "suspended" : "active";
  if (tab === "Stores") return row.suspended ? "suspended" : row.verified ? "verified" : "unverified";
  if (tab === "Products") return row.active ? "published" : "hidden";
  if (tab === "Videos") return String(row.status || "pending");
  return String(row.status || "recorded");
};
export default function AdminPanel() {
  const [data, setData] = useState<any>(null),
    [tab, setTab] = useState("Overview"),
    [query, setQuery] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [change, setChange] = useState<any>(null),
    [toast, setToast] = useState("");
  const [dialogError,setDialogError]=useState("");
  const [status, setStatus] = useState("all");
  const [page, setPage] = useState(1);
  const [refreshing, setRefreshing] = useState(false);
  const [updated, setUpdated] = useState<Date | null>(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  useEffect(() => {
    const key = "dashboardRedesign";
    const selector = `link[data-${key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`)}]`;
    if (document.querySelector(selector)) return;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "/dashboard-redesign.css";
    link.dataset[key] = "true";
    link.addEventListener("load", () => { link.dataset.loaded = "true"; }, { once: true });
    link.addEventListener("error", () => { link.dataset.failed = "true"; }, { once: true });
    document.head.appendChild(link);
  }, []);
  const navigate = (next: string) => {
    setTab(next); setQuery(""); setStatus("all"); setPage(1);
    setMobileNavOpen(false);
    const url = new URL(window.location.href); url.searchParams.set("tab", next);
    window.history.replaceState(null, "", url);
  };
  useEffect(() => {
    const next = new URLSearchParams(window.location.search).get("tab");
    if (tabs.some(([t]) => t === next)) setTab(next!);
  }, []);
  useEffect(() => {
    if (!mobileNavOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMobileNavOpen(false);
    };
    document.addEventListener("keydown", closeOnEscape);
    return () => document.removeEventListener("keydown", closeOnEscape);
  }, [mobileNavOpen]);
  useEffect(() => { setPage(1); }, [query, status]);
  const load = useCallback(async () => {
    setRefreshing(true);
    try {
      const r = await fetch("/api/admin", {
        signal: AbortSignal.timeout(15000),
      });
      const b: any = await r.json();
      if (!r.ok) throw Error(b.error);
      setData(b);
      setUpdated(new Date());
      setError("");
    } catch (e: any) {
      setError(e.message);
    } finally { setRefreshing(false); }
  }, []);
  useEffect(() => {
    load();
  }, [load]);
  useEffect(() => {
    if (!change) return;
    const previous = document.activeElement as HTMLElement;
    const dialog = document.querySelector(
      '[aria-label="Confirm admin action"]',
    );
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !busy) setChange(null);
      if (e.key !== "Tab") return;
      const nodes = Array.from(
        dialog?.querySelectorAll<HTMLElement>(
          "button:not(:disabled),textarea,input,a[href]",
        ) || [],
      );
      if (!nodes.length) return;
      const first = nodes[0],
        last = nodes[nodes.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", handler);
    return () => {
      document.removeEventListener("keydown", handler);
      previous?.focus();
    };
  }, [change, busy]);
  const choose = (action: string, row: any, value: any, title: string) =>
    {setDialogError("");setChange({ action, id: row.id, value, title });}
  const submit = async (e: any) => {
    e.preventDefault();
    if (busy) return;
    const reason = String(new FormData(e.currentTarget).get("reason")||"").trim();
    const minimum=change?.action==="verification-revoke"?5:3;
    if(reason.length<minimum){setDialogError(`Enter a review reason of at least ${minimum} characters.`);return;}
    setDialogError("");setBusy(true);
    try {
      const r = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...change, reason }),
      });
      const b: any = await r.json();
      if (!r.ok) throw Error(b.error);
      setChange(null);
      setToast("Action applied and recorded in the audit log.");
      await load();
    } catch (e: any) {
      setDialogError(e.message||"Unable to save this review. Please retry.");
    } finally {
      setBusy(false);
    }
  };
  const matches = (row: any) =>
    JSON.stringify(row).toLowerCase().includes(query.trim().toLowerCase());
  const action = (text: string, fn: () => void, danger = false) => (
    <button
      className={danger ? "admin-action danger" : "admin-action"}
      disabled={busy}
      onClick={fn}
    >
      {text}
    </button>
  );
  const list = (rows: any[], render: (row: any) => any) => {
    const filtered = rows.filter((row) => matches(row) && (status === "all" || rowState(tab, row) === status));
    const pages = Math.max(1, Math.ceil(filtered.length / 20));
    const current = Math.min(page, pages);
    const visible = filtered.slice((current - 1) * 20, current * 20);
    return filtered.length ? (
      <>
      <p className="admin-result-count" role="status">{filtered.length} matching {filtered.length === 1 ? "record" : "records"} · showing {(current - 1) * 20 + 1}–{Math.min(current * 20, filtered.length)}</p>
      <div className="admin-records">
        {visible.map((row) => (
          <article className="admin-record panel" key={row.id}>
            {render(row)}
          </article>
        ))}
      </div>
      {pages > 1 && <nav className="admin-pagination" aria-label="Record pages">
        <button disabled={current === 1} onClick={() => setPage(current - 1)}>Previous</button>
        <span>Page {current} of {pages}</span>
        <button disabled={current === pages} onClick={() => setPage(current + 1)}>Next</button>
      </nav>}
      </>
    ) : (
      <div className="empty">
        <h3>No matching records</h3>
        <p>
          {query || status !== "all"
            ? "Try a different search."
            : "Records will appear as customers and sellers use " +
              brand.name +
              "."}
        </p>
        {(query || status !== "all") && <button className="secondary-button" onClick={() => { setQuery(""); setStatus("all"); }}>Clear filters</button>}
      </div>
    );
  };
  const keys: Record<string, string> = { Verification: "verification", Stores: "stores", Users: "users", Products: "products", Videos: "videos", Orders: "orders", Live: "streams", Ads: "campaigns", Reports: "reports", Support: "reports", "Audit log": "audit" };
  const sourceRows = (data?.[keys[tab]] || []).filter((r: any) => !["Reports", "Support"].includes(tab) || (tab === "Support" ? ["order", "return"].includes(r.target_type) : !["order", "return"].includes(r.target_type)));
  const states = Array.from(new Set<string>(sourceRows.map((r: any) => rowState(tab, r)))).sort();
  const openSupport = (data?.reports || []).filter((r: any) => ["order", "return"].includes(r.target_type) && ["open", "in_review"].includes(r.status)).length;
  return (
    <div className="admin-app admin-console-v2">
      <aside className="admin-sidebar">
        <BrandLogo surface="dark" />
        <p className="admin-label">
          <ShieldCheck size={16} />
          BACK OFFICE
        </p>
        <nav aria-label="Admin navigation">
          {groups.map((group) => {
            const visibleItems = group.items.filter(t => data?.permissions?.includes(tabPermissions[t]) || (t === "Seller Subscriptions & Payouts" && data?.permissions?.includes("verification")));
            if (!visibleItems.length) return null;
            return <details className="admin-nav-group" key={group.title} open={group.items.includes(tab)}>
            <summary>{group.title}</summary>
            {visibleItems.map((t) => {
              const Icon = tabs.find(([name]) => name === t)![1];
              const badge = t === "Verification" ? data?.metrics?.pending_verification : t === "Support" ? openSupport : t === "Reports" ? (data?.reports || []).filter((r: any) => !["order", "return"].includes(r.target_type) && ["open", "in_review"].includes(r.status)).length : 0;
              return <button className={tab === t ? "active" : ""} aria-current={tab === t ? "page" : undefined} key={t} onClick={() => navigate(t)}><Icon size={18} />{labels[t] || t}{badge > 0 && <b>{badge}</b>}</button>;
            })}
          </details>;
          })}
          {data?.permissions?.includes("sellers") && <a className="admin-nav-link" href="/admin/competitive"><ShieldCheck size={18} /> Competitive features</a>}
          {data?.permissions?.includes("settings") && <><a className="admin-nav-link" href="/admin/settings#settings-policies"><ScrollText size={18} /> Legal policies</a><a className="admin-nav-link" href="/admin/email-templates"><MessageSquare size={18} /> Email templates</a><a className="admin-nav-link" href="/admin/settings"><Settings size={18} /> System settings</a></>}
        </nav>
        <Link className="admin-back" href="/">
          <ChevronLeft size={17} />
          Return to marketplace
        </Link>
      </aside>
      <div className="admin-workspace">
        <header className="admin-topbar">
          <button
            type="button"
            className="admin-menu-trigger"
            aria-label={mobileNavOpen ? "Close admin navigation" : "Open admin navigation"}
            aria-expanded={mobileNavOpen}
            aria-controls="admin-mobile-drawer"
            onClick={() => setMobileNavOpen((value) => !value)}
          >
            {mobileNavOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
          <div>
            <ShieldCheck size={18} />
            Admin Console <span>{data?.admin}</span>
          </div>
          <div className="admin-header-actions">
            <button aria-label="Refresh back office" disabled={refreshing} onClick={load}>
              <RefreshCw size={19} className={refreshing ? "admin-spinning" : ""} />
            </button>
          </div>
        </header>
        {mobileNavOpen && <button className="admin-drawer-scrim" aria-label="Close admin navigation" onClick={() => setMobileNavOpen(false)} />}
        <aside id="admin-mobile-drawer" className={`admin-mobile-drawer${mobileNavOpen ? " is-open" : ""}`} hidden={!mobileNavOpen} aria-label="Admin navigation">
          <div className="admin-mobile-drawer-heading"><BrandLogo surface="dark" /><button type="button" aria-label="Close admin navigation" onClick={() => setMobileNavOpen(false)}><X size={20}/></button></div>
          <p className="admin-label"><ShieldCheck size={16}/> BACK OFFICE</p>
          <nav>
            {groups.map((group) => {
              const visibleItems = group.items.filter(t => data?.permissions?.includes(tabPermissions[t]) || (t === "Seller Subscriptions & Payouts" && data?.permissions?.includes("verification")));
              if (!visibleItems.length) return null;
              return <details className="admin-nav-group" key={group.title} open={group.items.includes(tab)}>
              <summary>{group.title}</summary>
              {visibleItems.map((t) => {
                const Icon = tabs.find(([name]) => name === t)![1];
                const badge = t === "Verification" ? data?.metrics?.pending_verification : t === "Support" ? openSupport : t === "Reports" ? (data?.reports || []).filter((r: any) => !["order", "return"].includes(r.target_type) && ["open", "in_review"].includes(r.status)).length : 0;
                return <button className={tab === t ? "active" : ""} aria-current={tab === t ? "page" : undefined} key={t} onClick={() => navigate(t)}><Icon size={18}/>{labels[t] || t}{badge > 0 && <b>{badge}</b>}</button>;
              })}
            </details>;
            })}
            {data?.permissions?.includes("sellers") && <a className="admin-nav-link" href="/admin/competitive" onClick={() => setMobileNavOpen(false)}><ShieldCheck size={18}/> Competitive features</a>}
            {data?.permissions?.includes("settings") && <><a className="admin-nav-link" href="/admin/settings#settings-policies" onClick={() => setMobileNavOpen(false)}><ScrollText size={18}/> Legal policies</a><a className="admin-nav-link" href="/admin/email-templates" onClick={() => setMobileNavOpen(false)}><MessageSquare size={18}/> Email templates</a><a className="admin-nav-link" href="/admin/settings" onClick={() => setMobileNavOpen(false)}><Settings size={18}/> System settings</a></>}
          </nav>
          <Link className="admin-back" href="/" onClick={() => setMobileNavOpen(false)}><ChevronLeft size={17}/> Return to marketplace</Link>
        </aside>
        <main id="main-content" tabIndex={-1}>
          <div className={`page-heading admin-page-heading${tab === "Overview" ? " is-overview" : ""}`} data-admin-tab={tab}>
            <div>
              <p className="eyebrow">{brand.name} OPERATIONS</p>
              <h1>{labels[tab] || tab}</h1>
              <p>
                {descriptions[tab]}
              </p>
            </div>
          </div>
          {updated && <p className="admin-updated">Last refreshed {updated.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}{refreshing ? " · Refreshing…" : ""}</p>}
          {error && (
            <div className="error-banner" role="alert">
              {error} <button onClick={load}>Retry</button>
            </div>
          )}
          {!data && !error ? (
            <div className="loading">Loading back office…</div>
          ) : (
            data && (
              <>
                {["Verification", "Seller Subscriptions & Payouts"].includes(tab) ? <SellerFinanceAdmin key={tab} verificationOnly={tab==="Verification"} /> : tab === "Payments" ? <FinancePanel /> : tab === "Overview" ? (
                  <>
                    <div className="stats">
                      {[
                        { label: "Registered users", value: data.metrics.users, icon: Users },
                        { label: "Business stores", value: data.metrics.stores, icon: Store },
                        { label: "Orders", value: data.metrics.orders, icon: Package },
                        { label: "Delivered sales", value: money(data.metrics.delivered_sales), icon: ArrowUpRight },
                      ].map(({ label, value, icon: Icon }) => (
                        <div className="stat panel admin-stat" key={label}>
                          <span>{label}<i aria-hidden="true"><Icon size={20}/></i></span>
                          <strong>{value}</strong>
                        </div>
                      ))}
                    </div>
                    <section className="admin-attention-section" aria-labelledby="admin-attention-title">
                    <h2 id="admin-attention-title">Needs your attention</h2>
                    <div className="admin-overview-grid">
                      {[
                        { tab: "Verification", value: data.metrics.pending_verification, title: "Seller applications", text: "Review business evidence", icon: FileCheck },
                        { tab: "Support", value: openSupport, title: "Support & returns", text: "Help customers with their orders", icon: MessageSquare },
                        { tab: "Reports", value: data.reports.filter((r: any) => !["order", "return"].includes(r.target_type) && ["open", "in_review"].includes(r.status)).length, title: "Moderation cases", text: "Review reported content", icon: ShieldCheck },
                        { tab: "Live", value: data.streams.filter((r: any) => r.status === "live").length, title: "Live broadcasts", text: "Monitor active sessions", icon: Radio },
                      ].filter(task => data.permissions.includes(tabPermissions[task.tab])).map((task) => <button className="panel admin-task" key={task.tab} onClick={() => navigate(task.tab)}>
                        <div className="admin-task-top"><task.icon size={22} /><ArrowUpRight size={18} /></div>
                        <strong>{task.value}</strong><h3>{task.title}</h3><span>{task.text}</span>
                      </button>)}
                    </div>
                    </section>
                    {data.permissions.includes("sellers") && <section className="panel admin-recent-sellers" aria-labelledby="admin-recent-sellers-title">
                      <div className="admin-recent-sellers-heading"><div><p className="eyebrow">SELLER ACTIVITY</p><h2 id="admin-recent-sellers-title">Recent seller registrations</h2></div></div>
                      {data.stores.length ? <div className="admin-recent-sellers-table-wrap" role="region" aria-label="Recent seller registrations" tabIndex={0}><table><thead><tr><th scope="col">Store</th><th scope="col">Owner</th><th scope="col">Category</th><th scope="col">Joined</th><th scope="col">Status</th></tr></thead><tbody>{data.stores.slice(0,5).map((store:any)=><tr key={store.id}><td><strong>{store.name}</strong><small>{store.location || "Location not set"}</small></td><td>{store.owner_email || "Owner details unavailable"}</td><td>{store.category || "Uncategorised"}</td><td>{store.created ? new Date(store.created).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}) : "—"}</td><td><span className={`admin-status-pill${store.suspended ? " is-suspended" : store.verified ? " is-verified" : " is-pending"}`}>{store.suspended ? "Suspended" : store.verified ? "Verified" : "Unverified"}</span></td></tr>)}</tbody></table></div> : <div className="admin-recent-sellers-empty"><Store size={20}/><p>No seller registrations yet. New stores will appear here.</p></div>}
                    </section>}
                    <details className="panel admin-launch-checklist" aria-labelledby="launch-check-title">
                      <summary id="launch-check-title">Marketplace readiness</summary>
                      <ul>
                        <li><strong>Delivery coverage:</strong> {data.metrics.missing_shipping} stores still need confirmed delivery states. {data.permissions.includes("sellers") && <button onClick={() => navigate("Stores")}>Review stores</button>}</li>
                        <li><strong>Policies:</strong> {data.metrics.draft_policies} drafts need business details and approval. {data.permissions.includes("settings") && <a href="/admin/settings#settings-policies">Review policies</a>}</li>
                        <li><strong>Debit card payments:</strong> {data.paymentReadiness?.online ? `${data.paymentReadiness.mode === "live" ? "Live" : "Test"} configuration ready` : "Configuration incomplete"}. {data.paymentReadiness?.blockers?.join(". ")} {data.permissions.includes("settings") && <a href="/admin/settings#settings-payments">Review payment setup</a>}</li>
                        <li><strong>Verified live payments:</strong> {data.metrics.live_payments}. A ready configuration still needs a real end-to-end test.</li>
                        <li><strong>Support:</strong> Confirm your published address receives customer replies. {data.permissions.includes("settings") && <a href="/admin/settings#settings-support">Review support contact</a>}</li>
                      </ul>
                    </details>
                    <details className="notice admin-guidance">
                      <summary>Understand payment and launch status</summary>
                      <p>
                        New orders use debit card payment; cash on delivery is disabled. Delivered sales
                        represent sellers’ gross order value; platform fees and
                        revenue have not been collected. Online payments and
                        paid ads use the configured payment mode. Native
                        broadcasts require streaming credentials. Seller payouts
                        and collected platform revenue are not represented as
                        real transactions.
                      </p>
                    </details>
                    <details className="panel admin-guidance">
                      <summary>How to make admin decisions</summary>
                      <p className="admin-explain">
                        Review evidence before granting a seller badge. Record a
                        reason for every moderation decision. Suspended users
                        cannot place orders or publish; suspended stores
                        disappear from discovery and their live sessions end.
                        Existing order records remain available.
                      </p>
                    </details>
                  </>
                ) : (
                  <>
                    <div className="admin-search">
                      <Search size={18} />
                      <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        aria-label={"Search " + (labels[tab] || tab).toLowerCase()}
                        placeholder={"Search " + (labels[tab] || tab).toLowerCase()}
                      />
                      {query && <button aria-label="Clear search" onClick={() => setQuery("")}><X size={18} /></button>}
                    </div>
                    <div className="admin-filter-bar">
                      <label htmlFor="admin-status">Status</label>
                      <select id="admin-status" value={status} onChange={(e) => setStatus(e.target.value)}><option value="all">All statuses</option>{states.map((value) => <option value={value} key={value}>{value.replaceAll("_", " ")}</option>)}</select>
                      <span>Searching latest {tab === "Live" ? 100 : 300} records</span>
                    </div>
                    {tab === "Videos"
                        ? list(data.videos, (r: any) => (
                            <>
                              <div className="admin-record-top"><div><h3>{r.seller}</h3><p>{r.caption || "Product video"}</p></div><span className="status">{r.status}</span></div>
                              <video className="admin-video-preview" src={r.media} controls playsInline preload="none" aria-label={"Moderate seller video from " + r.seller}/>
                              <p className="secondary">Submitted {new Date(r.created).toLocaleString("en-GB")}{r.moderation_note ? " · " + r.moderation_note : ""}</p>
                              {r.status === "pending" && <details className="admin-action-menu"><summary>Review video</summary><div className="admin-action-options">{action("Approve video", () => choose("video", r, "approved", "Approve this video for storefronts and discovery?"), true)}{action("Reject video", () => choose("video", r, "rejected", "Reject this video?"), false)}</div></details>}
                              {r.status !== "removed" && r.status !== "pending" && <details className="admin-action-menu"><summary>Manage video</summary><div className="admin-action-options">{action("Remove video", () => choose("video", r, "removed", "Remove this video from public surfaces?"), false)}</div></details>}
                            </>
                          ))
                        : tab === "Stores"
                        ? list(data.stores, (r) => (
                            <>
                              <div className="admin-record-top">
                                <div>
                                  <h3>
                                    {r.name}{" "}
                                    <VerifiedSellerBadge verified={r.verified} suspended={r.suspended}/>
                                  </h3>
                                  <p>
                                    {r.category} · {r.location}
                                  </p>
                                  {r.official_store === 1 && <p className="secondary">Official Store designation is active.</p>}
                                </div>
                                <span className="status">
                                  {r.suspended
                                    ? "Suspended"
                                    : r.verified
                                      ? "Verified"
                                      : "Unverified"}
                                </span>
                              </div>
                              <p className="secondary">
                                {r.owner_email ||
                                  "Owner profile not yet registered"}{" "}
                                · {r.phone}
                              </p>
                              <p>{r.description}</p>
                              <details className="admin-action-menu"><summary>Manage record</summary><div className="admin-action-options">
                                {r.verified===1&&data.permissions?.includes("verification")&&action("Revoke verification",()=>choose("verification-revoke",r,0,"Revoke this seller’s verification badge and selling eligibility? A reason is required."),true)}
                                {data.permissions?.includes("sellers")&&action(r.official_store===1?"Remove Official Store designation":"Designate Official Store",()=>choose("official-store",r,r.official_store===1?0:1,r.official_store===1?"Remove this Official Store designation?":"Confirm this seller is an authorised official brand/store before designation."),r.official_store===1)}
                                {action(
                                  r.suspended
                                    ? "Restore store"
                                    : "Suspend store",
                                  () =>
                                    choose(
                                      "store",
                                      r,
                                      r.suspended ? 0 : 1,
                                      r.suspended
                                        ? "Restore this store?"
                                        : "Suspend this store and end its live sessions?",
                                    ),
                                  !r.suspended,
                                )}
                              </div></details>
                            </>
                          ))
                        : tab === "Users"
                          ? list(data.users, (r) => (
                              <>
                                <div className="admin-record-top">
                                  <div>
                                    <h3>{r.name}</h3>
                                    <p>{r.email}</p>
                                  </div>
                                  <span className="status">
                                    {r.suspended ? "Suspended" : "Active"}
                                  </span>
                                </div>
                                <p className="secondary">
                                  Last seen{" "}
                                  {new Date(r.last_seen).toLocaleString(
                                    "en-GB",
                                  )}
                                </p>
                                <details className="admin-action-menu"><summary>Manage record</summary><div className="admin-action-options">
                                  {action(
                                    r.suspended
                                      ? "Restore account"
                                      : "Suspend account",
                                    () =>
                                      choose(
                                        "user",
                                        r,
                                        r.suspended ? 0 : 1,
                                        r.suspended
                                          ? "Restore this account?"
                                          : "Suspend this account?",
                                      ),
                                    !r.suspended,
                                  )}
                                </div></details>
                              </>
                            ))
                          : tab === "Products"
                            ? list(data.products, (r) => (
                                <>
                                  <div className="admin-record-top">
                                    <div className="admin-product">
                                      <ImageAsset src={r.image} alt={r.name} />
                                      <div>
                                        <h3>{r.name}</h3>
                                        <p>
                                          {r.seller} · {r.category}
                                        </p>
                                        <strong>
                                          {money(r.price)} · {r.stock} in stock
                                        </strong>
                                      </div>
                                    </div>
                                    <span className="status">
                                      {r.active ? "Listed" : "Hidden"}
                                    </span>
                                  </div>
                                  <p>{r.description}</p>
                                  <details className="admin-action-menu"><summary>Manage record</summary><div className="admin-action-options">
                                    {action(
                                      r.active
                                        ? "Hide product"
                                        : "Restore product",
                                      () =>
                                        choose(
                                          "product",
                                          r,
                                          r.active ? 0 : 1,
                                          r.active
                                            ? "Hide this product from the marketplace?"
                                            : "Restore this product?",
                                        ),
                                      Boolean(r.active),
                                    )}
                                  </div></details>
                                </>
                              ))
                            : tab === "Orders"
                              ? list(data.orders, (r) => (
                                  <>
                                    <div className="admin-record-top">
                                      <div>
                                        <small>
                                          ORDER {r.id.slice(0, 8).toUpperCase()}
                                        </small>
                                        <h3>
                                          {r.seller} · {money(r.total)}
                                        </h3>
                                      </div>
                                      <span className="status">{r.status}</span>
                                    </div>
                                    <p>
                                      {r.name} · {r.phone}
                                    </p>
                                    <details>
                                      <summary>Delivery address</summary>
                                      <p>{r.address}</p>
                                    </details>
                                    <p className="secondary">
                                      {new Date(r.created).toLocaleString(
                                        "en-GB",
                                      )}{" "}
                                      · Cash on delivery
                                    </p>
                                    <p className="secondary">
                                      Fulfilment updates are managed by the
                                      seller. Disputes and returns are handled
                                      under Reports.
                                    </p>
                                  </>
                                ))
                              : tab === "Live"
                                ? list(data.streams, (r) => (
                                    <>
                                      <div className="admin-record-top">
                                        <div>
                                          <h3>{r.title}</h3>
                                          <p>{r.seller}</p>
                                        </div>
                                        <span className="status">
                                          {r.status}
                                        </span>
                                      </div>
                                      {r.status === "live" && (
                                        <details className="admin-action-menu"><summary>Manage record</summary><div className="admin-action-options">
                                          {action(
                                            "End livestream",
                                            () =>
                                              choose(
                                                "stream",
                                                r,
                                                "ended",
                                                "End this livestream?",
                                              ),
                                            true,
                                          )}
                                        </div></details>
                                      )}
                                    </>
                                  ))
                                : tab === "Ads"
                                  ? list(data.campaigns, (r) => (
                                      <>
                                        <div className="admin-record-top">
                                          <div>
                                            <h3>{r.title}</h3>
                                            <p>
                                              {r.seller} · {r.goal} ·{" "}
                                              {r.location}
                                            </p>
                                          </div>
                                          <span className="status">
                                            {r.status.replace("_", " ")}
                                          </span>
                                        </div>
                                        <p>
                                          {money(r.budget)}/day · {r.days} days
                                        </p>
                                        <p className="secondary">
                                          No paid delivery or spend. Approval is
                                          for the campaign plan only.
                                        </p>
                                        {r.status === "draft" && (
                                          <details className="admin-action-menu"><summary>Manage record</summary><div className="admin-action-options">
                                            {action("Approve draft", () =>
                                              choose(
                                                "campaign",
                                                r,
                                                "approved_draft",
                                                "Approve this campaign draft?",
                                              ),
                                            )}
                                            {action(
                                              "Reject draft",
                                              () =>
                                                choose(
                                                  "campaign",
                                                  r,
                                                  "rejected",
                                                  "Reject this campaign draft?",
                                                ),
                                              true,
                                            )}
                                          </div></details>
                                        )}
                                      </>
                                    ))
                                  : ["Reports", "Support"].includes(tab)
                                    ? list(
                                        data.reports.filter((r: any) =>
                                          tab === "Support"
                                            ? ["order", "return"].includes(
                                                r.target_type,
                                              )
                                            : !["order", "return"].includes(
                                                r.target_type,
                                              ),
                                        ),
                                        (r) => (
                                          <>
                                            <div className="admin-record-top">
                                              <div>
                                                <h3>{r.reason}</h3>
                                                <p>
                                                  {r.target_type} ·{" "}
                                                  {r.reporter_name ||
                                                    "Customer"}{" "}
                                                  · {r.reporter_email || ""}
                                                </p>
                                              </div>
                                              <span className="status">
                                                {r.status.replace("_", " ")}
                                              </span>
                                            </div>
                                            <p>{r.details}</p>
                                            <small>Reference: {r.target}</small>
                                            {r.target_type==="seller_message"&&<ReportedMessage reportId={r.id}/>}
                                            {r.resolution && (
                                              <p className="admin-note">
                                                Resolution: {r.resolution}
                                              </p>
                                            )}
                                            <details className="admin-action-menu"><summary>Manage record</summary><div className="admin-action-options">
                                              {action("Start review", () =>
                                                choose(
                                                  "report",
                                                  r,
                                                  "in_review",
                                                  "Start reviewing this case?",
                                                ),
                                              )}
                                              {action("Resolve", () =>
                                                choose(
                                                  "report",
                                                  r,
                                                  "resolved",
                                                  "Resolve this case?",
                                                ),
                                              )}
                                              {action(
                                                "Reject",
                                                () =>
                                                  choose(
                                                    "report",
                                                    r,
                                                    "rejected",
                                                    "Reject this case?",
                                                  ),
                                                true,
                                              )}
                                            </div></details>
                                            <p className="secondary">
                                              Resolution notes are visible to
                                              the reporting customer. Resolving
                                              a return case does not transfer
                                              money or automatically restock a
                                              product.
                                            </p>
                                          </>
                                        ),
                                      )
                                    : list(data.audit, (r) => (
                                        <>
                                          <div className="admin-record-top">
                                            <div>
                                              <h3>
                                                {r.action} ·{" "}
                                                {r.target.slice(0, 12)}
                                              </h3>
                                              <p>
                                                {r.email} ·{" "}
                                                {new Date(
                                                  r.created,
                                                ).toLocaleString("en-GB")}
                                              </p>
                                            </div>
                                            <span className="status">
                                              Recorded
                                            </span>
                                          </div>
                                          <p>{r.reason}</p>
                                          <details>
                                            <summary>Before and after</summary>
                                            <pre>
                                              {JSON.stringify(
                                                {
                                                  before: JSON.parse(
                                                    r.before_json,
                                                  ),
                                                  after: JSON.parse(
                                                    r.after_json,
                                                  ),
                                                },
                                                null,
                                                2,
                                              )}
                                            </pre>
                                          </details>
                                        </>
                                      ))}
                  </>
                )}
              </>
            )
          )}
          <footer>
            <span>{brand.name} Back Office</span>
            <span>Access is role controlled.</span>
          </footer>
        </main>
      </div>
      {toast && (
        <div className="toast" role="status">
          <button
            aria-label="Dismiss notification"
            onClick={() => setToast("")}
          >
            <X size={17} />
          </button>
          {toast}
        </div>
      )}
      {change && (
        <div className="modal-backdrop">
          <section
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-label="Confirm admin action"
          >
            <button
              className="modal-close"
              aria-label="Cancel action"
              onClick={() => !busy && setChange(null)}
            >
              <X size={22} />
            </button>
            <h2>{change.title}</h2>
            <p>
              This action affects a real record and will be added to the audit
              log.
            </p>
            <form noValidate onSubmit={submit}>
              {dialogError&&<p role="alert" className="error-banner">{dialogError}</p>}
              <label className="field">
                Reason / customer resolution
                <textarea
                  name="reason"
                  required
                  minLength={change.action==="verification-revoke"?5:3}
                  maxLength={1000}
                  placeholder="Explain your decision clearly"
                  autoFocus
                />
              </label>
              <button className="primary full" disabled={busy}>
                {busy ? "Applying…" : "Confirm action"}
              </button>
              <button
                className="secondary-button full"
                type="button"
                disabled={busy}
                onClick={() => setChange(null)}
              >
                Cancel
              </button>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}
