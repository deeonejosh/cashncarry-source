import type { ReactNode } from "react";

/** Keep seller-specific terms visible while directing buyers to the platform's published return process. */
export default function ReturnGuidance({ sellerTerms }: { sellerTerms?: string | null }): ReactNode {
  return (
    <div className="product-return-guidance">
      {sellerTerms ? <p>Seller-provided return details: {sellerTerms}</p> : <p>Seller-specific return details are not available.</p>}
      <p>
        Read the <a href="/refunds">Returns and Refunds Policy</a>, then use your order to request a return or support review.
        Wait for return instructions before sending an item back.
      </p>
    </div>
  );
}
