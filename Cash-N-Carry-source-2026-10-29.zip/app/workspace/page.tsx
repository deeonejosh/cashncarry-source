"use client";
import { createPortraitPublisher } from "../portrait-publisher";
import Link from "next/link";
import { completeIceOffer } from "../webrtc-offer";
import { safeReturnPath, workspaceTab } from "../auth-navigation";
import SellerNavigation from "../seller/navigation";
import BrandLogo from "../brand-logo";
import ProfileEditor from "../account/profile-editor";
import ImageAsset from "../image-asset";
import StoreLogo from "../store-logo";
import { useEffect, useRef, useState } from "react";
import {
  Mic,
  MicOff,
  SwitchCamera,
  X,
  Send,
  ShoppingBag,
  MoreHorizontal,
  Maximize,
  Radio,
  Eye,
  Heart,
  MessageCircle,
  ShieldCheck,
  Video,
  VideoOff,
  Zap,
  Settings,
  Pin,
  Share2,
  BarChart3,
  CheckCircle2,
} from "lucide-react";
import { LiveAction, LiveSheet, ElapsedBroadcast } from "../live-overlay";
import { CustomerNavigation } from "../customer-shell";
import { takeCameraHandoff } from "../camera-handoff";
const states = [
  "Abia",
  "Adamawa",
  "Akwa Ibom",
  "Anambra",
  "Bauchi",
  "Bayelsa",
  "Benue",
  "Borno",
  "Cross River",
  "Delta",
  "Ebonyi",
  "Edo",
  "Ekiti",
  "Enugu",
  "FCT",
  "Gombe",
  "Imo",
  "Jigawa",
  "Kaduna",
  "Kano",
  "Katsina",
  "Kebbi",
  "Kogi",
  "Kwara",
  "Lagos",
  "Nasarawa",
  "Niger",
  "Ogun",
  "Ondo",
  "Osun",
  "Oyo",
  "Plateau",
  "Rivers",
  "Sokoto",
  "Taraba",
  "Yobe",
  "Zamfara",
];
export default function Workspace() {
  const [d, setD] = useState<any>(null),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [tab, setTab] = useState("Account"),
    [active, setActive] = useState(""),
    [starting, setStarting] = useState(false),
    [previewId, setPreviewId] = useState(""),
    [connectionLabel, setConnectionLabel] = useState("Not broadcasting"),
    [muted, setMuted] = useState(false),
    [hostChat, setHostChat] = useState<any[]>([]),
    [hostViewers, setHostViewers] = useState<number | null>(null),
    [hostMessage, setHostMessage] = useState(""),
    [hostSheet, setHostSheet] = useState(""),
    [broadcastStartedAt, setBroadcastStartedAt] = useState<number | null>(null),
    [fullscreenAvailable, setFullscreenAvailable] = useState(false),
    [returnPath, setReturnPath] = useState("/workspace"),
    [routeReady,setRouteReady]=useState(false);
  const hostChatScrollRef = useRef<HTMLDivElement>(null);
  const hostChatStickToBottom = useRef(true);
  const supportOrder = (new URL(returnPath, "https://cashncarryng.com").searchParams.get("order") || "").slice(0, 150);
  useEffect(() => {
    setReturnPath(
      safeReturnPath(window.location.pathname + window.location.search),
    );
    setRouteReady(true);
  }, []);
  const pc = useRef<RTCPeerConnection | null>(null),
    camera = useRef<MediaStream | null>(null),
    portrait = useRef<ReturnType<typeof createPortraitPublisher> | null>(null),
    confirmationPending = useRef(false),
    previewPending = useRef(false),
    switchPending = useRef(false),
    cameraFacing = useRef("user"),
    session = useRef(""),
    broadcast = useRef(""),
    generation = useRef(0),
    preview = useRef<HTMLVideoElement>(null),
    setupPending = useRef(false);
  const [studioTitle,setStudioTitle]=useState("");
  const [studioProduct,setStudioProduct]=useState("");
  const [cameraEnabled,setCameraEnabled]=useState(true);
  const [torchEnabled,setTorchEnabled]=useState(false);
  const [torchSupported,setTorchSupported]=useState(false);
  const [pinCollapsed,setPinCollapsed]=useState(false);
  const [hostLikes,setHostLikes]=useState<number|null>(null);
  const [liveStats,setLiveStats]=useState<any>(null);
  const [hostPeakViewers,setHostPeakViewers]=useState<number|null>(null);
  const [endedBackground,setEndedBackground]=useState("");
  const [endSummary,setEndSummary]=useState<{seconds:number|null;viewers:number|null;likes:number|null;productTaps:number|null;addToCart:number|null;comments:number|null;orders:number|null;sales:number|null}|null>(null);
  const studioEntered=useRef(false);
  const studioStartLock=useRef(false);
  const studioMutationLock=useRef(false);
  const endingLock=useRef(false);
  const pinLock=useRef(false);
  const [pinCandidate,setPinCandidate]=useState("");
  const [productSearch,setProductSearch]=useState("");
  const [dealProduct,setDealProduct]=useState("");
  const [dealPrice,setDealPrice]=useState("");
  const [dealQuantity,setDealQuantity]=useState("1");
  const [dealMinutes,setDealMinutes]=useState("10");
  const [auctionProduct,setAuctionProduct]=useState("");
  const [auctionStart,setAuctionStart]=useState("");
  const [auctionIncrement,setAuctionIncrement]=useState("");
  const [auctionMinutes,setAuctionMinutes]=useState("5");
  const [bundleProductIds,setBundleProductIds]=useState<string[]>([]);
  const [bundleQuantities,setBundleQuantities]=useState<Record<string,number>>({});
  const [bundleTitle,setBundleTitle]=useState("");
  const [bundlePrice,setBundlePrice]=useState("");
  const [bundleFeatureMinutes,setBundleFeatureMinutes]=useState("10");
  const [bundleRequestId,setBundleRequestId]=useState("");
  const [bundleProductId,setBundleProductId]=useState("");
  const [sellerDeals,setSellerDeals]=useState<any[]>([]);
  const [sellerAuctions,setSellerAuctions]=useState<any[]>([]);
  const [sellerBundles,setSellerBundles]=useState<any[]>([]);
  const [pinnedDealId,setPinnedDealId]=useState("");
  const [pinnedAuctionId,setPinnedAuctionId]=useState("");
  const [pinnedBundleId,setPinnedBundleId]=useState("");
  const [pinnedBundleEndsAt,setPinnedBundleEndsAt]=useState("");
  const [studioClock,setStudioClock]=useState(Date.now());
  useEffect(()=>{const timer=setInterval(()=>setStudioClock(Date.now()),1000);return()=>clearInterval(timer);},[]);
  async function refreshHostCommerce() {
    const streamQuery=active?"?stream="+encodeURIComponent(active):"";
    const [dealResponse, auctionResponse, bundleResponse] = await Promise.all([
      fetch("/api/live-deals"+streamQuery, { cache: "no-store" }),
      fetch("/api/live-auctions"+streamQuery, { cache: "no-store" }),
      active ? fetch("/api/product-bundles?stream="+encodeURIComponent(active), { cache: "no-store" }) : Promise.resolve(new Response(JSON.stringify({bundles:[]}))),
    ]);
    const [dealData, auctionData, bundleData] = await Promise.all([
      dealResponse.json(),
      auctionResponse.json(),
      bundleResponse.json(),
    ]);
    if (dealResponse.ok) {setSellerDeals(dealData.deals || []);setPinnedDealId(dealData.pinnedDeal||"");}
    if (auctionResponse.ok) {setSellerAuctions(auctionData.auctions || []);setPinnedAuctionId(auctionData.pinnedAuction||"");}
    if (bundleResponse.ok) {setSellerBundles(bundleData.bundles||[]);setPinnedBundleId(bundleData.pinnedBundle||"");setPinnedBundleEndsAt(bundleData.pinnedBundleEndsAt||"");}
    if(active&&!auctionResponse.ok)throw new Error(auctionData.error||"Auction status could not be refreshed.");
  }
  useEffect(()=>{if(!active)return;let alive=true;const load=async()=>{try{await refreshHostCommerce();}catch{/* Keep the studio usable when live activity cannot be refreshed. */}};void load();const timer=setInterval(()=>{if(alive)void load();},5000);return()=>{alive=false;clearInterval(timer);};},[active]);
  useEffect(()=>{if(hostSheet!=="stats"||!active)return;let alive=true;const load=async()=>{try{const response=await fetch("/api/seller-analytics?stream="+encodeURIComponent(active),{cache:"no-store",signal:AbortSignal.timeout(8000)});if(response.ok){const stats=await response.json();if(alive)setLiveStats(stats);}}catch{/* Stats stay unavailable until the next refresh. */}};void load();const timer=setInterval(()=>void load(),10000);return()=>{alive=false;clearInterval(timer);};},[hostSheet,active]);
  const cameraOnlyId="camera-preview";
  useEffect(()=>{
    if(!d || studioEntered.current || new URLSearchParams(location.search).get("studio")!=="1")return;
    studioEntered.current=true;
    const params=new URLSearchParams(location.search);
    setTab("Studio");
    const autoStart=params.get("autoStart")==="1";
    const launchTitle=params.get("studioTitle")||"";
    const launchProduct=params.get("studioProduct")||"";
    if(autoStart){params.delete("autoStart");const query=params.toString();history.replaceState(null,"",location.pathname+(query?`?${query}`:"")+location.hash);}
    if(!d.user){const returnTo=safeReturnPath(location.pathname+location.search);window.location.assign(`/sign-in?returnTo=${encodeURIComponent(returnTo)}`);return;}
    if(d.myStore && d.sellerAccess?.canSell){if(launchTitle)setStudioTitle(launchTitle);if(launchProduct)setStudioProduct(launchProduct);const action=params.get("studioAction");if(action==="deal"||action==="auction")setHostSheet(action);if(autoStart){setStarting(true);setConnectionLabel("Connecting…");setMessage("Preparing your broadcast…");}void (async()=>{await previewCamera(cameraOnlyId,autoStart);if(autoStart)await startStudio({title:launchTitle,product:launchProduct});})();}
    else if(d.myStore)setMessage(d.sellerAccess?.verification==="suspended"?"Selling is suspended. Review your seller status before broadcasting.":d.sellerAccess?.verification!=="verified"?"Complete seller verification before going live.":"Active selling access is required before going live.");
    else setMessage("Create your seller storefront before starting a livestream.");
  },[d]);
  async function startStudio(options?:{title?:string;product?:string}){
    if(studioStartLock.current)return;
    if(!camera.current?.getVideoTracks().some(t=>t.readyState==="live"&&t.enabled)||!camera.current?.getAudioTracks().some(t=>t.readyState==="live")){setStarting(false);setConnectionLabel("Camera preview — not live");setMessage("Enable your camera and allow microphone access before going live.");return;}
    if(!d.services?.stream){setStarting(false);setConnectionLabel("Camera preview — not live");setMessage("Broadcasting is not configured yet. Your camera view remains open.");return;}
    studioStartLock.current=true;
    setStarting(true);
    setConnectionLabel("Preparing broadcast…");
    setMessage("Preparing your broadcast…");
    const run=generation.current;
    try{
      const title=(options?.title??studioTitle).trim();
      const product=options?.product??studioProduct;
      const result=await request({action:"preview-session",title:title||`${d.myStore.name} · Live shopping`,featured:product?[product]:[],product});
      if(result?.streamId){if(run!==generation.current){await request({action:"end",id:result.streamId},"/api/streams");return;}setPreviewId(result.streamId);await start(result.streamId);}
      else {setStarting(false);setConnectionLabel("Not broadcasting");setMessage("We could not prepare the broadcast. Retry when your connection is stable.");}
    }catch(error){setStarting(false);setConnectionLabel("Not broadcasting");setMessage(error instanceof Error?error.message:"We could not prepare the broadcast. Retry when your connection is stable.");}
    finally{studioStartLock.current=false;}
  }
  async function toggleTorch(){
    const track=camera.current?.getVideoTracks()[0];if(!track)return;
    try{await track.applyConstraints({advanced:[{torch:!torchEnabled} as MediaTrackConstraintSet]});setTorchEnabled(v=>!v);}catch{setMessage("Flashlight is unavailable on this camera.");}
  }
  const reconnectTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const connectionDeadline=useRef<ReturnType<typeof setTimeout>|null>(null);
  const reconnectLock=useRef(false);
  const reconnectAttempts=useRef(0);
  const [retryBroadcast,setRetryBroadcast]=useState("");
  function detachTransport(){
    if(reconnectTimer.current){clearTimeout(reconnectTimer.current);reconnectTimer.current=null;}
    if(connectionDeadline.current){clearTimeout(connectionDeadline.current);connectionDeadline.current=null;}
    const endpoint=session.current;session.current="";
    if(pc.current)pc.current.onconnectionstatechange=null;
    pc.current?.close();pc.current=null;
    portrait.current?.stop();portrait.current=null;
    confirmationPending.current=false;
    return endpoint;
  }
  async function recoverBroadcast(id:string){
    if(reconnectLock.current || broadcast.current!==id)return;
    reconnectLock.current=true;
    const guard=++generation.current;
    const endpoint=detachTransport();
    setActive("");setPreviewId(id);setStarting(true);setConnectionLabel("Reconnecting…");
    setMessage("Network interrupted. Restoring this broadcast; keep the studio open.");
    try{
      if(endpoint)await fetch(endpoint,{method:"DELETE",signal:AbortSignal.timeout(5000)}).catch(()=>{});
      if(guard!==generation.current)return;
      broadcast.current="";
      await start(id,true);
    }finally{reconnectLock.current=false;}
  }
  function offerBroadcastRetry(id:string,reason:string){
    generation.current++;
    releaseMedia();
    broadcast.current=id;
    setActive("");setPreviewId(id);setStarting(false);setRetryBroadcast(id);
    setConnectionLabel("Connection lost — not live");setMessage(reason);
  }
  async function load() {
    const r = await fetch("/api/commerce", {
      signal: AbortSignal.timeout(15000),
    });
    const b: any = await r.json();
    if (!r.ok) throw Error(b.error);
    setD(b);
  }
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const requested = params.get("tab");
    // Keep the retired Seller Centre Broadcasts route pointed at history.
    // The camera-first studio has its own internal route state.
    if (requested === "Broadcasts" && params.get("studio") !== "1") {
      window.location.replace("/seller/live-history");
      return;
    }
    load().catch((e) => setMessage(e.message));
    const leave = () => {
      const id = broadcast.current;
      generation.current++;
      releaseMedia();
      if (id)
        fetch("/api/streams", {
          method: "POST",
          keepalive: true,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "end", id }),
        }).catch(() => {});
    };
    const warnBeforeLeaving = (e: BeforeUnloadEvent) => {
      if (!broadcast.current) return;
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", warnBeforeLeaving);
    window.addEventListener("pagehide", leave);
    const resolvedTab = requested === "Addresses" ? "Account" : requested === "Broadcasts" && params.get("studio") === "1" ? "Studio" : workspaceTab(requested);
    setTab(resolvedTab);
    if (requested === "Addresses") {
      params.set("tab", "Account");
      window.history.replaceState(null, "", `${window.location.pathname}?${params.toString()}`);
    }
    return () => {
      window.removeEventListener("pagehide", leave);
      window.removeEventListener("beforeunload", warnBeforeLeaving);
      const id = broadcast.current;
      generation.current++;
      releaseMedia();
      if (id)
        fetch("/api/streams", {
          method: "POST",
          keepalive: true,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "end", id }),
        }).catch(() => {});
    };
  }, []);
  async function request(body: any, path = "/api/commerce") {
    setBusy(true);
    try {
      const r = await fetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(body.action === "end" ? 45000 : 25000),
      });
      const b: any = await r.json();
      if (!r.ok) throw Error(b.error || "The action could not be completed. Please try again.");
      if (body.action !== "connected") {
        try {
          await load();
          setMessage("Saved successfully");
        } catch {
          setMessage(
            "Saved successfully, but the screen could not refresh. Reload to see the latest data.",
          );
        }
      }
      return b;
    } catch (e: any) {
      setMessage(e.message);
      return null;
    } finally {
      setBusy(false);
    }
  }
  async function form(e: React.FormEvent<HTMLFormElement>, action: string) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const body: any = Object.fromEntries(fd);
    if (action === "delivery-settings") body.coverage = fd.getAll("coverage");
    if (setupPending.current) return;
    setupPending.current = true;
    try {
      await request({ action, ...body });
    } finally {
      setupPending.current = false;
    }
  }
  function releaseMedia() {
    const endpoint = detachTransport();
    if (endpoint)
      fetch(endpoint, {
        method: "DELETE",
        signal: AbortSignal.timeout(5000),
      }).catch(() => {});
    if (pc.current) pc.current.onconnectionstatechange = null;
    pc.current?.close();
    pc.current = null;
    portrait.current?.stop();
    portrait.current = null;
    camera.current?.getTracks().forEach((track) => track.stop());
    camera.current = null;
    if (preview.current) preview.current.srcObject = null;
    broadcast.current = "";
    confirmationPending.current = false;
  }
  function captureEndedBackground() {
    const video=preview.current;
    if(!video || !video.videoWidth || !video.videoHeight)return "";
    try {const canvas=document.createElement("canvas");canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext("2d")?.drawImage(video,0,0);return canvas.toDataURL("image/jpeg",0.82);} catch {return "";}
  }
  async function loadEndAnalytics(id:string) {
    try {
      const response=await fetch("/api/seller-analytics?stream="+encodeURIComponent(id),{cache:"no-store",signal:AbortSignal.timeout(8000)});
      if(!response.ok)return;
      const stats=await response.json();
      setEndSummary(previous=>previous?{...previous,viewers:typeof stats.peakViewers==="number"?stats.peakViewers:previous.viewers,likes:typeof stats.likes==="number"?stats.likes:previous.likes,productTaps:typeof stats.productTaps==="number"?stats.productTaps:previous.productTaps,addToCart:typeof stats.addToCart==="number"?stats.addToCart:null,comments:typeof stats.comments==="number"?stats.comments:null,orders:typeof stats.confirmedOrders==="number"?stats.confirmedOrders:null,sales:typeof stats.verifiedSales==="number"?stats.verifiedSales:null}:previous);
    } catch {/* Keep the locally observed summary when analytics are unavailable. */}
  }
  async function stop(id = broadcast.current) {
    if (endingLock.current) return;
    endingLock.current = true;
    try {
    setRetryBroadcast("");
    reconnectAttempts.current=0;
    if(id){setEndedBackground(captureEndedBackground());setEndSummary({seconds:broadcastStartedAt?Math.max(0,Math.floor((Date.now()-broadcastStartedAt)/1000)):null,viewers:hostPeakViewers??hostViewers,likes:hostLikes,productTaps:null,addToCart:null,comments:null,orders:null,sales:null});}
    generation.current++;
    releaseMedia();
    setActive("");
    setPreviewId("");
    setStarting(false);
    setConnectionLabel(id ? "Confirming broadcast ended…" : "Preview closed");
    setHostSheet("");
    setBroadcastStartedAt(null);
    if (id) {
      let ended = null;
      for (let attempt = 0; attempt < 3 && !ended; attempt++) {
        ended = await request({ action: "end", id }, "/api/streams");
      }
      setConnectionLabel(
        ended ? "Ended" : "End not confirmed — camera stopped",
      );
      if(ended)void loadEndAnalytics(id);
      if (!ended) {
        setRetryBroadcast(id);
        setMessage(
          "Camera and microphone stopped. The server could not confirm ending; viewers may see LIVE until the connection expires. Use End session to retry safely.",
        );
      }
    }
    } finally { endingLock.current = false; }
  }
  async function previewCamera(id: string, connecting = false) {
    if ((broadcast.current && broadcast.current!==retryBroadcast) || starting || previewPending.current) return;
    previewPending.current = true;
    setEndedBackground("");
    setEndSummary(null);
    setBusy(true);
    setPreviewId(id);
    const run = ++generation.current;
    try {
      releaseMedia();
      const handedOff = takeCameraHandoff();
      let media = handedOff?.stream || null;
      if (!media) {
        if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) throw Error("Use HTTPS in a browser that supports camera access.");
        media = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "user",
            width: { ideal: 720 },
            height: { ideal: 1280 },
            aspectRatio: { ideal: 9 / 16 },
          },
          audio: true,
        });
      }
      if (run !== generation.current) {
        media.getTracks().forEach((t) => t.stop());
        return;
      }
      camera.current = media;
      cameraFacing.current =
        handedOff?.facing || media.getVideoTracks()[0]?.getSettings().facingMode || "user";
      if (preview.current) preview.current.srcObject = media;
      setPreviewId(id);
      setMuted(false);
      setCameraEnabled(true);
      setTorchEnabled(false);
      setTorchSupported(Boolean((media.getVideoTracks()[0]?.getCapabilities?.() as MediaTrackCapabilities & {torch?:boolean})?.torch));
      setConnectionLabel(connecting ? "Connecting…" : "Camera preview — not live");
      const settings = media.getVideoTracks()[0]?.getSettings();
      setMessage(
        connecting ? "Preparing your broadcast…" : `Camera ${settings?.width || "?"} × ${settings?.height || "?"}. Broadcast video is centred and cropped to portrait. Check your picture before going live.`,
      );
    } catch (e: any) {
      if (run !== generation.current) return;
      if(connecting)setStarting(false);
      if(id!==cameraOnlyId)setPreviewId("");
      setConnectionLabel(e.name === "NotAllowedError" ? "Camera permission required" : e.name === "NotFoundError" ? "Camera or microphone unavailable" : e.message?.startsWith("Use HTTPS") ? "Secure camera access unavailable" : "Camera preview unavailable");
      setMessage(
        e.name === "NotAllowedError"
          ? "Allow camera and microphone access to preview your broadcast."
          : e.message?.startsWith("Use HTTPS") ? e.message : e.name === "NotFoundError" ? "No camera or microphone was found. Connect a device and retry." : "Camera preview unavailable. Check your device and retry.",
      );
    } finally {
      previewPending.current = false;
      setBusy(false);
    }
  }
  async function switchCamera() {
    const old = camera.current?.getVideoTracks()[0];
    if (!old || switchPending.current) return;
    switchPending.current = true;
    const run = generation.current;
    const original = camera.current;
    const previousFacing = old.getSettings().facingMode || cameraFacing.current;
    const facing = previousFacing === "environment" ? "user" : "environment";
    const previousDevice = old.getSettings().deviceId;
    // Mobile devices often cannot open both cameras at once. Keep audio running.
    old.stop();
    setMessage("Switching camera…");
    const attach = async (media: MediaStream) => {
      if (run !== generation.current || camera.current !== original) {
        media.getTracks().forEach((t) => t.stop());
        return false;
      }
      const track = media.getVideoTracks()[0];
      const sender = pc.current
        ?.getSenders()
        .find((s) => s.track?.kind === "video");
      try {
        if (sender && !portrait.current) await sender.replaceTrack(track);
      } catch (e) {
        media.getTracks().forEach((t) => t.stop());
        throw e;
      }
      if (run !== generation.current || camera.current !== original) {
        media.getTracks().forEach((t) => t.stop());
        return false;
      }
      original!.removeTrack(old);
      original!.addTrack(track);
      track.enabled=cameraEnabled;
      setTorchEnabled(false);
      setTorchSupported(Boolean((track.getCapabilities?.() as MediaTrackCapabilities & {torch?:boolean})?.torch));
      if (preview.current) {
        preview.current.srcObject = original;
        preview.current.play().catch(() => {});
      }
      return true;
    };
    try {
      const media = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { exact: facing },
          width: { ideal: 720 },
          height: { ideal: 1280 },
          aspectRatio: { ideal: 9 / 16 },
        },
        audio: false,
      });
      if (await attach(media)) {
        cameraFacing.current = facing;
        setMessage(
          facing === "environment"
            ? "Back camera selected."
            : "Front camera selected.",
        );
      }
    } catch {
      if (run !== generation.current || camera.current !== original) return;
      try {
        const restored = await navigator.mediaDevices.getUserMedia({
          video: {
            ...(previousDevice
              ? { deviceId: { exact: previousDevice } }
              : { facingMode: { ideal: previousFacing } }),
            width: { ideal: 720 },
            height: { ideal: 1280 },
            aspectRatio: { ideal: 9 / 16 },
          },
          audio: false,
        });
        if (await attach(restored))
          setMessage(
            "Requested camera unavailable. Your previous camera has been restored.",
          );
      } catch {
        if (run === generation.current) {
          await stop();
          setMessage(
            "Camera switch failed and the previous camera could not restart. Broadcast stopped. Preview your camera and retry.",
          );
        }
      }
    } finally {
      switchPending.current = false;
    }
  }
  useEffect(() => {
    if (!active) return;
    let alive = true;
    let refreshing = false;
    const refresh = async () => {
      if (refreshing) return;
      refreshing = true;
      try {
        const r = await fetch("/api/commerce?stream=" + active, {
          signal: AbortSignal.timeout(10000),
        });
        if (!r.ok) throw Error();
        const body = (await r.json()) as any;
        if (alive && broadcast.current === active) {
          if (body.stream?.status === "ended") {
            setEndedBackground(captureEndedBackground());
            setEndSummary({seconds:broadcastStartedAt?Math.max(0,Math.floor((Date.now()-broadcastStartedAt)/1000)):null,viewers:hostPeakViewers??hostViewers,likes:hostLikes,productTaps:null,addToCart:null,comments:null,orders:null,sales:null});
            generation.current++;
            releaseMedia();
            setActive("");
            setPreviewId("");
            setStarting(false);
            setConnectionLabel("Ended");
            void loadEndAnalytics(active);
            setMessage(
              "This broadcast has ended. Camera and microphone stopped.",
            );
            return;
          }
          if (body.stream && (body.stream.verified === 0 || body.stream.verified === 1)) setD((previous:any) => previous?.myStore ? {...previous,myStore:{...previous.myStore,verified:body.stream.verified}} : previous);
          setHostChat((body.chats || []).reverse());
          setHostViewers(body.viewers);
          if(typeof body.viewers==="number")setHostPeakViewers(previous=>Math.max(previous??0,body.viewers));
          if(typeof body.likes === "number")setHostLikes(body.likes);
        }
      } catch {
        if (alive) setMessage("Chat disconnected. Retrying…");
      } finally {
        refreshing = false;
      }
    };
    refresh();
    const timer = setInterval(refresh, 3500);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [active]);
  useEffect(() => {
    const chat = hostChatScrollRef.current;
    if (chat && hostChatStickToBottom.current) chat.scrollTop = chat.scrollHeight;
  }, [hostChat]);
  async function start(id: string, resuming=false) {
    setRetryBroadcast("");
    if(!resuming)reconnectAttempts.current=0;
    if (switchPending.current) {
      setMessage("Wait for the camera switch before going live.");
      return;
    }
    if (broadcast.current && !(resuming && broadcast.current===id && !pc.current)) {
      setMessage("End the current broadcast before starting another.");
      return;
    }
    broadcast.current = id;
    const run = ++generation.current;
    setStarting(true);
    setConnectionLabel("Connecting…");
    setMessage("Requesting camera and microphone…");
    try {
      const b = await request({ action: resuming?"resume":"prepare", id }, "/api/streams");
      if (run !== generation.current) return;
      if (!b) {
        offerBroadcastRetry(id,"Connection preparation failed. Check your network, then retry this broadcast.");
        return;
      }
      const media =
        camera.current ||
        (await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "user",
            width: { ideal: 720 },
            height: { ideal: 1280 },
            aspectRatio: { ideal: 9 / 16 },
          },
          audio: true,
        }));
      if (run !== generation.current) {
        media.getTracks().forEach((t) => t.stop());
        return;
      }
      camera.current = media;
      media.getAudioTracks().forEach(t=>t.enabled=!muted);
      cameraFacing.current =
        media.getVideoTracks()[0]?.getSettings().facingMode || "user";
      if (preview.current) preview.current.srcObject = media;
      setMessage("Connecting broadcast…");
      const connection = new RTCPeerConnection();
      pc.current = connection;
      connectionDeadline.current=setTimeout(() => {
        connectionDeadline.current=null;
        if (
          run === generation.current &&
          !["connected", "closed"].includes(connection.connectionState)
        ) {
          offerBroadcastRetry(id,"Connection timed out. Check your network, then retry this broadcast.");
        }
      }, 30000);
      if (!preview.current)
        throw Error(
          "Camera preview is unavailable. Preview your camera and retry.",
        );
      await preview.current.play();
      if (run !== generation.current) return;
      portrait.current = createPortraitPublisher(preview.current, media);
      const published = portrait.current.stream;
      published.getTracks().forEach((t) =>
        connection.addTransceiver(t, {
          direction: "sendonly",
          streams: [published],
        }),
      );
      connection.onconnectionstatechange = async () => {
        if (run !== generation.current) return;
        if (connection.connectionState === "connected") {
          if(connectionDeadline.current){clearTimeout(connectionDeadline.current);connectionDeadline.current=null;}
          if(reconnectTimer.current){clearTimeout(reconnectTimer.current);reconnectTimer.current=null;}
          reconnectAttempts.current=0;
          if (confirmationPending.current) return;
          confirmationPending.current = true;
          let confirmed = null;
          for (
            let attempt = 0;
            attempt < 15 && run === generation.current;
            attempt++
          ) {
            confirmed = await request(
              { action: "connected", id },
              "/api/streams",
            );
            if (confirmed) break;
            await new Promise((resolve) => setTimeout(resolve, 1000));
          }
          if (run !== generation.current) return;
          if (connection.connectionState !== "connected") {
            confirmationPending.current = false;
            return;
          }
          if (!confirmed) {
            offerBroadcastRetry(id,"The provider could not confirm this connection. Retry when your network is stable.");
            return;
          }
          setPreviewId("");
          setActive(id);
          setBroadcastStartedAt((previous) => previous ?? Date.now());
          setStarting(false);
          confirmationPending.current = false;
          setMessage("Broadcast connected");
          setConnectionLabel("LIVE — provider confirmed");
        }
        if (["disconnected","failed"].includes(connection.connectionState)) {
          setConnectionLabel("Reconnecting…");
          setMessage("Network interrupted. Waiting for the connection to recover…");
          if(reconnectTimer.current)return;
          reconnectTimer.current=setTimeout(()=>{
            reconnectTimer.current=null;
            if(run!==generation.current||connection.connectionState==="connected"||connection.connectionState==="closed")return;
            if(reconnectAttempts.current>=2){offerBroadcastRetry(id,"Automatic recovery could not restore the connection. Check your network and retry this broadcast.");return;}
            reconnectAttempts.current++;
            void recoverBroadcast(id);
          },connection.connectionState==="failed"?1000:15000);
        }
      };
      const offer = await completeIceOffer(connection);
      const r = await fetch(b.publish, {
        method: "POST",
        signal: AbortSignal.timeout(15000),
        headers: { "Content-Type": "application/sdp" },
        body: offer,
      });
      if (!r.ok) throw Error("Provider rejected the connection");
      const loc = r.headers.get("location");
      const endpoint = loc ? new URL(loc, b.publish).href : "";
      if (run !== generation.current) {
        if (endpoint)
          fetch(endpoint, {
            method: "DELETE",
            signal: AbortSignal.timeout(5000),
          }).catch(() => {});
        return;
      }
      session.current = endpoint;
      await connection.setRemoteDescription({
        type: "answer",
        sdp: await r.text(),
      });
    } catch (e: any) {
      if (run !== generation.current) return;
      offerBroadcastRetry(id,e.name==="NotAllowedError"?"Camera permission was denied. Allow camera and microphone access and retry.":e.message||"Connection unavailable. Check your network and retry.");
    }
  }
  useEffect(() => {
    if (!active) return;
    const timer = setInterval(async () => {
      const id = broadcast.current;
      if (!id || pc.current?.connectionState!=="connected") return;
      const run=generation.current;
      const confirmed = await request(
        { action: "connected", id },
        "/api/streams",
      );
      if(run!==generation.current || pc.current?.connectionState!=="connected")return;
      if (confirmed && broadcast.current === id)
        setConnectionLabel("LIVE — provider confirmed");
      if (!confirmed && broadcast.current === id) {
        setConnectionLabel("Connection check unavailable — retrying…");
      }
    }, 20000);
    return () => clearInterval(timer);
  }, [active]);
  useEffect(() => {
    if (preview.current && camera.current && preview.current.srcObject !== camera.current) {
      preview.current.srcObject = camera.current;
      preview.current.play().catch(() => {});
    }
  });
  useEffect(() => {
    const media = camera.current;
    if (!media) return;
    let handled = false;
    const interrupted = () => {
      if (handled || camera.current !== media) return;
      handled = true;
      void stop().then(() => setMessage("Camera or microphone access was interrupted. Media stopped; reopen your camera to continue."));
    };
    const tracks = media.getTracks();
    tracks.forEach(track => track.addEventListener("ended", interrupted));
    return () => tracks.forEach(track => track.removeEventListener("ended", interrupted));
  });
  const hostId = active || previewId || (starting ? broadcast.current : "");
  const hostStream = d?.myStreams?.find((s: any) => s.id === hostId);
  let hostFeatured:string[]=[];try{hostFeatured=JSON.parse(hostStream?.featured||"[]");}catch{}
  const hostSelectedProduct=hostId===cameraOnlyId?studioProduct:(hostStream?.product||"");
  const selectableHostProducts=[...(d?.myProducts||[]),...(hostId===cameraOnlyId?[]:(d?.affiliateProducts||[]))];
  const hostEligibleProducts=selectableHostProducts.filter((product:any)=>product.active&&product.stock>0);
  // Keep one explicit selection so a newly rendered product is never silently pinned.
  const sellerPinSelection=pinCandidate||hostSelectedProduct||(!active?studioProduct:"")||"";
  const hostPinned = selectableHostProducts.find(
    (p: any) => p.id === hostSelectedProduct,
  );
  const hostFeedbackIsError=/could not|unable|failed|error|unavailable|not live|not configured|choose|connection|network|retry|permission|suspended|expired|in-stock/i.test(message);
  const hostPinnedDeal=sellerDeals.find((deal:any)=>deal.id===pinnedDealId&&deal.stream===active&&["active","scheduled"].includes(deal.status)&&Date.parse(deal.starts_at)<=studioClock&&Date.parse(deal.ends_at)>studioClock&&Number(deal.sold_quantity)<Number(deal.max_quantity));
  const hostPinnedAuction=sellerAuctions.find((auction:any)=>auction.id===pinnedAuctionId&&auction.stream===active&&["active","scheduled"].includes(auction.status));
  const studioCountdown=(value:string)=>{const seconds=Math.max(0,Math.ceil((Date.parse(value)-studioClock)/1000));return `${Math.floor(seconds/60).toString().padStart(2,"0")}:${(seconds%60).toString().padStart(2,"0")}`;};
  async function changePinnedProduct(productId: string) {
    if (pinLock.current) return;
    if (productId && !selectableHostProducts.some((p:any)=>p.id===productId && p.active && p.stock>0)) {setMessage("Choose an available, in-stock product.");return;}
    if (hostId===cameraOnlyId) {setStudioProduct(productId);setMessage(productId?"Product ready for your livestream.":"Product unpinned.");return;}
    pinLock.current=true;
    const previousProduct=hostSelectedProduct;
    setD((previous:any)=>({...previous,myStreams:previous.myStreams.map((item:any)=>item.id===hostId?{...item,product:productId}:item)}));
    try {
      const result=await request({action:"pin",id:hostId,product:productId,previousProduct});
      if (!result) setD((previous:any)=>({...previous,myStreams:previous.myStreams.map((item:any)=>item.id===hostId?{...item,product:previousProduct}:item)}));
      else setMessage(productId?"Product pinned. Viewer updates are syncing.":"Product unpinned. Viewer updates are syncing.");
    } finally {pinLock.current=false;}
  }
  async function submitStudioMutation(endpoint:string,payload:any,success:string) {
    if(studioMutationLock.current)return;
    studioMutationLock.current=true;
    setBusy(true);
    try {
      const response=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
      const result=await response.json();
      if(!response.ok)throw new Error(result.error||"Unable to complete this action.");
      let refreshFailed=false;
      if(endpoint==="/api/live-deals"||endpoint==="/api/live-auctions"||endpoint==="/api/product-bundles"){
        try { await refreshHostCommerce(); }
        catch { refreshFailed=true; }
      }
      if(endpoint==="/api/live-auctions"){
        if(result.auction)setSellerAuctions((current:any[])=>[result.auction,...current.filter(item=>item.id!==result.auction.id)]);
        if(typeof result.pinnedAuction==="string")setPinnedAuctionId(result.pinnedAuction);
        else if(result.pinned&&result.id)setPinnedAuctionId(result.id);
      }
      const auctionMessage=endpoint==="/api/live-auctions"&&payload.action==="create"?(result.queued?"Auction added to the live queue. Buyers can see it as up next.":"Auction started and pinned to this broadcast."):endpoint==="/api/live-auctions"&&result.cancelled?"Scheduled auction cancelled. The next lot has moved up in the queue.":success;
      setMessage(refreshFailed?`${auctionMessage} The server saved it; live details will retry shortly.`:auctionMessage);
      setHostSheet(endpoint==="/api/live-auctions"?"auction":endpoint==="/api/live-deals"?"deal":endpoint==="/api/product-bundles"?"bundle":"more");
    } catch(error) { setMessage(error instanceof Error?error.message:"Unable to complete this action."); }
    finally { studioMutationLock.current=false;setBusy(false); }
  }
  const hostOpen = Boolean(hostId || starting);
  useEffect(() => {
    if (!hostOpen) return;
    setFullscreenAvailable(Boolean(document.fullscreenEnabled));
    const stage = document.querySelector<HTMLElement>(".host-live-stage");
    const dock = stage?.querySelector<HTMLElement>(".host-live-lower");
    const fit = () => {
      if (dock) stage?.style.setProperty("--host-dock-height", `${dock.getBoundingClientRect().height + 8}px`);
      if (stage)
        stage.dataset.compact = String(
          (window.visualViewport?.height || window.innerHeight) < 520,
        );
      stage?.style.setProperty(
        "--host-viewport",
        `${window.visualViewport?.height || window.innerHeight}px`,
      );
      stage?.style.setProperty(
        "--host-viewport-top",
        `${window.visualViewport?.offsetTop || 0}px`,
      );
    };
    fit();
    const dockObserver = typeof ResizeObserver !== "undefined" ? new ResizeObserver(fit) : null;
    if (dock) dockObserver?.observe(dock);
    window.visualViewport?.addEventListener("resize", fit);
    window.visualViewport?.addEventListener("scroll", fit);
    window.addEventListener("resize", fit);
    const previousOverflow = document.body.style.overflow;
    const previousFocus = document.activeElement as HTMLElement | null;
    document.body.style.overflow = "hidden";
    const rotate = () => {
      fit();
      const track = camera.current?.getVideoTracks()[0];
      track
        ?.applyConstraints({
          width: { ideal: 720 },
          height: { ideal: 1280 },
          aspectRatio: { ideal: 9 / 16 },
        })
        .catch(() => {});
    };
    window.addEventListener("orientationchange", rotate);
    stage?.querySelector<HTMLElement>("button")?.focus({ preventScroll: true });
    return () => {
      dockObserver?.disconnect();
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus({ preventScroll: true });
      window.removeEventListener("orientationchange", rotate);
      window.visualViewport?.removeEventListener("resize", fit);
      window.visualViewport?.removeEventListener("scroll", fit);
      window.removeEventListener("resize", fit);
    };
  }, [hostOpen]);
  useEffect(()=>{
    if(connectionLabel!=="Ended")return;
    const dialog=document.querySelector<HTMLElement>(".seller-session-ended");
    if(!dialog)return;
    const previous=document.activeElement instanceof HTMLElement?document.activeElement:null;
    const previousOverflow=document.body.style.overflow;
    document.body.style.overflow="hidden";
    const controls=()=>Array.from(dialog.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),[tabindex]:not([tabindex="-1"])')).filter(el=>el.getClientRects().length>0);
    controls()[0]?.focus({preventScroll:true});
    const trap=(event:KeyboardEvent)=>{
      if(event.key!=="Tab")return;
      const items=controls(),first=items[0],last=items.at(-1);
      if(!first){event.preventDefault();dialog.focus();}
      else if(event.shiftKey&&(document.activeElement===first||!dialog.contains(document.activeElement))){event.preventDefault();last?.focus();}
      else if(!event.shiftKey&&(document.activeElement===last||!dialog.contains(document.activeElement))){event.preventDefault();first.focus();}
    };
    document.addEventListener("keydown",trap);
    return()=>{document.removeEventListener("keydown",trap);document.body.style.overflow=previousOverflow;previous?.focus({preventScroll:true});};
  },[connectionLabel]);
  const field = (
    name: string,
    label: string,
    type = "text",
    value: any = "",
    required = true,
  ) => (
    <label>
      {label}
      <input name={name} type={type} defaultValue={value} required={required} />
    </label>
  );
  const stateSelect = (name = "state", value = "") => (
    <label>
      State
      <select name={name} defaultValue={value} required>
        <option value="">Choose state</option>
        {states.map((x) => (
          <option key={x}>{x}</option>
        ))}
      </select>
    </label>
  );
  const studioMode = new URLSearchParams(returnPath.split("?")[1] || "").get("studio") === "1";
  const profileArea = routeReady && !studioMode && ["Account", "Saved products", "Notification preferences", "Support"].includes(tab);
  return (
    <>
    <main
      id="main-content"
      tabIndex={-1}
      className={
        "workspace-page workspace-dashboard" +
        (hostOpen ? " host-immersive" : "") + (studioMode && hostOpen ? " studio-page" : "") + (profileArea ? " profile-subpage profile-workspace-page" : "")
      }
    >
      {connectionLabel==="Ended"&&endSummary&&<section className="seller-session-ended" role="dialog" aria-modal="true" aria-labelledby="seller-session-ended-title">
        {endedBackground&&<img className="seller-session-ended-backdrop" src={endedBackground} alt=""/>}
        <div className="seller-session-ended-panel">
          <header className="seller-session-ended-heading"><span><CheckCircle2 size={29} aria-hidden="true"/></span><h1 id="seller-session-ended-title">Your live has ended</h1><p>Great job! Thanks for going live.</p></header>
          <section className="seller-session-summary" aria-labelledby="seller-session-summary-title"><h2 id="seller-session-summary-title">Session summary</h2><p>Here’s a quick overview of your live session.</p>
            <dl className="seller-session-key-stats"><div><dt><Eye size={16} aria-hidden="true"/>Peak viewers</dt><dd>{endSummary.viewers===null?"Not recorded":endSummary.viewers}</dd></div><div><dt><ShoppingBag size={16} aria-hidden="true"/>Confirmed orders</dt><dd>{endSummary.orders===null?"Not recorded":endSummary.orders}</dd></div><div><dt><Heart size={16} aria-hidden="true"/>Likes</dt><dd>{endSummary.likes===null?"Not recorded":endSummary.likes}</dd></div><div><dt><MessageCircle size={16} aria-hidden="true"/>Comments</dt><dd>{endSummary.comments===null?"Not recorded":endSummary.comments}</dd></div></dl>
            <details className="seller-session-more-stats"><summary>More session stats</summary><dl><div><dt>Duration</dt><dd>{endSummary.seconds===null?"Not recorded":endSummary.seconds<60?`${endSummary.seconds} sec`:`${Math.floor(endSummary.seconds/60)} min`}</dd></div><div><dt>Product taps</dt><dd>{endSummary.productTaps===null?"Not recorded":endSummary.productTaps}</dd></div><div><dt>Add to cart</dt><dd>{endSummary.addToCart===null?"Not recorded":endSummary.addToCart}</dd></div><div><dt>Verified sales</dt><dd>{endSummary.sales===null?"Not recorded":`₦${endSummary.sales.toLocaleString("en-NG")}`}</dd></div></dl></details>
            <p className="seller-session-summary-note">Tap counts include recorded product clicks from viewers who allow optional analytics.</p>
            <footer className="seller-session-actions">
              <button type="button" className="seller-session-analytics" onClick={()=>{setTab("Studio");void previewCamera(cameraOnlyId);}}><Radio size={19} aria-hidden="true"/>Start another live</button>
              <a className="seller-session-back" href="/?browse=1#live">Done</a>
            </footer>
          </section>
        </div>
      </section>}
      {routeReady && !studioMode && !profileArea && <BrandLogo tagline />}
      {profileArea ? <><a className="profile-back-link" href="/account">← Back to Profile</a><header className="profile-page-heading workspace-profile-heading"><p className="profile-page-kicker">YOUR PROFILE</p><h1>{({Account:"Edit Profile","Saved products":"Saved items","Notification preferences":"Notification preferences",Support:"Help & support"} as Record<string,string>)[tab]}</h1></header></> : routeReady && !studioMode && <header className="workspace-heading">
        <h1>
          {["Delivery", "Verification", "Studio", "Sales"].includes(tab)
            ? "Seller Centre"
            : "My account"}
        </h1>
        <a className="secondary-button" href="/seller">
          Seller Centre
        </a>
        <a className="secondary-button" href="/account">
          My account
        </a>
      </header>}
      <p role="status">{message}</p>
      {!d ? (
        message ? (
          <div role="alert">
            <p>Your workspace could not load.</p>
            <button onClick={() => load().catch((e) => setMessage(e.message))}>
              Retry
            </button>
          </div>
        ) : (
          <p role="status">Loading…</p>
        )
      ) : !d.user ? (
        <>
          <p>Sign in to access your account.</p>
          <a href={"/sign-in?returnTo=" + encodeURIComponent(returnPath)}>
            Sign in or register
          </a>
        </>
      ) : (
        <>
          {!studioMode && ["Delivery", "Verification", "Sales"].includes(tab) &&
            !hostOpen && <SellerNavigation active={tab} />}
          {!profileArea && !studioMode && <div className="workspace-tabs">
            {[
              "Account",
              "Saved products",
              "Addresses",
              "Notification preferences",
              "Delivery",
              "Verification",
              "Support",
              "Sales",
            ]
              .filter((t) =>
                ["Delivery", "Verification", "Sales"].includes(
                  tab,
                )
                  ? [
                      "Delivery",
                      "Verification",
                      "Sales",
                    ].includes(t)
                  : ![
                      "Delivery",
                      "Verification",
                      "Sales",
                    ].includes(t),
              )
              .map((t) => (
                <button
                  key={t}
                  aria-pressed={tab === t}
                  onClick={() => {
                    if (hostOpen) {
                      if (
                        (active || starting) &&
                        !confirm("End the broadcast and leave this screen?")
                      )
                        return;
                      void stop();
                    }
                    setTab(t);
                    const url = new URL(window.location.href);
                    url.searchParams.set("tab", t);
                    window.history.replaceState(
                      null,
                      "",
                      url.pathname + url.search,
                    );
                  }}
                >
                  {({ Delivery: "Shipping", Sales: "Payments & refunds", Account: "Profile settings" } as Record<string, string>)[t] || t}
                </button>
              ))}
            {!profileArea && d.user.admin && <a href="/admin">Admin back office</a>}
          </div>}
          <section className="workspace-content" aria-label={tab}>
            {tab === "Account" ? (
              <>
                <ProfileEditor user={d.user} onSaved={load} />
                <a href="/forgot-password">Reset your email password</a>
                <section className="profile-addresses" aria-labelledby="profile-addresses-title">
                  <div className="profile-addresses-heading"><div><p className="profile-page-kicker">DELIVERY DETAILS</p><h2 id="profile-addresses-title">Saved addresses</h2></div><span>{d.addresses.length} saved</span></div>
                  {d.addresses.length ? <div className="profile-address-list">{d.addresses.map((a: any) => (
                    <article className="profile-address-card" key={a.id}>
                      <div><strong>{a.name}</strong><p>{a.line}{a.area ? `, ${a.area}` : ""}{a.state ? `, ${a.state}` : ""}</p>{a.phone && <small>{a.phone}</small>}</div>
                      <button className="profile-address-delete" type="button" onClick={() => request({ action: "address", id: a.id, remove: true })}>Remove</button>
                    </article>
                  ))}</div> : <p className="profile-address-empty">Add an address to make delivery checkout quicker.</p>}
                  <form className="profile-address-form" onSubmit={(e) => form(e, "address")}>
                    <h3>Add a delivery address</h3>
                    {field("name", "Recipient")}
                    {field("phone", "Phone", "tel")}
                    {field("line", "Street address")}
                    {stateSelect()}
                    {field("area", "City or area")}
                    <button className="primary" disabled={busy}>Save address</button>
                  </form>
                </section>
              </>
            ) : tab === "Saved products" ? (
              <>
                <div className="saved-products-toolbar">
                  <span>{d.favourites.length} {d.favourites.length === 1 ? "item" : "items"} saved</span>
              <Link href="/?browse=1#market">Continue shopping</Link>
                </div>
                {d.favourites.length ? (
                  <div className="saved-products-grid">
                    {d.favourites.map((f: any) => {
                      const p = f.name ? f : d.products.find((item: any) => item.id === f.product);
                      const available = Boolean(p?.active);
                      return (
                        <article className="saved-product-card" key={f.product}>
                          <a className="saved-product-media" href={available ? "/product/" + f.product : "/?browse=1#market"} aria-label={available ? `View ${p.name}` : "Browse products"}>
                            {p?.image ? <ImageAsset src={p.image} width="420" height="344" alt={p.name || "Saved product"} /> : <span className="saved-product-unavailable">Image unavailable</span>}
                          </a>
                          <div className="saved-product-copy">
                            <small>{p?.category || "Saved item"}</small>
                            {available ? <a className="saved-product-title" href={"/product/" + f.product}>{p.name}</a> : <strong className="saved-product-title">{p?.name || "Product no longer available"}</strong>}
                            {p?.seller && <span className="saved-product-seller">{p.seller}</span>}
                            {available ? <strong className="saved-product-price">₦{Number(p.price || 0).toLocaleString("en-NG")}</strong> : <span className="saved-product-unavailable">This listing is currently unavailable</span>}
                          </div>
                          <div className="saved-product-actions">
                            {available && <a className="saved-product-open" href={"/product/" + f.product}>View item</a>}
                            <button className="saved-product-remove" type="button" disabled={busy} onClick={() => request({action:"favourite",product:f.product,saved:false})}>Remove saved</button>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                ) : (
                  <div className="saved-products-empty">
                    <h2>Your saved items will appear here</h2>
                    <p>Tap the heart on a product to keep it handy while you browse.</p>
                    <Link href="/?browse=1#market">Explore products</Link>
                  </div>
                )}
              </>
            ) : tab === "Notification preferences" ? (
              <>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const f = new FormData(e.currentTarget);
                    request({
                      action: "preferences",
                      order_updates: f.has("order_updates"),
                      live_alerts: f.has("live_alerts"),
                      marketing: f.has("marketing"),
                    });
                  }}
                >
                  {[
                    ["order_updates", "Order updates"],
                    ["live_alerts", "Followed seller live alerts"],
                    ["marketing", "Marketing emails"],
                  ].map(([v, l]) => (
                    <label key={v}>
                      <input
                        type="checkbox"
                        name={v}
                        defaultChecked={Boolean(
                          d.preferences?.[v] ?? v !== "marketing",
                        )}
                      />
                      {l}
                    </label>
                  ))}
                  <button disabled={busy}>Save preferences</button>
                </form>
              </>
            ) : !d.myStore &&
              ["Delivery", "Verification", "Studio", "Sales"].includes(
                tab,
              ) ? (
              <p>
                Create a storefront in <a href="/seller">Seller Centre</a>{" "}
                first.
              </p>
            ) : tab === "Delivery" ? (
              <>
                <h2>Set up shipping</h2>
                <p>Set your price, confirm the states you serve, then save. You can update these settings anytime.</p>
                <div className="shipping-price-card"><span>Current shipping fee per order</span><strong>₦{Number(d.myStore.delivery_fee).toLocaleString("en-NG")}</strong><p>Charged once per order. Changes apply to new orders.</p></div>
                <p>
                  Publish only your business city or area, not a private
                  residential street address. Save at least one delivery state
                  and a fee before customers can order. Empty coverage blocks
                  delivery checkout; it does not offer an arranged-delivery
                  option.
                </p>
                <div className="design-alert">
                  <strong>Delivery coverage</strong>
                  <p>
                    One fixed shipping fee per order applies across your
                    selected states. Destination-specific rates and collection
                    checkout are not currently supported.
                  </p>
                </div>
                {!JSON.parse(d.myStore.coverage || "[]").length && (
                  <p className="notice" role="status">
                    Delivery checkout is currently unavailable for your store.
                    Your ₦{Number(d.myStore.delivery_fee).toLocaleString("en-NG")} shipping fee is saved. Select the delivery states you actually serve below, then save shipping settings to enable checkout.
                  </p>
                )}
                <form className="shipping-setup-form" onSubmit={(e) => form(e, "delivery-settings")}>
                  <h3>1. Shipping price</h3>
                  <label>Shipping fee per order (₦)<input name="delivery_fee" type="number" min="0" max="100000000" step="1" required defaultValue={d.myStore.delivery_fee ?? 100} /></label>
                  <p>The starting fee is ₦100. Enter another amount anytime, or 0 for free shipping.</p>
                  <h3>2. Business location</h3>
                  {stateSelect("state", d.myStore.state)}
                  {field(
                    "area",
                    "Business city or area",
                    "text",
                    d.myStore.area,
                  )}
                  <p>
                    Optional coordinates must describe a public business
                    location. Leave blank for a home business.
                  </p>
                  {field(
                    "latitude",
                    "Public business latitude",
                    "text",
                    d.myStore.latitude ?? "",
                    false,
                  )}
                  {field(
                    "longitude",
                    "Public business longitude",
                    "text",
                    d.myStore.longitude ?? "",
                    false,
                  )}
                  <fieldset>
                    <legend>3. Delivery coverage</legend>
                    <p>
                      Select only states where you can fulfil orders for the
                      fixed fee below. Your business state is not selected
                      automatically.
                    </p>
                    <div className="delivery-state-options">
                      {states.map((state) => (
                        <label key={state}>
                          <input
                            type="checkbox"
                            name="coverage"
                            value={state}
                            defaultChecked={JSON.parse(
                              d.myStore.coverage || "[]",
                            ).includes(state)}
                          />
                          {state}
                        </label>
                      ))}
                    </div>
                  </fieldset>
                  <h3>4. Delivery time & returns</h3>
                  {field(
                    "delivery_days",
                    "Estimated delivery time",
                    "text",
                    d.myStore.delivery_days,
                  )}
                  <label>
                    Returns information
                    <textarea
                      name="return_policy"
                      required
                      defaultValue={d.myStore.return_policy}
                    />
                  </label>
                  <p>
                    This fixed shipping fee is added once to each order. Enter 0
                    for free shipping.
                  </p>
                  <button disabled={busy}>Save shipping settings</button>
                </form>
              </>
            ) : tab === "Verification" ? (
              <>
                <h2>Seller verification</h2>
                <p>Status: {d.myVerification?.status || "Not submitted"}</p>
                <p>{d.myVerification?.note}</p>
                <p>
                  Evidence is accessible only to you and authorised admins.
                  Verification is manual.
                </p>
<p>Complete individual or registered-business verification, review document requests and submit appeals from the verification centre.</p><Link className="primary" href="/seller/finance?tab=Activation">Open verification centre</Link>
              </>
            ) : tab === "Studio" ? (
              <>
                {new URLSearchParams(returnPath.split("?")[1]||"").get("studio")==="1" && !d.sellerAccess?.canSell && <section className="design-card" role="status"><h2>Prepare your seller access</h2><p>{d.sellerAccess?.verification==="suspended"?"Selling is suspended. Review the status and next steps in your verification centre.":d.sellerAccess?.verification!=="verified"?"Verification is required to broadcast.":"Your selling access is inactive or expired."}</p><Link className="primary" href={d.sellerAccess?.verification!=="verified"?"/seller/finance?tab=Activation":"/seller/finance?tab=Subscription"}> {d.sellerAccess?.verification!=="verified"?"Complete verification":"Manage selling access"}</Link><Link className="secondary-button" href="/?browse=1#live">Explore Lives</Link></section>}
                <h2>Live Studio</h2>
                <p role="status">{connectionLabel}</p>
                {hostOpen && (
                  <section
                    className="host-live-stage"
                    data-studio-state={active ? (connectionLabel.startsWith("LIVE")?"live":"reconnecting") : starting?"connecting":"preview"}
                    role="dialog"
                    aria-modal="true"
                    aria-label="Seller broadcast"
                    onKeyDown={(e) => {
                      if (e.key === "Tab") {
                        const controls = Array.from(
                          e.currentTarget.querySelectorAll<HTMLElement>(
                            "button:not(:disabled), input:not(:disabled), select:not(:disabled), summary, a[href]",
                          ),
                        ).filter((el) => el.getClientRects().length > 0);
                        const first = controls[0],
                          last = controls.at(-1);
                        if (e.shiftKey && document.activeElement === first) {
                          e.preventDefault();
                          last?.focus();
                        } else if (
                          !e.shiftKey &&
                          document.activeElement === last
                        ) {
                          e.preventDefault();
                          first?.focus();
                        }
                      }
                      if (e.key === "Escape") {
                        e.preventDefault();
                        if (hostSheet) setHostSheet("");
                        else if (active || starting) setHostSheet("leave");
                        else stop();
                      }
                    }}
                  >
                    <div className="host-video-frame">
                      {!camera.current&&<div className="studio-camera-empty"><span><VideoOff size={34}/></span><h2>{busy?"Opening your camera…":"Your camera is private"}</h2><p>{busy?"Allow camera and microphone access when your browser asks.":"Allow camera access to see your preview. Your broadcast has not started."}</p></div>}
                      <video
                        ref={preview}
                        autoPlay
                        muted
                        playsInline
                        className="host-preview"
                        data-facing={cameraFacing.current}
                        aria-label="Your camera preview"
                      />
                    </div>
                    <div className="host-live-top" inert={Boolean(hostSheet)}>
                      <div className="host-seller-identity">
                        <StoreLogo name={d.myStore?.name || "Seller"} src={d.myStore?.logo} size={44} className="host-seller-avatar" />
                        <div>
                          <strong className="seller-identity"><span className="seller-name-text">{d.myStore?.name}</span></strong>
                          <span title={hostStream?.title}>
                            {hostStream?.title}
                          </span>
                        </div>
                      </div>
                      {!active && !starting && <button aria-label="Close broadcast" onClick={() => stop()}><X /></button>}
                    </div>
                    <div
                      className="host-live-status"
                      inert={Boolean(hostSheet)}
                    >
                      <span className="live-status">
                        {active && connectionLabel.startsWith("LIVE")
                          ? "LIVE"
                          : active
                            ? "CHECKING"
                            : starting
                              ? "CONNECTING"
                              : "PREVIEW"}
                      </span>
                      {active && hostViewers !== null && (
                        <span className="host-viewer-count" title="Current viewers on this broadcast">
                          <span aria-hidden="true" className="live-viewer-dot" />
                          {hostViewers.toLocaleString()} {hostViewers === 1 ? "viewer" : "viewers"} watching
                        </span>
                      )}
                      {active && <ElapsedBroadcast startedAt={broadcastStartedAt} />}
                    </div>
                    {!active&&<div className="host-connection-meta" inert={Boolean(hostSheet)}><span role="status">{connectionLabel}</span></div>}
                    <div className="host-live-tools" aria-label="Host actions" inert={Boolean(hostSheet)}>
                      <LiveAction label={muted ? "Muted" : "Mic"} icon={muted ? <MicOff /> : <Mic />} aria-label={muted ? "Unmute microphone" : "Mute microphone"} aria-pressed={muted} disabled={!camera.current?.getAudioTracks().length} title={!camera.current?.getAudioTracks().length ? "Allow microphone access to use this control" : muted ? "Microphone is muted" : "Microphone is on"} onClick={() => { const next = !muted; camera.current?.getAudioTracks().forEach((t) => (t.enabled = !next)); setMuted(next); }} />
                      <LiveAction label="Flip" icon={<SwitchCamera />} aria-label="Switch camera" disabled={starting || !camera.current?.getVideoTracks().length} title={starting ? "Wait for the broadcast to connect" : "Switch between front and back cameras, where supported"} onClick={switchCamera} />
                      <LiveAction label="More" icon={<MoreHorizontal />} aria-label="More host options" aria-haspopup="dialog" onClick={() => setHostSheet("more")} />
                    </div>
                    <div className="host-live-lower" inert={Boolean(hostSheet)}>
                      {!active&&!starting&&camera.current&&<section className="studio-preflight" aria-label="Livestream setup">
                        <div className="studio-preflight-heading"><span><Radio size={15} aria-hidden="true"/> LIVE SHOPPING</span><span className="studio-public-audience"><Eye size={13} aria-hidden="true"/> Public</span></div>
                        <label className="studio-title-field">Live title <small>{studioTitle.length}/100</small>
                          <input aria-label="Livestream title" value={studioTitle} onChange={e=>setStudioTitle(e.target.value.slice(0,100))} maxLength={100} placeholder={`${d.myStore?.name || "Your store"} · Live shopping`} />
                        </label>
                        <label className="studio-title-field">Featured product
                          <select aria-label="Featured product for livestream" value={studioProduct} onChange={e=>setStudioProduct(e.target.value)}>
                            <option value="">Choose later or pin during the live</option>
                            {selectableHostProducts.filter((product:any)=>product.active&&product.stock>0).map((product:any)=><option key={product.id} value={product.id}>{product.name}</option>)}
                          </select>
                        </label>
                        {studioProduct&&(()=>{const product=selectableHostProducts.find((item:any)=>item.id===studioProduct);return product?<div className="studio-featured-product-preview"><ImageAsset src={product.image||"/image-unavailable.svg"} alt=""/><span><small>FEATURED PRODUCT</small><strong>{product.name}</strong><b>{new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(product.price)}</b></span><button type="button" aria-label="Remove featured product" onClick={()=>setStudioProduct("")}>×</button></div>:null;})()}
                        <div className="studio-preflight-checks" aria-label="Device checks">
                          <span><span className="studio-ready-dot"/>Camera {camera.current?.getVideoTracks().some(t=>t.readyState==="live"&&t.enabled)?"ready":camera.current?.getVideoTracks().some(t=>t.readyState==="live")?"turn on":"check access"}</span>
                          <span><span className="studio-ready-dot"/>Microphone {camera.current?.getAudioTracks().some(t=>t.readyState==="live")?(muted?"ready · muted":"ready"):"check access"}</span>
                          <span><span className="studio-ready-dot"/>{d.services?.stream?"Provider configured":"Stream setup needed"}</span>
                        </div>
                      </section>}
                      {(!active||hostFeedbackIsError)&&<p className="host-live-feedback" role="status">{message}</p>}
                      {message.startsWith("Chat disconnected") && (
                        <p role="status" className="host-chat-notice">
                          {message}
                        </p>
                      )}
                      <div
                        ref={hostChatScrollRef}
                        className="host-live-chat"
                        role="log"
                        aria-label={`Live comments, ${hostChat.length} total`}
                        aria-live="polite"
                        tabIndex={0}
                        onScroll={(event) => {
                          const chat = event.currentTarget;
                          hostChatStickToBottom.current = chat.scrollHeight - chat.scrollTop - chat.clientHeight < 32;
                        }}
                      >
                        {hostChat.slice(-30).map((c: any) => (
                          <div className="host-live-comment" key={c.id}>
                            <span className="host-live-comment-avatar" aria-hidden="true">{(c.name||"?").replace(/^@/,"").slice(0,1).toUpperCase()}</span>
                            <span className="host-live-comment-copy"><strong>{c.name}</strong><span>{c.message}</span></span>
                          </div>
                        ))}
                      </div>
                      {active&&(hostPinnedDeal||hostPinnedAuction)&&<div className="host-live-feature-badges" aria-label="Pinned live shopping features">
                        {hostPinnedDeal&&<span className="seller-live-promo-badge seller-live-flash-badge"><Zap size={12} aria-hidden="true"/>FLASH · {hostPinnedDeal.status==="active"?studioCountdown(hostPinnedDeal.ends_at):"STARTS "+studioCountdown(hostPinnedDeal.starts_at)}</span>}
                        {hostPinnedAuction&&<span className="seller-live-promo-badge seller-live-auction-badge"><Radio size={12} aria-hidden="true"/>AUCTION · {studioCountdown(hostPinnedAuction.status==="active"?hostPinnedAuction.ends_at:hostPinnedAuction.starts_at)}</span>}
                      </div>}
                      {hostPinned && !active && <section className={"studio-pin-shell seller-premium-pin"+(pinCollapsed?" is-collapsed":"")} aria-label="Pinned product">
                        <button className="seller-pin-heading studio-pin-toggle" aria-label={pinCollapsed?"Expand pinned product":"Collapse pinned product"} aria-expanded={!pinCollapsed} onClick={()=>setPinCollapsed(v=>!v)}>
                          <Pin size={16}/>{pinCollapsed?<><ImageAsset src={hostPinned.image} alt=""/><span className="pin-collapsed-name">{hostPinned.name}</span><b>{new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(hostPinned.price)}</b></>:<span>Pinned Product</span>}<span aria-hidden="true">{pinCollapsed?"⌄":"⌃"}</span>
                        </button>
                        {!pinCollapsed && <div className="host-live-pin"><ImageAsset src={hostPinned.image} alt={hostPinned.name}/><span><strong title={hostPinned.name}>{hostPinned.name}</strong><b>{new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(hostPinned.price)}</b><small>{hostPinned.stock>0?`In stock: ${hostPinned.stock}`:"Sold out"}</small><a href="/?browse=1&sellerTab=Products#seller" target="_blank" rel="noopener noreferrer">Manage product ↗</a></span><button className="seller-unpin" disabled={busy || pinLock.current} onClick={()=>changePinnedProduct("")}><Pin size={16}/>Unpin</button></div>}
                      </section>}
                      {active && (
                        <form
                          className="host-live-reply"
                          onSubmit={async (e) => {
                            e.preventDefault();
                            if (
                              await request({
                                action: "chat",
                                stream: active,
                                message: hostMessage,
                              })
                            )
                              setHostMessage("");
                          }}
                        >
                          <input
                            aria-label="Reply to viewers"
                            placeholder="Message buyers…"
                            value={hostMessage}
                            onChange={(e) => setHostMessage(e.target.value)}
                            required
                            maxLength={400}
                          />
                          <button aria-label="Send reply" disabled={busy}>
                            <Send />
                          </button>
                        </form>
                      )}
                      {active && <nav className="seller-live-product-queue" aria-label="Live products">
                        {hostEligibleProducts.map((product:any) => {
                          const isPinned=product.id===hostSelectedProduct;
                          const isSelected=product.id===sellerPinSelection;
                          return <button type="button" key={product.id} aria-pressed={isSelected} data-pinned={isPinned} onClick={()=>setPinCandidate(product.id)} title={`${product.name} · ${new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(product.price)}`}>
                            <span className="seller-live-queue-image">{product.image?<ImageAsset src={product.image} alt=""/>:<ShoppingBag size={20}/>}</span>
                            {(isPinned||hostPinnedDeal?.product===product.id||hostPinnedAuction?.product===product.id)&&<span className="seller-live-pinned-label"><Pin size={12}/>{isPinned?"Pinned":"Featured"}</span>}
                            <span className="seller-live-product-badges">
                              {hostPinnedDeal?.product===product.id&&<span className="seller-live-promo-badge seller-live-flash-badge"><Zap size={10} aria-hidden="true"/>FLASH</span>}
                              {hostPinnedAuction?.product===product.id&&<span className="seller-live-promo-badge seller-live-auction-badge"><Radio size={10} aria-hidden="true"/>AUCTION</span>}
                            </span>
                            <strong>{product.name}</strong>
                            <b>{new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(product.price)}</b>
                          </button>;
                        })}
                      </nav>}
                      <div className="host-live-actions">
                        {active ? <>
                          <button type="button" className="seller-products-action" aria-label="Manage broadcast products" aria-haspopup="dialog" onClick={()=>setHostSheet("products")}><ShoppingBag size={19}/>Products <span>{hostEligibleProducts.length}</span></button>
                          <button type="button" className="seller-pin-item-action" disabled={busy||!sellerPinSelection} onClick={()=>{const next=sellerPinSelection===hostSelectedProduct?"":sellerPinSelection;setPinCandidate(next);void changePinnedProduct(next);}}><Pin size={18}/>{sellerPinSelection===hostSelectedProduct?"Unpin Item":"Pin Item"}</button>
                          <button type="button" className="seller-end-live-action" onClick={()=>setHostSheet("leave")}><VideoOff size={18}/>End Live</button>
                        </> : !starting ? (
                          <>
                            {(busy || !camera.current || !cameraEnabled) && (
                              <p className="host-start-reason" role="status">
                                {busy
                                  ? "Please wait for the current camera or connection action to finish."
                                  : !cameraEnabled ? "Turn your camera on to go live." : message || "Allow camera and microphone access to open your preview."}
                              </p>
                            )}
                            <button
                              className="primary"
                              disabled={busy || (!retryBroadcast && (!camera.current || !cameraEnabled))}
                              onClick={() => retryBroadcast ? start(retryBroadcast,true) : previewId===cameraOnlyId ? startStudio() : start(previewId)}
                            >
                              <Radio size={20} aria-hidden="true"/>{retryBroadcast?"Retry broadcast":"Go Live"}
                            </button>
                            {!camera.current && <button onClick={()=>previewCamera(previewId||cameraOnlyId)}>Retry camera permission</button>}
                            <button onClick={() => retryBroadcast ? stop(retryBroadcast) : stop()}>
                              {retryBroadcast?"End session":"Cancel preview"}
                            </button>
                          </>
                        ) : null}
                      </div>
                    </div>
                    {hostSheet && (
                      <LiveSheet
                        className={hostSheet === "more" ? "studio-tools-sheet" : ["products","deal","auction","bundle"].includes(hostSheet) ? "studio-pin-picker" : ""}
                        title={
                          ["products","deal","auction","bundle"].includes(hostSheet)
                            ? "Pin to live"
                            : hostSheet === "moderation"
                              ? "Moderate comments"
                              : hostSheet === "leave"
                                ? "End livestream?"
                                : hostSheet === "settings" ? "Camera & live settings" : hostSheet === "stats" ? "Live statistics" : hostSheet === "deal" ? "Create Live Deal" : hostSheet === "auction" ? "Create Auction" : hostSheet === "bundle" ? "Create Product Bundle" : "Live Studio"
                        }
                        onClose={() => setHostSheet("")}
                      >
                        {["products","deal","auction","bundle"].includes(hostSheet) && <nav className="studio-pin-tabs" role="tablist" aria-label="Pin live shopping content">
                          {([ ["products","Products"], ["deal","Live deal"], ["auction","Auction"], ["bundle","Bundle"] ] as const).map(([key,label])=><button key={key} type="button" role="tab" aria-selected={hostSheet===key} onClick={()=>setHostSheet(key)}>{label}</button>)}
                        </nav>}
                        {hostSheet !== "more" && hostSheet !== "leave" && message && (
                          <p role="status" className="live-sheet-notice">
                            {message}
                          </p>
                        )}
                        {hostSheet === "stats" ? <dl className="seller-live-stats"><div><dt>Current viewers</dt><dd>{hostViewers===null?"Unavailable":hostViewers}</dd></div><div><dt>Peak viewers</dt><dd>{liveStats?.peakViewers??"Unavailable"}</dd></div><div><dt>Likes</dt><dd>{hostLikes===null?"Unavailable":hostLikes}</dd></div><div><dt>Comments</dt><dd>{liveStats?.comments??"Unavailable"}</dd></div><div><dt>Product taps</dt><dd>{liveStats?.productTaps??"Unavailable"}</dd></div><div><dt>Add to cart</dt><dd>{liveStats?.addToCart??"Unavailable"}</dd></div><div><dt>Confirmed orders</dt><dd>{liveStats?.confirmedOrders??"Unavailable"}</dd></div><div><dt>Verified sales</dt><dd>{typeof liveStats?.verifiedSales==="number"?`₦${liveStats.verifiedSales.toLocaleString("en-NG")}`:"Unavailable"}</dd></div></dl> : hostSheet === "deal" ? (
                          <><div className="live-option-list">{sellerDeals.filter((x:any)=>x.stream===active&&["active","scheduled"].includes(x.status)).map((x:any)=><article key={x.id} className="live-auction-card"><strong>{x.product_name}</strong><p>{x.status} · ₦{Number(x.promo_price).toLocaleString("en-NG")} · {x.sold_quantity}/{x.max_quantity} sold</p><div className="studio-feature-actions"><button type="button" className="secondary-button" disabled={busy} aria-pressed={pinnedDealId===x.id} onClick={()=>void submitStudioMutation("/api/live-deals",{action:"pin",stream:active,id:pinnedDealId===x.id?"":x.id},pinnedDealId===x.id?"Live deal unpinned from the livestream.":"Live deal pinned with its countdown.")}>{pinnedDealId===x.id?"Unpin live deal":"Pin to livestream"}</button>{x.status==="active"&&<button type="button" className="secondary-button" disabled={busy} onClick={()=>void submitStudioMutation("/api/live-deals",{action:"end",id:x.id},"Live deal ended.")}>End Deal</button>}{x.status==="scheduled"&&<button type="button" className="secondary-button" disabled={busy} onClick={()=>void submitStudioMutation("/api/live-deals",{action:"cancel",id:x.id},"Scheduled deal cancelled.")}>Cancel Deal</button>}</div></article>)}</div><form className="live-option-list studio-action-form" onSubmit={e=>{e.preventDefault();const chosen=selectableHostProducts.find((p:any)=>p.id===dealProduct);if(!active){setMessage("Start the broadcast before creating a live deal.");return;}if(!chosen){setMessage("Choose an eligible product.");return;}const start=new Date(),end=new Date(start.getTime()+Number(dealMinutes)*60000);void submitStudioMutation("/api/live-deals",{action:"save",product:dealProduct,stream:active,promoPrice:Number(dealPrice),maxQuantity:Number(dealQuantity),startsAt:start.toISOString(),endsAt:end.toISOString()},"Live deal started. Viewer updates are syncing.");}}>
                            <p>Set a limited offer for an in-stock product. Price and inventory are checked by the server.</p>
                            <label>Product<select required value={dealProduct} onChange={e=>setDealProduct(e.target.value)}><option value="">Choose product</option>{(d?.myProducts||[]).filter((p:any)=>p.active&&p.stock>0&&!JSON.parse(p.variants||"[]").length).map((p:any)=><option key={p.id} value={p.id}>{p.name} · ₦{Number(p.price).toLocaleString("en-NG")}</option>)}</select></label>
                            <div className="studio-form-row"><label>Deal price (₦)<input required type="number" min="1" step="1" value={dealPrice} onChange={e=>setDealPrice(e.target.value)}/></label><label>Quantity<input required type="number" min="1" max="10000" step="1" value={dealQuantity} onChange={e=>setDealQuantity(e.target.value)}/></label></div>
                            <label>Duration<select value={dealMinutes} onChange={e=>setDealMinutes(e.target.value)}><option value="5">5 minutes</option><option value="10">10 minutes</option><option value="15">15 minutes</option><option value="30">30 minutes</option><option value="60">60 minutes</option></select></label>
                            <button disabled={busy||!active||!dealProduct}>Start Deal</button>
                          </form></>
                        ) : hostSheet === "auction" ? (
                          <><div className="live-option-list">{sellerAuctions.filter((x:any)=>x.stream===active&&["active","scheduled"].includes(x.status)).map((x:any)=><article key={x.id} className="live-auction-card"><strong>{x.product_name}</strong><p>{x.status} · {x.bid_count||0} bids · ₦{Number(x.highest_bid||x.start_price).toLocaleString("en-NG")}</p><div className="studio-feature-actions"><button type="button" className="secondary-button" disabled={busy} aria-pressed={pinnedAuctionId===x.id} onClick={()=>void submitStudioMutation("/api/live-auctions",{action:"pin",stream:active,auction:pinnedAuctionId===x.id?"":x.id},pinnedAuctionId===x.id?"Auction unpinned from the livestream.":"Auction pinned with its live countdown.")}>{pinnedAuctionId===x.id?"Unpin auction":"Pin to livestream"}</button><button type="button" className="secondary-button" disabled={busy} onClick={()=>{const scheduled=x.status==="scheduled";if(confirm(scheduled?"Cancel this queued auction? Later lots will move forward.":"End this auction now? Any winning order remains unpaid."))void submitStudioMutation("/api/live-auctions",{action:"end",auction:x.id},scheduled?"Scheduled auction cancelled.":"Auction ended and result recorded.")}}>{x.status==="scheduled"?"Cancel queued auction":"End Auction"}</button></div></article>)}</div><form className="live-option-list studio-action-form" onSubmit={e=>{e.preventDefault();const chosen=d?.myProducts?.find((p:any)=>p.id===auctionProduct);if(!active){setMessage("Start the broadcast before creating an auction.");return;}if(!chosen){setMessage("Choose an eligible product.");return;}if(!Number.isSafeInteger(Number(auctionStart))||Number(auctionStart)<1||!Number.isSafeInteger(Number(auctionIncrement))||Number(auctionIncrement)<1){setMessage("Enter a valid starting bid and bid increment.");return;}void submitStudioMutation("/api/live-auctions",{action:"create",product:auctionProduct,stream:active,startPrice:Number(auctionStart),increment:Number(auctionIncrement),reservePrice:"",durationMinutes:Number(auctionMinutes)},"Auction started and pinned to this broadcast.");}}>
                            <p>Choose an available product. The first auction starts right away; additional auctions are queued to run one after another.</p>
                            <label>Product<select required value={auctionProduct} onChange={e=>setAuctionProduct(e.target.value)}><option value="">Choose product</option>{(d?.myProducts||[]).filter((p:any)=>p.active&&p.stock>0&&!JSON.parse(p.variants||"[]").length).map((p:any)=><option key={p.id} value={p.id}>{p.name} · {p.stock} in stock</option>)}</select></label>
                            <div className="studio-form-row"><label>Starting bid (₦)<input required type="number" min="1" step="1" value={auctionStart} onChange={e=>setAuctionStart(e.target.value)}/></label><label>Bid increment (₦)<input required type="number" min="1" step="1" value={auctionIncrement} onChange={e=>setAuctionIncrement(e.target.value)}/></label></div>
                            <label>Duration<select value={auctionMinutes} onChange={e=>setAuctionMinutes(e.target.value)}><option value="1">1 minute</option><option value="3">3 minutes</option><option value="5">5 minutes</option><option value="10">10 minutes</option><option value="15">15 minutes</option></select></label>
                            <button disabled={busy||!active||!auctionProduct}>Start Auction</button>
                          </form></>
                        ) : hostSheet === "bundle" ? (
                          <><div className="live-option-list">{sellerBundles.filter((x:any)=>x.stream===active&&x.active&&x.product_active&&Number(x.available_quantity)>0).map((x:any)=><article key={x.id} className="live-auction-card"><strong>{x.title}</strong><p>₦{Number(x.price).toLocaleString("en-NG")} · {Number(x.available_quantity)} available</p><div className="studio-feature-actions"><button type="button" className="secondary-button" disabled={busy} onClick={()=>void submitStudioMutation("/api/product-bundles",{action:"pin",stream:active,id:pinnedBundleId===x.id?"":x.id,durationMinutes:Number(bundleFeatureMinutes)},pinnedBundleId===x.id?"Bundle unpinned from the livestream.":"Bundle pinned. Viewer countdown started.")}>{pinnedBundleId===x.id?"Unpin bundle":"Pin to livestream"}</button></div></article>)}</div><form className="live-option-list studio-action-form studio-bundle-form" onSubmit={e=>{e.preventDefault();const chosen=(d?.myProducts||[]).filter((p:any)=>bundleProductIds.includes(p.id));if(!active){setMessage("Start the broadcast before publishing a live bundle.");return;}if(chosen.length<2||!bundleRequestId||!bundleProductId){setMessage("Select at least two eligible products.");return;}const total=chosen.reduce((sum:number,p:any)=>sum+Number(p.price)*(bundleQuantities[p.id]||1),0),price=Number(bundlePrice);if(!bundleTitle.trim()){setMessage("Add a name for this bundle.");return;}if(!Number.isSafeInteger(price)||price<1||price>=total){setMessage(`Bundle price must be below the selected items total of ₦${total.toLocaleString("en-NG")}.`);return;}void submitStudioMutation("/api/product-bundles",{action:"save",id:bundleRequestId,productId:bundleProductId,stream:active,title:bundleTitle.trim(),description:"Livestream product bundle",price,items:chosen.map((p:any)=>({product:p.id,quantity:bundleQuantities[p.id]||1})),publish:true,image:chosen.find((p:any)=>p.image)?.image||`${window.location.origin}/image-unavailable.svg`,featureDurationMinutes:Number(bundleFeatureMinutes)},"Bundle published and pinned to this livestream.");}}>
                            <div className="studio-bundle-intro"><strong>Build a live bundle</strong><p>Choose 2–10 products. We’ll reserve component stock when an order is placed.</p></div>
                            <label>Bundle name<input required maxLength={100} placeholder="e.g. Weekend essentials" value={bundleTitle} onChange={e=>setBundleTitle(e.target.value)}/></label>
                            <div className="bundle-choice-list">{(d?.myProducts||[]).filter((p:any)=>p.active&&p.stock>0&&p.category!=="Bundles"&&!JSON.parse(p.variants||"[]").length).map((p:any)=><label key={p.id}><input type="checkbox" checked={bundleProductIds.includes(p.id)} onChange={e=>{if(e.target.checked){setBundleProductIds(old=>old.length<10?[...old,p.id]:old);setBundleQuantities(old=>({...old,[p.id]:old[p.id]||1}));}else setBundleProductIds(old=>old.filter(id=>id!==p.id));}}/>{p.image?<ImageAsset src={p.image} alt=""/>:<ImageAsset src="/image-unavailable.svg" alt=""/>}<span>{p.name}<small>₦{Number(p.price).toLocaleString("en-NG")} · {p.stock} in stock</small></span>{bundleProductIds.includes(p.id)&&<input aria-label={`Quantity of ${p.name}`} type="number" min="1" max={Math.min(20,Number(p.stock))} value={bundleQuantities[p.id]||1} onChange={e=>setBundleQuantities(old=>({...old,[p.id]:Math.max(1,Math.min(20,Number(p.stock),Number(e.target.value)||1))}))}/>}</label>)}</div>
                            {(()=>{const chosen=(d?.myProducts||[]).filter((p:any)=>bundleProductIds.includes(p.id)),total=chosen.reduce((sum:number,p:any)=>sum+Number(p.price)*(bundleQuantities[p.id]||1),0),price=Number(bundlePrice)||0;return <div className="studio-bundle-summary"><span>Items total <strong>₦{total.toLocaleString("en-NG")}</strong></span><span>Your price <strong>₦{price.toLocaleString("en-NG")}</strong></span><span className={price>0&&price<total?"is-saving":"is-invalid"}>{price>0&&price<total?`Buyer saves ₦${(total-price).toLocaleString("en-NG")}`:"Set a price below the items total"}</span></div>;})()}
                            <label>Bundle price (₦)<input required type="number" min="1" step="1" value={bundlePrice} onChange={e=>setBundlePrice(e.target.value)}/></label>
                            <label>Pin countdown<select value={bundleFeatureMinutes} onChange={e=>setBundleFeatureMinutes(e.target.value)}><option value="5">5 minutes</option><option value="10">10 minutes</option><option value="15">15 minutes</option><option value="30">30 minutes</option><option value="60">60 minutes</option></select></label>
                            <button disabled={busy||!active||bundleProductIds.length<2||!bundlePrice}>Publish Bundle</button>
                          </form></>
                        ) : hostSheet === "products" ? (
                          <div className="live-option-list product-picker">
                            <label className="product-search">Search products<input type="search" value={productSearch} onChange={e=>setProductSearch(e.target.value)} placeholder="Search your catalogue" /></label>
                            {selectableHostProducts.filter((p:any)=>p.active&&p.stock>0&&`${p.name} ${p.seller||""}`.toLowerCase().includes(productSearch.trim().toLowerCase())).length ? (
                              <div className="host-product-list" role="listbox" aria-label="Available products">
                                {selectableHostProducts.filter((p:any)=>p.active&&p.stock>0&&`${p.name} ${p.seller||""}`.toLowerCase().includes(productSearch.trim().toLowerCase())).map((p:any)=><button type="button" role="option" aria-selected={pinCandidate===p.id} className={`host-product-option${pinCandidate===p.id?" is-selected":""}`} key={p.id} onClick={()=>setPinCandidate(p.id)}>
                                  {p.image?<ImageAsset src={p.image} alt=""/>:<span className="host-product-placeholder"><ShoppingBag size={20}/></span>}
                                  <span className="host-product-details"><strong>{p.name}</strong><b>{new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(p.price)}</b><small>{p.stock} in stock{Array.isArray(p.variants)&&p.variants.length?` · ${p.variants.length} variants`:""}{p.seller?` · ${p.seller}`:""}</small></span>
                                  <span className="host-product-choice" aria-hidden="true">{pinCandidate===p.id?"✓":""}</span>
                                </button>)}
                              </div>
                            ) : <p>{productSearch?"No matching in-stock products.":"No eligible in-stock products are available to pin."}</p>}
                            <div className="product-picker-actions"><button type="button" className="secondary-button" onClick={()=>setHostSheet("")}>Cancel</button><button type="button" disabled={busy||!pinCandidate||pinCandidate===hostSelectedProduct} onClick={async()=>{await changePinnedProduct(pinCandidate);if(!pinLock.current)setHostSheet("");}}>Pin Product</button></div>
                            {hostSelectedProduct&&<button type="button" className="unpin-product-action" disabled={busy} onClick={async()=>{await changePinnedProduct("");setHostSheet("");}}>Unpin current product</button>}
                          </div>
                        ) : hostSheet === "settings" ? <div className="live-option-list"><label>Optional livestream title<input value={studioTitle} maxLength={160} onChange={e=>setStudioTitle(e.target.value)} disabled={Boolean(active||starting)} placeholder="Showcase your products…"/></label><p>Front camera opens by default. Use Flip to change cameras. Permission settings are managed in your browser.</p><p>Camera: {camera.current?.getVideoTracks()[0]?.readyState||"unavailable"} · Microphone: {camera.current?.getAudioTracks()[0]?.readyState||"unavailable"}</p></div> : hostSheet === "moderation" ? (
                          <div className="live-moderation-list">
                            {hostChat.length ? (
                              hostChat.slice(-30).map((c: any) => (
                                <article key={c.id}>
                                  <p>
                                    <strong>{c.name}</strong> {c.message}
                                  </p>
                                  <div>
                                    <button
                                      disabled={busy}
                                      onClick={async () => {
                                        if (
                                          await request({
                                            action: "moderate-chat",
                                            id: c.id,
                                            moderationAction: "hide",
                                          })
                                        )
                                          setHostChat((previous) =>
                                            previous.filter(
                                              (item) => item.id !== c.id,
                                            ),
                                          );
                                      }}
                                    >
                                      Hide message
                                    </button>
                                    <button
                                      disabled={busy}
                                      onClick={async () => {
                                        if (await request({action:"moderate-chat",id:c.id,moderationAction:"mute"})) setMessage("Viewer muted for 10 minutes in this broadcast.");
                                      }}
                                    >
                                      Mute viewer
                                    </button>
                                    <button disabled={busy} onClick={async()=>{if(confirm("Block this viewer from this broadcast?")){if(await request({action:"moderate-chat",id:c.id,moderationAction:"block"}))setHostChat(previous=>previous.filter(item=>item.id!==c.id));}}}>Block viewer</button>
                                    <button disabled={busy} onClick={async()=>{const reason=prompt("Why are you reporting this comment?")||"";if(reason.trim().length>=5)await request({action:"moderate-chat",id:c.id,moderationAction:"report",reason});}}>Report comment</button>
                                  </div>
                                </article>
                              ))
                            ) : (
                              <p>No comments to moderate yet.</p>
                            )}
                          </div>
                        ) : hostSheet === "leave" ? (
                          <div className="live-option-list">
                            <p>Your livestream will stop and viewers will be disconnected.</p>
                            <button aria-label="Keep Streaming" className="secondary-button" onClick={() => setHostSheet("")}>Keep Streaming</button>
                            <button className="host-end" disabled={busy || endingLock.current} onClick={() => stop()}>End Live</button>
                          </div>
                        ) : hostSheet === "more" ? (
                          <div className="studio-tools-content">
                            <p className="studio-tools-intro">Broadcast controls and shopping tools.</p>
                            <section className="studio-tool-group" aria-labelledby="studio-camera-heading">
                              <h3 id="studio-camera-heading">Broadcast</h3>
                              <div className="studio-tool-grid">
                                {camera.current?.getVideoTracks().length>0&&<button aria-label={cameraEnabled?"Turn camera off":"Turn camera on"} className="studio-tool-card" onClick={()=>{const next=!cameraEnabled;camera.current?.getVideoTracks().forEach(t=>t.enabled=next);setCameraEnabled(next);}}><span className="studio-tool-icon">{cameraEnabled?<Video size={19}/>:<VideoOff size={19}/>}</span><span><strong>{cameraEnabled?"Turn camera off":"Turn camera on"}</strong><small>Camera visibility</small></span></button>}
                                {torchSupported&&<button aria-label={torchEnabled?"Turn flash off":"Turn flash on"} className="studio-tool-card" onClick={toggleTorch} aria-pressed={torchEnabled}><span className="studio-tool-icon"><Zap size={19}/></span><span><strong>{torchEnabled?"Turn flash off":"Turn flash on"}</strong><small>Improve lighting</small></span></button>}
                                <button aria-label="Stream settings" className="studio-tool-card" onClick={()=>setHostSheet("settings")}><span className="studio-tool-icon"><Settings size={19}/></span><span><strong>Stream settings</strong><small>Title and camera</small></span></button>
                                {fullscreenAvailable&&<button aria-label="Enter fullscreen" className="studio-tool-card" onClick={(e)=>{const stage=e.currentTarget.closest(".host-live-stage") as HTMLElement;stage.requestFullscreen().then(()=>setHostSheet("")).catch(()=>setMessage("Fullscreen is unavailable. Continue broadcasting here."));}}><span className="studio-tool-icon"><Maximize size={19}/></span><span><strong>Fullscreen</strong><small>Expand the studio</small></span></button>}
                                <button aria-label="Connection status" className="studio-tool-card" onClick={()=>setMessage(connectionLabel)}><span className="studio-tool-icon"><Radio size={19}/></span><span><strong>Connection status</strong><small>{connectionLabel}</small></span></button>
                                <button aria-label="Technical help" className="studio-tool-card" onClick={()=>{setMessage("For broadcast help, use the support link in your account menu.");}}><span className="studio-tool-icon"><ShieldCheck size={19}/></span><span><strong>Technical help</strong><small>Connection and camera</small></span></button>
                              </div>
                            </section>
                            <section className="studio-tool-group" aria-labelledby="studio-live-heading">
                              <h3 id="studio-live-heading">Live tools</h3>
                              <div className="studio-tool-grid">
                                <button aria-label="Live stats" className="studio-tool-card" onClick={()=>setHostSheet("stats")}><span className="studio-tool-icon"><BarChart3 size={19}/></span><span><strong>Live stats</strong><small>{hostViewers===null?"View audience activity":`${hostViewers} watching now`}</small></span></button>
                                <button aria-label="Moderate comments" className="studio-tool-card" onClick={()=>setHostSheet("moderation")}><span className="studio-tool-icon"><ShieldCheck size={19}/></span><span><strong>Moderate comments</strong><small>Review viewer messages</small></span></button>
                                <button aria-label="Share broadcast" className="studio-tool-card" disabled={!active} onClick={async()=>{const url=new URL("/",window.location.origin);url.searchParams.set("stream",active);try{if(navigator.share)await navigator.share({title:hostStream?.title||"Cash N Carry live",url:url.href});else{await navigator.clipboard.writeText(url.href);setMessage("Broadcast link copied.");}}catch(e){if((e as Error).name!=="AbortError")setMessage("Unable to share. Please try again.");}}}><span className="studio-tool-icon"><Share2 size={19}/></span><span><strong>Share broadcast</strong><small>Invite viewers to watch</small></span></button>
                              </div>
                            </section>
                            <section className="studio-tool-group" aria-labelledby="studio-selling-heading">
                              <h3 id="studio-selling-heading">Shopping</h3>
                              <div className="studio-tool-grid">
                                <button aria-label="Live deals" className="studio-tool-card" onClick={()=>setHostSheet("deal")}><span className="studio-tool-icon"><Zap size={19}/></span><span><strong>Live deals</strong><small>Create an offer</small></span></button>
                                <button aria-label="Auctions" className="studio-tool-card" onClick={()=>setHostSheet("auction")}><span className="studio-tool-icon"><Radio size={19}/></span><span><strong>Auctions</strong><small>Run an auction</small></span></button>
                                <button aria-label="Product bundles" className="studio-tool-card" onClick={()=>{setBundleProductIds([]);setBundleQuantities({});setBundleTitle("");setBundlePrice("");setBundleRequestId(crypto.randomUUID());setBundleProductId(crypto.randomUUID());setHostSheet("bundle");}}><span className="studio-tool-icon"><ShoppingBag size={19}/></span><span><strong>Product bundles</strong><small>Publish a bundle</small></span></button>
                              </div>
                            </section>
                            <section className="studio-tool-group" aria-labelledby="studio-more-heading"><h3 id="studio-more-heading">More</h3><div className="studio-tool-grid"><p>Use the close control in the broadcast header to end the live safely.</p></div></section>
                            {message&&<p role="status" className="studio-tools-status">{message}</p>}
                          </div>
                        ) : (
                          <div className="live-option-list">
                            {!active && !starting && <Link href="/?browse=1#live" onClick={()=>releaseMedia()}>Explore Lives</Link>}
                            {camera.current?.getVideoTracks().length>0&&<button onClick={()=>{const next=!cameraEnabled;camera.current?.getVideoTracks().forEach(t=>t.enabled=next);setCameraEnabled(next);}}><Video size={18}/>{cameraEnabled?"Turn camera off":"Turn camera on"}</button>}
                            {torchSupported&&<button onClick={toggleTorch} aria-pressed={torchEnabled}><Zap size={18}/>{torchEnabled?"Turn flash off":"Turn flash on"}</button>}
                            <button onClick={()=>setHostSheet("settings")}><Settings size={18}/>Camera settings and optional title</button>
                            <button onClick={()=>setHostSheet("stats")}><BarChart3 size={18}/>Live stats</button>
                            <button onClick={async()=>{const url=new URL("/",window.location.origin);url.searchParams.set("stream",active);try{if(navigator.share)await navigator.share({title:hostStream?.title||"Cash N Carry live",url:url.href});else{await navigator.clipboard.writeText(url.href);setMessage("Broadcast link copied.");}}catch(e){if((e as Error).name!=="AbortError")setMessage("Unable to share. Please try again.");}}} disabled={!active}><Share2 size={18}/>Share broadcast</button>
                            <button onClick={() => setHostSheet("moderation")}>
                              Moderate comments
                            </button>
                            {fullscreenAvailable && (
                              <button
                                onClick={(e) => {
                                  const stage = e.currentTarget.closest(
                                    ".host-live-stage",
                                  ) as HTMLElement;
                                  stage
                                    .requestFullscreen()
                                    .then(() => setHostSheet(""))
                                    .catch(() =>
                                      setMessage(
                                        "Fullscreen is unavailable. Continue broadcasting here.",
                                      ),
                                    );
                                }}
                              >
                                <Maximize />
                                Enter fullscreen
                              </button>
                            )}
                            <p role="status">{message || connectionLabel}</p>

                          </div>
                        )}
                      </LiveSheet>
                    )}
                  </section>
                )}
              </>
            ) : tab === "Sales" ? (
              <>
                <h2>Orders and shipment updates</h2>
                {d.sellerOrders.map((o: any) => (
                  <form key={o.id} onSubmit={(e) => form(e, "tracking")}>
                    <strong>
                      {o.id} · {o.status}
                    </strong>
                    <p>Payment: {o.payment_status || o.payment}{o.payment === "flutterwave" && o.payment_mode !== "live" ? " · Sandbox test" : ""}</p>
                    {o.payment === "flutterwave" && o.payment_status !== "paid" && <p role="status">Awaiting verified payment. Ask the customer to check My orders and complete payment before confirming. Do not ask them to pay again if the result is uncertain.</p>}
                    {["placed", "confirmed", "shipped"].includes(o.status) && <button type="button" disabled={busy || (o.payment === "flutterwave" && o.payment_status !== "paid")} onClick={() => request({action: "status", id: o.id, status: ({placed: "confirmed", confirmed: "shipped", shipped: "delivered"} as Record<string,string>)[o.status]})}>{({placed: "Confirm order", confirmed: "Mark shipped", shipped: "Mark delivered"} as Record<string,string>)[o.status]}</button>}
                    <a href={"/order/" + o.id}>View order details</a>
                    <input type="hidden" name="id" value={o.id} />
                    {field(
                      "tracking",
                      "Carrier / tracking reference",
                      "text",
                      o.tracking,
                      false,
                    )}
                    <button disabled={busy}>Save shipment details</button>
                  </form>
                ))}
                <h2>Verified payment records</h2>
                <p>
                  These records are payments to orders, not seller payouts.
                  Payout settlement is not configured.
                </p>
                {d.financials.length ? (
                  d.financials.map((p: any) => (
                    <article key={p.id}>
                      {p.mode.toUpperCase()} · ₦{p.amount.toLocaleString()} ·{" "}
                      {p.status}
                      <p>Order {p.order_id}</p>
                    </article>
                  ))
                ) : (
                  <p>No online payments recorded.</p>
                )}
              </>
            ) : (
              <>
                <h2>Support and reports</h2>
                <p>Track an issue, request a refund review or contact the team about an order.</p>
                <div className="support-form-grid">
                <form className="support-card" onSubmit={(e) => form(e, "refund-request")}>
                  <span className="support-kicker">PAYMENTS &amp; RETURNS</span><h3>Request a refund review</h3>
                  <p>Approval does not mean money has been refunded. We will show the provider-confirmed status.</p>
                  {field("id", "Paid order ID", "text", supportOrder)}
                  <label>Reason (at least 10 characters)<input name="reason" required minLength={10} maxLength={1000} /></label>
                  <button disabled={busy}>Request refund review</button>
                </form>
                <form className="support-card" onSubmit={(e) => form(e, "report")}>
                  <span className="support-kicker">ORDER &amp; MARKETPLACE HELP</span><h3>Open a support case</h3><p>Choose what happened and provide the item or order reference.</p>
                  <label>
                    Type
                    <select name="target_type" defaultValue={supportOrder ? "order" : "product"}>
                      {["product", "store", "stream", "order", "return"].map(
                        (t) => (
                          <option key={t}>{t}</option>
                        ),
                      )}
                    </select>
                  </label>
                  {field("target", "Item or order ID", "text", supportOrder)}
                  {field("reason", "Reason")}
                  <label>
                    Describe the problem
                    <textarea name="details" minLength={10} required />
                  </label>
                  <button disabled={busy}>Submit case</button>
                </form>
                </div><h3>Your cases</h3>
                {!d.myReports.length && <p className="support-empty">No cases yet. Your requests and responses will appear here.</p>}
                {d.myReports.map((r: any) => (
                  <article className="support-case" key={r.id}>
                    <strong>{r.reason}</strong>
                    <p>
                      {r.status} · {r.resolution || "Awaiting review"}
                    </p>
                  </article>
                ))}
              </>
            )}
          </section>
        </>
      )}
    </main>
    {profileArea && <CustomerNavigation active="Profile" />}
    </>
  );
}
