import { brand } from "./brand";
import Link from "next/link";

export default function BrandLogo({ tagline = false, compact = false, className = "", surface = "light" }: { tagline?: boolean; compact?: boolean; className?: string; surface?: "light" | "dark" }) {
  return (
    <Link href="/" className={`brand-logo${compact ? " brand-logo--compact" : ""}${surface === "dark" ? " brand-logo--dark-surface" : ""}${className ? ` ${className}` : ""}`} aria-label="Cash N Carry home">
      <picture>
        {compact && <source media="(max-width: 374px)" srcSet={brand.symbol} />}
        {compact && <source media="(max-width: 560px)" type="image/webp" srcSet={brand.compactLogo} />}
        <source type="image/webp" srcSet={surface === "dark" ? brand.logoDarkSurface : brand.logo} />
        <img src={brand.logoFallback} width={brand.logoWidth} height={brand.logoHeight} alt="Cash N Carry" decoding="async" />
      </picture>
      {tagline && <span className="brand-logo-tagline">{brand.tagline}</span>}
    </Link>
  );
}
