"use client";
import { preserveCartForSignIn } from "./cart-resume";
import { useState } from "react";
import Link from "next/link";
import { Heart, Minus, Plus, Ruler, ShoppingCart } from "lucide-react";
import { trackAnalyticsEvent } from "./analytics";
import { readableButtonText } from "./storefront-button-color";

type Variant = { name: string; price: number; stock: number };
export default function ProductPurchase({
  product,
  initiallySaved = false,
  signedIn = false,
  buyNowColor = "#164B35",
}: {
  product: { id: string; store: string; price: number; stock: number; variants: string | null };
  initiallySaved?: boolean;
  signedIn?: boolean;
  buyNowColor?: string;
}) {
  let parsedVariants: Variant[] = [];
  try { parsedVariants = JSON.parse(product.variants || "[]"); } catch { parsedVariants = []; }
  const variants = Array.isArray(parsedVariants) ? parsedVariants.filter((v) => v && typeof v.name === "string") : [];
  const [variant, setVariant] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [saved, setSaved] = useState(initiallySaved);
  const [added, setAdded] = useState(false);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);
  const choice = variants.find((v) => v.name === variant);
  const stock = variants.length ? Number(choice?.stock || 0) : Number(product.stock || 0);
  const price = variants.length ? Number(choice?.price || 0) : Number(product.price || 0);
  const maxQuantity = Math.max(0, Math.min(stock, 99));
  const validQuantity = Number.isInteger(quantity) && quantity >= 1 && quantity <= maxQuantity;

  async function request(action: "cart" | "favourite" | "buy-now") {
    if (busy || stock < 1 || !validQuantity) return;
    if (action === "buy-now") {
      if (!signedIn) {
        preserveCartForSignIn(product.id, variant, quantity, "/product/" + product.id, "buy-now");
        return;
      }
      setBusy(true);
      const params = new URLSearchParams({ buyNow: product.id, variant, quantity: String(quantity) });
      trackAnalyticsEvent("buy_now", product.store, { product: product.id });
      trackAnalyticsEvent("checkout_start", product.store, { product: product.id });
      window.location.assign("/?" + params.toString());
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      const r = await fetch("/api/commerce", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(action === "cart"
          ? { action, product: product.id, variant, quantity }
          : { action: "favourite", product: product.id, saved: !saved }),
        signal: AbortSignal.timeout(15000),
      });
      const result = await r.json() as { error?: string };
      if (r.status === 401) {
        if (action === "cart") preserveCartForSignIn(product.id, variant, quantity, "/product/" + product.id);
        else window.location.assign("/sign-in?returnTo=" + encodeURIComponent("/product/" + product.id));
        return;
      }
      if (!r.ok) throw Error(result.error || "Unable to update this item.");
      if (action === "cart") {
        setAdded(true);
        trackAnalyticsEvent("add_to_cart", product.store, { product: product.id });
        setMessage("Added to your cart.");
      } else {
        setSaved(!saved);
        setMessage(saved ? "Removed from your saved items." : "Added to your saved items.");
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Please check your connection and retry.");
    } finally {
      setBusy(false);
    }
  }

  const buttonColor = /^#[0-9a-f]{6}$/i.test(buyNowColor) ? buyNowColor : "#164B35";
  const buyButton = <button type="button" className="primary" style={{ backgroundColor: buttonColor, borderColor: buttonColor, color: readableButtonText(buttonColor) }} disabled={busy || !validQuantity} onClick={() => void request("buy-now")}>{busy ? "Please wait…" : "Buy now"}</button>;
  const cartButton = <button type="button" className="secondary-button" aria-label={busy ? "Adding to cart" : added ? "Add another item to cart" : "Add to cart"} title={busy ? "Adding to cart" : added ? "Add another item to cart" : "Add to cart"} disabled={busy || !validQuantity} onClick={() => void request("cart")}><ShoppingCart size={18} aria-hidden="true"/></button>;
  return <div className="product-purchase" id="product-purchase">
    <div className="purchase-price"><strong>₦{price.toLocaleString("en-NG")}</strong><span className={stock > 0 ? "stock-available" : "stock-unavailable"}>{stock > 0 ? `${stock} available` : "Out of stock"}</span></div>
    {variants.length > 0 && <fieldset className="product-variant-choices"><legend>Select size or option</legend><div>{variants.map((item) => <button type="button" key={item.name} aria-pressed={variant === item.name} disabled={!item.stock || busy} onClick={() => { setVariant(item.name); setQuantity(1); setAdded(false); setMessage(""); }}>{item.name}</button>)}</div><small>Price and availability update when you select an option.</small></fieldset>}
    {variants.some((v) => /size|\b\d{1,2}(?:\.\d)?\b/i.test(v.name)) && <button type="button" className="size-guide-trigger" onClick={() => setSizeGuideOpen(true)}><Ruler size={16}/>Size guide</button>}
    <div className="product-quantity-control"><span>Quantity</span><div><button type="button" aria-label="Decrease quantity" disabled={busy || quantity <= 1} onClick={() => setQuantity((value) => Math.max(1, value - 1))}><Minus size={16}/></button><output aria-live="polite">{quantity}</output><button type="button" aria-label="Increase quantity" disabled={busy || !maxQuantity || quantity >= maxQuantity} onClick={() => setQuantity((value) => Math.min(maxQuantity, value + 1))}><Plus size={16}/></button></div><small>{stock > 0 ? `${stock} available` : "Currently unavailable"}</small></div>
    {!validQuantity && stock > 0 && <p role="alert" className="product-purchase-error">Choose a quantity available in stock.</p>}
    <p className="product-purchase-message" role="status" aria-live="polite">{message}</p>
    <div className="purchase-actions product-purchase-desktop-actions">{cartButton}{buyButton}<button type="button" className="product-wishlist-button" aria-label={saved ? "Remove from wishlist" : "Add to wishlist"} aria-pressed={saved} disabled={busy} onClick={() => void request("favourite")}><Heart size={20}/><span>{saved ? "Saved" : "Wishlist"}</span></button><Link className="product-open-cart" href="/?open=cart">View cart</Link></div>
    <div className="product-purchase-mobile-actions"><button type="button" className="product-wishlist-button" aria-label={saved ? "Remove from wishlist" : "Add to wishlist"} aria-pressed={saved} disabled={busy} onClick={() => void request("favourite")}><Heart size={20}/></button>{cartButton}{buyButton}</div>
    {sizeGuideOpen && <div className="size-guide-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSizeGuideOpen(false); }}><section className="size-guide-dialog" role="dialog" aria-modal="true" aria-labelledby="size-guide-title"><button type="button" className="size-guide-close" aria-label="Close size guide" onClick={() => setSizeGuideOpen(false)}>×</button><h2 id="size-guide-title">Size guide</h2><p>The seller has not provided a measurement chart for this item. Available options are shown below; contact the seller if you need help choosing.</p><ul>{variants.map((v) => <li key={v.name}>{v.name}{v.stock < 1 ? " · unavailable" : ""}</li>)}</ul><Link href={`/messages?${new URLSearchParams({ store: product.store, product: product.id })}`}>Ask the seller</Link></section></div>}
  </div>;
}
