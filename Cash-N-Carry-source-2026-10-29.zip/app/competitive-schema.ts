import { env } from "cloudflare:workers";

let ready: Promise<void> | null = null;
let readyDatabase: unknown = null;
const statements = [
  `CREATE TABLE IF NOT EXISTS livestream_deals (id TEXT PRIMARY KEY,store TEXT NOT NULL REFERENCES stores(id),product TEXT NOT NULL REFERENCES products(id),stream TEXT NOT NULL REFERENCES streams(id),promo_price INTEGER NOT NULL CHECK(promo_price>0),max_quantity INTEGER NOT NULL CHECK(max_quantity>0),sold_quantity INTEGER NOT NULL DEFAULT 0 CHECK(sold_quantity>=0),starts_at TEXT NOT NULL,ends_at TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','active','ended','cancelled','disabled')),created TEXT NOT NULL,updated TEXT NOT NULL,CHECK(ends_at>starts_at))`,
  `CREATE INDEX IF NOT EXISTS live_deals_stream_status ON livestream_deals(stream,status,starts_at,ends_at)`,
  `CREATE TRIGGER IF NOT EXISTS live_deal_insert_guard BEFORE INSERT ON livestream_deals WHEN NOT EXISTS(SELECT 1 FROM products p JOIN streams s ON s.id=NEW.stream WHERE p.id=NEW.product AND p.store=NEW.store AND s.store=NEW.store AND NEW.promo_price<p.price AND NEW.max_quantity<=p.stock) BEGIN SELECT RAISE(ABORT,'Live deal product, price or quantity is invalid'); END`,
  `CREATE TRIGGER IF NOT EXISTS live_deal_insert_overlap_guard BEFORE INSERT ON livestream_deals WHEN NEW.status IN ('active','scheduled') AND EXISTS(SELECT 1 FROM livestream_deals d WHERE d.product=NEW.product AND d.stream=NEW.stream AND d.status IN ('active','scheduled') AND d.starts_at<NEW.ends_at AND d.ends_at>NEW.starts_at) BEGIN SELECT RAISE(ABORT,'Overlapping livestream deal'); END`,
  `CREATE TRIGGER IF NOT EXISTS live_deal_update_guard BEFORE UPDATE ON livestream_deals WHEN NEW.status IN ('active','scheduled') AND NOT EXISTS(SELECT 1 FROM products p JOIN streams s ON s.id=NEW.stream WHERE p.id=NEW.product AND p.store=NEW.store AND s.store=NEW.store AND NEW.promo_price<p.price AND NEW.max_quantity<=p.stock) BEGIN SELECT RAISE(ABORT,'Live deal product, price or quantity is invalid'); END`,
  `CREATE TRIGGER IF NOT EXISTS live_deal_update_overlap_guard BEFORE UPDATE ON livestream_deals WHEN NEW.status IN ('active','scheduled') AND EXISTS(SELECT 1 FROM livestream_deals d WHERE d.id!=NEW.id AND d.product=NEW.product AND d.stream=NEW.stream AND d.status IN ('active','scheduled') AND d.starts_at<NEW.ends_at AND d.ends_at>NEW.starts_at) BEGIN SELECT RAISE(ABORT,'Overlapping livestream deal'); END`,
  `CREATE TABLE IF NOT EXISTS seller_analytics_events (id TEXT PRIMARY KEY,store TEXT NOT NULL REFERENCES stores(id),product TEXT NOT NULL DEFAULT '',stream TEXT NOT NULL DEFAULT '',visitor TEXT NOT NULL,event TEXT NOT NULL CHECK(event IN ('product_view','store_view','livestream_view','product_click','add_to_cart','buy_now','checkout_start','livestream_like','follow')),day TEXT NOT NULL,order_id TEXT NOT NULL DEFAULT '',created TEXT NOT NULL)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS seller_analytics_daily_dedupe ON seller_analytics_events(store,product,stream,visitor,event,day)`,
  `CREATE INDEX IF NOT EXISTS seller_analytics_store_day ON seller_analytics_events(store,day,event)`,
  `CREATE TABLE IF NOT EXISTS livestream_peak_metrics (stream TEXT NOT NULL REFERENCES streams(id),day TEXT NOT NULL,peak_viewers INTEGER NOT NULL DEFAULT 0,sampled_at TEXT NOT NULL,PRIMARY KEY(stream,day))`,
  `CREATE TABLE IF NOT EXISTS product_bundles (id TEXT PRIMARY KEY,store TEXT NOT NULL REFERENCES stores(id),product TEXT NOT NULL UNIQUE REFERENCES products(id),title TEXT NOT NULL,description TEXT NOT NULL,image TEXT NOT NULL,price INTEGER NOT NULL CHECK(price>0),active INTEGER NOT NULL DEFAULT 0 CHECK(active IN (0,1)),stream TEXT NOT NULL DEFAULT '',created TEXT NOT NULL,updated TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS product_bundles_store_active ON product_bundles(store,active)`,
  `CREATE TABLE IF NOT EXISTS product_bundle_items (bundle TEXT NOT NULL REFERENCES product_bundles(id),product TEXT NOT NULL REFERENCES products(id),quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 99),name_snapshot TEXT NOT NULL,price_snapshot INTEGER NOT NULL CHECK(price_snapshot>0),PRIMARY KEY(bundle,product))`,
  `CREATE TRIGGER IF NOT EXISTS bundle_component_owner_guard BEFORE INSERT ON product_bundle_items WHEN NOT EXISTS(SELECT 1 FROM product_bundles b JOIN products p ON p.id=NEW.product WHERE b.id=NEW.bundle AND p.store=b.store AND p.id!=b.product AND p.active=1 AND json_array_length(p.variants)=0) BEGIN SELECT RAISE(ABORT,'Invalid bundle component'); END`,
  `CREATE TABLE IF NOT EXISTS bundle_order_snapshots (order_id TEXT NOT NULL REFERENCES orders(id),bundle TEXT NOT NULL,title TEXT NOT NULL,contents TEXT NOT NULL,bundle_price INTEGER NOT NULL,PRIMARY KEY(order_id,bundle))`,
  `CREATE TABLE IF NOT EXISTS order_deal_snapshots (order_id TEXT NOT NULL REFERENCES orders(id),deal TEXT NOT NULL REFERENCES livestream_deals(id),product TEXT NOT NULL REFERENCES products(id),quantity INTEGER NOT NULL,price INTEGER NOT NULL,PRIMARY KEY(order_id,deal))`,
  `CREATE TABLE IF NOT EXISTS order_stream_snapshots (order_id TEXT NOT NULL REFERENCES orders(id),stream TEXT NOT NULL REFERENCES streams(id),product TEXT NOT NULL REFERENCES products(id),PRIMARY KEY(order_id,product))`,
  `CREATE TRIGGER IF NOT EXISTS order_deal_validate BEFORE INSERT ON order_deal_snapshots WHEN NOT EXISTS(SELECT 1 FROM livestream_deals d WHERE d.id=NEW.deal AND d.product=NEW.product AND d.promo_price=NEW.price AND NEW.quantity>0 AND d.status IN ('active','scheduled') AND d.starts_at<=strftime('%Y-%m-%dT%H:%M:%fZ','now') AND d.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now') AND d.sold_quantity+NEW.quantity<=d.max_quantity) BEGIN SELECT RAISE(ABORT,'Live deal expired or promotional quantity unavailable'); END`,
  `CREATE TRIGGER IF NOT EXISTS order_deal_reserve AFTER INSERT ON order_deal_snapshots BEGIN UPDATE livestream_deals SET sold_quantity=sold_quantity+NEW.quantity,updated=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=NEW.deal; END`,
  `CREATE TRIGGER IF NOT EXISTS order_deal_restock AFTER UPDATE OF status ON orders WHEN NEW.status='cancelled' AND OLD.status!='cancelled' BEGIN UPDATE livestream_deals SET sold_quantity=MAX(0,sold_quantity-COALESCE((SELECT SUM(quantity) FROM order_deal_snapshots WHERE order_id=NEW.id AND deal=livestream_deals.id),0)),updated=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id IN (SELECT deal FROM order_deal_snapshots WHERE order_id=NEW.id); END`,
  `CREATE TABLE IF NOT EXISTS creator_profiles (user TEXT PRIMARY KEY,display_name TEXT NOT NULL,social_links TEXT NOT NULL DEFAULT '[]',categories TEXT NOT NULL DEFAULT '[]',status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','suspended')),note TEXT NOT NULL DEFAULT '',created TEXT NOT NULL,updated TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS affiliate_partnerships (id TEXT PRIMARY KEY,creator TEXT NOT NULL REFERENCES creator_profiles(user),store TEXT NOT NULL REFERENCES stores(id),product TEXT NOT NULL REFERENCES products(id),commission_bps INTEGER NOT NULL CHECK(commission_bps BETWEEN 0 AND 3000),status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','revoked','suspended')),created TEXT NOT NULL,updated TEXT NOT NULL,UNIQUE(creator,product))`,
  `CREATE INDEX IF NOT EXISTS affiliate_store_status ON affiliate_partnerships(store,status)`,
  `CREATE TABLE IF NOT EXISTS affiliate_clicks (id TEXT PRIMARY KEY,partnership TEXT NOT NULL REFERENCES affiliate_partnerships(id),visitor TEXT NOT NULL,created TEXT NOT NULL,UNIQUE(partnership,visitor))`,
  `CREATE TABLE IF NOT EXISTS affiliate_commissions (id TEXT PRIMARY KEY,partnership TEXT NOT NULL REFERENCES affiliate_partnerships(id),order_id TEXT NOT NULL REFERENCES orders(id),amount INTEGER NOT NULL CHECK(amount>=0),status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','reversed','eligible','paid')),created TEXT NOT NULL,updated TEXT NOT NULL,UNIQUE(partnership,order_id))`,
  `CREATE TRIGGER IF NOT EXISTS affiliate_commission_reconcile AFTER UPDATE OF status,payment_status ON orders BEGIN UPDATE affiliate_commissions SET status=CASE WHEN NEW.status='cancelled' OR NEW.payment_status IN ('failed','refunded') THEN 'reversed' WHEN NEW.status='delivered' AND EXISTS(SELECT 1 FROM payments pay WHERE pay.order_id=NEW.id AND pay.mode='live' AND pay.status='paid') THEN 'eligible' WHEN NEW.payment_status='paid' AND EXISTS(SELECT 1 FROM payments pay WHERE pay.order_id=NEW.id AND pay.mode='live' AND pay.status='paid') THEN 'confirmed' ELSE status END,updated=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE order_id=NEW.id; END`,
  `CREATE TABLE IF NOT EXISTS live_auctions (id TEXT PRIMARY KEY,store TEXT NOT NULL REFERENCES stores(id),product TEXT NOT NULL REFERENCES products(id),stream TEXT NOT NULL REFERENCES streams(id),start_price INTEGER NOT NULL CHECK(start_price>0),increment INTEGER NOT NULL CHECK(increment>0),reserve_price INTEGER,starts_at TEXT NOT NULL,ends_at TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','active','ended','cancelled','suspended')),winning_bid TEXT NOT NULL DEFAULT '',order_id TEXT NOT NULL DEFAULT '',created TEXT NOT NULL,updated TEXT NOT NULL,CHECK(ends_at>starts_at))`,
  `CREATE TABLE IF NOT EXISTS live_chat_mutes (stream TEXT NOT NULL REFERENCES streams(id),user TEXT NOT NULL,muted_until TEXT NOT NULL,actor TEXT NOT NULL,created TEXT NOT NULL,PRIMARY KEY(stream,user))`,
  `CREATE TABLE IF NOT EXISTS stream_reminders (stream TEXT NOT NULL REFERENCES streams(id) ON DELETE CASCADE,user TEXT NOT NULL,created TEXT NOT NULL,reminded_at TEXT NOT NULL DEFAULT '',PRIMARY KEY(stream,user))`,
  `CREATE INDEX IF NOT EXISTS stream_reminders_user ON stream_reminders(user,created)`,
  `CREATE INDEX IF NOT EXISTS live_chat_mutes_expiry ON live_chat_mutes(stream,muted_until)`,
  `CREATE TABLE IF NOT EXISTS live_moderation_events (id TEXT PRIMARY KEY,stream TEXT NOT NULL REFERENCES streams(id),comment_id TEXT NOT NULL DEFAULT '',actor TEXT NOT NULL,subject_user TEXT NOT NULL DEFAULT '',action TEXT NOT NULL CHECK(action IN ('hide','mute','block','report')),reason TEXT NOT NULL DEFAULT '',created TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS live_moderation_stream_created ON live_moderation_events(stream,created DESC)`,
  `CREATE INDEX IF NOT EXISTS live_auctions_stream_status ON live_auctions(stream,status,ends_at)`,
  `CREATE TRIGGER IF NOT EXISTS live_auction_queue_shift AFTER UPDATE OF ends_at ON live_auctions WHEN OLD.status='active' AND NEW.status='active' AND NEW.ends_at!=OLD.ends_at BEGIN UPDATE live_auctions SET starts_at=strftime('%Y-%m-%dT%H:%M:%fZ',starts_at,printf('%+f seconds',(julianday(NEW.ends_at)-julianday(OLD.ends_at))*86400)),ends_at=strftime('%Y-%m-%dT%H:%M:%fZ',ends_at,printf('%+f seconds',(julianday(NEW.ends_at)-julianday(OLD.ends_at))*86400)),updated=NEW.updated WHERE stream=NEW.stream AND status='scheduled' AND starts_at>=OLD.ends_at; END`,
  `CREATE TRIGGER IF NOT EXISTS live_auction_cancel_queue_shift AFTER UPDATE OF status ON live_auctions WHEN OLD.status='scheduled' AND NEW.status='cancelled' BEGIN UPDATE live_auctions SET starts_at=strftime('%Y-%m-%dT%H:%M:%fZ',starts_at,printf('%+f seconds',(julianday(OLD.starts_at)-julianday(OLD.ends_at))*86400)),ends_at=strftime('%Y-%m-%dT%H:%M:%fZ',ends_at,printf('%+f seconds',(julianday(OLD.starts_at)-julianday(OLD.ends_at))*86400)),updated=NEW.updated WHERE stream=NEW.stream AND status='scheduled' AND starts_at>=OLD.ends_at; END`,
  `CREATE TABLE IF NOT EXISTS auction_bids (id TEXT PRIMARY KEY,auction TEXT NOT NULL REFERENCES live_auctions(id),bidder TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),request_id TEXT NOT NULL UNIQUE,created TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS auction_bids_rank ON auction_bids(auction,amount,created)`,
  `CREATE TABLE IF NOT EXISTS auction_max_bids (auction TEXT NOT NULL REFERENCES live_auctions(id),bidder TEXT NOT NULL,max_amount INTEGER NOT NULL CHECK(max_amount>0),created TEXT NOT NULL,updated TEXT NOT NULL,PRIMARY KEY(auction,bidder))`,
  `CREATE INDEX IF NOT EXISTS auction_max_bids_rank ON auction_max_bids(auction,max_amount DESC,created ASC)`,
  `CREATE TABLE IF NOT EXISTS auction_max_bid_requests (request_id TEXT PRIMARY KEY,auction TEXT NOT NULL REFERENCES live_auctions(id),bidder TEXT NOT NULL,max_amount INTEGER NOT NULL CHECK(max_amount>0),created TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS auction_max_bid_requests_auction ON auction_max_bid_requests(auction,created)`,
  `CREATE TABLE IF NOT EXISTS founding_program (id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)),duration_days INTEGER NOT NULL DEFAULT 30 CHECK(duration_days BETWEEN 1 AND 365),max_participants INTEGER NOT NULL DEFAULT 100 CHECK(max_participants BETWEEN 1 AND 100000),eligibility TEXT NOT NULL DEFAULT 'Verified sellers approved by an administrator.',updated TEXT NOT NULL)`,
  `INSERT OR IGNORE INTO founding_program(id,enabled,duration_days,max_participants,eligibility,updated) VALUES(1,0,30,100,'Verified sellers approved by an administrator.',strftime('%Y-%m-%dT%H:%M:%fZ','now'))`,
  `CREATE TABLE IF NOT EXISTS founding_enrollments (id TEXT PRIMARY KEY,store TEXT NOT NULL UNIQUE REFERENCES stores(id),status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','revoked','expired')),starts_at TEXT NOT NULL DEFAULT '',ends_at TEXT NOT NULL DEFAULT '',approved_by TEXT NOT NULL DEFAULT '',note TEXT NOT NULL DEFAULT '',created TEXT NOT NULL,updated TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS founding_enrollments_status_end ON founding_enrollments(status,ends_at)`,
  `CREATE TRIGGER IF NOT EXISTS bundle_component_stock_guard BEFORE INSERT ON order_items WHEN EXISTS(SELECT 1 FROM product_bundles b WHERE b.product=NEW.product AND b.active=1) AND EXISTS(SELECT 1 FROM product_bundle_items bi JOIN products p ON p.id=bi.product WHERE bi.bundle=(SELECT id FROM product_bundles WHERE product=NEW.product) AND (p.active!=1 OR p.stock<bi.quantity*NEW.quantity OR json_array_length(p.variants)>0)) BEGIN SELECT RAISE(ABORT,'Bundle component stock changed'); END`,
  `CREATE TRIGGER IF NOT EXISTS bundle_component_stock_decrement AFTER INSERT ON order_items WHEN EXISTS(SELECT 1 FROM product_bundles WHERE product=NEW.product AND active=1) BEGIN UPDATE products SET stock=stock-COALESCE((SELECT SUM(bi.quantity*NEW.quantity) FROM product_bundle_items bi JOIN product_bundles b ON b.id=bi.bundle WHERE b.product=NEW.product AND b.active=1 AND bi.product=products.id),0) WHERE id IN (SELECT bi.product FROM product_bundle_items bi JOIN product_bundles b ON b.id=bi.bundle WHERE b.product=NEW.product AND b.active=1); END`,
  `CREATE TRIGGER IF NOT EXISTS bundle_stock_recalc AFTER UPDATE OF stock ON products WHEN EXISTS(SELECT 1 FROM product_bundle_items WHERE product=NEW.id) BEGIN UPDATE products SET stock=COALESCE((SELECT MIN(CAST(p.stock/bi.quantity AS INTEGER)) FROM product_bundle_items bi JOIN product_bundles b ON b.id=bi.bundle JOIN products p ON p.id=bi.product WHERE b.product=products.id AND b.active=1),0) WHERE id IN (SELECT b.product FROM product_bundles b JOIN product_bundle_items bi ON bi.bundle=b.id WHERE bi.product=NEW.id AND b.active=1); END`,
  `CREATE TRIGGER IF NOT EXISTS bundle_component_restock AFTER UPDATE OF status ON orders WHEN NEW.status='cancelled' AND OLD.status!='cancelled' BEGIN UPDATE products SET stock=stock+COALESCE((SELECT SUM(i.quantity*CAST(json_extract(component.value,'$.quantity') AS INTEGER)) FROM bundle_order_snapshots bos JOIN order_items i ON i.order_id=bos.order_id AND i.product=(SELECT product FROM product_bundles WHERE id=bos.bundle) JOIN json_each(bos.contents) component WHERE bos.order_id=NEW.id AND json_extract(component.value,'$.id')=products.id),0) WHERE id IN (SELECT json_extract(component.value,'$.id') FROM bundle_order_snapshots bos JOIN order_items i ON i.order_id=bos.order_id AND i.product=(SELECT product FROM product_bundles WHERE id=bos.bundle) JOIN json_each(bos.contents) component WHERE bos.order_id=NEW.id); END`,
];

export async function ensureCompetitiveSchema() {
  if (!env.DB) throw Error("Storage unavailable");
  if (!ready || readyDatabase !== env.DB) {
    readyDatabase = env.DB;
    ready = (async () => {
    for (const sql of statements) await env.DB!.prepare(sql).run();
    try{await env.DB!.prepare("ALTER TABLE product_bundles ADD COLUMN stream TEXT NOT NULL DEFAULT ''").run();}
    catch(error){if(!/duplicate column name:\s*stream/i.test(String((error as Error)?.message||error)))throw error;}
    for(const [column,definition] of [["pinned_auction","TEXT NOT NULL DEFAULT ''"],["pinned_deal","TEXT NOT NULL DEFAULT ''"],["pinned_bundle","TEXT NOT NULL DEFAULT ''"],["pinned_bundle_ends_at","TEXT NOT NULL DEFAULT ''"]] as const){
      try{await env.DB!.prepare(`ALTER TABLE streams ADD COLUMN ${column} ${definition}`).run();}
      catch(error){if(!new RegExp(`duplicate column name:\\s*${column}`,"i").test(String((error as Error)?.message||error)))throw error;}
    }
    for(const [column,definition] of [["recipient","TEXT NOT NULL DEFAULT ''"],["phone","TEXT NOT NULL DEFAULT ''"],["delivery_address","TEXT NOT NULL DEFAULT ''"],["delivery_state","TEXT NOT NULL DEFAULT ''"],["delivery_area","TEXT NOT NULL DEFAULT ''"],["delivery_fee","INTEGER NOT NULL DEFAULT 0"]] as const){
      try{await env.DB!.prepare(`ALTER TABLE auction_bids ADD COLUMN ${column} ${definition}`).run();}
      catch(error){if(!new RegExp(`duplicate column name:\\s*${column}`,"i").test(String((error as Error)?.message||error)))throw error;}
    }
    await env.DB!.prepare(`INSERT OR IGNORE INTO auction_max_bids(auction,bidder,max_amount,created,updated)
      SELECT auction,bidder,MAX(amount),MIN(created),MAX(created) FROM auction_bids GROUP BY auction,bidder`).run();
    // Older clients could create the same product auction more than once
    // before the studio refreshed its list. Keep the most useful record
    // (most bids, then newest) and retain every other record as cancelled;
    // bids and historical auction data are never deleted. The partial unique
    // index makes duplicate active auctions impossible, including concurrent
    // requests from separate worker isolates.
    await env.DB!.batch([
      env.DB!.prepare(`WITH ranked AS (
        SELECT a.id, ROW_NUMBER() OVER (
          PARTITION BY a.stream,a.product
          ORDER BY (SELECT COUNT(*) FROM auction_bids b WHERE b.auction=a.id) DESC,a.created DESC,a.id DESC
        ) AS position
        FROM live_auctions a WHERE a.status IN ('scheduled','active')
      )
      UPDATE live_auctions SET status='cancelled',updated=strftime('%Y-%m-%dT%H:%M:%fZ','now')
      WHERE id IN (SELECT id FROM ranked WHERE position>1)`),
      env.DB!.prepare(`UPDATE streams SET pinned_auction=COALESCE((
        SELECT winner.id FROM live_auctions old
        JOIN live_auctions winner ON winner.stream=old.stream AND winner.product=old.product
        WHERE old.id=streams.pinned_auction AND winner.status IN ('scheduled','active')
        ORDER BY (SELECT COUNT(*) FROM auction_bids b WHERE b.auction=winner.id) DESC,winner.created DESC,winner.id DESC LIMIT 1
      ),'') WHERE pinned_auction!='' AND NOT EXISTS(
        SELECT 1 FROM live_auctions current WHERE current.id=streams.pinned_auction AND current.status IN ('scheduled','active')
      )`),
      env.DB!.prepare("CREATE UNIQUE INDEX IF NOT EXISTS live_auctions_one_open_product_per_stream ON live_auctions(stream,product) WHERE status IN ('scheduled','active')"),
    ]);
    await env.DB!.prepare("CREATE INDEX IF NOT EXISTS product_bundles_stream_active ON product_bundles(stream,active)").run();
    // Replace the older subscription-only gate with the combined verified
    // subscription OR approved founding-access condition.
    // D1 batches are transactional: concurrent isolates cannot interleave
    // DROP/CREATE pairs or observe a missing selling/inventory guard.
    await env.DB!.batch([
      env.DB!.prepare("DROP TRIGGER IF EXISTS seller_new_order_activation"),
      env.DB!.prepare(`CREATE TRIGGER seller_new_order_activation BEFORE INSERT ON orders WHEN NEW.seller_activation_required=1 AND NOT EXISTS (SELECT 1 FROM stores s WHERE s.id=NEW.store AND s.verified=1 AND s.suspended=0 AND NOT EXISTS(SELECT 1 FROM profiles p WHERE p.id=s.owner AND p.suspended=1) AND (EXISTS(SELECT 1 FROM seller_subscriptions ss WHERE ss.store=s.id AND ss.mode=COALESCE((SELECT value FROM platform_settings WHERE key='seller_subscription_mode'),'test') AND ss.status='active' AND ss.paid_until>strftime('%Y-%m-%dT%H:%M:%fZ','now')) OR EXISTS(SELECT 1 FROM founding_enrollments fe JOIN founding_program fp ON fp.id=1 WHERE fe.store=s.id AND fp.enabled=1 AND fe.status='active' AND fe.starts_at<=strftime('%Y-%m-%dT%H:%M:%fZ','now') AND fe.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now')))) BEGIN SELECT RAISE(ABORT,'Seller activation expired or verification missing'); END`),
      env.DB!.prepare("DROP TRIGGER IF EXISTS item_stock_guard"),
      env.DB!.prepare(`CREATE TRIGGER item_stock_guard BEFORE INSERT ON order_items WHEN NEW.quantity<=0 OR NOT EXISTS(SELECT 1 FROM products p WHERE p.id=NEW.product AND p.active=1 AND ((NEW.variant='' AND json_array_length(p.variants)=0 AND ((p.price=NEW.price AND p.stock>=NEW.quantity) OR (EXISTS(SELECT 1 FROM orders o JOIN live_auctions a ON a.order_id=o.id JOIN auction_bids b ON b.id=a.winning_bid WHERE o.id=NEW.order_id AND o.payment='auction' AND a.status='ended' AND a.product=p.id AND b.amount=NEW.price) AND p.stock>=NEW.quantity) OR (EXISTS(SELECT 1 FROM order_deal_snapshots ds JOIN livestream_deals d ON d.id=ds.deal WHERE ds.order_id=NEW.order_id AND ds.product=p.id AND ds.price=NEW.price AND ds.quantity=NEW.quantity AND d.product=p.id AND d.status IN ('active','scheduled')) AND p.stock>=NEW.quantity))) OR (NEW.variant!='' AND EXISTS(SELECT 1 FROM json_each(p.variants) v WHERE json_extract(v.value,'$.name')=NEW.variant AND json_extract(v.value,'$.price')=NEW.price AND json_extract(v.value,'$.stock')>=NEW.quantity)))) BEGIN SELECT RAISE(ABORT,'Stock or price changed'); END`),
      env.DB!.prepare("DROP TRIGGER IF EXISTS bundle_component_restock"),
      env.DB!.prepare(`CREATE TRIGGER bundle_component_restock AFTER UPDATE OF status ON orders WHEN NEW.status='cancelled' AND OLD.status!='cancelled' BEGIN UPDATE products SET stock=stock+COALESCE((SELECT SUM(i.quantity*CAST(json_extract(component.value,'$.quantity') AS INTEGER)) FROM bundle_order_snapshots bos JOIN order_items i ON i.order_id=bos.order_id AND i.product=(SELECT product FROM product_bundles WHERE id=bos.bundle) JOIN json_each(bos.contents) component WHERE bos.order_id=NEW.id AND json_extract(component.value,'$.id')=products.id),0) WHERE id IN (SELECT json_extract(component.value,'$.id') FROM bundle_order_snapshots bos JOIN order_items i ON i.order_id=bos.order_id AND i.product=(SELECT product FROM product_bundles WHERE id=bos.bundle) JOIN json_each(bos.contents) component WHERE bos.order_id=NEW.id); END`),
    ]);
    await env.DB!.prepare("INSERT INTO platform_settings(key,value,updated) VALUES('seller_subscription_mode',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated").bind(env.FLW_MODE==='live'?'live':'test',new Date().toISOString()).run();
    })().catch((e) => { ready = null; readyDatabase = null; throw e; });
  }
  await ready;
}
