/** Top Seller means 10 verified delivered orders and five delivered-order reviews at 4.5+. */
export function topSellerEligibilitySQL(storeAlias = "s") {
  return `(
    (SELECT COUNT(DISTINCT o.id) FROM orders o
      WHERE o.store=${storeAlias}.id AND o.status='delivered'
        AND (o.payment!='flutterwave' OR (o.payment_status='paid' AND EXISTS(
          SELECT 1 FROM payments paid WHERE paid.order_id=o.id AND paid.mode='live' AND paid.status='paid'
        )))
    ) >= 10
    AND (SELECT COUNT(*) FROM reviews r JOIN orders ro ON ro.id=r.order_id
      WHERE ro.store=${storeAlias}.id AND ro.status='delivered'
        AND (ro.payment!='flutterwave' OR (ro.payment_status='paid' AND EXISTS(
          SELECT 1 FROM payments rpaid WHERE rpaid.order_id=ro.id AND rpaid.mode='live' AND rpaid.status='paid'
        )))
    ) >= 5
    AND (SELECT AVG(r.rating) FROM reviews r JOIN orders ro ON ro.id=r.order_id
      WHERE ro.store=${storeAlias}.id AND ro.status='delivered'
        AND (ro.payment!='flutterwave' OR (ro.payment_status='paid' AND EXISTS(
          SELECT 1 FROM payments rpaid WHERE rpaid.order_id=ro.id AND rpaid.mode='live' AND rpaid.status='paid'
        )))
    ) >= 4.5
  )`;
}

export function qualifiesForFastDelivery(value: unknown) {
  const text = String(value || "").trim().toLowerCase();
  if (!text) return false;
  if (/\b(same day|next day|within 24 hours?)\b/.test(text)) return true;
  const match = text.match(/\b(\d+)\s*(?:-|–|to)\s*(\d+)\s*(?:business\s*)?days?\b|\b(\d+)\s*(?:business\s*)?days?\b/);
  if (!match) return false;
  const maximum = Number(match[2] || match[3] || match[1]);
  return Number.isFinite(maximum) && maximum > 0 && maximum <= 2;
}

export function acceptsReturns(value: unknown) {
  const text = String(value || "").trim().toLowerCase();
  if (!text || /\b(no returns?|non[- ]?returnable|final sale|not accepted|not applicable|contact the seller before)\b/.test(text)) return false;
  return /\b(returns? accepted|accepts? returns?|return eligible|eligible for returns?|refunds? available|exchange accepted)\b/.test(text)
    || /\b\d+\s*[- ]?days?\b.*\b(returns?|refunds?|exchange)\b|\b(returns?|refunds?|exchange)\b.*\b\d+\s*[- ]?days?\b/.test(text);
}
