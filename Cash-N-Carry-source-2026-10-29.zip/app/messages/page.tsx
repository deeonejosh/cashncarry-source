import { requireChatGPTUser } from "../chatgpt-auth";
import Messages from "./panel";
import { CustomerNavigation } from "../customer-shell";
export const dynamic="force-dynamic";
export default async function Page({searchParams}:{searchParams:Promise<{store?:string;buyer?:string;product?:string;order?:string}>}){
 const p=await searchParams;
 const query=new URLSearchParams();if(p.store)query.set("store",p.store);if(p.buyer)query.set("buyer",p.buyer);if(p.product)query.set("product",p.product);if(p.order)query.set("order",p.order);
 await requireChatGPTUser("/messages"+(query.size?"?"+query.toString():""));
 return <><main id="main-content" className="customer-page messages-page"><Messages store={p.store||""} buyer={p.buyer||""} product={p.product||""} order={p.order||""}/></main><CustomerNavigation active="Messages"/></>;
}
