"use client";
import {
  Radio,
  ShoppingBag,
  Shirt,
  Sparkles,
  Armchair,
  Headphones,
  Utensils,
  Briefcase,
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  CircleHelp,
  Compass,
  MessageCircle,
  Share2,
  Truck,
  PackageCheck,
  ShieldCheck,
  FileText,
  LifeBuoy,
} from "lucide-react";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import BrandLogo from "./brand-logo";
import ImageAsset from "./image-asset";
import { storefrontImageSrcSet, storefrontImageUrl } from "./storefront-image-url";
import { trustBadgeImage } from "./trust-badge-image";
export function ShoppingHero({
  onLive,
  onShop,
  liveCount = 0,
}: {
  onLive: () => void;
  onShop: () => void;
  liveCount?: number;
}) {
  return (
    <section className="shopping-hero">
      <div className="hero-copy">
        <p className="eyebrow"><span className="hero-live-dot" aria-hidden="true" /> CASH N CARRY MARKETPLACE</p>
        <h1>Shop from trusted Nigerian sellers</h1>
        <p>Discover quality products from Nigerian businesses. Great prices, reliable delivery options and a stronger local economy.</p>
        <div className="hero-actions">
          <button className="primary" onClick={onShop}>
            <ShoppingBag size={19} aria-hidden="true" /> Shop products
          </button>
          <button className="secondary-button homepage-live-button" onClick={onLive} aria-label={liveCount > 0 ? `Watch live shopping: ${liveCount} sellers live now` : "Watch live shopping"}>
            <Radio size={19} aria-hidden="true" /> Watch live{liveCount > 0 ? ` · ${liveCount} live` : ""}
          </button>
        </div>
      </div>
      <div className="hero-photo">
        <ImageAsset
          src="/seller-hero-640.webp"
          srcSet="/seller-hero-640.webp 640w, /seller-hero.webp 1050w"
          sizes="(max-width: 767px) 100vw, (max-width: 1100px) 45vw, 550px"
          alt="Illustrative Nigerian seller demonstrating a leather handbag to a phone camera"
          width={1050}
          height={700}
          loading="eager"
          fetchPriority="high"
        />
        <div className="hero-photo-caption"><span>THE LIVE SHOPPING EXPERIENCE</span><strong>A closer look before you choose.</strong><small>Illustrative seller demonstration</small></div>
      </div>
    </section>
  );
}

function CategoryVisual({ product, Icon }: { product?: { image: string }; Icon: typeof ShoppingBag }) {
  const visual = useRef<HTMLSpanElement>(null);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);
  useEffect(() => {
    const image = visual.current?.querySelector("img");
    if (image?.complete && image.naturalWidth > 0 && !image.classList.contains("image-unavailable")) {
      setImageLoaded(true);
    }
  }, [product?.image]);
  return (
    <span className="category-visual" ref={visual}>
      {product?.image && <ImageAsset
        src={storefrontImageUrl(product.image, 160)}
        srcSet={storefrontImageSrcSet(product.image, [160, 256, 320])}
        sizes="64px"
        fallbackSrc={product.image}
        width="64"
        height="64"
        alt=""
        loading="lazy"
        onLoad={(event) => {
          if (!event.currentTarget.classList.contains("image-unavailable")) setImageLoaded(true);
        }}
        onError={() => setImageFailed(true)}
      />}
      {(!product?.image || !imageLoaded || imageFailed) && <Icon className="category-fallback-icon category-fallback-icon--visible" size={34} strokeWidth={1.5} aria-hidden="true" />}
    </span>
  );
}

export function ShopCategories({
  products,
  onSelect,
  mobileVariant = false,
  activeCategory = "All",
  categories,
}: {
  products: { category: string; name: string; image: string }[];
  onSelect: (label: string, stored: string, term: string) => void;
  mobileVariant?: boolean;
  activeCategory?: string;
  categories?: string[];
}) {
  const choices = [...new Set((categories?.length ? categories : products.map((product) => product.category)).filter(Boolean))]
    .slice(0, mobileVariant ? 6 : 7)
    .map((stored) => {
      const normalized = stored.toLowerCase();
      const Icon = normalized.includes("fashion") || normalized.includes("cloth") ? Shirt
        : normalized.includes("beaut") || normalized.includes("health") ? Sparkles
        : normalized.includes("food") || normalized.includes("grocer") ? Utensils
        : normalized.includes("tech") || normalized.includes("phone") || normalized.includes("elect") ? Headphones
        : normalized.includes("home") || normalized.includes("kitchen") ? Armchair
        : normalized.includes("service") ? Briefcase : ShoppingBag;
      const label = normalized === "tech" ? "Phones & Tech" : stored;
      return { label, stored, Icon, product: products.find((product) => product.category === stored) };
    });
  return (
    <section className="shop-categories">
      <div className="section-heading">
        <h2>Shop by category</h2>
      </div>
      <div className="shopping-category-grid">
        {mobileVariant && <button className={activeCategory === "All" ? "is-active" : ""} onClick={() => onSelect("All", "All", "")} aria-pressed={activeCategory === "All"}>
          <span className="category-visual category-visual--all"><ShoppingBag size={26} aria-hidden="true" /></span>
          <strong>All</strong>
        </button>}
        {choices.map(({ label, stored, Icon, product: p }) => {
          return (
            <button key={label} className={activeCategory === stored ? "is-active" : ""} aria-pressed={activeCategory === stored} onClick={() => onSelect(label, stored, "")}>
              <CategoryVisual product={p} Icon={Icon} />
              <strong>{label}</strong>
            </button>
          );
        })}
        {!choices.length && <p className="shop-categories-empty">Product categories will appear here as sellers list items.</p>}
      </div>
    </section>
  );
}
export function ShoppingGuide({ onShop, onLive }: { onShop: () => void; onLive: () => void }) {
  return <section className="shopping-guide" aria-labelledby="shopping-guide-title">
    <div className="shopping-guide-cta">
      <div className="shopping-guide-copy">
        <p className="shopping-guide-eyebrow">MADE FOR THE WAY NIGERIA SHOPS</p>
        <h2 id="shopping-guide-title">Meet your next Nigerian favourite.</h2>
        <p>Find independent sellers, see products in action and shop with the details you need before checkout.</p>
        <div className="shopping-guide-actions">
          <button type="button" className="shopping-guide-primary" onClick={onShop}><ShoppingBag size={18} aria-hidden="true" /> Explore the shop <ArrowRight size={17} aria-hidden="true" /></button>
          <button type="button" className="shopping-guide-secondary" onClick={onLive}><Radio size={17} aria-hidden="true" /> Watch live</button>
        </div>
      </div>
      <div className="shopping-guide-steps" aria-label="How Cash N Carry shopping works">
        <article><span><Compass size={19} aria-hidden="true" /></span><div><strong>Discover</strong><p>Browse products and seller storefronts.</p></div></article>
        <article><span><MessageCircle size={19} aria-hidden="true" /></span><div><strong>See it up close</strong><p>Watch a live demo and ask questions.</p></div></article>
        <article><span><ShoppingBag size={19} aria-hidden="true" /></span><div><strong>Choose with confidence</strong><p>Review options, delivery and total at checkout.</p></div></article>
      </div>
    </div>
    <div className="shopping-guide-lower">
      <div className="shopping-guide-note">
        <span className="shopping-guide-note-icon"><BadgeCheck size={18} aria-hidden="true" /></span>
        <div><h3>Know who you’re buying from</h3><p>Seller pages show their products and available details. A Verified Seller badge means their verification was approved; it is not a guarantee of a particular product or transaction.</p></div>
      </div>
      <section className="shopping-faq" aria-labelledby="shopping-faq-title">
        <h3 id="shopping-faq-title"><CircleHelp size={19} aria-hidden="true" /> Quick answers</h3>
        <details><summary>How do delivery fees work?</summary><p>Delivery coverage and fees vary by seller and destination. Enter your delivery address and review the shipping charge in the checkout summary before placing an order.</p></details>
        <details><summary>Can I ask a seller about an item?</summary><p>Yes. Use the product or live comments for questions, or sign in and message the seller for a private product enquiry.</p></details>
        <details><summary>Where can I get help with an order?</summary><p>Check your order details and contact the seller about the item. For platform guidance, visit <Link href="/help">Help &amp; contact</Link>. Review the <Link href="/delivery">delivery</Link> and <Link href="/refunds">returns policies</Link> before ordering.</p></details>
      </section>
    </div>
  </section>;
}

export function HomeFooter({ onShop, onLive }: { onShop: () => void; onLive: () => void }) {
  return <footer className="home-footer">
    <div className="home-footer-main">
      <div className="home-footer-brand">
        <BrandLogo tagline />
        <p>Discover Nigerian sellers through products, videos and live shopping.</p>
        <Link href="/social" className="home-footer-social"><Share2 size={17} aria-hidden="true" /><span>Social channels</span><ArrowUpRight size={15} aria-hidden="true" /></Link>
      </div>
      <nav className="home-footer-column" aria-label="Customer care"><h2>Customer care</h2><a href="/help">Help centre</a><a href="/help">Contact us</a><a href="/delivery">Delivery information</a><a href="/refunds">Returns &amp; refunds</a><a className="cnc-trust-badge-link cnc-footer-trust" href="/refunds" aria-label="Buyer Protection — read returns and refunds policy"><img {...trustBadgeImage("buyer-protection")} className="cnc-trust-badge cnc-trust-badge--compact"/></a></nav>
      <nav className="home-footer-column" aria-label="Shopping"><h2>Shopping</h2><button type="button" onClick={onShop}>Shop all products</button><Link href="/?browse=1#market">Categories</Link><a href="/workspace?tab=Orders">Track an order</a><button type="button" onClick={onLive}>Watch live</button></nav>
      <nav className="home-footer-column" aria-label="Sell on Cash N Carry"><h2>Sell on Cash N Carry</h2><a href="/start-selling">Start selling</a><a href="/seller">Seller Centre</a><a href="/seller-terms">Seller guidelines</a></nav>
      <nav className="home-footer-column" aria-label="Legal and policies"><h2>Legal &amp; policies</h2><a href="/privacy">Privacy policy</a><a href="/terms">Terms of use</a><a href="/refunds">Returns policy</a><a href="/community-guidelines">Community guidelines</a></nav>
    </div>
    <div className="home-footer-bottom"><span>© {new Date().getFullYear()} Cash N Carry</span><span>Shop local. Shop with care.</span></div>
  </footer>;
}

const policyLinks = [
  ["Delivery information", "/delivery", Truck],
  ["Returns & refunds", "/refunds", PackageCheck],
  ["Privacy policy", "/privacy", ShieldCheck],
  ["Terms of use", "/terms", FileText],
  ["Contact us", "/help", LifeBuoy],
] as const;

export function HelpPolicies() {
  return <section className="help-policies" aria-labelledby="help-policies-title">
    <h2 id="help-policies-title">Help &amp; policies</h2>
    <nav aria-label="Help and policies">
      {policyLinks.map(([label, href, Icon]) => <Link href={href} key={href}><Icon size={18} aria-hidden="true"/><span>{label}</span><ArrowRight size={16} aria-hidden="true"/></Link>)}
    </nav>
  </section>;
}

/** Marketplace footer. Every destination below is an existing public route. */
export function MarketplaceFooter() {
  return <footer className="marketplace-footer">
    <div className="marketplace-footer-grid">
      <section className="marketplace-footer-brand">
        <BrandLogo />
        <p>Discover Nigerian sellers through products, videos and live shopping.</p>
        <Link href="/social">Cash N Carry social channels <ArrowUpRight size={14} aria-hidden="true" /></Link>
      </section>
      <nav aria-label="Shop"><h2>Shop</h2><Link href="/?browse=1#market">All products &amp; categories</Link><Link href="/live">Live shopping</Link><Link href="/for-you">For You</Link><Link href="/start-selling">Sell on Cash N Carry</Link></nav>
      <nav aria-label="Customer help"><h2>Customer help</h2><Link href="/workspace?tab=Orders">Track an order</Link><Link href="/delivery">Delivery information</Link><Link href="/refunds">Returns &amp; refunds</Link><Link href="/help">Help &amp; contact</Link><Link className="cnc-trust-badge-link cnc-footer-trust" href="/refunds" aria-label="Buyer Protection — read returns and refunds policy"><img {...trustBadgeImage("buyer-protection")} className="cnc-trust-badge cnc-trust-badge--compact"/></Link></nav>
      <nav aria-label="Policies"><h2>Policies</h2><Link href="/terms">Terms &amp; conditions</Link><Link href="/privacy">Privacy policy</Link><Link href="/refunds">Returns policy</Link><Link href="/community-guidelines">Community guidelines</Link></nav>
      <nav aria-label="About and sellers"><h2>About &amp; sellers</h2><Link href="/seller">Seller Centre</Link><Link href="/seller-terms">Seller guidelines</Link><Link href="/social">Social channels</Link></nav>
    </div>
    <div className="marketplace-footer-bottom"><span>© {new Date().getFullYear()} Cash N Carry. All rights reserved.</span><span>Payment methods available at checkout</span></div>
  </footer>;
}

export function StorefrontFooter(props?: { storeName?: string; storeDescription?: string; storeId?: string; categories?: string[]; surfaceColor?: string; surfaceText?: string; accentColor?: string }) {
  return <footer className="storefront-platform-footer" style={{ "--store-surface": props?.surfaceColor || "#ffffff", "--store-surface-text": props?.surfaceText || "#17221c", "--store-accent": props?.accentColor || "#164b35" } as React.CSSProperties}>
    <div className="storefront-powered-by"><span>Powered by</span><BrandLogo compact className="storefront-powered-logo" /><span className="sr-only">Cash N Carry NG</span></div>
    <nav aria-label="Help and policies">
      {policyLinks.map(([label, href]) => <Link href={href} key={href}>{label}</Link>)}
    </nav>
    <small>Cash N Carry NG · © {new Date().getFullYear()}</small>
  </footer>;
}
