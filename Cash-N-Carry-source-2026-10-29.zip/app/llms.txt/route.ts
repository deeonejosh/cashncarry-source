export function GET(){return new Response(`# Cash N Carry

Cash N Carry is a Nigerian marketplace for product discovery and livestream shopping. Prices are displayed in Nigerian naira. Independent sellers manage their listings and fulfil orders.

## Public information
- [Homepage](https://www.cashncarryng.com/)
- [Help](https://www.cashncarryng.com/help)
- [Terms](https://www.cashncarryng.com/terms)
- [Delivery](https://www.cashncarryng.com/delivery)
- [Returns and refunds](https://www.cashncarryng.com/refunds)
- [Privacy](https://www.cashncarryng.com/privacy)
- [Public sitemap](https://www.cashncarryng.com/sitemap.xml)

Product stock, prices and live availability change. Check current product pages before purchasing.
`,{headers:{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"public,max-age=3600"}});}
