import { env } from "cloudflare:workers";

let ready: Promise<void> | null = null;

/** Confirm the additive deployment migration is present without mutating on reads. */
export async function ensureTrustBadgeSchema() {
  if (!env.DB) throw Error("Storage unavailable");
  ready ??= (async () => {
    const column = await env.DB!.prepare(
      "SELECT COUNT(*) AS count FROM pragma_table_info('stores') WHERE name='official_store'",
    ).first<{ count: number }>();
    if (!Number(column?.count || 0)) throw Error("Trust badge schema migration is required.");
  })().catch((error) => {
    ready = null;
    throw error;
  });
  await ready;
}
