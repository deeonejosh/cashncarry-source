import { brand } from "./brand";
export const EMAIL_ORIGIN = "https://www.cashncarryng.com";
export type EmailData = {
  name?: string;
  message?: string;
  details?: [string, string][];
  items?: {
    name: string;
    variant?: string;
    quantity: number;
    price: number;
    image?: string;
  }[];
  actionUrl?: string;
  actionLabel?: string;
  expiresAt?: string;
  sample?: boolean;
  sandbox?: boolean;
};
const definitions = [
  [
    "seller-verification-received",
    "Verification submitted",
    "Your documents were received for human review. You can check your current status in the verification centre.",
    "Check verification",
    "Stored verification submission",
    true,
  ],
  [
    "seller-verification-approved",
    "Seller verification approved",
    "Your seller verification is approved. An active subscription is also required before new selling and broadcasts.",
    "Review selling access",
    "Stored human verification decision",
    true,
  ],
  [
    "seller-verification-information",
    "More verification information needed",
    "Review the private reviewer note and provide the requested evidence through the verification centre. Do not email identity documents.",
    "Review document request",
    "Stored human verification decision",
    true,
  ],
  [
    "seller-verification-rejected",
    "Verification decision available",
    "Review the decision and reviewer note privately. You may request a review through the appeal form.",
    "Review decision",
    "Stored human verification decision",
    true,
  ],
  [
    "seller-withdrawal-requested",
    "Withdrawal request received",
    "Your withdrawal request is recorded. Funds are reserved while the request is reviewed. This is not confirmation of payment.",
    "Track request",
    "Stored withdrawal request",
    true,
  ],
  [
    "seller-withdrawal-approved",
    "Withdrawal request approved",
    "The request was approved for processing. Approval does not mean that the bank has received the funds.",
    "Track withdrawal",
    "Stored withdrawal approval",
    true,
  ],
  [
    "seller-withdrawal-paid",
    "Withdrawal payment confirmed",
    "The provider confirmed the transfer. Review its reference, recipient amount and fees in your private history.",
    "View transfer",
    "Provider-confirmed withdrawal result",
    true,
  ],
  [
    "seller-withdrawal-failed",
    "Withdrawal needs attention",
    "The transfer failed. Review the recorded status and contact support before retrying.",
    "Review withdrawal",
    "Provider-confirmed failed withdrawal",
    true,
  ],

  [
    "seller-subscription-activated",
    "Your seller subscription is active",
    "Your monthly subscription payment was verified. Review your expiry date; seller verification is also required to sell.",
    "View subscription",
    "Provider-verified first subscription payment",
    true,
  ],
  [
    "seller-subscription-renewed",
    "Your seller subscription has been renewed",
    "Flutterwave confirmed your recurring renewal payment and your paid period was extended. Check your new expiry date.",
    "View renewed subscription",
    "Provider-verified recurring renewal payment",
    true,
  ],
  [
    "seller-subscription-expiring",
    "Your seller subscription expires soon",
    "Check your paid-through date. If automatic renewal is active, Flutterwave manages the next billing attempt. Otherwise, renew manually to continue selling.",
    "Manage subscription",
    "Reminder before the current paid period expires",
    true,
  ],
  [
    "seller-subscription-expired",
    "Your seller subscription has expired",
    "New selling and livestream activity are paused. Resubscribe to restore paid access; existing orders remain manageable.",
    "Resubscribe",
    "Confirmed expired paid period",
    true,
  ],
  [
    "seller-subscription-payment-failed",
    "Your subscription payment needs attention",
    "Flutterwave reported an unsuccessful renewal attempt. Check your current paid-through date and payment status. Cash N Carry will not make a separate card charge.",
    "Check subscription and retry",
    "Provider-verified failed subscription payment",
    true,
  ],
  [
    "seller-subscription-cancelled",
    "Your renewal cancellation is recorded",
    "Flutterwave confirmed that future automatic renewal is cancelled. Your paid access continues until the paid-through date below; you can authorise renewal again later.",
    "Manage subscription",
    "Provider-confirmed subscription cancellation",
    true,
  ],
  [
    "verification",
    "Verify your email",
    "Confirm your email to finish creating your account.",
    "Verify email",
    "Authentication verification link; expires in 1 hour",
    true,
  ],
  [
    "welcome",
    "Welcome to Cash N Carry",
    "Your email is verified. Discover stores and live shopping.",
    "Start discovering",
    "Successful first email verification",
    true,
  ],
  [
    "password-reset",
    "Reset your password",
    "Use your secure, single-use link to choose a new password.",
    "Reset password",
    "Authentication reset request; expires in 1 hour",
    true,
  ],
  [
    "password-changed",
    "Your password was changed",
    "Your password reset completed successfully.",
    "Review account",
    "Successful password reset completion",
    true,
  ],
  [
    "email-change-verification",
    "Verify your new email",
    "Confirm your new email address before it can replace the current address.",
    "Verify new email",
    "Email change is not currently offered by the account workflow",
    false,
  ],
  [
    "email-change-notice",
    "Email change requested",
    "A request was made to change your account email. Review it if you did not request this.",
    "Review account",
    "Email change is not currently offered by the account workflow",
    false,
  ],
  [
    "order-confirmation",
    "Your order was received",
    "Review your items, delivery fee and actual payment status.",
    "View order",
    "New stored order; pending payment is not a receipt",
    true,
  ],
  [
    "order-update",
    "Your order was confirmed",
    "The seller confirmed your order. Review the latest order and payment details.",
    "View order",
    "Stored order transition to confirmed",
    true,
  ],
  [
    "payment-receipt",
    "Your payment is verified",
    "Payment was independently verified on the server.",
    "View order",
    "Verified reference, amount, currency and successful provider status",
    true,
  ],
  [
    "payment-issue",
    "Payment needs attention",
    "Check the current payment status before taking further action.",
    "Check order status",
    "Verified checkout closure or uncertain payment reconciliation",
    true,
  ],
  [
    "seller-order",
    "A new order is ready to fulfil",
    "An eligible order is available in your Seller Centre.",
    "Open Seller Centre",
    "Cash on delivery order or server-verified online payment",
    true,
  ],
  [
    "dispatched",
    "Your order has been dispatched",
    "The seller updated your order to dispatched.",
    "Track order",
    "Stored order transition to shipped",
    true,
  ],
  [
    "pickup-ready",
    "Your order is ready for pickup",
    "The seller confirmed your order is ready for pickup.",
    "View pickup details",
    "Pickup readiness is not currently a stored fulfilment status",
    false,
  ],
  [
    "delivered",
    "Your order is marked delivered",
    "The seller has marked your order delivered. Contact support if there is a problem.",
    "View order",
    "Stored order transition to delivered",
    true,
  ],
  [
    "order-cancelled",
    "Your order was cancelled",
    "Review the cancellation and actual payment or refund status.",
    "View order",
    "Confirmed stored cancellation; uncertain payments remain pending",
    true,
  ],
  [
    "return-request",
    "Your return request was received",
    "Your request is recorded for review. It is not yet approved.",
    "View case",
    "Delivered order return case created",
    true,
  ],
  [
    "seller-return",
    "A return request needs review",
    "A customer opened a return case for an order from your store.",
    "Open Seller Centre",
    "Stored return case created",
    true,
  ],
  [
    "return-decision",
    "Your return case was updated",
    "Read the recorded decision and next steps for your case.",
    "View case",
    "Existing case review/resolution; no automatic return approval",
    true,
  ],
  [
    "refund-update",
    "Your refund request was updated",
    "Check the recorded refund status. Approval does not mean money has been refunded.",
    "View order",
    "Refund request, review, processing or provider reconciliation",
    true,
  ],
  [
    "seller-verification",
    "Your store verification was updated",
    "Review the status and any information requested by the reviewer.",
    "Open Seller Centre",
    "Submission or approved/rejected verification review",
    true,
  ],
  [
    "support-acknowledgement",
    "Your support case was received",
    "Your case is recorded. Sign in to view private details.",
    "View support case",
    "Stored customer order/support report created",
    true,
  ],
  [
    "support-response",
    "There is an update on your case",
    "Read the recorded response and next steps.",
    "View support case",
    "Case changed to in review or rejected with reviewer response",
    true,
  ],
  [
    "support-resolution",
    "Your support case was resolved",
    "A resolution has been recorded. Review it and contact support if you still need help.",
    "View support case",
    "Case changed to resolved with recorded resolution",
    true,
  ],
  [
    "restriction",
    "An account or listing restriction was recorded",
    "Review the reason and available support route.",
    "Get help",
    "Confirmed administrator suspension or listing/broadcast moderation",
    true,
  ],
  [
    "review-request",
    "How was your purchase?",
    "Your delivered purchase is eligible for a review.",
    "Review purchase",
    "One delivered-order review request; respects order-update preference",
    true,
  ],
  [
    "admin-alert",
    "An item needs administrator review",
    "Open the protected Admin Console to review the issue.",
    "Open Admin Console",
    "Verification queue, reported cases or payment discrepancy",
    true,
  ],
  [
    "notification",
    "An update from Cash N Carry",
    "Sign in to see your latest account updates.",
    "View account",
    "Existing transactional notification fallback",
    true,
  ],
] as const;
export const emailTemplates = definitions.map(
  ([id, title, preview, action, trigger, connected]) => ({
    id,
    title,
    subject: `${title} · ${brand.name}`,
    preview,
    action,
    trigger,
    connected,
  }),
);
export type TemplateId = (typeof definitions)[number][0];
export function escapeEmail(value: unknown): string {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
export function emailLink(
  value: string | undefined,
  fallback = "/account",
): string {
  try {
    const u = new URL(value || fallback, EMAIL_ORIGIN);
    if (
      ![
        EMAIL_ORIGIN,
        "https://cashncarryng.com",
        "https://revibe-commerce.ogundiyatemidayo1.chatgpt.site",
      ].includes(u.origin) ||
      u.username ||
      u.password
    )
      throw Error();
    u.protocol = "https:";
    u.host = "www.cashncarryng.com";
    return u.toString();
  } catch {
    return EMAIL_ORIGIN + fallback;
  }
}
export function naira(value: number) {
  return (
    "₦" +
    Number(value).toLocaleString("en-NG", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  );
}
function safeEmailImage(value?: string): string | undefined {
  if (!value) return undefined;
  try {
    const url = new URL(value, EMAIL_ORIGIN);
    if (url.protocol !== "https:" || url.username || url.password)
      return undefined;
    return url.toString();
  } catch {
    return undefined;
  }
}
export function renderEmail(
  id: TemplateId,
  data: EmailData = {},
  year = new Date().getUTCFullYear(),
) {
  const t = emailTemplates.find((t) => t.id === id);
  if (!t) throw Error("Unknown email template");
  const url = emailLink(
    data.actionUrl,
    id.startsWith("seller-verification-")
      ? "/seller/finance?tab=Activation"
      : id.startsWith("seller-withdrawal-")
        ? "/seller/finance?tab=Withdrawals"
        : id.startsWith("seller-subscription-")
          ? "/seller/finance?tab=Subscription"
          : id === "restriction"
            ? "/help"
            : id === "welcome"
              ? "/?browse=1#market"
              : "/account",
  );
  const greeting = data.name ? `Hello ${data.name},` : "Hello,";
  const security = [
    "verification",
    "password-reset",
    "email-change-verification",
    "email-change-notice",
    "password-changed",
  ].includes(id);
  const message =
    data.message ||
    (id === "verification"
      ? "Verify your email to finish creating your Cash N Carry account. This link expires in 1 hour. If it expires, request another verification email from Sign in."
      : id === "password-reset"
        ? "You requested a password reset. This link expires in 1 hour and can be used once. If it expires, request a new link from Forgot password."
        : t.preview);
  const securityNote = security
    ? id === "password-changed"
      ? "If you did not change your password, reset it immediately and contact Help."
      : "If you did not request this action, do not use this link. Visit Help if you have concerns."
    : "";
  const details = data.details || [];
  const items = data.items || [];
  const sandbox =
    Boolean(data.sandbox) ||
    details.some(
      ([k, v]) => k.toLowerCase() === "environment" && /test|sandbox/i.test(v),
    );
  const help =
    "For help, visit Help & contact. Sign in for private order or account enquiries. Never send passwords, card details or verification documents by email.";
  const action = data.actionLabel || t.action;
  const text = [
    data.sample
      ? "SAMPLE PREVIEW — illustrative data; no account or order action has occurred."
      : sandbox
        ? "TEST / SANDBOX — this message is not proof of a live payment."
        : "",
    brand.name,
    brand.tagline,
    t.title,
    greeting,
    message,
    ...details.map(([k, v]) => `${k}: ${v}`),
    ...items.map(
      (i) =>
        `${i.name}${i.variant ? ` (${i.variant})` : ""} × ${i.quantity} — ${naira(i.price * i.quantity)}`,
    ),
    data.expiresAt ? `Expires: ${data.expiresAt}` : "",
    `${action}: ${url}`,
    securityNote,
    help,
    `Website: ${EMAIL_ORIGIN}`,
    `Help: ${EMAIL_ORIGIN}/help`,
    `Privacy: ${EMAIL_ORIGIN}/privacy`,
    `© ${year} ${brand.name}`,
  ]
    .filter(Boolean)
    .join("\n\n");
  const statusKeys = new Set([
    "payment",
    "refund",
    "refund status",
    "order status",
  ]);
  const statusDetails = details.filter(([k]) =>
    statusKeys.has(k.toLowerCase()),
  );
  const regularDetails = details.filter(
    ([k]) => !statusKeys.has(k.toLowerCase()),
  );
  const detailHtml = regularDetails.length
    ? `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;margin:18px 0;border-top:1px solid #E5E7EB">${regularDetails.map(([k, v]) => (k.toLowerCase() === "total" ? `<tr><td style="padding:12px 8px 12px 0;vertical-align:top;border-top:1px solid #E5E7EB;font-size:15px;color:#1F2937;font-weight:bold;width:38%">${escapeEmail(k)}</td><td style="padding:12px 0;vertical-align:top;border-top:1px solid #E5E7EB;font-size:18px;color:#164B35;font-weight:bold;overflow-wrap:anywhere">${escapeEmail(v)}</td></tr>` : `<tr><td style="padding:10px 8px 10px 0;vertical-align:top;font-size:14px;color:#667085;width:38%">${escapeEmail(k)}</td><td style="padding:10px 0;vertical-align:top;font-size:14px;color:#1F2937;overflow-wrap:anywhere">${escapeEmail(v)}</td></tr>`)).join("")}</table>`
    : "";
  const statusHtml = statusDetails.length
    ? `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;margin:18px 0;background:#F8FAF9;border:1px solid #E5E7EB;border-radius:10px"><tr><td style="padding:14px 16px"><p style="margin:0 0 8px;color:#164B35;font-size:14px;font-weight:bold">${id === "order-cancelled" ? "Payment &amp; refund status" : "Status details"}</p><table role="presentation" width="100%" cellpadding="0" cellspacing="0">${statusDetails.map(([k, v]) => `<tr><td style="padding:5px 12px 5px 0;vertical-align:top;font-size:14px;color:#667085;width:34%">${escapeEmail(k)}</td><td style="padding:5px 0;vertical-align:top;font-size:14px;line-height:1.5;color:#1F2937;overflow-wrap:anywhere">${escapeEmail(v)}</td></tr>`).join("")}</table></td></tr></table>`
    : "";
  const itemsHtml = items.length
    ? `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;margin:16px 0;border-top:1px solid #E5E7EB;border-bottom:1px solid #E5E7EB">${items
        .map((i) => {
          const image = safeEmailImage(i.image);
          return `<tr>${image ? `<td width="64" style="width:64px;padding:12px 8px 12px 0;vertical-align:top"><img src="${escapeEmail(image)}" width="56" alt="" style="display:block;width:56px;max-width:56px;height:auto;border-radius:6px;border:1px solid #E5E7EB"></td>` : ""}<td style="padding:12px 8px 12px 0;font-size:14px;line-height:1.5;color:#1F2937;vertical-align:top"><strong>${escapeEmail(i.name)}</strong>${i.variant ? `<br><span style="color:#667085">${escapeEmail(i.variant)}</span>` : ""}<br><span style="color:#667085">Qty ${escapeEmail(i.quantity)}</span></td><td align="right" style="padding:12px 0;font-size:14px;color:#1F2937;white-space:nowrap;vertical-align:top">${escapeEmail(naira(i.price * i.quantity))}</td></tr>`;
        })
        .join("")}</table>`
    : "";
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeEmail(t.title)}</title><style>@media(max-width:600px){.email-card{padding:24px 18px!important}.email-outer{padding:18px 8px!important}.email-logo{width:210px!important}}a:focus{outline:3px solid #D65A30;outline-offset:3px}</style></head><body style="margin:0;background:#F5F7F8;font-family:Arial,Helvetica,sans-serif;color:#1F2937;font-size:16px;line-height:1.55"><div style="display:none;max-height:0;overflow:hidden;mso-hide:all">${escapeEmail(t.preview)}</div><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;background:#F5F7F8"><tr><td align="center" class="email-outer" style="padding:28px 16px"><!--[if mso]><table role="presentation" width="600"><tr><td><![endif]--><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;max-width:600px"><tr><td class="email-header" bgcolor="#FFFFFF" style="background:#FFFFFF;border:1px solid #E5E7EB;border-radius:14px;padding:14px 12px 12px;text-align:center"><img class="email-logo" src="${EMAIL_ORIGIN}${brand.emailLogo}" alt="Cash N Carry logo" width="220" style="display:block;width:220px;max-width:100%;height:auto;margin:0 auto"><p style="margin:7px 0 0;color:#164B35;font-size:13px">${brand.tagline}</p></td></tr><tr><td height="12" style="height:12px;line-height:12px;font-size:1px">&nbsp;</td></tr><tr><td class="email-card" style="background:#FFFFFF;border:1px solid #E5E7EB;border-radius:14px;padding:30px">${data.sample ? '<p style="margin:0 0 14px;padding:7px 10px;display:inline-block;background:#FFF4E5;border:1px solid #F2D6B3;border-radius:5px;color:#7A3E12;font-size:12px;font-weight:bold">SAMPLE PREVIEW · illustrative data only</p>' : sandbox ? '<p style="margin:0 0 14px;padding:7px 10px;display:inline-block;background:#FFF4E5;border:1px solid #F2D6B3;border-radius:5px;color:#7A3E12;font-size:12px;font-weight:bold">TEST / SANDBOX · not proof of a live payment</p>' : ""}<p style="margin:0;color:#9B3F23;font-size:12px;letter-spacing:1.3px;font-weight:bold">${security ? "ACCOUNT & SECURITY" : id.startsWith("order-") || ["payment-receipt", "payment-issue", "dispatched", "delivered"].includes(id) ? "ORDER UPDATE" : "CASH N CARRY UPDATE"}</p><h1 style="margin:7px 0 20px;color:#1F2937;font-size:27px;line-height:1.25">${escapeEmail(t.title)}</h1><p style="margin:0 0 14px;color:#1F2937">${escapeEmail(greeting)}</p><p style="margin:0 0 18px;color:#344054">${escapeEmail(message).replaceAll("\n", "<br>")}</p>${itemsHtml}${detailHtml}${statusHtml}${data.expiresAt ? `<p style="color:#7A3E12;font-size:14px">Expires: ${escapeEmail(data.expiresAt)}</p>` : ""}<table role="presentation" cellpadding="0" cellspacing="0" style="margin:22px 0 14px"><tr><td bgcolor="#164B35" style="background:#164B35;border-radius:8px;mso-padding-alt:14px 24px"><a href="${escapeEmail(url)}" style="display:inline-block;background:#164B35;border-radius:8px;padding:14px 24px;min-height:20px;color:#FFFFFF;text-decoration:none;font-weight:bold;line-height:24px">${escapeEmail(action)}</a></td></tr></table><p style="margin:0;font-size:13px;color:#5C6675">Button not working? Copy this link:<br><a href="${escapeEmail(url)}" style="color:#164B35;word-break:break-all">${escapeEmail(url)}</a></p>${securityNote ? `<p style="font-size:14px;color:#7A3E12">${escapeEmail(securityNote)}</p>` : ""}<hr style="border:0;border-top:1px solid #E5E7EB;margin:22px 0"><p style="font-size:14px;color:#344054;margin:0">${help.replace("Help & contact", `<a href="${EMAIL_ORIGIN}/help" style="color:#164B35">Help &amp; contact</a>`)}</p></td></tr><tr><td align="center" class="email-footer" style="padding:18px 12px 4px;color:#5C6675;font-size:13px;line-height:1.7"><strong style="color:#1F2937">Cash N Carry</strong><p style="margin:6px 0 0"><a href="${EMAIL_ORIGIN}" style="color:#164B35">Website</a> &nbsp;·&nbsp; <a href="${EMAIL_ORIGIN}/help" style="color:#164B35">Help Centre</a> &nbsp;·&nbsp; <a href="${EMAIL_ORIGIN}/privacy" style="color:#164B35">Privacy Policy</a></p><p style="margin:6px 0 0">© ${year} Cash N Carry</p></td></tr></table><!--[if mso]></td></tr></table><![endif]--></td></tr></table></body></html>`;
  return { subject: t.subject, preview: t.preview, html, text };
}
export function sampleEmail(id: TemplateId): EmailData {
  if (
    id.startsWith("seller-verification-") ||
    id.startsWith("seller-withdrawal-")
  )
    return {
      sample: true,
      name: "Sample seller",
      actionUrl: id.startsWith("seller-verification-")
        ? "/seller/finance?tab=Activation"
        : "/seller/finance?tab=Withdrawals",
      details: [
        ["Store", "Sample store"],
        ["Reference", "SAMPLE-PREVIEW"],
        ["Mode", "Illustrative preview — no actual payment or review"],
      ],
    };
  if (id.startsWith("seller-subscription-"))
    return {
      sample: true,
      name: "Sample seller",
      actionUrl: "/seller/finance?tab=Subscription",
      details: [
        ["Store", "Sample store"],
        ["Plan", "Cash N Carry Seller"],
        ["Monthly price", naira(2000) + " (illustrative)"],
        ["Access expires", "12 November 2030, 11:00 am WAT (sample)"],
        [
          "Billing",
          "Sandbox sample — provider confirmation determines renewal status",
        ],
        ["Verification", "Approved (sample)"],
        ["Payment mode", "SAMPLE / SANDBOX — no real payment"],
        ...(id === "seller-subscription-renewed" ||
        id === "seller-subscription-activated"
          ? [["Receipt reference", "SAMPLE-SUBSCRIPTION"] as [string, string]]
          : []),
      ],
    };
  const common: EmailData = {
    sample: true,
    name: "Sample customer",
    actionUrl: "/account",
  };
  if (
    ["verification", "password-reset", "email-change-verification"].includes(id)
  )
    return {
      ...common,
      actionUrl: "/sign-in?preview=sample",
      expiresAt: "Sample link — no usable token; real links expire in 1 hour",
    };
  if (
    [
      "order-confirmation",
      "payment-receipt",
      "payment-issue",
      "seller-order",
      "dispatched",
      "pickup-ready",
      "delivered",
      "order-cancelled",
      "review-request",
    ].includes(id)
  )
    if (id === "order-cancelled")
      return {
        ...common,
        actionUrl: "/order/sample-preview",
        items: [
          {
            name: "Sample product",
            variant: "Sample option",
            quantity: 2,
            price: 12500,
          },
        ],
        details: [
          ["Order", "SAMPLE-ORDER"],
          ["Seller", "Sample store"],
          ["Delivery fee", naira(1500)],
          ["Total", naira(26500)],
          ["Payment", "Pending — not yet verified"],
          ["Order status", "Cancelled (sample)"],
          [
            "Refund",
            "Payment requires reconciliation; refund status not confirmed",
          ],
        ],
      };
  return {
    ...common,
    actionUrl: "/order/sample-preview",
    items: [
      {
        name: "Sample product",
        variant: "Sample option",
        quantity: 2,
        price: 12500,
      },
    ],
    details: [
      ["Order", "SAMPLE-ORDER"],
      ["Seller", "Sample store"],
      ["Delivery fee", naira(1500)],
      ["Total", naira(26500)],
      [
        "Payment",
        id === "payment-receipt"
          ? "Verified success (sample)"
          : "Pending / check order (sample)",
      ],
    ],
  };
  if (id === "seller-verification")
    return {
      ...common,
      name: "Sample seller",
      actionUrl: "/seller/finance?tab=Activation",
      details: [
        ["Store", "Sample store"],
        ["Verification", "Submitted for review (sample)"],
      ],
    };
  if (id === "refund-update")
    return {
      ...common,
      details: [
        ["Refund", "Approved for processing (sample)"],
        ["Important", "Money has not yet been refunded."],
      ],
    };
  return {
    ...common,
    details: [
      ["Reference", "SAMPLE-CASE"],
      ["Status", "In review (sample)"],
    ],
    actionUrl: "/workspace?tab=Support",
  };
}
