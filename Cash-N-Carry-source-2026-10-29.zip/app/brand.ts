/** Public platform branding. Integration identifiers and the existing domain stay unchanged. */
export const brand = Object.freeze({
  name: "Cash N Carry",
  tagline: "Watch Live. Discover. Shop.",
  logo: "/brand/cash-n-carry-logo-transparent-v2.webp",
  logoDarkSurface: "/brand/cash-n-carry-logo-dark-surface-v2.webp",
  logoFallback: "/brand/cash-n-carry-logo-fallback-v2.jpg",
  emailLogo: "/brand/cash-n-carry-logo-fallback-v2.jpg",
  compactLogo: "/brand/cash-n-carry-logo-compact-v2.webp",
  symbol: "/brand/cash-n-carry-icon-transparent-v2.png",
  appIcon: "/brand/cash-n-carry-icon-v2-512.png",
  logoWidth: 1319,
  logoHeight: 427,
  iconVersion: "v2",
  accent: "#B94D32",
  iconBackground: "#164B35",
  filePrefix: "cash-n-carry",
  description:
    "Shop Nigerian sellers on Cash N Carry. Watch live product demonstrations, ask questions, discover local businesses and buy products online in naira.",
});

/** Historical platform wording in editable policies must never leak publicly. */
export function platformWording(text: string): string {
  return text.replace(/revibe/gi, brand.name);
}
