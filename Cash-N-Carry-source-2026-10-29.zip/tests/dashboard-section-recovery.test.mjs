import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const ast=ts.createSourceFile('panel.tsx',readFileSync('app/seller/competitive-panel.tsx','utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
let callback;
function walk(n){if(ts.isVariableDeclaration(n)&&n.name.getText(ast)==='load')callback=n.initializer.arguments[0].getText(ast);ts.forEachChild(n,walk)}
walk(ast);
test('one failed growth endpoint leaves remaining Seller Centre sections usable',async()=>{
 let error='',commerce,bundles,affiliate;const urls=[];
 const ctx={days:30,AbortSignal,setError:v=>error=v,setCommerce:v=>commerce=v,setBundles:v=>bundles=v,setBundleItems:()=>{},setAnalytics:()=>{},setFounding:()=>{},setAffiliate:v=>affiliate=v,fetch:async(url,options)=>{urls.push(url);assert(options.signal);if(url.includes('analytics'))return Response.json({error:'Unavailable'},{status:503});if(url.includes('product-bundles'))return Response.json({bundles:[{id:'bundle'}],items:[]});if(url.includes('affiliate'))return Response.json({creators:[]});return Response.json({user:{id:'seller'}})}};
 const code=ts.transpileModule('return ('+callback+')();',{compilerOptions:{target:ts.ScriptTarget.ES2023}}).outputText;
 await new Function(...Object.keys(ctx),code)(...Object.values(ctx));
 assert.equal(commerce.user.id,'seller');assert.equal(bundles[0].id,'bundle');assert.deepEqual(affiliate.creators,[]);assert.equal(error,'Analytics: Unavailable');
 assert(!urls.some(url=>url.includes('live-deals')||url.includes('live-auctions')));
});
