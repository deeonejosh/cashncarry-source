import test from "node:test";
import assert from "node:assert/strict";
import { adjacentLiveStream, liveStreamCandidates } from "../app/live-stream-navigation.mjs";

const streams = [
  { id: "older", status: "live", created: "2026-10-21T10:00:00Z" },
  { id: "newer", status: "live", created: "2026-10-22T10:00:00Z" },
  { id: "external", status: "external", created: "2026-10-20T10:00:00Z" },
  { id: "scheduled", status: "scheduled", created: "2026-10-23T10:00:00Z" },
  { id: "ended", status: "ended", replay: "/replay", created: "2026-10-24T10:00:00Z" },
  { id: "newer", status: "live", created: "2026-10-22T10:00:00Z" },
];

test("swipe navigation uses only active streams, newest first, without duplicates", () => {
  assert.deepEqual(liveStreamCandidates(streams).map(({ id }) => id), ["newer", "older", "external"]);
});

test("swipe up advances and swipe down returns, wrapping around the active stream set", () => {
  assert.equal(adjacentLiveStream(streams, "newer", 1).id, "older");
  assert.equal(adjacentLiveStream(streams, "newer", -1).id, "external");
  assert.equal(adjacentLiveStream(streams, "external", 1).id, "newer");
});

test("navigation safely reports no adjacent stream when only one live stream exists", () => {
  assert.equal(adjacentLiveStream([{ id: "only", status: "live" }], "only", 1), null);
});
