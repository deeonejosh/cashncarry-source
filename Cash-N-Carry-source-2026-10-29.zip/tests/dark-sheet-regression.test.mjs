import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const component=readFileSync(new URL('../app/live-overlay.tsx',import.meta.url),'utf8');
const css=readFileSync(new URL('../app/shop-redesign.css',import.meta.url),'utf8');
test('LiveSheet traps keyboard focus and supports Escape',()=>{
  assert.match(component,/e\.key === "Escape"/);
  assert.match(component,/e\.key === "Tab"/);
  assert.match(component,/tabIndex=\{-1\}/);
  assert.match(component,/controls\.includes\(document\.activeElement/);
});
test('LiveSheet restores scroll and previous focus after closing',()=>{
  assert.match(component,/document\.body\.style\.overflow = "hidden"/);
  assert.match(component,/document\.body\.style\.overflow = previousOverflow/);
  assert.match(component,/previous\?\.isConnected/);
});
test('Livestream sheet uses dark glass and safe-area controls',()=>{
  assert.match(css,/background: rgba\(12, 16, 14, \.92\)/);
  assert.match(css,/backdrop-filter: blur\(12px\)/);
  assert.match(css,/prefers-reduced-transparency/);
  assert.match(css,/min-width: 44px/);
});
