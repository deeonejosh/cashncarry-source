import test from 'node:test';
import assert from 'node:assert/strict';
import ts from 'typescript';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';

const source = readFileSync('app/canonical-host.ts', 'utf8');
const sandbox = { exports: {}, URL, Request, Response };
vm.runInNewContext(
  ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText,
  sandbox,
);
const canonicalHostRedirect = sandbox.exports.canonicalHostRedirect;

test('apex HTML navigation redirects to www while preserving route and query', () => {
  const response = canonicalHostRedirect(
    new Request('https://cashncarryng.com/store/market?ref=share#reviews', {
      headers: { accept: 'text/html,application/xhtml+xml' },
    }),
  );
  assert.equal(response.status, 308);
  assert.equal(
    response.headers.get('location'),
    'https://www.cashncarryng.com/store/market?ref=share#reviews',
  );
});

test('API, POST, non-HTML and insecure requests are not redirected', () => {
  const cases = [
    new Request('https://cashncarryng.com/api/commerce', {
      headers: { accept: 'text/html' },
    }),
    new Request('https://cashncarryng.com/sign-in', {
      method: 'POST',
      headers: { accept: 'text/html' },
    }),
    new Request('https://cashncarryng.com/product/1', {
      headers: { accept: 'application/json' },
    }),
    new Request('http://cashncarryng.com/', {
      headers: { accept: 'text/html' },
    }),
  ];
  for (const request of cases) assert.equal(canonicalHostRedirect(request), null);
});

test('www canonical requests are not redirected again', () => {
  assert.equal(
    canonicalHostRedirect(
      new Request('https://www.cashncarryng.com/', {
        headers: { accept: 'text/html' },
      }),
    ),
    null,
  );
});
