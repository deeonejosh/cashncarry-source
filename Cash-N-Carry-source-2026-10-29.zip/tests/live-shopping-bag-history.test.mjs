import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {sourceModule} from './load-route.mjs';
import {onboardFixtureSellers} from './seller-fixture.mjs';
const db=new DatabaseSync(':memory:');
for(const file of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+file,'utf8'));
class Q{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Q(this.sql,args)}async first(){return db.prepare(this.sql).get(...this.args)||null}async all(){return{results:db.prepare(this.sql).all(...this.args)}}async run(){return{meta:db.prepare(this.sql).run(...this.args)}}}
globalThis.testEnv={DB:{prepare:sql=>new Q(sql),batch:async stmts=>{db.exec('BEGIN');try{const result=[];for(const stmt of stmts)result.push(await stmt.run());db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}}}};
globalThis.testUser={userId:'seller',email:'seller@test.invalid',displayName:'Seller',fullName:'Seller'};
db.exec("INSERT INTO profiles(id,email,name,created,last_seen) VALUES('seller','seller@test.invalid','Seller','now','now');INSERT INTO stores(id,owner,name,category,location,created) VALUES('store','seller','Shop','Tech','Lagos','now');INSERT INTO products(id,store,name,description,category,price,stock,image,created) VALUES('item','store','Item','Item','Tech',100,4,'https://image.test/item','now'),('bundle-product','store','Bundle','Includes two products','Bundles',150,2,'https://image.test/bundle','now');INSERT INTO streams(id,store,title,url,status,provider,created) VALUES('stream','store','Live','https://provider.test/play','live','external','now');");
onboardFixtureSellers(db);
const api=await import(sourceModule('app/api/commerce/route.ts'));
const pin=async product=>{const response=await api.POST(new Request('https://app.test/api/commerce',{method:'POST',headers:{origin:'https://app.test','content-type':'application/json'},body:JSON.stringify({action:'pin',id:'stream',product})}));return response;};
test('switching the single live pin replaces the previous product or bundle',async()=>{
 assert.equal((await pin('item')).status,200);assert.equal((await pin('bundle-product')).status,200);assert.equal((await pin('bundle-product')).status,200);
 const row=db.prepare("SELECT product,featured FROM streams WHERE id='stream'").get();assert.equal(row.product,'bundle-product');assert.deepEqual(JSON.parse(row.featured),['bundle-product']);
 const viewer=await (await api.GET(new Request('https://app.test/api/commerce?stream=stream'))).json();assert.deepEqual(viewer.products.map(p=>p.id),['bundle-product']);
});
test('a new live pin replaces legacy multi-product featured state',async()=>{
 const legacy=['item',...Array.from({length:29},(_,i)=>'prior-'+i)];db.prepare("UPDATE streams SET featured=?,product='item' WHERE id='stream'").run(JSON.stringify(legacy));assert.equal((await pin('bundle-product')).status,200);assert.equal(db.prepare("SELECT product FROM streams WHERE id='stream'").get().product,'bundle-product');assert.deepEqual(JSON.parse(db.prepare("SELECT featured FROM streams WHERE id='stream'").get().featured),['bundle-product']);
});

test('seller pin and repeated unpin are reflected in independent buyer API reads',async()=>{
 db.exec("UPDATE streams SET product='',featured='[]' WHERE id='stream'");
 assert.equal((await pin('item')).status,200);
 globalThis.testUser={userId:'buyer',email:'buyer@test.invalid'};
 let viewer=await(await api.GET(new Request('https://app.test/api/commerce?stream=stream'))).json();assert.equal(viewer.stream.product,'item');assert.equal(viewer.products.find(p=>p.id==='item').price,100);
 globalThis.testUser={userId:'seller',email:'seller@test.invalid'};assert.equal((await pin('')).status,200);assert.equal((await pin('')).status,200);
 globalThis.testUser={userId:'buyer',email:'buyer@test.invalid'};
 viewer=await(await api.GET(new Request('https://app.test/api/commerce?stream=stream'))).json();assert.equal(viewer.stream.product,'');assert(!viewer.products.some(p=>p.id==='item'));
 globalThis.testUser={userId:'seller',email:'seller@test.invalid'};
 db.exec("UPDATE products SET stock=0 WHERE id='item'");assert.equal((await pin('item')).status,400);assert.equal(db.prepare("SELECT product FROM streams WHERE id='stream'").get().product,'');
});
