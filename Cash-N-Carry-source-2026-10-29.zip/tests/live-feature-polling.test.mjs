import test from 'node:test';
import assert from 'node:assert/strict';
import {sourceModule} from './load-route.mjs';
const {startLiveFeaturePolling}=await import(sourceModule('app/live-feature-polling.ts'));
test('live offer polling prevents overlap, pauses hidden pages, times out and aborts on exit',async()=>{
 const old={fetch:global.fetch,document:global.document,setInterval:global.setInterval,clearInterval:global.clearInterval,setTimeout:global.setTimeout,clearTimeout:global.clearTimeout};
 let tick,deadline,visibility,calls=[],received=[],removed=false;
 global.document={visibilityState:'visible',addEventListener:(_,fn)=>visibility=fn,removeEventListener:()=>removed=true};
 global.setInterval=fn=>(tick=fn,1);global.clearInterval=()=>{};global.setTimeout=fn=>(deadline=fn,2);global.clearTimeout=()=>{};
 global.fetch=(url,options)=>new Promise((resolve,reject)=>{calls.push({url,options,resolve});options.signal.addEventListener('abort',()=>reject(new Error('aborted')))});
 try{
  const stop=startLiveFeaturePolling('/api/live-deals?stream=test',d=>received.push(d));
  assert.equal(calls.length,1);await tick();assert.equal(calls.length,1);
  deadline();await new Promise(resolve=>old.setTimeout(resolve,0));assert(calls[0].options.signal.aborted);
  global.document.visibilityState='hidden';visibility();await tick();assert.equal(calls.length,1);
  global.document.visibilityState='visible';visibility();assert.equal(calls.length,2);
  calls[1].resolve({ok:true,json:async()=>({deals:[{id:'real-response'}]})});await new Promise(resolve=>old.setTimeout(resolve,0));assert.equal(received[0].deals[0].id,'real-response');
   void tick();assert.equal(calls.length,3);stop();assert(calls[2].options.signal.aborted);assert(removed);await new Promise(resolve=>old.setTimeout(resolve,0));await tick();assert.equal(calls.length,3);
  }finally{Object.assign(global,old)}
});

test('buyer deal matching synchronizes active deals and tolerates minor client clock skew', async () => {
  const deals = [
    {
      id: 'deal-active-skewed',
      product: 'prod-1',
      stream: 'stream-1',
      promo_price: 1500,
      max_quantity: 10,
      sold_quantity: 2,
      status: 'active',
      starts_at: new Date(Date.now() + 3000).toISOString(),
      ends_at: new Date(Date.now() + 600000).toISOString(),
    },
    {
      id: 'deal-expired',
      product: 'prod-2',
      stream: 'stream-1',
      promo_price: 800,
      max_quantity: 5,
      sold_quantity: 1,
      status: 'active',
      starts_at: new Date(Date.now() - 600000).toISOString(),
      ends_at: new Date(Date.now() - 1000).toISOString(),
    },
  ];
  const clock = Date.now();
  const dealFor = (productId) =>
    (Array.isArray(deals) ? deals : []).find(
      (d) =>
        d.product === productId &&
        (d.status === 'active' || new Date(d.starts_at).getTime() <= clock + 10000) &&
        new Date(d.ends_at).getTime() > clock &&
        Number(d.sold_quantity) < Number(d.max_quantity)
    );

  const matched = dealFor('prod-1');
  assert.ok(matched, 'Active deal with 3s skew should match');
  assert.equal(matched.id, 'deal-active-skewed');

  const expired = dealFor('prod-2');
  assert.equal(expired, undefined, 'Expired deal must not match');
});

