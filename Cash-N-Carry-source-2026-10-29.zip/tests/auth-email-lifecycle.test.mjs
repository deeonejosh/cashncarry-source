import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import ts from "typescript";
import { betterAuth } from "better-auth";
import { createEmailVerificationToken } from "better-auth/api";
import { memoryAdapter } from "better-auth/adapters/memory";
import { sourceModule } from "./load-route.mjs";
const db = new DatabaseSync(":memory:");
for (const f of readdirSync("drizzle")
  .filter((f) => f.endsWith(".sql"))
  .sort())
  db.exec(readFileSync("drizzle/" + f, "utf8"));
class Query {
  constructor(sql, args = []) {
    this.sql = sql;
    this.args = args;
  }
  bind(...args) {
    return new Query(this.sql, args);
  }
  async first() {
    return db.prepare(this.sql).get(...this.args) || null;
  }
  async all() {
    return { results: db.prepare(this.sql).all(...this.args) };
  }
  async run() {
    return db.prepare(this.sql).run(...this.args);
  }
}
globalThis.authEmailEnv = {
  SITE_URL: "https://cashncarryng.com",
  BETTER_AUTH_SECRET: "isolated-auth-fixture-secret-32-bytes-long",
  RESEND_API_KEY: "fixture-sending-key",
  EMAIL_FROM: "notifications@cashncarryng.com",
  DB: { prepare: (sql) => new Query(sql) },
};
let source = readFileSync("app/auth.ts", "utf8").replace(
  /import[\s\S]*?from\s*["'][^"']+["'];/g,
  "",
);
const imports = [
  ["getEmailConfig", "app/email-config.ts"],
  ["renderEmail,emailTemplates", "app/email-templates.ts"],
  ["emailReplyTo", "app/email-reply-to.ts"],
  ["queueTemplate,flushEmails", "app/notifications.ts"],
  ["brand", "app/brand.ts"],
]
  .map(
    ([names, path]) =>
      `import {${names}} from ${JSON.stringify(sourceModule(path, "authEmailEnv"))};`,
  )
  .join("");
source =
  `import {twoFactor} from "${new URL("../node_modules/better-auth/dist/plugins/index.mjs", import.meta.url).href}";` + imports +
  `const env=globalThis.authEmailEnv;const MIN_PASSWORD_LENGTH=12;const authUser={},authSession={},authAccount={},authVerification={},authTwoFactor={};const getDb=()=>({});const drizzleAdapter=()=>({});const chatGptAdminMfa=()=>({id:"cash-n-carry-chatgpt-admin-mfa"});const betterAuth=config=>config;` +
  source;
const js = ts.transpileModule(source, {
  compilerOptions: {
    target: ts.ScriptTarget.ES2023,
    module: ts.ModuleKind.ESNext,
  },
}).outputText;
const options = await import(
  "data:text/javascript;base64," + Buffer.from(js).toString("base64")
);
const captured = [];
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, request) => {
  assert.equal(url, "https://api.resend.com/emails");
  captured.push(JSON.parse(request.body));
  return Response.json({ id: "fixture-provider-" + captured.length });
};
globalThis.testSendEmail = options.sendEmail;
const memory = { user: [], session: [], account: [], verification: [] };
let auth;
const post = async (path, body) =>
  auth.handler(
    new Request("https://cashncarryng.com/api/auth/" + path, {
      method: "POST",
      headers: {
        origin: "https://cashncarryng.com",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    }),
  );
const link = (template) =>
  captured
    .filter((m) => m.tags?.some((t) => t.value === template))
    .at(-1)
    .text.match(/(?:Verify email|Reset password): (https:\/\/[^\s]+)/)[1];
test("actual isolated auth signup sends expiring verification; verification welcomes once and reset is single-use", async () => {
  const config = await options.getAuth();
  assert.equal(config.emailVerification.expiresIn, 3600);
  assert.equal(config.emailAndPassword.resetPasswordTokenExpiresIn, 3600);
  auth = betterAuth({
    ...config,
    database: memoryAdapter(memory),
    rateLimit: { enabled: false },
    logger: { disabled: true },
  });
  const signup = await post("sign-up/email", {
    name: "Controlled test account",
    email: "controlled-auth@example.invalid",
    password: "isolated-password-123",
    callbackURL: "/sign-in?verified=1",
  });
  assert.equal(signup.status, 200);
  assert.equal(captured.length, 1);
  const verification = new URL(link("verification"));
  assert.equal(verification.origin, "https://www.cashncarryng.com");
  const jwt = JSON.parse(
    Buffer.from(
      verification.searchParams.get("token").split(".")[1],
      "base64url",
    ).toString(),
  );
  assert(jwt.exp - jwt.iat === 3600);
  const expiredVerification = await createEmailVerificationToken(
    globalThis.authEmailEnv.BETTER_AUTH_SECRET,
    "controlled-auth@example.invalid",
    undefined,
    -1,
  );
  const expiredResponse = await auth.handler(
    new Request(
      "https://cashncarryng.com/api/auth/verify-email?token=" +
        expiredVerification +
        "&callbackURL=%2Fsign-in",
    ),
  );
  assert.equal(expiredResponse.status, 302);
  assert.match(expiredResponse.headers.get("location"), /TOKEN_EXPIRED/);
  assert.equal(memory.user[0].emailVerified, false);
  const denied = await post("sign-in/email", {
    email: "controlled-auth@example.invalid",
    password: "isolated-password-123",
  });
  assert.equal(denied.status, 403);
  const verify = await auth.handler(new Request(verification));
  assert.equal(verify.status, 302);
  assert.equal(memory.user[0].emailVerified, true);
  assert.equal(
    db
      .prepare("SELECT count(*) n FROM email_outbox WHERE template='welcome'")
      .get().n,
    1,
  );
  await auth.handler(new Request(verification));
  assert.equal(
    db
      .prepare("SELECT count(*) n FROM email_outbox WHERE template='welcome'")
      .get().n,
    1,
  );
  const reset = await post("request-password-reset", {
    email: "controlled-auth@example.invalid",
    redirectTo: "https://cashncarryng.com/forgot-password",
  });
  assert.equal(reset.status, 200);
  const resetUrl = new URL(link("password-reset"));
  let token = resetUrl.pathname.split("/").at(-1);
  // Better Auth validates the emailed reset path before redirecting to the application.
  const resetRedirect = await auth.handler(new Request(resetUrl));
  assert.equal(resetRedirect.status, 302);
  const destination = new URL(resetRedirect.headers.get("location"));
  token = destination.searchParams.get("token");
  assert(token);
  const completed = await post("reset-password", {
    token,
    newPassword: "new-isolated-password-123",
  });
  assert.equal(completed.status, 200);
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE template='password-changed'",
      )
      .get().n,
    1,
  );
  const repeated = await post("reset-password", {
    token,
    newPassword: "another-password-123",
  });
  assert.equal(repeated.status, 400);
  assert.equal(
    db
      .prepare(
        "SELECT count(*) n FROM email_outbox WHERE template='password-changed'",
      )
      .get().n,
    1,
  );
  const signedIn = await post("sign-in/email", {
    email: "controlled-auth@example.invalid",
    password: "new-isolated-password-123",
  });
  assert.equal(signedIn.status, 200);
  assert.match(signedIn.headers.get("set-cookie"), /Secure/);
  // Force the persisted reset token to expire and verify the real auth implementation rejects it.
  await post("request-password-reset", {
    email: "controlled-auth@example.invalid",
    redirectTo: "https://cashncarryng.com/forgot-password",
  });
  const expiredLink = new URL(link("password-reset"));
  const expiredToken = expiredLink.pathname.split("/").at(-1);
  const stored = memory.verification.find(
    (v) => v.identifier === "reset-password:" + expiredToken,
  );
  assert(stored);
  stored.expiresAt = new Date(Date.now() - 1000);
  assert.equal(
    (
      await post("reset-password", {
        token: expiredToken,
        newPassword: "never-used-password-123",
      })
    ).status,
    400,
  );
});
test.after(() => {
  globalThis.fetch = realFetch;
  db.close();
});
