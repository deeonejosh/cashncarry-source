import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import { onboardFixtureSellers } from "./seller-fixture.mjs";
import { sourceModule } from "./load-route.mjs";

function database() {
  const db = new DatabaseSync(":memory:");
  for (const file of readdirSync("drizzle").filter((name) => name.endsWith(".sql")).sort())
    db.exec(readFileSync(`drizzle/${file}`, "utf8"));
  db.exec("INSERT INTO profiles(id,email,name,created,last_seen) VALUES('seller','seller@example.invalid','Seller','now','now'),('buyer','buyer@example.invalid','Buyer','now','now'); INSERT INTO stores(id,owner,name,category,location,created) VALUES('store','seller','Shop','Goods','Lagos','now');");
  onboardFixtureSellers(db);
  db.exec("INSERT INTO streams(id,store,title,url,status,provider,heartbeat,created) VALUES('stream','store','Live','','live','external','now','now');");
  db.exec("ALTER TABLE streams ADD COLUMN pinned_auction TEXT NOT NULL DEFAULT ''; ALTER TABLE streams ADD COLUMN pinned_bundle TEXT NOT NULL DEFAULT ''; ALTER TABLE streams ADD COLUMN pinned_bundle_ends_at TEXT NOT NULL DEFAULT '';");
  return db;
}

function testEnvironment(db){
  class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args);}async first(){return db.prepare(this.sql).get(...this.args)||null;}async all(){return{results:db.prepare(this.sql).all(...this.args)};}async run(){return{meta:db.prepare(this.sql).run(...this.args)};}}
  return{FLW_MODE:"test",FLW_SECRET_KEY:"FLWSECK_TEST-auction-fixture",FLW_WEBHOOK_HASH:"fixture",SITE_URL:"https://shop.test",DB:{prepare(sql){return new Statement(sql);},async batch(statements){db.exec("BEGIN");try{const result=[];for(const statement of statements)result.push(await statement.run());db.exec("COMMIT");return result;}catch(error){db.exec("ROLLBACK");throw error;}}}};
}

function addProduct(db, id, price, stock) {
  db.prepare("INSERT INTO products(id,store,name,description,category,price,stock,image,active,created) VALUES(?, 'store', ?, '', 'Goods', ?, ?, '/image',1,'now')").run(id, id, price, stock);
}

function addOrder(db, id, payment = "flutterwave") {
  db.prepare("INSERT INTO orders(id,buyer,store,name,phone,address,total,status,payment,payment_status,delivery_fee,delivery_state,created,seller_activation_required) VALUES(?,'buyer','store','Buyer','','',1000,'placed',?,'pending',0,'Lagos','now',1)").run(id, payment);
}

test("migration installs six competitive feature domains without destructive changes", () => {
  const db = database();
  const tables = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((x) => x.name));
  for (const table of ["livestream_deals", "seller_analytics_events", "product_bundles", "creator_profiles", "affiliate_partnerships", "affiliate_commissions", "live_auctions", "auction_bids", "founding_enrollments"])
    assert(tables.has(table), `missing ${table}`);
  assert.equal(db.prepare("SELECT enabled,duration_days FROM founding_program WHERE id=1").get().enabled, 0);
  assert.equal(db.prepare("SELECT duration_days FROM founding_program WHERE id=1").get().duration_days, 30);
});

test("live deals reject invalid price, overlapping windows and promotional oversell; cancelled orders restore capacity", () => {
  const db = database(); addProduct(db, "item", 10000, 3);
  const start = new Date(Date.now() - 1000).toISOString(), end = new Date(Date.now() + 60000).toISOString();
  db.prepare("INSERT INTO livestream_deals(id,store,product,stream,promo_price,max_quantity,starts_at,ends_at,status,created,updated) VALUES('deal','store','item','stream',7000,2,?,?,'active','now','now')").run(start, end);
  assert.throws(() => db.prepare("INSERT INTO livestream_deals(id,store,product,stream,promo_price,max_quantity,starts_at,ends_at,status,created,updated) VALUES('overlap','store','item','stream',6000,1,?,?,'scheduled','now','now')").run(start, end), /Overlapping/);
  addOrder(db, "deal-order");
  db.prepare("INSERT INTO order_deal_snapshots(order_id,deal,product,quantity,price) VALUES('deal-order','deal','item',2,7000)").run();
  assert.equal(db.prepare("SELECT sold_quantity FROM livestream_deals WHERE id='deal'").get().sold_quantity, 2);
  addOrder(db, "deal-order-2");
  assert.throws(() => db.prepare("INSERT INTO order_deal_snapshots(order_id,deal,product,quantity,price) VALUES('deal-order-2','deal','item',1,7000)").run(), /unavailable/);
  db.prepare("UPDATE orders SET status='cancelled' WHERE id='deal-order'").run();
  assert.equal(db.prepare("SELECT sold_quantity FROM livestream_deals WHERE id='deal'").get().sold_quantity, 0);
});

test("bundle component ownership and inventory are enforced and immutable snapshots restore stock", () => {
  const db = database(); addProduct(db, "one", 2000, 5); addProduct(db, "two", 3000, 4); addProduct(db, "bundle-product", 4000, 2);
  db.exec("INSERT INTO product_bundles(id,store,product,title,description,image,price,active,created,updated) VALUES('bundle','store','bundle-product','Pair','','/image',4000,1,'now','now'); INSERT INTO product_bundle_items(bundle,product,quantity,name_snapshot,price_snapshot) VALUES('bundle','one',2,'one',2000),('bundle','two',1,'two',3000);");
  assert.throws(() => db.exec("INSERT INTO product_bundle_items(bundle,product,quantity,name_snapshot,price_snapshot) VALUES('bundle','bundle-product',1,'bundle',4000)"), /Invalid bundle component/);
  addOrder(db, "bundle-order");
  db.prepare("INSERT INTO bundle_order_snapshots(order_id,bundle,title,contents,bundle_price) VALUES('bundle-order','bundle','Pair',?,4000)").run(JSON.stringify([{id:"one",quantity:2},{id:"two",quantity:1}]));
  db.prepare("INSERT INTO order_items(id,order_id,product,name,price,quantity,variant) VALUES('oi','bundle-order','bundle-product','Pair',4000,1,'')").run();
  assert.equal(db.prepare("SELECT stock FROM products WHERE id='one'").get().stock, 3);
  assert.equal(db.prepare("SELECT stock FROM products WHERE id='two'").get().stock, 3);
  db.prepare("UPDATE orders SET status='cancelled' WHERE id='bundle-order'").run();
  assert.equal(db.prepare("SELECT stock FROM products WHERE id='one'").get().stock, 5);
  assert.equal(db.prepare("SELECT stock FROM products WHERE id='two'").get().stock, 4);
});

test("analytics deduplication and affiliate commission states exclude unpaid orders", () => {
  const db = database(); addProduct(db, "item", 10000, 3);
  db.prepare("INSERT INTO seller_analytics_events(id,store,product,stream,visitor,event,day,created) VALUES('e1','store','item','stream','visitor','product_view','2026-10-13','now')").run();
  assert.throws(() => db.prepare("INSERT INTO seller_analytics_events(id,store,product,stream,visitor,event,day,created) VALUES('e2','store','item','stream','visitor','product_view','2026-10-13','now')").run(), /UNIQUE/);
  db.exec("INSERT INTO creator_profiles(user,display_name,created,updated) VALUES('creator','Creator','now','now'); INSERT INTO affiliate_partnerships(id,creator,store,product,commission_bps,status,created,updated) VALUES('partnership','creator','store','item',1000,'approved','now','now');");
  addOrder(db, "affiliate-order");
  db.prepare("INSERT INTO affiliate_commissions(id,partnership,order_id,amount,created,updated) VALUES('commission','partnership','affiliate-order',1000,'now','now')").run();
  assert.equal(db.prepare("SELECT status FROM affiliate_commissions WHERE id='commission'").get().status, "pending");
  db.prepare("UPDATE orders SET status='cancelled' WHERE id='affiliate-order'").run();
  assert.equal(db.prepare("SELECT status FROM affiliate_commissions WHERE id='commission'").get().status, "reversed");
});

test("ended livestream recap returns recorded taps and viewer peak only to its store owner", async () => {
  const db=database();addProduct(db,"item",10000,3);
  db.exec("INSERT INTO stores(id,owner,name,category,location,created) VALUES('other-store','buyer','Other Shop','Goods','Lagos','now');");
  db.exec("INSERT INTO seller_analytics_events(id,store,product,stream,visitor,event,day,created) VALUES('tap-1','store','item','stream','visitor-1','product_click','2026-10-22','now'),('tap-2','store','item','stream','visitor-2','product_click','2026-10-22','now'),('like-1','store','','stream','visitor-3','livestream_like','2026-10-22','now'); INSERT INTO livestream_peak_metrics(stream,day,peak_viewers,sampled_at) VALUES('stream','2026-10-22',128,'now');");
  globalThis.testEnv=testEnvironment(db);
  const api=await import(sourceModule("app/api/seller-analytics/route.ts"));
  const get=async()=>api.GET(new Request("https://shop.test/api/seller-analytics?stream=stream"));
  globalThis.testUser={userId:"seller",email:"seller@example.invalid"};
  const own=await get();assert.equal(own.status,200);assert.deepEqual(await own.json(),{stream:"stream",productTaps:2,addToCart:0,comments:0,confirmedOrders:0,verifiedSales:0,peakViewers:128,likes:1});
  globalThis.testUser={userId:"buyer",email:"buyer@example.invalid"};
  const foreign=await get();assert.equal(foreign.status,404);assert.match((await foreign.json()).error,/unavailable/);
});

test("auction API validates authenticated bids, deduplicates requests and creates only an unpaid winner order", async () => {
  const db=database();addProduct(db,"auction-item",10000,2);
  db.prepare("UPDATE stores SET coverage='[\"Lagos\"]',shipping_fee=500 WHERE id='store'").run();
  globalThis.testEnv=testEnvironment(db);
  const api=await import(sourceModule("app/api/live-auctions/route.ts"));
  const user=(id)=>globalThis.testUser=id?{userId:id,email:`${id}@example.invalid`,displayName:id,fullName:id}:null;
  const post=async(body)=>{const response=await api.POST(new Request("https://shop.test/api/live-auctions",{method:"POST",headers:{origin:"https://shop.test","Content-Type":"application/json"},body:JSON.stringify(body)}));return{status:response.status,body:await response.json()};};
  const get=async(path)=>{const response=await api.GET(new Request(`https://shop.test${path}`));return{status:response.status,body:await response.json()};};
  user("seller");
  const startsAt=new Date(Date.now()+1000).toISOString(),endsAt=new Date(Date.now()+8000).toISOString();
  const created=await post({action:"create",product:"auction-item",stream:"stream",startPrice:1000,increment:100,reservePrice:1200,startsAt,endsAt});
  assert.equal(created.status,200,JSON.stringify(created.body));
  const auction=created.body.id;
  const duplicateAuction=await post({action:"create",product:"auction-item",stream:"stream",startPrice:1000,increment:100,reservePrice:1200,startsAt,endsAt});
  assert.equal(duplicateAuction.status,200,JSON.stringify(duplicateAuction.body));
  assert.equal(duplicateAuction.body.id,auction,"retries reuse the one open auction for a product in this stream");
  assert.equal(duplicateAuction.body.duplicate,true);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM live_auctions WHERE stream='stream' AND product='auction-item' AND status IN ('active','scheduled')").get().n,1,"duplicate saves cannot create extra active auctions");
  assert.equal(db.prepare("SELECT pinned_auction FROM streams WHERE id='stream'").get().pinned_auction,auction,"new in-stream auction is featured immediately");
  db.prepare("UPDATE live_auctions SET starts_at=?,status='scheduled' WHERE id=?").run(new Date(Date.now()-1000).toISOString(),auction);
  await new Promise(resolve=>setTimeout(resolve,1100));
  const sellerAuctions=await get("/api/live-auctions");assert.equal(sellerAuctions.body.auctions.find(x=>x.id===auction).status,"active","seller polling derives the active display state once the scheduled start has passed");assert.equal(db.prepare("SELECT status FROM live_auctions WHERE id=?").get(auction).status,"scheduled","read-only polling must not mutate the auction record");
  user(null);assert.equal((await get("/api/live-auctions")).body.auctions.length,0,"signed-out buyers get no public auction catalogue");
  user("buyer");const buyerAuctions=await get("/api/live-auctions?stream=stream");assert.equal(buyerAuctions.body.auctions.length,1,"buyers see the auction inside its live broadcast");assert.equal(buyerAuctions.body.pinnedAuction,auction,"buyer receives the featured auction id for the countdown card");
  user("seller");assert.equal((await post({action:"pin",stream:"stream",auction:""})).status,200);assert.equal((await get("/api/live-auctions?stream=stream")).body.pinnedAuction,"");assert.equal((await post({action:"pin",stream:"stream",auction})).status,200);user("buyer");
  const requestId=crypto.randomUUID();
  const first=await post({action:"bid",auction,maxBid:1000,requestId});assert.equal(first.status,200,JSON.stringify(first.body));assert.equal(first.body.currentBid,1000);assert.equal(first.body.youAreLeading,true);assert.equal(first.body.myMaxBid,1000);assert(Date.parse(first.body.endsAt)-Date.now()>10000,"a bid in the final 12 seconds restarts the closing countdown");
  const duplicate=await post({action:"bid",auction,maxBid:1000,requestId});assert.equal(duplicate.status,200);assert.equal(duplicate.body.duplicate,true);assert.equal(duplicate.body.endsAt,first.body.endsAt);
  const below=await post({action:"bid",auction,maxBid:1050,requestId:crypto.randomUUID()});assert.equal(below.status,400);assert.match(below.body.error,/at least/i);
  const winning=await post({action:"bid",auction,maxBid:1200,requestId:crypto.randomUUID()});assert.equal(winning.status,200,JSON.stringify(winning.body));assert.equal(winning.body.currentBid,1200);assert.equal(winning.body.myMaxBid,1200);assert(Date.parse(winning.body.endsAt)>Date.parse(first.body.endsAt),"another accepted bid restarts the closing countdown again");
  user("seller");const ended=await post({action:"end",auction});assert.equal(ended.status,200,JSON.stringify(ended.body));assert(ended.body.orderId);
  const resultEvent=db.prepare("SELECT message FROM live_stream_events WHERE id=?").get(`auction-result:${auction}`);assert.match(resultEvent.message,/won .* for ₦1,200/);
  assert.equal(db.prepare("SELECT pinned_auction FROM streams WHERE id='stream'").get().pinned_auction,"","ending the auction clears its pinned badge");
  const order=db.prepare("SELECT payment,payment_status,total,delivery_fee,delivery_state,name,phone,address FROM orders WHERE id=?").get(ended.body.orderId);assert.deepEqual({...order},{payment:"auction",payment_status:"pending",total:1700,delivery_fee:500,delivery_state:"",name:"Buyer",phone:"",address:""},"a winner is not asked for delivery details until checkout");
  const sellerAuction=(await get("/api/live-auctions")).body.auctions.find(x=>x.id===auction);assert.equal(sellerAuction.paymentStatus,"pending");assert.equal(sellerAuction.orderTotal,1700);
  const checkoutApi=await import(sourceModule("app/api/commerce/route.ts"));const checkout=async(details={})=>{const response=await checkoutApi.POST(new Request("https://shop.test/api/commerce",{method:"POST",headers:{origin:"https://shop.test","Content-Type":"application/json"},body:JSON.stringify({action:"retry-payment",id:ended.body.orderId,...details})}));return{status:response.status,body:await response.json()};};
  const originalFetch=globalThis.fetch;let checkoutPayload;
  globalThis.fetch=async(_url,options)=>{checkoutPayload=JSON.parse(options.body);return Response.json({status:"success",data:{link:"https://checkout.flutterwave.com/auction-fixture"}});};
  user("seller");assert.equal((await checkout()).status,400,"seller cannot pay another user's winning auction order");
  user("buyer");const delivery={name:"Buyer Name",phone:"08012345678",address:"10 Market Road, Ikeja",delivery_state:"Lagos"};const checkoutResult=await checkout(delivery);assert.equal(checkoutResult.status,200,JSON.stringify(checkoutResult.body));assert.equal(checkoutResult.body.paymentLink,"https://checkout.flutterwave.com/auction-fixture");assert.equal(checkoutPayload.amount,1700,"hosted checkout charges bid plus fixed shipping quote");assert.deepEqual({...db.prepare("SELECT name,phone,address,delivery_state,total FROM orders WHERE id=?").get(ended.body.orderId)},{name:"Buyer Name",phone:"08012345678",address:"10 Market Road, Ikeja",delivery_state:"Lagos",total:1700});const retryResult=await checkout();assert.equal(retryResult.body.paymentLink,checkoutResult.body.paymentLink,"payment retries reuse the same provider checkout instead of creating duplicate charges");assert.equal(db.prepare("SELECT COUNT(*) n FROM payments WHERE order_id=?").get(ended.body.orderId).n,1);globalThis.fetch=originalFetch;
  user("seller");
  db.prepare("INSERT INTO notifications(id,user,title,body,created) VALUES(?,?,'Auction payment not completed','Attempt failed; order remains open.','now')").run(`auction-payment-attempt:${ended.body.orderId}:fixture-transaction`,"seller");
  assert.equal((await get("/api/live-auctions")).body.auctions.find(x=>x.id===auction).paymentStatus,"failed_attempt","seller polling sees a verified failed payment attempt while the winner may retry");
  db.prepare("UPDATE orders SET payment_status='paid' WHERE id=?").run(ended.body.orderId);
  assert.equal((await get("/api/live-auctions")).body.auctions.find(x=>x.id===auction).paymentStatus,"paid","seller polling reports the verified order state");
  assert.equal(db.prepare("SELECT status FROM live_auctions WHERE id=?").get(auction).status,"ended");
  db.prepare("UPDATE streams SET status='ended' WHERE id='stream'").run();
  user(null);assert.equal((await get("/api/live-auctions?stream=stream")).body.auctions.length,0,"offline broadcasts expose no auctions");
  user("buyer");const offlineBid=await post({action:"bid",auction,amount:1300,requestId:crypto.randomUUID()});assert.equal(offlineBid.status,400);assert.match(offlineBid.body.error,/only available while its livestream is live/i);
  user(null);const settled=await post({action:"settle",auction});assert.equal(settled.status,200);assert.equal(db.prepare("SELECT COUNT(*) n FROM orders WHERE id=?").get(ended.body.orderId).n,1);
});

test("public auction polling exposes expired auctions without settling; explicit settlement publishes a result", async () => {
  const db=database();addProduct(db,"expired-item",10000,2);
  const stamp=new Date().toISOString(),pastStart=new Date(Date.now()-60_000).toISOString(),pastEnd=new Date(Date.now()-1000).toISOString();
  db.prepare("INSERT INTO live_auctions(id,store,product,stream,start_price,increment,reserve_price,starts_at,ends_at,status,created,updated) VALUES('expired-auction','store','expired-item','stream',1000,100,1000,?,?, 'active',?,?)").run(pastStart,pastEnd,stamp,stamp);
  db.prepare("UPDATE streams SET pinned_auction='expired-auction' WHERE id='stream'").run();
  db.prepare("INSERT INTO auction_bids(id,auction,bidder,amount,request_id,created,recipient,phone,delivery_address,delivery_state,delivery_area,delivery_fee) VALUES('expired-bid','expired-auction','buyer',1200,? ,?,'Buyer','08012345678','1 Main Street','Lagos','Ikeja',500)").run(crypto.randomUUID(),stamp);
  globalThis.testEnv=testEnvironment(db);globalThis.testUser={userId:"buyer",email:"buyer@example.invalid"};
  const api=await import(sourceModule("app/api/live-auctions/route.ts"));
  const response=await api.GET(new Request("https://shop.test/api/live-auctions?stream=stream"));
  assert.equal(response.status,200);
  const payload=await response.json();assert.equal(payload.auctions.length,1);assert.equal(payload.auctions[0].status,"expired");assert.equal(payload.auctions[0].resultEventPublished,false);assert.equal(payload.pinnedAuction,"expired-auction");
  assert.equal(db.prepare("SELECT status FROM live_auctions WHERE id='expired-auction'").get().status,"active","viewer polling must leave auction settlement to the maintenance job");
  assert.equal(db.prepare("SELECT COUNT(*) n FROM orders").get().n,0,"viewer polling must not create a winner order");
  assert.equal(db.prepare("SELECT pinned_auction FROM streams WHERE id='stream'").get().pinned_auction,"expired-auction","viewer polling must not change the live stream state");
  const settled=await api.POST(new Request("https://shop.test/api/live-auctions",{method:"POST",headers:{origin:"https://shop.test","Content-Type":"application/json"},body:JSON.stringify({action:"settle",auction:"expired-auction"})}));
  assert.equal(settled.status,200);assert.equal(db.prepare("SELECT status FROM live_auctions WHERE id='expired-auction'").get().status,"ended");
  assert.match(db.prepare("SELECT message FROM live_stream_events WHERE id='auction-result:expired-auction'").get().message,/won .* for ₦1,200/);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM orders").get().n,1);
});

test("auction queue advances in order when a lot is extended, ended or cancelled", async () => {
  const db=database();addProduct(db,"queue-one",10000,2);addProduct(db,"queue-two",10000,2);addProduct(db,"queue-three",10000,2);
  globalThis.testEnv=testEnvironment(db);globalThis.testUser={userId:"seller",email:"seller@example.invalid"};
  const api=await import(sourceModule("app/api/live-auctions/route.ts"));
  const post=async(body)=>{const response=await api.POST(new Request("https://shop.test/api/live-auctions",{method:"POST",headers:{origin:"https://shop.test","Content-Type":"application/json"},body:JSON.stringify(body)}));return{status:response.status,body:await response.json()};};
  const create=async(product,durationMinutes)=>post({action:"create",product,stream:"stream",startPrice:1000,increment:100,durationMinutes});
  const first=await create("queue-one",1);assert.equal(first.status,200,JSON.stringify(first.body));assert.equal(first.body.queued,false);
  const second=await create("queue-two",2);assert.equal(second.status,200,JSON.stringify(second.body));assert.equal(second.body.queued,true);assert.equal(second.body.pinnedAuction,first.body.id);
  const third=await create("queue-three",3);assert.equal(third.status,200,JSON.stringify(third.body));assert.equal(third.body.queued,true);
  const initialSecondEnd=db.prepare("SELECT ends_at FROM live_auctions WHERE id=?").get(second.body.id).ends_at;
  assert.equal(db.prepare("SELECT starts_at FROM live_auctions WHERE id=?").get(second.body.id).starts_at,first.body.endsAt);
  assert.equal(db.prepare("SELECT starts_at FROM live_auctions WHERE id=?").get(third.body.id).starts_at,initialSecondEnd);
  const extendedEnd=new Date(Date.now()+12000).toISOString();db.prepare("UPDATE live_auctions SET ends_at=?,updated=? WHERE id=?").run(extendedEnd,new Date().toISOString(),first.body.id);
  const shiftedSecond=db.prepare("SELECT starts_at,ends_at FROM live_auctions WHERE id=?").get(second.body.id);
  assert.equal(shiftedSecond.starts_at,extendedEnd,"queued lot shifts with the active lot's closing time");
  assert.equal(db.prepare("SELECT starts_at FROM live_auctions WHERE id=?").get(third.body.id).starts_at,shiftedSecond.ends_at,"later lots remain sequential after the shift");
  const cancelled=await post({action:"end",auction:second.body.id});assert.equal(cancelled.status,200,JSON.stringify(cancelled.body));assert.equal(cancelled.body.cancelled,true);
  assert.equal(db.prepare("SELECT status FROM live_auctions WHERE id=?").get(second.body.id).status,"cancelled");
  assert.equal(db.prepare("SELECT starts_at FROM live_auctions WHERE id=?").get(third.body.id).starts_at,extendedEnd,"cancelling a queued lot moves the following lot forward");
  const ended=await post({action:"end",auction:first.body.id});assert.equal(ended.status,200,JSON.stringify(ended.body));
  assert.equal(db.prepare("SELECT pinned_auction FROM streams WHERE id='stream'").get().pinned_auction,third.body.id,"ending a lot pins the next available queued auction");
});

test("founding sellers must be verified, admin-approved and inside their configured access period",async()=>{
 const db=database();db.prepare("DELETE FROM seller_subscriptions WHERE store='store'").run();
 globalThis.foundingEnv=testEnvironment(db);globalThis.foundingEnv.REVIBE_ADMIN_EMAIL="admin@example.invalid";
 const api=await import(sourceModule("app/api/founding-sellers/route.ts","foundingEnv","foundingUser"));const {sellerActivation}=await import(sourceModule("app/seller-activation.ts","foundingEnv","foundingUser"));const user=id=>globalThis.foundingUser=id?{userId:id,email:`${id}@example.invalid`,displayName:id}:null;
 const post=async(body)=>{const response=await api.POST(new Request("https://shop.test/api/founding-sellers",{method:"POST",headers:{origin:"https://shop.test","Content-Type":"application/json"},body:JSON.stringify(body)}));return{status:response.status,body:await response.json()};};
 user("admin");assert.equal((await post({action:"configure",enabled:true,durationDays:30,maxParticipants:1,eligibility:"Verified sellers only"})).status,200);
 user("seller");let result=await post({action:"apply"});assert.equal(result.status,200);assert.equal(result.body.status,"pending",JSON.stringify(result.body));
 user("admin");result=await post({action:"approve",store:"store"});assert.equal(result.status,200,JSON.stringify(result.body));
 const access=await sellerActivation("store");assert.equal(access.foundingActive,true);assert.equal(access.canSell,true);
 db.prepare("UPDATE founding_enrollments SET ends_at=? WHERE store='store'").run(new Date(Date.now()-1000).toISOString());
 const expired=await sellerActivation("store");assert.equal(expired.foundingActive,false);assert.equal(expired.canSell,false);
});
