import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import assert from 'node:assert/strict';
import {sourceModule} from './load-route.mjs';
const db=new DatabaseSync(':memory:');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(readFileSync('drizzle/'+f,'utf8'));
db.exec("CREATE TABLE seller_messages(id TEXT PRIMARY KEY,store TEXT,buyer TEXT,sender TEXT,body TEXT,created TEXT); INSERT INTO stores(id,owner,name,category,location,phone,created) VALUES('shop','seller','Shop','Tech','Lagos','08000000000','now'); INSERT INTO seller_messages VALUES('msg','shop','buyer','buyer','Please confirm availability','2026-10-01T10:00:00Z'); INSERT INTO reports(id,reporter,target_type,target,reason,details,status,resolution,created,updated) VALUES('case','buyer','seller_message','msg','spam','Reported from private chat','open','','now','now');");
class Q{constructor(s,a=[]){this.s=s;this.a=a;}bind(...a){return new Q(this.s,a);}async first(){return db.prepare(this.s).get(...this.a)||null;}async run(){return db.prepare(this.s).run(...this.a);}}
globalThis.testEnv={DB:{prepare:s=>new Q(s)}};globalThis.testUser={userId:'moderator',email:'mod@test.invalid'};globalThis.fixtureAdminRole=null;
const route=await import(sourceModule('app/api/admin/message-reports/route.ts'));
const get=id=>route.GET(new Request('https://test.invalid/api/admin/message-reports?id='+id));
assert.equal((await get('case')).status,403);
globalThis.fixtureAdminRole='moderator';const response=await get('case');assert.equal(response.status,200);const data=await response.json();assert.equal(data.message.body,'Please confirm availability');assert.equal(data.message.sender,'Buyer');
assert.equal(db.prepare("SELECT COUNT(*) AS n FROM admin_audit WHERE action='view-reported-message' AND target='case'").get().n,1);
assert.equal((await get('missing')).status,404);
assert.equal(db.prepare("SELECT COUNT(*) AS n FROM admin_audit WHERE action='view-reported-message'").get().n,1);
console.log('PASS: report-only message disclosure requires moderation permission and writes an access audit record.');
