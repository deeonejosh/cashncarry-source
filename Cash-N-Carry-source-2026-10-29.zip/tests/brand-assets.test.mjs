import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";

test("approved Cash N Carry brand asset set is present and uses versioned delivery paths", () => {
  const brand = readFileSync("app/brand.ts", "utf8");
  const logo = readFileSync("app/brand-logo.tsx", "utf8");
  for (const path of [
    "cash-n-carry-logo-transparent-v2.webp",
    "cash-n-carry-logo-fallback-v2.jpg",
    "cash-n-carry-logo-dark-surface-v2.webp",
    "cash-n-carry-logo-compact-v2.webp",
    "cash-n-carry-icon-transparent-v2.png",
    "cash-n-carry-icon-v2-16.png",
    "cash-n-carry-icon-v2-32.png",
    "cash-n-carry-icon-v2-48.png",
    "cash-n-carry-icon-v2-180.png",
    "cash-n-carry-icon-v2-192.png",
    "cash-n-carry-icon-v2-512.png",
    "cash-n-carry-icon-v2-maskable.png",
  ]) {
    assert(existsSync(`public/brand/${path}`), `Missing brand asset: ${path}`);
  }
  assert.match(brand, /logo-transparent-v2\.webp/);
  assert.match(brand, /logo-fallback-v2\.jpg/);
  assert.match(logo, /brand\.symbol/);
  assert.match(logo, /brand\.compactLogo/);
  assert.match(readFileSync("app/api/manifest/route.ts", "utf8"), /cash-n-carry-icon-v2-maskable\.png/);
  const png = readFileSync("public/brand/cash-n-carry-icon-v2-512.png");
  assert.equal(png.toString("ascii", 1, 4), "PNG");
  assert.equal(png.readUInt32BE(16), 512);
  assert.equal(png.readUInt32BE(20), 512);
});
