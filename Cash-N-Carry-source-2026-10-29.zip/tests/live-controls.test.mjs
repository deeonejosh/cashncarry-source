import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import ts from "typescript";
import * as React from "react";
import { adjacentLiveStream, liveStreamCandidates } from "../app/live-stream-navigation.mjs";
const url = (source) =>
  "data:text/javascript;base64," +
  Buffer.from(
    ts.transpileModule(source, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2023,
        jsx: ts.JsxEmit.React,
      },
    }).outputText,
  ).toString("base64");
let state = [],
  cursor = 0,
  refs = [],
  refCursor = 0;
const hooks = {
  useState(initial) {
    const i = cursor++;
    if (!(i in state)) state[i] = typeof initial === "function" ? initial() : initial;
    return [
      state[i],
      (next) => (state[i] = typeof next === "function" ? next(state[i]) : next),
    ];
  },
  useRef(initial) {
    const i = refCursor++;
    return (refs[i] ??= { current: initial });
  },
  useEffect() {},
};
globalThis.liveTest = { React, ...hooks, adjacentLiveStream, liveStreamCandidates };
const icons =
  "Heart,ShoppingBag,ShoppingCart,Share2,Flag,X,Check,CheckCircle2,Play,Send,MoreHorizontal,Maximize,ChevronDown,ChevronUp,Video,VideoOff,Zap,Settings,ArrowLeft,Radio,ShieldCheck,Mic,MicOff,SwitchCamera,Pin,BarChart3,MessageCircle,Eye".split(
    ",",
  );
const stub = (name) => {
  function IconStub() {
    return React.createElement("span", { "data-icon": name });
  }
  IconStub.displayName = `IconStub(${name})`;
  return IconStub;
};
for (const name of icons) globalThis.liveTest[name] = stub(name);
const prefix =
  "const React=globalThis.liveTest.React;const {useState,useRef,useEffect," +
  icons.join(",") +
  ",adjacentLiveStream,liveStreamCandidates}=globalThis.liveTest;";
const strip = (source) =>
  source.replace(/import[\s\S]*?from\s*["'][^"']+["'];/g, "");
const overlays = await import(
  url(prefix + strip(readFileSync("app/live-overlay.tsx", "utf8")))
);
Object.assign(globalThis.liveTest, overlays, {
  WebRTCVideo: () => null,
  LiveVideo: () => null,
  ScheduleInfo: () => null,
  ImageAsset: (p) => React.createElement("img", p),
  StoreLogo: () => null,
  BrandLogo: () => null,
  VerifiedSellerBadge: () => null,
  brand: { name: "Cash N Carry" },
  safeReturnPath: (x) => x,
  workspaceTab: (x) => x,
  broadcastLabel: (s) => s.status.toUpperCase(),
  deliveryQuote: () => 1000,
  deliveryFee: () => 1000,
});
Object.assign(globalThis.liveTest, await import(url(readFileSync("app/live-product-selection.ts", "utf8"))));
const deps =
  "const {liveProductSelection,LiveAction,LiveSheet,ElapsedBroadcast,WebRTCVideo,LiveVideo,ScheduleInfo,ImageAsset,StoreLogo,BrandLogo,VerifiedSellerBadge,brand,safeReturnPath,workspaceTab,broadcastLabel,deliveryQuote,deliveryFee}=globalThis.liveTest;";
const { default: Viewer } = await import(
  url(prefix + deps + strip(readFileSync("app/live-shopping.tsx", "utf8")))
);
const { default: Host } = await import(
  url(
    prefix +
      deps +
      "const createPortraitPublisher=()=>null,completeIceOffer=()=>null,LiveHistoryPanel=()=>null;" +
      strip(readFileSync("app/workspace/page.tsx", "utf8")),
  )
);
function flatten(node, out = []) {
  if (!node || typeof node !== "object") return out;
  if (Array.isArray(node)) {
    node.forEach((n) => flatten(n, out));
    return out;
  }
  if (typeof node.type === "function")
    return flatten(node.type(node.props), out);
  out.push(node);
  flatten(node.props?.children, out);
  return out;
}
const text = (n) =>
  typeof n === "string" || typeof n === "number"
    ? String(n)
    : Array.isArray(n)
      ? n.map(text).join("")
      : text(n?.props?.children ?? "");
const find = (tree, p) => flatten(tree).find(p);
const button = (tree, label) =>
  find(
    tree,
    (n) =>
      n.type === "button" &&
      (n.props["aria-label"] === label || text(n) === label),
  );
const render = (Component, props = {}) => {
  cursor = 0;
  refCursor = 0;
  return Component(props);
};
const product = {
  id: "p",
  store: "s",
  name: "Stored product",
  image: "/api/media/real",
  price: 1200,
  stock: 4,
  active: 1,
  variants: "[]",
};
const stream = {
  id: "live",
  store: "s",
  seller: "Stored seller",
  title: "Real title",
  status: "live",
  provider: "native",
  product: "p",
};
const chat = { id: "c", name: "Viewer", message: "Actual message" };
let calls = [],
  clipboard = "";
globalThis.location = { origin: "https://app.test" };
Object.defineProperty(globalThis, "navigator", {
  configurable: true,
  value: {
    clipboard: { writeText: async (x) => (clipboard = x) },
    mediaDevices: { getUserMedia: async () => media },
  },
});
const fixture = {
  user: { id: "seller" },
  myStore: { id: "s", name: "Stored seller" },
  myStreams: [stream],
  myProducts: [product],
  services: { stream: true },
  cart: [],
  stores: [],
  follows: [],
};
globalThis.fetch = async (path, options) => {
  if (options?.method === "POST")
    calls.push({ path, body: JSON.parse(options.body) });
  return Response.json(
    options?.method === "POST"
      ? { ok: true }
      : path.includes("?stream=")
        ? { likes: 13, liked: true }
        : fixture,
  );
};
let confirmResult = false;
globalThis.confirm = () => confirmResult;
const audio = {
    enabled: true,
    stop() {
      this.stopped = true;
    },
  },
  video = {
    getSettings: () => ({ facingMode: "user" }),
    stop() {
      this.stopped = true;
    },
  };
const media = {
  getTracks: () => [audio, video],
  getAudioTracks: () => [audio],
  getVideoTracks: () => [video],
  removeTrack() {},
  addTrack() {},
};
const event = { preventDefault() {}, stopPropagation() {} };
function viewerState(sheet = "") {
  state = [
    stream,
    [product],
    [chat],
    12,
    false,
    sheet,
    "",
    {},
    {},
    "Question",
    "",
    false,
    "",
    false,
    false,
    12,
    false,
    "Concern",
    "", null, [], "", [], "", "", Date.now(), [],
  ];
  refs = [];
  calls = [];
}
const viewerProps = {
  initial: stream,
  data: { cart: [{ ...product, quantity: 2 }], stores: [], follows: [] },
  busy: false,
  act: async (body) => {
    calls.push(body);
    return true;
  },
  onClose: () => calls.push("closed"),
};
test("vertical buyer swipes switch forward and back through active streams", () => {
  viewerState();
  const next = { ...stream, id: "next", status: "external", created: "2026-10-22T10:00:00Z" };
  const props = { ...viewerProps, availableStreams: [stream, next] };
  let tree = render(Viewer, props);
  const stage = find(tree, (node) => node.props.className === "live-stage");
  const touch = (y) => ({ touches: [{ clientX: 100, clientY: y }], target: { closest: () => null } });
  stage.props.onTouchStart(touch(300));
  stage.props.onTouchEnd({ changedTouches: [{ clientX: 108, clientY: 220 }] });
  assert.equal(state[0].id, "next");
  tree = render(Viewer, props);
  const switchedStage = find(tree, (node) => node.props.className === "live-stage");
  switchedStage.props.onTouchStart(touch(220));
  switchedStage.props.onTouchEnd({ changedTouches: [{ clientX: 103, clientY: 300 }] });
  assert.equal(state[0].id, "live");
});
test("viewer rail order, follow, real counts, product selection, cart, share, comment and report handlers", async () => {
  viewerState();
  let tree = render(Viewer, viewerProps);
  const rail = find(tree, (n) => n.props.className === "live-viewer-tools");
  assert.deepEqual(
    flatten(rail)
      .filter((n) => n.type === "button")
      .map((n) => text(n)),
    ["12", "1", "Share", "More"],
  );
  assert.equal(button(tree, "Open cart, 2 items") !== undefined, true);
  assert(!button(tree, "Switch camera"));
  assert(!button(tree, "End Live"));
  button(tree, "More broadcast options").props.onClick();
  tree = render(Viewer, viewerProps);
  await button(tree, "Follow seller").props.onClick();
  assert.equal(calls.at(-1).action, "follow");
  await button(tree, "Share broadcast").props.onClick();
  assert.equal(clipboard, "https://app.test/?stream=live");
  await button(tree, "Like broadcast, 12 likes").props.onClick();
  assert.deepEqual(calls.at(-1), {
    action: "stream-like",
    stream: "live",
    liked: true,
  });
  assert.equal(state[15], 13);
  button(tree, "Close Broadcast options").props.onClick();
  tree = render(Viewer, viewerProps);
  const before = calls.length;
  find(tree, n => n.props.className === "live-premium-product-info").props.onClick();
  assert.equal(state[5], "product");
  assert.equal(state[6], "p");
  assert.equal(calls.length, before);
  button(tree, "Open cart, 2 items").props.onClick();
  assert.equal(state[5], "checkout");
  assert(state[12]);
  await find(tree, (n) => n.type === "form").props.onSubmit(event);
  assert.equal(calls.at(-1).action, "chat");
  button(tree, "More broadcast options").props.onClick();
  assert.equal(state[5], "more");
  tree = render(Viewer, viewerProps);
  const stage = find(tree, (n) => n.props.className === "live-stage");
  assert.equal(stage.props.inert, true);
  await find(find(tree, (n) => n.props.className === "live-option-list"), (n) => n.type === "form").props.onSubmit(event);
  assert.equal(calls.at(-1).action, "report");
  button(tree, "Close Broadcast options").props.onClick();
  assert.equal(state[5], "");
});
function hostState(sheet = "") {
  state = [
    fixture,
    "Connected",
    false,
    "Studio",
    "live",
    false,
    "",
    "LIVE — provider confirmed",
    false,
    [chat],
    12,
    "Reply",
    sheet,
    Date.now() - 65000,
    false,
    "/workspace",
    true,
  ];
  refs = [
    { current: null },
    { current: media },
    { current: null },
    { current: false },
    { current: false },
    { current: false },
    { current: "user" },
    { current: "" },
    { current: "live" },
    { current: 1 },
    { current: null },
  ];
  calls = [];
  audio.enabled = true;
}
test("host rail, microphone, product management, moderation and explicit confirmed close/end handlers", async () => {
  hostState();
  let tree = render(Host);
  const rail = find(tree, (n) => n.props.className === "host-live-tools");
  assert.deepEqual(
    flatten(rail)
      .filter((n) => n.type === "button")
      .map((n) => text(n)),
    ["Mic", "Flip", "More"],
  );
  button(tree, "Mute microphone").props.onClick();
  assert.equal(audio.enabled, false);
  assert.equal(state[8], true);
  tree = render(Host);
  button(tree, "Unmute microphone").props.onClick();
  assert.equal(audio.enabled, true);
  button(tree, "Manage broadcast products").props.onClick();
  assert.equal(state[12], "products");
  tree = render(Host);
  find(tree, (n) => n.props.role === "option" && n.props["aria-selected"] === false).props.onClick();
  assert.equal(calls.filter(c=>c.body?.action==="pin").length,0);
  tree=render(Host);await button(tree,"Pin Product").props.onClick();
  assert.equal(calls.at(-1).body.action, "pin");
  assert.equal(calls.at(-1).body.id, "live");
  hostState("more");
  tree = render(Host);
  button(tree, "Moderate comments").props.onClick();
  assert.equal(state[12], "moderation");
  tree = render(Host);
  await button(tree, "Hide message").props.onClick();
  assert.equal(calls.at(-1).body.action, "moderate-chat");
  hostState();
  tree = render(Host);
  await find(
    tree,
    (n) => n.type === "form" && n.props.className === "host-live-reply",
  ).props.onSubmit(event);
  assert.equal(calls.at(-1).body.action, "chat");
  calls = [];
  find(tree, n => n.props.className === "seller-end-live-action").props.onClick();
  assert.equal(state[12], "leave");
  assert.equal(calls.length, 0);
  tree = render(Host);
  button(tree, "Keep Streaming").props.onClick();
  assert.equal(state[12], "");
  assert.equal(calls.length, 0);
  find(render(Host), n => n.props.className === "seller-end-live-action").props.onClick();
  tree = render(Host);
  const end=find(tree,n=>n.props.className==="host-end");
  end.props.onClick();
  end.props.onClick();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(calls[0].body.action, "end");
  assert.equal(calls[0].path, "/api/streams");
  assert.equal(calls.filter(c=>c.body?.action==="end").length,1);
});
test("ended viewer hides composer and empty products while retaining a cart", () => {
  viewerState();
  state[0] = { ...stream, status: "ended", product: "" };
  state[1] = [];
  const tree = render(Viewer, viewerProps);
  assert(find(tree,n=>String(n.props.className).includes("live-ended-transition")));
  assert(find(tree,n=>String(n.props.className).includes("live-next-card")));
  assert(find(tree,n=>n.props.className==="live-ended-swipe-hint"));
  assert(
    !find(
      tree,
      (n) => n.type === "input" && n.props.placeholder === "Ask the seller…",
    ),
  );
  assert(!find(tree, (n) => n.props.className === "live-premium-product"));
  assert(!button(tree, "Browse 0 featured products"));
  assert(
    find(tree, (n) => n.props.className === "live-cart-button live-ended-cart"),
  );
  assert.equal(button(tree, "Like broadcast, 12 likes").props.disabled, true);
});
test("sheets close with Escape and trap focus without propagating to outer dialog", () => {
  state = [];
  refs = [];
  let closed = false;
  const tree = render(overlays.LiveSheet, {
    title: "Options",
    onClose: () => (closed = true),
    children: null,
  });
  const dialog = find(tree, (n) => n.props.role === "dialog");
  let stopped = false,
    prevented = false;
  dialog.props.onKeyDown({
    key: "Escape",
    preventDefault() {
      prevented = true;
    },
    stopPropagation() {
      stopped = true;
    },
  });
  assert(closed && stopped && prevented);
});

test("repositioned camera, close and fullscreen actions invoke their existing operations", async () => {
  hostState();
  let tree = render(Host);
  let captured;
  navigator.mediaDevices.getUserMedia = async (options) => {
    captured = options;
    return media;
  };
  await button(tree, "Switch camera").props.onClick();
  assert.equal(captured.video.facingMode.exact, "environment");
  assert.equal(captured.audio, false);
  hostState("more");
  state[14] = true;
  tree = render(Host);
  let fullscreen = 0;
  await button(tree, "Enter fullscreen").props.onClick({
    currentTarget: {
      closest: () => ({ requestFullscreen: async () => fullscreen++ }),
    },
  });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(fullscreen, 1);
  assert.equal(state[12], "");
  viewerState("more");
  state[14] = true;
  refs = [{ current: { requestFullscreen: async () => fullscreen++ } }];
  tree = render(Viewer, viewerProps);
  await button(tree, "Enter fullscreen").props.onClick();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(fullscreen, 2);
  assert.equal(state[5], "");
  viewerState();
  tree = render(Viewer, viewerProps);
  button(tree, "Close broadcast").props.onClick();
  assert.equal(calls.at(-1), "closed");
});
test("sheets trap both Tab boundaries and restore navigation remains guarded while broadcasting", () => {
  state = [];
  refs = [];
  const tree = render(overlays.LiveSheet, {
    title: "Options",
    onClose: () => {},
    children: null,
  });
  const dialog = find(tree, (n) => n.props.role === "dialog");
  let target = "",
    prevented = false;
  const first = { getClientRects: () => [1], focus: () => (target = "first") },
    last = { getClientRects: () => [1], focus: () => (target = "last") };
  globalThis.document = { activeElement: last };
  const key = {
    key: "Tab",
    shiftKey: false,
    preventDefault: () => (prevented = true),
    stopPropagation() {},
    currentTarget: { querySelectorAll: () => [first, last] },
  };
  dialog.props.onKeyDown(key);
  assert.equal(target, "first");
  assert(prevented);
  document.activeElement = first;
  key.shiftKey = true;
  dialog.props.onKeyDown(key);
  assert.equal(target, "last");
  const source = ts.createSourceFile(
    "workspace.tsx",
    readFileSync("app/workspace/page.tsx", "utf8"),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TSX,
  );
  let body;
  function visit(n) {
    if (
      ts.isVariableDeclaration(n) &&
      n.name.getText(source) === "warnBeforeLeaving"
    )
      body = n.initializer.body.getText(source);
    ts.forEachChild(n, visit);
  }
  visit(source);
  const guard = new Function("broadcast", "return (e)=>" + body);
  const broadcast = { current: "" };
  let warned = false;
  guard(broadcast)({ preventDefault: () => (warned = true) });
  assert.equal(warned, false);
  broadcast.current = "live";
  const event = { preventDefault: () => (warned = true) };
  guard(broadcast)(event);
  assert.equal(warned, true);
  assert.equal(event.returnValue, "");
});

test("camera preview exposes an enabled Go Live action and a working Cancel preview action", async () => {
  hostState();
  state[4] = "";
  state[6] = "live";
  state[7] = "Camera preview — not live";
  state[13] = null;
  refs[8].current = "";
  let tree = render(Host);
  const go = button(tree, "Go Live");
  assert(go);
  assert.equal(go.props.disabled, false);
  assert(button(tree, "Cancel preview"));
  assert(!button(tree, "End Live"));
  button(tree, "Cancel preview").props.onClick();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(state[6], "");
  assert.equal(calls.length, 0);
  hostState();
  state[4] = "";
  state[6] = "live";
  state[2] = true;
  tree = render(Host);
  assert.equal(button(tree, "Go Live").props.disabled, true);
});
test("host overlay containing block is the full stage rather than empty grid rows", () => {
  const css = readFileSync("app/design-system.css", "utf8");
  const start = css.indexOf("/* Portrait host stage,");
  const end = css.indexOf("/* Save controls", start);
  const stageRules = css.slice(start, end);
  assert.match(stageRules, /\.host-live-stage \{[\s\S]*?display: block;/);
  assert.doesNotMatch(stageRules, /grid-row:|grid-column:|grid-template-rows:/);
  const lastRules = css.slice(css.indexOf("/* Cash N Carry live overlays."));
  assert.match(
    lastRules,
    /\.host-live-stage \.host-live-lower \{[\s\S]*?position: absolute;[\s\S]*?bottom: 0;/,
  );
});

test("pinned product collapses without losing the broadcast and restores its purchase entry", () => {
  viewerState();
  let tree = render(Viewer, viewerProps);
  assert(find(tree, n => n.props.className === "live-premium-product"));
  button(tree, "Collapse pinned product").props.onClick();
  tree = render(Viewer, viewerProps);
  assert(!find(tree, n => n.props.className === "live-premium-product"));
  assert(find(tree, n => n.props.className === "live-stage"));
  assert.equal(button(tree, "Expand pinned product").props["aria-expanded"], false);
  button(tree, "Expand pinned product").props.onClick();
  tree = render(Viewer, viewerProps);
  assert(find(tree, n => n.props.className === "live-premium-product"));
  assert.equal(button(tree, "Collapse pinned product").props["aria-expanded"], true);
});
test("buyer player shows the pinned product once, adds a desktop shopping/chat rail and keeps a visible close action", () => {
  viewerState();
  state[1] = [product, { ...product, id: "p2", name: "Second product", price: 2400 }];
  const tree = render(Viewer, viewerProps);
  const strip = find(tree, (node) => node.props.className === "live-product-strip");
  assert(strip);
  assert(!text(strip).includes("Stored product"));
  assert(text(strip).includes("Second product"));
  const sidebar = find(tree, (node) => node.props.className === "live-desktop-sidebar");
  assert(sidebar);
  assert.equal(find(sidebar, (node) => node.props.className === "live-desktop-product-main") !== undefined, true);
  assert.equal(find(sidebar, (node) => node.props.className === "live-desktop-chat") !== undefined, true);
  assert(button(tree, "Close broadcast"));
  const css = readFileSync("app/shop-redesign.css", "utf8");
  assert.match(css, /\.live-shopping \.live-lower\{display:none!important\}/);
  assert.match(css, /\.live-desktop-sidebar\{display:flex;flex-direction:column/);
});

test("live product Buy Now opens direct checkout while Add to Cart remains independent", async () => {
  viewerState("product"); state[6] = product.id;
  let tree = render(Viewer, viewerProps);
  const buy = button(tree, "Buy Now");
  assert.equal(buy.props.className, "primary");
  buy.props.onClick();
  assert.equal(state[5], "checkout");
  assert.equal(state[19].product.id, product.id);
  assert.equal(calls.length, 0);
  viewerState("product"); state[6] = product.id;
  tree = render(Viewer, viewerProps);
  const add = button(tree, "Add to Cart");
  assert.equal(add.props.className, "secondary-button");
  await add.props.onClick();
  assert.equal(calls.at(-1).action, "cart");
  assert.equal(state[5], "product");
});

test("live deal price is shown on the pin and shopping controls are hidden under sheets", () => {
  viewerState(); state[20] = [{ product: product.id, promo_price: 700, max_quantity: 5, sold_quantity: 2, starts_at: new Date(Date.now()-10000).toISOString(), ends_at: new Date(Date.now()+10000).toISOString() }];
  const tree = render(Viewer, viewerProps);
  const pin = find(tree, n => n.props.className === "live-premium-product");
  assert.match(text(pin), /700/);
  assert.match(text(pin), /00:1[01] left/);
  state[5] = "products";
  const sheetTree = render(Viewer, viewerProps);
  assert(!find(sheetTree, n => n.props.className === "live-premium-product"));
  assert.equal(find(sheetTree, n => n.props.className === "live-stage").props.inert, true);
});

test("active live deal is featured once in the pinned buyer card", () => {
  viewerState();
  state[1] = [];
  state[20] = [{ id:"deal-1", status:"active", product: product.id, name: product.name, price: product.price, image: product.image, stock: product.stock, variants: "[]", seller: "Test seller", promo_price: 700, max_quantity: 5, sold_quantity: 1, starts_at: new Date(Date.now()-10000).toISOString(), ends_at: new Date(Date.now()+60000).toISOString() }];
  const tree = render(Viewer, viewerProps);
  const feature = find(tree, n => n.props.className === "live-premium-product");
  assert.match(text(feature), /Stored product/);
  assert.match(text(feature), /FLASH/);
  assert.equal(find(tree, n => n.props.className === "live-product-strip"), undefined);
  find(feature, n => n.props.className === "live-premium-product-info").props.onClick();
  assert.equal(state[6], product.id);
  assert.equal(state[5], "product");
});

test("a pinned live bundle appears to buyers with a ticking expiry and opens its product",()=>{
 viewerState();render(Viewer,viewerProps);
 state[22]=[{id:"bundle-product",bundleId:"bundle-1",name:"Weekend bundle",price:1800,image:product.image,stock:3,seller:"Test seller",liveBundle:true}];
 state[23]="bundle-1";state[24]=new Date(Date.now()+65000).toISOString();state[25]=Date.now();
 const tree=render(Viewer,viewerProps),feature=find(tree,n=>n.props.className==="live-product-strip");
 assert.match(text(feature),/PINNED BUNDLE/);assert.match(text(feature),/Weekend bundle/);
 find(feature,n=>n.type==="button"&&n.props["aria-label"]?.includes("Weekend bundle")).props.onClick();assert.equal(state[5],"product");assert.equal(state[6],"bundle-product");
});

test("live discount matches Buy Now line item and total",()=>{viewerState('product');state[6]=product.id;state[20]=[{product:product.id,promo_price:700,max_quantity:5,sold_quantity:0,starts_at:new Date(Date.now()-1000).toISOString(),ends_at:new Date(Date.now()+60000).toISOString()}];state[25]=Date.now();button(render(Viewer,viewerProps),'Buy Now').props.onClick();const tree=render(Viewer,viewerProps);const lines=flatten(tree).filter(n=>n.type==='p').map(text);assert(lines.some(line=>line.includes('Stored product')&&line.includes('700')));assert(lines.some(line=>line.includes('Products')&&line.includes('700')));});

test('premium pinned Buy Now opens direct checkout and Add to Cart preserves the live stage', async()=>{
 viewerState();let tree=render(Viewer,viewerProps);
 button(tree,'Buy Now').props.onClick();assert.equal(state[5],'checkout');assert.equal(state[19].product.id,product.id);assert.equal(calls.length,0);
 viewerState();tree=render(Viewer,viewerProps);button(tree,'Add to Cart').props.onClick();await Promise.resolve();assert.equal(calls.at(-1).action,'cart');assert.equal(calls.at(-1).product,product.id);assert(!('price' in calls.at(-1)));assert.equal(state[5],'');assert(find(tree,n=>n.props.className==='live-stage'));
});

test('Products sheet unpins and pins through existing ownership-checked actions',async()=>{
 hostState();let tree=render(Host);button(tree,'Manage broadcast products').props.onClick();tree=render(Host);await button(tree,'Unpin current product').props.onClick();assert.equal(calls.at(-1).body.action,'pin');assert.equal(calls.at(-1).body.product,'');assert.equal(calls.at(-1).body.previousProduct,product.id);
 hostState();tree=render(Host);button(tree,'Manage broadcast products').props.onClick();tree=render(Host);find(tree,n=>n.props.role==='option'&&n.props['aria-selected']===false).props.onClick();assert.equal(calls.length,0);tree=render(Host);await button(tree,'Pin Product').props.onClick();assert.equal(calls.at(-1).body.action,'pin');assert.equal(calls.at(-1).body.product,product.id);
 assert(!button(tree,'Buy Now')); 
});
test('seller More menu opens real count panel rather than example sales metrics',()=>{
 hostState('more');let tree=render(Host);button(tree,'Live stats').props.onClick();assert.equal(state[12],'stats');tree=render(Host);assert.match(text(tree),/Current viewers/);assert.doesNotMatch(text(tree),/2\.4K|320 sold|Free delivery/);
});

test('selecting a valid product option clears the resolved variant prompt',()=>{
 viewerState('product');state[6]=product.id;state[10]='Choose an available product option first.';
 const original=product.variants;product.variants=JSON.stringify([{name:'Black',price:1200,stock:4}]);
 try{const tree=render(Viewer,viewerProps);find(tree,n=>n.type==='select').props.onChange({target:{value:'Black'}});assert.equal(state[7][product.id],'Black');assert.equal(state[10],'');}finally{product.variants=original;}
});

 test("pinned variant selector enables purchase and preserves the selected option",async()=>{
  const original=product.variants;product.variants=JSON.stringify([{name:"Black",price:1200,stock:4},{name:"Red",stock:0}]);
  try { viewerState();let tree=render(Viewer,viewerProps);
   assert.equal(button(tree,"Buy Now").props.disabled,true);
   const select=find(tree,n=>n.type==="select"&&n.props["aria-label"]===`Option for ${product.name}`);
   assert(select);select.props.onChange({target:{value:"Black"}});
   tree=render(Viewer,viewerProps);assert.equal(button(tree,"Buy Now").props.disabled,false);
   button(tree,"Buy Now").props.onClick();assert.equal(state[19].variant,"Black");
   viewerState();tree=render(Viewer,viewerProps);find(tree,n=>n.type==="select").props.onChange({target:{value:"Black"}});
   tree=render(Viewer,viewerProps);button(tree,"Add to Cart").props.onClick();await Promise.resolve();assert.equal(calls.at(-1).variant,"Black");
  } finally {product.variants=original;}
 });
 test("live selection rejects missing, stale and sold out options but permits plain products",()=>{
  const choose=globalThis.liveTest.liveProductSelection;
  assert.equal(choose({name:"Plain",stock:2,price:100}).error,"");
  const item={name:"Shirt",stock:8,variants:JSON.stringify([{name:"M",stock:2,price:200},{name:"L",stock:0}])};
  assert.match(choose(item).error,/Choose an available option for Shirt/);
  assert(choose(item,"Old").error);assert(choose(item,"L").error);
  assert.equal(choose(item,"M").price,200);assert.equal(choose(item,"M").error,"");
  for(const q of [-1,0,1.5,3])assert(choose(item,"M",q).error);
  assert(choose({...item,variants:"broken"}).error);
 });

test('host uses one compact bottom action dock and keeps camera and extra tools in More',()=>{
 hostState();let tree=render(Host);
 assert.equal(flatten(tree).filter(n=>n.type==='button'&&n.props.className==='seller-end-live-action').length,1);
 assert.deepEqual(flatten(find(tree,n=>n.props.className==='host-live-tools')).filter(n=>n.type==='button').map(text),['Mic','Flip','More']);
 assert.deepEqual(flatten(find(tree,n=>n.props.className==='host-live-actions')).filter(n=>n.type==='button').map(text),['Products 1','Unpin Item','End Live']);
 assert(button(tree,'End Live'));
 assert(!button(tree,'Camera & title'));
 button(tree,'More host options').props.onClick();tree=render(Host);
 for(const label of ['Stream settings','Live stats','Share broadcast','Moderate comments','Live deals','Auctions','Product bundles','Connection status','Technical help'])assert(button(tree,label));
 assert.equal(flatten(tree).filter(n=>n.type==='button'&&n.props.className==='seller-end-live-action').length,1); // Keep exactly one end control in the dock
 assert(button(tree,'Turn camera off'));
 assert(find(tree,n=>String(n.props.className).includes('studio-tools-sheet')));
 assert.deepEqual(flatten(find(tree,n=>n.props.className==='studio-tools-content')).filter(n=>n.type==='h3').map(text),['Broadcast','Live tools','Shopping','More']);
 assert(!button(tree,'Closing and leaving'));
 assert(!flatten(tree).some(n=>n.type==='a'&&/tab=(Bundles|Auctions|Live%20Deals)/.test(String(n.props.href))));
});
test('host and viewer tools remain compact right-side rails, clear of the bottom chat dock',()=>{
 const css=readFileSync('app/design-system.css','utf8');
 hostState();let host=render(Host);assert(find(host,n=>n.props.className==='host-live-tools'));assert(find(host,n=>n.props.className==='host-live-lower'));
 viewerState();let viewer=render(Viewer,viewerProps);assert(find(viewer,n=>n.props.className==='live-viewer-tools'));assert(find(viewer,n=>n.props.className==='live-lower'));
 const finalCss=readFileSync('app/shop-redesign.css','utf8');assert.match(finalCss,/Compact live layouts: keep seller controls on the right and chat at the bottom/);assert.match(finalCss,/\.studio-page \.host-live-stage\[data-studio-state=live\]\s*>\.host-live-tools\s*\{[^}]*position:absolute/s);assert.match(finalCss,/\.live-shopping \.live-stage>\.live-viewer-tools\{position:absolute/s);assert.match(finalCss,/host-live-chat\{order:1/);
 const buyerRail=finalCss.slice(finalCss.lastIndexOf('Keep buyer actions in the free video rail'));
 assert.match(buyerRail,/top:calc\(env\(safe-area-inset-top\) \+ var\(--live-header-height,44px\) \+ 52px\)!important/);
 assert.match(buyerRail,/bottom:calc\(env\(safe-area-inset-bottom\) \+ var\(--live-dock-height,200px\) \+ 10px\)!important/);
 assert.match(buyerRail,/transform:none!important;display:flex!important;flex-direction:column!important;justify-content:flex-start!important/);
 assert.match(buyerRail,/left:auto!important/);
 assert.match(buyerRail,/overflow-y:auto!important/);
 assert.match(finalCss,/top:calc\(env\(safe-area-inset-top\) \+ 146px\)!important;right:max\(6px,env\(safe-area-inset-right\)\)!important;left:auto!important;bottom:auto!important/);
 assert.match(finalCss,/height:max-content!important;min-height:0!important;max-height:min\(42vh,236px\)!important/);
});
test('Seller Centre has no livestream management entries and legacy deal/auction routes resolve to history',()=>{
 const navigation=readFileSync('app/seller/navigation.tsx','utf8');
 const route=readFileSync('app/seller/competitive/page.tsx','utf8');
 assert.doesNotMatch(navigation,/\["Livestream"/);
 assert.match(navigation,/\["Livestream history", "\/seller\/live-history"/);
 assert.match(route,/requested==="Live Deals"\|\|requested==="Auctions"/);
 assert.match(route,/if\(legacyLiveTab\)redirect\("\/seller\/live-history"\)/);
});
test('successful live deal creation refreshes seller deal state immediately for the studio overlay',async()=>{
 const previous=globalThis.fetch;let dealReads=0;const deal={id:'deal-1',stream:'live',status:'active',starts_at:new Date(Date.now()-1000).toISOString(),ends_at:new Date(Date.now()+60000).toISOString(),product_name:'Stored product',promo_price:900,regular_price:1200,max_quantity:4,sold_quantity:0,image:product.image};
 globalThis.fetch=async(path,options)=>{if(options?.method==='POST'){calls.push({path,body:JSON.parse(options.body)});return Response.json({ok:true,id:deal.id});}if(String(path).startsWith('/api/live-deals')){dealReads++;return Response.json({deals:[deal]});}if(String(path).startsWith('/api/live-auctions'))return Response.json({auctions:[]});if(String(path).startsWith('/api/product-bundles'))return Response.json({bundles:[]});return Response.json(fixture);};
 try{hostState('deal');let tree=render(Host);let form=find(tree,n=>n.type==='form'&&n.props.className==='live-option-list studio-action-form');const fields=flatten(form).filter(n=>n.type==='select'||n.type==='input');fields.find(n=>n.type==='select').props.onChange({target:{value:product.id}});fields.filter(n=>n.type==='input')[0].props.onChange({target:{value:'900'}});fields.filter(n=>n.type==='input')[1].props.onChange({target:{value:'4'}});tree=render(Host);form=find(tree,n=>n.type==='form'&&n.props.className==='live-option-list studio-action-form');form.props.onSubmit(event);await new Promise(resolve=>setTimeout(resolve,0));assert.equal(calls.at(-1).path,'/api/live-deals');assert.equal(calls.at(-1).body.action,'save');assert(dealReads>=1);state[12]='deal';tree=render(Host);assert.match(text(tree),/Stored product/);assert.match(text(tree),/900/);}finally{globalThis.fetch=previous;}
});
test('post-live Done returns to the marketplace instead of Seller Centre',()=>{
 const source=readFileSync('app/workspace/page.tsx','utf8');
 assert(source.includes('<a className="seller-session-back" href="/?browse=1#live">Done</a>'));
 assert.doesNotMatch(source,/<a className="seller-session-back" href="https?:\/\//);
 assert.doesNotMatch(source,/<a className="seller-session-back" href="\/seller[^>]*>Done<\/a>/);
 assert.match(source,/document\.body\.style\.overflow="hidden"/);
 assert.match(source,/<footer className="seller-session-actions">/);
});
test('buyer exit only closes local viewing and all comments remain accessible',()=>{
 viewerState();let tree=render(Viewer,viewerProps);button(tree,'Close broadcast').props.onClick();
 assert.deepEqual(calls,['closed']);assert(!button(tree,'End Live'));assert(!button(tree,'Mute microphone'));
 viewerState('more');tree=render(Viewer,viewerProps);button(tree,'View all comments').props.onClick();
 tree=render(Viewer,viewerProps);assert.match(text(tree),/Actual message/);assert.equal(state[5],'comments');
});
test('buyer stream renders a scrollable history of comments at readable mobile sizes',()=>{
 viewerState();
 state[2]=Array.from({length:36},(_,index)=>({...chat,id:`comment-${index}`,message:`Comment number ${index}`}));
 const tree=render(Viewer,viewerProps);
 const messages=find(tree,n=>n.props.className==='live-messages');
 assert.equal(flatten(messages).filter(n=>n.props.className==='live-comment-row').length,30);
 assert.equal(typeof messages.props.onScroll,'function');
 messages.props.onScroll({currentTarget:{scrollHeight:500,scrollTop:30,clientHeight:120}});
 assert.equal(refs[3].current,false,'reading older comments disables automatic jump-to-latest');
 messages.props.onScroll({currentTarget:{scrollHeight:500,scrollTop:370,clientHeight:120}});
 assert.equal(refs[3].current,true,'returning to the bottom resumes following new comments');
 const css=readFileSync('app/shop-redesign.css','utf8');
 const chatRules=css.slice(css.lastIndexOf('Buyer chat stays readable'));
 assert.match(chatRules,/overflow-y:auto!important/);
 assert.match(chatRules,/touch-action:pan-y!important/);
 assert.match(chatRules,/max-height:clamp\(112px,20vh,176px\)!important/);
 assert.match(chatRules,/live-comment-copy>span\{font-size:13px!important/);
});
test('failed provider ending releases local tracks and exposes a recovery state',async()=>{
 const previous=globalThis.fetch;hostState('leave');audio.stopped=false;video.stopped=false;
 globalThis.fetch=async(path,options)=>{if(options?.method==='POST'){calls.push({path,body:JSON.parse(options.body)});return Response.json({error:'Provider unavailable'},{status:503});}return Response.json(fixture);};
 try{await find(render(Host),n=>n.props.className==='host-end').props.onClick();assert.equal(audio.stopped,true);assert.equal(video.stopped,true);assert.equal(state[4],'');assert.equal(state[7],'End not confirmed — camera stopped');assert.match(state[1],/retry safely/);assert.equal(calls.filter(c=>c.body.action==='end').length,3);}finally{globalThis.fetch=previous;}
});

test('active host manages pinned product from Products sheet without covering live video',async()=>{
 hostState();let tree=render(Host);assert(!find(tree,n=>n.props.className==='host-live-pin'));
 button(tree,'Manage broadcast products').props.onClick();tree=render(Host);assert(find(tree,n=>n.props.className==='product-search'));assert.match(text(tree),/Stored product/);assert(button(tree,'Unpin current product'));assert.equal(calls.length,0);
});
test('unpin is immediate, locked during flight, and rolls back on failure',async()=>{
 const previous=globalThis.fetch;hostState();let resolve;const waiting=new Promise(r=>resolve=r);
 globalThis.fetch=async(path,options)=>{if(options?.method==='POST'){calls.push({path,body:JSON.parse(options.body)});await waiting;return Response.json({error:'Network failed'},{status:503});}return Response.json(fixture);};
 try{button(render(Host),'Manage broadcast products').props.onClick();const unpin=button(render(Host),'Unpin current product');const pending=unpin.props.onClick();unpin.props.onClick();assert.equal(state[0].myStreams[0].product,'');assert.equal(calls.length,1);resolve();await pending;assert.equal(state[0].myStreams[0].product,'p');assert.match(state[1],/Network failed/);}finally{resolve();globalThis.fetch=previous;}
});
test('buyer pin presentation excludes seller actions and blocks stale shopping while disconnected',()=>{
 viewerState();state[4]=true;let tree=render(Viewer,viewerProps);assert.equal(button(tree,'Buy Now').props.disabled,true);assert.equal(button(tree,'Add to Cart').props.disabled,true);assert(!button(tree,'Unpin'));assert(!text(tree).includes('Manage product'));
 button(tree,'Collapse pinned product').props.onClick();tree=render(Viewer,viewerProps);assert.match(text(button(tree,'Expand pinned product')),/Stored product/);
});

test('livestream management sheets use dark glass styling with mobile-safe scrolling and actions',()=>{
 const css=readFileSync('app/design-system.css','utf8');
 const dark=css.split('/* Dark-glass livestream sheets:')[1];
 assert(dark,'dark-glass livestream sheet rules are present');
 assert.match(dark,/background: rgba\(12, 16, 14, \.88\)/);
 assert.match(dark,/border: 1px solid rgb\(255 255 255 \/ 12%\)/);
 assert.match(dark,/border-radius: 24px/);
 assert.match(dark,/backdrop-filter: blur\(12px\)/);
 assert.match(dark,/env\(safe-area-inset-bottom\)/);
 assert.match(dark,/var\(--host-viewport, 100dvh\)/);
 assert.match(dark,/overflow: auto/);
 assert.match(dark,/\.live-sheet-backdrop \.live-sheet::before/);
 assert.match(dark,/product-picker-actions > button:last-child/);
 assert.match(dark,/\.host-end[\s\S]*?#dc3545/);
 assert.match(dark,/\.live-deal-timer[\s\S]*?#ff8a3d/);
 assert.match(dark,/@media \(max-width: 430px\)/);
 assert.doesNotMatch(dark,/\.live-sheet-backdrop\s*\{[^}]*backdrop-filter/);
});

test('pinned host auction card overrides generic workspace article styling',()=>{
 const css=readFileSync('app/design-system.css','utf8');
 assert.match(css,/\.workspace-page\.studio-page \.host-live-stage \.host-featured-commerce\s*\{[^}]*margin: 0;[^}]*padding: 9px 12px;[^}]*background: #0c100ee8;/s);
 assert.match(css,/\.workspace-page\.studio-page \.host-live-stage \.host-live-deal\s*\{[^}]*margin: 0;[^}]*padding: 9px 11px;/s);
});

test('final stylesheet overrides legacy cream livestream sheet and form styles',()=>{
 const layout=readFileSync('app/layout.tsx','utf8');
 const finalCss=readFileSync('app/shop-redesign.css','utf8');
 assert(layout.indexOf('./premium.css')<layout.indexOf('./shop-redesign.css'),'final livestream sheet fixes load after legacy premium rules');
 const fix=finalCss.split('/* Final livestream sheet layer:')[1];
 assert(fix,'final cascade fix is present');
 assert.match(fix,/\.live-sheet-backdrop \.live-sheet\s*\{[^}]*background: rgba\(12, 16, 14, \.92\) !important/s);
 assert.match(fix,/\.live-sheet-backdrop \.live-sheet :is\(input[^}]*background: rgba\(255,255,255,\.08\) !important/s);
 assert.match(fix,/\.host-product-option\s*\{[^}]*background: rgba\(255,255,255,\.06\) !important/s);
 assert.match(fix,/\.product-picker-actions\s*\{[^}]*background: rgba\(12,16,14,\.98\) !important/s);
 assert.match(fix,/@media\(max-width:430px\)/);
});

test('seller live chat shows a scrollable history instead of limiting the stage to two comments',()=>{
 hostState();state[9]=Array.from({length:36},(_,index)=>({...chat,id:`host-comment-${index}`,message:`Seller comment ${index}`}));
 const tree=render(Host);const messages=find(tree,n=>n.props.className==='host-live-chat');
 assert.equal(flatten(messages).filter(n=>n.props.className==='host-live-comment').length,30);
 assert.equal(messages.props.tabIndex,0,'seller can focus and scroll comment history with a keyboard');
 const css=readFileSync('app/shop-redesign.css','utf8');
 assert.match(css,/host-live-chat\{[\s\S]*?overflow-x:hidden!important;overflow-y:auto!important/);
 assert.match(readFileSync('app/workspace/page.tsx','utf8'),/hostChat\.slice\(-30\)/);
 assert.doesNotMatch(readFileSync('app/workspace/page.tsx','utf8'),/hostChat\.slice\(-2\)/);
});

test('auction bid validates visibly and remains confirmed when the optional totals refresh fails',async()=>{
 const originalFetch=globalThis.fetch,OriginalFormData=globalThis.FormData;let posts=0;
 const auction={id:'auction-1',status:'active',canBid:true,product_name:'Stored product',start_price:1000,increment:100,highest_bid:0,bid_count:0,deliveryCoverage:['Lagos'],ends_at:new Date(Date.now()+60000).toISOString()};
 globalThis.FormData=class{constructor(){return [['amount','1000'],['recipient','Buyer'],['phone','08012345678'],['deliveryState','Lagos'],['deliveryAddress','12 Market Road'],['deliveryArea','Ikeja'],['terms','on']][Symbol.iterator]();}};
 globalThis.fetch=async(_path,options)=>{if(options?.method==='POST'){posts++;return Response.json({ok:true,bid:{id:'bid-1',amount:1000,created:new Date().toISOString()}});}return Response.json({error:'refresh unavailable'},{status:503});};
 try{
  viewerState('auction');state[26]=[auction];state[27]='';
  const props={...viewerProps,data:{...viewerProps.data,user:{id:'buyer'}}};let tree=render(Viewer,props);
  const form=find(tree,n=>n.type==='form'&&n.props.className==='live-auction-bid-form');assert(form);assert.equal(form.props.noValidate,true);
  form.props.onSubmit({preventDefault(){},currentTarget:{elements:{namedItem(){return {focus(){}}}}}});
  await new Promise(resolve=>setTimeout(resolve,0));tree=render(Viewer,props);
  assert.equal(posts,1);assert.match(text(tree),/Your bid was recorded/);assert.match(text(tree),/₦1,000/);
  assert.match(readFileSync('app/live-shopping.tsx','utf8'),/auctionBidRequestIds\.current\[auction\.id\]/);
 }finally{globalThis.fetch=originalFetch;globalThis.FormData=OriginalFormData;}
});
