import assert from 'node:assert/strict';
const files=new Map();let signed=true;let mediaVisibility={blocked:0,public_listing:1,public_video:0,public_storefront:0};let mediaVisibilitySql='';let mediaVisibilityArgs=[];
globalThis.mediaEnv={DB:{prepare:(sql)=>({bind:(...args)=>({first:async()=>{if(sql.includes('AS blocked')){mediaVisibilitySql=sql;mediaVisibilityArgs=args;return mediaVisibility;}return sql.includes('media_blocks')?null:({id:'store',user:'seller',count:1});},all:async()=>({results:[]}),run:async()=>({changes:1})})}),batch:async statements=>statements.map(()=>({meta:{changes:1}}))},BUCKET:{put:async(key,buffer,opt)=>files.set(key,{bytes:new Uint8Array(buffer),type:opt.httpMetadata.contentType}),head:async key=>{const f=files.get(key);return f?{size:f.bytes.length,httpEtag:'"test"',customMetadata:{owner:'seller'}}:null;},delete:async key=>files.delete(key),get:async(key,opt)=>{const f=files.get(key);if(!f)return null;const b=opt?.range?f.bytes.slice(opt.range.offset,opt.range.offset+opt.range.length):f.bytes;return {body:b,httpEtag:'"test"',writeHttpMetadata:h=>h.set('Content-Type',f.type)};}}};
globalThis.mediaUser=()=>signed?{userId:'seller'}:null;
const {sourceModule}=await import('./load-route.mjs');
async function module(path){return import(sourceModule(path,'mediaEnv','mediaUser'));}
const upload=await module('app/api/media/route.ts'),download=await module('app/api/media/[key]/route.ts');
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aX1cAAAAASUVORK5CYII=','base64');
const request=(bytes,type='image/png')=>{const form=new FormData();form.append('file',new File([bytes],'test.png',{type}));return new Request('https://revibe.test/api/media',{method:'POST',headers:{origin:'https://revibe.test'},body:form});};
signed=false;assert.equal((await upload.POST(request(png))).status,401);signed=true;assert.equal((await upload.POST(request(Buffer.from('fake')))).status,400);
const r=await upload.POST(request(png));assert.equal(r.status,200);const {url}=await r.json();const key=url.split('/').pop();assert(!key.includes('seller'));
const get=async(headers={})=>download.GET(new Request('https://revibe.test'+url,{headers}),{params:Promise.resolve({key})});
let d=await get();assert.equal(d.status,200);assert.equal((await d.arrayBuffer()).byteLength,png.length);assert.equal(d.headers.get('Accept-Ranges'),'bytes');
mediaVisibility={blocked:0,public_listing:0,public_video:0,public_storefront:1};
d=await get();assert.equal(d.status,200,'published storefront logos and banners must be readable without requiring product/video links');
assert.match(mediaVisibilitySql,/f\.logo IN \(\?,\?\).*f\.banner IN \(\?,\?\).*f\.promo_banner IN \(\?,\?\).*f\.published=1/s);
assert.deepEqual(mediaVisibilityArgs.slice(-6),['/api/media/'+key,'https://revibe.test/api/media/'+key,'/api/media/'+key,'https://revibe.test/api/media/'+key,'/api/media/'+key,'https://revibe.test/api/media/'+key]);
mediaVisibility={blocked:0,public_listing:0,public_video:0,public_storefront:0};assert.equal((await get()).status,404,'draft or unreferenced seller media must remain private');
mediaVisibility={blocked:0,public_listing:1,public_video:0,public_storefront:0};
d=await get({Range:'bytes=0-9'});assert.equal(d.status,206);assert.equal(d.headers.get('Content-Range'),'bytes 0-9/'+png.length);assert.equal((await d.arrayBuffer()).byteLength,10);
d=await get({Range:'bytes=-4'});assert.equal((await d.arrayBuffer()).byteLength,4);assert.equal((await get({Range:'bytes=999-1000'})).status,416);assert.equal((await get({'If-None-Match':'"test"'})).status,304);
assert.equal((await download.GET(new Request('https://revibe.test/api/media/missing'),{params:Promise.resolve({key:'missing'})})).status,404);
console.log('PASS: authenticated upload, media signature validation, opaque file URLs, published storefront branding visibility, private draft protection, full download, seek ranges, suffix ranges, invalid ranges, cache validation and missing media.');

assert.equal((await download.GET(new Request("https://revibe.test/api/media/verification%2Fprivate"),{params:Promise.resolve({key:"verification/private"})})).status,404);
