const fs = require('node:fs/promises');
const path = require('node:path');
const { TwaManifest, TwaGenerator } = require('@bubblewrap/core');
const { fetchUtils } = require('@bubblewrap/core/dist/lib/FetchUtils');
const root = path.resolve(__dirname, '..');
const origin = 'https://revibe-commerce.ogundiyatemidayo1.chatgpt.site';
const webManifest = {
  id: '/', name: 'Cash N Carry', short_name: 'Cash N Carry',
  description: 'Watch Live. Discover. Shop.', start_url: '/', scope: '/',
  display: 'standalone', background_color: '#FFF8EF', theme_color: '#164B35',
  icons: [
    {src:'/brand/cash-n-carry-icon-v2-512.png',sizes:'512x512',type:'image/png',purpose:'any'},
    {src:'/brand/cash-n-carry-icon-v2-maskable.png',sizes:'512x512',type:'image/png',purpose:'maskable'}
  ]
};
// Generate from checked-in approved assets. No network access, account data or secrets.
fetchUtils.fetch = async input => {
  const url = new URL(String(input));
  if (url.origin !== origin) throw Error('Unexpected generation asset origin');
  if (url.pathname === '/api/manifest') return Response.json(webManifest);
  if (!webManifest.icons.some(icon => icon.src === url.pathname)) throw Error('Unexpected generation asset');
  const bytes = await fs.readFile(path.join(root, 'public', url.pathname));
  return new Response(bytes, {headers:{'Content-Type':'image/png'}});
};
(async()=>{
  const manifest = TwaManifest.fromWebManifestJson(new URL(origin+'/api/manifest'), webManifest);
  manifest.packageId = 'site.chatgpt.ogundiyatemidayo1.cashncarry';
  manifest.appVersionName = '1.0.0'; manifest.appVersionCode = 1;
  manifest.enableNotifications = false;
  manifest.fallbackType = 'customtabs';
  manifest.orientation = 'default';
  manifest.additionalTrustedOrigins = [];
  manifest.signingKey = {path:'./upload-key.jks',alias:'cash-n-carry-upload'};
  const invalid = manifest.validate(); if (invalid) throw Error(invalid);
  const destination = path.join(root,'android');
  const logger = {debug(){},info(){},warn:console.warn,error:console.error,setVerbose(){}};
  await new TwaGenerator().createTwaProject(destination,manifest,logger);
  await manifest.saveToFile(path.join(destination,'twa-manifest.json'));
  const gradlePath=path.join(destination,'build.gradle');
  const gradle=await fs.readFile(gradlePath,'utf8');
  await fs.writeFile(gradlePath,gradle.replaceAll('jcenter()', 'mavenCentral()'));
  console.log('Generated Android source. No APK/AAB, signing key or Play submission was created.');
})().catch(error=>{console.error(error.message);process.exitCode=1;});
